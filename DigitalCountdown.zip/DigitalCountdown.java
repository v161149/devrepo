package learnjava.fun;

public class DigitalCountdown {
	// Two dimension array [11][22]
	String[][]  grid = { 
						{"0","0","0","0","0","0","0","0","0","0"," "," ","0","0","0","0","0","0","0","0","0","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0","0","0","0","0","0","0","0","0","0"," "," ","0","0","0","0","0","0","0","0","0","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0"," "," "," "," "," "," "," "," ","0"," "," ","0"," "," "," "," "," "," "," "," ","0"},
						{"0","0","0","0","0","0","0","0","0","0"," "," ","0","0","0","0","0","0","0","0","0","0"}
			           };
	
	
	public DigitalCountdown() {
		// TODO Auto-generated constructor stub
	}

	public void printCountDown() {
		for(int r = 0; r< 11;r++) {
			for(int c = 0; c< 22;c++) {
				System.out.print(grid[r][c]);
			}
			System.out.print("\n");
		}
	}
	
	public String erasePoint(int counter, int row, int col) {
		int onesplace = 0;
		int tensplace = 0;
        if (counter<10) {
        	onesplace = counter;
        	tensplace = 0;
        } else {
        	tensplace = counter/10;
        	onesplace = counter-tensplace*10;
        }

        if (tensplace==0) {
        	//one digit number
    		if(onesplace == 9) {
    			//erase area
    			if (6<=row && row<=9&&col==12) {
    				return " ";
    			}
    		}else if(onesplace == 7) {		
    			if (1<=row && row<=10&&12<=col&&col<=20) {
    				return " ";
    			}			
    		}else if(onesplace == 6) {		
    			if (1<=row && row<=4&&col==21) {
    				return " ";
    			}			
    		}else if(onesplace == 5) {		
    			if ((1<=row && row<=4&&col==21)||(6<=row && row<=9&&col==12)) {
    				return " ";
    			}			
    		}else if(onesplace == 4) {		
    			if ((row==0&&13<=col&&col<=20)||(row==10&&13<=col&&col<=20)||
    				(6<=row&&row<=10&&col==12)) {
    				return " ";
    			}			
    		}else if(onesplace == 3) {		
    			if((1<=row && row<=4&&col==12)||(6<=row&&row<=9&&col==12)) {
    				return " ";
    			}
    		}else if(onesplace == 2) {		
    			if ((1<=row && row<=4&&col==12)||(6<=row && row<=9&&col==21)) {
    				return " ";
    			}			
    		}else if(onesplace == 1) {		
    			if ((0<=row && row<=10&&12<=col&&col<=20)) {
    				return " ";
    			}			
    		}else if(onesplace == 0) {		
    			if ((row==5&&13<=col&&col<=20)) {
    				return " ";
    			}			
    		}
    		
    		//tens digit number
			if ((row==5 && 1<=col&&col<=8)) {
				return " ";
			}    		
        } else {
        	//two digits number
        	
        	//ones place digit
    		if(onesplace == 9) {
    			//erase area
    			if (6<=row && row<=9&&col==12) {
    				return " ";
    			}
    		}else if(onesplace == 7) {		
    			if (1<=row && row<=10&&12<=col&&col<=20) {
    				return " ";
    			}			
    		}else if(onesplace == 6) {		
    			if (1<=row && row<=4&&col==21) {
    				return " ";
    			}			
    		}else if(onesplace == 5) {		
    			if ((1<=row && row<=4&&col==21)||(6<=row && row<=9&&col==12)) {
    				return " ";
    			}			
    		}else if(onesplace == 4) {		
    			if ((row==0&&1<=col&&col<=8)||(row==10&&1<=col&&col<=8)||
        				(6<=row&&row<=10&&col==0)) {
    				return " ";
    			}			
    		}else if(onesplace == 3) {		
    			if((1<=row && row<=4&&col==12)||(6<=row&&row<=9&&col==12)) {
    				return " ";
    			}
    		}else if(onesplace == 2) {		
    			if ((1<=row && row<=4&&col==12)||(6<=row && row<=9&&col==21)) {
    				return " ";
    			}			
    		}else if(onesplace == 1) {		
    			if ((0<=row && row<=10&&12<=col&&col<=20)) {
    				return " ";
    			}			
    		}else if(onesplace == 0) {		
    			if ((row==5&&13<=col&&col<=20)) {
    				return " ";
    			}			
    		}
    		
        	//tens place digit
    		if(tensplace == 9) {
    			//erase area
    			if (6<=row && row<=9&&col==0) {
    				return " ";
    			}
    		}else if(tensplace == 7) {		
    			if (1<=row && row<=10&&0<=col&&col<=8) {
    				return " ";
    			}			
    		}else if(tensplace == 6) {		
    			if (1<=row && row<=4&&col==9) {
    				return " ";
    			}			
    		}else if(tensplace == 5) {		
    			if ((1<=row && row<=4&&col==9)||(6<=row && row<=9&&col==0)) {
    				return " ";
    			}			
    		}else if(tensplace == 4) {		
    			if ((row==0&&1<=col&&col<=8)||(row==10&&1<=col&&col<=8)||
    				(6<=row&&row<=9&&col==1)||(row==10&&0<=col&&col<=8)) {
    				return " ";
    			}			
    		}else if(tensplace == 3) {		
    			if((1<=row && row<=4&&col==0)||(6<=row&&row<=9&&col==0)) {
    				return " ";
    			}
    		}else if(tensplace == 2) {		
    			if ((1<=row && row<=4&&col==0)||(6<=row && row<=9&&col==9)) {
    				return " ";
    			}			
    		}else if(tensplace == 1) {		
    			if ((0<=row && row<=10&&0<=col&&col<=8)) {
    				return " ";
    			}			
    		}else if(tensplace == 0) {		
    			if ((row==5&&1<=col&&col<=8)) {
    				return " ";
    			}			
    		}    		
        }
		return null;
	}
	
	public void printnumber(int counter) {
		String dot = "";
		for(int r = 0; r< 11;r++) {	
			for(int c = 0; c< 22;c++) {
				dot = erasePoint(counter,r,c);
				if (dot!=null) {
					System.out.print(dot);
				} else {
					System.out.print(grid[r][c]);
				}
			}
			System.out.print("\n");
		}
	}
	
	public static void main(String[] args) {
		try {
			DigitalCountdown countdown = new DigitalCountdown();
			int counter = 0;
			while(counter>=0) { 
				System.out.println("\n----------------------\n");
				countdown.printnumber(counter);
				counter++;	
				Thread.sleep(1000);
			}
		}catch(Exception exp) {
			exp.printStackTrace();
		}
	}
}
