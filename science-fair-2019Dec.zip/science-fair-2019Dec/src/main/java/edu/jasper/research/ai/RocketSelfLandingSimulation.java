package edu.jasper.research.ai;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
import org.encog.Encog;
import org.encog.ml.MLMethod;
import org.encog.ml.MLResettable;
import org.encog.ml.MethodFactory;
import org.encog.ml.genetic.MLMethodGeneticAlgorithm;
import org.encog.ml.train.MLTrain;
import org.encog.neural.networks.BasicNetwork;
import org.encog.util.obj.SerializeObject;

public class RocketSelfLandingSimulation {
	
	public static int epochSequenceNumber = 1;
	
	public static void main(String args[]) {
		Scanner sc = null;
		//we start the simulation when the first stage captures the below flying parameters values through the system sensors
		int initialFuel=200;
		double initialAltitude=80000;
		double initialVelocity=0;
		MLTrain train;
		
	    try {
		    System.out.println("*=======================================================================================================*");
			System.out.println("*This program simulates how reusable orbital rocket use Deep Learning Neural Network Algorithms         *");
			System.out.println("*back to Earth for a soft touchdown (-2 m/s ~ +2 ms).                                                                    *");
			System.out.println("*-------------------------------------------------------------------------------------------------------*");
			System.out.println("*The orbital rocket starts with 200 liters and the altitude is set to 10,000 meters above Earth surface.*");
			System.out.println("*The fuel variable holds the amount of fuel remaining.                                                  *");
			System.out.println("*The time variable holds the number of seconds aloft.                                                   *");
			System.out.println("*The altitude variable holds the current altitude in meters.                                            *");
			System.out.println("*The velocity variable holds the current velocity.                                                      *");
			System.out.println("*Positive numbers indicate that the craft is moving upwards.                                            *");
			System.out.println("*Negative numbers indicate that the craft is moving downwards.                                          *");
			System.out.println("*The thrust parameter indicates whether the orbital rocket needs to thrust during this turn             *");
			System.out.println("*-------------------------------------------------------------------------------------------------------*");
			System.out.println("*The simulator sets the values to reasonable starting values in the following :                         *");
			System.out.println("*             f u e l         = 200   liters                                                            *");
			System.out.println("*             timer           = 0     seconds                                                           *");
			System.out.println("*             a l t i t u d e = 80    kms                                                               *");
			System.out.println("*=======================================================================================================*\n\n\n");

			String trainingModelFile = "C:\\education\\science-fair\\data\\trainingModel";
			sc = new Scanner(System.in);
			System.out.println("Please enter T to train the neural network, enter R to let the network to pilot the rocket landing");
			String userInput = sc.next();
			
			if(userInput.charAt(0)=='T'||userInput.charAt(0)=='t') {			

				train = new MLMethodGeneticAlgorithm(new MethodFactory(){
				//@Override
				public MLMethod factor() {
					//create an AI Deep Learning network
					AIDeepLearningNetworkCreator aiCreator = new AIDeepLearningNetworkCreator();
					final BasicNetwork result = aiCreator.createAIDeepLearningNetwork();
					((MLResettable)result).reset();
					return result;
				}},new AISelfPilotPerfMetric(initialFuel,initialAltitude,initialVelocity),1000);
				
				for(int i=0;i<50;i++) {
					train.iteration();
					System.out.println("Epoch #" + epochSequenceNumber + " Score:" + train.getError());
					epochSequenceNumber++;
				} 

				train.finishTraining();
				System.out.println("\nSave the neural network training model:");
				SerializeObject.save(new File(trainingModelFile), (BasicNetwork)train.getMethod());
				System.out.println("\nNow the neural network algorithm will pilot the landing prrocess of the reusable rocket:");
				BasicNetwork network = (BasicNetwork)train.getMethod();
				AISelfPilotProcessor pilot = new AISelfPilotProcessor(network,true,initialFuel,initialAltitude,initialVelocity);
				System.out.println(pilot.evaluateAISelfPilotPerfMetric());					
			} else {
				System.out.println("\nLoad the neural network training model.");
				System.out.println("\nShow How the neural network algorithm pilot the landing prrocess of the reusable rocket:");
				BasicNetwork network = (BasicNetwork)SerializeObject.load(new File(trainingModelFile));
				AISelfPilotProcessor pilot = new AISelfPilotProcessor(network,true,initialFuel,initialAltitude,initialVelocity);
				System.out.println(pilot.evaluateAISelfPilotPerfMetric());					
			}

	    } catch(Exception exp) {
		    exp.printStackTrace();
	    } finally {
			sc.close();
			Encog.getInstance().shutdown();		  
	    }
	}
}
