package edu.jasper.research.ai;

import java.text.NumberFormat;

public class RocketThrottleController {
	//list of constant values
	public static final double EARTH_GRAVITY = 9.807;            // Earth gravity is 9.807 m/s^2
	public static final double THRUST = 50;                      // Each thrust adds 50 m/s
	public static final double EARTH_TERMINAL_VELOCITY = 162;     // Earth terminal velocity 130 m/s

	//list of important sensors connected to rocket throttle controller
	private int fuel = 0;
	private int timer = 0;
	private double altitude = 0;
	private double velocity = 0;
	
	/*
	 * turn on self pilot mode when the first stage rocket reach certain altitude and speed..
	 * collect rocket sensor parameter values and reset timer to zero
	 */
	public void enableSelfPilotMode(int fuelSesor, double altitudeSensor, double velocitySensor) {
		this.fuel = fuelSesor;
		this.timer = 0;
		this.altitude = altitudeSensor;
		this.velocity = velocitySensor;		
	}
	
	public void turn(boolean thrust) {
		this.timer++;
		this.velocity -= EARTH_GRAVITY;
		this.altitude += this.velocity;

		if (thrust && this.fuel > 0 && this.altitude >0) {
			this.fuel--;
			this.velocity += THRUST;
		}

		this.velocity = Math.max(-EARTH_TERMINAL_VELOCITY, this.velocity);
		this.velocity = Math.min(EARTH_TERMINAL_VELOCITY, this.velocity);
		
		if (this.altitude <0) {
			this.altitude =0;
		}
	}

	public String readRocketFlyingParameters() {
		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMinimumFractionDigits(4);
		nf.setMaximumFractionDigits(4);
		StringBuilder result = new StringBuilder();
		result.append("Elapsed: ");
		result.append(timer);
		result.append(" s, Fuel: ");
		result.append(this.fuel);
		result.append(" l, Velocity: ");
		result.append(nf.format(velocity));
		result.append(" m/s, ");
		result.append((int) altitude);
		result.append(" m");
		return result.toString();
	}

	public int score() {
		return (int) ((this.fuel * 27) + (this.velocity * 395)); // 25, 375
	}

	public int readFuel() {
		return fuel;
	}

	public int readTimers() {
		return timer;
	}

	public double readAltitude() {
		return altitude;
	}

	public double readtVelocity() {
		return velocity;
	}

	public boolean flying() {
		return (this.altitude > 0);
	}	
}
