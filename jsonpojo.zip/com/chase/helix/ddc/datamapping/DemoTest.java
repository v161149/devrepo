package com.chase.helix.ddc.datamapping;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DemoTest {

   public Staff createStaffObject() {

        Staff staff = new Staff();

        staff.setName("mkyong");
        staff.setAge(35);
        staff.setPosition(new String[]{"Founder", "CTO", "Writer"});
        Map<String, BigDecimal> salary = new HashMap<String, BigDecimal>() {{
            put("2010", new BigDecimal(10000));
            put("2012", new BigDecimal(12000));
            put("2018", new BigDecimal(14000));
        }};
        staff.setSalary(salary);
        staff.setSkills(Arrays.asList("java", "python", "node", "kotlin"));

        return staff;
    }	
   
	public static void main(String[] args) {
		try {
			DemoTest inst = new DemoTest();
			System.out.println("start testing the logic that converts pojo to json string.");
			Staff staff = inst.createStaffObject();
			//convert pojo to json string
			String jsonStr = null;
			GsonPojoConverter<String, Staff> jsonpojoconv = new GsonPojoConverter<String, Staff>();
			jsonStr = jsonpojoconv.convertPojoToGsonString(staff);
			System.out.println(jsonStr);
			System.out.println("End testing");
			
			System.out.println("start testing the logic that converts json string to pojo.");
		    //convert json to pojo
			String srcJson = IJsonTestData.DEMO_JSON_DATA;
			Staff staff2 = new Staff();
			staff2 = jsonpojoconv.convertGsonStringToPojo(srcJson,staff2);
			System.out.println("End testing");
		} catch (Exception exp) {
			exp.printStackTrace();
		}

	}

}
