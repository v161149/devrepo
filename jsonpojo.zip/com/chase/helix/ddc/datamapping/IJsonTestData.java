package com.chase.helix.ddc.datamapping;

public interface IJsonTestData {
	public static final String DEMO_JSON_DATA = "{\r\n" + 
			"  \"name\": \"mkyong\",\r\n" + 
			"  \"age\": 35,\r\n" + 
			"  \"position\": [\r\n" + 
			"    \"Founder\",\r\n" + 
			"    \"CTO\",\r\n" + 
			"    \"Writer\"\r\n" + 
			"  ],\r\n" + 
			"  \"skills\": [\r\n" + 
			"    \"java\",\r\n" + 
			"    \"python\",\r\n" + 
			"    \"node\",\r\n" + 
			"    \"kotlin\"\r\n" + 
			"  ],\r\n" + 
			"  \"salary\": {\r\n" + 
			"    \"2018\": 14000,\r\n" + 
			"    \"2012\": 12000,\r\n" + 
			"    \"2010\": 10000\r\n" + 
			"  }\r\n" + 
			"}";
}
