package com.chase.helix.ddc.datamapping;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GsonPojoConverter<GSON_STR, POJO_CLAZZ> implements IGsonPojoConverter<GSON_STR, POJO_CLAZZ> {

	@Override
	public POJO_CLAZZ convertGsonStringToPojo(final GSON_STR gsonstr, POJO_CLAZZ pojo) throws Exception {
		if (!(gsonstr instanceof String)) {
			throw new RuntimeException("Bad input data issue for type " + gsonstr.getClass().getSimpleName());
		} else if (pojo ==null) {
			throw new RuntimeException("null pointer was caught for POJO type.");
		}
		Gson gson = new Gson();
		pojo = (POJO_CLAZZ) gson.fromJson((String)gsonstr, pojo.getClass());
		return pojo;
	}

	@Override
	public GSON_STR convertPojoToGsonString(POJO_CLAZZ pojo) throws Exception {
		if (pojo ==null) {
			throw new RuntimeException("null pointer was caught for POJO type.");
		}
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		return (GSON_STR)gson.toJson(pojo, pojo.getClass());
	}
}
