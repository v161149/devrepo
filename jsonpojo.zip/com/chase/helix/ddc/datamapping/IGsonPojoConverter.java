package com.chase.helix.ddc.datamapping;

public interface IGsonPojoConverter<GSON_STR, POJO_CLAZZ> {
	public POJO_CLAZZ convertGsonStringToPojo(final GSON_STR gsonstr, POJO_CLAZZ pojo) throws Exception;
	public GSON_STR convertPojoToGsonString(POJO_CLAZZ pojo) throws Exception;
}
