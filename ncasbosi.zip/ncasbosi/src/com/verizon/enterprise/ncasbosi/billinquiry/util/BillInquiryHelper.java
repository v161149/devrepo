package com.verizon.enterprise.ncasbosi.billinquiry.util;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Map;
import java.util.List;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry.OneViewRespVO;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.Request;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.ServiceAgreement;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.ServiceAgreementAttachment;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.ArrayOfRequestServiceAgreementServiceAgreementAttachment;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingresponse.pipelines.biztalk.ebillingtooneview.networx.Response;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.kernel.xml.XmlParseException;

/**
 * A Helper class to populate OV soap request. Note - we created a different method for each OSID as the
 * pre-cursor to the Web Service was an http interface that needed it that way.
 * Oneview is a very finicky system, change this with caution.
 *
 * 02/2009 PVB - Update to latest version of OV WS
 *
 */
public class BillInquiryHelper implements NCASBOSIConstants, NcasConstants
{
    static private final Logger _Logger = Logger
            .getLogger(BillInquiryHelper.class);

    public BillInquiryHelper()
    {
    }

    public Request getCreateInputSOAPRequestForIxplus(BillInquiry bi)
            throws XmlParseException
    {
        Request myRequest = getInitilizedRequest();

        String dateStr = "";
        String repStr;
        String san10Chk = "";
        String envChk = "";

        myRequest.setAction("Create");
        myRequest.setSysName(BI_IXPLUS);

        try
        {
            myRequest.setEnvironment(envChk);
            san10Chk = bi.getSAN10();
            if (san10Chk == null)
                throw new Exception("Invalid Data: SAN is NULL");
            else
                myRequest.setAccountNum(san10Chk);

            dateStr = CommonUtil.getFormattedDateString(bi.getBillDate(),
                    "yyyyMMdd");

            myRequest.setAccountName(bi.getAcctName());
            myRequest.setInvoiceNumber(bi.getInvoiceNum());
            myRequest.setInvoiceBillDate(dateStr);
        }
        catch (Exception ex)
        {
            _Logger
                    .error("error while creating Create Xml to be sent to One View\n"
                            + ex.getMessage(), ex);
            throw new XmlParseException(ex.getMessage());
        }
        _Logger
                .info("Quotes, Hyphens, Spaces will be removed from the first and last name becuase One View does not support special characters");

        repStr = new String(bi.getSenderLastName());
        _Logger.info("Last Name Before removing special characters " + repStr);
        repStr = repStr.replaceAll("[^a-z || A-Z]", "");
        repStr = repStr.replaceAll("\\s+", "");
        _Logger.info("Last Name After removing special characters " + repStr);
        myRequest.setContactLastName(repStr);
        repStr = new String(bi.getSenderFirstName());
        _Logger.info("First Name Before removing special characters " + repStr);
        repStr = repStr.replaceAll("[^a-z || A-Z]", "");
        repStr = repStr.replaceAll("\\s+", "");
        _Logger.info("First Name After removing special characters " + repStr);

        myRequest.setContactFirstName(repStr);
        myRequest.setContactPhone(bi.getSenderPhone());
        myRequest.setContactEmail(bi.getSenderEmail());
        myRequest.setCCEmail(bi.getAddlEmail());
        myRequest.setCreditDispAmount(new BigDecimal("0.00"));
        myRequest.setReasonCode(bi.getReasonCode());
        myRequest.setReasonDetail(bi.getReason());
        myRequest.setCommentText(bi.getInquiryMemo());
        myRequest.setOriginatingSystem(BI_ORIG_SYSTEM);

        //set <ServiceAgreement> section data
        ServiceAgreement serviceAgreement = setServiceAgreementSection(bi, myRequest);
		myRequest.setServiceAgreement(serviceAgreement);

        return myRequest;
    }


    public Request getCreateInputSOAPRequestForIBRSVision(BillInquiry bi)
            throws XmlParseException
    {
        /*
         * Handle both M1 and M2 as only difference in System Value (at least
         * for now). 01/2008 PVB
         */

        Request myRequest = getInitilizedRequest();

        String outXmlStr = "";
        String dateStr = "";
        String repStr;

        myRequest.setAction("Create");


        /*
         * Based on if stmt in BillInquiryDAOImpl - only getting in here if M1
         * or M2 - hence if stmt below. PVB
         */
        if ("M1".equalsIgnoreCase(bi.getOSID()))
            myRequest.setSysName(BI_IBRS);
        else
            myRequest.setSysName(BI_VISION);
        try
        {

            myRequest.setAccountNum(bi.getSAN());
            myRequest.setAccountName(bi.getAcctName());
            myRequest.setInvoiceNumber(bi.getInvoiceNum());
            dateStr = CommonUtil.getFormattedDateString(bi.getBillDate(),
                    "yyyyMMdd");
        }
        catch (Exception ex)
        {
            _Logger
                    .debug("error while creating Create Xml to be sent to One View\n"
                            + ex.getMessage());
            _Logger
                    .error("error while creating Create Xml to be sent to One View\n"
                            + ex.getMessage());
            throw new XmlParseException(ex.getMessage());
        }
        myRequest.setInvoiceBillDate(dateStr);
        _Logger
                .info("Quotes, Hyphens, Spaces will be removed from the first and last name becuase One View does not support special characters");
        repStr = new String(bi.getSenderLastName());
        _Logger.info("Last Name Before removing special characters " + repStr);

        repStr = repStr.replaceAll("[^a-z || A-Z]", "");
        repStr = repStr.replaceAll("\\s+", "");
        _Logger.info("Last Name After removing special characters " + repStr);

        myRequest.setContactLastName(repStr);
        repStr = new String(bi.getSenderFirstName());
        _Logger.info("First Name Before removing special characters " + repStr);

        repStr = repStr.replaceAll("[^a-z || A-Z]", "");
        repStr = repStr.replaceAll("\\s+", "");
        _Logger.info("First Name After removing special characters " + repStr);

        myRequest.setContactFirstName(repStr);

        myRequest.setContactPhone(bi.getSenderPhone());
        myRequest.setContactEmail(bi.getSenderEmail());
        myRequest.setCCEmail(bi.getAddlEmail());
		myRequest.setCreditDispAmount(new BigDecimal("0.00"));
        myRequest.setReasonCode(bi.getReasonCode());
        myRequest.setReasonDetail(bi.getReason());
        myRequest.setCommentText(bi.getInquiryMemo());
        myRequest.setOriginatingSystem(BI_ORIG_SYSTEM);

        //set <ServiceAgreement> section data
        ServiceAgreement serviceAgreement = setServiceAgreementSection(bi, myRequest);
		myRequest.setServiceAgreement(serviceAgreement);

        return myRequest;
    }


    public Request getCreateInputSOAPRequestForSingleView(BillInquiry bi)
            throws XmlParseException
    {
        Request myRequest = getInitilizedRequest();

        String dateStr = "";
        String repStr;

        myRequest.setAction("Create");
        myRequest.setSysName(BI_SINGELVIEW);

        try
        {
            myRequest.setAccountNum(bi.getSAN());
            myRequest.setAccountName(bi.getAcctName());
            myRequest.setInvoiceNumber(bi.getInvoiceNum());
            dateStr = CommonUtil.getFormattedDateString(bi.getBillDate(),
                    "yyyyMMdd");
        }
        catch (Exception ex)
        {
            _Logger
                    .error("error while creating Create Xml to be sent to One View\n"
                            + ex.getMessage());
            throw new XmlParseException(ex.getMessage());
        }
        myRequest.setInvoiceBillDate(dateStr);
        _Logger
                .info("Quotes, Hyphens, Spaces will be removed from the first and last name becuase One View does not support special characters");

        repStr = new String(bi.getSenderLastName());
        _Logger.info("Last Name Before removing special characters " + repStr);
        repStr = repStr.replaceAll("[^a-z || A-Z]", "");
        repStr = repStr.replaceAll("\\s+", "");
        _Logger.info("Last Name After removing special characters " + repStr);
        myRequest.setContactLastName(repStr);
        repStr = new String(bi.getSenderFirstName());
        _Logger.info("First Name Before removing special characters " + repStr);
        repStr = repStr.replaceAll("[^a-z || A-Z]", "");
        repStr = repStr.replaceAll("\\s+", "");
        _Logger.info("First Name After removing special characters " + repStr);
        myRequest.setContactFirstName(repStr);
        myRequest.setContactPhone(bi.getSenderPhone());
        myRequest.setContactEmail(bi.getSenderEmail());
        myRequest.setCCEmail(bi.getAddlEmail());
		myRequest.setCreditDispAmount(new BigDecimal("0.00"));
        myRequest.setReasonCode(bi.getReasonCode());
        myRequest.setReasonDetail(bi.getReason());

        myRequest.setCommentText(bi.getInquiryMemo());
        myRequest.setOriginatingSystem(BI_ORIG_SYSTEM);
        myRequest.setSVCustCode(bi.getCustSvcType());

        //set <ServiceAgreement> section data
        ServiceAgreement serviceAgreement = setServiceAgreementSection(bi, myRequest);
		myRequest.setServiceAgreement(serviceAgreement);

        return myRequest;
    }

    public Request getCancelInputSOAPRequest(BillInquiry bi) throws Exception
    {

        Request myRequest = new Request();
        myRequest.setAction("Cancel");
        if (bi.getOSID().equalsIgnoreCase(SINGLEVIEW))
            myRequest.setSysName(BI_SINGELVIEW);
        else if (bi.getOSID().equalsIgnoreCase(IXPLUS))
            myRequest.setSysName(BI_IXPLUS);
               else if (bi.getOSID().equalsIgnoreCase(IBRS))
                   myRequest.setSysName(BI_IBRS);
        else if (bi.getOSID().equalsIgnoreCase(VISION))
            myRequest.setSysName(BI_VISION);
        else
            throw new Exception("BAD OSID for BI Cancel: " + bi.getOSID());
        myRequest.setTrackingID(bi.getSrcSysBIID());
        myRequest.setCommentText(bi.getInquiryMemo());
        return myRequest;
    }


	//For SingleView system only
    public Request getCancelInputSOAPRequestForSingleView(BillInquiry bi) throws Exception
    {
        Request myRequest = new Request();
        myRequest.setAction("Cancel");

        if (bi.getOSID().equalsIgnoreCase(SINGLEVIEW))
        {
            myRequest.setSysName(BI_SINGELVIEW);
		}
        else if (bi.getOSID().equalsIgnoreCase(IXPLUS))
        {
            myRequest.setSysName(BI_IXPLUS);
		}
        else if (bi.getOSID().equalsIgnoreCase(IBRS))
        {
			myRequest.setSysName(BI_IBRS);
		}
        else if (bi.getOSID().equalsIgnoreCase(VISION))
        {
            myRequest.setSysName(BI_VISION);
		}
        else
        {
            throw new Exception("BAD OSID for BI Cancel: " + bi.getOSID());
		}

        myRequest.setTrackingID(bi.getSrcSysBIID());
        myRequest.setCommentText(bi.getInquiryMemo());
        myRequest.setSVCustCode(bi.getCustSvcType());

        return myRequest;
    }



    public OneViewRespVO transformOVSOAPResponse(Response myResponse)
            throws XmlParseException
    {
        OneViewRespVO ovRespVo = new OneViewRespVO();

        ovRespVo.setAction(myResponse.getAction());
        ovRespVo.setTrackingID(myResponse.getTrackingID());
        ovRespVo.setResponseCode(myResponse.getReturnMsgCode());
        ovRespVo.setResponseMessage(myResponse.getReturnMsgText());

        return ovRespVo;
    }
    public static void printMap(Map results)
    {
        for (Iterator it = results.entrySet().iterator(); it.hasNext();)
        {
            _Logger.info(it.next());
        }
    }

    public static String mapToString(Map results)
    {
        StringBuffer sb = new StringBuffer();
        for (Iterator it = results.entrySet().iterator(); it.hasNext();)
        {
            sb.append(it.next());
        }
        return sb.toString();
    }


    public Request getInitilizedRequest()
    {
    	Request myRequest = new Request();

    	myRequest.setAction("");
    	myRequest.setAccountName("");
    	myRequest.setAccountNum("");
    	myRequest.setAdjustmentDate("");
    	myRequest.setAgencyHierCode("");
    	myRequest.setBillingPeriodThru("");
    	myRequest.setCCEmail("");
    	myRequest.setCircuitID("");
    	//ClinItem myItem[] = new ClinItem[0];
    	//myRequest.setClinItem(myItem);
    	myRequest.setCommentText("");
    	myRequest.setContactAddr1("");
    	myRequest.setContactAddr2("");
    	myRequest.setContactCity("");
    	myRequest.setContactEmail("");
    	myRequest.setContactFirstName("");
    	myRequest.setContactLastName("");
    	myRequest.setContactPhone("");
    	myRequest.setContactState("");
    	myRequest.setContactTitle("");
    	myRequest.setContactZip("");
    	myRequest.setCreditDispAmount(new BigDecimal(0));
    	myRequest.setEnvironment("");
    	myRequest.setGovContractNum("");
    	myRequest.setGovDisputeNum("");
    	myRequest.setInvoiceBillDate("");
    	myRequest.setInvoiceNumber("");
    	myRequest.setNetInvCode("");
    	myRequest.setOriginatingSystem("");
    	myRequest.setPreferredMethodContact("");
    	myRequest.setReasonCode("");
    	myRequest.setReasonDetail("");
    	myRequest.setService("");
    	myRequest.setSysName("");
    	myRequest.setTrackingID("");
    	myRequest.setUniqueBillID("");
    	myRequest.setSVCustCode("");

		ServiceAgreement serviceAgreement = new ServiceAgreement();
        serviceAgreement.setInvDate("");
		serviceAgreement.setToAddrAttn("");
		serviceAgreement.setToAddrLine1("");
		serviceAgreement.setToAddrLine2("");
		serviceAgreement.setToAddrCity("");
		serviceAgreement.setToAddrState("");
		serviceAgreement.setToAddrZip("");
		serviceAgreement.setOldAddrAttn("");
		serviceAgreement.setOldAddrLine1("");
		serviceAgreement.setOldAddrLine2("");
		serviceAgreement.setOldAddrCity("");
		serviceAgreement.setOldAddrState("");
		serviceAgreement.setOldAddrZip("");
		serviceAgreement.setNewAddrAttn("");
		serviceAgreement.setNewAddrLine1("");
		serviceAgreement.setNewAddrLine2("");
		serviceAgreement.setNewAddrCity("");
		serviceAgreement.setNewAddrState("");
		serviceAgreement.setNewAddrZip("");
		serviceAgreement.setNewContactAddrAttn("");
		serviceAgreement.setNewContactAddrLine1("");
		serviceAgreement.setNewContactAddrLine2("");
		serviceAgreement.setNewContactCity("");
		serviceAgreement.setNewContactAddrState("");
		serviceAgreement.setNewContactAddrZip("");
		serviceAgreement.setLOA("");
		serviceAgreement.setAdjReason("");
		serviceAgreement.setDisputedAdj("");
        serviceAgreement.setExpectedAdj("");
		serviceAgreement.setTransFromAcct("");
		serviceAgreement.setTransToAcct("");
		serviceAgreement.setTransAmt("");
		serviceAgreement.setReqSvc("");
		serviceAgreement.setReqInstallDt("");
		serviceAgreement.setDtBlgBegan("");
		serviceAgreement.setDisputeAmt("");
		serviceAgreement.setInvPgNo("");
		serviceAgreement.setProblemBeganDt("");
		serviceAgreement.setProblemEndDt("");
        serviceAgreement.setDupAcctNos("");
        serviceAgreement.setDisputedChgs("");
        serviceAgreement.setContractID("");
        serviceAgreement.setAmendID("");
        serviceAgreement.setAdditionalAcctNos("");
        serviceAgreement.setPromoType("");
        serviceAgreement.setAffectedSvcID("");
        serviceAgreement.setTroubleTicketNo("");
        serviceAgreement.setTaxType("");
        serviceAgreement.setTaxForm("");
        serviceAgreement.setDisonnectDt("");
        serviceAgreement.setLOD("");
        serviceAgreement.setLOC("");
        serviceAgreement.setPostedToAcct("");
        serviceAgreement.setShouldHavePostedToAcct("");
        serviceAgreement.setCheckCopy("");
        serviceAgreement.setReqRefundAmt("");

		ArrayOfRequestServiceAgreementServiceAgreementAttachment arrayOfRequestServiceAgreementAttachment = new ArrayOfRequestServiceAgreementServiceAgreementAttachment();
        ServiceAgreementAttachment[] serviceAgreementAttachment = null;
		arrayOfRequestServiceAgreementAttachment.setServiceAgreementAttachment(serviceAgreementAttachment);
		serviceAgreement.setListOfServiceAgreementAttachment(arrayOfRequestServiceAgreementAttachment);

		myRequest.setServiceAgreement(serviceAgreement);

    	return myRequest;
    }


    public ServiceAgreement setServiceAgreementSection(BillInquiry bi, Request request)
    {
		ServiceAgreement serviceAgreement = request.getServiceAgreement();

		//Invoice Copy
		if ("EB0240".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setInvDate(bi.getInvoiceCopyDate());
			serviceAgreement.setToAddrAttn(bi.getAddrAttention());
			serviceAgreement.setToAddrLine1(bi.getAddrLine1());
			serviceAgreement.setToAddrLine2(bi.getAddrLine2());
			serviceAgreement.setToAddrCity(bi.getAddrCity());
			serviceAgreement.setToAddrState(bi.getAddrState());
			serviceAgreement.setToAddrZip(bi.getAddrZip());
		}
		//Billing Address Change
		else if ("EB0250".equals(bi.getReasonCode()))
		{
			serviceAgreement.setOldAddrAttn(bi.getAddrAttention());
			serviceAgreement.setOldAddrLine1(bi.getAddrLine1());
			serviceAgreement.setOldAddrLine2(bi.getAddrLine2());
			serviceAgreement.setOldAddrCity(bi.getAddrCity());
			serviceAgreement.setOldAddrState(bi.getAddrState());
			serviceAgreement.setOldAddrZip(bi.getAddrZip());
			serviceAgreement.setNewAddrAttn(bi.getNewAddrAttention());
			serviceAgreement.setNewAddrLine1(bi.getNewAddrLine1());
			serviceAgreement.setNewAddrLine2(bi.getNewAddrLine2());
			serviceAgreement.setNewAddrCity(bi.getNewAddrCity());
			serviceAgreement.setNewAddrState(bi.getNewAddrState());
			serviceAgreement.setNewAddrZip(bi.getNewAddrZip());
		}
		//Contact Information Change
		else if ("EB0260".equals(bi.getReasonCode()))
		{
			serviceAgreement.setNewContactAddrAttn(bi.getAddrAttention());
			serviceAgreement.setNewContactAddrLine1(bi.getAddrLine1());
			serviceAgreement.setNewContactAddrLine2(bi.getAddrLine2());
			serviceAgreement.setNewContactCity(bi.getAddrCity());
			serviceAgreement.setNewContactAddrState(bi.getAddrState());
			serviceAgreement.setNewContactAddrZip(bi.getAddrZip());
	        serviceAgreement.setLOA(bi.getAttachmentInd());
		}
		//Adjustment Incorrect
		else if ("EB0270".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setAdjReason(bi.getAdjustmentReason());
			serviceAgreement.setDisputedAdj(bi.getDisputeAmount());
	        serviceAgreement.setExpectedAdj(bi.getExpectedAdjustment());
		}
		//Credit Transfer
		else if ("EB0280".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setTransFromAcct(bi.getTransferFrom());
	        serviceAgreement.setTransToAcct(bi.getTransferTo());
	        serviceAgreement.setTransAmt(bi.getTransferAmount());
	        serviceAgreement.setLOA(bi.getAttachmentInd());
		}
		//Early Billing
		else if ("EB0290".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setReqSvc(bi.getServiceRequested());
	        serviceAgreement.setReqInstallDt(bi.getInstallationDate());
	        serviceAgreement.setDtBlgBegan(bi.getBillingDate());
		}
		//Incorrect Service Provider/billed by another provider
		else if ("EB0300".equals(bi.getReasonCode()))
		{
			serviceAgreement.setDisputeAmt(bi.getDisputeAmount());
	        serviceAgreement.setInvPgNo(bi.getImpactedInvoicePageNum());
	        serviceAgreement.setProblemBeganDt(bi.getProblemBeganDate());
	        serviceAgreement.setProblemEndDt(bi.getProblemEndDate());
		}
		//Do not recognize Service or Charge
		else if ("EB0310".equals(bi.getReasonCode()))
		{
			serviceAgreement.setDisputeAmt(bi.getDisputeAmount());
		}
		//Duplicate Billing
		else if ("EB0320".equals(bi.getReasonCode()))
		{
			serviceAgreement.setDisputeAmt(bi.getDisputeAmount());
	        serviceAgreement.setDupAcctNos(bi.getAdditionalAcctNumbers());
		}
		//Incorrect Rate
		else if ("EB0330".equals(bi.getReasonCode()))
		{
			serviceAgreement.setDisputedChgs(bi.getDisputeAmount());
	        serviceAgreement.setContractID(bi.getContractId());
	        serviceAgreement.setAmendID(bi.getAmendmentId());
	        serviceAgreement.setAdditionalAcctNos(bi.getAdditionalAcctNumbers());
		}
		//Late Payment Charge
		else if ("EB0340".equals(bi.getReasonCode()))
		{
			serviceAgreement.setDisputeAmt(bi.getDisputeAmount());
		}
		//Promotions
		else if ("EB0360".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setContractID(bi.getContractId());
	        serviceAgreement.setAmendID(bi.getAmendmentId());
	        serviceAgreement.setPromoType(bi.getPromotionType());
		}
		//Service Level Agreement - Service Outage
		else if ("EB0370".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setAffectedSvcID(bi.getAffectedServiceId());
	        serviceAgreement.setContractID(bi.getContractId());
	        serviceAgreement.setAmendID(bi.getAmendmentId());
	        serviceAgreement.setTroubleTicketNo(bi.getTroubleTicketNum());
		}
		//Tax Exemption
		else if ("EB0380".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setTaxType(bi.getTaxType());
	        serviceAgreement.setAdditionalAcctNos(bi.getAdditionalAcctNumbers());
	        serviceAgreement.setTaxForm(bi.getAttachmentInd());
		}
		//Untimely Disconnect
		else if ("EB0390".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setDisonnectDt(bi.getDisconnectDate());
	        serviceAgreement.setLOD(bi.getAttachmentInd());
		}
		//Contract Cancellation
		else if ("EB0400".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setContractID(bi.getContractId());
	        serviceAgreement.setLOC(bi.getAttachmentInd());
		}
		//Misapplied Payments
		else if ("EB0410".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setPostedToAcct(bi.getPaymentPostedAcct());
	        serviceAgreement.setShouldHavePostedToAcct(bi.getCorrectPaymentAcct());
	        serviceAgreement.setCheckCopy(bi.getAttachmentInd());
		}
		//Refund
		else if ("EB0420".equals(bi.getReasonCode()))
		{
	        serviceAgreement.setReqRefundAmt(bi.getRefundAmount());
	        serviceAgreement.setAdditionalAcctNos(bi.getAdditionalAcctNumbers());
			serviceAgreement.setToAddrAttn(bi.getAddrAttention());
			serviceAgreement.setToAddrLine1(bi.getAddrLine1());
			serviceAgreement.setToAddrLine2(bi.getAddrLine2());
			serviceAgreement.setToAddrCity(bi.getAddrCity());
			serviceAgreement.setToAddrState(bi.getAddrState());
			serviceAgreement.setToAddrZip(bi.getAddrZip());
		}

		//if there are attachments
		if (bi.getAttachemnturls() != null && bi.getAttachemnturls().size() > 0)
		{
			List fileAttachmentList = bi.getAttachemnturls();
			ServiceAgreementAttachment[] serviceAgreementAttachment = new ServiceAgreementAttachment[fileAttachmentList.size()];
			ArrayOfRequestServiceAgreementServiceAgreementAttachment arrayOfRequestServiceAgreementAttachment = new ArrayOfRequestServiceAgreementServiceAgreementAttachment();
			int i = 0;

			for(i = 0; i < fileAttachmentList.size(); i++)
			{
				serviceAgreementAttachment[i] = new ServiceAgreementAttachment();
				serviceAgreementAttachment[i].setActivityFileName((String) fileAttachmentList.get(i));
			}

			arrayOfRequestServiceAgreementAttachment.setServiceAgreementAttachment(serviceAgreementAttachment);
			serviceAgreement.setListOfServiceAgreementAttachment(arrayOfRequestServiceAgreementAttachment);
		}

    	return serviceAgreement;
    }
}
