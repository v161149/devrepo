package com.verizon.enterprise.ncasbosi.billinquiry.bo;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.ncasbosi.billinquiry.util.BillInquiryHelper;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIUtil;
import com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry.OneViewRespVO;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.Request;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingresponse.pipelines.biztalk.ebillingtooneview.networx.Response;

/**
 * A Business class responsible for sending and receiving XML responses sent to
 * One View over HTTP A class is also responsible for logging the Bill Inquiries
 * and Responses to/from One View.
 *
 * @author z894579 Last Modified: 03/28/2007
 *
 */
public class OVBillInquiryBO
{
    static private final Logger _LOGGER = Logger
            .getLogger(OVBillInquiryBO.class);

    private String urlWSString;

    private String outXML; // getCreateXMLString();

    private int connectTimeout;

    private int readTimeout;

    private int retry;

    /**
     * A no argument constructor
     *
     */
    public OVBillInquiryBO() throws Exception
    {
        outXML = null; // getCreateXMLString();
        loadProperties();
    }

    private void loadProperties() throws Exception
    {

        urlWSString = NCASBOSIConfig
        	.getProperty(NCASBOSIConstants.ONE_VIEW_WS_URL_IDENTIFIER);
        _LOGGER.info("One View WS URL=" + urlWSString);

    }


    public Response createOVBillInquiryUsingSOAP(Request myRequest)
            throws Exception
    {
        _LOGGER.info("Entering createOVBillInquiryUsingSOAP");
        Response myResponse = null;

        try
        {
            _LOGGER.info("SOAP Request to be sent to One View: \n" + myRequest);
            myResponse = NCASBOSIUtil.postOneViewSOAPRequest(urlWSString,
                    myRequest);
            _LOGGER.info("Response from One View: \n" + myResponse);
        }
        catch (Exception e)
        {
            _LOGGER.error("Exception in OVBillInquiryBO: createOVBillInquiry "
                    + e.getMessage());
            throw e;
        }

        _LOGGER.info("Exiting createOVBillInquiryUsingSOAP");
        return myResponse;
    }

    public Response cancelOVBillInquiryUsingSOAP(Request myRequest) throws Exception
    {
        _LOGGER.info("Entering cancelOVBillInquiryUsingSOAP");
        Response myResponse = null;
        try
        {
            _LOGGER.info("Soap Request to be sent to One View: \n" + myRequest);
            myResponse = NCASBOSIUtil.postOneViewSOAPRequest(urlWSString,
                    myRequest);
            _LOGGER.info("Response XML from One View: \n" + outXML);
        }
        catch (Exception e)
        {
            _LOGGER.error("Exception in OVBillInquiryBO: cancelOVBillInquiry "
                    + e.getMessage(), e);
            throw e;
        }
        _LOGGER.info("Exiting cancelOVBillInquiry");
        return myResponse;
    }

    public String getUrlWSString()
    {
        return urlWSString;
    }

    public void setUrlWSString(String urlWSString)
    {
        this.urlWSString = urlWSString;
    }
}
