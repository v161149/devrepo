package com.verizon.enterprise.ncasbosi.common;
  public class CursorSortingInfo
  {
        public String curserID = null;
        public String sortOrder = null;
        public int startPosition = 0;
        public int pageSize = 0;
        public String toString()
        {
            StringBuffer outputStr = new StringBuffer(256);
            outputStr.append("curserID : "+curserID);
            outputStr.append(",sortOrder : "+sortOrder);
            outputStr.append(",startPosition  : "+startPosition);
            outputStr.append(",pageSize  : "+pageSize);
            return outputStr.toString();
        }
  }
