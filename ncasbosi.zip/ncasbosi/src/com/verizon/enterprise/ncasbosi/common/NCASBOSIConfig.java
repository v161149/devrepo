package com.verizon.enterprise.ncasbosi.common;

import java.util.Properties;

import com.verizon.kernel.config.Config;


public class NCASBOSIConfig extends Config
{
    public final static String PREFIX_NCASBOSI = "ncasbosi.ncasbosi";

    public static String getProperty(String key)
    {
        return Config.getProperty(PREFIX_NCASBOSI, key);
    }

    public static String getProperty(String key, String defaultValue)
    {
        String value = Config.getPropertyValue(PREFIX_NCASBOSI, key);

        return (value == null) ? defaultValue : value;
    }

    public static boolean getBooleanProperty(String key)
    {
        return isBoolean(getProperty(key));
    }

    public static boolean getBooleanProperty(String key, boolean defaultValue)
    {
        String value = Config.getPropertyValue(PREFIX_NCASBOSI, key);

        return (value == null) ? defaultValue : isBoolean(value);
    }

    private static boolean isBoolean(String value)
    {
        return (value != null && (value.equals("1") ||
                                  value.equalsIgnoreCase("true") ||
                                  value.equalsIgnoreCase("y")));
    }

    public static int getIntProperty(String key)
    {
        return Config.getIntProperty(PREFIX_NCASBOSI, key);
    }

    public static int getIntProperty(String key, int defaultValue)
    {
        String value = Config.getPropertyValue(PREFIX_NCASBOSI, key);

        return (value == null) ? defaultValue : Integer.parseInt(value);
    }

    public static long getLongProperty(String key)
    {
        return Config.getLongProperty(PREFIX_NCASBOSI, key);
    }

    public static long getLongProperty(String key, long defaultValue)
    {
        String value = Config.getPropertyValue(PREFIX_NCASBOSI, key);

        return (value == null) ? defaultValue : Long.parseLong(value);
    }

    public static float getFloatProperty(String key)
    {
        return Config.getFloatProperty(PREFIX_NCASBOSI, key);
    }

    public static float getFloatProperty(String key, float defaultValue)
    {
        String value = Config.getPropertyValue(PREFIX_NCASBOSI, key);

        return (value == null) ? defaultValue : Float.parseFloat(value);
    }

    public static double getDoubleProperty(String key)
    {
        return Config.getDoubleProperty(PREFIX_NCASBOSI, key);
    }

    public static double getDoubleProperty(String key, double defaultValue)
    {
        String value = Config.getPropertyValue(PREFIX_NCASBOSI, key);

        return (value == null) ? defaultValue : Double.parseDouble(value);
    }

    public static Properties getPropertiesFull(String beginsWith)
    {
        return Config.getPropertiesFull(PREFIX_NCASBOSI, beginsWith);
    }

    public static Properties getPropertiesShort(String beginsWith)
    {
        return Config.getPropertiesShort(PREFIX_NCASBOSI, beginsWith);
    }
} // NCASBOSIConfig
