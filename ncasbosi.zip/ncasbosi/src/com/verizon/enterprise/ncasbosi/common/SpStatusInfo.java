package com.verizon.enterprise.ncasbosi.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SpStatusInfo
{
    private int myReturnCode = 0;
    private String myReasonCode =null;
    private String myErrorText = null;
    private int mySQLCode = 0;
    private String mySQLState = null;
    private String mySQLToken = null;
    private static final String lineEnd = "\n";
    public int getReturnCode()
    {
        return myReturnCode;
    }

    public String getReasonCode()
    {
         return myReasonCode;
    }

    public String getErrorText()
    {
          return myErrorText;
    }
    public String getSQLState()
    {
          return mySQLState;
    }
    public String getSQLToken()
    {
          return mySQLToken;
    }

    public int getSQLCode()
    {
            return mySQLCode;
    }


    public void setReturnCode(int returnCode)
    {
        myReturnCode = returnCode;
    }

    public void setReasonCode(String reasonCode)
    {
         myReasonCode = reasonCode;
    }

    public void setErrorText(String errorText)
    {
          myErrorText = errorText;
    }
    public void setSQLState(String sqlState)
    {
          mySQLState = sqlState;
    }
    public void setSQLToken(String sqlToken)
    {
         mySQLToken = sqlToken;
    }

    public void setSQLCode(int sqlCode)
    {
           mySQLCode = sqlCode;
    }

    public String toString()
    {
         StringBuffer outputStr = new StringBuffer(256);
         outputStr.append(lineEnd+"RETURN_CODE : "+myReturnCode);
         outputStr.append(lineEnd+"REASON_CODE : "+myReasonCode);
         outputStr.append(lineEnd+"ERROR_TEXT  : "+myErrorText);
         outputStr.append(lineEnd+"SP_SQLCODE  : "+mySQLCode);
         outputStr.append(lineEnd+"SP_SQLSTATE : "+mySQLState);
         return outputStr.toString();
    }
}