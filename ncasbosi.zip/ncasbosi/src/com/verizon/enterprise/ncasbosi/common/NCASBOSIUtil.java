package com.verizon.enterprise.ncasbosi.common;



import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;
import org.apache.xerces.dom.DocumentImpl;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;

import org.apache.log4j.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.apache.xerces.dom.DocumentImpl;
import org.apache.xml.serialize.*;
import com.verizon.enterprise.ncasbosi.webservice.oneview.OneViewSoapHandler;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.com.vzbi.ebillingtooneview.Networx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponseSoap_Stub;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.com.vzbi.ebillingtooneview.Networx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponse_Impl;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.Request;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingresponse.pipelines.biztalk.ebillingtooneview.networx.Response;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.SpStatusInfo;
import com.verizon.enterprise.ncasbosi.common.CursorSortingInfo;
import com.verizon.enterprise.common.ncas.exception.NCASException;

/**
 * A Utility Class for misc services such as http,connectivity etc.
 * @author z894579
 * Last Modified: 03/28/2007
 *
 */


public class NCASBOSIUtil
{

	static private final Logger _Logger = Logger.getLogger(NCASBOSIUtil.class);

	private static final String XML_HEAD = "Header";

	private static final String XML_HEAD_BACKOFFICE = "BackOffice";
	private static final String XML_HEAD_CURSOR_TOTALNUMBER = "TotalRecordNumberReturned";
	private static final String XML_HEAD_PAGINATION = "Pagination";
	private static final String XML_HEAD_PAGE_TOTALRECORDS = "TotalRecords";

	private static final String XML_HEAD_PAGE_RECORDASKED = "TotalRecordAsked";
	private static final String XML_HEAD_PAGE_CURSOROFFSET = "CursorOffset";
	private static final String XML_HEAD_PAGE_CURSORID = "CursorId";
	private static final String XML_HEAD_PAGE_SORTBY = "SortBy";

	private static final String BOGUS_DATE = "0000-00-00";
	private static final String DEFAULT_DATE = " ";

	private static final boolean DEBUG = true;
	private static final String SPACESTR=" ";

	public static Response postOneViewSOAPRequest(String nameSpaceUri,
			                                      Request myRequest)
		throws Exception
	{
	    String METHOD_NAME = "NCASBOSIUtil.postOneViewSOAPRequest() ";

		Response myResponse = null;

	    //String nameSpaceUri = "https://j36srv026.vzbi.com/Networx.eBillingToOneView.BizTalk.Orchestrations_Proxy/Networx_eBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponse.asmx";
	    String serviceName = "Networx_eBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponseSoap";

        System.setProperty("javax.xml.rpc.ServiceFactory", "weblogic.webservice.core.rpc.ServiceFactoryImpl");
		System.setProperty("weblogic.webservice.verbose", "true");

        // create service
        Networx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponse_Impl
        service = new Networx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponse_Impl(nameSpaceUri + "?wsdl");

        // Attach Soap Header - Handler Chain
        QName portName = new QName(nameSpaceUri, serviceName);

        HandlerRegistry registryH = service.getHandlerRegistry();
        List chain = registryH.getHandlerChain(portName);
        HandlerInfo info = new HandlerInfo(OneViewSoapHandler.class, null, null);
        chain.add(info);
        Networx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponseSoap_Stub port = null;
        port = (Networx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponseSoap_Stub) service.getNetworx_EBillingToOneView_BizTalk_Orchestrations_ProcessEbillingSR_EbillingSRRequestResponseSoap();

        if (_Logger.isInfoEnabled())
        {
	        _Logger.info(METHOD_NAME + " port=" + port);
	        _Logger.info(METHOD_NAME + " service=" + service);
        }

        _Logger.info(METHOD_NAME + " request = " + myRequest.toString());
        myResponse = port.sRRequest(myRequest);
        _Logger.info(METHOD_NAME + " response = " + myResponse.toString());

		return myResponse;
	}


    public static Document createDOMDocument()
	{
		return new DocumentImpl();
	}

    public static String getXMLString(Document doc) throws Exception
    {
        // converts a given DOM document to xml string
        try
        {
            OutputFormat format = new OutputFormat(doc);    // Serialize DOM
            StringWriter stringOut = new StringWriter();    // Writer will be a String
            XMLSerializer serial = new XMLSerializer(stringOut, format);
            serial.asDOMSerializer();                       // As a DOM Serializer
            serial.serialize(doc.getDocumentElement());

            return stringOut.toString(); // return DOM as a string
        }
        catch(IOException except)
        {
            String methodName = "getXMLString()";
            String eInfo[] = getExceptionInfo(methodName, except.getMessage());
            throw new Exception("error converting xml string to doc" + eInfo);
        }
    }


	public static Element createSysBillHeader( Document doc, String SysID,
								int TotalNumber, int TotalReturnedNumber,
								int CursorOffset, int TotalRecordAsked,
								String SortBy, String CursorID )
	{
		Element root = doc.createElement(XML_HEAD);
		buildNode(doc, root, XML_HEAD_BACKOFFICE, SysID);
		Element item = doc.createElement(XML_HEAD_PAGINATION);
		buildNode(doc, item, XML_HEAD_PAGE_TOTALRECORDS,
				String.valueOf(TotalNumber));
		buildNode(doc, item, XML_HEAD_CURSOR_TOTALNUMBER,
				String.valueOf(TotalReturnedNumber));
		/* Commented out temporaliy for further discussion*/
		buildNode(doc, item, XML_HEAD_PAGE_CURSOROFFSET,
				String.valueOf(CursorOffset));
		buildNode(doc, item, XML_HEAD_PAGE_RECORDASKED,
				String.valueOf(TotalRecordAsked));
		buildNode(doc, item, XML_HEAD_PAGE_SORTBY, SortBy);
		buildNode(doc, item, XML_HEAD_PAGE_CURSORID, CursorID);
		root.appendChild(item);
		return root;
	}

	public static Map newBuildResultSetToXMLWithHeader(ResultSet rset,
			String itemDetailsName,
			String itemName,
			Document doc,
			int numReturned) throws SQLException

	{
		HashMap map = new HashMap();
		Element items = doc.createElement(itemDetailsName);
		if (rset == null)
		{
			map.put("element" , items);
			map.put("numReturned", String.valueOf(numReturned));
			return map;
		}
		ResultSetMetaData rmd = rset.getMetaData();
		int colcount = rmd.getColumnCount();
		String[] metaTags = NCASBOSIUtil.retrieve_MetaData(rmd, colcount);
		for (int i = 0; i < metaTags.length; i++)
		{
			_Logger.debug("metaTags[" + i + "]==" + metaTags[i]);

		}
		Element itemRow = null;
		Element item = null;
		String colValue = null;
		if (metaTags != null)
		{
			while (rset.next())
			{
				itemRow = doc.createElement(itemName);
				for (int i = 0; i < colcount; i++)
				{
					colValue = rset.getString(i + 1);
					if (colValue == null)
					{
						colValue = SPACESTR;
					}
					else
					{
						colValue = colValue.trim();
					}
					NCASBOSIUtil.buildNode(doc, itemRow, metaTags[i], colValue);
					items.appendChild(itemRow);
				}
				numReturned++;
			} // end of while next
		} // end if if

		map.put("element" , items);
		map.put("numReturned", String.valueOf(numReturned));
		return map;
	}

	public static void buildNode(Document doc, Element paraNode, String NodeName,
			String NodeValue)
	{
		Element item = doc.createElement(NodeName);
		if ( (NodeValue != null) && (NodeValue.equals(BOGUS_DATE)))
		{
			NodeValue = DEFAULT_DATE;
		}
		if (NodeValue != null)
		{
			item.appendChild(doc.createTextNode(NodeValue));
		}
		paraNode.appendChild(item);
	}

    private static String[] getExceptionInfo(String methodName, String message)
    {
        String eInfo[] = new String[3];
        eInfo[0] = methodName;
        eInfo[1] = "N/A";
        eInfo[2] = (message == null) ? "" : message;

        return eInfo;
    }

	/**
	 * A Private method to try the Connection if unsuccesful tries to make specified attempts
	 * @param httpClient
	 * @param urlString
	 * @param post
	 * @param retries Specified attempts
	 * @return
	 */

	public static String[] retrieve_MetaData(ResultSetMetaData rsMD, int metaInfoCount)
	{
		String tmpStr = null;
		String[] metaInfo = null;
		metaInfo = new String[metaInfoCount];
		try
		{
			for (int i = 1; i <= metaInfoCount; i++)
			{
				metaInfo[i - 1] = rsMD.getColumnLabel(i).trim();
			}
		}
		catch (Exception e)
		{
			metaInfo = null; // No MetaData will be returned

			String[] errMsg = new String[3];
			errMsg[0] = "Retrieve_MetaData";
			errMsg[1] = "N/A";
			errMsg[2] = e.getMessage();
    		_Logger.error("retrieve_MetaData() failed.."+errMsg);
		}
		return metaInfo;
	}

	public static String getCurrentDateAndTime()
	{
		String dateTimeStr = "";
		Date date = new Date();
		dateTimeStr = new String(date.toString());
		return dateTimeStr;

	}

	public static Date formatDate(String format, String dateStr)throws Exception
	{
		Date date = null;
		if(format != null && dateStr != null && !dateStr.trim().equals(""))
		{
		_Logger.info("format "+format);
		_Logger.info("DateStr "+dateStr);
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		date = sdf.parse(dateStr);
		}
		return date;
	}
	
    static public Document getDOMDocument(String xml) throws Exception
    {
        // converts a given xml string to DOM document
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            InputSource input = new InputSource(new StringReader(xml.trim()));
            DocumentBuilder builder = factory.newDocumentBuilder();
            return builder.parse(input);
        }
        catch(Exception except)
        {
            String methodName = "getDOMDocument()";
            String eInfo[] = getExceptionInfo(methodName, except.getMessage());
            _Logger.error("error when calling getDOMDocument()..."+eInfo);
            throw new Exception("error when calling getDOMDocument()..." + eInfo);    
        }
    }  

    static public int parseInt(String value)
    {
        if(value != null)
        {
            return Integer.parseInt(value.trim());
        }

        return NCASBOSIConstants.NULL_INT;
    } 
    
    static public int getNodeValueAsInt(Element element)
    {
        return parseInt(getNodeValue(element));
    }

    static public String getNodeValue(Element element)
    {
        Node firstChild = element.getFirstChild();
        if(firstChild != null)
        {
            String nodeValue = firstChild.getNodeValue();
            if(nodeValue != null && nodeValue.length() > 0)
            {
                return nodeValue;
            }
        }
        return NCASBOSIConstants.NULL_STRING;
    }    
    
    static public Element addElement(Element parent,
            String name,
            String value) throws Exception {
    		// adds the element 'name' to parent and sets its value to name
    		Document doc = parent.getOwnerDocument();
    		Element element = doc.createElement(name);
    		element.appendChild(doc.createTextNode(value));
    		parent.appendChild(element);
    		return element;
    }

    // the following 3 functions are there for backward compatibility
    static public void addElement(Document doc,
         Element parent,
         String name,
         ResultSet rs) throws Exception {
    		addElement(parent, name, rs);
    }

    static public void addElement(Document doc,
         Element parent,
         String name,
         int columnIndex,
         ResultSet rs) throws Exception {
    		addElement(parent, name, columnIndex, rs);
    }

    static public void addElement(Document doc,
         Element parent,
         String name,
         String value) throws Exception {
    		addElement(parent, name, value);
    }       
    
    static public void addElement(Element parent,
            String name,
            ResultSet rs) throws Exception {
    		// adds the element 'name' to parent and sets its value to rs(name)
    		Document doc = parent.getOwnerDocument();
    		Element element = doc.createElement(name);
    		element.appendChild(doc.createTextNode(NCASBOSIUtil.getString(rs, name)));
    		parent.appendChild(element);
    } 
    
    static public void addElement(Element parent,
            String name,
            int columnIndex,
            ResultSet rs) throws Exception {
    	// adds the element 'name' to parent and sets its value to rs(columnIndex)
    	Document doc = parent.getOwnerDocument();
    	Element element = doc.createElement(name);
    	element.appendChild(doc.createTextNode(NCASBOSIUtil.getString(rs, columnIndex)));
    	parent.appendChild(element);
    }
    
    static public String getString(ResultSet rs, String columnName) throws NCASException {
    	try
    	{
    		String columnValue = rs.getString(columnName);
    		return (rs.wasNull()) ? NCASBOSIConstants.NULL_STRING : columnValue.trim();
    	}
    	catch(SQLException except)
    	{
    		String methodName = "getString(" + columnName + ")";
    		String eInfo[] = getExceptionInfo(methodName, columnName, except.getMessage());
    		_Logger.error(except.getMessage());
    		throw new NCASException("VBIF1001",NCASBOSIUtil.class,except);
    	}
    }

    static public String getString(ResultSet rs, int columnIndex) throws NCASException {
    	try
    	{
    		String columnValue = rs.getString(columnIndex);
    		return (rs.wasNull()) ? NCASBOSIConstants.NULL_STRING : columnValue.trim();
    	}
    	catch(SQLException except)
    	{
    		String methodName = "getString(" + columnIndex + ")";
    		String eInfo[] = getExceptionInfo(methodName, columnIndex, except.getMessage());
    		_Logger.error("error when calling getString()..."+eInfo);
    		_Logger.error(except.getMessage());
    		throw new NCASException("VBIF1001",NCASBOSIUtil.class,except);
    	}
    }  
    
    public static String[] getExceptionInfo(String functionName,
            String columnName,
            String message) {
    	String eInfo[] = new String[4];
    	eInfo[0] = functionName;
    	eInfo[1] = "N/A";
    	eInfo[2] = columnName;
    	eInfo[3] = message;

    	return eInfo;
    }

    private static String[] getExceptionInfo(String functionName,
             int columnIndex,
             String message) {
    	return getExceptionInfo(functionName, String.valueOf(columnIndex), message);
    } 
    
    public static SpStatusInfo getSPInfo(CallableStatement cstmt,
            int startPosition) throws SQLException {
    		SpStatusInfo spInfo = new SpStatusInfo();
    		spInfo.setReturnCode(cstmt.getInt(startPosition));
    		spInfo.setReasonCode(cstmt.getString(startPosition + 1).trim());
    		spInfo.setErrorText(cstmt.getString(startPosition + 2).trim());
    		spInfo.setSQLCode(cstmt.getInt(startPosition + 3));
    		spInfo.setSQLToken(cstmt.getString(startPosition + 4));
    		spInfo.setSQLState(cstmt.getString(startPosition + 5));
    		return spInfo;
    } 

    public static void printStoredProcInfo(SpStatusInfo spInfo, String apiName, String spName) throws Exception {
    	int returnCode = spInfo.getReturnCode();
    	int sqlCode = spInfo.getSQLCode();
    	String strSPInfo = spInfo.toString();
    	_Logger.debug("strSPInfo =>" + strSPInfo);

    	//sqlCode 100 means no data
    	if (returnCode > 0 && sqlCode != 100) // Excuting SP doesn't return correct result
    	{
    		String[] errMsg = new String[3];
    		errMsg[0] = apiName;
    		errMsg[1] = spName;
    		errMsg[2] = spInfo.toString();
    		_Logger.error("error when calling printStoredProcInfo()..."+errMsg);
    		throw new Exception("error when calling printStoredProcInfo()..."+errMsg);
    	}
    }
    
    public static void printStoredProcInfoWithNoDataCheck(SpStatusInfo spInfo, String apiName, String spName) throws Exception {
    	    int returnCode = spInfo.getReturnCode();
    	    String strSPInfo = spInfo.toString();
            if (_Logger.isInfoEnabled())
            {
    	        _Logger.info(strSPInfo);
            }    	    

    	    if (returnCode > 0 && (spInfo.getSQLCode() != NCASBOSIConstants.NO_DATA_FOUND) &&
    	        (returnCode != NCASBOSIConstants.RC_NO_DATA_FOUND)) // Excuting SP doesn't return correct result
    	    {
    	      String[] errMsg = new String[3];
    	      errMsg[0] = apiName;
    	      errMsg[1] = spName;
    	      errMsg[2] = spInfo.toString();
      		_Logger.error("error when calling printStoredProcInfoWithNoDataCheck()..."+errMsg);
    		throw new Exception("error when calling printStoredProcInfoWithNoDataCheck()..."+errMsg);
    	    }
    }
    
    public static void cleanup(Connection connection, 
    		                   CallableStatement statement,
                               ResultSet resultSet) {

    		try
    		{
    			if (resultSet != null)
    			{
    				resultSet.close();
    			}
    		} catch (Exception e) {
    			_Logger.error(e.getMessage());
    		}
    		try
    		{
    			if (statement != null)
    			{
    				statement.close();
    			}
    		} catch (Exception e) {
    			_Logger.error(e.getMessage());
    		}
    		try
    		{
    			if (connection != null)
    			{
    				connection.close();
    			}
    		} catch (Exception e) {
    			_Logger.error(e.getMessage());
    		}
    } 
    
    public static void registerCommonVACSParams(CallableStatement cstmt, int startPosition) throws SQLException {
    		//====================  Register the Output Parameters =====
    		cstmt.registerOutParameter(startPosition, Types.INTEGER); //Return Code
    		cstmt.registerOutParameter(startPosition + 1, Types.CHAR); //REASON_CODE
    		cstmt.registerOutParameter(startPosition + 2, Types.VARCHAR); //ERROR_TEXT
    		cstmt.registerOutParameter(startPosition + 3, Types.INTEGER); //SP_SQLCODE
    		cstmt.registerOutParameter(startPosition + 4, Types.CHAR); //SP_SQLTOKEN
    		cstmt.registerOutParameter(startPosition + 5, Types.CHAR); //SP_SQLSTATE
    }
       
    static public List<Object> buildDataObjectResponse(ResultSet rset, CursorSortingInfo cs) throws SQLException, Exception {
    	    List<Object> returnedResultSet = new ArrayList<Object>();
    		if (rset != null)
    		{
    			  ResultSetMetaData rmd = rset.getMetaData();
    			  int colcount = rmd.getColumnCount();
    			  String[] metaTags = retrieve_MetaData(rmd, colcount);
    	          if (_Logger.isDebugEnabled()) {
    				  for (int i = 0; i < metaTags.length; i++)
    				  {
    					  _Logger.debug("metaTags[" + i + "]==" + metaTags[i]);
    				  }    	        	  
    	          }        			  
    	          String colValue = null;
    			  if (metaTags != null)
    			  {
    				  while (rset.next())
    				  {
    					  Map<String,String> recordMap = new HashMap<String,String>();
    					  for (int i = 0; i < colcount; i++)
    					  {
    						  colValue = rset.getString(i + 1);
    						  if (_Logger.isDebugEnabled())
    						  {
    							  _Logger.debug("metaTags values[" + i + "]==" + colValue);
    						  }
    						  if (colValue != null)
    						  {
    							  colValue = colValue.trim();
    						  }
    						  recordMap.put(metaTags[i],colValue);
    					  }
    					  returnedResultSet.add(recordMap);
    				  } // end of while next
    			  } // end if if
    		}
    		return returnedResultSet;
    }
    
    static public void commitTransaction(Connection connection)
    {
        try
        {
            if(connection != null)
            {
                connection.commit();
            }
        }
        catch(SQLException except)
        {
            // we can safely ignore this exception.
            // as we are not doing any data manipulation.
            String methodName = "commitTransaction()";
            _Logger.error(methodName+" => "+except.getMessage());
        }
    }   
    
    static public void rollbackTransaction(Connection connection) {
    	try {
            if(connection != null)
                connection.rollback();
        } catch(SQLException except) {
            // we can safely ignore this exception.
            // as we are not doing any data manipulation.
            String methodName = "rollbackTransaction()";
            _Logger.error(methodName+" => "+except.getMessage());
        }
    }
    
    public static String dateToString(java.util.Date dd)
    {
      if (dd != null)
      {
        SimpleDateFormat formatter
            = new SimpleDateFormat("yyyy-MM-dd");

        String dateString = formatter.format(dd);
        return dateString;
      }
      else
      {
        return null;
      }
    }

    static public void registerCommonOutParams(CallableStatement cstmt, int startPosition) throws SQLException
    {
    	//====================  Register the Output Parameters =====
    	cstmt.registerOutParameter(startPosition, Types.INTEGER); //Return Code
    	cstmt.registerOutParameter(startPosition + 1, Types.CHAR); //REASON_CODE
    	cstmt.registerOutParameter(startPosition + 2, Types.VARCHAR); //ERROR_TEXT
    	cstmt.registerOutParameter(startPosition + 3, Types.INTEGER); //SP_SQLCODE
    	cstmt.registerOutParameter(startPosition + 4, Types.CHAR); //SP_SQLTOKEN
    	cstmt.registerOutParameter(startPosition + 5, Types.CHAR); //SP_SQLSTATE
    }  
}
