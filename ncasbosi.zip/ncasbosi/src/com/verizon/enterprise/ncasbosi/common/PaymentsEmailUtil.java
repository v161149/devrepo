package com.verizon.enterprise.ncasbosi.common;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.verizon.enterprise.common.ProducerIds;
import com.verizon.enterprise.siren.notifications.EmailMessage;
import com.verizon.enterprise.siren.notifications.Notification;
import com.verizon.kernel.config.Config;

public class PaymentsEmailUtil {

  private static final org.apache.log4j.Logger __Logger = org.apache.log4j.Logger.getLogger(PaymentsEmailUtil.class);
  private boolean notified = false;
  private List toAddr = new ArrayList();
  private String subject = "";
  private String message = "Test";
  private String fromAddr = "Do_Not_Reply@verizon.com";
  public static PaymentsEmailUtil paymentsEmailUtil = null;

  public PaymentsEmailUtil() {
      fromAddr = Config.getProperty("ncas.ncas",
          "verizon.ncas.DO_NOT_REPLY");
  }

  // synchronized static method initialization
  public synchronized static PaymentsEmailUtil getInstance() {
    if (paymentsEmailUtil == null) {
      paymentsEmailUtil = new PaymentsEmailUtil();
    }
    return paymentsEmailUtil;
  }

  // Method for sending mail
  public boolean sendMail(List toInAddr) throws Exception {
    __Logger.info("SendMail Start ::");
    setToAddr(toInAddr);
    try {
      checkValid();
    }
    catch (Exception e) {
      throw e;
    }
    EmailMessage emsg = null;
    int UALogid = ProducerIds.PRES_BILLS;
    __Logger.info("UALogid -->"+UALogid);
    try {
      emsg = new EmailMessage(toAddr, null, null, fromAddr, subject, message, null);
      // steeing for the html format message
      emsg.setFormatHtml(true);
      emsg.setMessageType("HTML");
      Notification noti = new Notification(emsg);

      //boolean doneEmail = noti.sendNotification();
      long doneEmail = noti.sendTrackableNotification();
      // check for success of mail delivery
      __Logger.info("\n\n\n\n Email Tracking ID ---> " + doneEmail);
      
      if (doneEmail > 0) {
        __Logger.info("Email sent successfully = " + emsg);
        notified = true;
      } else {
        __Logger.info("Email NOT sent successfully = " + emsg);
        notified = false;
      }

      return notified;
    }
    catch (Exception e) {
    	throw new Exception("Error sending Email: " + e);
    }
  }

  private void checkValid() throws Exception {
    if (toAddr.size() == 0) {
      throw new Exception(" missing mail_to address ");
    }
    if (fromAddr == null) {
      throw new Exception(" missing mail_from address");
    }

  }

  public void getOneTimePaymentMessage(List accNum, String subject) throws Exception {
    StringBuffer content = new StringBuffer();
    String accountNbrs = "";
//    for(int i=0;i<accNum.length();i++)
//    {
//    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//    }
    
    content.append(
    		"<HTML>" +
    		"<BODY>" +
    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
    		"<BR><BR>" +
    		"This email is to confirm payment status for the following Verizon Wireless account(s):<BR><BR>" +
    		
    		/*
    		 * Need to replace with accountNbrs
    		 */
    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
    		"in: XXXXX6-00001<BR></SPAN>" +
    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
    		"in: XXXXX6-00004<BR></SPAN>" +
    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
    		"in: XXXXX6-00005<BR></SPAN>" +
    		
    		
    		"<BR><BR>If any payments were rejected, your account balance would remain unpaid. You can easily submit another online payment at My Business Account https://www.verizonwireless.com/b2blogin/." +
    		"<BR><BR>Your checking account will be debited electronically depending on your bank's schedule for electronic fund transfers on 12/De/ PST. If you need to stop payment on this transaction please contact your bank immediately. Below is a copy of the authorization you accepted in order for us to withdraw your payment amount from your checking account electronically. Visit us again to make your next online payment." +
    		"<BR><BR>" +
    		"By paying your Verizon Wireless bill by way of this online billing service, you are authorizing Verizon Wireless to electronically charge your checking account for the amount you submitted. If you want to use this method of payment, you must complete this authorization process each time. You will receive an E-mail notification each month, stating your bill is available for online viewing and payment. The bill you see online is a replica of your paper version. If you have chosen to pay electronically using your checking account to stop payment you must contact your banking institution immediately." +
    		"<BR><BR>" +
    		"The terms and conditions of your Customer Agreement apply to the Online Bill Payment Service and are incorporated by reference here. Currently Verizon Wireless offers this service to you free of charge, however your bank may charge a fee." +
    		"<BR><BR>Thank you for your payment and for choosing Verizon Wireless." +
    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
    		);

//        if(precedingText!=null && !precedingText.trim().equals(""))
//		{
//			content.append(precedingText+"<br>");
//		}
//	content.append("This is a system generated e-mail from the Verizon Enterprise Center. Please do no reply.The attached memo bill is a PDF file and can be viewed using Adode Acrobat.<br>"+
//					"<p>This is a courtesy copy of your bill.  Please do not pay from this statement.<br><p>"+
//					"WARNING: E-mail transmission cannot be guaranteed to be secure or error-free as information could be intercepted, corrupted, lost, "+
//					"destroyed, arrive late or incomplete, or contain viruses.<br></body></html>");

//    __Logger.info("\n\n getOneTimePaymentMessage content -->"+content+"\n\n");
    setMessage(content.toString());
    setSubject(subject);
//    __Logger.info("getOneTimePaymentMessage Subject -->"+getSubject()+"\n\n");

  }
  
  
  public void getNSFCreditCardEmailMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to notify you that your recent online check payment has either been declined by your bank due to non-sufficient funds (NSF) or it has been reversed.  This impacts the following Verizon Wireless account(s): <BR><BR>" +
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>Because of this, your account balance remains unpaid. You can easily submit another online payment at My Business Account https://www.verizonwireless.com/b2blogin/." +
	    		"<BR><BR>" +
	    		"In order to make sure future payments are processed in a timely manner, you may need to update your payment account information. To update your payment information, simply log in to My Business Account and go to Payments/ Payment Accounts." +
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("\n\n getNSFCreditCardEmailMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getNSFCreditCardEmailMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getCreditCardFailuresMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to notify you that your recent recurring payment to the following Verizon Wireless account(s) has failed:" +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"Because of this, your account balance remains unpaid. To avoid any disruption to your service or late payment fees, contact us to make a payment using another credit card, or visit My Business Account and submit a one-time payment using your checking account." +
	    		"My Business Account is located at the URL https://www.verizonwireless.com/b2blogin.  You can also click on the 'Contact Us' link in the upper right corner to make a payment using another credit card." +
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getCreditCardFailuresMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getCreditCardFailuresMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getPaymentChangesMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"Your Verizon Wireless Business Account - Automatic Payment Thank you for setting up your automatic payment for account(s): " +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"Your automatic payment request may take up to two billing cycles to process. Remember you will be responsible for all payments in the interim. " +
	    		" <BR><BR> For updates on the status of your request, visit" +
	    		"<BR> <A style='COLOR: #0000ff' " +
	    		"href='https://b2b.verizonwireless.com/tbmb/?cm_mmc=My%20Business%20E-Confirmations-_-Payment%20-%20APO%20Request-_-Middle%20-_-On-going%20Confirm.%20-%20MyBiz'>" +
	    		"My Business Account</A> to view your current online bill. " +
	    		"<BR><BR>You will also receive a confirmation email after your automatic payment has been processed." +
	    	
	    		"<BR><BR> Thank you for using Verizon Wireless. We never stop working for you." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentChangesMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentChangesMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getPaymentApplicationErrorMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to notify you that your recent online payment to the following Verizon Wireless account(s) has failed:" +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"Because of this, your account balance remains unpaid. You can easily submit another online payment at My Business Account https://www.verizonwireless.com/b2blogin/. Please note the account(s) listed are enrolled in the automatic payment service." +
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentApplicationErrorMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentApplicationErrorMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getPaymentAccountOwnerChangeMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to confirm that the following account(s) you had previously enrolled in the automatic payment service were modified by another user who selected a different payment account:" +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"If you have any questions, please click the Contact Us link in My Business Account." +
	    		
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentAccountOwnerChangeMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentAccountOwnerChangeMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getPaymentNotificationMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"Your Verizon Wireless Business Account - Online Bill Now Available You can view your Verizon Wireless bill online for account(s): " +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"The account(s) you designated will be debited for automatic payment 10 days before the next billing cycle date. " +
	    		" <BR><BR>" +
	    		"If your banking information has changed, please" +
	    		"<BR>" +
	    		"log into " +
	    		"<A style='COLOR: #0000ff' href='https://b2b.verizonwireless.com/tbmb/?cm_mmc=My%20Business%20E-Confirmations-_-Payment%20-%20APO%20Request-_-Middle%20-_-On-going%20Confirm.%20-%20MyBiz'>" +
	    		"My Business Account</A> to update your payment information to ensure there is no disruption in payment or service. " +
	    		"<BR><BR>Thank you for using Verizon Wireless. We never stop working for you." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentNotificationMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentNotificationMessage Subject -->"+getSubject()+"\n\n");
	  }
  

  public void getPaymentDeleteByDifferentOwnerChangeMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to notify you that the automatic payment on the following account(s) has been deleted by another user: " +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"If you wish to set up another automatic payment to ensure this change does not disrupt the timely processing of your payment, please login to  https://www.verizonwireless.com/b2blogin." +
	    		
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentDeleteByDifferentOwnerChangeMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentDeleteByDifferentOwnerChangeMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getPaymentDeleteNotificatioMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to confirm that you deleted the automatic payment on the following account(s): " +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"If you wish to set up another automatic payment to ensure this change does not disrupt the timely processing of your payment, please login to https://www.verizonwireless.com/b2blogin." +
	    		
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentDeleteNotificatioMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentDeleteNotificatioMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public void getCreditCardexpirationMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"This email is to notify you that the expiration date on your credit card will soon pass." +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Credit card nicknamed:" +
	    		" XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Credit card nicknamed:" +
	    		" XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Credit card nicknamed:" +
	    		" XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"Please login to My Business Account https://www.verizonwireless.com/b2blogin/ and update your credit card information to ensure this change does not disrupt the timely processing of your payment." +
	    		
	    		"<BR><BR>Thank you for choosing Verizon Wireless and for using My Business Account." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getCreditCardexpirationMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getCreditCardexpirationMessage Subject -->"+getSubject()+"\n\n");
	  }

  
  public void getPaymentsDuplicateAccountsMessage(List accNum, String subject) throws Exception {
	    StringBuffer content = new StringBuffer();
	    String accountNbrs = "";
//	    for(int i=0;i<accNum.length();i++)
//	    {
//	    	accountNbrs.concat("<SPAN style='PADDING-LEFT: 25px'>Account number ending in: "+ accNum.get(i)+ "<BR></SPAN>");
//	    }
	    
	    content.append(
	    		"<HTML>" +
	    		"<BODY>" +
	    		"<TABLE cellSpacing=0 cellPadding=0 border=0>" +
	    		"<TR>" +
	    		"<TD style='PADDING-RIGHT: 40px; PADDING-LEFT: 20px; FONT: bold 16px Arial; COLOR: #d6001c; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"Your Verizon Wireless Business Account - Automatic Payment</TD></TR>" +
	    		
	    		"<TR><TD style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
	    		"<BR><BR>" +
	    		"Thank you for setting up your automatic payment  <BR>for account(s):" +
	    		
	    		
	    		/*
	    		 * Need to replace with accountNbrs
	    		 */
	    		"<SPAN style='PADDING-LEFT: 25px'>Credit card nicknamed:" +
	    		" XXXXX6-00001<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Credit card nicknamed:" +
	    		" XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Credit card nicknamed:" +
	    		" XXXXX6-00005<BR></SPAN>" +
	    		
	    		
	    		" <BR><BR>" +
	    		"Your automatic payment request may take up to two billing cycles to process. Remember you will be responsible for all payments in the interim. " +
	    		"<BR><BR>For updates on the status of your request, visit <BR>" +
	    		"<A style='COLOR: #0000ff' href='https://b2b.verizonwireless.com/tbmb/?cm_mmc=My%20Business%20E-Confirmations-_-Payment%20-%20APO%20Request-_-Middle%20-_-On-going%20Confirm.%20-%20MyBiz'>" +
	    		"My Business Account</A> to view your current online bill." +
	    		"<BR><BR>You will also receive a confirmation email after your automatic payment has been processed. However the process of scheduling a recurring payment for the following Verizon Wireless account(s)" +
	    		" <BR><BR>" +
	    		/*
	    		 * These values also should be dynamic 
	    		 */
	    		
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00004<BR></SPAN>" +
	    		"<SPAN style='PADDING-LEFT: 25px'>Account number ending" +
	    		"in: XXXXX6-00005<BR></SPAN>  <BR>" +
	    		
	    		
	    		"failed because these accounts have already been registered for recurring payment through an application other than My Business. If you need assistance, please" +
	    		"contact us by visiting https://b2b.verizonwireless.com/tbmb/contactUs.do" + 
	    		
	    		"<BR><BR>Thank you for using Verizon Wireless. We never stop working for you." +
	    		"</TD></TR></TBODY></TABLE></BODY></HTML>"
	    		);
//	    __Logger.info("getPaymentsDuplicateAccountsMessage content -->"+content+"\n\n");
	    setMessage(content.toString());
	    setSubject(subject);
//	    __Logger.info("getPaymentsDuplicateAccountsMessage Subject -->"+getSubject()+"\n\n");
	  }
  
  
  public String getFromAddr() {
    return fromAddr;
  }

  public void setFromAddr(String addr) {
    fromAddr = addr;
  }

  public List getToAddr() {
    return toAddr;
  }

  public void setToAddr(List addr) {
    toAddr = addr;
  }

  public String getSubject() {
    return subject;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }
}
