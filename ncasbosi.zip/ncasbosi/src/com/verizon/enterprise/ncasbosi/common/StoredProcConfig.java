package com.verizon.enterprise.ncasbosi.common;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.log4j.Logger;
import com.verizon.kernel.xml.Path;
import com.verizon.kernel.xml.XmlParse;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.billview.BillViewInterface;

public class StoredProcConfig {
	private static final Logger __Logger = Logger.getLogger(StoredProcConfig.class);
	private static StoredProcConfig storedProcConfig = null;
	private static Map osidSp = null;
	private static long timer = 0;
	private static BillViewInterface billViewInterface ;

	public static StoredProcConfig getInstance() {
    	if(storedProcConfig==null) {
    		storedProcConfig =  new StoredProcConfig();
    		timer = System.currentTimeMillis();
    		billViewInterface =  DAOFactory.getInstance().getBillView();
    	}
      return storedProcConfig;
    }


	public void loadFromDB() {

		 osidSp =  new HashMap();
		try {
			Map retMap = billViewInterface.getStoredProcNames();
			__Logger.info(" Innner :: " + retMap);
			Set set = retMap.keySet();
			Iterator iter = set.iterator();
			String spName;
			String osid;
			while (iter.hasNext()) {
				osid = (String) iter.next();
				spName = (String) retMap.get(osid);
				osidSp.put(osid, spName);
			}
		} catch (Exception e) {
			__Logger.error(" loadFromDB FAILED :: " + e);
		}
	}


	public synchronized String getOSIDStoredProcs(String osidName, String value) {
		long minutes = ( System.currentTimeMillis() - timer ) / 60000;
		if(minutes >= 90) {
			if (osidSp	!= null) {
				osidSp.clear();
				osidSp= null;
			}
			timer = System.currentTimeMillis();
		}
		if(osidSp == null)
			loadFromDB();

		String spName = (String)osidSp.get(osidName);
		__Logger.debug("The final value for the stored proc is "+spName);
		if(spName != null){
		return spName;
	  }else{
		return value;
	  }
	}



}