package com.verizon.enterprise.ncasbosi.common;

import java.math.BigDecimal;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import java.util.Calendar;

import java.util.GregorianCalendar;

import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.custom.CLink;
import com.verizon.enterprise.common.ncas.custom.CPermission;
import com.verizon.enterprise.common.ncas.custom.CPortal;

/*
 * Class for common functions (dates) etc.
 */
public class CommonUtil
{

	static private final Logger _LOGGER = Logger.getLogger(CommonUtil.class);
	private static NumberFormat NumberformatLocal =  NumberFormat.getNumberInstance();

	/**
	 * A Method that converts the Date and returns as per the specified format
	 * Method takes any valid date format based java.text.SimpleDateFormat conventions
	 * @param date
	 * @param format
	 */

	public static String getFormattedDateString(Date date, String format)throws Exception
	{
		SimpleDateFormat sdf = null;
		String outDateStr = null;

		if(date != null && format != null)
		{
			try
			{
				sdf = new SimpleDateFormat(format);
				outDateStr= sdf.format(date);
				//outDateStr = sdf.toString();
			}
			catch(Exception e)
			{

				_LOGGER.error("Error while formatting date "+ e.getMessage());
				_LOGGER.debug("Error while formatting date "+ e.getMessage());
				throw e;

			}
		}

		return outDateStr;
	}
	/**
	 * Method returns a String version of double value
	 */
	public static String formatDouble(double val)
	{
		NumberFormat formatter = new DecimalFormat("0.00");
		return formatter.format(val);

		//BigDecimal bd = new BigDecimal(val);
		//return bd.toString();
//		return bd.toPlainString(); when java 1.5 comes around uncomment this
	}


	/**
	 * Method that returns an instance java.sql.Timestamp object that hold the creation timestamp
	 * @return
	 */
	public static Timestamp getCurrentTimestamp()
	{
		Timestamp ts = null;

		Date date = new Date();
		ts = new Timestamp(date.getTime());
		return ts;
	}

	/**
	 * Method that prints the ColumnName, ColumnType, ColumnClassName, TableName and SchemaName for any given ResultSetMetaData.
	 * @param metaData
	 */
	public static void printMetaDataInfo(ResultSetMetaData metaData) {
		try {
			int noOfColumns = metaData.getColumnCount();
			_LOGGER.debug("No of Columns Returned == " + noOfColumns);
			for(int columnIndex=1; columnIndex<=noOfColumns; columnIndex++) {
				_LOGGER.debug("Column Name := " + metaData.getColumnName(columnIndex) +
						" , Column Type := " + metaData.getColumnTypeName(columnIndex) +
						" , Column Class Name := " + metaData.getColumnClassName(columnIndex) +
						" , Table Name := " + metaData.getTableName(columnIndex) +
						" , Schema Name := " + metaData.getSchemaName(columnIndex));
			}
		} catch(SQLException sqlEx) {
			sqlEx.printStackTrace();
		}
	}

	public static Date getDateFromString(String str) {
		Date date = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			date = formatter.parse(str);
		} catch(Exception e) {
			_LOGGER.error("Error while formatting date "+ e.getMessage());
		}
		return date;
	}

	public static Date getDateFromString(String str, String fmt) {
		Date date = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(fmt);
			date = formatter.parse(str);
		} catch(Exception e) {
			_LOGGER.error("Error while formatting date "+ e.getMessage());
		}
		return date;
	}

	public static String getDisplayDateFromString(String str) {
		String retValue = "";
		if (str != null) {
			try {
		    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		    retValue = formatter.format(getDateFromString(str));
			}
			catch (Exception e) {
				_LOGGER.error("Error while formatting Date: Date parsing exception ---" + e.getMessage());
			}
		}	
		return retValue;
	}

	public static String getDisplayDateFromString(Date date) {
		String dateString = "";
		if (date != null) {
			try {
				SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
				dateString = df.format(date);
			}
			catch (Exception e) {
				_LOGGER.error("Error while formatting Date: Date parsing exception ---" + e.getMessage());
			}
		}
		return dateString;
	}

	public static String getDisplayDateFromString(Date date, String fmt) {
		String dateString = "";
		if (date != null) {
			try {
				SimpleDateFormat df = new SimpleDateFormat(fmt);
				dateString = df.format(date);
			}
			catch (Exception e) {
				_LOGGER.error("Error while formatting Date: Date parsing exception ---" + e.getMessage());
			}
		}
		return dateString;
	}

	public static String getDisplayVAMDateFromString(Date date) {
		String dateString = "";
		if (date != null) {
			try {
				SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy");
				dateString = df.format(date);
			}
			catch (Exception e) {
				_LOGGER.error("Error while formatting Date: Date parsing exception ---" + e.getMessage());
			}
		}
		return dateString;
	}


public static String getStrFromDate(Date date) {
		String dateString = "";
		if (date != null) {
			try {
				SimpleDateFormat df = new SimpleDateFormat("MMM yyyy");
				dateString = df.format(date);
			}
			catch (Exception e) {
				_LOGGER.error("Error while formatting Date: Date parsing exception ---" + e.getMessage());
			}
		}
		return dateString;
	}

	public static String getDisplayDateTime(Date inDate) {
	  String dateString = "";
	    if (inDate != null) {
	      try {
	        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	        dateString = df.format(inDate);
	      }
	      catch (Exception e) {
	        _LOGGER.error("NCASBOSI:CommonUtil.java -- Date parsing exception --> " + e.toString());
	      }
	    }
	    return dateString;
	}

	public static String getDisplayDateTimeEx(Date inDate) {
		String dateString = "";
		if (inDate != null) {
			try {
		        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
		        dateString = df.format(inDate);
		    }
		    catch (Exception e) {
		        _LOGGER.error("NCASBOSI:CommonUtil.java -- Date parsing exception --> " + e.toString());
		    }
		}
		return dateString;
	}

	public static boolean isNotNull(String str) {
		boolean retValue = false;
		if(str != null) {
			retValue = true;
		}
		return retValue;
	}

    public static String convertStringFromDouble(double dbl){

        DecimalFormat myFormatter = new DecimalFormat("##########");
        String output = myFormatter.format(dbl);
		return output;
    }

    public static double convertDoubleFromString(String number) {
        double d = 0.0;
        Number n;

        if(number!=null && !number.equals("")){
          try {
              n = NumberformatLocal.parse(number);
              d = n.doubleValue();
           } catch (ParseException nfe) {
					_LOGGER.debug("convertDoubleFromString ParseException: " + nfe.getMessage());
    				_LOGGER.error("convertDoubleFromString ParseException: " + nfe.getMessage());
           }
        }
        return d;
    }

    public static String getFormattedAccount(String account,String osid, String format)
    {
    	String retValue = account;

    	if (!format.equalsIgnoreCase("COL_HDR")) {
      	  if(!osid.equals("04")&&!osid.equals("4")){
    			if (account.length()==13)
    				retValue = account.substring(0,3) + " " + account.substring(3, 6) + "-" + account.substring(6,10) + " " + account.substring(10,13);
    			else if (account.length()==10)
    				retValue = account.substring(0,3) + "-" + account.substring(3, 6) + "-" + account.substring(6,10);
    			else if (account.length()==7)
    				retValue = account.replaceAll("(\\d{3})-*(\\d{4})", "$1-$2");
    	  }
        }
    	return retValue;
    }

    public static void printMap(Map results)
	 {
		 if(results != null)
		 {
	        for (Iterator it = results.entrySet().iterator(); it.hasNext(); ) {
	        	_LOGGER.info("   "+it.next());
	        }
		 }
		 else
		 {
			 _LOGGER.info("Map is null");
			 _LOGGER.error("Map is null");
			 _LOGGER.debug("Map is null");
		 }
	 }
	 public static String mapToString(Map results)
	 {
		 StringBuffer sb = new StringBuffer();
		 if(results != null)
		 {
	        for (Iterator it = results.entrySet().iterator(); it.hasNext(); ) {
	        	sb.append("   "+it.next());
	        }
		 }
		 else {
			 sb.append("null MAP received");
			 _LOGGER.info("Map is null");
			 _LOGGER.error("Map is null");
			 _LOGGER.debug("Map is null");
		 }
	      return sb.toString();
	 }

	 public static void prettyPrintValues(List list) {
		 final String DELIM = ",  ";
		 StringBuffer sBuff = new StringBuffer();
		 int listSize = list.size();
		 for (int index=0; index<listSize; index++) {
			 sBuff.append(list.get(index)).append(DELIM);
		 }
		 sBuff.append('\n');
		_LOGGER.info(sBuff);
	 }

	 public static String getFormattedDisplayValue(String type,String format,String value, String currencyCode, boolean isDownload)
	 {
		String retValue = value;
		if(type.equals("CURRENCY")){
			retValue = getFormattedAmountValue(value, currencyCode, isDownload);
			if (retValue != null && !retValue.equals("")) {
				if (currencyCode != null && !currencyCode.equals("")) {
					if (!isDownload){
					  retValue = retValue + " " + currencyCode;
					}
				}
				if((currencyCode == null || currencyCode.equals("")) &&
					 (format.equals("TBL_GRAND_TL")||format.equals("TBL_TL")||format.equals("FP_SCR_TL")||format.equals("FACE_TL")||format.equals("FP_TL")||format.equals("TBL_OUTER_TL")|| format.equals("RL_TL_PAY")|| format.equals("INV_TL_PAY"))) {
					retValue = "$"+retValue;
				}
			}
		}
		else if(type.equals("DATE"))
			retValue = getFormattedDate(value,"MMMMM dd, yyyy");
		else if(type.equals("DATE_INTL"))
			retValue = getFormattedDate(value,"dd MMMMM, yyyy");
		else if(type.equals("DATE_INTLS"))
			retValue = getFormattedDate(value,"dd/MMM/yyyy");		
		else if(type.equals("DATE_SHORT"))
			retValue = getFormattedDate(value,"MM/dd/yyyy");
		else if(type.equals("DATE_SHORT1"))
			retValue = getFormattedDate(value,"MMM dd, yyyy");
		else if(type.equals("DATE_MY"))
			retValue = getFormattedDate(value,"MMMMM, yyyy");
		else if(type.equals("DATE_MYS"))
			retValue = getFormattedDate(value,"MMM, yyyy");
		else if(type.equals("NUMBER"))
			retValue =placeCommas(value);
		else if(type.equals("TIME")||type.equals("TIME_FULL"))
			retValue = getFormattedTime(value,type);
		else if(type.equals("PHONE"))
			retValue = getFormattedAccount(value,"", format);
		else if(type.equals("PERCENT"))
			if (value.trim().length() == 0) {
			  retValue = value;
		  } else {
			  retValue = value + "%";
		  }
		return retValue;
	 }
	 public static  StringBuffer chkNegative(String arg_num) {
			String tempStr =arg_num;
			if(arg_num.length() > 0 && arg_num.charAt(0) == '-') {
			tempStr = arg_num.substring(1,arg_num.length());
			}
			tempStr = tempStr.replaceAll("^0*","");
			if(tempStr.length()==0) tempStr = "0";
			StringBuffer str = new StringBuffer(tempStr);
				for (int i=str.length()-3; i>0; i-=3) {
					str = str.insert(i,',');
				}
			if(arg_num.length() > 0 && arg_num.charAt(0) == '-') {
				str.insert(0,"-");
			}
				return str;
		}
		 public static String placeCommas(String arg_num) {
			 String tempStr =arg_num;
			 try{
				  double  test = Double.parseDouble(arg_num);
			 if(arg_num != null && arg_num.length() != 0) {
					boolean flag = false;

					if(arg_num.indexOf(".")!= -1) {
					tempStr = arg_num.substring(0,arg_num.indexOf("."));
					flag =true;
					}
					StringBuffer str = chkNegative(tempStr);
					if(flag) {
					//str = str.append(arg_num.substring(arg_num.indexOf("."), arg_num.length()));
						String decimalCheck = arg_num.substring((arg_num.indexOf(".")+1), arg_num.length());
						decimalCheck = decimalCheck.replaceAll("^\\s+", "");
						if(decimalCheck.length()!=0) {
							  decimalCheck = "."+ decimalCheck;
							 str = str.append(decimalCheck);
							 }
					}
					String returnStr =str.toString();
					 //if(returnStr.length()==0) returnStr = "0";
						// try {
							 //double  testStr = Double.parseDouble(returnStr);
							 //if(new Double(arg_num).doubleValue()== 0.0) returnStr = "0";
							 //} catch (NumberFormatException nfe) {
								// return returnStr;
							 //}
					return returnStr;
				 } else {
				 return arg_num;
				 }
			 } catch(Exception e){
					return arg_num;
					}
			}
	 /**
		 * Method that truncats the leading  "0" s and format the number values.
		 * @param Raj
		 */
	 public static String getFormattedAmountValue(String pNumber, String currencyCode, boolean isDownload){
			String number =  "";
			pNumber = pNumber.trim();
			try{
				if(pNumber.length()==0){
					return pNumber;
				}
				if(pNumber.indexOf(",")!=-1){
					pNumber=pNumber.replaceAll(",","");
				}
				if(pNumber.indexOf("CR")!=-1){
					pNumber=pNumber.replaceAll("CR","");
				}

				try{
					new BigDecimal(pNumber);
				}catch(Exception e){
					return pNumber;
				}
				number = getFormattedValue(pNumber);

				if(number.indexOf(".")!=-1){
					number=number.substring(0,number.indexOf(".")+3);
				}
				String minusSign="";
				if(number.indexOf("-")!=-1){
					number = number.substring(number.indexOf("-")+1);
					minusSign="-";
				}
				number=number.trim();
				StringTokenizer str = new StringTokenizer(number,".");
				String afterDecimal = ".00";
				if(number.indexOf(".")!=-1){
					afterDecimal=number.substring(number.indexOf("."));
				}
				StringBuffer sb=new StringBuffer();
				while(str.hasMoreTokens()){
				sb = new StringBuffer(str.nextToken());
				sb=sb.reverse();
				String reversedString = sb.toString();
				ArrayList al = new ArrayList();
				int count=0;
				for (int i=0;i<reversedString.length();i++){
					char temp = reversedString.charAt(i);
					if(count==3){
						al.add(",");
						count=0;
					}
					al.add(String.valueOf(temp));
					++count;
				}
				reversedString="";
				for(int j=0;j<al.size();j++){
					reversedString = reversedString+(String)al.get(j);
				}
				sb=new StringBuffer(reversedString);
				break;
				}
				sb=sb.reverse();
				number=sb.toString();
				number=number+afterDecimal;
				if(minusSign.length()>0){
					if (isDownload || (currencyCode != null && !currencyCode.equals(""))) {
						number= "-" + number;
					} else {
					   number=number+" CR";
					}
				}
				return number;
			}
			catch(Exception e){
				return number;
			}
		}

		public static String getFormattedValue(String inputString){
			String modifiedString = inputString;
			try{
			  modifiedString = new BigDecimal(inputString).toPlainString();
			  return modifiedString;
			}catch(Exception e){
			 return inputString;
			}

		}

/* convert date string in one format to date string in another format */
			public static String formatDate(String dateString, String formatIn, String formatOut)
			{
				try
				{
					if (dateString == null)
						return null;

					SimpleDateFormat sdf = new SimpleDateFormat(formatIn);
					Date dateObect = sdf.parse(dateString);
					sdf = new SimpleDateFormat(formatOut);
					String output = sdf.format(dateObect);
					return output;
				}
				catch(Exception e)
				{
					_LOGGER.error("Date translation failed in CommonUtil.formatDate" +
					     " tried to convert " + dateString + " using format " + formatIn +
					     " to format " + formatOut + " returning null may cause problem later");
					return null;
				}
	}

		 /**
		 * Method that changes the fiven date value to month day and year EX- JAN 07, 2007.
		 * @param Raj
		 */
		public static String getFormattedDate(String date,String format){
			try{
				if(date.trim().length()==0){
					return date;
				}
				if(date.trim().equalsIgnoreCase("0000-00-00")){
					return "00/00/0000";
				}
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date dateObect = sdf.parse(date);
				sdf = new SimpleDateFormat(format);
				date=sdf.format(dateObect);
				return date;
			}catch(Exception e){
				return date;
			}
		}


		public static String getFormattedTime(String time,String type){
			String retValue = time;
			DateFormat formatter = null;
			Date date = null;
			try{
				 if(type.equalsIgnoreCase("TIME")){
				  formatter = new SimpleDateFormat("HH:mm");
				  date = formatter.parse(time);
				  formatter = new SimpleDateFormat("hh:mma");
				 }
				 else{
					    formatter = new SimpleDateFormat("hhmmss");
				        date = formatter.parse(time);
				        formatter = new SimpleDateFormat("hh:mm:ssa");
				 }

			        retValue = formatter.format(date);



			}
			catch(Exception e){
				_LOGGER.error("Exception in getFormattedTime : " + time + " Exp:"+e.getMessage()  );
			}
		    return retValue;

		}



		public static int getMapSize(Map acctMap){
			int size = 0;
			if(acctMap != null){
				Collection co = acctMap.values();
			    Iterator   iterator = co.iterator();

		        while(iterator.hasNext()){
					List  recList = (List)iterator.next();
					size += recList.size();
		        }
			}
	        return size;
		}


		public  static String getCSVStringFromList(List str){
			String retValue = "";
			 if(str != null)
			 {
		        for (Iterator it = str.iterator(); it.hasNext(); ) {
		        	retValue += it.next()+",";
		        }
			 }
	        return retValue;
		}

		public  static List getListFromCSVString(String str){
			List retValue = new ArrayList();

			StringTokenizer strTok = new StringTokenizer(str,",");
			while(strTok.hasMoreTokens()){
				retValue.add(strTok.nextToken());
			 }
	        return retValue;
		}

	public static int getLinkKeyFromFormat(String fmtName) throws Exception{
	 Map portLinkMap = PortalLinkDBConfig.getInstance().getExternalLinks();
	 CLink cLink = (CLink)portLinkMap.get(fmtName);
	 if(cLink != null)
	 {
	 	return cLink.getKey();
	 }
	 else{
		 return -1;
	 }
	}

	public static String getTrackingFromLink(String fmtName)
	{
		 String retValue = "";
		 Map portLinkMap = PortalLinkDBConfig.getInstance().getExternalLinks();
		 CLink cLink = (CLink)portLinkMap.get(fmtName);
		 if(cLink != null)
		 	return cLink.getTrackName();
		 return retValue;
	}


	public static CLink getCLinkFromKey(int linkKey) throws Exception{

	 Map portLinkMap = PortalLinkDBConfig.getInstance().getExternalLinks();
	 List cLinks = null;
	 String linkType = null;
	 CLink cLinkTemp =  null;
	 Object[] cLinkObjs = portLinkMap.values().toArray();

	 for(int i  = 0; i<cLinkObjs.length; i++)
	 {
		 cLinkTemp = (CLink)cLinkObjs[i];
		 if(cLinkTemp != null)
		 {
		 	if(cLinkTemp.getKey()==linkKey)
		 	{
				 return cLinkTemp;
		 	}
		}
	 }
	 return cLinkTemp;
	}

	public static boolean userHasPermission(List userPermissions, String linkName) throws Exception {

		Map portLinkMap = PortalLinkDBConfig.getInstance().getExternalLinks();

	   //Get the permission list for that link

	   CLink cLink = (CLink)portLinkMap.get(linkName);
	   if(cLink != null && cLink.getPermission() != null)
	   {
	   List cPerm = cLink.getPermission();

	   //Get all the permissions the user has..and compare with the required permission to view the link

	   if(cPerm != null && cPerm.size()>0)
	   {
		   //This means the link has an entry in the permissions table

			   for(int i = 0; i<cPerm.size(); i++)
			   {
				   if(userPermissions.contains(((CPermission)cPerm.get(i)).getName()))
				   {
					   //the user has the matching permission.So return true.
					   return true;
				   }
			   }
		   //no matching permission found. So return false so that the link stays hidden for this user.
		   return false;
	   }else
		{
			//This means the link doesn't have any related rows in the permissions table which means
			//the link has no permission constraints. So return true so that the link can be shown.
			return true;
		}
	  }else
		{
			//This means the link doesn't have any related rows in the permissions table which means
			//the link has no permission constraints. So return true so that the link can be shown.
			return true;
		}
   }

   public static boolean linkHasExclusion(String linkName, String portalInd, boolean isAdmin) throws Exception {

		Map portLinkMap = PortalLinkDBConfig.getInstance().getExternalLinks();
		CLink cLink = (CLink)portLinkMap.get(linkName);
		if(cLink !=null)
		{
			if(cLink.getAdmin()!=null && cLink.getAdmin().equalsIgnoreCase("Y"))
			{
				if(!isAdmin)
				{
					//The link config requires the user to be an Admin. This user is not an Admin. So returning true.
					return true;
				}
			}
		}

		if(cLink != null && cLink.getPortal()!=null)
		{
		List cPortal = cLink.getPortal();
		CPortal cPort = null;

	   	if(cPortal != null && cPortal.size()>0)
	   	{
		   //So this link has some exclusions or overrides
		   for(int i = 0; i<cPortal.size(); i++)
		   {
			   cPort =  (CPortal)cPortal.get(i);
			   if(cPort.getName().equalsIgnoreCase(portalInd) && !cPort.isVisible())
			   {
				   //The link should be invisible for this portal
				   return true;
			   }
		   }
		   return false;

	   }else
		{
			return false;
		}
  	  }else
  	  {
		  return false;
	  }

   }

   public static int linkHasOverride(int currentLink, String linkName, String portalInd) throws Exception {

		Map portLinkMap = PortalLinkDBConfig.getInstance().getExternalLinks();
		CLink cLink = (CLink)portLinkMap.get(linkName);
		if(cLink != null && cLink.getPortal()!=null)
		{
			List cPortal = cLink.getPortal();
			CPortal cPort = null;

		   if(cPortal != null && cPortal.size()>0)
		   {
			   //So this link has overrides or exclusions
			   for(int i = 0; i<cPortal.size(); i++)
			   {
				   cPort =  (CPortal)cPortal.get(i);
				   if(cPort.getName().equalsIgnoreCase(portalInd) && cPort.isVisible())
				   {
					   //The link has an override for this portal
					   return cPort.getAlternateLink();
				   }
			   }
			   return currentLink;

		   }else
			{
				return currentLink;
			}
  	 	}else
			{
				return currentLink;
			}
   }

   public static String getDebugLevel(String propertyName) {
	   //NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL
	   String debugLevelValue = NCASBOSIConfig.getProperty(propertyName);
	   if (debugLevelValue.equalsIgnoreCase("EMPTY")) {
		   debugLevelValue = " ";
	   }
	   return debugLevelValue;
   }
	public static int compareDate(String date1, String date2, String formatDateString)throws Exception
	{
		SimpleDateFormat df = new SimpleDateFormat(formatDateString);
		int result = 0;
		result = df.parse(date1).compareTo(df.parse(date2));
		return result;
	}
public static String getCurrentDate() throws Exception
{
	_LOGGER.info("getCurrentDate:::Entering");
	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	return df.format(new Date());
}

public static String getCurrentDate(String format) throws Exception
{
	_LOGGER.info("getCurrentDate:::Entering");
	String date = "";
	try{
		SimpleDateFormat df = new SimpleDateFormat(format);
		date = df.format(new Date());
	}catch(Exception e){

	}
	return date;
}

	public static String  getNextPaymentDateFromNextDate(String currentNextPaymentDate, int recurDay)throws Exception
	{
		_LOGGER.info("getNextPaymentDateFromNextDate:::Entering-> current date"+currentNextPaymentDate);
		String retDate = currentNextPaymentDate;
		if(compareDate(currentNextPaymentDate,getCurrentDate(),"yyyy-MM-dd")<=0){
			Calendar c = Calendar.getInstance();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

			try{
				GregorianCalendar tempDate = new GregorianCalendar();
				tempDate.setTime(df.parse(currentNextPaymentDate));
	            int currentNextDateMonth = tempDate.get(Calendar.MONTH);

	            if(currentNextDateMonth == 12)
	            {
	            	c.set(Calendar.YEAR, tempDate.get(Calendar.YEAR)+1);
	            }
	            else
	            {
	            	c.set(Calendar.YEAR, tempDate.get(Calendar.YEAR));
	            }

	            c.set(Calendar.MONTH, currentNextDateMonth+1 );

	            if((recurDay >28 && currentNextDateMonth == 0) || (recurDay > 30 && currentNextDateMonth !=0))
	            {
	            	c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DATE));
	            }
	            else
	            {
	            	c.set(Calendar.DATE,recurDay);
	            }

	            _LOGGER.info("The new next payment date is :::"+df.format(c.getTime()));
	            retDate = df.format(c.getTime());
	            retDate = getNextPaymentDateFromNextDate(retDate, recurDay);
			}catch(Exception e){
				_LOGGER.error("Invalid Date");
				throw e;
			}

		}
		return retDate;
	}






	public static String getNextPaymentDateVZB(String lastInvDate,int recurDay) throws Exception
	{
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");

		GregorianCalendar currentDate = new GregorianCalendar();
		currentDate.setTime(new Date());

		int month = currentDate.get(Calendar.MONTH);
		int year = currentDate.get(Calendar.YEAR);
		int day = currentDate.get(Calendar.DAY_OF_MONTH);


		int monthInc = 0;


		GregorianCalendar invDate = new GregorianCalendar();

		try{

			if(!lastInvDate.equals("")){
				invDate.setTime(df.parse(lastInvDate));
				if(invDate.before(currentDate)){

					if(invDate.get(Calendar.MONTH) < month || invDate.get(Calendar.YEAR) < year){
					    if(recurDay > day && invDate.get(Calendar.DAY_OF_MONTH) <=  recurDay)
					    	monthInc = 1;
					    else if(recurDay <= day && invDate.get(Calendar.DAY_OF_MONTH) >  recurDay)
					    	monthInc = 2;
					    else if(recurDay == day && invDate.get(Calendar.DAY_OF_MONTH) >  recurDay)
					    	monthInc = 1;
					    else if(recurDay <= day && invDate.get(Calendar.DAY_OF_MONTH) <=  recurDay)
					    	monthInc = 1;
					}else if(invDate.get(Calendar.MONTH) == month){
					    if(recurDay > day && invDate.get(Calendar.DAY_OF_MONTH) >  recurDay)
					    	monthInc = 1;
					    else if(recurDay <= day && invDate.get(Calendar.DAY_OF_MONTH) >  recurDay)
					    	monthInc = 1;
					    else if(recurDay <= day && invDate.get(Calendar.DAY_OF_MONTH) <=  recurDay)
					    	monthInc = 1;

					}
				}
			}



			if((currentDate.get(Calendar.MONTH)==11&&monthInc>0)||(currentDate.get(Calendar.MONTH)==10&&monthInc>1))
					year+=1;
			GregorianCalendar retDate = new GregorianCalendar(year,month+monthInc,recurDay);
			return df2.format(retDate.getTime());
		}catch(Exception e){
			throw e;
		}
	}

	public static String getPaymentDateVZB(String currentPayDate, int recurDay) throws Exception
	{
		GregorianCalendar currentPayDateCalObj = new GregorianCalendar();
		GregorianCalendar currentDateCalObj = new GregorianCalendar();
		GregorianCalendar nextPayDateCalObj = new GregorianCalendar();

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		currentDateCalObj.setTime(new Date());

		// This holds good in a case when a new recur payment is created or edited
		try{
			if (currentPayDate == null)
			{
				nextPayDateCalObj.set(Calendar.YEAR, currentDateCalObj.get(Calendar.YEAR));
				// If the recur day is yet to feature in the current month and recurDay is available in the current month
				if ((recurDay > currentDateCalObj.get(Calendar.DATE)) &&
					(currentDateCalObj.getActualMaximum(Calendar.DATE) >= recurDay))
				{
					nextPayDateCalObj.set(Calendar.MONTH, currentDateCalObj.get(Calendar.MONTH));
					nextPayDateCalObj.set(Calendar.DATE, recurDay);
				}
				// If the recur day is yet to feature in the current month and recurDay is not available in the current month
				else if ((recurDay > currentDateCalObj.get(Calendar.DATE)) &&
						 (currentDateCalObj.getActualMaximum(Calendar.DATE) < recurDay))
				{
					if(currentDateCalObj.get(Calendar.DATE)== currentDateCalObj.getActualMaximum(Calendar.DATE)){
						nextPayDateCalObj.set(Calendar.MONTH, currentDateCalObj.get(Calendar.MONTH) + 1);
						if (nextPayDateCalObj.getActualMaximum(Calendar.DATE) < recurDay)
						{
							nextPayDateCalObj.set(Calendar.MONTH, nextPayDateCalObj.get(Calendar.MONTH));
							nextPayDateCalObj.set(Calendar.DATE, nextPayDateCalObj.getActualMaximum(Calendar.DATE) );
						}
						else
						{
							nextPayDateCalObj.set(Calendar.DATE, recurDay);
						}
					}else{
						nextPayDateCalObj.set(Calendar.MONTH, currentDateCalObj.get(Calendar.MONTH));
						nextPayDateCalObj.set(Calendar.DATE, currentDateCalObj.getActualMaximum(Calendar.DATE));
					}
				}
				//For a case where the recurday has gone by in the current month
				else
				{
					//Skip the current month and reference the next month
					nextPayDateCalObj.set(Calendar.MONTH, currentDateCalObj.get(Calendar.MONTH) + 1);

					// If the next month does not have the recurDay then pay on last day of month
					if (nextPayDateCalObj.getActualMaximum(Calendar.DATE) < recurDay)
					{
						nextPayDateCalObj.set(Calendar.MONTH, nextPayDateCalObj.get(Calendar.MONTH));
						nextPayDateCalObj.set(Calendar.DATE, nextPayDateCalObj.getActualMaximum(Calendar.DATE) );
					}
					// Reference the recurDay in the next month
					else
					{
						nextPayDateCalObj.set(Calendar.DATE, recurDay);
					}
				}
				return df.format(nextPayDateCalObj.getTime());
			}
			//For a recur run
			else
			{
				currentPayDateCalObj.setTime(df.parse(currentPayDate));
				nextPayDateCalObj.set(Calendar.YEAR, currentPayDateCalObj.get(Calendar.YEAR));
				if(recurDay!=currentPayDateCalObj.get(Calendar.DATE) && currentPayDateCalObj.get(Calendar.DATE)==1){
					// code for clean up in case where we are using 1st day of next month as payment day when recur day is not present in the current month
					if (currentPayDateCalObj.getActualMaximum(Calendar.DATE) < recurDay)
					{
						nextPayDateCalObj.set(Calendar.MONTH, currentPayDateCalObj.get(Calendar.MONTH));
						nextPayDateCalObj.set(Calendar.DATE,currentPayDateCalObj.getActualMaximum(Calendar.DATE));
					}
					else
					{
						nextPayDateCalObj.set(Calendar.MONTH, currentPayDateCalObj.get(Calendar.MONTH));
						nextPayDateCalObj.set(Calendar.DATE, recurDay);
					}

				}else{
					nextPayDateCalObj.set(Calendar.MONTH, currentPayDateCalObj.get(Calendar.MONTH) + 1);
					if (nextPayDateCalObj.getActualMaximum(Calendar.DATE) < recurDay)
					{
						nextPayDateCalObj.set(Calendar.MONTH, nextPayDateCalObj.get(Calendar.MONTH));
						nextPayDateCalObj.set(Calendar.DATE, nextPayDateCalObj.getActualMaximum(Calendar.DATE));
					}
					else
					{
						nextPayDateCalObj.set(Calendar.DATE, recurDay);
					}
				}
				return df.format(nextPayDateCalObj.getTime());
			}
		}catch(Exception e){
			throw e;
		}
		
	}




public static int getSettleDayForVZW(String lastInvDate, int recurDay) throws Exception
{
	_LOGGER.info("getSettleDayForVZW:::Entering-> recurDay"+recurDay);

	try{
		if(lastInvDate.equals(""))
		{
			return recurDay;
		}
		int day = getDayFromDate(lastInvDate);
		int tempDay = day+recurDay;
		if(tempDay>30)
		{
			tempDay = tempDay - 30;
		}
		return tempDay;
	}catch(Exception e){
		_LOGGER.error("Invalid Date");
	throw e;
}
}

public static int getDayFromDate(String dateStr) throws Exception
{
	_LOGGER.info("getDayFromDate:::Entering-> recurDay"+dateStr);
	int settleDay = -1;
	try{
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		GregorianCalendar tempDate = new GregorianCalendar();
		tempDate.setTime(df.parse(dateStr));
		settleDay =  tempDate.get(Calendar.DATE);
	}catch(Exception e){
		_LOGGER.error("Invalid Date");
		return settleDay;
	}
	return settleDay;
}

public static String acctNbrMaskForPayments(String number, String vzbVzwFlag) {
	StringBuffer output = new StringBuffer();
	if(vzbVzwFlag.equalsIgnoreCase(NcasConstants.VZB_VZW_FLAG_VZW))
	{
	//this is a vzw account.
	//vzw ->if nbr is 10 or greater than 10, show 7. If between 7 and 9, show 5. if less than 5 show only last two
		if (number != null && number.length() > 0) {
			//This condition takes care of uniform formatting style in case the serviceid comes from vzw_payment_status.
			if(number.indexOf('-')==-1 && number.length()>5){
				  number = new StringBuffer(number).insert(number.length()-5, "-").toString();
			 }
			int numberLength = number.length();
			char[] lnumber = number.toCharArray();
			output.append("xxxxx");
			if (numberLength >= 10) {
				output.append(number.substring(numberLength-7,numberLength));
			} else if (numberLength > 6 && numberLength < 10) {
				output.append(number.substring(numberLength-5,numberLength));
			} else {
				output.append(number.substring(numberLength-2,numberLength));
			}


		}else
		{
			return number;
		}
	}
	else{
	//this is a vzb account.
	//vzb ->if 8 or greater than 8, show 5. If between 5 and 7, show 3. if less than 5 show only last two
		if (number != null && number.length() > 0) {
			int numberLength = number.length();
			char[] lnumber = number.toCharArray();
			output.append("xxxxx");
			if (numberLength >= 8) {
				output.append(number.substring(numberLength-5,numberLength));
			} else if (numberLength > 4 && numberLength < 8) {
				output.append(number.substring(numberLength-3,numberLength));
			} else {
				output.append(number.substring(numberLength-2,numberLength));
			}
		}else
		{
			return number;
		}
	}

	return output.toString();
}


	public static String creditCardMask(String number) {
		StringBuffer output = new StringBuffer();
		output.append("xxxxxxxxxx");
		if (number != null && number.length() > 0) {
			int numberLength = number.length();
			char[] lnumber = number.toCharArray();
			if (numberLength >= 11) {
				output.append(number.substring(numberLength-4,numberLength));
			} else if (numberLength >= 8 && numberLength <= 10) {
				output.append(number.substring(numberLength-2,numberLength));
			} else {
				output.append(lnumber[numberLength - 1]);
			}

		}
		return output.toString();
	}

	public static String bankAcctMask(String number)
	{
	  StringBuffer output = new StringBuffer();
	  if(number!=null && number.length()>0)
	  {
	  int numberLength = number.length();
	  char[] lnumber = number.toCharArray();
	  if(numberLength>=8)
	  {
			output.append(lnumber[0]).append(lnumber[1]).append("xxxxxxx")
									 .append(number.substring(numberLength-2,numberLength));
	  }
	  else if(numberLength>=4 && numberLength<=7)
	  {
			output.append(lnumber[0]).append("xxxxxxx")
			.append(lnumber[numberLength-1]);
	  }
	  else
	  {
		  output.append("xxxxxxx")
			.append(lnumber[numberLength-1]);
	  }

	}
	  return output.toString();
	}

	/**
	 * method to decode base64 encoded string
	 */
	static char[]    map1 = new char[64];
	static {
	   int i=0;
	   for (char c='A'; c<='Z'; c++) map1[i++] = c;
	   for (char c='a'; c<='z'; c++) map1[i++] = c;
	   for (char c='0'; c<='9'; c++) map1[i++] = c;
	   map1[i++] = '+'; map1[i++] = '/';
	 }

	static byte[] map2 = new byte[128];
	static {
	   for (int i=0; i<map2.length; i++) map2[i] = -1;
	   for (int i=0; i<64; i++) map2[map1[i]] = (byte)i;
	}

	/**
	* Decodes a byte array from Base64 format.
	* No blanks or line breaks are allowed within the Base64 encoded data.
	* @param in  a character array containing the Base64 encoded data.
	* @return    An array containing the decoded data bytes.
	* @throws    IllegalArgumentException if the input is not valid Base64 encoded data.
	*/
	public static String decode (char[] in) {
	   int iLen = in.length;
	   if (iLen%4 != 0) throw new IllegalArgumentException ("Length of Base64 encoded input string is not a multiple of 4.");
	   while (iLen > 0 && in[iLen-1] == '=') iLen--;
	   int oLen = (iLen*3) / 4;
	   byte[] out = new byte[oLen];
	   int ip = 0;
	   int op = 0;
	   while (ip < iLen) {
	      int i0 = in[ip++];
	      int i1 = in[ip++];
	      int i2 = ip < iLen ? in[ip++] : 'A';
	      int i3 = ip < iLen ? in[ip++] : 'A';
	      if (i0 > 127 || i1 > 127 || i2 > 127 || i3 > 127)
	         throw new IllegalArgumentException ("Illegal character in Base64 encoded data.");
	      int b0 = map2[i0];
	      int b1 = map2[i1];
	      int b2 = map2[i2];
	      int b3 = map2[i3];
	      if (b0 < 0 || b1 < 0 || b2 < 0 || b3 < 0)
	         throw new IllegalArgumentException ("Illegal character in Base64 encoded data.");
	      int o0 = ( b0       <<2) | (b1>>>4);
	      int o1 = ((b1 & 0xf)<<4) | (b2>>>2);
	      int o2 = ((b2 &   3)<<6) |  b3;
	      out[op++] = (byte)o0;
	      if (op<oLen) out[op++] = (byte)o1;
	      if (op<oLen) out[op++] = (byte)o2; }
	   return new String(out);
	 }


	//this is for GCP - accounts are eligible for selection only if the eligi.indicator is 01
	public static boolean isEligibleForSelection(String eligibilityIndicator){
		if(eligibilityIndicator!=null && "01".equalsIgnoreCase(eligibilityIndicator)){
			return true;
		}else{
			return false;
		}
	}

	public static String getNextSchDateForRpt(String startDate, int recurDay) throws Exception
	{
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		GregorianCalendar refDate = new GregorianCalendar();
		GregorianCalendar retDate = new GregorianCalendar();
		//retDate.setTime(new Date());

		if (startDate.length() > 0)
		{
			refDate.setTime(df.parse(startDate));
		}
		else
		{
			refDate.setTime(new Date());
		}

		int monthInc = 0;

		if (startDate.length() > 0)
		{
			if(refDate.get(Calendar.DAY_OF_MONTH) >  recurDay)
			{
				monthInc = 1;
			}
		}
		else
		{
			if(refDate.get(Calendar.DAY_OF_MONTH) >=  recurDay)
			{
				monthInc = 1;
			}
		}

		retDate.roll(Calendar.MONTH, monthInc);
		retDate.set(Calendar.DAY_OF_MONTH, recurDay);

		if((refDate.get(Calendar.MONTH)==11&&monthInc>0)||(refDate.get(Calendar.MONTH)==10&&monthInc>1))
		{
			retDate.set(Calendar.YEAR, refDate.get(Calendar.YEAR)+1);
		}
		else
		{
			retDate.set(Calendar.YEAR, refDate.get(Calendar.YEAR));
		}
		return df.format(retDate.getTime());
	}

	public static String getDisplayVAMDateFromStringEx(Date date) {
		String dateString = "";
		if (date != null) {
			try {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				dateString = df.format(date);
			}
			catch (Exception e) {
				_LOGGER.error("Error while formatting Date: Date parsing exception ---" + e.getMessage());
			}
		}
		return dateString;
	}

	public static Class getClassType(Object input){
		Class clName = null;
		if(input instanceof String){
			clName = String.class;
		}else if(input instanceof Integer){
			clName = Integer.class;
		}else if(input instanceof Map){
			clName = Map.class;
		}else if(input instanceof List){
			clName = List.class;
		}else{
			clName = input.getClass();
		}
		return clName;
	}

	public static String trimSpace(String input){
		return input!=null?input.trim():input;
	}
}
