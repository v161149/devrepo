package com.verizon.enterprise.ncasbosi.common;


import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.common.ncasbosi.beans.SystemParam;


public class SystemParamConfig {
	
	public static String getProperty(String key)
	{
		return getValueFromCache(key);
	}
	public static SystemParam getObjectProperty(String key)
	{
		return getFullObjectFromCache(key);
	}
	public static String getProperty(String key, String defaultValue)
	{
		String value = getValueFromCache(key);
		return (value == null) ? defaultValue : value;
	}

	public static boolean getBooleanProperty(String key)
	{
		return isBoolean(getProperty(key));
	}

	public static boolean getBooleanProperty(String key, boolean defaultValue)
	{
		String value = getProperty(key);
		return (value == null) ? defaultValue : isBoolean(value);
	}

	private static boolean isBoolean(String value)
	{
		return (value != null && (value.equals("1") ||
				value.equalsIgnoreCase("true") ||
				value.equalsIgnoreCase("y")));
	}

	public static int getIntProperty(String key)
	{
		return Integer.parseInt(getProperty(key));
	}

	public static int getIntProperty(String key, int defaultValue)
	{
		String value = getProperty(key);
		return (value == null) ? defaultValue : Integer.parseInt(value);
	}

	public static long getLongProperty(String key)
	{
		return Long.parseLong(getProperty(key)) ;
	}

	public static long getLongProperty(String key, long defaultValue)
	{
		String value = getProperty(key);
		return (value == null) ? defaultValue : Long.parseLong(value);
	}

	public static float getFloatProperty(String key)
	{
		return Float.parseFloat(getProperty(key));
	}

	public static float getFloatProperty(String key, float defaultValue)
	{
		String value = getProperty(key);
		return (value == null) ? defaultValue : Float.parseFloat(value);
	}

	public static double getDoubleProperty(String key)
	{
		return Double.parseDouble(getProperty(key));
	}

	public static double getDoubleProperty(String key, double defaultValue)
	{
		String value = getProperty(key);
		return (value == null) ? defaultValue : Double.parseDouble(value);
	}
	
	private static String getValueFromCache(String key){
		String propertyValue=DAOFactory.getInstance().getSystemParamCache().get(new SystemParam(key,null));
		return propertyValue;
	}
	private static SystemParam getFullObjectFromCache(String key){
		SystemParam systemParamObject=DAOFactory.getInstance().getSystemParamCache().getFullObject(new SystemParam(key,null));
		return systemParamObject;
	}
	
}
