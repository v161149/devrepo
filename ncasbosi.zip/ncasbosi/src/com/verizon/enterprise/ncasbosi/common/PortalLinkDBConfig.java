package com.verizon.enterprise.ncasbosi.common;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.custom.CLink;
import com.verizon.enterprise.common.ncas.custom.CPermission;
import com.verizon.enterprise.common.ncas.custom.CPortal;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.portallinks.PortalLinkInterface;

public class PortalLinkDBConfig {
	private static final Logger __Logger = Logger.getLogger(PortalLinkDBConfig.class);
	private static PortalLinkDBConfig portLinkConfig = null;
	private Map portLinkMap = null;
	private static long timer = 0;
	private static PortalLinkInterface portalLinkInterface;

	public static PortalLinkDBConfig getInstance() {
		if (portLinkConfig == null) {
			portLinkConfig = new PortalLinkDBConfig();
			portalLinkInterface = DAOFactory.getInstance().getPortalLink();
		}
		return portLinkConfig;
	}

	public synchronized void populatePortalLinkDBInfo() {

		portLinkMap = new HashMap();
		try {
			Map retMap = portalLinkInterface.selectAllPortalLinks();
			__Logger.debug(" Portal Link map :: " + retMap);
			Set set = retMap.keySet();
			Iterator iter = set.iterator();
			CLink cLink;
			String linkName;
			while (iter.hasNext()) {
				linkName = (String) iter.next();
				cLink = (CLink) retMap.get(linkName);
				printCLink(cLink);
				portLinkMap.put(linkName, cLink);
			}

		} catch (Exception e) {
			__Logger.error(" populatePortalLinkDBInfo FAILED :: " + e);
		}
	}

	public synchronized String getExternalLink(String name, String value) {
		if (portLinkMap == null)
			populatePortalLinkDBInfo();
		CLink cLink = (CLink) portLinkMap.get(name);

		if (cLink != null) {
			value = value.replaceAll("'", "\\\\'");

			String prefix = "BV_LNK";
			String funcName = cLink.getExtFunc();
			int index = funcName.indexOf(".");
			if (index > 0) {
				prefix = funcName.substring(0, index);
				funcName = funcName.substring(index + 1);
			}

			String extLinkFinalValue = "javascript:" + prefix + ".Handler('" + funcName + "','" + cLink.getTrackName() + "','" + value + "')";
			__Logger.debug("The final value for the link " + name + " is :" + extLinkFinalValue);

			return extLinkFinalValue;

		} else {
			return value;
		}
	}

	public synchronized Map getExternalLinks() {
		if (portLinkMap == null)
			populatePortalLinkDBInfo();
		return portLinkMap;
	}

	private static void printCLink(CLink cLink) {

		__Logger.debug("************************");
		__Logger.debug("KEY->" + cLink.getKey());
		__Logger.debug("NAME->" + cLink.getName());
		__Logger.debug("DESC->" + cLink.getDesc());
		__Logger.debug("TOOLTIP->" + cLink.getTooltip());
		__Logger.debug("EXTFUNC->" + cLink.getExtFunc());
		__Logger.debug("TYPE->" + cLink.getType());
		__Logger.debug("INTLNAME->" + cLink.getIntlName());
		__Logger.debug("INTLTOOLTIP->" + cLink.getIntlTooltip());
		__Logger.debug("ADMIN->" + cLink.getAdmin());
		__Logger.debug("USERTYPE->" + cLink.getUserType());

		List cperm = cLink.getPermission();

		for (int i = 0; i < cperm.size(); i++) {
			__Logger.debug("CPERMISSION'S KEY->" + ((CPermission) cperm.get(i)).getKey());
			__Logger.debug("CPERMISSION'S NAME->" + ((CPermission) cperm.get(i)).getName());
		}

		List cport = cLink.getPortal();

		for (int i = 0; i < cport.size(); i++) {
			__Logger.debug("CPORTAL'S KEY->" + ((CPortal) cport.get(i)).getKey());
			__Logger.debug("CPORTAL'S NAME->" + ((CPortal) cport.get(i)).getName());
			__Logger.debug("CPORTAL'S ISVISIBLE->" + ((CPortal) cport.get(i)).isVisible());
			__Logger.debug("CPORTAL'S ALTERNATELINK->" + ((CPortal) cport.get(i)).getAlternateLink());
		}

		__Logger.debug(".........................");
	}

}