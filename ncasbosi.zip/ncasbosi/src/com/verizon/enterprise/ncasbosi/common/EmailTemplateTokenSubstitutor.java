package com.verizon.enterprise.ncasbosi.common;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * @author v992473
 * This is a special class that replaces tokens in the email template with the run-time values
 */
public class EmailTemplateTokenSubstitutor {

	private static EmailTemplateTokenSubstitutor templateTokenSubstitutor;
	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	private final String EMAIL_SBST_STR = "EMAIL_SBST.";
	private String OPEN_BRACES = "{";
	private String CLOSED_BRACES = "}";

	private EmailTemplateTokenSubstitutor(){}

	public synchronized static EmailTemplateTokenSubstitutor getInstance(){
		if(templateTokenSubstitutor == null){
			templateTokenSubstitutor = new EmailTemplateTokenSubstitutor();
		}
		return templateTokenSubstitutor;
	}

	private Object getValueOfTheField(String fieldName,Object _thisObj) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException{
			Field[] fieldArray = _thisObj.getClass().getDeclaredFields();
			int fieldLocation = findIndexOfTheField(fieldArray, fieldName);
			if(fieldLocation == -1){
				return getValueFromBases(fieldName, _thisObj.getClass().getSuperclass(),_thisObj);
			}else{
				setFieldAccessible(fieldArray[fieldLocation]);
				return fieldArray[fieldLocation].get(_thisObj);
			}
	}

	private void setFieldAccessible(Field field){
			field.setAccessible(true);
	}

	private Object getValueFromBases(String fieldName,Class superClass,Object _thisObj) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException{
			if(superClass == Object.class){
				throw new NoSuchFieldException("No Such Field :: "+fieldName);
			}else{
					Field[] fieldArray = superClass.getDeclaredFields();
					int fieldLocation = findIndexOfTheField(fieldArray, fieldName);
					if(fieldLocation == -1){
						return getValueFromBases(fieldName,superClass.getSuperclass(),_thisObj);
					}else{
						setFieldAccessible(fieldArray[fieldLocation]);
						return fieldArray[fieldLocation].get(_thisObj);
					}
			}
	}

	private int findIndexOfTheField(Field[] fieldArray,String fieldName){
			int fieldLocation = -1;
			for(int j=0;j<fieldArray.length;j++){
				if(fieldArray[j].getName().equals(fieldName)){
					fieldLocation = j;
					break;
				}
			}
			return fieldLocation;
	}

	private Object getValueFromCustomObject(Object[] fields,Object _thisObj) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException{
			boolean searchForList = false;
			boolean searchForMap = false;
			Object thisObject = _thisObj;

			for(int i=0;i<fields.length;i++){
				String fieldName = (String)fields[i];
				thisObject = getValueOfTheField(fieldName, thisObject);

				if(thisObject instanceof List){
					searchForList = true;
				}
				if(thisObject instanceof Map){
					searchForMap = true;
				}
				if(searchForList && (i+1) < fields.length){
					List<Object> listObj = new ArrayList<Object>();
					for(int objCount=0;objCount<fields.length;objCount++){
						if(objCount>i){
							listObj.add(fields[objCount]);
						}
					}
					List outList = new ArrayList();
					getValueFromCustomList((Object[])listObj.toArray(new Object[0]), thisObject, outList);
					return getListDataInPrintableFormat(outList);
				}
				if(searchForMap && (i+1) < fields.length){
					List<Object> mapObj = new ArrayList<Object>();
					for(int objCount=0;objCount<fields.length;objCount++){
						if(objCount>i){
							mapObj.add(fields[objCount]);
						}
					}
					return getValueFromCustomMap(mapObj.toArray(new Object[0]), thisObject);
				}
			}
			return thisObject;
	}

	private Object getValueFromCustomMap(Object[] fields, Object mapObj) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException{
		List<Object> listObjOut = new ArrayList<Object>();
		if(fields.length == 1 && "KEYS".equalsIgnoreCase((String)fields[0])){
			return ((Map)mapObj).keySet();
		}
		if(fields.length >1 && "VALUES".equalsIgnoreCase((String)fields[0])){
			Iterator<Object> it = ((Map)mapObj).values().iterator();
			while(it.hasNext()){
				Object thisObject = it.next();
				for(int i=1;i<fields.length;i++){
					String fieldName = (String)fields[i];
					thisObject = getValueOfTheField(fieldName, thisObject);
				}
				listObjOut.add(thisObject);
			}
		}
		return listObjOut;
	}

	private void getValueFromCustomList(Object[] fields, Object listObj, List listObjOut) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException{
		LISTSUBSTITUTOR:
		for(int k=0;k < ((List<Object>)listObj).size();k++){
			Object _thisObj = ((List<Object>)listObj).get(k);
			Object thisObject = _thisObj;
			for(int i=0;i<fields.length;i++){
				String fieldName = (String)fields[i];
				thisObject = getValueOfTheField(fieldName, thisObject);
				if(thisObject instanceof List){
					//System.out.println("inside list");
					List<Object> loopListObj = new ArrayList<Object>();
					for(int objCount=0;objCount<fields.length;objCount++){
						if(objCount>i){
							loopListObj.add(fields[objCount]);
						}
					}
					getValueFromCustomList(loopListObj.toArray(new Object[0]), thisObject, listObjOut);
					continue LISTSUBSTITUTOR;
				}
			}
			listObjOut.add(thisObject);
		}
	}

	private Object setDynamicEmailTokenString(String checkParamStr, Object inputObj, Object fieldValue) {
		try {
			//all the objects that want appenders to their tokens must have this method - checkParamsAndAppendDynamicEmailTokenString
			//for example see VBIFEmailInfo
			Method method = inputObj.getClass().getMethod("checkParamsAndAppendDynamicEmailTokenString", new Class[]{String.class, Object.class});
			return method.invoke(inputObj, new Object[]{checkParamStr, fieldValue});
		} catch (Exception e) {
			//e.printStackTrace();
			return fieldValue;
		}
	}

	private Object checkParamsAndAppendDynamicEmailTokenString(Object param, Object fieldValue, Object inputObj){
		String[] checkParams;
		try{
			//all the objects that want appenders to their tokens must have this String[] CHECK_PARAMS_FOR_TOKEN_APPENDERS declared
			//for example see VBIFEmailInfo
			checkParams = (String[])getValueOfTheField("CHECK_PARAMS_FOR_TOKEN_APPENDERS", inputObj);
			 if(checkParams == null){
				 return fieldValue;
			 }
		}catch (Exception e) {
			//e.printStackTrace();
			return fieldValue;
		}
		if(param instanceof String){
			String paramStr = (String)param;
			if(Arrays.asList(checkParams).contains(paramStr)){
				return setDynamicEmailTokenString(paramStr,inputObj,fieldValue);
			}
		}else if(param instanceof Object[]){
			List<Object> paramList = Arrays.asList((Object[])param);
			for(String paramStr: checkParams){
				if(paramList.contains(paramStr)){
					return setDynamicEmailTokenString(paramStr,inputObj,fieldValue);
				}
			}
		}
		return fieldValue;
	}

	/**
	 * @param listValues
	 * @return
	 * This method prints the List of values in a document format(line-by-line)
	 */
	private String getListDataInPrintableFormat(List listValues){
		StringBuffer buffer = new StringBuffer();
		if(listValues!=null){
			for(Object listItem: listValues){
				buffer.append(listItem!=null?listItem:"");
				buffer.append("<BR><BR>");
			}
		}
		return buffer.toString();
	}

	/**
	 * @param tic
	 * @param desc
	 * @return
	 * @throws Exception
	 * This is the only method exposed
	 */
	public String substituteValuesInEmailTemplate(Object tic, String desc)throws Exception{
		_LOGGER.info("template before substituion::\n"+desc);
		if(desc==null){
			return "";
		}
		StringBuffer descBuffer = new StringBuffer(desc);
		replaceTokens(tic, descBuffer);
		_LOGGER.info("template after substituion::\n"+descBuffer.toString());
		return descBuffer.toString();
	}


	/**
	 * @param tic
	 * @param desc
	 * @throws IllegalArgumentException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * This method replaces tokens in email template recursively based on tokenReplacer values
	 */
	private void replaceTokens(Object tic, StringBuffer desc) throws IllegalArgumentException, SecurityException, IllegalAccessException, NoSuchFieldException{
		int startBrace = desc.indexOf(OPEN_BRACES+EMAIL_SBST_STR);
		if(startBrace < 0){
			//nothing
		}else{
			int emailSbstLen = EMAIL_SBST_STR.length();
			int closedBrace = desc.indexOf(CLOSED_BRACES,startBrace);
			String token = desc.substring(startBrace+emailSbstLen+1, closedBrace);
			String[] tokenArr = token.split("\\.");
			desc.delete(startBrace, closedBrace+1);
			Object fieldValue = getValueFromCustomObject(tokenArr,tic);
			fieldValue = checkParamsAndAppendDynamicEmailTokenString(tokenArr, fieldValue, tic);
			desc.insert(startBrace,String.valueOf(fieldValue==null?"":fieldValue));
			replaceTokens(tic, desc);
		}
	}
}
