package com.verizon.enterprise.ncasbosi.common;

import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.dao.Impl.batch.BatchRequestDAOImpl;
import com.verizon.enterprise.ncasbosi.dao.Impl.perf.LogPerfHelper;
import com.verizon.enterprise.ncasbosi.dao.Impl.payments.PaymentsDAOImpl;

public class BatchProcessorHelper
{
	private static final org.apache.log4j.Logger __Logger = org.apache.log4j.Logger.getLogger(BatchProcessorHelper.class);
	private String batchControlKey = "";
	private String batchTypeName = "";
	PaymentsDAOImpl payDaoImplObj = null;
	BatchRequestDAOImpl batchDaoObj = null;
	
	public BatchProcessorHelper(String batchControlKey)
	{
		super();
		initialize(batchControlKey,"");
	}
	
	private void initialize(String key,String type)
	{
		final String METHOD_NAME = "initialize()";
	   __Logger.info("ENTER " + METHOD_NAME);

	   try
	   {
		   batchControlKey = key;
		   batchTypeName = type;
		   payDaoImplObj = new PaymentsDAOImpl();
		   batchDaoObj = new BatchRequestDAOImpl();
	   }
	   catch(Exception ex)
	   {
	   	     ex.printStackTrace();
	   	     __Logger.error(METHOD_NAME + " Exception "+ex.getMessage());
	   }	
	   __Logger.info("EXIT " + METHOD_NAME);
	}

	public  boolean lock()throws Exception
	{
		final String METHOD_NAME = "lock()";
		boolean retValue = false;
		__Logger.info("ENTER " + METHOD_NAME);
	 	try
	 	{
	 		int updatedRows = batchDaoObj.lockBatchControl(NcasConstants.BATCH_PERF_ONETIME, false);
			if (updatedRows>0)
				retValue = true;
		}
	 	catch(Exception ex)
	 	{
	 		ex.printStackTrace();
		   	__Logger.error(METHOD_NAME + " Exception "+ex.getMessage());
		   	payDaoImplObj.insertInternalEmail("PORTAL_BILLING_NOTIF_TEMPLATE",ex.getMessage(),METHOD_NAME);
	 	}
		__Logger.info("EXIT " + METHOD_NAME + " retValue :: "+retValue + "for " + batchControlKey);
		return retValue;
	}
	
	public void unlockBatchControl()throws Exception
	{
		__Logger.info("About to unlock the batch control");
		try
		{
			batchDaoObj.unlockBatchControl(batchControlKey);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			 __Logger.error("unlockBatchControl Failed \n"+ex.getMessage());
			throw ex;
		}
		__Logger.info("finished unlocking the batch control");
	}
}
