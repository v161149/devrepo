package com.verizon.enterprise.ncasbosi.common;

public interface NCASBOSIConstants {

	public static final String BILL_TRACKING_BEAN_NAME = "billtracking";

	public static final String SP_BILL_TRACKING = "TARGET_METRICS";

	public static final String VAM_SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	public static final String VAC_TABLESCHEMA_NAME = "verizon.ncasbosi.billInquiry.biVAC.auditTableSchema"; // VARVZT,
	public static final String VAC_SPSCHEMA_NAME = "verizon.ncasbosi.vac.schemaName";
	public static final String VGW_SCHEMA_NAME = "verizon.ebosi.bill.vgw.schema";
	public static final String BARSWEST_SCHEMA_NAME = "verizon.ebosi.bill.barswest.schema";
	public static final String BRI_SCHEMA_NAME = "verizon.ncasbosi.bri.schemaName";

	public static final String VAC_SCHEMA_NAME = NCASBOSIConfig.getProperty(VAC_SPSCHEMA_NAME); // FOR SP's VAR
	public static final String VAC_TABLESCHEMA = NCASBOSIConfig.getProperty(VAC_TABLESCHEMA_NAME);
	public static final String VAM_SCHEMA = BOSIConfig.getProperty(VAM_SCHEMA_NAME);
	public static final String VAM_USER_ID_CONFIG_PATH = "verizon.ebosi.bill.vam.userid";

	// SQL
	public static String WS_LOG_INSERT_SQL = "INSERT INTO " + VAC_TABLESCHEMA
			+ ".OBDS_OV_AUDIT(TRACKING_ID,ACTION_TYPE, REQ_MESSAGE,RETN_CODE, RETN_MESSAGE,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";

	public static String ONE_VIEW_INSERT_USER = "NCASBOSI.SYSTEM";

	// Oneview and R2 punching
	public static final String ONEVIEW_R2_ACTION = "PUNCH";
	public static final String ONEVIEW_R2_USER = "punchcode";

	// IBI - IBIWS_AUDIT
	public static String PORTAL_WS_LOG_INSERT_SQL = "INSERT INTO " + BOSIConfig.getProperty(VAM_SCHEMA_NAME)
			+ ".BIWS_AUDIT (SRC_SYS_BI_ID,SECONDARY_BI_ID,ACTION,SOAPOUT,SOAPIN,LAST_UPDATED,LAST_UPDATED_BY) VALUES (?,?,?,?,?,?,?)";

	// SP
	public static final String SP_TEST_VAC = VAC_SCHEMA_NAME + "." + "GET_APPROVAL_TXS";
	public static final String SP_GET_BI = VAC_SCHEMA_NAME + "." + "GET_BILL_INQUIRY";
	public static final String SP_GET_BIS = VAC_SCHEMA_NAME + "." + "SEARCH_BILL_INQ";
	public static final String SP_CREATE_BI = VAC_SCHEMA_NAME + "." + "CREATE_BIL_INQUIRY";
	public static final String SP_UPDATE_BI = VAC_SCHEMA_NAME + "." + "UPDATE_BIL_INQUIRY";
	public static final String SP_GET_BI_DROPDOWNS = VAC_SCHEMA_NAME + "." + "GET_BI_DROP_DOWNS";
	public static final String SP_SEARCH_CLAIMS = VAC_SCHEMA_NAME + "." + "SEARCH_CLAIMS";
	public static final String SP_GET_VBCC_CLAIM = VAC_SCHEMA_NAME + "." + "GET_VBCC_CLAIM";

	// Real Bill Inquiry Constants - 3/27/2007
	public static final String BILL_INQUIRY_BEAN_NAME = "billinquiry";
	public static final String BI_VAC_RETURN_CODE_IDENTIFIER = "RETURN_CODE";
	public static final String BI_VAC_REASON_CODE_IDENTIFIER = "REASON_CODE";
	public static final String BI_VAC_ERROR_TEXT_IDENTIFIER = "ERROR_TEXT";
	public static final String BI_VAC_WARNING_TEXT_IDENTIFIER = "ERROR_TEXT";
	public static final String BI_ORIG_SYSTEM = "IntegBillingPortal";
	public static final String BI_IXPLUS = "IXPlus";
	public static final String BI_SINGELVIEW = "SingleView";
	public static final String BI_IBRS = "IBRS";
	public static final String BI_VISION = "Vision";
	public static final int BI_VAC_ERROR_CODE = 8;
	public static final int BI_VAC_WARNING_CODE = 4;
	public static final String CLAIM_NOT_FOUND_ERROR_CODE = "SGVC#002";
	public static final String CLAIM_USER_NOT_ENTITLED_ERROR_CODE = "SGVC#004";
	public static final String BI_NOT_FOUND_ERROR_CODE = "SGBQ#016";
	public static final String BI_USER_NOT_ENTITLED_ERROR_CODE = "SGBQ#004";
	
	public static final String BI_STATUS = "BI_STATUS"; //Aug2012. Followup/Tickler
	public static final String BI_SUB_STATUS ="BI_SUB_STATUS";//Aug2012

	// Bill Views
	public static final String BILL_VIEW_BEAN_NAME = "billViews";
	public static final String SP_BILL_VIEW = "PORTAL_IBRS_INFO";
	public static final String SP_EXT_BILL_VIEW = "PORTAL_BILLVIEW_XL";
	public static final String SP_SEARCH_LIST = "SEARCH_LIST";

	public static final String SP_START_PAGE = "IBRS_START_PAGE";
	public static final String SP_DEFERRED_DL = "PORTAL_IBRS_INF_DL";
	public static final String SP_USER_PREF = "USER_PREFS";
	public static final String SP_CHECK_PAPER_BILLS = "CHECK_PAPER_BILLS";

	// eMedia
	public static final String EMEDIA_PROFILE_BEAN_NAME = "eMediaProfile";
	public static final String SP_GENERATE_CONFIG_ID = "GENERATE_CONFIG_ID";
	public static final String SP_GET_EM_PROFILE = "GET_EM_PROFILE";
	public static final String SP_SEARCH_EM_PROFILE = "SEARCH_EM_PROFILE";
	public static final String SP_GET_EM_CONTACT = "GET_EM_CONTACT";
	public static final String SP_MANAGE_EM_CONTACT = "MANAGE_EM_CONTACT";
	public static final String SP_MANAGE_EM_PROFILE = "MANAGE_EM_PROFILE";
	public static final String SP_GET_EM_SVC_PROV = "GET_EM_SVC_PROV";
	public static final String SP_GET_EM_DROPDOWN = "GET_EM_DROPDOWN";
	public static final String SP_GET_EM_HISTORY = "GET_EM_HISTORY";
	public static final String SP_GET_EM_ACCTS = "GET_EM_ACCTS";
	public static final String SP_GET_GBR_ACCTS = "GET_GBR_ACCTS";
	public static final String SP_SEARCH_BM_DD_CFGS = "SEARCH_BM_DD_CFGS";
	public static final String SP_MANAGE_EM_ACCTS = "MANAGE_EM_ACCOUNTS";
	public static final String SP_MANAGE_GBR_ACCTS = "MANAGE_GBR_ACCTS";
	public static final String SP_PUT_EM_RECREATE_RQST = "PUT_EM_REC_RQST";
	public static final String SP_GET_EM_RECREATE_RQST = "GET_EM_REC_RQST";
	public static final String SP_GET_EM_SUMMARY = "SUMMARY_EMEDIA_V10";
	public static final String SP_GET_EM_CORP_SUMMARY = "CORP_EMEDIA_V10";
	public static final String SP_GET_GBR_SUMMARY = "SUMMARY_GBR_V11";
	public static final String SP_GET_GCP_SUMMARY = "SUMMARY_GCP_V11";
	public static final String SP_GET_GBR_CORP_SUMMARY = "CORP_GBR_V11";
	public static final String SP_GET_GCP_CORP_SUMMARY = "CORP_GCP_V11";
	public static final String SP_GET_EM_SUMMARY_MRG = "SUMMARY_EMEDIA_MRG";
	public static final String SP_GET_EM_CORP_SUMMARY_MRG = "CORP_EMEDIA_MRG";
	public static final String SP_GET_EM_ACCTS_BY_SEARCH = "SERVICE_EMEDIA_V10";
	public static final String SP_GET_GBR_ACCTS_BY_SUBSCRIPTION = "SERVICE_GBR_V11";
	public static final String SP_GET_GCP_ACCTS_BY_SUBSCRIPTION = "SERVICE_GCP_V11";
	public static final String SP_GET_SECABS_ACCTS_BY_SUBSCRIPTION = "SERVICE_SECABS_V10";
	public static final String SP_GET_SECABS_SUMMARY = "SUMMARY_SECABS_V10";
	public static final String SP_GET_SECABS_CORPS_SUMMARY = "CORP_SECABS_V10";
	public static final String SP_ADD_DIR_ENTL = "ADD_DIR_ENTL";

	public static final String SP_GET_PAPER_AUTH = "CHECK_PAPER_AUTH";
	public static final String SP_MANAGE_EM_ADDRESS = "MANAGE_EM_ADDRESS";
	public static final String SP_GET_EM_ADDRESS = "GET_EM_ADDRESS";
	public static final String SP_ACCT_EMEDIA_LIST = "ACCT_EMEDIA_LIST";
	public static final String SP_GET_EMEDIA_DOWNLOAD_SUMMARY = "SUMMARY_EMEDIA_MRG";
	public static final String SP_GET_EMEDIA_CORP_DOWNLOAD_SUMMARY = "CORP_EMEDIA_MRG";
	public static final String SP_EMEDIA_SUMMARY_DEFERRED_DOWNLOAD = "SUMM_EMEDIA_DL_V10";
	public static final String SP_EMEDIA_CORP_SUMMARY_DEFERRED_DOWNLOAD = "CORP_EMEDIA_DL_V10";
	public static final String SP_SET_PAPER_AMEND = "SET_PAPER_AMEND";
	public static final String SP_GET_BM_CFG_WAIVERS = "GET_BM_CFG_WAIVERS";
	public static final String SP_GET_BM_WAIVERS = "GET_BM_WAIVERS";
	public static final String SP_MANAGE_BM_WAIVER = "MANAGE_BM_WAIVER";
	public static final String SP_GET_BM_CONTRACT = "GET_BM_CONTRACT";
	public static final String SP_MANAGE_SVC_PROV = "MANAGE_SVC_PROV";
	public static final String SP_GENERATE_AFT_REQUEST_NO = "GEN_AFT_REQUEST_NO";
	public static final String SP_UPLOAD_AFT_INFO = "UPLOAD_AFT_INFO";
	public static final String SP_GET_AFT_INFO = "GET_AFT_INFO";
	public static final String SP_GET_AFT_DETAIL = "GET_AFT_DETAIL";
	public static final String SP_MANAGE_PAPER_FREE = "MANAGE_PAPER_FREE";
	public static final String SP_GET_VBE_SUMMARY = "SUMMARY_VBE_V11";
	public static final String SP_GET_VBE_CORP_SUMMARY = "CORP_VBE_V11";
	public static final String SP_GET_VBE_ACCTS = "GET_VBE_ACCTS";
	public static final String SP_GET_VBE_ACCTS_BY_SUBSCRIPTION = "SERVICE_VBE_V11";
	public static final String SP_SEARCH_VBE_REMIT = "SEARCH_VBE_REMIT";

	// eMedia GBR
	public static final String SP_SEARCH_GBR_PROFILE = "SEARCH_GBR_PROFILE";
	public static final String SP_MANAGE_GBR_PROFILE = "MANAGE_GBR_PROFILE";
	public static final String SP_GET_GBR_PROFILE = "GET_GBR_PROFILE";
	public static final String SP_GENERATE_GBR_CONFIG_ID = "GENERATE_GBR";
	public static final String SP_GET_GBR_ORG = "GET_GBR_ORG";
	public static final String SP_MANAGE_GBR_ORG = "MANAGE_GBR_ORG";
	public static final String SP_GET_SMP_CONTRACTS = "GET_SMP_CONTRACTS";
	public static final String SP_GET_STRUCTURE_INFO = "GET_STRUCTURE_INFO";

	// EMedia Edit and Msg
	public static final String EMEDIA_EDIT_BEAN_NAME = "eMediaEdit";
	public static final String EMEDIA_MSG_BEAN_NAME = "eMediaMsg";
	public static final String EMEDIA_CUSTOMER_BEAN_NAME = "eMediaCustomer";
	public static final String DB_ADMIN_BEAN_NAME = "dbAdmin";
	public static final String DB_ADMIN_EXCEL_TRANS_BEAN_NAME = "dbadminExcel";

	public static final String CONFIG_SUBS_OID = "CONFIG_SUBS_OID";

	public static final String ROW_COUNT = "ROW_COUNT";

	// Admin permissions
	public static final String ADMIN_PERMISSIONS_BEAN_NAME = "adminPermissions";

	// GBR
	public static final String GBR_BEAN_NAME = "gbr";

	// Stored Procedure Parameters Types and Data Types Variable
	public static final String SP_PARAMETER_TYPE_IN = "IN";
	public static final String SP_PARAMETER_TYPE_OUT = "OUT";
	public static final String SP_PARAMETER_TYPE_INOUT = "INOUT";
	public static final String SP_PARAMETER_TYPE_RESULTSET = "RESULTSET";

	// Dummy Data Types Variables for the return datatype ResultSet not
	// available in java.sql.Types
	// This dummy variable does not conflict with any of the variables in JDK
	// 1.3

	public static final int DATA_TYPE_RESULTSET = 999;

	// Values coming from Config
	public static final String ONE_VIEW_WS_URL_IDENTIFIER = "verizon.ncasbosi.billInquiry.oneView.oneViewWSURL";
	public static final String ITW_USERID = "verizon.ncasbosi.ITWUserId";
	public static final String ITW_PASSWORD = "verizon.ncasbosi.ITWPassword";

	// IPOP WS Config Details - added by v898809 - 2011 Jan Rel
	public static final String IPOP_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.ipop.ipopWSURL";
	public static final String IPOP_WS_USERID = "verizon.ncasbosi.IPOPWSUserId";
	public static final String IPOP_WS_PASSWORD = "verizon.ncasbosi.IPOPWSPassword";
	public static final String EXECUTE_WS_IPOP = "verizon.ncasbosi.vbif.ipop.executeWS";

	// IntradaPro WS Config Details - 2011 Jan Rel
  public static final String INTRADAPRO_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.intradaPro.intradaProWSURL";
	public static final String EXECUTE_WS_INTRADA = "verizon.ncasbosi.vbif.intradaPro.executeWS";

	// Items WS Config Details - 2011 Jan Rel
	public static final String ITEMS_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.items.itemsWSURL";
	public static final String EXECUTE_WS_ITEMS = "verizon.ncasbosi.vbif.items.executeWS";

	// AR2K WS Config Details - added by v898809
	public static final String AR2K_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.ar2k.ar2kWSURL";

	// IAD WS Config Details - added by v898809
	public static final String IAD_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.iad.iadWSURL";
	
	// VPRICE WS CONFIG DETAILS - added by v523043
	public static final String VPRICE_WS_URL_IDENTIFIER = "verizon.ncasbosi.billInquiry.vPriceWS.url";		
		
	// CRIT WS Config Details - added by v898809
	public static final String CRIT_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.crit.critWSURL";
	public static final String CRIT_WS_CONTRACT_URL_IDENTIFIER = "verizon.ncasbosi.vbif.critExtPrtl.critExtPrtlWSURL";

	// nasplookup WS - VBE April 2012 Release
	public static final String NASPLOOKUP_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.nasplookup.nasplookupWSURL";
	// revloclookup WS - VBE April 2012 Release
	public static final String REVLOCLOOKUP_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.revloclookup.revloclookupWSURL";
	public static final String VBE_ITW_USERID = "verizon.ncasbosi.VBEITWUserId";
	public static final String VBE_ITW_PASSWORD = "verizon.ncasbosi.VBEITWPassword";

	// OnestopAddressValidation WS - Feb 2012 Release - added by v915678
	public static final String ONESTOP_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.onestop.onestopWSURL";

	// BITS WS Config Details - Aug Release - added by v898809
	public static final String BITS_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.bits.bitsWSURL";

	// COMMS WS Config Details - added by v898809
	public static final String COMMS_WS_URL_IDENTIFIER = "verizon.ncasbosi.vbif.comms.commsWSURL";

	public static final String EMEDIA_DEUBG_LEVEL = "verizon.ncasbosi.emedia.debugLevel";

	public static final String BILL_VIEW_DEUBG_LEVEL = "verizon.ncasbosi.billView.debugLevel";

	// StatAndSched Stored Procedure related constants..........
	public static final String SP_ADD_ACCT_LIST = "ADD_ACCT_LIST";
	public static final String SP_GET_ACCT_LIST = "GET_ACCT_LIST";
	public static final String SP_GET_NAMED_AC_LISTS = "GET_NAMED_AC_LISTS";
	public static final String SP_DELETE_ACCT_LIST = "DELETE_ACCT_LIST";
	public static final String SP_REQUEST_REPORT_DL = "REQUEST_REPORT_DL";
	public static final String SP_GET_RPT_STATUSES = "GET_RPT_STATUSES";
	public static final String SP_GET_USER_RPT_SCHED = "GET_USER_RPT_SCHED";
	public static final String SP_UPDT_SCHEDULED_RPT = "UPDT_SCHEDULED_RPT";
	public static final String SP_GET_SCHEDULED_RPTS = "GET_SCHEDULED_RPTS";
	public static final String SP_SUMM_ACCT_LIST_V63 = "SUMM_ACCT_LIST_V63	";
	public static final String STATUS_BEAN_NAME = "statandsched";

	// Added new Constants for IBI
	public static final String IBIVAM_BEAN_NAME = "billinquiryvam";

	public static final String SP_BILL_ADDRESS = "ACCOUNT_ADDRESS";

	public static final String SP_GET_IBI_CATEGORY = VAC_SCHEMA_NAME + "." + "GET_BI_CATEGORY";

	public static final String SP_GET_IBI_DROPDOWN = VAC_SCHEMA_NAME + "." + "GET_IBI_DROP_DOWN";

	public static final String SP_GET_INT_BIL_INQ = VAC_SCHEMA_NAME + "." + "GET_INT_BIL_INQ";

	public static final String SP_CREATE_INT_BIL_INQ = VAC_SCHEMA_NAME + "." + "CREATE_INT_BIL_INQ";

	public static final String SP_SEARCH_BILL_INQ_DL = BOSIConfig.getProperty(VAM_SCHEMA_NAME) + "." + "SEARCH_BILL_INQ_DL";

	// Added new Constants for AFT END
	public static final String PORTAL_LINKS_BEAN_NAME = "portalLinks";
	public static final String PORTAL_LINKS_ECP_BEAN_NAME = "portalLinksECP";
	public static final String PAYMENTS_ECP_BEAN_NAME = "paymentsECP";

	// Added for AutoCredit
	public static final String Get_AUDITOR_DTL_By_VZID = "VZID_ONLY";
	public static final String Get_AUDITOR_DTL_By_SERVICE_CENTER = "SER_CENTER_ONLY";
	public static final String Get_AUDITOR_DTL_ALL = "ALL";

 // if userid is not found from Config file ,use the default value as USSLBMG
	public static final String VAM_USER_ID = BOSIConfig.getProperty("verizon.ebosi.bill.vam.userid", "USSLBMG");

	public static final String VAM_DEBUG_LEVEL = NCASBOSIConfig.getProperty("verizon.ncasbosi.vam.debugLevel");

	public static final String AUTO_CREDIT_BEAN_NAME = "autocredit";// id used in ncasbosi-springcontext.xml

	public static final String HISTORICAL_INVOICE_BEAN_NAME = "historicalinvoice";// id used in ncasbosi-springcontext.xml

	public static final String BRI_NETWORX_BEAN_NAME = "brinetworx";// id used in ncasbosi-springcontext.xml

	public static final String USAGE_REPOSITORY_BEAN_NAME = "usagerepository"; // id used in ncasbosi-springcontext.xml

	public static final String SP_CREATE_VZB_CLAIM = VAC_SCHEMA_NAME + "." + "CREATE_VZB_CLAIM";

	public static final String SP_GET_VZB_CLAIM = VAC_SCHEMA_NAME + "." + "GET_VZB_CLAIM";

	public static final String SP_GET_DUPE_CLAIMS = VAC_SCHEMA_NAME + "." + "GET_DUP_CLAIMS";

	public static final String SP_UPDATE_AC_CLAIM = VAC_SCHEMA_NAME + "." + "UPDATE_AC_CLAIM";

	public static final String SP_SEARCH_AC_CLAIMS = VAC_SCHEMA_NAME + "." + "SEARCH_AC_CLAIMS";

	public static final String SP_GET_DROP_DOWNS = VAC_SCHEMA_NAME + "." + "GET_DROP_DOWNS";

	public static final String SP_GET_ACT_DROP_DOWNS = VAC_SCHEMA_NAME + "." + "GET_ACT_DROP_DOWNS";

	public static final String SP_GET_CAUSE_RTCAUSE = VAC_SCHEMA_NAME + "." + "GET_CAUSE_RTCAUSE";

	public static final String SP_GET_ADJ_RSN_SUBCAT = VAC_SCHEMA_NAME + "." + "GET_ADJ_RSN_SUBCAT";

	public static final String SP_GET_SVC_TYPE_DD = VAC_SCHEMA_NAME + "." + "GET_SVC_TYPE_DD";

	public static final String SP_GET_VZB_ADJS = VAC_SCHEMA_NAME + "." + "GET_VZB_ADJS";

	public static final String SP_RETARGET_VZB_ADJ = VAC_SCHEMA_NAME + "." + "RETARGET_VZB_ADJ";

    public static final String SP_GET_CAN_DATES = BOSIConfig.getProperty(VAM_SCHEMA_NAME) + "." + "GET_CAN_DATES"; // VAM
    public static final String SP_GET_MAN_BAN_DATES = BOSIConfig.getProperty(VAM_SCHEMA_NAME) + "." + "GET_MAN_BAN_DATES"; // VAM
																																																									// api

	public static final String SP_GET_DUP_SVC_ID = "GET_DUP_SVC_ID";

	public static final String SP_GET_SERVICE_IDS = "GET_SERVICE_IDS";

	public static final String SP_GET_BILL_ELEMENTS = "GET_BILL_ELEMENTS";
	public static final String SP_GET_ACT_USAGE = "GET_ACT_USAGE";

	public static final String SP_GET_LPCS = "GET_LPCS"; // get late payment charges - gets late payment charges in
																												// invoices, used by autocredit tool.
	public static final String SP_GET_TAX_CALC_INFO = "GET_TAX_CALC_INFO"; // get tax calculation info - adds taxes
																																					// assoiated with billing elements for the
																																					// autocredit tool.

	public static final String SP_GET_CALC_DETAIL = "GET_CALC_DETAIL";
	public static final String SP_GET_INT_CALC_DTL = "GET_INT_CALC_DTL";
	public static final String SP_CALC_LATEDISC_ADJS = "CALC_LATEDISC_ADJS"; // calculate latedisconnect adjustments -
																																						// used on calcwiz to calculate
																																						// non-persisted billing elements into
																																						// adjustments

	public static final String SP_UPDATE_VZB_ADJ = "UPDATE_VZB_ADJ";
	public static final String SP_GET_AR_SYSTEM = VAC_SCHEMA_NAME + "." + "GET_AR_SYSTEM";
	public static final String SP_GET_ACT_CATEGORIES = VAC_SCHEMA_NAME + "." + "GET_ACT_CATEGORIES";
	public static final String SP_GET_AUDITOR_DETAILS = VAC_SCHEMA_NAME + "." + "GET_AUDITOR_DTL";
	public static final String SP_UPDATE_AUDITOR_DETAILS = VAC_SCHEMA_NAME + "." + "UPD_AUDITOR_DTL";
	public static final String SP_CLEANUP_CALC_DTL = VAC_SCHEMA_NAME + "." + "CLEANUP_CALC_DTL"; // cleanup calc detail -
																																																// deletes persisted
																																																// work-in-progress
																																																// billelements
	public static final String SP_UPDATE_CALC_DTL = VAC_SCHEMA_NAME + "." + "UPDATE_CALC_DTL"; // update calculation
																																															// detail - updates a
																																															// persisted be
	public static final String SP_CALC_ACT_ADJS = "CALC_ACT_ADJS"; // calculate autocredit tool adjustments - used for
																																	// persisted be's
	public static final String SP_CREATE_CALC_DTL = VAC_SCHEMA_NAME + "." + "CREATE_CALC_DTL"; // create calculation
																																															// detail - persists
																																															// billelements from vam

  //get autocredit tool taxes - gets billingelements for the tax exempt credits
	public static final String SP_GET_ACT_TAXES = BOSIConfig.getProperty(VAM_SCHEMA_NAME) + "." + "GET_ACT_TAXES";

	public static final String SP_VALIDATE_NASP_ID = VAC_SCHEMA_NAME + "." + "VALIDATE_NASP_ID";
	public static final String SP_GET_DUP_ADJ_DTLS = VAC_SCHEMA_NAME + "." + "GET_DUP_ADJ_DTLS";
	public static final String SP_VALIDATE_RevLoc = BOSIConfig.getProperty(VAM_SCHEMA_NAME) + "." + "VALIDATE_RevLoc";//Added by v191876

	// Ibi for emea weservices. added by anand august 25 2008

	public static final String VAC_PUBLIC = "1";
	public static final String VAC_PRIVATE = "2";

	public static final String EMEA_WS_URL = "verizon.ncasbosi.ws_emea_url.emea_url";
	public static final String EPAY_WS_URL = "verizon.ncasbosi.ws_epay_url.epay_url";

	// Epayment WebServices
	public static final String CREDITCARD_WS_URL = "verizon.ncasbosi.payments.cc_epay_url";
	public static final String PAYMENT_WS_URL = "verizon.ncasbosi.payments.pay_epay_url";
	public static final String GCP_PAYMENT_WS_URL = "verizon.ncasbosi.payments.gcp_pay_epay_url";

	// WirelessRealTimeBalance
	public static final String WIRELESS_REL_USERID = "verizon.ncasbosi.payments.vision_realtime_userid";
	public static final String WIRELESS_REL_PASSWORD = "verizon.ncasbosi.payments.vision_realtime_password";
	public static final String EPAY_VISION_REAL_BALANCE_URL = "verizon.ncasbosi.payments.vision_real_time_balance_url";

	public static final String COMP_ECP_XLS = "compareBean";

	// getPaymentHistoryURL
	public static final String PAYMENT_HISTORY_URL = "verizon.ncasbosi.payments.paymenthistory_url";

	// generic gcp group email
	public static final String GENERIC_GROUP_EMAIL_ADDR_FOR_GCP = "verizon.ncasbosi.payments.gcp_generic_email";

	public static final String ONEVIEW_WS_URL = "verizon.ncasbosi.ws_oneview_url.oneview_url";
	public static final String ONEVIEW_SSL_PATH = "verizon.ncasbosi.ssl_oneview_path.cert_path";

	public static final String VAC_DROP_DOWNS_BEAN_NAME = "vacDropDowns";// id use in ncasbosi-springcontext.xml

	public static final String PAYMENTS_BEAN_NAME = "payments";
	public static final String PAYMENTS_UI_BEAN_NAME = "paymentsUI";
	public static final String PAYMENTS_VZB_BEAN_NAME = "paymentsVZB";
	public static final String PAYMENTS_VZW_BEAN_NAME = "paymentsVZW";
	public static final String PAYMENTS_BATCH_BEAN_NAME = "paymentsBatch";

	public static final String EMAIL_LOG_BEAN_NAME = "emailLog";

	public static final String INTERNATIONAL_BEAN_NAME = "international";

	public static final String VBIF_BEAN_NAME = "vbif";
	public static final String VBIF_BEAN_WITH_TXN = "vbifProxyWithTxn";

	// VAC Adjustments/Claim API
	public static final String ADJUSTMENTS_BEAN_NAME = "adjustments";

	public static final String SP_CREATE_PORTAL_ADJ = "CREATE_PORTAL_ADJ";
	public static final String SP_GET_ADJ_BY_STATUS = "GET_ADJ_BY_STATUS";
	public static final String SP_GET_REP_CLAIM_LIST = "GET_REP_CLAIM_LIST";
	public static final String SP_DELETE_ADJUSTMENTS = "DELETE_ADJUSTMENTS";
	public static final String SP_ADJUSTMENTS_DETAILS = "GET_ADJ_DETAILS";
	public static final String SP_GET_REASON_CODE = "GET_REASON_CODE";
	public static final String SP_GET_ADJUSTMENT_BY_ID = "GET_ADJ_BY_ID";
	public static final String SP_UPDATE_ADJUSTMENT = "UPDATE_ADJUSTMENT";
	public static final String SP_UPDATE_ADJUSTMENT_DETAILS = "UPDATE_ADJ_DTLS";
	public static final String SP_UPDATE_ADJUSTMENT_TAXES = "UPDATE_ADJ_TAXES";
	public static final String SP_UPDATE_ADJUSTMENT_INTEREST = "UPDATE_ADJ_INT";
	public static final String SP_SUBMIT_ADJUSTMENT = "SUBMIT_ADJUSTMENT";
	public static final String SP_GET_TAX_DETAILS = "GET_TAX_DETAILS";
	public static final String SP_CLAIM_CALCULATE_INTEREST = "CLM_CALC_INTEREST";
	public static final String SP_DELETE_TRANSACTION = "DELETE_TRANSACTION";
	public static final String SP_UPDATE_INT_RATE = "UPDATE_INT_RATE";
	public static final String SP_UPDATE_CLAIM = "UPDATE_CLAIM";

	public static final String SP_SAVE_CUSTOM_TAG_DIGEX = "SAVE_TAGS";

	// NBBE Tax Engine API
	// public static final String SP_GET_NBBE_TAX_INFO = "XETX_TAXADJ_SP1";
	// public static final String SP_GET_NBBE_TAX_INFO =
	// BOSIConfig.getProperty("verizon.ebosi.bill.nbbetaxengine.nbbeTaxSPName", "XETX_TAXADJ_SP1");

	// Batch Processor
	public static final String BATCH_BEAN_NAME = "batchrequest";
	// BillManager
	public static final String SP_GET_EMEDIA_LIST = "GET_EMEDIA_LIST";
	public static final String EMEDIA_BEAN_NAME = "emedialist";
	// Payments

	public static final String VZB_VZW_FLAG_VZB = "B";
	public static final String VZB_VZW_FLAG_VZW = "W";
	public static final String VZB_VZW_FLAG_BOTH = "BW";
	public static final String PLACEHOLDER = "*";
	public static final String CREDIT_CARD_MASK_FORMAT = "xxxxxxxxxx****";
	public static final String BANK_ACCT_MASK_FORMAT = "**xxxxxxx**";

	public static final String CREDIT_CARD_PAYMENT_TYPE = "C";
	public static final String BANK_EFT_PAYMENT_TYPE = "B";
	public static final String INTL_PAYMENT_TYPE = "IB";

	public static final String PAYMENTS_EMAIL_ADDRESS = "verizon.ncasbosi.payments.pmnts_generic_email";
	public static final String DEFAULT_PAYMENTS_EMAIL_ADDRESS = "paymentIssues@lists.verizonbusiness.com";

	public static final String REPORTS_EMAIL_ADDRESS = "BILL_RPT_MONITOR_DISTRO";
	public static final String DEFAULT_REPORTS_EMAIL_ADDRESS = "reportIssues@lists.verizonbusiness.com";

	public static final String ALL_ONETIME_PMNTS_TEMPLATE_VZB = "ALL_ONETIME_PMNTS_TEMPLATE_VZB";
	public static final String ALL_REC_FAILURES_TEMPLATE_VZB = "ALL_REC_FAILURES_TEMPLATE_VZB";
	public static final String REC_PMNT_CHANGES_TEMPLATE_VZB = "REC_PMNT_CHANGES_TEMPLATE_VZB";
	public static final String REC_PMNT_CHANGES_TEMPLATE_VZW = "REC_PMNT_CHANGES_TEMPLATE_VZW";
	public static final String REC_PMNT_NOTIF_TEMPLATE_VZB = "REC_PMNT_NOTIF_TEMPLATE_VZB";
	public static final String REC_PMNT_NOTIF_TEMPLATE_VZW = "REC_PMNT_NOTIF_TEMPLATE_VZW";
	public static final String REC_PMNT_DELETE_TEMPLATE_VZB = "REC_PMNT_DELETE_TEMPLATE_VZB";
	public static final String REC_PMNT_DELETE_TEMPLATE_VZW = "REC_PMNT_DELETE_TEMPLATE_VZW";
	public static final String CC_EXP_TEMPLATE = "CC_EXP_TEMPLATE";
	public static final String REC_PMNT_SETUP_FAILURE_TEMPLATE_VZW = "REC_PMNT_SETUP_FAILURE_TEMPLATE_VZW";
	public static final String REC_PMNT_EXCEEDS_TEMPLATE_VZB = "REC_PMNT_EXCEEDS_TEMPLATE_VZB";
	public static final String REC_PMNT_EXCEEDS_TEMPLATE_VZW = "REC_PMNT_EXCEEDS_TEMPLATE_VZW";
	public static final String REC_PMNT_APP_ERROR_TEMPLATE_VZW = "REC_PMNT_APP_ERROR_TEMPLATE_VZW";
	public static final String ALL_ONETIME_PMNTS_TEMPLATE_GCP = "ALL_ONETIME_PMNTS_TEMPLATE_GCP";

	//  for recur reversal enhancements
	public static final String STATUS_REVERSAL_EMAIL_NOTIF_TEMPLATE="STATUS_REVERSAL_EMAIL_NOTIF_TEMPLATE";
	public static final String REVERSAL_EP_RESPONSE_CODES="REVERSAL_EP_RESPONSE_CODES";
	public static final String STATUS_REVERSAL_PROFILE_ERR_DESC="Cancelled owing to reversal on ";

	public static final String ONETIME_PMNT_FAIL_TEMPLATE_VZW = "ONETIME_PMNT_FAIL_TEMPLATE_VZW";
	public static final String ONETIME_PMNT_SUCCESS_TEMPLATE_VZW = "ONETIME_PMNT_SUCCESS_TEMPLATE_VZW";

	public static final String PORTAL_BILLING_NOTIF_TEMPLATE = "PORTAL_BILLING_NOTIF_TEMPLATE";

	public static final int MANAGE_PAYMENTS_PAGE_ID = 440;

	public static final double VZW_ONETIME_ECPDID = -1.;
	public static final double VZW_RECUR_ECPDID = -2.;

	public static final String SP_IS_USER_ELIGABLE = "IS_USER_ELIGABLE";
	public static final String SP_GET_NEXT_INV_DATE = "GET_NEXT_INV_DATE";
	public static final String SP_GET_REAL_TIME_BALANCE = "GET_RT_BALANCE";

	//SP lv2lv3
	public static final String SP_GET_LV2_LV3_DATA = "BMGPAYTAX";

	public static final String SP_BACKGRD_MOVE_CLIS = "BACKGRD_MOVE_CLIS";

	// BillManager
	public static final String MEDIA_DOWNLOAD_BEAN_NAME = "mediadownload";

	public static final String BQA_ASYNC_QUEUE = "BQAConsumerQueue";
	public static final String INITIAL_CONTEXT_FACTORY = BOSIConfig.getProperty("verizon.ebosi.jndi.initialContextFactory", null);

	// payment and memo bill distribution
	public static final String PAYMENT_EMAIL_BEAN = "paymentsemaildetails";
	public static final String EMAIL_STATUS_EXCEPTION = "java.sql.SQLSyntaxErrorException";
	// Bill Reprints
	public static final String SUM_REPRINT_REQ = "reprintbean";
	public static final String SUM_REPRINT_REQ_VSSI = "reprintbeanvssi";
	static public final String SP_EXA_NSB_REP_REQ = "EXA_NSB_REP_REQ";
	static public final String SP_EXA_VSSI_REP_REQ = "VGWD900";
	public static final String APP_USER_ID = "ESGDBH7";
	public static final int NULL_INT = 0x80000000;
	static public String datasource = BOSIConfig.getProperty("verizon.ebosi.bill.reprint.datasource", "");
	static public final String EXA_REPRINT_REQ = "EXA_REPRINT_REQ";
	static public String schemaName = BOSIConfig.getProperty("verizon.ebosi.bill.reprint.schema", "");

	public static final String SP_RETRIEVE_ARCHIVED_BILL = "RETR_REQ";

	public static final String VUAUI_BEAN_NAME = "vuaui";
	public static final String VUA_STRUCT_TYPE = "ID";
	// DfrgMigration
	public static final String BILL_MIGRATION_BEAN_NAME = "billinquirymigrationbean";

	public static final String VBIF_SP_CREATE_TICKET = VAC_SCHEMA_NAME + "." + "CREATE_TICKET";
	public static final String VBIF_SP_UPDATE_TICKET = VAC_SCHEMA_NAME + "." + "UPDATE_TICKET";
	public static final String VBIF_SP_GET_TICKET = VAC_SCHEMA_NAME + "." + "GET_TICKET";
	public static final String VBIF_SP_SEARCH_CONTACT = VAC_SCHEMA_NAME + "." + "SEARCH_CONTACT";
	public static final String VBIF_SP_SEARCH_TICKETS = VAC_SCHEMA_NAME + "." + "SEARCH_TICKETS";
	public static final String VBIF_SP_ADD_NOTE = VAC_SCHEMA_NAME + "." + "ADD_NOTE";
	public static final String VBIF_SP_GET_NOTES = VAC_SCHEMA_NAME + "." + "GET_NOTES";
	public static final String VBIF_SP_GET_AUDIT_TKT = VAC_SCHEMA_NAME + "." + "GET_AUDIT_TKT";
	public static final String VBIF_SP_GET_TKT_DROP_DOWNS = VAC_SCHEMA_NAME + "." + "GET_TKT_DROP_DOWN";
	public static final String VBIF_SP_GET_ICI_DROP_DOWNS = VAC_SCHEMA_NAME + "." + "GET_ICI_DROP_DOWNS";
	public static final String VBIF_SP_CREATE_SVCID = VAC_SCHEMA_NAME + "." + "CREATE_SVCID";
	public static final String VBIF_SP_GET_SVCID = VAC_SCHEMA_NAME + "." + "GET_SVCID";
	public static final String VBIF_SP_GET_ALL_SVCID = VAC_SCHEMA_NAME + "." + "GET_ALL_SVCID";
	public static final String VBIF_SP_UPDATE_SVCID = VAC_SCHEMA_NAME + "." + "UPDATE_SVCID";
	public static final String VBIF_SP_CREATE_CONTRACT = VAC_SCHEMA_NAME + "." + "CREATE_CONTRACT";
	public static final String VBIF_SP_GET_MASTER_CONTRACT = VAC_SCHEMA_NAME + "." + "GET_MASTER_CONTRACT";
	public static final String VBIF_SP_GET_CONTRACT = VAC_SCHEMA_NAME + "." + "GET_CONTRACT";
	public static final String VBIF_SP_UPDATE_CONTRACT = VAC_SCHEMA_NAME + "." + "UPDATE_CONTRACT";
	public static final String VBIF_SP_GET_BITS_TICKET = VAC_SCHEMA_NAME + "." + "GET_BITS_TICKET";
	public static final String VBIF_SP_GET_BATCH_DATA = VAC_SCHEMA_NAME + "." + "GET_BATCH_DATA";
	public static final String VBIF_SP_GET_REFUND = VAC_SCHEMA_NAME + "." + "GET_REFUND";
	public static final String VBIF_SP_UPDATE_REFUND = VAC_SCHEMA_NAME + "." + "UPDATE_REFUND";
	public static final String VBIF_SP_UPDATE_ADMIN = VAC_SCHEMA_NAME + "." + "VAC_ADMIN_UPDATE";
	public static final String VBIF_SP_GET_ICI_ADJ_DATA = VAC_SCHEMA_NAME + "." + "GET_ICI_ADJ_DATA";
    public static final String VBIF_ADD_EMAIL = VAC_SCHEMA_NAME+"."+"ADD_EMAIL";
    public static final String VBIF_ADD_ATTACHMENT = VAC_SCHEMA_NAME+"."+"ADD_ATTACHMENT";
    public static final String VBIF_SP_GET_FOLLOWUP = VAC_SCHEMA_NAME+"."+"GET_FOLLOWUP";//Aug2012. iCI Follow-up/Tickler
    public static final String VBIF_SP_UPDATE_FOLLOWUP = VAC_SCHEMA_NAME+"."+"UPDATE_FOLLOWUP";//Aug2012

	public static final String INTERNATIONAL_EXCEPTION_950 = "IE950";

	public static final String LANG_CODE_ENGLISH = "en-US";
	// BugTracker
	public static final String SP_GET_BUG_TRACKER = "BUG_TRACK_PROCESS";
	public static final String BUG_TRACKER_BEAN_NAME = "Bugdata";

	public static final String SP_GET_NASP_ID = VAC_SCHEMA_NAME + "." + "GET_NASP_ID";
	public static final String PERFORMANCE_TRACKER_BEAN_NAME = "PERFORMANCE_TRACK";

	public static final String REPORTS_UI_BEAN_NAME = "reportsUI";
	public static final String REPORTS_BATCH_BEAN_NAME = "reportsBatchBean";

	// SP's for Wireless Custom Reports
	public static final String SP_CUST_PAGE_ID = "CUST_PAGE_ID";
	public static final String SP_CUST_FILTER_INFO = "CUST_FILTER_INFO";
	public static final String SP_SAVE_CUST_FILTERS = "SAVE_CUST_FILTERS";
	public static final String SP_DELETE_CUST_RPT = "DELETE_CUST_RPT";

	// Domain Constants.

	public static final String BOSI_DOMAIN = "BOSI";
	public static final String VBCIBR_DOMAIN = "VBCIBR";
	public static final String VBCCIBR_DOMAIN = "VBCCIBR";
	public static final String LOG_PATH = "\\config\\ncasbosi\\log.properties";
	// SystemParam
	public static final String SYSTEM_PARAM_BEAN_NAME = "SystemParamBean";
	// Auto Rem
	public static final String AUTO_REM_BATCH_BEAN = "autoRemBatchBean";
	public static final String PAY_ONETIME_VW = "MAKE WIRELESS ONE TIME PAYMENT";
	public static final String PAY_RECUR_VW = "SETUP WIRELESS RECURRING PAYMENT";
	public static final String PAY_RECUR_UPD_VW = "EDIT/CANCEL WIRELESS RECURRING PAYMENTS";
	public static final String PFB_PAPERLESS_VW = "SET PAPERLESS";
	public static final String PFB_PAPER_VW = "SET PAPER BILL";
	public static final String DEFAULT_CONTACT_METHOD = "IN";
	public static final String DEFAULT_REMARK_TYPE = "F1";
	public static final String DEFAULT_BILL_ACCT_TYPE = "C";
	public static final String REMARK_LEVEL_FOR_ACCT = "A";
	public static final String REMARK_LEVEL_FOR_MTN = "M";

	public static final String GET_STRUCTURE_INFO_BEAN = "getStructureInfoBean";

	// Tickets
	public static final String TICKETS_UI_BEAN_NAME = "Ticket";
	public static final String EMAIL_UI_BEAN_NAME = "Email";

	// Exception Error Codes
	public static final String ERROR_VAM = "VM1001";
	public static final String DUPLICATE_VAM = "VM1002";
	public static final String USER_CFG_ERROR = "EM1001";
	public static final String BILLING_EXCEPTION_850 = "BI850";
	public static final String BILLING_EXCEPTION_860 = "BI860";
	public static final String BILLING_EPAY_PRE = "BI870";
	public static final String BILLING_EPAY_POST = "BI880";
	public static final String DB_ADMIN_EXCEPTION_950 = "DA950";
	public static final String MEMO_BILL_EXCEPTION_950 = "MB950";
	public static final String PAYMENT_EXCEPTION_950 = "PE950";
	public static final String EPAYMENT_ERROR_PROFILE = "EP001";
	public static final String EPAYMENT_ERROR_PAY = "EP002";
	public static final String VISION_RT_BALANCE = "EP003";
	public static final String EPAYMENT_ERROR_CONNECT = "EP004";
	public static final String VISION_PAY_HISTORY = "EP005";
	public static final String REPORT_EXCEPTION_950 = "RP950";

	public static final String ERROR_VAC = "VAC001";

	// Adjustments [OCC Misc. and Misc.]
	static public final String EPS_SCHEMA_NAME = BOSIConfig.getProperty("verizon.ebosi.bill.eps.schema","");
	static public String EPS_DATASOURCE = BOSIConfig.getProperty("verizon.ebosi.bill.eps.datasource","");
	static public String DELIMITER = "~";
	static public final String SSB_INVOICE  ="I";
	static public final String VAM_WTN      ="WTN";
	static public final String VAM_CKT      ="CKT";
	static public final String VAM_ABAN     ="ABN";
	static public final String BM_MTN="M";
	static public final String BM_BTN="B";
	static public final int SQLCODE_RESOURCE_BUSY = -913;
	static public final String SPACESTR=" ";
	static public final long   NULL_LONG   = 0x8000000000000000L;
	static public int NO_DATA_FOUND = 100;
	static public int RC_NO_DATA_FOUND = 8;
	static public final String ERROR_BOSI_INVALID_CURSOR = "BE0002";
	static public final String BMSQLERR = "BE1002";
	static public final String BMGENERALERR  = "BE1003";
	static public final String ERROR_BOSI_INVALID_COLUMN_NAME = "BE0006";
	static public final String ERROR_BOSI_CONVERT_DOC_TO_XML = "BE0007";
	static public final String ERROR_BOSI_CONVERT_XML_TO_DOC = "BE0008";
	static public final String NULL_STRING = null;
	static public final int BOSI_PRODUCER_ID = 1400;
	static public final String GET_PRODUCT_GROUP = "{call " + VAC_SCHEMA_NAME + "." + "GET_PRODUCT_GROUP(?,?,?,?,?,?,?,?,?,?)}";
	static public final String VAM_SP_GET_DISCOUNT_PLANS = "{call " + VAM_SCHEMA + "." + "GET_DISCOUNT_PLANS(?,?,?,?,?,?,?,?,?)}";
	static public final String VAM_SP_GET_ERNY_CONTRACT = "{call " + VAM_SCHEMA + "." + "GET_ERNY_CONTRACT(?,?,?,?,?,?,?,?,?,?)}";
	static public final String VAM_SP_PROV_ADJ_LIST = "{call " + VAM_SCHEMA + "." + "PROV_ADJ_LIST(?,?,?,?,?,?,?,?,?,?,?)}";
	static public final String GET_ACC_LVL_TAX = "{call " + VAC_SCHEMA_NAME + "." + "GET_ACC_LVL_TAX(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	static public final String VAM_SP_MISC_ADJ_PARAMS = "{call " + VAM_SCHEMA + "." + "MISC_ADJ_PARAMS(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	static public final String CHECK_USOC = "{call " + VAC_SCHEMA_NAME + "." + "CHECK_USOC(?,?,?,?,?,?,?,?,?,?,?)}";
	static public final String ERATE_CAP_CHECK = "{call " + VAC_SCHEMA_NAME + "." + "ERATE_CAP_CHECK(?,?,?,?,?,?,?,?,?,?)}";
	static public final String EPS_API_CAP = "{call " + EPS_SCHEMA_NAME + "." + "SPGETUSL(?,?,?,?,?,?,?,?,?)}";
	static public final String CREATE_ICI_OCC = VAC_SCHEMA_NAME + "." + "CREATE_ICI_OCC";
	static public final String CREATE_ICI_MISCADJ = VAC_SCHEMA_NAME + "." + "CREATE_ICI_MISCADJ";
	static public final String VAM_SP_ENTITY_LOB_RPT = "{call " + VAM_SCHEMA + "." + "ENTITY_LOB_CHG_V60(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	static public final String VAM_IBILL_WTN_MRC = "GET_MRC_BY_WTN_I50";
	
	static public final String GET_PRODUCT_GROUP_V2 = VAC_SCHEMA_NAME + "." + "GET_PRODUCT_GROUP";
	static public final String GET_ACC_LVL_TAX_V2 = VAC_SCHEMA_NAME + "." + "GET_ACC_LVL_TAX";
	static public final String CHECK_USOC_V2 = VAC_SCHEMA_NAME + "." + "CHECK_USOC";
	static public final String ERATE_CAP_CHECK_V2 = VAC_SCHEMA_NAME + "." + "ERATE_CAP_CHECK";
	
	static public final String VAM_SP_GET_DISCOUNT_PLANS_V2 = VAM_SCHEMA + "." + "GET_DISCOUNT_PLANS";
	static public final String VAM_SP_GET_ERNY_CONTRACT_V2 = VAM_SCHEMA + "." + "GET_ERNY_CONTRACT";
	static public final String VAM_SP_PROV_ADJ_LIST_V2 = VAM_SCHEMA + "." + "PROV_ADJ_LIST";
	static public final String VAM_SP_MISC_ADJ_PARAMS_V2 = VAM_SCHEMA + "." + "MISC_ADJ_PARAMS";
	static public final String VAM_SP_ENTITY_LOB_RPT_V2 = VAM_SCHEMA + "." + "ENTITY_LOB_CHG_V60";	
	
	static public final String EPS_API_CAP_V2 = EPS_SCHEMA_NAME + "." + "SPGETUSL";
	
}
