package com.verizon.enterprise.ncasbosi.common;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Set;

import org.apache.log4j.Logger;
import java.sql.ResultSet;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import java.sql.SQLException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface;
import com.verizon.enterprise.ncasbosi.mdbs.BOSIJMSHelper;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.common.JMSUtility;
import com.verizon.enterprise.common.ncasbosi.beans.SystemParam;
import com.verizon.enterprise.common.util.commonUtil;

/**
 * This cache class keeps a paramMap - a map that has  system param objects stored against their name
 * {k,v} = {"PORTAL_ENV",SystemParamObject}
 * {k,v} = {"RUN_ROUTE_BALANCE",SystemParamObject}
 * 
 * Whenever a system param is updated in DB via UI,changeInAllCache() method is invoked so as to have
 * the change request is sent to all BOSI domains - so as to have cache updated at the same time across all BOSI domains
 * 
 * Whenever a new system param is inserted into DB via UI,insertInAllCache() method is invoked so as to have
 * the insert request is sent to all BOSI domains - so as to have cache updated at the same time across all BOSI domains
 *
 * This cache is refreshed on user's request.Its refreshed through UI
 * 
 * Deleting a system param is not supported.
 * 
 */
public class SystemParamDBCache extends NCASSpringJDBCBase implements SystemParamCacheInterface {
	
	private static final Logger _LOGGER = Logger.getLogger(SystemParamDBCache.class);
	
	/**
	 * it is a map of system param got from db - its a one time process done on first call.
	 * it can be cleared on user's request and can be reget from db
	 */
	private Map<String, SystemParam> paramMap = new HashMap<String, SystemParam>();

	/**
	 * Query to get the list of Configuration
	 */
	public final String GET_SYSPARMT_SQL = "SELECT PARM_NAME,PARM_VALUE,LAST_UPDATE_BY,DATE(EFFECTIVE_DATE_FROM) DATE_FROM, DATE(EFFECTIVE_DATE_TO) DATE_TO FROM "+NCASBOSIConstants.VAM_SCHEMA+".PL_SYS_PARM_T WHERE DATE(CURRENT_TIMESTAMP) BETWEEN DATE(EFFECTIVE_DATE_FROM) AND DATE(EFFECTIVE_DATE_TO)";	

	/**
	 * This objects tells that the params are loaded or not
	 */
	private ParamLoadObject paramLoad = null;
		
	public SystemParamDBCache() {
		paramLoad = this.new ParamLoadObject();
	}
	
	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#get(com.verizon.enterprise.common.ncasbosi.beans.SystemParam)
	 * This method returns the value associated with the identifier name
	 * 
	 */
	public String get(SystemParam inputParam){
		String propertyName = inputParam.getName();
        _LOGGER.info("Entering into get Method:"+propertyName);
        checkParamsLoaded();
		SystemParam systemParam = findSystemParam(inputParam);
        if(systemParam!=null){
        	synchronized(systemParam){
    			return systemParam.getValue();
    		}
        }else{
        	return null;
        }							
	}

	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#changeInAllCache(java.lang.String, java.lang.String)
	 * This method is called right after a sys param is changed in DB
	 * This method puts the change request in BOSI topic so that the request is forwarded to all the BOSI domains across cluster
	 * The idea is to have the sys param has the updated value in all the cache across cluster
	 */
	public void changeInAllCache(SystemParam sysParam){		
		try {			 
			Map<String,Object> topicMap = new HashMap<String, Object>();
			topicMap.put(NcasConstants.REQUESTED_OPERATION, NcasConstants.CHANGE_VALUE_SYSTEM_PARAM_CACHE);
			topicMap.put(NcasConstants.MDB_KEY_OBJECT, sysParam);
			JMSUtility.processAsyncMessageToBOSITopic(topicMap);
		}catch (Exception ex){
			_LOGGER.info("Exception::"+ex);
		}	
	}
	
	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#change(com.verizon.enterprise.common.ncasbosi.beans.SystemParam)
	 * This method is called by async process (by an MDB)
	 * This method updates the value of sys param - called right after sys param is updated in DB
	 * 
	 */
	public boolean change(SystemParam inputParam){
		String propertyName = inputParam.getName();
		String value = inputParam.getValue();
		boolean validParam = false;
        _LOGGER.info("Entering into change Method:"+propertyName);
		checkParamsLoaded();
		SystemParam systemParam = findSystemParam(inputParam);
		if(systemParam!=null){
			synchronized(systemParam){
				systemParam.setValue(value);
			}
			//deliver email about property changed
			//String mailSubject = "SystemParamDBCache - property changed";
			//String mailContent = "property:"+inputParam.getName()+" value changed to "+inputParam.getValue();
			//deliverEmail(mailSubject,mailContent);
			validParam = true;
		}		
		return validParam;
	}
	
	/**
	 * @param d1
	 * @param d2
	 * @return
	 * This method compares dates for equality(checks year,month,day)
	 */
	private boolean compareDates(Date d1, Date d2){		
		if(d1!=null && d2!=null){
			Calendar cal1 = new GregorianCalendar();
			Calendar cal2 = new GregorianCalendar();			
			cal1.setTime(d1);
			cal2.setTime(d2);
			int day1 = cal1.get(Calendar.DAY_OF_MONTH);
			int day2 = cal2.get(Calendar.DAY_OF_MONTH);
			int month1 = cal1.get(Calendar.MONTH)+1;
			int month2 = cal2.get(Calendar.MONTH)+1;
			int year1 = cal1.get(Calendar.YEAR);
			int year2 = cal2.get(Calendar.YEAR);			
			return (day1==day2 && month1==month2 && year1==year2);
		}else{
			return false;
		}
	}
		
	/**
	 * @param sysParam
	 * @return
	 * This method checks the from & to dates of a sys param are valid to have the param cached.
	 * This is now done on inserting a sys param at run-time via UI 
	 */
	private boolean checkValidDates(SystemParam sysParam){
		String frmDate = sysParam.getEffectiveDatefrom();
		String toDate = sysParam.getEffectiveDateto();
		String dtFormat = "yyyy-MM-dd";
		Date fromD = CommonUtil.getDateFromString(frmDate, dtFormat);
		Date toD = CommonUtil.getDateFromString(toDate, dtFormat);
		Date currD = new Date();
		return (compareDates(fromD, currD) ||  fromD.before(currD)) && (compareDates(toD, currD) || currD.before(toD));
	}
		
	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#insertInAllCache(com.verizon.enterprise.common.ncasbosi.beans.SystemParam)
	 * This method is called right after a sys param is added in DB
	 * This method puts the insert request in BOSI topic so that the request is forwarded to all the BOSI domains across cluster
	 * The idea is to add a sys param in all the cache across cluster
	 */
	public void insertInAllCache(SystemParam sysParam) {
		if(checkValidDates(sysParam)){
		try {			 
			Map<String,Object> topicMap = new HashMap<String, Object>();
			topicMap.put(NcasConstants.REQUESTED_OPERATION, NcasConstants.INSERT_SYSTEM_PARAM_CACHE);
			topicMap.put(NcasConstants.MDB_KEY_OBJECT, sysParam);
			JMSUtility.processAsyncMessageToBOSITopic(topicMap);
		}catch (Exception ex){
			_LOGGER.info("Exception::"+ex);
		}	
	}
	}
	
	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#insert(com.verizon.enterprise.common.ncasbosi.beans.SystemParam)
	 * This method inserts a new sys param - called right after a new sys param is added in DB
	 */
	public void insert(SystemParam param) {
		synchronized(paramMap){
			paramMap.put(param.getName(),param);
		}
		//delivering email about property added
		//String mailSubject = "SystemParamDBCache - property added";
		//String mailContent = "property:"+param.getName()+" added with value "+param.getValue();
		//deliverEmail(mailSubject,mailContent);
	}
	
	/**
	 * @param inputParam
	 * @return SystemParam
	 * This method searches for the System param in the paramMap.
	 * If its not there,it returns null - Also email Extraordinary Gentlemen about param not found
	 * 
	 */
	private SystemParam findSystemParam(SystemParam inputParam){
		boolean foundParam = false;
		SystemParam param = null;
		synchronized(paramMap){
			param = paramMap.get(inputParam.getName());
			foundParam = (param!=null);			
		}		
		if(!foundParam){
			/*
			if(!NCASDataUtil.getFortWaynePortalInd()){//not sending emails in frontier domain
				//deliver email about sys param not found in cache
				String mailSubject = "SystemParamDBCache - property not found";
				String mailContent = "property:"+inputParam.getName() + " not found in SystemParamDBCache";
				mailContent+= "<BR> accessed at "+new Date();
				List<String> toMail = new ArrayList<String>();
				//hard-coded email addresses
				//dont change unless advised to do so 
				//if you try to get these values also from Sys param cache,you have the risk of getting StackOverflow Error one day
				//***********Remember,send this email with all hard-coded values{toAddr,subject,content - all hard-coded content}
				toMail.add("paul.boudette@verizonbusiness.com");   
				toMail.add("ramkumar.m.sethuraman@verizon.com");
				Map<String,Object> eMap = new HashMap<String, Object>();
				eMap.put(NcasConstants.EMAIL_TO_ADDR, toMail);						
				eMap.put(NcasConstants.EMAIL_SUBJECT, mailSubject + " - "+BOSIJMSHelper.ipaddr +" - Find env by IP");
				eMap.put(NcasConstants.EMAIL_MESSAGE, mailContent);
				try {
					commonUtil.sendEmail(eMap);
				} catch (Exception ex){
					_LOGGER.info("Exception-emailing::"+ex);
				}				
			}
			*/						
		}
		return param;
	}
	
	/**
	 * This method checks the flag to determine if params are loaded or not.
	 * If its not,it calls loadParams() and gets the params loaded.
	 */
	private void checkParamsLoaded(){
		boolean sendEmail = false;
		synchronized(paramLoad){
			if(paramLoad.loadedFlag==false){
				try{
					loadParams();				
					paramLoad.loadedFlag = true;
					sendEmail = true;
					_LOGGER.info("Sys params loaded");
				}catch(Exception e){
					throw new RuntimeException("Exception occurred when loading SystemParamDBCache::"+e.getCause());
				}
			}
		}
		if(sendEmail){
			String env = get(new SystemParam(NcasConstants.PORTAL_ENV,null));
			if(env!=null && (env.startsWith("UAT")||env.equalsIgnoreCase("PROD"))){
				//sending email only for uat and prod environment about cache load
				//delivering email about cache created/loaded
				//String mailSubject = "SystemParamDBCache - cache loaded";
				//String mailContent = "cache loaded at "+new Date();
				//deliverEmail(mailSubject,mailContent);
			}			
		}
	}
		
	/**
	 * This method loads sqls.
	 * 
	 */
	private void loadParams() {
		_LOGGER.info("Inside loadParams");
		Map<String,SystemParam> dbMap = (Map<String,SystemParam>)getSystemParamsFromDB();		
		if(dbMap!=null){
			synchronized(paramMap){
				paramMap.clear();
				paramMap.putAll(dbMap);
				_LOGGER.info("paramMap:"+paramMap);
			}
		}		
	}
	
	

	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#getFullObject(com.verizon.enterprise.common.ncasbosi.beans.SystemParam)
	 * This method returns the full SystemParam Object.
	 * It returns cloned version of system param
	 */
	public SystemParam getFullObject(SystemParam inputParam) {
		String propertyName = inputParam.getName();
        _LOGGER.info("Entering into getFullObject Method:"+propertyName);
        checkParamsLoaded();
		SystemParam systemParam = findSystemParam(inputParam);
        if(systemParam!=null){
        	synchronized(systemParam){
    			return (SystemParam)systemParam.clone();
    		}
        }else{
        	return null;
        }	
	}

	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#clear()
	 * This method clears the paramMap on user request
	 */
	public void clear() {
		synchronized(paramLoad){
			paramLoad.loadedFlag = false;
			synchronized(paramMap){
				paramMap.clear();
			}
		}												
		//delivering email about cache cleared
		//not needed because mail will be sent already by BOSIJMSHelper class
	}
	
	/**
	 * This objects tells that the params are loaded or not by the loadedFlag.
	 * Basically,params are loaded/refreshed(on user request) by synchronizing this object
	 * 
	 */
	private class ParamLoadObject{
		private boolean loadedFlag = false;						
	}
	
	private Object getSystemParamsFromDB() {
		_LOGGER.info("inside getSystemParams:"+GET_SYSPARMT_SQL);
		return this.vamJdbcTemplate.query(GET_SYSPARMT_SQL,new ResultSetExtractor(){
			@Override
			public Object extractData(ResultSet rs) throws SQLException,DataAccessException {
				Map<String, SystemParam> paramMap = new HashMap<String, SystemParam>();
				if(rs!=null){
					while(rs.next()){
						SystemParam sysParam = new SystemParam();
					String name = rs.getString("PARM_NAME");
					String value = rs.getString("PARM_VALUE");
						String last_updated_by = rs.getString("LAST_UPDATE_BY");
						Date effDtFrom = rs.getDate("DATE_FROM");
						Date effDtTo = rs.getDate("DATE_TO");											
						sysParam.setName(name!=null?name.trim():null);
						sysParam.setValue(value!=null?value.trim():null);
						sysParam.setEffectiveDatefrom(CommonUtil.getDisplayDateFromString(effDtFrom));
						sysParam.setEffectiveDateto(CommonUtil.getDisplayDateFromString(effDtTo));
						sysParam.setLastUpdatedBy(last_updated_by);
						paramMap.put(name, sysParam);
					}
				}				
				return paramMap;
			}
		});
	}

	
	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface#emailParams()
	 * This method emails system params based on user-request.
	 * This method creates clones of system params and email them - just to be consistent with the fact that emailing thread has what it actually sees in memory at that moment.
	 * 
	 */
	public void emailParams() {
		List<SystemParam> emailPrm = new ArrayList<SystemParam>();
		Set<String> parmKeys = null;
		synchronized(paramMap){			
			parmKeys = paramMap.keySet();
		}	
		if(parmKeys!=null){
			Iterator<String> it = parmKeys.iterator();
			while(it.hasNext()){
				String key = it.next();
				emailPrm.add(getFullObject(new SystemParam(key,null)));
			}
		}						
		deliverEmail("SystemParamDBCache - Emailing Sys Params",getEmailFormat(emailPrm));
		//make the cloned params eligible for GC after emailing is done
		emailPrm.clear();
	}
	
	private void deliverEmail(String subject, String content){
		try {			 
			Map<String,Object> eMap = new HashMap<String, Object>();
			List<String> to_list = null;
			List<String> cc_list = null;			
			
			to_list = JMSUtility.getSplittedMailList(get(new SystemParam(JMSUtility.PAUL_TEAM_TO,null)));
			//to_list.addAll(JMSUtility.getSplittedMailList(get(new SystemParam(JMSUtility.AVNEET_TEAM_TO,null))));
			cc_list = JMSUtility.getSplittedMailList(get(new SystemParam(JMSUtility.PAUL_TEAM_CC,null)));
			//cc_list.addAll(JMSUtility.getSplittedMailList(get(new SystemParam(JMSUtility.AVNEET_TEAM_CC,null))));		
			eMap.put(NcasConstants.EMAIL_TO_ADDR, to_list);
			eMap.put(NcasConstants.EMAIL_CC_ADDR, cc_list);			
			eMap.put(NcasConstants.EMAIL_SUBJECT, subject + " - "+BOSIJMSHelper.ipaddr + " - " + get(new SystemParam(NcasConstants.PORTAL_ENV,null)));
			eMap.put(NcasConstants.EMAIL_MESSAGE,content);
			commonUtil.sendEmail(eMap);
		}catch (Exception ex){
			_LOGGER.info("Exception::"+ex);
		}
	}

	@Override
	public void emailParamsInCache() {
		// TODO Auto-generated method stub
		try {			 
			Map<String,Object> topicMap = new HashMap<String, Object>();
			topicMap.put(NcasConstants.REQUESTED_OPERATION, NcasConstants.EMAIL_PARAMS);
			//topicMap.put(NcasConstants.MDB_KEY_OBJECT, sysParam);
			JMSUtility.processAsyncMessageToBOSITopic(topicMap);
		}catch (Exception ex){
			_LOGGER.info("Exception::"+ex);
		}
	}
	
	private String getEmailFormat(List<SystemParam> paramList){
		StringBuilder builder = new StringBuilder();
		builder.append("This is the snapshot of sys params available in cache at "+new Date());
		builder.append("<BR><BR>");
		Iterator<SystemParam> it = paramList.iterator();
		String _delimit = ";";
		while(it.hasNext()){
			SystemParam param = it.next();
			if(param!=null){
				builder.append(param.getName()).append("=").append(param.getValue());
				builder.append("[");
				builder.append("Eff.From=").append(param.getEffectiveDatefrom());
				builder.append(_delimit);
				builder.append("Eff.To=").append(param.getEffectiveDateto());
				builder.append("]");
				//builder.append(_comma);
				builder.append("<BR>");
			}
		}
		return builder.toString();
	}

}
