package com.verizon.enterprise.ncasbosi.common;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.PaymentsInterface;
import com.verizon.enterprise.common.ncas.payments.EmailTemplateInfo;

public class PaymentsTemplateConfig {
	private static final Logger __Logger = Logger.getLogger(PaymentsTemplateConfig.class);
	private static PaymentsTemplateConfig pmntsTemplateConfig = null;
	private static long timer = 0;
	private static PaymentsInterface paymentsImpl ;
	private  Map templateMap = null;

	public static synchronized PaymentsTemplateConfig getInstance() {
		final String METHOD_NAME = "getInstance => ";
		__Logger.info(METHOD_NAME+" Entering");
    	if(pmntsTemplateConfig==null) {
    		pmntsTemplateConfig =  new PaymentsTemplateConfig();
    		timer = System.currentTimeMillis();
    		paymentsImpl =  DAOFactory.getInstance().getPayments();
    	}
    	__Logger.info(METHOD_NAME+" Exiting");
      return pmntsTemplateConfig;
    }

	public synchronized void populateEmailTemplateDBInfo() {
		final String METHOD_NAME = "populateEmailTemplateDBInfo => ";
		__Logger.info(METHOD_NAME+" Entering");
		 templateMap =  new HashMap();
		try {
			Map retMap = paymentsImpl.selectAllEmailTemplates();
			__Logger.debug(" Payment Template map :: " + retMap);
			__Logger.info(" Payment Template map size:: " + retMap.size());
			Set set = retMap.keySet();
			Iterator iter = set.iterator();
			EmailTemplateInfo tempInfo;
			String templateName;
			while (iter.hasNext()) {
				templateName = (String)iter.next();
				tempInfo = (EmailTemplateInfo) retMap.get(templateName);
				templateMap.put(templateName, tempInfo);
			}

		} catch (Exception e) {
			__Logger.error(METHOD_NAME+" FAILED :: " +e.getMessage());
		}
    	__Logger.info(METHOD_NAME+" Exiting");
	}

	public synchronized Map<String,EmailTemplateInfo> getEmailTemplateInfo() {
		long minutes = ( System.currentTimeMillis() - timer ) / 60000;
		if(minutes >= 300) {
			if (templateMap	!= null) {				
				templateMap= null;
			}
			timer = System.currentTimeMillis();
		}
		if(templateMap == null)
			populateEmailTemplateDBInfo();

		return templateMap;
	}

}
