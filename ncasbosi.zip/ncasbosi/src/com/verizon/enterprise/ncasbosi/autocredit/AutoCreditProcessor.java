package com.verizon.enterprise.ncasbosi.autocredit;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.autocredit.AutoCreditInterface;

/*
 * Author - Ram/v992473
 * This class decides which operation to be performed
 * for the auto credit. 
 */
public class AutoCreditProcessor {
	private static AutoCreditInterface autoCreditObject;
	private static final Logger _LOGGER = Logger.getLogger(AutoCreditProcessor.class);
	
	private static synchronized AutoCreditInterface getAutoCreditObject(){
		if(autoCreditObject==null){
			_LOGGER.info("Getting the singleton AutoCredit Object");
			autoCreditObject = DAOFactory.getInstance().getAutoCreditImplementationReference();
			_LOGGER.info("Successfully retrieved handle to the AutoCredit Object");
		}
		return autoCreditObject;
	}
	
	public static Map processAutoCredit(Object input,String function)throws NCASException{
		_LOGGER.info("Entering processAutoCredit");
		Map responseMap = null;
		try{
			Method method = getAutoCreditObject().getClass().getMethod(function, new Class[]{Object.class});
			responseMap = (Map)method.invoke(getAutoCreditObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException("AC1001",AutoCreditProcessor.class,exception.getTargetException());
		}catch(Exception exception){
			throw new NCASException("AC1001",AutoCreditProcessor.class,exception);
		}
		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processAutoCredit");
		return responseMap;
	}
}
