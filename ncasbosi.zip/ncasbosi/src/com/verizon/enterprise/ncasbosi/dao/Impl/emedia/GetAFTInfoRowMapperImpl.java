package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAFTInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAFTInfoRowMapperImpl implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetAFTInfoRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetAFTInfoRowMapperImpl::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		EMediaAFTInfo aftInfo = new EMediaAFTInfo();

		try {
			String requestNumber = rs.getString("REQUEST_NO");//Char(17)
			String afpUserId = rs.getString("APP_USER_ID");//Char(20)
			String userName = rs.getString("USER_NAME");//Char(50)
			String configType = rs.getString("CONFIG_TYPE");//Char(20)
			String configId = rs.getString("CONFIG_ID");//Char(20)
			String customerName = rs.getString("CUSTOMER_NAME");//Char(55)
			String action = rs.getString("ACTION");//Char(8)
			String mode = rs.getString("MODE");//Char(8)

			//Date startDate = rs.getDate("START_DATE");//Date
			//SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
			//String startDateStr =  formatter.format(startDate);
			String startDateStr =  rs.getString("START_DATE");//Date
			
			String comments = rs.getString("COMMENTS");//LongVarchar(500)
			String fileName = rs.getString("SS_FILE_NAME");//Varchar(100)
			String status = rs.getString("STATUS");//Char(10)
			String billMonth = rs.getString("BILL_MONTH");//Char(2)
			String billYear = rs.getString("BILL_YEAR");//Char(4)
			int recordCount = rs.getInt("RECORD_COUNT");//SmallInt
			int recordsFailedCount = rs.getInt("RECORDS_FAILED");//SmallInt
			int recordsAddedCount = rs.getInt("RECORDS_ADDED");//SmallInt
            int recordsDeletedCount = rs.getInt("RECORDS_DELETE");//SmallInt
            int rptRequestId = rs.getInt("RPT_REQUEST_ID");//SmallInt
			
			if(CommonUtil.isNotNull(requestNumber)) {
				aftInfo.setRequestNumber(requestNumber.trim());
			}
			if(CommonUtil.isNotNull(userName)) {
				aftInfo.setRequestorName(userName.trim());
			}
			if(CommonUtil.isNotNull(configType)) {
				aftInfo.setConfigType(configType.trim());
			}
			if(CommonUtil.isNotNull(configId)) {
				aftInfo.setConfigId(configId.trim());
			}
			if(CommonUtil.isNotNull(customerName)) {
				aftInfo.setCustomerName(customerName.trim());
			}
			if(CommonUtil.isNotNull(action)) {
				aftInfo.setAction(action.trim());
			}
			if(CommonUtil.isNotNull(mode)) {
				aftInfo.setMode(mode.trim());
			}
			if(CommonUtil.isNotNull(startDateStr)) {
				aftInfo.setStartDate(startDateStr.trim());
			}
			if(CommonUtil.isNotNull(comments)) {
				aftInfo.setComments(comments.trim());
			}
			if(CommonUtil.isNotNull(fileName)) {
				aftInfo.setFileName(fileName.trim());
			}
			if(CommonUtil.isNotNull(status)) {
				aftInfo.setStatus(status.trim());
			}
			if(CommonUtil.isNotNull(billMonth)) {
				aftInfo.setBillMonth(billMonth.trim());
			}
			if(CommonUtil.isNotNull(billYear)) {
				aftInfo.setBillYear(billYear.trim());
			}
			if(recordCount >= 0) {
				aftInfo.setTotalRecords(String.valueOf(recordCount));
			}
			if(recordsFailedCount >= 0) {
				aftInfo.setRecordsFailed(String.valueOf(recordsFailedCount));
			}
			if(recordsAddedCount >= 0) {
				aftInfo.setRecordsAdded(String.valueOf(recordsAddedCount));
			}
            if(recordsDeletedCount >= 0) {
                aftInfo.setRecordsDeleted(String.valueOf(recordsDeletedCount));
            }
            if(rptRequestId >= 0) {
                aftInfo.setRptRequestId(String.valueOf(rptRequestId));
            }
			
		} catch (NumberFormatException nfe) {
			_LOGGER.error("Exception occured while parsing the resultset \n", nfe);
		} catch (Exception e) {
			_LOGGER.error("Exception occured while parsing the resultset \n", e);
		}
		_LOGGER.debug("aftInfo ^^ " + aftInfo);
		return aftInfo;
	}

}
