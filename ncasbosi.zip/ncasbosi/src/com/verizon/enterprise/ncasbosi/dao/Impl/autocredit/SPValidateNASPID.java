package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


/**
 * @author v992473
 * This class represents the VALIDATE_NASP_ID api 
 * It is used for two purposes
 * 1.To validate a NASP ID when user tries to do so
 * 2.To validate a NASP ID on claim submit
 */

public class SPValidateNASPID extends BaseStoredProcedure {
	
	private final static Logger _LOGGER = Logger.getLogger(SPValidateNASPID.class);
	private static List<Object[]> spInOutList;
	
	static{		 
		 spInOutList = new ArrayList<Object[]>();
		 spInOutList.add(new Object[]{"NASP_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"VALID_NASP_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"OUT_NASP_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"OUT_NASP_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	 }
	
	public SPValidateNASPID(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_VALIDATE_NASP_ID, spInOutList);
	}
	
	public Map<String,Object> executeStoredProcedure(Object pInput)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map<String,Object> inputMap = (HashMap<String,Object>)pInput;
		_LOGGER.info("inputMap::"+inputMap);
		if(inputMap==null){
			throw new Exception("Input Object cannot be null");
		}
		
		String naspId = (String)inputMap.get("NASP_ID");
		String userAction = (String)inputMap.get("USER_ACTION");
		String claimNumber = (String)inputMap.get("ESG_CLAIM_NUMBER");
		
		List<Object> inputList = new ArrayList<Object>();
		inputList.add(naspId);//NASP_ID
		inputList.add(userAction);//USER_ACTION
		if("SUBMIT".equalsIgnoreCase(userAction)){
			if(claimNumber==null||claimNumber.trim().length()==0){
				throw new Exception("Claim number cannot be empty when userAction is SUBMIT");
			}else{
				inputList.add(new BigDecimal(claimNumber));//ESG_CLAIM_NUMBER
			}
		}else{
			inputList.add(null);//ESG_CLAIM_NUMBER claim number not required when user_Action=VALIDATE_NASP
		}		
		Map<String,Object> resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
		
	}	
}
