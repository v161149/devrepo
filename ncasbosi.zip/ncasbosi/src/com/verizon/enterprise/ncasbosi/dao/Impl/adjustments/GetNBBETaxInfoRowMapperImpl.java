package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.adjustments.Tax;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetNBBETaxInfoRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetNBBETaxInfoRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetNBBETaxInfoRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List taxInfoList = new ArrayList();
		try{
			while(rs.next()) {

				String taxId = rs.getString("TRK_RQ_LN_SEQ_B");
				String taxGroup = rs.getString("TAX_GRP_C");
				String taxAmount = rs.getString("TAX_SCHRG_A");
				String taxAmountId = rs.getString("TAX_SCHRG_C");
				String taxDescription = rs.getString("TAX_E_X");
				String taxLocationTypeCode = rs.getString("TAX_LCTN_C");
				String taxEngineCode = rs.getString("TAX_PGM_C");
				String geoCode = rs.getString("TAX_LCTN_F");

				Tax taxInfo = new Tax();
				if(CommonUtil.isNotNull(taxId)) {
					taxInfo.setTaxId(taxId.trim());
				}
				if(CommonUtil.isNotNull(taxGroup)) {
					taxInfo.setTaxGroup(taxGroup.trim());
				}
				if(CommonUtil.isNotNull(taxAmount)) {
					taxInfo.setTaxAmount(taxAmount.trim());
				}
				if(CommonUtil.isNotNull(taxAmountId)) {
					taxInfo.setTaxAmountId(taxAmountId.trim());
				}
				if(CommonUtil.isNotNull(taxDescription)) {
					taxInfo.setTaxDescription(taxDescription.trim());
				}
				if(CommonUtil.isNotNull(taxLocationTypeCode)) {
					taxInfo.setTaxLocationTypeCode(taxLocationTypeCode.trim());
				}
				if(CommonUtil.isNotNull(taxEngineCode)) {
					taxInfo.setTaxEngineCode(taxEngineCode.trim());
				}
				if(CommonUtil.isNotNull(geoCode)) {
					taxInfo.setGeoCode(geoCode.trim());
				}
				taxInfoList.add(taxInfo);
			}
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			throw nfe;
		}catch(Exception ex) {
			ex.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+ex.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+ex.getMessage());
		}
		return taxInfoList;
	}
}
