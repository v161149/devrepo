package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetVBEEMediaAccountsRowMapperImpl  implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetVBEEMediaAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetVBEEMediaAccountsRowMapperImpl::extractData()";

		logger.debug(METHOD_NAME + " ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();
		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = new ArrayList();
		String key = "";
		double remitOid=0.0;
		
		try
		{
			while(rs.next())
			{
				emediaRecord = new EMediaRecord();
				// resultSet
				String corpId = rs.getString("CORP_ID");//
				String man = rs.getString("MAN");//
				String ban = rs.getString("BAN");//
				String manDan = rs.getString("MAN_DAN");//
				String banDan = rs.getString("BAN_DAN");//
				String origSysId = rs.getString("ORIG_SYSTEM_ID");//
				String startBillPeriod = rs.getString("START_DATE");//
				String endBillPeriod = rs.getString("END_DATE");//
				String accountName = rs.getString("COMPANY_NAME");//
				String acctStatus = rs.getString("ACCT_STATUS");//
				String billPeriod = rs.getString("BP_DAY");//
				String configId = rs.getString("CONFIG_ID");//
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");//
				String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");//
				String gbrRegionName = rs.getString("GBR_REGION_NAME");//
				acctSubscriptionOid = rs.getDouble("SUBSCRIPTION_OID");//
				String billingFrequency = rs.getString("BILLING_FREQ");//
                String manBillDate = rs.getString("MAN_BILL_DATE");//
                remitOid = rs.getDouble("REMIT_OID");
                String remitId= rs.getString("REMIT_ID");
                String eligibilityInd = rs.getString("ELIGIBILITY_IND");
                String msg = rs.getString("MSG");
                String serviceId= rs.getString("SERVICE_ID");
                String productDesc= rs.getString("PRODUCT_DESC");
                String reportId= rs.getString("REPORT_ID");
                String reportName= rs.getString("REPORT_NAME");
                
				//Pretty print the DB Values - GBR - as per Paul request.
				List valuesList = new ArrayList();
				valuesList.add("CORP_ID="+corpId);
				valuesList.add("MAN="+man);
				valuesList.add("BAN="+ban);
				valuesList.add("MAN_DAN="+manDan);
				valuesList.add("BAN_DAN="+banDan);
				valuesList.add("ORIG_SYSTEM_ID="+origSysId);
				valuesList.add("START_DATE="+startBillPeriod);
				valuesList.add("END_DATE="+endBillPeriod);
				valuesList.add("COMPANY_NAME="+accountName);
				valuesList.add("ACCT_STATUS="+acctStatus);
				valuesList.add("BP_DAY="+billPeriod);
				valuesList.add("CONFIG_ID="+configId);
				valuesList.add("SYST_ABBREVIATION="+systemAbbrv);
				valuesList.add("GBR_INVOICE_TYPE="+gbrInvoiceType);
				valuesList.add("GBR_REGION_NAME="+gbrRegionName);
				valuesList.add("SUBSCRIPTION_OID="+acctSubscriptionOid);
				valuesList.add("BILLING_FREQ="+billingFrequency);
				valuesList.add("MAN_BILL_DATE="+manBillDate);
				valuesList.add("REMIT_OID="+remitOid);
				valuesList.add("REMIT_ID="+remitId);
				valuesList.add("ELIGIBILITY_IND="+eligibilityInd);
				valuesList.add("MSG="+msg);
				valuesList.add("SERVICE_ID="+serviceId);
				valuesList.add("PRODUCT_DESC="+productDesc);
				valuesList.add("REPORT_ID="+reportId);
				valuesList.add("REPORT_NAME="+reportName);
				
				CommonUtil.prettyPrintValues(valuesList);

				if(CommonUtil.isNotNull(corpId))
				{
					emediaRecord.setCorp(corpId.trim());
				}

				if(CommonUtil.isNotNull(ban))
				{
					emediaRecord.setBan(ban.trim());
				}

				if(CommonUtil.isNotNull(man))
				{
					emediaRecord.setMan(man.trim());
				}

				if(CommonUtil.isNotNull(manDan))
				{
					emediaRecord.setMan_dan(manDan.trim());
				}

				if(CommonUtil.isNotNull(configId))
				{
					emediaRecord.setCustConfigId(configId.trim());
				}

				if(CommonUtil.isNotNull(manDan))
				{
					emediaRecord.setMan_dan(manDan.trim());
				}

				if(CommonUtil.isNotNull(gbrInvoiceType))
				{
					emediaRecord.setInvoiceType(gbrInvoiceType.trim());
				}

				if(CommonUtil.isNotNull(gbrRegionName))
				{
					emediaRecord.setRegionName(gbrRegionName.trim());
				}

				if(CommonUtil.isNotNull( origSysId))
				{
					origSysId = origSysId.trim();
				}
				else
				{
					origSysId = "";
				}

				if((!origSysId.startsWith("M1") && !origSysId.startsWith("M2") && !origSysId.startsWith("M3") && !origSysId.startsWith("M9")) && (banDan==null || (banDan!=null && banDan.trim().equals(""))))
				{
					banDan = man;
					man = "";
				}

				emediaRecord.setOrigSysId(origSysId);

				if(CommonUtil.isNotNull(banDan))
				{
					emediaRecord.setBan_dan(banDan.trim());
				}

				if(CommonUtil.isNotNull(man))
				{
					emediaRecord.setMan_dan(man.trim());
				}

				if(CommonUtil.isNotNull(accountName))
				{
					emediaRecord.setAccountName(accountName.trim());
				}

				if(CommonUtil.isNotNull(billPeriod))
				{
					emediaRecord.setBillPeriod(billPeriod.trim());
				}

				if(CommonUtil.isNotNull(systemAbbrv))
				{
					emediaRecord.setSystemAbbrv(systemAbbrv.trim());
				}

				if(CommonUtil.isNotNull(startBillPeriod))
				{
					emediaRecord.setStartBillPeriod(CommonUtil.getDisplayDateFromString(startBillPeriod.trim()));
				}

				if(CommonUtil.isNotNull(endBillPeriod))
				{
					emediaRecord.setEndBillPeriod(CommonUtil.getDisplayDateFromString(endBillPeriod.trim()));
				}

				if(CommonUtil.isNotNull(acctStatus))
				{
					emediaRecord.setStatus(acctStatus.trim());
				}

				if(CommonUtil.isNotNull(billingFrequency))
				{
					emediaRecord.setBillingFrequency(billingFrequency.trim());
				}

				if(CommonUtil.isNotNull(manBillDate))
				{
					emediaRecord.setManBillDate(CommonUtil.getDisplayDateFromString(manBillDate.trim()));
				}

				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				emediaRecord.setAcctSubscriptionOid(key);

				emediaRecord.setRemitOid(CommonUtil.convertStringFromDouble(remitOid));
				if(CommonUtil.isNotNull(remitId)) {
					emediaRecord.setRemitId(remitId.trim());
				}
				if(CommonUtil.isNotNull(eligibilityInd)) {
					emediaRecord.setEligibilityInd(eligibilityInd.trim());
				}
				if(CommonUtil.isNotNull(msg)) {
					emediaRecord.setMsg(msg.trim());
				}			
				if(CommonUtil.isNotNull(serviceId)) {
					emediaRecord.setServiceId(serviceId.trim());
				}
				if(CommonUtil.isNotNull(productDesc)) {
					emediaRecord.setProductDesc(productDesc.trim());
				}
				if(CommonUtil.isNotNull(reportId)) {
					emediaRecord.setReportId(reportId.trim());
				}	
				if(CommonUtil.isNotNull(reportName)) {
					emediaRecord.setReportName(reportName.trim());
				}					
				refList.add(emediaRecord);
			}
		}
		catch(NumberFormatException nfe)
		{
				nfe.printStackTrace();
				logger.info(METHOD_NAME + " Exception occured while parsing the resultset \n"+nfe.getMessage());
				logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}

		logger.debug(METHOD_NAME + " EXIT");

		return refList;
	}
}