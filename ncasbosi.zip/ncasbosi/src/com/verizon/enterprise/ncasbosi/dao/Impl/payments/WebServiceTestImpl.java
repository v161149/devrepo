package com.verizon.enterprise.ncasbosi.dao.Impl.payments;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;


import java.util.HashMap;



import org.apache.log4j.Logger;




import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.paymentBeanPortBinding.*;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.*;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

import com.verizon.enterprise.common.ncas.exception.PaymentException;




import com.verizon.enterprise.common.ncas.payments.PaymentResponse;
import com.verizon.kernel.xml.XmlParse;
import com.verizon.enterprise.common.ncas.exception.InvalidPaymentException;




public class WebServiceTestImpl implements  NCASBOSIConstants
{
	private final Logger _LOGGER = Logger.getLogger(WebServiceTestImpl.class);

	public PaymentResponse addPayProfile(HashMap inpMap)throws InvalidPaymentException, PaymentException
	{
		final String METHOD_NAME = "addPayProfile => ";		
		return managePaymentProfile(inpMap);
	}
	public PaymentResponse updatePayProfile(HashMap inpMap)throws InvalidPaymentException, PaymentException
	{
		final String METHOD_NAME = "updatePayProfile => ";		
		return managePaymentProfile(inpMap);
	}

	public PaymentResponse managePaymentProfile(HashMap inpMap)throws InvalidPaymentException, PaymentException
	{
		final String METHOD_NAME = "managePaymentProfile => ";	
		_LOGGER.info(METHOD_NAME+" Entering");
		CreditCardBean creditCardBean = null;
		PaymentResponse paymentResponseObject = null;
		PaymentResults paymentResult = null;
		AccountsResponse accountResponseReturnObject = null;
		String default_address = "";
		try
		{
			if(((String)inpMap.get("PaymentType")).equals(CREDIT_CARD_PAYMENT_TYPE))
			{
				default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.CREDITCARD_WS_URL);				
				_LOGGER.info("authorizeCreditCard WS URL ==>"+default_address);
				creditCardBean = getCreditCardWebserviceObject(default_address);
				_LOGGER.info("Before Calling authorizeCreditCard WS in managePaymentProfile");
				accountResponseReturnObject = creditCardBean.authorizeCreditCard(setCreditCardInfo(inpMap));
				_LOGGER.info("updatePayProfile:::Exiting");
				paymentResponseObject =  setPaymentResponse(accountResponseReturnObject);
			}
			else if(((String)inpMap.get("PaymentType")).equals(BANK_EFT_PAYMENT_TYPE))
			{
				default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.PAYMENT_WS_URL);
				_LOGGER.info("bankAccount WS URL ==>"+default_address);
				MakeCCEFTPayment makeCCEFTPayment = getPaymentWebserviceObject(default_address);
				_LOGGER.info("Before Calling bankAccount WS in managePaymentProfile");
				paymentResult = makeCCEFTPayment.makePayment(paymentInput(inpMap));
				paymentResponseObject = setPaymentResponse(paymentResult);
				
			}
		}
		catch(PaymentException ex){
			throw ex;
		}		
		catch(Exception ex){
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_PROFILE,errMsg,ex);
		}
		_LOGGER.info("managePaymentProfile:::Exiting");
		return paymentResponseObject;
	}
	
	
	public com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard setCreditCardInfo(HashMap inpMap)throws PaymentException
	{
		final String METHOD_NAME = "setCreditCardInfo => ";			
		try{
			_LOGGER.info("setCreditCardInfo profile :::Entering");
			com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard creditCardObject = null;
			
			creditCardObject = new com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard();
			creditCardObject.setCardNumber((String)inpMap.get("AccountNumber"));
			creditCardObject.setCvvDigits((String)inpMap.get("AcctDigits"));
			creditCardObject.setCardType((String)inpMap.get("TypeDescription"));
			creditCardObject.setNameOnCard((String)inpMap.get("Name"));
			creditCardObject.setExperationMonth(Integer.parseInt((String)inpMap.get("ExpDateMM")));
			creditCardObject.setExperationYear(Integer.parseInt((String)inpMap.get("ExpDateYY")));
			creditCardObject.setZip((String)inpMap.get("Zip"));
			
			_LOGGER.info("setCreditCardInfo profile :::Exiting");
			return creditCardObject;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);						
		}				
		
	}

	
	public PaymentInput paymentInput(HashMap inpMap)throws PaymentException
	{
		final String METHOD_NAME = "paymentInput for encryptBankAccount => ";
		_LOGGER.info("paymentInput for encryptBankAccount :::Entering");
		try
		{
			PaymentInput paymentInputObject = new PaymentInput() ;
	
			paymentInputObject.setBankAccountNumber((String)inpMap.get("AccountNumber"));
			paymentInputObject.setRoutingNumber((String)inpMap.get("RoutingNumber"));
			paymentInputObject.setWhatTodo((String)inpMap.get("WhatTodo"));
			_LOGGER.info("paymentInput for encryptBankAccount  :::Exiting");
			return paymentInputObject;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);						
		}	
		
	}
	
	
	public PaymentResponse addPayment(HashMap inpMap)throws InvalidPaymentException, PaymentException
	{
		_LOGGER.info("addPayment:::Entering");
		return managePayment(inpMap);
	}



	//This method will only be called from VZW Recur Payment Batch processing.
	public PaymentResponse updatePayment(HashMap inpMap)throws InvalidPaymentException, PaymentException
	{
		_LOGGER.info("updatePayment:::Entering");
		return managePayment(inpMap);
	}

	public PaymentResponse managePayment(HashMap inpMap)throws InvalidPaymentException, PaymentException
	{
		final String METHOD_NAME = "managePayment => ";	
		_LOGGER.info(METHOD_NAME+" Entering");
		PaymentResults paymentResult = null;
		PaymentResponse paymentResponse = null;
		String default_address = "";
		
		try
		{
			default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.PAYMENT_WS_URL);		
			_LOGGER.info("makePayment WS URL ==>"+default_address);
			MakeCCEFTPayment makeCCEFTPayment = getPaymentWebserviceObject(default_address);
			_LOGGER.info("Before Calling makePayment WS in addPayment");
			paymentResult = makeCCEFTPayment.makePayment(paymentInputPay(inpMap));
			paymentResponse = setPaymentResponse(paymentResult);
		}
		catch(PaymentException ex){
				throw ex;
		}		
		catch(Exception ex){
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_PAY,errMsg,ex);			
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return paymentResponse;
	}
	
	
	public PaymentInput paymentInputPay(HashMap inpMap)throws PaymentException
	{
		final String METHOD_NAME = "paymentInput => ";	
		try{
		
			_LOGGER.info("paymentInput :::Entering");
			PaymentInput paymentInputObject = new PaymentInput() ;
			paymentInputObject.setAlias((String)inpMap.get("NickName"));
			paymentInputObject.setAmountDue((String)inpMap.get("InvAmtDue"));
			paymentInputObject.setBan((String)inpMap.get("CustAcctNum"));
			paymentInputObject.setBanDan((String)inpMap.get("ServiceID"));
	
			if(((String)inpMap.get("PaymentType")).equals(CREDIT_CARD_PAYMENT_TYPE))
			{
				paymentInputObject.setCardType((String)inpMap.get("TypeCode"));
				paymentInputObject.setCreditCardNumber((String)inpMap.get("AccountNumber"));
				paymentInputObject.setExpMonth((String)inpMap.get("ExpDateMM"));
				paymentInputObject.setExpYear((String)inpMap.get("ExpDateYY"));
				paymentInputObject.setExpDate((String)inpMap.get("ExpDateMM")+"/"+(String)inpMap.get("ExpDateYY"));
				paymentInputObject.setBankAccountNumber("");
			}
			else
			{
				paymentInputObject.setBankAccountNumber((String)inpMap.get("SafeKey"));
				paymentInputObject.setCreditCardNumber("");
				paymentInputObject.setCardType("");
				paymentInputObject.setExpDate("");
				paymentInputObject.setExpMonth("");
				paymentInputObject.setExpYear("");
			}
			paymentInputObject.setCustomerName((String)inpMap.get("Name"));
	
				paymentInputObject.setInvoiceDate((String)inpMap.get("InvoiceDate"));
				paymentInputObject.setInvoiceNumber((String)inpMap.get("InvoiceNum"));
				paymentInputObject.setAmount((String)inpMap.get("PaymentAmnt"));
			
			paymentInputObject.setOsid((String)inpMap.get("OrigSystemID"));
			paymentInputObject.setRoutingNumber((String)inpMap.get("RoutingNumber"));
			if(!((String)inpMap.get("OrigSystemID")).equals("VW"))
				paymentInputObject.setSettleDays("0");
			else
				paymentInputObject.setSettleDays((String)inpMap.get("SettleDay"));
			paymentInputObject.setSystemID((String)inpMap.get("LoginId"));
			paymentInputObject.setUserid((String)inpMap.get("PortalLoginID"));
			paymentInputObject.setWhatTodo((String)inpMap.get("WhatTodo"));
			paymentInputObject.setZipCode((String)inpMap.get("Zip"));
			
			_LOGGER.info("paymentInput :::Exiting");
			
			return paymentInputObject;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);						
		}			
	}
	
	
	
	
	public Double getWirelessRealTimeBalance(String accountNumber) throws PaymentException
	{
		final String METHOD_NAME = "getWirelessRealTimeBalance => ";	
		_LOGGER.info(METHOD_NAME+" Entering");		

		Double retValue = 0.0;
		StringBuffer sbResponseXML = new StringBuffer();
		String userID = NCASBOSIConfig.getProperty(NCASBOSIConstants.WIRELESS_REL_USERID);
		String password = NCASBOSIConfig.getProperty(NCASBOSIConstants.WIRELESS_REL_PASSWORD);
		_LOGGER.info("UserID and Password are -->"+userID+" --- "+password);
		String sbRequestXML =
			"xmlreqdoc=<service>" +
				"<serviceHeader>" +
					"<billingSys>VISION</billingSys>" +
					"<clientId>VZB-EPAYMENTS</clientId>" +
					"<userId>"+userID+"</userId>" +
					"<password>"+password+"</password>" +
					"<serviceName>retrieveAccountBalanceForPayment" +
					"</serviceName>" +
				"</serviceHeader>" +
				"<serviceBody>" +
					"<serviceRequest>" +
						"<subServiceName></subServiceName>" +
						"<accountNo>"+accountNumber+"</accountNo>" +
						"<billTypeCode>C</billTypeCode>" +
						"</serviceRequest>" +
				"</serviceBody>" +
			"</service>";
		_LOGGER.info("Request XMLString -->"+sbRequestXML.toString());
		String default_address = "";
		
		
		try
	    {
			default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.EPAY_VISION_REAL_BALANCE_URL);	
			URL url = new URL (default_address);

		    URLConnection urlCon = url.openConnection();
		    urlCon.setDoOutput(true);

		    PrintWriter out = new PrintWriter(new OutputStreamWriter(urlCon.getOutputStream(), "UTF-8"));
		    out.println(sbRequestXML.toString());
		    out.println("");
		    out.close();

		    // read in the Response stream
		    BufferedReader reader = new BufferedReader(new InputStreamReader(urlCon.getInputStream()));
		    String sLine = "";

		    for (int lineCnt = 0; (sLine = reader.readLine()) != null; lineCnt++)
		    {
		    	sbResponseXML.append(sLine + "\n");
		    }
		    _LOGGER.info("Response XMLString -->"+sbResponseXML.toString());
		    XmlParse inXml = new XmlParse(sbResponseXML.toString());
		    inXml.moveToRoot();
		    inXml.moveTo("serviceBody/serviceResponse");
		    _LOGGER.info("totalBalanceDue -->"+inXml.getNodeValue("totalBalanceDue"));
		    retValue = Double.parseDouble(inXml.getNodeValue("totalBalanceDue"));
		    _LOGGER.info("\n\n\n retValue -->"+retValue);
		}
	    catch (Exception ex)
	    {
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(VISION_RT_BALANCE,errMsg,ex);			
		}
		_LOGGER.info("getWirelessRealTimeBalance:::Exiting");
		return retValue;
	}

	
	
	
	
	public CreditCardBean getCreditCardWebserviceObject(String default_address)throws PaymentException
	{
		final String METHOD_NAME = "getCreditCardWebserviceObject => ";	
		_LOGGER.info(METHOD_NAME+" Entering");
		try{
			CreditCardBeanServiceLocator creditCardBeanLocator = new CreditCardBeanServiceLocator();
			CreditCardBean creditCardBean = new CreditCardBeanPortBindingStub();
			creditCardBeanLocator.setCreditCardBeanPortEndpointAddress(default_address);
			creditCardBean = creditCardBeanLocator.getCreditCardBeanPort();
			_LOGGER.info(METHOD_NAME+" Exiting");
			return creditCardBean;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_CONNECT,errMsg,ex);						
		}
	}

	public MakeCCEFTPayment getPaymentWebserviceObject(String default_address)throws PaymentException
	{
		final String METHOD_NAME = "getPaymentWebserviceObject => ";	
		_LOGGER.info(METHOD_NAME+" Entering");
		
		try{			
			MakeCCEFTPaymentServiceLocator cceftPaymentServiceLocator = new MakeCCEFTPaymentServiceLocator();
			MakeCCEFTPayment cceftPayment = new MakeCCEFTPaymentSoapBindingStub();
			cceftPaymentServiceLocator.setMakeCCEFTPaymentEndpointAddress(default_address);
			cceftPayment = cceftPaymentServiceLocator.getMakeCCEFTPayment();
			_LOGGER.info(METHOD_NAME+" Exiting");
			return cceftPayment;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_CONNECT,errMsg,ex);						
		}			
	}

	public PaymentResponse setPaymentResponse(AccountsResponse accountResponseReturnObject)throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "setPaymentResponse => ";	
		try{
		
			_LOGGER.info("After Calling authorizeCreditCard WS");
			_LOGGER.info("setPaymentResponse AccountsResponse :::Entering");
			PaymentResponse paymentResponseObject = new PaymentResponse();
			_LOGGER.info("\n *****output from WS for authorizeCreditCard  ********* \n");
			_LOGGER.info("Approval_code -->"+accountResponseReturnObject.getApproval_code());
			_LOGGER.info("Avs_check -->"+accountResponseReturnObject.getAvs_check());
			_LOGGER.info("Response_code -->"+accountResponseReturnObject.getResponse_code());
			_LOGGER.info("Response_text -->"+accountResponseReturnObject.getResponse_text());
			_LOGGER.info("Tracking_id -->"+accountResponseReturnObject.getTracking_id());
			_LOGGER.info("Seq_number -->"+accountResponseReturnObject.getSeq_number());
			_LOGGER.info("Order_number -->"+accountResponseReturnObject.getOrder_number());
			_LOGGER.info("SafeValue -->"+accountResponseReturnObject.getSafeValue());
			_LOGGER.info("\n *********************************************************** \n ");

			handleResponse(accountResponseReturnObject.getResponse_code(),accountResponseReturnObject.getResponse_text(),METHOD_NAME);
			paymentResponseObject.setEpResponseCode(accountResponseReturnObject.getResponse_code());
			paymentResponseObject.setEpResponseText(accountResponseReturnObject.getResponse_text());
			
			paymentResponseObject.setEpTrackID(accountResponseReturnObject.getTracking_id());
			paymentResponseObject.setSafeKey(accountResponseReturnObject.getSafeValue());
			_LOGGER.info("setPaymentResponse AccountsResponse :::Exiting");
			return paymentResponseObject;
		}
		catch(PaymentException ex){
			throw ex;
		}			
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_POST,errMsg,ex);						
		}		
		
	}

	private void handleResponse(String response_code, String response_text,String methodName)throws InvalidPaymentException,PaymentException
	{
		String[] errMsg = new String[1];
	    errMsg[0] = methodName;

		if(response_code!=null && !(response_code.equals("00")||response_code.equals("0")||response_code.equals("")))
			throw new PaymentException(BILLING_EPAY_POST,errMsg,null,response_code,response_text);		
		
	}

	public PaymentResponse setPaymentResponse(PaymentResults paymentResult)throws PaymentException
	{
		final String METHOD_NAME = "setPaymentResponse => ";	
		try{		
			_LOGGER.info("setPaymentResponse paymentResult :::Entering");
			PaymentResponse paymentResponseObject = new PaymentResponse();
			_LOGGER.info("\n output from WS for makePayment WS ******************** \n");
			_LOGGER.info("ReturnCode -->"+paymentResult.getReturnCode());
			_LOGGER.info("ReturnText -->"+paymentResult.getReturnText());
			_LOGGER.info("TrackingID -->"+paymentResult.getTrackingID());
			_LOGGER.info("SafeValue -->"+paymentResult.getSafeValue());
			_LOGGER.info("CICSReturnText -->"+paymentResult.getCICSReturnText());
			_LOGGER.info("StatusCode -->"+paymentResult.getStatusCode());
			_LOGGER.info("StatusIndicators -->"+paymentResult.getStatusIndicators());
			_LOGGER.info("\n ****************************************************** \n");
			//paymentResponseObject = new PaymentResponse(0,"",Integer.parseInt(paymentResult.getTrackingID()),"",paymentResult.getReturnCode(),paymentResult.getReturnText(),"","");
			handleResponse(paymentResponseObject.getEpResponseCode(),paymentResponseObject.getEpResponseText(),METHOD_NAME);
			paymentResponseObject.setEpResponseCode(paymentResult.getReturnCode());
			paymentResponseObject.setEpResponseText(paymentResult.getReturnText());
			paymentResponseObject.setEpTrackID(paymentResult.getTrackingID());
			paymentResponseObject.setSafeKey(paymentResult.getSafeValue());
			_LOGGER.info("setPaymentResponse paymentResult :::Exiting");
			return paymentResponseObject;
		}
		catch(PaymentException ex){
			throw ex;
		}			
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_POST,errMsg,ex);						
		}				
	}


}