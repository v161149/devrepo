package com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker;

import java.util.Arrays;
import java.util.Map;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.bugtracker.BugTrackerDataInterface;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.apache.log4j.Logger;
import com.verizon.enterprise.common.ncas.bugtracker.IssueDetails;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import org.apache.struts.util.LabelValueBean;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.Types;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.StringTokenizer;
public class BugTrackerDaoImpl extends NCASSpringJDBCBase implements
		BugTrackerDataInterface, NCASBOSIConstants {
	static private final Logger _LOGGER = Logger
			.getLogger(BugTrackerDaoImpl.class);
	private JdbcTemplate vamJdbcTemplate;// jdbctemplate created for VAM
	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	private BatchSqlUpdate insertProjectSqlUpdate = null;
	private BatchSqlUpdate insertUserSqlUpdate = null;
    private BatchSqlUpdate insertFileSqlUpdate=null;
    private UpdateIssueStatus updateIssueStatus=null;
    private DeleteFileStatus  deleteFileStatus=null;
	// dataSource
	private String getSchemaName() {
		//Time being it is commented
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	public void setVAMDataSource(DataSource dataSource) {
		vamJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[VAMjdbcTemplate datasource set ]");
	}

	public DataSource getVAMDataSource() {
		return vamJdbcTemplate.getDataSource();
	}

	public Map processBugData(IssueDetails input) throws NCASException {
     String METHOD_NAME="BugTrackerDaoImpl::processBugData";
     _LOGGER.info(METHOD_NAME+" Entering...");
     int issueId;
     Map output;
     List resultList=new ArrayList();
		try {
			output=new HashMap();
			String schemaName = getSchemaName();
			
			_LOGGER.info("Entering into processBugData::");
			_LOGGER.info("Operation Name::"+input.getOperation());
			if (input == null) {
				_LOGGER.error("throwing exception IssueDetails is Null ");
				_LOGGER.debug("throwing exception IssueDetails is Null ");
				throw new Exception("IssueDetails is Null");
			}
			if (input.getOperation() != null
					&&( input.getOperation().equals("ADD")
					|| input.getOperation().equals("VIEW")
					|| input.getOperation().equals("EDIT")
					|| input.getOperation().equals("SEARCH")
					|| input.getOperation().equals("UPDATE"))) {
				_LOGGER.info("Inside operation"+input.getOperation());
				SPGetBugTracker getBugTrackerData = new SPGetBugTracker(
						getDataSource(), schemaName,input.getOperation());
				output = getBugTrackerData.executeStoredProcedure(input);
			
				//SELECT THE FILENAME AND FILEID IN EDIT OPERATION
				if(input.getOperation() != null
						&& input.getOperation().equals("EDIT")){
					_LOGGER.info("Selecting the FILE_ID");
					String fileQuery="SELECT FILE_ID,FILE_NAME FROM "
			              +getSchemaName()+".PL_TST_FILES WHERE ISSUE_ID="+input.getIssueId();
		      SelectFileContentEdit selectFileContentEdit=new SelectFileContentEdit(getDataSource(),fileQuery);
		      List fileList=selectFileContentEdit.execute(new Object[]{});
		      output.put("fileMap", fileList);
				}
				
				//Insert the File attachment if the operation is ADD 
				if(input.getOperation() != null
					&& input.getOperation().equals("ADD")){
				 resultList=(ArrayList)output.get("RESULT_SET_ONE");
				 IssueDetails issue=(IssueDetails)resultList.get(0);
				issueId=Integer.parseInt(issue.getIssueId());
				String file_name = input.getFileName();
				_LOGGER.info("IssueId:::"+issueId);
				if(issueId!=0 && file_name.trim().length()>0){
			output=insertBugTrackerFile(input,issueId);
				}
				}
				else if(input.getOperation() != null
						&& input.getOperation().equals("UPDATE")){
					String file_name = input.getFileName();
					int issue_id = Integer.parseInt(input.getIssueId());
					_LOGGER.info("IssueId:::"+issue_id);
					if(issue_id!=0 && file_name.trim().length()>0){
				output=insertBugTrackerFile(input,issue_id);
					
				}
				
			}
			} 
			else if (input.getOperation() != null
					&& input.getOperation().equals("loadValues")) {
				
				String userQuery = "SELECT USER_ID,USER_NAME FROM  "
						+ getSchemaName() + ".PL_TST_USER WHERE USER_TYPE='"
						+ "DEVELOPER" + "'"+ " ORDER BY USER_NAME ASC";
				String projectQuery = "SELECT PROJECT_ID,PROJECT_NAME FROM  "
						+ getSchemaName() + ".PL_TST_PROJECTS ORDER BY PROJECT_NAME ASC";
				SelectAllUser selectAllUser = new SelectAllUser(
						getDataSource(), userQuery);
				List userList = selectAllUser.execute(new Object[] {});
				SelectAllProject selectAllProject = new SelectAllProject(
						getDataSource(), projectQuery);
				List projectList = selectAllProject.execute(new Object[] {});
				output.put("userMap", userList);
				output.put("projectMap", projectList);

			} else if (input.getOperation() != null
					&& input.getOperation().equals("insertProject")) {
				output = insertBugTrackerProject(input);
			} else if (input.getOperation() != null
					&& input.getOperation().equals("insertUser")) {
				output = insertBugTrackerUser(input);
			}
			/*else if(input.getOperation() != null
					&& input.getOperation().equals("insertFile")){
				output=insertBugTrackerFile(input);
			}*/
			else if(input.getOperation() != null
					&& input.getOperation().equals("selectFile")){
				String fileQuery="SELECT FILE_ID,FILE_SIZE,FILE_NAME,FILE_DATA FROM "
					              +getSchemaName()+".PL_TST_FILES WHERE FILE_ID="+input.getFileId();
				SelectFileContent selectFileContent=new SelectFileContent(getDataSource(),fileQuery);
				List fileList=selectFileContent.execute(new Object[]{});
				output.put("fileMap", fileList);
			}
			else if(input.getOperation() != null
					&& input.getOperation().equals("LOGIN")){
				boolean status=false;
				String loginQuery="SELECT USER_NAME,USER_TYPE FROM "+getSchemaName()+".PL_TST_USER WHERE UPPER(USER_ID)=UPPER('"+input.getUserProfile()+"')" ;
				SelectLoginStatus selectLoginStatus=new SelectLoginStatus(getDataSource(),loginQuery);
				List loginList=selectLoginStatus.execute(new Object[]{});
				/*if(loginList.isEmpty() ){
					loginList.add(new Boolean(status));
				}*/
				output.put("loginMap", loginList);
			}
			else if(input.getOperation() != null
					&& input.getOperation().equals("CLOSE")){
				String deleteBugs=null;
				StringTokenizer bugtoken=null;
				String bugId=null;
				
				
					deleteBugs=input.getBugList();
					_LOGGER.info("Bugs in removeIssues:::"+deleteBugs);
					
					bugtoken=new StringTokenizer(deleteBugs,",");
					
					while(bugtoken.hasMoreTokens()){
					bugId=bugtoken.nextToken();
					issueId=Integer.parseInt(bugId);
					_LOGGER.info("issueId:::"+issueId);
					String updateIssueHeader="UPDATE "+getSchemaName()+".PL_TST_ISSUE_HEADER SET STATUS='"+"CLOSED"+"' WHERE ISSUE_ID="+issueId;
					updateIssueStatus=new UpdateIssueStatus(getDataSource(),updateIssueHeader);
					updateIssueStatus.update(new Object[]{});
					}
			}
			else if(input.getOperation() != null
					&& input.getOperation().equals("REMOVE")){
				boolean status=false;
				String deleteFileQuery="DELETE FROM "
		              +getSchemaName()+".PL_TST_FILES WHERE FILE_ID="+input.getFileId()+" AND ISSUE_ID="+input.getIssueId();
				deleteFileStatus=new DeleteFileStatus(getDataSource(),deleteFileQuery);
	            deleteFileStatus.update(new Object[]{});
	            status=true;
	            output.put("removeStatus",status );
				
			}
			_LOGGER.info("Leaving getBugTrackerData");

			return output;
		} catch (Exception vamEx) {
			_LOGGER.debug("GET SPGetBugTracker\n" + vamEx.getMessage());
			_LOGGER.error("GET SPGetBugTracker\n" + vamEx.getMessage());
			throw new NCASException("BI0906", BugTrackerDaoImpl.class, vamEx);
		}
	}

	abstract class AbstractSelect extends MappingSqlQuery {
		public AbstractSelect(DataSource dataSource, String sql) {
			super(dataSource, sql);
		}
	}

	class SelectAllUser extends AbstractSelect {
		SelectAllUser(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			String userId = rs.getString("USER_ID");
			String userName = rs.getString("USER_NAME");
			/*
			 * IssueDetails issue = new IssueDetails();
			 * issue.setUserProfile(userId); issue.setUserNameValue(userName);
			 * return issue;
			 */
			LabelValueBean userBean = new LabelValueBean(userId.trim(), userName.trim());
			return userBean;

		}
	}

	class SelectAllProject extends AbstractSelect {
		SelectAllProject(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			String projectId = rs.getString("PROJECT_ID");
			String projectName = rs.getString("PROJECT_NAME");
			/*
			 * IssueDetails issue = new IssueDetails();
			 * issue.setProject(projectId); issue.setProjectdesc(projectName);
			 * return issue;
			 */
			LabelValueBean projectBean = new LabelValueBean(projectId.trim(),
					projectName.trim());
			return projectBean;
		}
	}
	class SelectFileContent extends AbstractSelect {
		SelectFileContent(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			byte [] outFile = null;
			ByteArrayOutputStream baos = null;
			Blob fileData = rs.getBlob("FILE_DATA");
			String fileName = rs.getString("FILE_NAME");
			long fileSize=rs.getLong("FILE_SIZE");
			int fileId=rs.getInt("FILE_ID");
			baos = new ByteArrayOutputStream();
			baos.write(fileData.getBytes(1, (int)fileData.length()), 0, (int)fileData.length());
			outFile = baos.toByteArray();
			 IssueDetails issue = new IssueDetails();
			 issue.setFileName(fileName);
			 issue.setFileSize(String.valueOf(fileSize));
			 issue.setFileBytes(outFile);
			 issue.setFileId(String.valueOf(fileId));
			 
			 return issue;
			 
			
		}
	}
	
	class SelectLoginStatus extends AbstractSelect {
		
		SelectLoginStatus(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			boolean status = false;
			 IssueDetails issue = new IssueDetails();
			 String userName = rs.getString("USER_NAME");
			 String userRole=rs.getString("USER_TYPE");
			 if(userName!=null && !userName.equals("")){
				status=true;
				issue.setUserType(userRole);
				issue.setUserNameValue(userName);
			 }
			 
			return issue;
		}
	}
	class SelectFileContentEdit extends AbstractSelect {
		SelectFileContentEdit(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		
			 String fileName = rs.getString("FILE_NAME");
			 int fileId=rs.getInt("FILE_ID");
			 IssueDetails issue = new IssueDetails();
			 issue.setFileName(fileName);
			 issue.setFileId(String.valueOf(fileId));
			 return issue;
			 
			
		}
	}
	public Map insertBugTrackerProject(IssueDetails input) throws NCASException {
		String METHOD_NAME = "insertBugTrackerProject";
		_LOGGER.info(METHOD_NAME + "  Enter ");
		String INSERT_PROJECT = " INSERT INTO " + getSchemaName()
				+ ".PL_TST_PROJECTS(PROJECT_ID,PROJECT_NAME,PROJECT_RELEASE)"
				+ "VALUES (?,?,?)";
		boolean status = false;
		Map resultMap = new HashMap();
		int count;
		try {
			if (insertProjectSqlUpdate == null) {
				insertProjectSqlUpdate = new BatchSqlUpdate(getDataSource(),
						INSERT_PROJECT);
				insertProjectSqlUpdate.declareParameter(new SqlParameter(
						"PROJECT_ID", Types.VARCHAR));
				insertProjectSqlUpdate.declareParameter(new SqlParameter(
						"PROJECT_NAME", Types.VARCHAR));
				insertProjectSqlUpdate.declareParameter(new SqlParameter(
						"PROJECT_RELEASE", Types.VARCHAR));
				insertProjectSqlUpdate.compile();
				
				

			}
				Object[] parameterValues = new Object[] { input.getProject(),
						input.getProjectdesc(), input.getProjectRelease() };

				count = insertProjectSqlUpdate.update(parameterValues);
			if(insertProjectSqlUpdate!=null)
				insertProjectSqlUpdate.flush();
			status = true;
			
		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertBugTrackerProject in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("insertBugTrackerProject in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					BugTrackerDaoImpl.class, vamEx);
		}
		resultMap.put("Status", status);
		return resultMap;
	}

	public Map insertBugTrackerUser(IssueDetails input) throws NCASException {
		String METHOD_NAME = "insertBugTrackerUser";
		Map resultMap = new HashMap();
		_LOGGER.info(METHOD_NAME + "  Enter ");
		String INSERT_USER = " INSERT INTO " + getSchemaName()
				+ ".PL_TST_USER(USER_ID,USER_NAME,PASSWORD,USER_TYPE)"
				+ "VALUES (?,?,?,?)";
		boolean status = false;
		_LOGGER.info("User Id" +input.getUserProfile());
		_LOGGER.info("User Name "+input.getUserNameValue());
		_LOGGER.info("password"+input.getPassword());
		_LOGGER.info("userType"+ input.getUserType());
		int count=0;
		try {

			if (insertUserSqlUpdate == null) {
				insertUserSqlUpdate = new BatchSqlUpdate(getDataSource(),
						INSERT_USER);
				insertUserSqlUpdate.declareParameter(new SqlParameter(
						"USER_ID", Types.VARCHAR));
				insertUserSqlUpdate.declareParameter(new SqlParameter(
						"USER_NAME", Types.VARCHAR));
				insertUserSqlUpdate.declareParameter(new SqlParameter(
						"PASSWORD", Types.VARCHAR));
				insertUserSqlUpdate.declareParameter(new SqlParameter(
						"USER_TYPE", Types.VARCHAR));
				insertUserSqlUpdate.compile();
				
			}
				Object[] parameterValues = new Object[] {
					input.getUserProfile().trim(), input.getUserNameValue().trim(),
					input.getPassword().trim(), input.getUserType().trim() };

		count=	insertUserSqlUpdate.update(parameterValues);
			if (insertUserSqlUpdate != null) 
				insertUserSqlUpdate.flush();	
			status = true;

		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertBugTrackerProject in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("insertBugTrackerProject in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					BugTrackerDaoImpl.class, vamEx);
		}
		_LOGGER.info("count:::"+count);
		resultMap.put("Status", new Boolean(status));
		return resultMap;
	}

	public Map insertBugTrackerFile(IssueDetails input,int issueId) throws NCASException {
		String METHOD_NAME = "insertBugTrackerFile";
		Map resultMap =  new HashMap();
		_LOGGER.info(METHOD_NAME + "  Enter ");
		String INSERT_FILE = " INSERT INTO " + getSchemaName()
				+ ".PL_TST_FILES(ISSUE_ID,FILE_SIZE,FILE_NAME,FILE_DATA)"
				+ "VALUES (?,?,?,?)";
		boolean status = false;
        long fileSize=Long.parseLong(input.getFileSize());
        byte[] fileData=input.getFileBytes();
        String fileName=input.getFileName();
        _LOGGER.info("File Size"+fileSize);
        _LOGGER.info("File Data"+fileData);
        _LOGGER.info("fileName::"+fileName);
        _LOGGER.info("IssueId::"+issueId);
        ByteArrayInputStream bais = new ByteArrayInputStream(fileData);
		try {

			if (insertFileSqlUpdate == null) {
				insertFileSqlUpdate = new BatchSqlUpdate(getDataSource(),
						INSERT_FILE);
				insertFileSqlUpdate.declareParameter(new SqlParameter(
						"ISSUE_ID", Types.INTEGER));
				insertFileSqlUpdate.declareParameter(new SqlParameter(
						"FILE_SIZE", Types.BIGINT));
				insertFileSqlUpdate.declareParameter(new SqlParameter(
						"FILE_NAME", Types.VARCHAR));
				insertFileSqlUpdate.declareParameter(new SqlParameter(
						"FILE_DATA", Types.LONGVARBINARY));
				insertFileSqlUpdate.compile();
				
			}
			Object[] parameterValues = new Object[] {
					 new Integer(issueId), new Long(fileSize),
					fileName,fileData};
			 _LOGGER.info("parameterValues:::"+Arrays.asList(parameterValues));
			 insertFileSqlUpdate.update(parameterValues);
			if (insertFileSqlUpdate != null) 
				insertFileSqlUpdate.flush();	
			status = true;
			

		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertBugTrackerFile in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("insertBugTrackerFile in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					BugTrackerDaoImpl.class, vamEx);
		}
		resultMap.put("fileInsertionStatus", new Boolean(status));
		  _LOGGER.info("Attachment insertion status:::"+status);
		return resultMap;
	}
	class UpdateIssueStatus extends SqlUpdate{
		public UpdateIssueStatus(DataSource dataSource,String updateQuery){
			super(dataSource,updateQuery);
			
		}
		}
	class DeleteFileStatus extends SqlUpdate{
		public DeleteFileStatus(DataSource dataSource,String deleteQuery){
			super(dataSource,deleteQuery);
			
		}
		}
}
