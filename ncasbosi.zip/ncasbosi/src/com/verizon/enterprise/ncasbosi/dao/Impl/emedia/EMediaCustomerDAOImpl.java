package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.
    EMediaCustomerInterface;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncasbosi.beans.EMediaCustomer;

public class EMediaCustomerDAOImpl
    extends NCASSpringJDBCBase implements
    EMediaCustomerInterface,
    NCASBOSIConstants {

  private static final Logger _LOGGER = Logger.getLogger(
      EMediaCustomerDAOImpl.class);

  private static final String USER_ID_CONFIG_PATH =
      "verizon.ebosi.bill.vam.userid";

  private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
  private static final String USER_ID_CONFIG_READ_ERROR =
      "Errors in reading config : " + USER_ID_CONFIG_PATH;

  private SqlUpdate insertEMediaCustomerSqlUpdate = null;
  private SqlUpdate updateEMediaCustomerSqlUpdate = null;
  private SqlUpdate deleteEMediaCustomerSqlUpdate = null;

  /* INSERT, UPDATE, DELETE, SELECT for EMEDIA_CUATOMER Table  -  START */
  /**
   *
   * @param eMediaCustomer EMediaCustomer
   * @return boolean
   * @throws Exception
   */  public Map doEMediaCustomer(String operation, EMediaCustomer eMediaCustomer) throws  NCASException {	  Map returnMap;	  if(operation.equalsIgnoreCase("I"))		  returnMap = insertEMediaCustomer(eMediaCustomer);	  else if(operation.equalsIgnoreCase("U"))		  returnMap = updateEMediaCustomer(eMediaCustomer);	  else if(operation.equalsIgnoreCase("D"))		  returnMap = deleteEMediaCustomer(eMediaCustomer);	  else if(operation.equalsIgnoreCase("S"))		  returnMap = selectEMediaCustomer(eMediaCustomer);	  else returnMap = selectALL_EMediaCustomer();	  	  	  
	  return returnMap;  }
  public Map insertEMediaCustomer(EMediaCustomer eMediaCustomer) throws
      NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String customerType = eMediaCustomer.getCustomerType();
    String channelCode = CommonUtil.getCSVStringFromList(eMediaCustomer.getChannelCode());
    String INSERT_EMEDIA_CUSTOMER_LINK = "INSERT INTO " + getSchemaName() +
        ".EMEDIA_CUSTOMER(CUSTOMER_TYPE,CHANNEL_CODE) VALUES(?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_EMEDIA_CUSTOMER_LINK);
    try {
      if (insertEMediaCustomerSqlUpdate == null) {
        insertEMediaCustomerSqlUpdate = new SqlUpdate(jdbcTemplate.
            getDataSource(), INSERT_EMEDIA_CUSTOMER_LINK);
        insertEMediaCustomerSqlUpdate.declareParameter(new SqlParameter(
            "CUSTOMER_TYPE", Types.VARCHAR));
        insertEMediaCustomerSqlUpdate.declareParameter(new SqlParameter(
            "CHANNEL_CODE", Types.VARCHAR));
        insertEMediaCustomerSqlUpdate.compile();
      }

      Object[] parameterValues = new Object[] {
          customerType, channelCode};
      _LOGGER.info("****************parameterValues" + parameterValues);
      int insCount = insertEMediaCustomerSqlUpdate.update(parameterValues);
      if (insCount > 0) {
        _LOGGER.info(
            "Insert EMediaCustomer Response logged successfully \n Number of Records inserted - " +
            insCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertEMediaCustomerSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("insertEMediaCustomerSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaCustomerDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertEMediaCustomer");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param customerType String
   * @return boolean
   * @throws Exception
   */

  public Map deleteEMediaCustomer(EMediaCustomer eMediaCustomer) throws
      NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String customerType = eMediaCustomer.getCustomerType();
    String DELETE_EMEDIA_CUSTOMER = "DELETE FROM " + getSchemaName() +
        ".EMEDIA_CUSTOMER WHERE CUSTOMER_TYPE = ?";
    _LOGGER.info("Delete SQL: " + DELETE_EMEDIA_CUSTOMER);
    try {
      if (deleteEMediaCustomerSqlUpdate == null) {
        deleteEMediaCustomerSqlUpdate = new SqlUpdate(jdbcTemplate.
            getDataSource(),
            DELETE_EMEDIA_CUSTOMER);
        deleteEMediaCustomerSqlUpdate.declareParameter(new SqlParameter(
            "CUSTOMER_TYPE", Types.VARCHAR));
        deleteEMediaCustomerSqlUpdate.compile();
      }

      Object[] parameterValues = new Object[] {
          customerType};
      int deleteCount = deleteEMediaCustomerSqlUpdate.update(
          parameterValues);
      if (deleteCount > 0) {
        _LOGGER.info(
            "Delete EMedia Customer Response logged successfully \n Number of Records deleted - " +
            deleteCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("deleteEMediaCustomerSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("deleteEMediaCustomerSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaCustomerDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting deleteEMediaCustomer");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param eMediaCustomer EMediaCustomer
   * @return boolean
   * @throws Exception
   */

  public Map updateEMediaCustomer(EMediaCustomer eMediaCustomer) throws
      NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String customerType = eMediaCustomer.getCustomerType();
    String channelCode = CommonUtil.getCSVStringFromList(eMediaCustomer.getChannelCode());
    String UPDATE_EMEDIA_CUSTOMER_LINK = "UPDATE " + getSchemaName() +
        ".EMEDIA_CUSTOMER SET CUSTOMER_TYPE = ?,CHANNEL_CODE = ?";
    _LOGGER.info("Update SQL: " + UPDATE_EMEDIA_CUSTOMER_LINK);
    try {
      if (updateEMediaCustomerSqlUpdate == null) {
        updateEMediaCustomerSqlUpdate = new SqlUpdate(jdbcTemplate.
            getDataSource(), UPDATE_EMEDIA_CUSTOMER_LINK);
        updateEMediaCustomerSqlUpdate.declareParameter(new SqlParameter(
            "CUSTOMER_TYPE",
            Types.VARCHAR));
        updateEMediaCustomerSqlUpdate.declareParameter(new SqlParameter(
            "CHANNEL_CODE", Types.VARCHAR));
        updateEMediaCustomerSqlUpdate.compile();
      }

      Object[] parameterValues = new Object[] {
          customerType, channelCode};
      int updateCount = updateEMediaCustomerSqlUpdate.update(
          parameterValues);
      if (updateCount > 0) {
        _LOGGER.info(
            "Update EMedia Customer Response logged successfully \n Number of Records updated - " +
            updateCount);
        status = true;
      }
      else {
        Boolean satusObj = (Boolean) insertEMediaCustomer(
            eMediaCustomer).get("status");
        status = satusObj.booleanValue();
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("updateEMediaCustomerSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("updateEMediaCustomerSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaCustomerDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting updateEMediaCustomer");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param customerType String
   * @return EMediaCustomer
   * @throws NCASException
   */
  public Map selectEMediaCustomer(EMediaCustomer eMediaCustomer) throws
      NCASException {
	final Map responseMap = new HashMap();
    String customerType = eMediaCustomer.getCustomerType();
    String SELECT_EMEDIA_CUSTOMER =
        "SELECT CUSTOMER_TYPE, CHANNEL_CODE FROM " + getSchemaName() +
        ".EMEDIA_CUSTOMER WHERE CUSTOMER_TYPE ='" + customerType + "'";
    _LOGGER.info("Select SQL: " + SELECT_EMEDIA_CUSTOMER);
    try {
      jdbcTemplate.query(SELECT_EMEDIA_CUSTOMER, new RowCallbackHandler() {
        public void processRow(ResultSet rs) throws SQLException {
          String key = rs.getString("CUSTOMER_TYPE");          String channelCode = rs.getString("CHANNEL_CODE");          EMediaCustomer cust = new EMediaCustomer(key,CommonUtil.getListFromCSVString(channelCode));
          responseMap.put(key,cust);        }
      });
    }
    catch (Exception vamEx) {
      _LOGGER.debug("selectEMediaCustomer in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("selectEMediaCustomer in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaCustomerDAOImpl.class, vamEx);
    }
    _LOGGER.debug("responseMap" + responseMap);
    return responseMap;
  }

  /**
   *
   * @return Map
   * @throws NCASException
   */
  public Map selectALL_EMediaCustomer() throws
      NCASException {
	final Map responseMap = new HashMap();
    String SELECT_EMEDIA_CUSTOMER =
        "SELECT CUSTOMER_TYPE, CHANNEL_CODE FROM " + getSchemaName() +
        ".EMEDIA_CUSTOMER";
    _LOGGER.info("Select SQL: " + SELECT_EMEDIA_CUSTOMER);
    try {        jdbcTemplate.query(SELECT_EMEDIA_CUSTOMER, new RowCallbackHandler() {          public void processRow(ResultSet rs) throws SQLException {            String key = rs.getString("CUSTOMER_TYPE");            String channelCode = rs.getString("CHANNEL_CODE");            EMediaCustomer cust = new EMediaCustomer(key,CommonUtil.getListFromCSVString(channelCode));            responseMap.put(key,cust);                      }        });      }      catch (Exception vamEx) {        _LOGGER.debug("selectALL_EMediaCustomer in VAM Failed \n" +                      vamEx.getMessage());        _LOGGER.error("selectALL_EMediaCustomer in VAM Failed \n" +                      vamEx.getMessage());        throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,EMediaCustomerDAOImpl.class, vamEx);      }      _LOGGER.debug("responseMap" + responseMap);      return responseMap;
  }

  /* INSERT, UPDATE, DELETE, SELECT for EMEDIA_CUSTOMER Table  -  END */

  private String getSchemaName() {
    String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
    //String schemaName = "BMGVZS";
    _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
    return schemaName;
  }
}
