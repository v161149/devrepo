package com.verizon.enterprise.ncasbosi.dao.Impl.payments;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.apache.log4j.Logger;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.BillViewPagination;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.exception.InvalidPaymentException;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.exception.PaymentException;
import com.verizon.enterprise.common.ncas.payments.GlobalPay;
import com.verizon.enterprise.common.ncas.payments.GlobalSub;
import com.verizon.enterprise.common.ncas.payments.PaymentDetails;
import com.verizon.enterprise.common.ncas.payments.PaymentProfile;
import com.verizon.enterprise.common.ncas.payments.PaymentResponse;
import com.verizon.enterprise.common.ncas.payments.RecurPayment;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.PaymentsUIInterface;
import com.verizon.enterprise.common.ncas.payments.Pay;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.VisionPaymentsStatusInfo.PaymentStatusReturn;


public class PaymentsUIImpl extends PaymentsDAOImpl implements NCASBOSIConstants,PaymentsUIInterface {

	private static final Logger _LOGGER = Logger.getLogger(PaymentsUIImpl.class);

	enum StatusList
	{
	  A,
	  F
	}


	public Map<String,Object> addPaymentProfile(PaymentProfile profile) throws PaymentException,NCASException {
		final String METHOD_NAME = "addPaymentProfile => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		boolean status = false;
		Map<String,Object> responseMap = new HashMap<String, Object>();
		if(profile!=null)
		{
			_LOGGER.info(METHOD_NAME+"Profile:"+profile.toString());
			try
			{
				String maskedAcctNum = "";
				String safeKey = "";
				if (profile.getEaasFlag() == false)
				{
					PaymentResponse payResponse = webImpl.managePaymentProfile(profile);
					_LOGGER.info(METHOD_NAME+"Succesfully added payment profile information to ePayments for the user:"+profile.getPortalLoginID());
					safeKey = payResponse.getSafeKey();
					_LOGGER.debug(METHOD_NAME+"Payment Type::"+profile.getPaymentType());
					if(profile.getPaymentType().equalsIgnoreCase(BANK_EFT_PAYMENT_TYPE))
						maskedAcctNum = CommonUtil.bankAcctMask(CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
					else maskedAcctNum = CommonUtil.creditCardMask(CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
					_LOGGER.info(METHOD_NAME+"Masked Acct Number:"+maskedAcctNum);
					_LOGGER.info(METHOD_NAME+"Safekey:" + safeKey);
				}
				else
				{
					maskedAcctNum = profile.getMaskedAcctNum();
					safeKey = profile.getSafeKey();
				}
				insertPaymentProfile(profile, safeKey, maskedAcctNum, false);
				status = true;
				if (profile.getEaasFlag() == true)
				{
					responseMap.put("paymentProfileId", new Integer(profile.getProfileID()));
				}
			}
			catch(PaymentException ex)
			{
				throw ex;
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
			}
		}
		responseMap.put("status",new Boolean(status));
		_LOGGER.info(METHOD_NAME+" Exiting");
		return responseMap;
	}

	public Map<String,Object> updatePaymentProfile(PaymentProfile profile ) throws PaymentException,NCASException
	{
		final String METHOD_NAME = "updatePaymentProfile => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		boolean status = false;
		Map<String,Object> responseMap = new HashMap<String, Object>();
		if(profile!=null&&isUserTheProfileOwner(profile.getUserOid(), profile.getProfileID()))
		{
			try
			{
				_LOGGER.info(METHOD_NAME+"Payment Profile::"+profile.toString());
				if(!profile.isLocalizedOnly()){
					PaymentResponse payResponse = webImpl.managePaymentProfile(profile);
					_LOGGER.info(METHOD_NAME+"Succesfully updated payment profile information to ePayments:"+profile.getProfileID());
					String maskedAcctNum = "";
					_LOGGER.debug(METHOD_NAME+"Payment Type::"+profile.getPaymentType());
					if(profile.getPaymentType().equalsIgnoreCase(BANK_EFT_PAYMENT_TYPE))
						maskedAcctNum = CommonUtil.bankAcctMask(CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
					else maskedAcctNum = CommonUtil.creditCardMask(CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
					updatePaymentProfile(profile,payResponse.getSafeKey(),maskedAcctNum,payResponse.getEpResponseCode(),payResponse.getEpResponseText());
					_LOGGER.info(METHOD_NAME+"Updated the payment profile::"+profile.getProfileID());
				}
				else updatePaymentProfileLocalized(profile);
				if(!profile.getUpdateType().equals(""))
				{
					updateRecurPaymentForProfile(profile.getProfileID(), profile.getUpdateType(),profile.getPortalLoginID());
					_LOGGER.info(METHOD_NAME+"updatedRecurPaymentForProfile for the profile::"+profile.getProfileID());
				}
				status = true;
			}
			catch(PaymentException ex){
				throw ex;
			}
			catch(Exception ex) {
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
			}
		}
		responseMap.put("status",new Boolean(status));
		_LOGGER.info(METHOD_NAME+" Exiting");
		return responseMap;
	}



	public Map<String,Boolean> deletePaymentProfile(PaymentProfile profile) throws PaymentException,NCASException
	{
		final String METHOD_NAME = "deletePaymentProfile => ";
		_LOGGER.info(METHOD_NAME + " Entering");
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		_LOGGER.info(METHOD_NAME+"userOid::"+profile.getUserOid()+"::   profileID:"+profile.getProfileID());
		if(profile!=null&&isUserTheProfileOwner(profile.getUserOid(), profile.getProfileID()))
		{
			_LOGGER.info(METHOD_NAME+"Yes the user is the profile owner");
			_LOGGER.info(METHOD_NAME+"Payment Profile::"+profile.toString());
			List<Integer> profileIDList = new ArrayList<Integer>();
			profileIDList.add(profile.getProfileID());
			SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			_LOGGER.info(METHOD_NAME+"About to update profile status to Cancelled:"+profile.getProfileID());
			responseMap = updatePayProfileStatus(profileIDList,NcasConstants.PROFILE_STATUS_CANCELLED,"This payment account was cancelled on "+df.format(new java.util.Date()));
			cancelRecurPaymentForProfile(profile.getProfileID(),profile.getPortalLoginID());
			_LOGGER.info(METHOD_NAME+"Cancelled related recurring payments for profile:"+profile.getProfileID());
			status = true;
		}else{
			_LOGGER.info(METHOD_NAME+"Either the profile obj is null or the user is not the actual owner of the profile.");
		}
		responseMap.put("status", new Boolean(status));

		_LOGGER.info(METHOD_NAME + " Exiting");
		return responseMap;
	}


	public Map<String,String> addPayments(List<Pay> payments,String paymentType) throws PaymentException,NCASException{
		final String METHOD_NAME = "addPayments => ";
		_LOGGER.info(METHOD_NAME + " Entering");
		String portalTrackID = "";
		String paymentTotal = "";
		Map<String,String> responseMap = new HashMap<String,String>();
		int paymentSize = 0;
		boolean realTimePay = false;
		try{
			if(payments!=null && payments.size()>0)
			{
				paymentSize = payments.size();
				_LOGGER.info(METHOD_NAME+"Payments Size::"+paymentSize);
				PaymentProfile payProfile = (selectPaymentProfileDetails(payments.get(0).getProfileID()).get("paymentProfile"));
				_LOGGER.info(METHOD_NAME+"Payment Profile::"+payProfile.toString());
				Pay firstPmnt = payments.get(0);
				int track = insertPaymentTransaction(firstPmnt,paymentType,payProfile);
				_LOGGER.info(METHOD_NAME+"track::"+track);
				portalTrackID = "PAY"+String.valueOf(track);

				if(track>=0){
					if(paymentType.equalsIgnoreCase(NcasConstants.PAYMENT_TYPE_ONETIME))
					{
						if(firstPmnt.getVzbVzwFlag().equalsIgnoreCase(VZB_VZW_FLAG_VZB) && paymentSize<=10 && payProfile.getPaymentType().equals(CREDIT_CARD_PAYMENT_TYPE ))
							realTimePay = true;
						_LOGGER.info(METHOD_NAME+"About to insert "+paymentSize+" onetime payments");
						paymentTotal = insertPaymentDetails(payments,track,payProfile,realTimePay);
						_LOGGER.info(METHOD_NAME+"Done inserting "+paymentSize+" onetime payments");
						if(realTimePay)
						{
							_LOGGER.info(METHOD_NAME+"Yes paysize is lessthan or equal to 10 and the payment type is credit card.");
							sendImmediatePayment(payProfile,payments, track);
							_LOGGER.info(METHOD_NAME+"Done calling sendImmediatePayments.");
						}

					}
					else
					{
						_LOGGER.info(METHOD_NAME+"About to insert "+paymentSize+" recur payments");
						insertRecurPayment(payments, track, payProfile);
						_LOGGER.info(METHOD_NAME+"Done inserting "+paymentSize+" recur payments");
						if (isRecurPayEaaS((RecurPayment)payments.get(0)))
						{
							responseMap.put("status", "true");
							responseMap.put("recurPayId", portalTrackID);
						}
					}
				}
			}
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}


		if(!paymentTotal.isEmpty())
		{
			_LOGGER.info(METHOD_NAME+"The paymentTotal is::"+paymentTotal);
			responseMap.put("paymentAmount",paymentTotal);
		}
		responseMap.put("trackId",portalTrackID);

		_LOGGER.info(METHOD_NAME + " Exiting");
		return responseMap;
	}

	public Map<String,String> addGCPPayments(GlobalPay globalPay) throws PaymentException,NCASException{
		final String METHOD_NAME = "addPayments => ";
		_LOGGER.info(METHOD_NAME + " Entering");
		String portalTrackID = "";
		int globalPayId = -1;
		String paymentTotal = "";
		List<GlobalSub> globalSubs = null;
		Map<String,String> responseMap = new HashMap<String,String>();
		try{
			if(globalPay!=null)
			{
				//As of now GCP just deals with onetime payments..in future once the recurring type is added this If needs to
				//be moved down to where the insert in to gcp_subs happens.
				PaymentProfile payProfile = selectPaymentProfileDetails(globalPay.getProfileID()).get("paymentProfile");
				_LOGGER.info(METHOD_NAME+"Payment Profile::"+payProfile.toString());

				int track = insertPaymentTransaction(globalPay,NcasConstants.PAYMENT_TYPE_ONETIME,payProfile);
				_LOGGER.info(METHOD_NAME+"track::"+track);
				portalTrackID = "PAY"+String.valueOf(track);

				if(track>=0){
						_LOGGER.info(METHOD_NAME+"About to insert global onetime payment");
						globalPayId = insertGlobalPaymentDetails(globalPay,track,payProfile);
						_LOGGER.info(METHOD_NAME+"Done inserting global onetime payment");
						if(globalPayId>=0)
						{
							_LOGGER.info(METHOD_NAME+"About to insert global sub payment");
							globalSubs = new ArrayList<GlobalSub>();
							globalSubs.addAll(globalPay.getSubs().values());
							insertGlobalSubPaymentDetails(globalSubs,globalPayId,payProfile);
							_LOGGER.info(METHOD_NAME+"Done inserting global sub payment");
						}

					}
				}
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}

		responseMap.put("trackId",portalTrackID);

		_LOGGER.info(METHOD_NAME + " Exiting");
		return responseMap;
	}

	public void  sendImmediatePayment(PaymentProfile payProfile,List<Pay> payments, int portalTrackingId) throws NCASException, Exception
	{
		final String METHOD_NAME = "sendImmediate=> ";
		_LOGGER.info(METHOD_NAME+" Entering");

		PaymentResponse payResponse = null;
		PaymentDetails payDetails = null;
		int paySize = payments.size();
		_LOGGER.info(METHOD_NAME+" The number of payments is:"+paySize);
		if(((PaymentDetails)payments.get(0)).getVzbVzwFlag().equals(NcasConstants.VZB_VZW_FLAG_VZB)){
			SimpleDateFormat df1 = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");

				int payId = 0;
				for(int i = 0;i<paySize;i++)
				{
					try{
								payDetails = (PaymentDetails)payments.get(i);
								payDetails.setPortalTrackID(portalTrackingId);
								payId = payDetails.getPaymentID();
								if(payDetails.getInvoiceDate()!=null)
									payDetails.setInvoiceDate(new String(df2.format(df1.parse(payDetails.getInvoiceDate()))));
								payResponse = webImpl.managePayment(payDetails,payProfile, NcasConstants.PAYMENT_TYPE_ONETIME);
								_LOGGER.info(METHOD_NAME+"Successfully sent payId:: "+payId+":: payment to EPayments");
								updateSuccessResponse(payResponse,payDetails,NcasConstants.PAY_DETAILS_PROCESSED_STATUS,NcasConstants.ONLINE_RT_PAYMENT,payProfile.getNickName());

					}catch(InvalidPaymentException iex){
						PaymentResponse payResp = iex.getPaymentResponse("");
						updateFailureResponse(payResp,payDetails,NcasConstants.PAY_DETAILS_FAILED_STATUS,NcasConstants.ONLINE_RT_PAYMENT);
					}catch(PaymentException pex){
						_LOGGER.error(METHOD_NAME+" PaymentException  in NCASBOSI : \n" +pex.getMessage());
						updateErrorDescForPayment(pex.getMessage(),payDetails,NcasConstants.ONLINE_RT_PAYMENT);
					}catch(Exception ex){
						_LOGGER.error(METHOD_NAME + "::   Inner Loop Failed \n"+ex.getMessage());
						insertPaymentEmail(payDetails, payDetails.getNickName(),PORTAL_BILLING_NOTIF_TEMPLATE,payDetails.getLoginId(),METHOD_NAME,"","Exception Inner Loop Processing ::"+METHOD_NAME+"::"+ex.getMessage(),payDetails.getEpResponseCode(),Integer.toString(payDetails.getPortalTrackID()),NcasConstants.ONLINE_RT_PAYMENT);
					}
					
				}
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}




	public Map<String,Boolean>  editPayment(RecurPayment payment) throws PaymentException,NCASException
	{
		final String METHOD_NAME = "editPayment => ";
		_LOGGER.debug(METHOD_NAME + " Entering");
		try{
			RecurPayment oldRecurPayment=(RecurPayment)(selectRecurPaymentIDDetails(payment.getPaymentID()).get("recurPaymentDetails"));
			_LOGGER.info(METHOD_NAME+"Old Recur Payment:"+oldRecurPayment.toString());
			payment.setServiceID(oldRecurPayment.getServiceID());
			payment.setPortalTrackID(oldRecurPayment.getPortalTrackID());
			}catch(Exception nex){
			_LOGGER.error(METHOD_NAME + " Failed \n"+nex.getMessage());
		}
		_LOGGER.info(METHOD_NAME +"New Recur Payment:"+payment.toString());
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		boolean status = false;
	    try {
			//Extra layer of security to check whether the user who is updating actually
			//owns this profile or not. If not, we return false;
	    	int profileId = payment.getProfileID();
	    	double userOid = payment.getUserOID();
			if(isUserTheProfileOwner(userOid, profileId))
			{
				_LOGGER.info(METHOD_NAME+"Yes the user::"+userOid+"  is the onwer of the pay profile::"+profileId+"    So Updating the recurpaymentId:"+payment.getPaymentID());
				updateRecurPayment(payment);
				 status = true;
			}
			else{
				_LOGGER.info(METHOD_NAME+"The user::"+userOid+" is not the actual profile owner for profile::"+profileId+" . So the recur payment cannot be updated.");
			}
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}

		_LOGGER.info(METHOD_NAME + " Exiting");

		responseMap.put("status",new Boolean(status));
		return responseMap;
	}


	public Map<String,Boolean>  deletePayment(RecurPayment payment,String paymentType) throws PaymentException,NCASException
	{
		final String METHOD_NAME = "deletePayment => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME+"PaymentType::"+paymentType);
		_LOGGER.info(METHOD_NAME+"RecurPayment::"+payment.toString());

		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		boolean status = false;
	    try {
	    	Map<String,RecurPayment> returnMap = selectRecurPaymentIDDetails(payment.paymentID);
	    	_LOGGER.info(METHOD_NAME+"Deleting the recurpaymentId:"+payment.paymentID);
	    	RecurPayment recurRecord = (returnMap.get("recurPaymentDetails"));
	    	cancelRecurPayment(recurRecord);
	    	_LOGGER.info(METHOD_NAME+"Deleted the recurpaymentId:"+payment.paymentID);
			status = true;
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME+"Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}

		_LOGGER.info(METHOD_NAME+"Exiting");

		responseMap.put("status",new Boolean(status));
		return responseMap;
	}


	public Double getWirelessRealTimeBalance(String accountNumber) throws PaymentException,NCASException
	{
		final String METHOD_NAME = "getWirelessRealTimeBalance => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME+"accountNumber:"+accountNumber);

		Double retValue = 0.0;
		try{
			retValue = webImpl.getWirelessRealTimeBalance(accountNumber);
			_LOGGER.info(METHOD_NAME+"For accountnumber:"+accountNumber+" the real time balance being returned:: "+ retValue);
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retValue;
	}


	public Content getPaymentHistory(String accountNumber,String startDate,String endDate) throws PaymentException,NCASException
	{
		final String METHOD_NAME = "getPaymentHistory => ";
		_LOGGER.info(METHOD_NAME+"accountNumber:"+accountNumber+"::startDate::"+startDate+"::endDate::"+endDate);
		Content retValue = null;
		try{
			List hist  = webImpl.getPaymentHistory(accountNumber, startDate, endDate);
			retValue = getContent(hist);
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}

		return retValue;
	}
	public Content getContent(List<Object> wirelessList) {
		Content content = new Content();
		List<List> rowList = new ArrayList<List>();
		List<Cell> headerList = new ArrayList<Cell>();

		headerList.add(returnCell("PaymentType", "Payment Type", "CHAR", false));
		headerList.add(returnCell("PaymentDate", "Payment Date", "DATE", false));
		headerList.add(returnCell("PaymentAmount", "Payment Amount", "NUMBER", false));
		headerList.add(returnCell("ICON", "", "ICON", true));
		headerList.add(returnCell("PaymentStatus", "Payment Status", "CHAR", false));

		rowList.add(headerList);
		for (Object wList : wirelessList) {
			rowList.add(getWirelessList((PaymentStatusReturn) wList));
			// content.setRows(rowList);
		}
		content.setRows(rowList);
		int  totalRows = rowList.size()-1;
		BillViewPagination wirelessPagination = new BillViewPagination();
		wirelessPagination.updateCurrentPageFromServer(totalRows, totalRows,0) ;
		content.setPagination(wirelessPagination);
		content.setPaginate("N");
		return content;
	}
	public Cell returnCell(String name, String Value, String Type, boolean isNotHeader) {
		Cell cell = new Cell(Value);
			if(isNotHeader) {
				cell.setFormat(Type);
			}
			else {
				cell.setFormat("COL_HDR");
			}
			cell.setName(name);
			cell.setType(Type);
			cell.setSortAble("N");
			cell.setFilterAble("N");
	  return cell;
	}
	public  List<Cell> getWirelessList(PaymentStatusReturn paymentStatusReturn) {

		List<Cell> rowList = new ArrayList<Cell>();
		String sourceCode = paymentStatusReturn.getSourceCode();
		String statusValue = paymentStatusReturn.getPaymentStatusCode();
		String paymentType = "Recurring";
		String statusCode = "Processed";
		String iconSrc = "billCmpl.gif";
		if(sourceCode!=null)
			sourceCode=sourceCode.trim();

		if(sourceCode.equalsIgnoreCase("EDOAE")||sourceCode.equalsIgnoreCase("EDOAW")||sourceCode.equalsIgnoreCase("EDOAN"))
			paymentType = "One Time";
		rowList.add(returnCell("paymenttype", paymentType, "CHAR", true));
		rowList.add(returnCell("paymentdate", paymentStatusReturn.getActionDate(), "DATE", true));
		rowList.add(returnCell("paymentamount", paymentStatusReturn.getPaymentAmount(), "NUMBER", true));
		switch(StatusList.valueOf(statusValue.toUpperCase())) {
		 case F :
			 statusCode = "Failed";
			 iconSrc = "billFail.gif";
		}
		rowList.add(returnCell("icon", iconSrc, "ICON", true));
		rowList.add(returnCell("status", statusCode, "CHAR", true));
		return rowList;
	}


	public String getTermsConditions(double userOid, String vzbvzwFlag, String paymentType,String paymentMethod)throws PaymentException,NCASException
	{
		final String METHOD_NAME = "getTermsConditions =>";
		_LOGGER.info(METHOD_NAME+"userOid::"+userOid+"vzbvzwFlag::"+vzbvzwFlag+"::paymentType:::"+paymentType+"::paymentMethod:::"+paymentMethod);
		_LOGGER.info(METHOD_NAME+"Entering");
		String termsText = null;
		try{
			List<Double> ecpdIdList = DAOFactory.getInstance().getPaymentsBeanForECP().selectAllECPDIdsForUser(userOid);
			if(ecpdIdList.size()>0)
			{
				_LOGGER.info(METHOD_NAME+"ecpdIdList::"+ecpdIdList);
				termsText = getTermsConcatenatedText(ecpdIdList,paymentType,paymentMethod);
			}


			if(termsText!=null && termsText.length()>0)
			{
				_LOGGER.info(METHOD_NAME+"Exiting");
				return termsText;
			}
			else
			{
				_LOGGER.info(METHOD_NAME+"The user doesn't have any terms specific. Getting default terms based on paymentType and vzbvzw flag");
				ecpdIdList = new ArrayList<Double>();
				_LOGGER.info(METHOD_NAME+"vzbvzwFlag:"+vzbvzwFlag);
				if(vzbvzwFlag.equalsIgnoreCase(NcasConstants.VZB_VZW_FLAG_VZW))
				{
					_LOGGER.info(METHOD_NAME+"paymentType:"+paymentType);
					if(paymentType.equalsIgnoreCase(NcasConstants.PAYMENT_TYPE_ONETIME))
					{
						ecpdIdList.add(new Double(NCASBOSIConstants.VZW_ONETIME_ECPDID));
					}else
					{
						ecpdIdList.add(new Double(NCASBOSIConstants.VZW_RECUR_ECPDID));
					}
				}
				else
				{
					_LOGGER.info(METHOD_NAME+"No terms specifically for vzb");
					return "";
				}
				_LOGGER.info(METHOD_NAME+"ecpdIdList::::"+ecpdIdList);
				termsText = getTermsConcatenatedText(ecpdIdList,paymentType,paymentMethod);
				_LOGGER.info(METHOD_NAME+"Exiting getTermsConditions ");
			}
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,errMsg,ex);
		}

		_LOGGER.info(METHOD_NAME + " Exiting");
		return termsText;
	}



	  public Map<String,Boolean> anyDuplicatePayments(Map<String,Object> recurPayInfo)throws PaymentException,NCASException
	  {
		  final String METHOD_NAME = "anyDuplicatePayments => ";
		  _LOGGER.info(METHOD_NAME + " Entering");

		  Map<String,Boolean> dupMap = selectDuplicatePayments(recurPayInfo);
		  _LOGGER.info(METHOD_NAME+" dupMap->"+dupMap);
		  _LOGGER.info(METHOD_NAME + " Exiting");
		  return dupMap;
	  }

	  public Map<String,List<String>> selectCurrencyCountryDtls() throws NCASException
	  {
			final String METHOD_NAME = "selectCurrencyCountryDtls => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			_LOGGER.info(METHOD_NAME+ "Select SQL: " + SELECT_CURRENCY_COUNTRY_DTLS);
			SelectCurrencyCountryDtls selectCurrencyCountryDtls = new SelectCurrencyCountryDtls(SELECT_CURRENCY_COUNTRY_DTLS);
			Map<String,List<String>> finalCurCountryMap = new HashMap<String,List<String>>();
			Map<String,List<String>> curCountryMap = selectCurrencyCountryDtls.getCurrencyCountryList(new Object[]{});
			finalCurCountryMap.putAll(curCountryMap);
			_LOGGER.info(METHOD_NAME+" Currency Country Details Map::"+finalCurCountryMap);
			return finalCurCountryMap;
	  }

	  public Map<Map<String, String>, List<PaymentProfile>> getRecurPaymentInfo(List<Map<String, String>> inpList) throws NCASException
	  {
			final String METHOD_NAME = "getRecurPaymentInfo => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			Map<Map<String, String>, List<PaymentProfile>> responseMap = new HashMap<Map<String, String>, List<PaymentProfile>>();
			if (inpList!=null)
			{
				_LOGGER.info(METHOD_NAME + "Input List Size=" + inpList.size());

				try
				{
					responseMap = getRecurPayDetails(inpList);
				}
				catch(PaymentException ex)
				{
					throw ex;
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					String[] errMsg = new String[2];
				    errMsg[0] = METHOD_NAME;
				    errMsg[1] = ex.getMessage();
					_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
					throw new PaymentException(PAYMENT_EXCEPTION_950,errMsg,ex);
				}
			}
			_LOGGER.info(METHOD_NAME+" Exiting");
			return responseMap;
	  }
}





