package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.bills.InvoiceTypeHelper;

public class GetEMediaSummaryRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaSummaryRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetEMediaSummaryRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();

		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = null;
		String key = "";

		try{
			while(rs.next()) {
				emediaRecord = new EMediaRecord();

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");
				String ban = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String man = rs.getString("MAN");
				String manDan = rs.getString("MAN_DAN");
				String tnType = rs.getString("TN_TYPE");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String startBillPeriod = rs.getString("START_BP_DATE");
				String endBillPeriod = rs.getString("END_BP_DATE");
				//String backEndSYstem = rs.getString("BACKEND_SYSTEM");
				String accountName = rs.getString("ACCT_NAME");
				String billPeriod = rs.getString("BILL_PERIOD");
				String verified = rs.getString("VERIFIED_FLAG");
				String mediaType = rs.getString("BM_MEDIA_TYPE");
				String bmCustConfig = rs.getString("BM_CUST_CONFIG_ID");
				String bmNatlInd = rs.getString("BM_NATL_IND");
				String ediNatlInd = rs.getString("EDI_NATL_IND");
				String vz450NatlInd = rs.getString("VZ450_NATL_IND");
				String edi05 = rs.getString("EDI_PROD_ISA_05");
				String edi06 = rs.getString("EDI_PROD_ISA_06");
				String edi02 = rs.getString("EDI_PROD_GS_02");
				String channelDesc = rs.getString("CHANNEL_DESC");
				String channelCode = rs.getString("CHANNEL_CODE");
				String ediDeliveryOption = rs.getString("EDI_DELIV_OPT");
				String ediDataGroup = rs.getString("EDI_DATA_GROUP");
				String vz450DeliveryOption = rs.getString("VZ450_DELIV_OPT");
				String vz450CustConfig = rs.getString("VZ450_CUST_CFG_ID");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String paperSuppressInd = rs.getString("PAPER_SUPPRESS_IND");
				String paperChargeCode = rs.getString("PAPER_CHARGE_CODE");
				String paperChargeDesc = rs.getString("PAPER_CHARGE_DESC");
				String ebid = rs.getString("EBID");
				String nationalAccount = rs.getString("NBBE_ACCT_NUM");
				acctSubscriptionOid = rs.getDouble("ACCT_SUBS_OID");
				String callDetailStatus = rs.getString("CALL_DTL_STATUS");
				String invoiceRptStatus = rs.getString("INV_RPT_STATUS");

				String contractAmendFlag = rs.getString("PAP_CONTRACT_AMEND");
				String softwareVersion = rs.getString("SOFTWARE_VER");
				String internationalInd = rs.getString("INTERNATIONAL_IND");
                String invoiceType = rs.getString("INVOICE_TYPE");
                
				if(CommonUtil.isNotNull(origSysId)) {emediaRecord.setOrigSysId(origSysId.trim());}
				if(CommonUtil.isNotNull(enterpriseId)) {emediaRecord.setEnterprise(enterpriseId.trim());}
				if(CommonUtil.isNotNull(corpId)) {emediaRecord.setCorp(corpId.trim());}
				if(CommonUtil.isNotNull(ban)) {emediaRecord.setBan(ban.trim());}
				if(CommonUtil.isNotNull(banDan)) {emediaRecord.setBan_dan(CommonUtil.getFormattedAccount(banDan.trim(),emediaRecord.getOrigSysId(), ""));}
				if(CommonUtil.isNotNull(man)) {emediaRecord.setMan(man.trim());}
				if(CommonUtil.isNotNull(manDan)) {emediaRecord.setMan_dan(CommonUtil.getFormattedAccount(manDan.trim(),emediaRecord.getOrigSysId(), ""));}
				if(CommonUtil.isNotNull(tnType)) {emediaRecord.setTnType(tnType.trim());}

				if(CommonUtil.isNotNull(startBillPeriod)) {emediaRecord.setStartBillPeriod(startBillPeriod.trim());}
				if(CommonUtil.isNotNull(endBillPeriod)) {emediaRecord.setEndBillPeriod(endBillPeriod.trim());}
				if(CommonUtil.isNotNull(accountName)) {emediaRecord.setAccountName(accountName.trim());}
				if(CommonUtil.isNotNull(billPeriod)) {emediaRecord.setBillPeriod(billPeriod.trim());}
				if(CommonUtil.isNotNull(verified)) {emediaRecord.setVerified(verified.trim());}
				if(CommonUtil.isNotNull(mediaType)) {emediaRecord.setMediaType(mediaType.trim());}
				if(CommonUtil.isNotNull(bmCustConfig)) {emediaRecord.setCustConfigId(bmCustConfig.trim());}
				if(CommonUtil.isNotNull(bmNatlInd)) {emediaRecord.setBmNatlInd(bmNatlInd.trim());}
				if(CommonUtil.isNotNull(ediNatlInd)) {emediaRecord.setEdiNatlInd(ediNatlInd.trim());}
				if(CommonUtil.isNotNull(vz450NatlInd)) {emediaRecord.setVz450NatlInd(vz450NatlInd.trim());}
				if(CommonUtil.isNotNull(edi05)) {emediaRecord.setEdi05(edi05.trim());}
				if(CommonUtil.isNotNull(edi06)) {emediaRecord.setEdi06(edi06.trim());}
				if(CommonUtil.isNotNull(edi02)) {emediaRecord.setEdi02(edi02.trim());}
				if(CommonUtil.isNotNull(channelCode)) {emediaRecord.setChannelCode(channelCode.trim());}
				if(CommonUtil.isNotNull(channelDesc)) {emediaRecord.setChannelDesc(channelDesc.trim());}
				if(CommonUtil.isNotNull(ediDeliveryOption)) {emediaRecord.setEdiDeliveryOption(ediDeliveryOption.trim());}
				if(CommonUtil.isNotNull(ediDataGroup)) {emediaRecord.setEdiDataGroup(ediDataGroup.trim());}
				if(CommonUtil.isNotNull(vz450DeliveryOption)) {emediaRecord.setVz450DeliveryOption(vz450DeliveryOption.trim());}
				if(CommonUtil.isNotNull(vz450CustConfig)) {emediaRecord.setVz450ConfigId(vz450CustConfig.trim());}
				if(CommonUtil.isNotNull(systemAbbrv)) {emediaRecord.setSystemAbbrv(systemAbbrv.trim());}
				if(CommonUtil.isNotNull(paperSuppressInd)) {emediaRecord.setPaperSuppressInd(paperSuppressInd.trim());}
				if(CommonUtil.isNotNull(ebid)) {emediaRecord.setEbId(ebid.trim());}
				if(CommonUtil.isNotNull(nationalAccount)) {emediaRecord.setNationalSummary(nationalAccount.trim());}
				if(CommonUtil.isNotNull(paperChargeCode)) {emediaRecord.setPaperChargeCode(paperChargeCode.trim());}
				if(CommonUtil.isNotNull(paperChargeDesc)) {emediaRecord.setPaperChargeDesc(paperChargeDesc.trim());}
				if(CommonUtil.isNotNull(callDetailStatus)) {emediaRecord.setCallDetailStatus(callDetailStatus.trim());}
				if(CommonUtil.isNotNull(invoiceRptStatus)) {emediaRecord.setInvoiceRptStatus(invoiceRptStatus.trim());}
				if(CommonUtil.isNotNull(contractAmendFlag)) {emediaRecord.setContractAmendFlag(contractAmendFlag.trim());}
				if(CommonUtil.isNotNull(softwareVersion)) {emediaRecord.setSoftwareVersion(softwareVersion.trim());}
				if(CommonUtil.isNotNull(internationalInd)) {emediaRecord.setInternationalInd(internationalInd.trim());}
                if(CommonUtil.isNotNull(invoiceType)) {emediaRecord.setInvoiceType(invoiceType.trim());}
                
                try
                {
                    InvoiceTypeHelper invoiceTypeHelper = InvoiceTypeHelper.getInstance(); 
                    String invoiceTypeName = invoiceTypeHelper.getInvoiceTypeName(emediaRecord.getInvoiceType());
                    emediaRecord.setInvoiceTypeName(invoiceTypeName);
                }
                catch (Exception e)
                {
                    SQLException newException = new SQLException(e.getMessage());
                    throw newException;
                }
                
				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				emediaRecord.setAcctSubscriptionOid(key);

				if(previousOid!=acctSubscriptionOid){
					refList = new ArrayList();
					returnMap.put(key,refList);
				}
				refList.add(emediaRecord);
				previousOid = acctSubscriptionOid;
			}
			_LOGGER.debug("emedia record " + emediaRecord);

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			return returnMap;
		}
}
