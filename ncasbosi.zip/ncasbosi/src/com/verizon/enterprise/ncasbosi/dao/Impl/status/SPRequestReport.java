package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.Types;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.vzbreports.ScheduleReportData;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;


public class SPRequestReport extends BaseStoredProcedure {

	static private final Logger logger = Logger.getLogger(SPRequestReport.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SCHEDULED_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"EMPLOYEE_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PORTAL_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"EMAIL_ADDRESS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SELECTION_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_TYPE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCT_LIST_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCT_LIST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIBER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIPTION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FREQUENCY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SCHEDULED_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"THRU_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_NUMBER ", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"WHERE_PHRASE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDITIONAL_PARMS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"FTP_USERID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_PASSWORD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_HOST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_DIRECTORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_FILENAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DATAFORMAT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STRUCTURE_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STRUCTURE_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"POSITION_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"POSITION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPRequestReport(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_REQUEST_REPORT_DL, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel,Map inputMap)throws Exception
	{
		String METHOD_NAME = "SPRequestReport::executeStoredProcedure";
		logger.info("ENTER " + METHOD_NAME);

		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();

		logger.info(METHOD_NAME + "REQUEST_REPORT_DL SP Params - Input Map=" +  inputMap.toString());

		//get all the parameters from input map
		paramValueList.add(userId); //APP_USER_ID
		logger.debug(METHOD_NAME + " userId=" + userId );

		paramValueList.add(debugLevel); //DEBUG_LEVEL
		logger.debug(METHOD_NAME + " debugLevel=" + debugLevel );

		String action = (String) inputMap.get("action");
		paramValueList.add(action); //ACTION
		logger.debug(METHOD_NAME + " action=" + action );

		String scheduledInd = (String) inputMap.get("scheduled_ind");
		paramValueList.add(scheduledInd); //SCHEDULED_IND
		logger.debug(METHOD_NAME + " scheduledInd=" + scheduledInd );

		String employeeFlag = (String) inputMap.get("employee_flag");
		paramValueList.add(employeeFlag); //EMPLOYEE_FLAG
		logger.debug(METHOD_NAME + " employeeFlag=" + employeeFlag );

		String userOid = (String) inputMap.get("user_oid");
		paramValueList.add(userOid); //USER_OID
		logger.debug(METHOD_NAME + " userOid=" + userOid );

		String portalUserId = (String) inputMap.get("portal_user_id");
		paramValueList.add(portalUserId); //PORTAL_USER_ID
		logger.debug(METHOD_NAME + " portalUserId=" + portalUserId );

		String emailAddress = (String) inputMap.get("email_address");
		paramValueList.add(emailAddress); //EMAIL_ADDRESS
		logger.debug(METHOD_NAME + " emailAddress=" + emailAddress );

		String selectionType = (String) inputMap.get("selection_type");
		paramValueList.add(selectionType); //SELECTION_TYPE
		logger.debug(METHOD_NAME + " selectionType=" + selectionType );

		String billTypeFilter = (String) inputMap.get("bill_type_filter");
		paramValueList.add(billTypeFilter); //BILL_TYPE_FILTER
		logger.debug(METHOD_NAME + " billTypeFilter=" + billTypeFilter );

		String acctListType = (String) inputMap.get("acct_list_type");
		paramValueList.add(acctListType); //ACCT_LIST_TYPE
		logger.debug(METHOD_NAME + " acctListType=" + acctListType );

		String acctListName = (String) inputMap.get("acct_list_name");
		paramValueList.add(acctListName); //ACCT_LIST_NAME
		logger.debug(METHOD_NAME + " acctListName=" + acctListName );

		String subscriberOid = (String) inputMap.get("subscriber_oid");
		paramValueList.add(subscriberOid); //SUBSCRIBER_OID
		logger.debug(METHOD_NAME + " subscriberOid=" + subscriberOid );

		String strSubscriptionOid =  (String) inputMap.get("subscription_oid");
		double subscriptionOid = 0;

		if (strSubscriptionOid != null)
		{
			subscriptionOid = Double.valueOf(strSubscriptionOid).doubleValue();

			DecimalFormat decimalFormatter = new DecimalFormat("##########");
			strSubscriptionOid = decimalFormatter.format(subscriptionOid);
		}

		paramValueList.add(strSubscriptionOid); //SUBSCRIPTION_OID
		logger.debug(METHOD_NAME + " strSubscriptionOid=" + strSubscriptionOid );

		String frequency = (String) inputMap.get("frequency");
		paramValueList.add(frequency); //FREQUENCY
		logger.debug(METHOD_NAME + " frequency=" + frequency );

		String scheduled_date = (String) inputMap.get("scheduled_date");
		paramValueList.add(scheduled_date); //SCHEDULED_DATE
		logger.debug(METHOD_NAME + " scheduled_date=" + scheduled_date );

		String bill_date = (String) inputMap.get("bill_date");
		paramValueList.add(bill_date); //BILL_DATE
		logger.debug(METHOD_NAME + " bill_date=" + bill_date );

		String thru_date = (String) inputMap.get("thru_date");
		paramValueList.add(thru_date); //THRU_DATE
		logger.debug(METHOD_NAME + " thru_date=" + thru_date );

		String reportNumber = (String) inputMap.get("report_number");
		paramValueList.add(reportNumber); //REPORT_NUMBER
		logger.debug(METHOD_NAME + " reportNumber=" + reportNumber );

		String wherePhrase = (String) inputMap.get("where_phrase");
		paramValueList.add(wherePhrase); //WHERE_PHRASE
		logger.debug(METHOD_NAME + " wherePhrase=" + wherePhrase );

		String sortOrder = (String) inputMap.get("sort_order");
		paramValueList.add(sortOrder); //SORT_ORDER
		logger.debug(METHOD_NAME + " sortOrder=" + sortOrder );

		String additionalParms = (String) inputMap.get("additional_parms");
		paramValueList.add(additionalParms); //ADDITIONAL_PARMS
		logger.debug(METHOD_NAME + " additionalParms=" + additionalParms );

		String ftpUserid = (String) inputMap.get("ftp_userid");
		paramValueList.add(ftpUserid); //FTP_USERID
		logger.debug(METHOD_NAME + " ftpUserid=" + ftpUserid );

		String ftpPassword = (String) inputMap.get("ftp_password");
		paramValueList.add(ftpPassword); //FTP_PASSWORD
		logger.debug(METHOD_NAME + " ftpPassword=" + ftpPassword );

		String ftpHostname = (String) inputMap.get("ftp_hostname");
		paramValueList.add(ftpHostname); //FTP_HOST_NAME
		logger.debug(METHOD_NAME + " ftpHostname=" + ftpHostname );

		String ftpDirectory = (String) inputMap.get("ftp_directory");
		paramValueList.add(ftpDirectory); //FTP_DIRECTORY
		logger.debug(METHOD_NAME + " ftpDirectory=" + ftpDirectory );

		String ftpFilename = (String) inputMap.get("ftp_filename");
		paramValueList.add(ftpFilename); //FTP_FILENAME
		logger.debug(METHOD_NAME + " ftpFilename=" + ftpFilename );

		String dataformat = (String) inputMap.get("dataformat");
		paramValueList.add(dataformat); //DATAFORMAT
		logger.debug(METHOD_NAME + " dataformat=" + dataformat );

		String structure_type = (String) inputMap.get("structure_type");
		paramValueList.add(structure_type); //structure_type
		logger.debug(METHOD_NAME + " structure_type=" + structure_type );

		String structure_oid = (String) inputMap.get("structure_oid");
		paramValueList.add(structure_oid); //structure_oid
		logger.debug(METHOD_NAME + " structure_oid=" + structure_oid );

		String position_type = (String) inputMap.get("position_type");
		paramValueList.add(position_type); //position_type
		logger.debug(METHOD_NAME + " position_type=" + position_type );

		String position_oid = (String) inputMap.get("position_oid");
		paramValueList.add(position_oid); //position_oid
		logger.debug(METHOD_NAME + " position_oid=" + position_oid );

		Map procMap = (HashMap)executeStoredProcedure(paramValueList);

		logger.info("EXIT " + METHOD_NAME);

		return procMap ;
	}


	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
