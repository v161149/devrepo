package com.verizon.enterprise.ncasbosi.dao.Impl.payments;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.PaymentsEmailInterface;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.EmailUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.PaymentsTemplateConfig;
import com.verizon.enterprise.common.ncas.payments.EmailDtlsForVZW;
import com.verizon.enterprise.common.ncas.payments.EmailTemplateInfo;
import com.verizon.enterprise.common.ncas.payments.UserEmailDetails;
import com.verizon.enterprise.common.ncas.payments.EmailMapStruct;




public class PaymentsEmailImpl implements PaymentsEmailInterface, NCASBOSIConstants
{
	private static final org.apache.log4j.Logger _LOGGER =  org.apache.log4j.Logger.getLogger(PaymentsEmailImpl.class);




	public void emailVZBOneTimePaymentStatus()
	{
		final String METHOD_NAME = "emailVZBOneTimePaymentStatus => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = ALL_ONETIME_PMNTS_TEMPLATE_VZB;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,true);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),1);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZWOneTimePaymentSuccess()
	{
		final String METHOD_NAME = "emailVZWOneTimePaymentSuccess => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = ONETIME_PMNT_SUCCESS_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsListForOnetimeVZW(templateName);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getEmailDtlsMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),2);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZWOneTimePaymentFailure()
	{
		final String METHOD_NAME = "emailVZWOneTimePaymentFailure => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = ONETIME_PMNT_FAIL_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsListForOnetimeVZW(templateName);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getEmailDtlsMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),3);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZBRecurPaymentFailures()
	{
		final String METHOD_NAME = "emailVZBRecurPaymentFailures => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = ALL_REC_FAILURES_TEMPLATE_VZB;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),4);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZBRecurPaymentChanges()
	{
		final String METHOD_NAME = "emailVZBRecurPaymentChanges => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_CHANGES_TEMPLATE_VZB;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),5);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}
	public void emailVZWRecurPaymentChanges()
	{
		final String METHOD_NAME = "emailVZWRecurPaymentChanges => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_CHANGES_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName, true);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),6);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZWRecurPaymentApplicationError()
	{
		final String METHOD_NAME = "emailVZWRecurPaymentApplicationError => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_APP_ERROR_TEMPLATE_VZW;
	try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),7);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailRecurVZBPaymentNotification()
	{
		final String METHOD_NAME = "emailRecurVZBPaymentNotification => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_NOTIF_TEMPLATE_VZB;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),8);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailRecurVZWPaymentNotification()
	{
		final String METHOD_NAME = "emailRecurVZWPaymentNotification => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_NOTIF_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),9);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailRecurVZWPaymentDeleteNotification()
	{
		final String METHOD_NAME = "emailRecurVZWPaymentDeleteNotification => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_DELETE_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),10);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailCreditCardexpiration()
	{
		final String METHOD_NAME = "emailCreditCardexpiration => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = CC_EXP_TEMPLATE;
		try{
			EmailMapStruct emailMapStruct = getUserEmailNickNameList(templateName);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),11);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZWRecurSetupPaymentsFailure()
	{
		final String METHOD_NAME = "emailVZWRecurSetupPaymentsFailure => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_SETUP_FAILURE_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),12);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZBRecurPaymentsExceedAmount()
	{
		final String METHOD_NAME = "emailVZBRecurPaymentsExceedAmount => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_EXCEEDS_TEMPLATE_VZB;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),13);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailVZWRecurPaymentsExceedAmount()
	{
		final String METHOD_NAME = "emailVZWRecurPaymentsExceedAmount => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_EXCEEDS_TEMPLATE_VZW;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),14);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}
	public void emailVZBPaymentDelete()
	{
		final String METHOD_NAME = "emailVZBPaymentDelete => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = REC_PMNT_DELETE_TEMPLATE_VZB;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,false);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),15);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}
	public void emailPortalBillingNotif()
	{
		final String METHOD_NAME = "emailPortalBillingNotif => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = PORTAL_BILLING_NOTIF_TEMPLATE;
		try{
			EmailMapStruct emailMapStruct = getExceptionMessagesForPortalBilling(templateName);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),16);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}


	public void emailGCPOneTimePaymentStatus()
	{
		final String METHOD_NAME = "emailGCPOneTimePaymentStatus => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		final String templateName = ALL_ONETIME_PMNTS_TEMPLATE_GCP;
		try{
			EmailMapStruct emailMapStruct = getUserEmailDetailsList(templateName,true);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getServiceIDMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),17);
			updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void emailRecurReversalNotification() throws NCASException, Exception
		{
			final String METHOD_NAME = "emailRecurReversalNotification => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			final String templateName = STATUS_REVERSAL_EMAIL_NOTIF_TEMPLATE;
			try{
				EmailMapStruct emailMapStruct = getUserEmailDetailsListForOnetimeVZW(templateName);
				Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
				EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
				Map<String, Long> emailTrackingMap = sendEmail(emailMapStruct.getEmailDtlsMap(),tempInfo.getSubject(),tempInfo.getTemplateDesc(),18);
				updateTrackingID(emailMapStruct.getMailOidIDMap(),emailTrackingMap);
			}catch(Exception ex){
				_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
			}
			_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public Map<String,Long> sendEmail(Map serviceIDMap,String subject,String content,int switchValue)throws NCASException, Exception
	{
		final String METHOD_NAME = "sendEmail => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		Set<String> keySet = serviceIDMap.keySet();
		Iterator<String> it = keySet.iterator();
		long emailTrackingnumber = -1;
		Map<String,Long> emailTrackingnumberMap = new HashMap<String,Long>();
		String keyValue ="";
		List<String> mailList = new ArrayList<String>();
		EmailUtil emailUtil = new EmailUtil();
		try
		{
			while(it.hasNext())
			{
				keyValue = it.next();
				_LOGGER.info(METHOD_NAME+"\n\n sendEmail :: serviceIDMap keyValue   -->"+serviceIDMap.get(keyValue)+"\n\n");
				mailList.add(keyValue);
				switch(switchValue)
				{
					case 1:
						emailUtil.getOneTimePaymentVZBMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 2:
						emailUtil.getVZWOneTimePaymentSuccessMessage((ArrayList<EmailDtlsForVZW>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 3:
						emailUtil.getVZWOneTimePaymentFailureMessage((ArrayList<EmailDtlsForVZW>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 4:
						emailUtil.getVZBRecurFailuresMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 5:
						emailUtil.getVZBRecurPaymentChangesMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 6:
						emailUtil.getVZWRecurPaymentChangesMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 7:
						emailUtil.getVZWPaymentApplicationErrorMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 8:
						emailUtil.getVZBPaymentNotificationMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 9:
						emailUtil.getVZWPaymentNotificationMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 10:
						emailUtil.getVZWPaymentDeleteMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 11:
						emailUtil.getCreditCardexpirationMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 12:
						emailUtil.getVZWRecurPaymentsSetupFailureMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 13:
						emailUtil.getVZBPaymentExceedsMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 14:
						emailUtil.getVZWPaymentExceedsMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 15:
						emailUtil.getVZBPaymentDeleteMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
                        break;
					case 16:
						emailUtil.getPortalBillingNotifMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 17:
						emailUtil.getOneTimePaymentGCPMessage((ArrayList<String>)serviceIDMap.get(keyValue), subject, content);
						break;
					case 18:
						emailUtil.getEmailRecurReversalNotificationMessage((ArrayList<EmailDtlsForVZW>)serviceIDMap.get(keyValue), subject, content);
						break;
				}

				try{
					emailTrackingnumber = emailUtil.sendMail(mailList);
				}catch(Exception ex)
				{
					_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
				}
				_LOGGER.info(METHOD_NAME+"sendEmail :: emailTrackingnumber -->"+emailTrackingnumber);
				emailTrackingnumberMap.put(keyValue, new Long(emailTrackingnumber));
				mailList = new ArrayList<String>();
			}

		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME+"Exception occured-->"+e.getMessage());
			throw e;
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return emailTrackingnumberMap;
	}

	public EmailMapStruct getUserEmailDetailsListForOnetimeVZW(String emailTemplate)throws NCASException, Exception
	{
		final String METHOD_NAME = "getUserEmailDetailsList => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		List<UserEmailDetails> userEmailDetailsList = new ArrayList<UserEmailDetails>();
		UserEmailDetails userEmailDetails;
		Map<String, List<EmailDtlsForVZW>> emailDtlsMap = new LinkedHashMap<String, List<EmailDtlsForVZW>>();
		//List<String> serviceIDList = new ArrayList<String>();
		List<Integer> mailOidList = new ArrayList<Integer>();
		List<EmailDtlsForVZW> emailDtlsList = new ArrayList<EmailDtlsForVZW>();
		Map<String, List<Integer>> mailOidIDMap = new HashMap<String, List<Integer>>();
		EmailMapStruct emailMapStruct = null;
		String accountStatus = "";
		EmailDtlsForVZW emailDtlsVZW = null;
		try
		{

		 userEmailDetailsList = DAOFactory.getInstance().getPayments().selectEmailList(emailTemplate);
		 String userEmailAddr = "";
		 String userServiceId = "";
		 int userPayEmailOid = -1;
		 String custAcct = "";
		 String pmntMethod = "";
		 String pmntAmnt = "";
		 String username = "";
		 String pmntDate = "";
		 String serviceId = "";
		 SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-yyyy");

			for(int i=0;i<userEmailDetailsList.size();i++)
			{
				userEmailDetails = userEmailDetailsList.get(i);
				userEmailAddr = userEmailDetails.getUserEmailAddr();
				userPayEmailOid = userEmailDetails.getPayEmailOId();
				userServiceId = userEmailDetails.getServiceID();
				custAcct = userEmailDetails.getCustAcct();
				pmntMethod = userEmailDetails.getPmntMethod();
				pmntAmnt = Double.toString(userEmailDetails.getPaymentAmnt());
				username = userEmailDetails.getUserName();
				serviceId = userEmailDetails.getServiceID();
				pmntDate = simpleDateFormat.format(Timestamp.valueOf(userEmailDetails.getCreatedTimestamp()));
				emailDtlsVZW = new EmailDtlsForVZW();
				emailDtlsVZW.setCustAcct(custAcct);
				emailDtlsVZW.setPmntAmount(pmntAmnt);
				emailDtlsVZW.setPmntDate(pmntDate);
				emailDtlsVZW.setUsername(username);
				emailDtlsVZW.setServiceId(serviceId);
				emailDtlsVZW.setPmntMethod(pmntMethod);

				if(emailDtlsMap.size() > 0)
				{
					if(emailDtlsMap.containsKey(userEmailAddr))
					{
						accountStatus = userServiceId;
						emailDtlsList = (emailDtlsMap.get(userEmailAddr));

						emailDtlsList.add(emailDtlsVZW);
						mailOidList = (mailOidIDMap.get(userEmailAddr));
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
					}
					else
					{
						accountStatus = userServiceId;
						emailDtlsList = new ArrayList();
						emailDtlsList.add(emailDtlsVZW);
						mailOidList = new ArrayList<Integer>();
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						emailDtlsMap.put(userEmailAddr,emailDtlsList);
					}
				}
				else
				{
					emailDtlsList.add(emailDtlsVZW);
					mailOidList.add(new Integer(userPayEmailOid));
					mailOidIDMap.put(userEmailAddr, mailOidList);
					emailDtlsMap.put(userEmailAddr,emailDtlsList);
				}


			}
			emailMapStruct = new EmailMapStruct(mailOidIDMap,emailDtlsMap,true);

		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
			throw ex;
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return emailMapStruct;
	}

	public EmailMapStruct getUserEmailDetailsList(String emailTemplate, boolean statusMentionedInEmail)throws NCASException, Exception
	{
		final String METHOD_NAME = "getUserEmailDetailsList => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		List<UserEmailDetails> userEmailDetailsList = new ArrayList<UserEmailDetails>();
		UserEmailDetails userEmailDetails;
		Map<String, List<String>> serviceIDMap = new LinkedHashMap<String, List<String>>();
		List<String> serviceIDList = new ArrayList<String>();
		List<Integer> mailOidList = new ArrayList<Integer>();
		Map<String, List<Integer>> mailOidIDMap = new HashMap<String, List<Integer>>();
		EmailMapStruct emailMapStruct = null;
		String accountStatus = "";
		try
		{

		 userEmailDetailsList = DAOFactory.getInstance().getPayments().selectEmailList(emailTemplate);
		 String userEmailAddr = "";
		 String userPaymentStatus = "";
		 String userServiceId = "";
		 int userPayEmailOid = -1;
			for(int i=0;i<userEmailDetailsList.size();i++)
			{
				userEmailDetails = userEmailDetailsList.get(i);
				userEmailAddr = userEmailDetails.getUserEmailAddr();
				userPaymentStatus = userEmailDetails.getPaymentStatus();
				userPayEmailOid = userEmailDetails.getPayEmailOId();
				userServiceId = userEmailDetails.getServiceID();
				if(serviceIDMap.size() > 0)
				{
					if(serviceIDMap.containsKey(userEmailAddr))
					{
						if(!statusMentionedInEmail)
						accountStatus = userServiceId;
						else
						accountStatus = userServiceId+": "+userPaymentStatus;
						serviceIDList = (serviceIDMap.get(userEmailAddr));
						if(!serviceIDList.contains(accountStatus))
							serviceIDList.add(accountStatus);
						mailOidList = (mailOidIDMap.get(userEmailAddr));
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						serviceIDMap.put(userEmailAddr,serviceIDList);
					}
					else
					{
						if(!statusMentionedInEmail)
						accountStatus = userServiceId;
						else
						accountStatus = userServiceId+": "+userPaymentStatus;

						serviceIDList = new ArrayList<String>();
						serviceIDList.add(accountStatus);
						mailOidList = new ArrayList<Integer>();
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						serviceIDMap.put(userEmailAddr,serviceIDList);
					}
				}
				else
				{
					if(!statusMentionedInEmail)
						accountStatus = userServiceId;
						else
						accountStatus = userServiceId+": "+userPaymentStatus;
					serviceIDList.add(accountStatus);
					mailOidList.add(new Integer(userPayEmailOid));
					mailOidIDMap.put(userEmailAddr, mailOidList);
					serviceIDMap.put(userEmailAddr,serviceIDList);
				}


			}
			emailMapStruct = new EmailMapStruct(mailOidIDMap,serviceIDMap);

		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
			throw ex;
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return emailMapStruct;
	}


	public EmailMapStruct getUserEmailNickNameList(String emailTemplate)throws NCASException, Exception
	{
		final String METHOD_NAME = "getUserEmailNickNameList => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		List<UserEmailDetails> userEmailDetailsList = new ArrayList<UserEmailDetails>();
		UserEmailDetails userEmailDetails;
		Map<String,List<String>> nickNamesMap = new LinkedHashMap<String,List<String>>();
		List<String> nickNamesList = new ArrayList<String>();
		List<Integer> mailOidList = new ArrayList<Integer>();
		String accountStatus = "";
		String userProfileNickName = "";
		String userPaymentStatus = "";
		String userEmailAddr = "";
		int userPayEmailOid = -1;
		Map<String, List<Integer>> mailOidIDMap = new HashMap<String, List<Integer>>();
		EmailMapStruct emailMapStruct = null;
		try
		{
			userEmailDetailsList = DAOFactory.getInstance().getPayments().selectEmailList(emailTemplate);

			for(int i=0;i<userEmailDetailsList.size();i++)
			{
				userEmailDetails = userEmailDetailsList.get(i);

				userProfileNickName = userEmailDetails.getPayProfileNickName();
				userPaymentStatus = userEmailDetails.getPaymentStatus();
				userEmailAddr = userEmailDetails.getUserEmailAddr();
				userPayEmailOid = userEmailDetails.getPayEmailOId();

				if(nickNamesMap.size() > 0)
				{
					if(nickNamesMap.containsKey(userEmailDetails.getUserEmailAddr()))
					{
						accountStatus = userProfileNickName;
						nickNamesList = (nickNamesMap.get(userEmailAddr));
						if(!nickNamesList.contains(accountStatus))
						nickNamesList.add(accountStatus);

						mailOidList = (mailOidIDMap.get(userEmailAddr));
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						nickNamesMap.put(userEmailAddr,nickNamesList);
					}
					else
					{
						nickNamesList = new ArrayList<String>();
						accountStatus = userProfileNickName;
						nickNamesList.add(accountStatus);
						mailOidList = new ArrayList<Integer>();
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						nickNamesMap.put(userEmailAddr,nickNamesList);
					}
				}
				else
				{
					accountStatus = userProfileNickName;
					nickNamesList.add(accountStatus);
					mailOidList.add(new Integer(userPayEmailOid));
					mailOidIDMap.put(userEmailAddr, mailOidList);
					nickNamesMap.put(userEmailAddr,nickNamesList);
				}
			}
			emailMapStruct = new EmailMapStruct(mailOidIDMap,nickNamesMap);
		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
			throw ex;
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return emailMapStruct;
	}

	public EmailMapStruct getExceptionMessagesForPortalBilling(String emailTemplate)throws NCASException, Exception
	{
		final String METHOD_NAME = "getExceptionMessagesForPortalBilling => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		List<UserEmailDetails> userEmailDetailsList = new ArrayList<UserEmailDetails>();
		UserEmailDetails userEmailDetails;
		Map<String,List<String>> exceptionMap = new LinkedHashMap<String,List<String>>();
		List<String> exceptionList = new ArrayList<String>();
		List<Integer> mailOidList = new ArrayList<Integer>();
		String accountStatus = "";
		String userEmailAddr = "";
		int userPayEmailOid = -1;
		String errorText = "";
		String userServiceID;
		EmailMapStruct emailMapStruct = null;
		Map<String, List<Integer>> mailOidIDMap = new HashMap<String, List<Integer>>();
		try
		{
			userEmailDetailsList = DAOFactory.getInstance().getPayments().selectEmailList(emailTemplate);
			for(int i=0;i<userEmailDetailsList.size();i++)
			{
				userEmailDetails = userEmailDetailsList.get(i);
				userEmailAddr = userEmailDetails.getUserEmailAddr();
				errorText = userEmailDetails.getErrorText();
				userServiceID = userEmailDetails.getServiceID();
				userPayEmailOid = userEmailDetails.getPayEmailOId();
				if(exceptionMap.size() > 0)
				{
					_LOGGER.info(METHOD_NAME+"Second::"+userEmailDetails.getErrorText());
					if(exceptionMap.containsKey(userEmailDetails.getUserEmailAddr()))
					{
						accountStatus = errorText+"::"+userServiceID;
						exceptionList = exceptionMap.get(userEmailAddr);
						if(!exceptionList.contains(accountStatus))
						exceptionList.add(accountStatus);
						mailOidList = (mailOidIDMap.get(userEmailAddr));
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						exceptionMap.put(userEmailAddr,exceptionList);
					}
					else
					{
						exceptionList = new ArrayList<String>();
						accountStatus = errorText+"::"+userServiceID;
						exceptionList.add(accountStatus);
						mailOidList = new ArrayList<Integer>();
						mailOidList.add(new Integer(userPayEmailOid));
						mailOidIDMap.put(userEmailAddr, mailOidList);
						exceptionMap.put(userEmailAddr,exceptionList);
					}
				}
				else
				{
					_LOGGER.info(METHOD_NAME+"First::"+userEmailDetails.getErrorText());
					accountStatus = errorText+"::"+userServiceID;
					exceptionList.add(accountStatus);
					mailOidList.add(new Integer(userPayEmailOid));
					mailOidIDMap.put(userEmailAddr, mailOidList);
					exceptionMap.put(userEmailAddr,exceptionList);
				}
			}
			emailMapStruct = new EmailMapStruct(mailOidIDMap,exceptionMap);
		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
			throw ex;
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return emailMapStruct;
	}

	public void updateTrackingID(Map<String, List<Integer>> mailOidIDMap,Map<String, Long> emailTrackingMap)throws NCASException, Exception
	{
		final String METHOD_NAME = "updateTrackingID => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		Set<String> keySet = emailTrackingMap.keySet();
		Iterator<String> it = keySet.iterator();
		String keyValue ="";
		try
		{
			while(it.hasNext())
			{
				keyValue = it.next();
				List<Integer> trackList = mailOidIDMap.get(keyValue);
				if(trackList != null && trackList.size() > 0)
				{
					for(int i=0;i<trackList.size();i++)
					{
						_LOGGER.info(METHOD_NAME+"trackList item:"+trackList.get(i));
						_LOGGER.info(emailTrackingMap.get(keyValue));
						Map<String,Boolean> responseMap = DAOFactory.getInstance().getPayments().updateEmailTrackingNumber(String.valueOf(trackList.get(i)),String.valueOf(emailTrackingMap.get(keyValue)));
						_LOGGER.info(METHOD_NAME+"\n\n Response for Up-Date  -->"+responseMap.get("status")+"\n\n");
					}
				}
			}
		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME+"Exception sending email::"+ex.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

}