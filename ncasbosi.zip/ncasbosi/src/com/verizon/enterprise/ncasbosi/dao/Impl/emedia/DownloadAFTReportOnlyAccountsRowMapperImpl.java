package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadAFTReportOnlyAccountsRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadAFTReportOnlyAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		_LOGGER.info("Inside DownloadAFTReportOnlyAccountsRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List accountsList = new ArrayList();
		List account = new ArrayList();
		try {
			while(rs.next()) {
				account = new ArrayList();

				//Set the values
				String requestNumber = rs.getString("REQUEST_NO");//Char(17)
				String appUserId = rs.getString("APP_USER_ID");//Char(20)
				String userName = rs.getString("USER_NAME");//Char(50)
				String configType = rs.getString("CONFIG_TYPE");//Char(20)
				String configId = rs.getString("CONFIG_ID");//Char(20)
				String customerName = rs.getString("CUSTOMER_NAME");//Char(55)
				String action = rs.getString("ACTION");//Char(8)
				String mode = rs.getString("MODE");//Char(8)
				String comments = rs.getString("COMMENTS");//LongVarchar(500)
				String fileName = rs.getString("SS_FILE_NAME");//Varchar(100)
				String status = rs.getString("STATUS");//Char(10)
				String accountNumber = rs.getString("ACCOUNT");//Char(20)
				String errorCode = rs.getString("ERROR_CODE");//Char(8)
				String errorReason = rs.getString("ERROR_REASON");//Char(50)
				String accountType = rs.getString("ACCOUNT_TYPE");//Char(4)
				String foundIndicator = rs.getString("FOUND_IND");//Char(10)
				String origSystemId = rs.getString("ORIG_SYSTEM_ID");//Char(2)
				String origSystemName = rs.getString("ORIG_SYSTEM_NAME");//Char(20)
				String man = rs.getString("MAN");//Char(13)
				String ban = rs.getString("BAN");//Char(13)
				String aban = rs.getString("ABAN");// Char(13)
				String accountName = rs.getString("ACCOUNT_NAME");//Char(30)
				String addr1 = rs.getString("ADDRESS1");//Char(30)
				String addr2 = rs.getString("ADDRESS2");//Char(30)
				String addr3 = rs.getString("ADDRESS3");//Char(30)
				String addr4 = rs.getString("ADDRESS4");//Char(30)
				String state = rs.getString("STATE");//Char(2)
				String city = rs.getString("CITY");//Char(28)
				String zipCode = rs.getString("ZIP");//Char(9)
				double subscriberOid = rs.getDouble("SUBS_OID");//Decimal(10,0)
				String subscriberName = rs.getString("SUBSCRIBER_NAME");//Char(100)
				String guduns = rs.getString("GUDUNS");//Char(10)
				String bicCode = rs.getString("BIC_CODE");//Char(20)
				String verifyFlag = rs.getString("VERIFY_FLAG");//Char(1)
				double topSubscriberOid = rs.getDouble("TOP_SUBS_OID");//Decimal(10,0)
				String topSubscriberName = rs.getString("TOP_SUBS_NAME");//Char(100)
				String topGuduns = rs.getString("TOP_GUDUNS");//Char(10)
				String topBicName = rs.getString("TOP_BIC_NAME");//Char(100)
				String topBicCode = rs.getString("TOP_BIC_CODE");//Char(20)
				String topVerifyFlag = rs.getString("TOP_VERIFY_FLAG");//Char(1)
				String paperSupressIndicator = rs.getString("PAPER_SUPPRESS_IND");//Char(1)
				String paperFeeIndicator = rs.getString("PAPER_FEE_IND");//Char(1)
				String remitAccountIndicator = rs.getString("REMIT_ACCOUNT_IND");//Char(1)
				String enterpriseId = rs.getString("ENTERPRISE_ID");//Char(10)
				String naspId = rs.getString("NASP_ID");//Char(10)
				String bmConfigId = rs.getString("BM_CONFIG_ID");//Char(20)
				String ediEbid = rs.getString("EDI_VB811_EBID");//Char(20)
				String ddConfigId = rs.getString("DD_CONFIG_ID");//Char(20) 
				String ediDataGroup = rs.getString("DATA_GROUP");//Char(3)
				//New fields added - 52173.AA EDI Billing Enhancements: Account Finder Tool
				String callDetailVolumeIndicator = rs.getString("VOLUME_IND");//Char(1)
				String noOfVz450Records = rs.getString("RECORD_COUNT");//SmallInt
				String subscriptionStatus = rs.getString("SUBSCRIPTION_STATUS");//Char(2)
				double subscriptionOid = rs.getDouble("SUBSCRIPTION_OID");//Decimal(10,0)
				String country = rs.getString("COUNTRY");//Varchar(40)
				String languageCode = rs.getString("LANG_CODE");//Char(3)
				String accountNameSizeIndicator = rs.getString("ACCT_NAME_SIZE_IND");//Char(1)
				String addr1SizeIndicator = rs.getString("ADDR1_SIZE_IND");//Char(1)
				String addr2SizeIndicator = rs.getString("ADDR2_SIZE_IND");//Char(1)
				String addr3SizeIndicator = rs.getString("ADDR3_SIZE_IND");//Char(1)
				String cityStateZipSizeIndicator = rs.getString("CTY_ST_ZP_SIZE_IND");//Char(1)
				
				try {
					Date startDate = rs.getDate("START_DATE");//Date
					String startDateStr =  formatter.format(startDate);
					if(CommonUtil.isNotNull(startDateStr)) {
						account.add(new Cell(startDateStr.trim()));
					}
				} catch(IllegalArgumentException iae) {
					/*_LOGGER.debug("IllegalArgumentException Exception occured while parsing the Date(START_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("IllegalArgumentException Exception occured while parsing the Date(START_DATE) \n"
							+ iae.getMessage());
					 */					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					/*_LOGGER.debug("SQL Exception occured while parsing the Date(START_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(START_DATE) \n"
							+ sqlex.getMessage());
					*/
					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				
				try {
					Date billDate = rs.getDate("BILL_DATE");//Date
					String billDateStr =  formatter.format(billDate);
					if(CommonUtil.isNotNull(billDateStr)) {
						account.add(new Cell(billDateStr));
					}
				} catch(IllegalArgumentException iae) {
					_LOGGER.debug("Exception occured while parsing the Date(BILL_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date(BILL_DATE) \n"
							+ iae.getMessage());
					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					_LOGGER.debug("SQL Exception occured while parsing the Date(BILL_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(BILL_DATE) \n"
							+ sqlex.getMessage());
					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				
				if(CommonUtil.isNotNull(requestNumber)) {
					account.add(new Cell(requestNumber.trim()));
				}
				if(CommonUtil.isNotNull(appUserId)) {
					account.add(new Cell(appUserId.trim()));
				}
				if(CommonUtil.isNotNull(userName)) {
					account.add(new Cell(userName.trim()));
				}
				if(CommonUtil.isNotNull(configType)) {
					account.add(new Cell(configType.trim()));
				}
				if(CommonUtil.isNotNull(configId)) {
					account.add(new Cell(configId.trim()));
				}
				if(CommonUtil.isNotNull(customerName)) {
					account.add(new Cell(customerName.trim()));
				}
				if(CommonUtil.isNotNull(action)) {
					account.add(new Cell(action.trim()));
				}
				if(CommonUtil.isNotNull(mode)) {
					account.add(new Cell(mode.trim()));
				}
				if(CommonUtil.isNotNull(comments)) {
					account.add(new Cell(comments.trim()));
				}
				if(CommonUtil.isNotNull(fileName)) {
					account.add(new Cell(fileName.trim()));
				}
				if(CommonUtil.isNotNull(status)) {
					account.add(new Cell(status.trim()));
				}
				if(CommonUtil.isNotNull(accountNumber)) {
					account.add(new Cell(accountNumber.trim()));
				}
				if(CommonUtil.isNotNull(errorCode)) {
					account.add(new Cell(errorCode.trim()));
				}
				if(CommonUtil.isNotNull(errorReason)) {
					account.add(new Cell(errorReason.trim()));
				}
				if(CommonUtil.isNotNull(accountType)) {
					account.add(new Cell(accountType.trim()));
				}
				if(CommonUtil.isNotNull(foundIndicator)) {
					account.add(new Cell(foundIndicator.trim()));
				}
				if(CommonUtil.isNotNull(origSystemId)) {
					account.add(new Cell(origSystemId.trim()));
				}
				if(CommonUtil.isNotNull(origSystemName)) {
					account.add(new Cell(origSystemName.trim()));
				}
				if(CommonUtil.isNotNull(man)) {
					account.add(new Cell(man.trim()));
				}
				if(CommonUtil.isNotNull(ban)) {
					account.add(new Cell(ban.trim()));
				}
				if(CommonUtil.isNotNull(aban)) {
					account.add(new Cell(aban.trim()));
				}
				if(CommonUtil.isNotNull(accountName)) {
					account.add(new Cell(accountName.trim()));
				}
				if(CommonUtil.isNotNull(addr1)) {
					account.add(new Cell(addr1.trim()));
				}
				if(CommonUtil.isNotNull(addr2)) {
					account.add(new Cell(addr2.trim()));
				}
				if(CommonUtil.isNotNull(addr3)) {
					account.add(new Cell(addr3.trim()));
				}
				if(CommonUtil.isNotNull(addr4)) {
					account.add(new Cell(addr4.trim()));
				}
				if(CommonUtil.isNotNull(state)) {
					account.add(new Cell(state.trim()));
				}
				if(CommonUtil.isNotNull(city)) {
					account.add(new Cell(city.trim()));
				}
				if(CommonUtil.isNotNull(zipCode)) {
					account.add(new Cell(zipCode.trim()));
				}
				account.add(new Cell(String.valueOf(subscriberOid)));
				if(CommonUtil.isNotNull(subscriberName)) {
					account.add(new Cell(subscriberName.trim()));
				}
				if(CommonUtil.isNotNull(guduns)) {
					account.add(new Cell(guduns.trim()));
				}
				if(CommonUtil.isNotNull(bicCode)) {
					account.add(new Cell(bicCode.trim()));
				}
				if(CommonUtil.isNotNull(verifyFlag)) {
					account.add(new Cell(verifyFlag.trim()));
				}
				account.add(new Cell(String.valueOf(topSubscriberOid)));
				if(CommonUtil.isNotNull(topSubscriberName)) {
					account.add(new Cell(topSubscriberName.trim()));
				}
				if(CommonUtil.isNotNull(topGuduns)) {
					account.add(new Cell(topGuduns.trim()));
				}
				if(CommonUtil.isNotNull(topBicName)) {
					account.add(new Cell(topBicName.trim()));
				}
				if(CommonUtil.isNotNull(topBicCode)) {
					account.add(new Cell(topBicCode.trim()));
				}
				if(CommonUtil.isNotNull(topVerifyFlag)) {
					account.add(new Cell(topVerifyFlag.trim()));
				}
				if(CommonUtil.isNotNull(paperSupressIndicator)) {
					account.add(new Cell(paperSupressIndicator.trim()));
				}
				if(CommonUtil.isNotNull(paperFeeIndicator)) {
					account.add(new Cell(paperFeeIndicator.trim()));
				}
				if(CommonUtil.isNotNull(remitAccountIndicator)) {
					account.add(new Cell(remitAccountIndicator.trim()));
				}
				if(CommonUtil.isNotNull(enterpriseId)) {
					account.add(new Cell(enterpriseId.trim()));
				}
				if(CommonUtil.isNotNull(naspId)) {
					account.add(new Cell(naspId.trim()));
				}
				if(CommonUtil.isNotNull(bmConfigId)) {
					account.add(new Cell(bmConfigId.trim()));
				}
				if(CommonUtil.isNotNull(ediEbid)) {
					account.add(new Cell(ediEbid.trim()));
				}
				if(CommonUtil.isNotNull(ddConfigId)) {
					account.add(new Cell(ddConfigId.trim()));
				}
				if(CommonUtil.isNotNull(ediDataGroup)){
					account.add(new Cell(ediDataGroup.trim()));
				}
				//New Fields
				if(CommonUtil.isNotNull(callDetailVolumeIndicator)){
					account.add(new Cell(callDetailVolumeIndicator.trim()));
				}
				if(CommonUtil.isNotNull(noOfVz450Records)){
					account.add(new Cell(noOfVz450Records.trim()));
				}
				if(CommonUtil.isNotNull(subscriptionStatus)){
					account.add(new Cell(subscriptionStatus.trim()));
				}
				account.add(new Cell(String.valueOf(subscriptionOid)));
				try {
					Date subscriberStatusChangeDate = rs.getDate("SUBSCR_STAT_CHG_DT");//Date
					String subscriberStatusChangeDateStr =  formatter.format(subscriberStatusChangeDate);
					if(CommonUtil.isNotNull(subscriberStatusChangeDateStr)) {
						account.add(new Cell(subscriberStatusChangeDateStr));
					}
				} catch(IllegalArgumentException iae) {
					_LOGGER.debug("Exception occured while parsing the Date(SUBSCR_STAT_CHG_DT) \n"
							+ iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date(SUBSCR_STAT_CHG_DT) \n"
							+ iae.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					_LOGGER.debug("SQL Exception occured while parsing the Date(SUBSCR_STAT_CHG_DT) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(SUBSCR_STAT_CHG_DT) \n"
							+ sqlex.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				try {
					Date billManagerAcctStartDate = rs.getDate("BM_ACT_START_DATE");//Date
					String billManagerAcctStartDateStr =  formatter.format(billManagerAcctStartDate);
					if(CommonUtil.isNotNull(billManagerAcctStartDateStr)) {
						account.add(new Cell(billManagerAcctStartDateStr));
					}
				} catch(IllegalArgumentException iae) {
					_LOGGER.debug("Exception occured while parsing the Date(BM_ACT_START_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date(BM_ACT_START_DATE) \n"
							+ iae.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					_LOGGER.debug("SQL Exception occured while parsing the Date(BM_ACT_START_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(BM_ACT_START_DATE) \n"
							+ sqlex.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				try {
					Date ddAccountStartDate = rs.getDate("DD_ACT_START_DATE");//Date
					String ddAccountStartDateStr =  formatter.format(ddAccountStartDate);
					if(CommonUtil.isNotNull(ddAccountStartDateStr)) {
						account.add(new Cell(ddAccountStartDateStr));
					}
				} catch(IllegalArgumentException iae) {
					_LOGGER.debug("Exception occured while parsing the Date(DD_ACT_START_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date(DD_ACT_START_DATE) \n"
							+ iae.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					_LOGGER.debug("SQL Exception occured while parsing the Date(DD_ACT_START_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(DD_ACT_START_DATE) \n"
							+ sqlex.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				try {
					Date ediAccountStartDate = rs.getDate("EDI_ACT_START_DATE");//Date
					String ediAccountStartDateStr =  formatter.format(ediAccountStartDate);
					if(CommonUtil.isNotNull(ediAccountStartDateStr)) {
						account.add(new Cell(ediAccountStartDateStr));
					}
				} catch(IllegalArgumentException iae) {
					_LOGGER.debug("Exception occured while parsing the Date(EDI_ACT_START_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date(EDI_ACT_START_DATE) \n"
							+ iae.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					_LOGGER.debug("SQL Exception occured while parsing the Date(EDI_ACT_START_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(EDI_ACT_START_DATE) \n"
							+ sqlex.getMessage());
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(country)){
					account.add(new Cell(country.trim()));
				}
				if(CommonUtil.isNotNull(languageCode)){
					account.add(new Cell(languageCode.trim()));
				}
				if(CommonUtil.isNotNull(accountNameSizeIndicator)){
					account.add(new Cell(accountNameSizeIndicator.trim()));
				}
				if(CommonUtil.isNotNull(addr1SizeIndicator)){
					account.add(new Cell(addr1SizeIndicator.trim()));
				}
				if(CommonUtil.isNotNull(addr2SizeIndicator)){
					account.add(new Cell(addr2SizeIndicator.trim()));
				}
				if(CommonUtil.isNotNull(addr3SizeIndicator)){
					account.add(new Cell(addr3SizeIndicator.trim()));
				}
				if(CommonUtil.isNotNull(cityStateZipSizeIndicator)){
					account.add(new Cell(cityStateZipSizeIndicator.trim()));
				}
				accountsList.add(account);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadAFTReportOnlyAccountsRowMapperImpl's account -  " + account);
		}
		return accountsList;
	}
}