package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.bills.InvoiceTypeHelper;

public class GetGbrSummaryAccountsRowMapperImpl implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetGbrSummaryAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		logger.info("Inside GetGbrSummaryAccountsRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();

		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = null;
		String key = "";

		try
		{
			while(rs.next())
			{
				emediaRecord = new EMediaRecord();

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");
				String ban = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String man = rs.getString("MAN");
				String manDan = rs.getString("MAN_DAN");
				String tnType = rs.getString("TN_TYPE");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String backEndSYstem = rs.getString("BACKEND_SYSTEM");
				String accountName = rs.getString("ACCT_NAME");
				String billPeriod = rs.getString("BILL_PERIOD");
				String channelCode = rs.getString("CHANNEL_CODE");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String systemDesc = rs.getString("SYST_DESCRIPTION");
				acctSubscriptionOid = rs.getDouble("ACCT_SUBS_OID");
                String eligibilityInd = rs.getString("ELIGIBILITY_IND");
                String billingFrequency = rs.getString("BILLING_FREQ");
                String invoiceType = rs.getString("INVOICE_TYPE");
                String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");
                String regionName = rs.getString("GBR_REGION_NAME");
                String manBillDate = rs.getString("MAN_BILL_DATE");

				List valuesList = new ArrayList();
				valuesList.add(enterpriseId);
				valuesList.add(corpId);
				valuesList.add(ban);
				valuesList.add(banDan);
				valuesList.add(man);
				valuesList.add(manDan);
				valuesList.add(tnType);
				valuesList.add(origSysId);
				valuesList.add(accountName);
				valuesList.add(billPeriod);
				valuesList.add(systemAbbrv);
				valuesList.add(acctSubscriptionOid);
				valuesList.add(eligibilityInd);
				valuesList.add(billingFrequency);
				valuesList.add(invoiceType);
				valuesList.add(gbrInvoiceType);
				valuesList.add(regionName);
				valuesList.add(manBillDate);
				CommonUtil.prettyPrintValues(valuesList);

				if(CommonUtil.isNotNull(origSysId))
				{
					emediaRecord.setOrigSysId(origSysId.trim());
				}

				if(CommonUtil.isNotNull(enterpriseId))
				{
					emediaRecord.setEnterprise(enterpriseId.trim());
				}

				if(CommonUtil.isNotNull(corpId))
				{
					emediaRecord.setCorp(corpId.trim());
				}

				if(CommonUtil.isNotNull(ban))
				{
					emediaRecord.setBan(ban.trim());
				}

				if(CommonUtil.isNotNull(banDan))
				{
					emediaRecord.setBan_dan(banDan.trim());
				}

				if(CommonUtil.isNotNull(man))
				{
					emediaRecord.setMan(man.trim());
				}

				if(CommonUtil.isNotNull(manDan))
				{
					emediaRecord.setMan_dan(manDan.trim());
				}

				if(CommonUtil.isNotNull(tnType))
				{
					emediaRecord.setTnType(tnType.trim());
				}

				if(CommonUtil.isNotNull(accountName))
				{
					emediaRecord.setAccountName(accountName.trim());
				}

				if(CommonUtil.isNotNull(billPeriod))
				{
					emediaRecord.setBillPeriod(billPeriod.trim());
				}

				if(CommonUtil.isNotNull(channelCode))
				{
					emediaRecord.setChannelCode(channelCode.trim());
				}

				if(CommonUtil.isNotNull(systemAbbrv))
				{
					emediaRecord.setSystemAbbrv(systemAbbrv.trim());
				}

				if(CommonUtil.isNotNull(systemDesc))
				{
					emediaRecord.setSystemDesc(systemDesc.trim());
				}

				if(CommonUtil.isNotNull(eligibilityInd))
				{
					emediaRecord.setEligibilityInd(eligibilityInd.trim());
				}

				if(CommonUtil.isNotNull(billingFrequency))
				{
					emediaRecord.setBillingFrequency(billingFrequency.trim());
				}

                if(CommonUtil.isNotNull(invoiceType))
                {
					emediaRecord.setInvoiceType(invoiceType.trim());
				}

                if(CommonUtil.isNotNull(gbrInvoiceType))
                {
					emediaRecord.setGbrInvoiceType(gbrInvoiceType.trim());
				}

                if(CommonUtil.isNotNull(regionName))
                {
					emediaRecord.setRegionName(regionName.trim());
				}

				if(CommonUtil.isNotNull(manBillDate))
				{
					emediaRecord.setManBillDate(CommonUtil.getDisplayDateFromString(manBillDate.trim()));
				}

                try
                {
                    InvoiceTypeHelper invoiceTypeHelper = InvoiceTypeHelper.getInstance();
                    String invoiceTypeName = invoiceTypeHelper.getInvoiceTypeName(emediaRecord.getInvoiceType());
                    emediaRecord.setInvoiceTypeName(invoiceTypeName);
                }
                catch (Exception e)
                {
                    SQLException newException = new SQLException(e.getMessage());
                    throw newException;
                }

				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				emediaRecord.setAcctSubscriptionOid(key);

				if(previousOid!=acctSubscriptionOid)
				{
					refList = new ArrayList();
					returnMap.put(key,refList);
				}

				refList.add(emediaRecord);
				previousOid = acctSubscriptionOid;
			}

		}
		catch(NumberFormatException nfe)
		{
				nfe.printStackTrace();
				logger.info("Exception occured while parsing the resultset \n"+nfe.getMessage());
				logger.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}

		return returnMap;
	}
}
