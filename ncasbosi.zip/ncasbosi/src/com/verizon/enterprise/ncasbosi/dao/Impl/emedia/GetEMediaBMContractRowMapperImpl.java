package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.eMedia.EMediaWaiverRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetEMediaBMContractRowMapperImpl  implements ResultSetExtractor {
	
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaBMContractRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetEMediaBMContractRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		EMediaWaiverRecord waiverRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = new ArrayList();
		String key = "";
		try{
			while(rs.next()) {
				
				waiverRecord = new EMediaWaiverRecord();
				//int lineNum = rs.getInt("LINE_NUM");
				String masterContractId = rs.getString("MASTER_CONTRACT_ID");
				String contractId = rs.getString("CONTRACT_ID");
				String cdorCustomerName = rs.getString("CDOR_CUSTOMER_NAME");
				String bcasignDate = CommonUtil.getDisplayVAMDateFromString(rs.getDate("BCASIGN_DATE"));
				//String aggrementType =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("AGREEMENT_TYPE"));
				String aggrementType =  rs.getString("AGREEMENT_TYPE");
				
				if(CommonUtil.isNotNull(masterContractId)) { waiverRecord.setMasterContractId(masterContractId.trim()); }
				if(CommonUtil.isNotNull(contractId)) { waiverRecord.setContractId(contractId.trim()); }
				if(CommonUtil.isNotNull(cdorCustomerName)) { waiverRecord.setCdorCustomerName(cdorCustomerName.trim()); }				
				if(CommonUtil.isNotNull(bcasignDate)) {waiverRecord.setBcasignDate(bcasignDate.trim()); }
				if(CommonUtil.isNotNull(aggrementType)) {waiverRecord.setAggrementType(aggrementType.trim()); }

				refList.add(waiverRecord);	
					
			}
			//returnMap.put("bmContractsList",refList);

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			//return returnMap;
			return refList;
		}
}