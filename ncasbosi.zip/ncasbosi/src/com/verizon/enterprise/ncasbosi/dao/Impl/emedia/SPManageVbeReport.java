package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.gbr.VbeReportPoint;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

// update reports identifying fields.
public class SPManageVbeReport extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPManageVbeReport.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ID",       getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME",     getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"REPORT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_ADDR_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_1", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_2", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_3", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_CITY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_STATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ZIP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"POSTAL_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_COUNTRY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CURRENCY_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
	}

	public SPManageVbeReport(DataSource dataSource)
	{
		super(dataSource, getVAMSchemaName() + "." + "MANAGE_RPT_PT", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception
	{

		_LOGGER.debug("entering SPGenerateVbeReport executeStoredProcedure api");
		Map requestMap = (HashMap)input;
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		VbeReportPoint reportPoint = (VbeReportPoint) requestMap.get("reportPoint");

		String debugLevel = "0";

		List callList = new ArrayList();
		callList.add("esgportal"); // APP_USER_ID
		callList.add(reportPoint.getExtUpdtUserId()); // USER_ID
		callList.add(reportPoint.getExtUpdtUserName()); // USER_NAME
		callList.add(debugLevel);    // IN_DEBUG_LEVEL
		callList.add(new BigDecimal(reportPoint.getReportOid())); //REPORT_OID
		callList.add((String) requestMap.get ("ACTION"));
		callList.add(reportPoint.getReportName()); //REPORT_NAME
		callList.add(reportPoint.getCustAddrType ()); // CUST_ADDR_TYPE
		callList.add(reportPoint.getCustAddr1 ()); // CUST_ADDR_1
		callList.add(reportPoint.getCustAddr2 ()); // CUST_ADDR_2
		callList.add(reportPoint.getCustAddr3 ()); // CUST_ADDR_3
		callList.add(reportPoint.getCustCity ()); // CUST_CITY
		callList.add(reportPoint.getCustState ()); // CUST_STATE
		callList.add(reportPoint.getCustZip ()); // CUST_ZIP
		callList.add(reportPoint.getPostalCode ()); // POSTAL_CODE
		callList.add(reportPoint.getCustCountry ()); // CUST_COUNTRY
		callList.add(reportPoint.getLanguage_code ()); // LANGUAGE_CODE
		callList.add(reportPoint.getCurrency_code ()); // CURRENCY_CODE

		Map responseMap = executeSP(callList, false);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(responseMap, VAM);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
	}




}

