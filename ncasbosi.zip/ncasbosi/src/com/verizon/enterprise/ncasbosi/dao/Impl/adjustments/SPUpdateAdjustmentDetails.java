package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPUpdateAdjustmentDetails extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPUpdateAdjustmentDetails.class);
	
	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"INPUT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPUpdateAdjustmentDetails(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_UPDATE_ADJUSTMENT_DETAILS, spInOutList);	
	}

	public Map executeStoredProcedure(String inputString, int numberOfRows)throws Exception	{
		//Create an input param list and pass it Stored Procedure.
		List paramValueList = new ArrayList();
		paramValueList.add(inputString);//INPUT_STRING
		paramValueList.add(numberOfRows);//INPUT_ROWS

		//Add all input Params to Map and pass it back along with responseMap.
		Map inputParamMap = new HashMap();
		inputParamMap.put("INPUT_STRING", inputString);
		inputParamMap.put("INPUT_ROWS", numberOfRows);

		//Add input Params Map and API_NAME to responseMap and return it back.
		Map responseMap = executeStoredProcedure(paramValueList);
		responseMap.put("API_NAME", NCASBOSIConstants.SP_UPDATE_ADJUSTMENT_DETAILS);
		responseMap.put("inputParamMap", inputParamMap);

		return responseMap;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}