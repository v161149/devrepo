package com.verizon.enterprise.ncasbosi.dao.Impl.payments;

import java.lang.reflect.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.payments.*;
import com.verizon.enterprise.common.ncas.exception.InvalidPaymentException;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.exception.PaymentException;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.*;
import com.verizon.enterprise.common.ncas.User;
import com.verizon.enterprise.common.ncas.common.JMSUtility;
import java.util.HashMap;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.ncasbosi.common.PaymentsTemplateConfig;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.common.ncas.payments.EmailTemplateInfo;

public  class PaymentsBatchImpl extends PaymentsDAOImpl implements NCASBOSIConstants,PaymentsBatchInterface {

	private static final Logger _LOGGER = Logger.getLogger(PaymentsBatchImpl.class);
	public void createPayDetailsFromRecurring(RecurPayment recurPmnt) throws NCASException{}
	public void doVZWRecurPaymentBatch() throws NCASException{}

	public void doOneTimePayDetailsBatch() throws NCASException
	{
		final String METHOD_NAME = "doOneTimePayDetailsBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		PaymentResponse payResponse = null;
		PaymentDetails payDetails = null;

		try{
			//1.Picking up all the eligible payments from PL_PAY_DETAILS( PAYMENT_DATE is less than or equal to the current date,
			//	PAYMENT_STATUS=Scheduled - Includes OneTime & Recurring

			List<PaymentDetails> payments = selectPaymentDetails();
			int paySize = payments.size();
			PaymentProfile profile = null;
			_LOGGER.info(METHOD_NAME+" The number of eligible payments is:"+paySize);
			int payId = 0;
			for(int i = 0;i<paySize;i++)
			{
			try{
				payDetails = payments.get(i);
				payId = payDetails.getPaymentID();
				int payProfileId = payDetails.getProfileID();
				_LOGGER.info(METHOD_NAME+"payProfileId:"+payProfileId);
				_LOGGER.info(METHOD_NAME+"About to send payId"+payId+" payment to EPayments");
				profile = (PaymentProfile)selectPaymentProfileDetails(payProfileId).get("paymentProfile");
				updateDetailsStatus(payDetails,NcasConstants.PAY_DETAILS_LOCKED_STATUS,NcasConstants.BATCH_PAY_ONETIME);
				payResponse = webImpl.managePayment(payDetails,profile, NcasConstants.PAYMENT_TYPE_ONETIME);
				_LOGGER.info(METHOD_NAME+"Successfully sent payId"+payId+" payment to EPayments");
				updateSuccessResponse(payResponse,payDetails,NcasConstants.PAY_DETAILS_PROCESSED_STATUS,NcasConstants.BATCH_PAY_ONETIME);
				_LOGGER.info(METHOD_NAME+"Updated payId:"+payId+" with Processed status");
			}catch(InvalidPaymentException iex){
				PaymentResponse payResp = iex.getPaymentResponse("Failed to process the payment..");
				updateFailureResponse(payResp,payDetails,NcasConstants.PAY_DETAILS_FAILED_STATUS,NcasConstants.BATCH_PAY_ONETIME);
			}catch(PaymentException pex){
				_LOGGER.info(METHOD_NAME + ":: PaymentException  : \n"+pex.getMessage());
				_LOGGER.error(METHOD_NAME + ":: PaymentException  in NCASBOSI : \n" +pex.getMessage());
				updateErrorDescForPayment(pex.getMessage(),payDetails,NcasConstants.BATCH_PAY_ONETIME);
			}catch(Exception ex){
				_LOGGER.error(METHOD_NAME + "::   Inner Loop Failed \n"+ex.getMessage());
				insertPaymentEmail(payDetails, payDetails.getNickName(),PORTAL_BILLING_NOTIF_TEMPLATE,payDetails.getLoginId(),METHOD_NAME,"","Exception Inner Loop Processing ::"+METHOD_NAME+"::"+ex.getMessage(),payDetails.getEpResponseCode(),Integer.toString(payDetails.getPortalTrackID()),NcasConstants.BATCH_PAY_ONETIME);
			}
		}
		}
		catch(Exception e){
			_LOGGER.error(METHOD_NAME + "::   in NCASBOSI Failed \n" +e.getMessage());
			if(payDetails == null)
				payDetails = new PaymentDetails();
			insertPaymentEmail(payDetails,payDetails.getNickName(), PORTAL_BILLING_NOTIF_TEMPLATE,payDetails.getLoginId(),METHOD_NAME,"","Exception Processing ::"+METHOD_NAME+"::"+e.getMessage(),payDetails.getEpResponseCode(),Integer.toString(payDetails.getPortalTrackID()),NcasConstants.BATCH_PAY_ONETIME);
		}

		_LOGGER.info(METHOD_NAME+" Exiting");

	}

	public void doRecurPaymentUpdateBatch() throws NCASException
	{
		final String METHOD_NAME = "doRecurPaymentUpdateBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		RecurPayment item = null;
		PaymentResponse payResponse = null;
		String emailTemplate = REC_PMNT_CHANGES_TEMPLATE_VZB;
		String emailStatus = NcasConstants.EMAIL_VZB_RECUR_UPDATE;

		try{
			List<RecurPayment> recurPay = selectRecurPaymentsForUpdateType();
			Iterator<RecurPayment> itr = recurPay.iterator();
			_LOGGER.info(METHOD_NAME+"The size of incomplete Date or Acct or Both or Cancel Upd Status Reqs::"+recurPay.size());
			PaymentProfile profile = null;
			  while (itr.hasNext()) {
				try{
					item = itr.next();
					if(item.getVzbVzwFlag().equals(NcasConstants.VZB_VZW_FLAG_VZW)){
						if(CommonUtil.compareDate(item.getNextPaymentDate(),item.getFirstPaymentDate(),"yyyy-MM-dd")!=0)
						{
							String status = item.getPaymentStatus();
							profile = (PaymentProfile)selectPaymentProfileDetails(item.getProfileID()).get("paymentProfile");
							updateRecurDetailsStatus(item.getPaymentID(),NcasConstants.PAY_DETAILS_LOCKED_STATUS,NcasConstants.BATCH_UPDATE_RECUR);
							payResponse = webImpl.managePayment(item, profile, NcasConstants.PAYMENT_TYPE_RECURRING);
							_LOGGER.info(METHOD_NAME+"Updated ePayments of the payment id:"+item.getPaymentID()+":: about Wireless update");
							updateRecurDetailsStatus(item.getPaymentID(),status,NcasConstants.BATCH_UPDATE_RECUR);
						}
						else{
							_LOGGER.info(METHOD_NAME+"Not sending the recur payment update to ePayments as this payment hasn't been sent to ePayments yet.");
						}
					}

					if(item.getUpdateType().equalsIgnoreCase(NcasConstants.RECUR_WIRELESS_UPD_CANCEL))
					{
						_LOGGER.info(METHOD_NAME+"This is a CANCEL");
						item.setPaymentStatus(NcasConstants.RECUR_PAY_CANCEL_STATUS);
						item.setNextPaymentDate("");
					}
					if(item.getVzbVzwFlag().equalsIgnoreCase(NcasConstants.VZB_VZW_FLAG_VZB)){
						emailTemplate = REC_PMNT_CHANGES_TEMPLATE_VZB;
						emailStatus = NcasConstants.EMAIL_PROCESSED;
						if(item.getUpdateType().equalsIgnoreCase(NcasConstants.RECUR_WIRELESS_UPD_CANCEL))
						emailTemplate = REC_PMNT_DELETE_TEMPLATE_VZB;
					}
					if(item.getVzbVzwFlag().equalsIgnoreCase(NcasConstants.VZB_VZW_FLAG_VZW)){
						emailTemplate = REC_PMNT_CHANGES_TEMPLATE_VZW;
						emailStatus = NcasConstants.EMAIL_PROCESSED;
						if(item.getUpdateType().equalsIgnoreCase(NcasConstants.RECUR_WIRELESS_UPD_CANCEL))
							emailTemplate = REC_PMNT_DELETE_TEMPLATE_VZW;
					}


					updateRecurPaymentStatus(item.getPaymentID(),item.getPaymentStatus(),"",item.getNextPaymentDate(),"",NcasConstants.BATCH_UPDATE_RECUR);
					if(payResponse!=null)
					{
						_LOGGER.info(METHOD_NAME +"payResponse::"+payResponse.toString());
						updateEPaymentsResponseForRecur(payResponse,item.getPaymentID(),item.getNextPaymentDate(),"",NcasConstants.BATCH_UPDATE_RECUR);
					}
					_LOGGER.info(METHOD_NAME + "Updated the status of the payment id:"+item.getPaymentID());

					insertPaymentEmail(item,item.getNickName(), emailTemplate,item.getLoginId(),METHOD_NAME,emailStatus,NcasConstants.BATCH_UPDATE_RECUR);


				}catch(InvalidPaymentException iex){
					PaymentResponse payResp = iex.getPaymentResponse("Failed to process the update of  the payment..");
					updateFailureRecurResponse(payResp,item,NcasConstants.PAY_DETAILS_FAILED_STATUS,NcasConstants.BATCH_UPDATE_RECUR);
				}catch(PaymentException pex){
					_LOGGER.info(METHOD_NAME + ":: PaymentException  : \n"+pex.getMessage());
					_LOGGER.error(METHOD_NAME + ":: PaymentException  in NCASBOSI : \n" +pex.getMessage());
					updateErrorDescForPaymentRecur(pex.getMessage(),item,NcasConstants.BATCH_UPDATE_RECUR);
				}catch(Exception ex){
					_LOGGER.error(METHOD_NAME + "::   Inner Loop Failed \n"+ex.getMessage());
					insertPaymentEmail(item,item.getNickName(), PORTAL_BILLING_NOTIF_TEMPLATE,item.getLoginId(),METHOD_NAME,"","Exception Inner Loop Processing ::"+METHOD_NAME+"::"+ex.getMessage(),item.getEpResponseCode(),Integer.toString(item.getPortalTrackID()),NcasConstants.BATCH_UPDATE_RECUR);
				}
			  }
		}
		catch(Exception e){
			_LOGGER.error(METHOD_NAME + "::  in NCASBOSI Failed \n" +e.getMessage());
			if(item == null)
				item = new RecurPayment();
			insertPaymentEmail(item,item.getNickName(), PORTAL_BILLING_NOTIF_TEMPLATE,item.getLoginId(),METHOD_NAME,"","Exception Processing ::"+METHOD_NAME+"::"+e.getMessage(),item.getEpResponseCode(),Integer.toString(item.getPortalTrackID()),NcasConstants.BATCH_UPDATE_RECUR);
		}

		_LOGGER.info(METHOD_NAME+" Exiting");

	}


	public void doCreditCardExpiryBatch() throws NCASException
	{
		final String METHOD_NAME = "doCreditCardExpiryBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try{
		List<PaymentProfile> payProfileList = selectAllAboutToExpireCreditCards();
		PaymentProfile payProfile = null;
		UserEmailDetails userEmailDtls = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
		List<UserEmailDetails> userEmailList = new ArrayList<UserEmailDetails>();
		_LOGGER.info(METHOD_NAME+"Size of the payProfileList::"+payProfileList.size());
		String userEmail = "";
		User user= null;
		for(int i=0;i<payProfileList.size();i++)
		{
			payProfile = payProfileList.get(i);
			user = DAOFactory.getInstance().getPaymentsBeanForECP().getUserFromECP(payProfile.getPortalLoginID());
			if(user!=null)
				userEmail = user.getEmail();
			_LOGGER.info(METHOD_NAME+"userEmail:"+userEmail);
			userEmailDtls = new UserEmailDetails(-1, "", "",userEmail , 0, CC_EXP_TEMPLATE, payProfile.getNickName(), lastUpdated, lastUpdated, "", 0, "",-1,"",NcasConstants.BATCH_CC_EXPIRY);
			userEmailList.add(userEmailDtls);
		}
		_LOGGER.info(METHOD_NAME+" Size of the userEmailList::"+userEmailList.size());
		insertPaymentEmailDtls(userEmailList);
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+" Failed \n" +ex.getMessage());
			insertPaymentEmail(null,"", PORTAL_BILLING_NOTIF_TEMPLATE,"",METHOD_NAME,"","Exception processing ::"+METHOD_NAME+"::"+ex.getMessage(),"","",NcasConstants.BATCH_CC_EXPIRY);
		}
		_LOGGER.info(METHOD_NAME+":::Exiting");
	}
	public void doAlreadyExpiredCreditCardBatch() throws NCASException
	{
		final String METHOD_NAME = "doAlreadyExpiredCreditCardBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try{

		List<Integer> payProfileList = selectAlreadyExpiredCreditCards();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		int profileListSize = payProfileList.size();
		_LOGGER.info(METHOD_NAME+"The number of already expired profiles is::"+profileListSize);

		if(profileListSize>0)
		{
			updatePayProfileStatus(payProfileList,NcasConstants.PROFILE_STATUS_CANCELLED,"This payment account was cancelled on "+df.format(new java.util.Date())+" because the credit card expired.");
			for(int i=0;i<profileListSize;i++)
				updateRecurPaymentForExpiredProfile((payProfileList.get(i)).intValue(), NcasConstants.RECUR_WIRELESS_UPD_CANCEL, NcasConstants.BATCH_CC_EXPIRED, "This payment account was cancelled on "+df.format(new java.util.Date())+" because the credit card expired.");
		}else{
			_LOGGER.info(METHOD_NAME+"No expired credit card profiles found.");
		}
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME+" Failed \n" +ex.getMessage());
			insertPaymentEmail(null,"", PORTAL_BILLING_NOTIF_TEMPLATE,"",METHOD_NAME,"","Exception processing ::"+METHOD_NAME+"::"+ex.getMessage(),"","",NcasConstants.BATCH_CC_EXPIRED);
		}
		_LOGGER.info(METHOD_NAME+":::Exiting");
	}

	public void doProcessVZWResponsesBatch() throws NCASException
	{
		final String METHOD_NAME = "doProcessVZWResponsesBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try{
				List<Integer> processedRecNbrs = processUnreadVZWPaymentStatusRows(SELECT_UNREAD_PROCESSED_VZW_RESPONSES,REC_PMNT_NOTIF_TEMPLATE_VZW);
				List<Integer> appErrNbrs = processUnreadVZWPaymentStatusRows(SELECT_UNREAD_APP_ERROR_VZW_RESPONSES,REC_PMNT_APP_ERROR_TEMPLATE_VZW);
				List<Integer> pmtnExceedsNbrs = processUnreadVZWPaymentStatusRows(SELECT_UNREAD_PMNT_EXCEEDS_VZW_RESPONSES,REC_PMNT_EXCEEDS_TEMPLATE_VZW);
			    List<Integer> allNbrsList = new ArrayList<Integer>();
			    allNbrsList.addAll(processedRecNbrs);
			    _LOGGER.info(METHOD_NAME+"Processed -Numbers:"+processedRecNbrs);
			    _LOGGER.info(METHOD_NAME+"App Err -Numbers:"+appErrNbrs);
			    _LOGGER.info(METHOD_NAME+"Payment Exceeds- Numbers:"+pmtnExceedsNbrs);
			    allNbrsList.addAll(appErrNbrs);
			    allNbrsList.addAll(pmtnExceedsNbrs);

			    if(allNbrsList.size()>0)
			    {
			    _LOGGER.info(METHOD_NAME+"The list of recordnbrs from the vzw response processing is ::"+allNbrsList.toString());
			    //Now update the emailtimestamp to current time so as to suggest they have been already processed.
			    updateVZWPaymentStatus(allNbrsList);
			    _LOGGER.info(METHOD_NAME+"Updated the VZW_PAYMENT_STATUS table by setting the email process timestamp");
			    }else{
			    	_LOGGER.info(METHOD_NAME+"No Records to be updated.");
			    }


			    //Now work on the reversals.
			    List<PaymentDetails> payDetailObjs = selectVZWReversalPayments();
			    PaymentDetails item = null;
			    int reversalSize = payDetailObjs.size();
			    _LOGGER.info(METHOD_NAME+"The size of the incomplete reversal requests is ::"+reversalSize);
			    if(reversalSize>0)
			    {
				    //update paydetails ep_response_txt with REVERSAL+Currenttimestamp so as to make sure it doesn't get picked up again
				    _LOGGER.info(METHOD_NAME+"About to update the PaymentDetails with the epresponsetext as reversaltext plus timestamp");
				    updatePayDetailsForReversal(payDetailObjs,NcasConstants.BATCH_VZW_RESPONSE);
				    _LOGGER.info(METHOD_NAME+"Updated the PaymentDetails with the epresponsetext as reversaltext plus timestamp");
			    }else{
			    	_LOGGER.info(METHOD_NAME+"No Reversal Records to be updated.");
			    }
		}catch(Exception ex){
			_LOGGER.error(METHOD_NAME + "::  in NCASBOSI Failed \n" +ex.getMessage());
			insertPaymentEmail(null,"", PORTAL_BILLING_NOTIF_TEMPLATE,"",METHOD_NAME,"","Exception processing ::"+METHOD_NAME+"::"+ex.getMessage(),"","",NcasConstants.BATCH_VZW_RESPONSE);
		}
	    _LOGGER.info(METHOD_NAME+"Exiting");
	}

	public List<Integer> processUnreadVZWPaymentStatusRows(String sql,String templateName) throws NCASException
	{
		final String METHOD_NAME = "processUnreadVZWPaymentStatusRows => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		List<VZWPaymentStatus> processedList = null;
		List<Integer> pmntRecordNbrList = new ArrayList<Integer>();

		try{
			processedList = selectUnreadVZWResponses(sql);
			_LOGGER.info(METHOD_NAME+"The size of unread vzw responses for this sql :"+sql+" is::"+processedList.size());
			//read the entries and create a list of the useremaildtls objs and call insertPaymentEmailDtls
			VZWPaymentStatus vzwPayStatus = null;
			UserEmailDetails emailDtls = null;
			List<UserEmailDetails> emailDtlsList = new ArrayList<UserEmailDetails>();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			String userEmail = "";
			User user= null;
			PaymentsInternalInterface paymentsIntImpl = DAOFactory.getInstance().getPaymentsBeanForECP();
			for(int i = 0;i<processedList.size();i++)
			{

				vzwPayStatus = processedList.get(i);
				if(paymentsIntImpl!=null)
					user = paymentsIntImpl.getUserFromECP(vzwPayStatus.getUserOId());
				if(user!=null)
					userEmail = user.getEmail();
				_LOGGER.info(METHOD_NAME+"userEmail::"+userEmail);
				emailDtls = new UserEmailDetails(-1,CommonUtil.acctNbrMaskForPayments(vzwPayStatus.getServiceID(),NcasConstants.VZB_VZW_FLAG_VZW),vzwPayStatus.getPaymentStatus(),userEmail,0,templateName,"",lastUpdated,lastUpdated,"",vzwPayStatus.getPayRecordNbr(),"",vzwPayStatus.getPayRecordNbr(),"",NcasConstants.BATCH_VZW_RESPONSE);
				emailDtlsList.add(emailDtls);
				if(vzwPayStatus.getCustomEmail().length()>0)
				{
					emailDtls = new UserEmailDetails(-1,CommonUtil.acctNbrMaskForPayments(vzwPayStatus.getServiceID(),NcasConstants.VZB_VZW_FLAG_VZW),vzwPayStatus.getPaymentStatus(),vzwPayStatus.getCustomEmail(),0,templateName,"",lastUpdated,lastUpdated,"",vzwPayStatus.getPayRecordNbr(),"",vzwPayStatus.getPayRecordNbr(),"",NcasConstants.BATCH_VZW_RESPONSE);
					emailDtlsList.add(emailDtls);
				}
				pmntRecordNbrList.add(new Integer(vzwPayStatus.getPayRecordNbr()));
			}
			_LOGGER.info(METHOD_NAME+"The payment record numbers getting updated are:"+pmntRecordNbrList);
			insertPaymentEmailDtls(emailDtlsList);
		}catch(Exception ncasex){
			_LOGGER.error(METHOD_NAME+" in NCASBOSI Failed \n" +ncasex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,PaymentsBatchImpl.class,ncasex);
		}
		_LOGGER.info(METHOD_NAME+"::Exiting");
		return pmntRecordNbrList;
	}

	public void doRunEmailBatch(String templateName) throws NCASException
	{
		final String METHOD_NAME = "doRunEmailBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		_LOGGER.info(METHOD_NAME+"templateName:::"+templateName);
		try
		{
		Class cls = Class.forName("com.verizon.enterprise.ncasbosi.dao.Impl.payments.PaymentsEmailImpl");
		if(templateName!=null && templateName.trim().length()>0)
		{
			_LOGGER.info(METHOD_NAME+"Template name is present. Just sending emails for that template");
			Method meth = cls.getMethod(templateName, new Class[] {});
			meth.invoke((PaymentsEmailInterface)cls.newInstance(), new Object[] {});
		}
		else
		{
			_LOGGER.info(METHOD_NAME+"Template name is not present. Sending emails for all the templates");
			PaymentsEmailInterface emailImp = (PaymentsEmailInterface)cls.newInstance();
			emailImp.emailVZBOneTimePaymentStatus();
			emailImp.emailVZWOneTimePaymentSuccess();
			emailImp.emailVZWOneTimePaymentFailure();
			emailImp.emailVZBRecurPaymentFailures();
			emailImp.emailVZBRecurPaymentChanges();
			emailImp.emailVZWRecurPaymentChanges();
			emailImp.emailVZWRecurPaymentApplicationError();
			emailImp.emailRecurVZBPaymentNotification();
			emailImp.emailRecurVZWPaymentNotification();
			emailImp.emailRecurVZWPaymentDeleteNotification();
			emailImp.emailCreditCardexpiration();
			emailImp.emailVZWRecurSetupPaymentsFailure();
			emailImp.emailVZBRecurPaymentsExceedAmount();
			emailImp.emailVZWRecurPaymentsExceedAmount();
			emailImp.emailVZBPaymentDelete();
			emailImp.emailPortalBillingNotif();
			emailImp.emailGCPOneTimePaymentStatus();
			emailImp.emailRecurReversalNotification();
		}
		}catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME+" in NCASBOSI Failed \n" +ex.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950, PaymentsEmailImpl.class, ex);
		}

		_LOGGER.info(METHOD_NAME+":::Exiting");
	}

	public void doOneTimeGCPPayDetailsBatch() throws NCASException
	{
		final String METHOD_NAME = "doOneTimeGCPPayDetailsBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		PaymentResponse payResponse = null;
		GlobalPay globalPay = null;

		try{
			//1.Picking up all the eligible payments from PL_PAY_DETAILS( PAYMENT_DATE is less than or equal to the current date,
			//	PAYMENT_STATUS=Scheduled & VZB_VZW_FLAG is G
			List<PayRef> payRefList =  null;


			Map shortPayMap = (Map)DAOFactory.getInstance().getPaymentsUIImpl().selectPayRefDtls(NcasConstants.PAYMENTS_SHORT_PAY_TYPE);
			payRefList = (List<PayRef>)shortPayMap.get("payRefList");

			List<GlobalPay> gcpPayments = selectGCPPaymentDetails(NcasConstants.PAYMENT_TYPE_ONETIME);
			int paySize = gcpPayments.size();
			PaymentProfile profile = null;
			User user = null;
			_LOGGER.info(METHOD_NAME+" The number of eligible payments is:"+paySize);
			int payId = 0;
			for(int i = 0;i<paySize;i++)
			{
			try{
				globalPay = gcpPayments.get(i);
				payId = globalPay.getPaymentID();
				int payProfileId = globalPay.getProfileID();
				_LOGGER.info(METHOD_NAME+"payProfileId:"+payProfileId);
				_LOGGER.info(METHOD_NAME+"About to send GCP payId"+payId+" payment to EPayments");
				profile = (PaymentProfile) selectPaymentProfileDetails(payProfileId).get("paymentProfile");
				payResponse = webImpl.manageGCPPayment(globalPay,profile,payRefList);
				_LOGGER.info(METHOD_NAME+"Successfully sent GCP payId"+payId+" payment to EPayments");
				updateGCPSuccessResponse(payResponse,globalPay,NcasConstants.PAY_DETAILS_PROCESSED_STATUS,NcasConstants.BATCH_PAY_ONETIME_GCP);
				_LOGGER.info(METHOD_NAME+"Updated GCP payId:"+payId+" with Processed status");
			}catch(InvalidPaymentException iex){
				PaymentResponse payResp = iex.getPaymentResponse("Failed to process the payment..");
				updateGCPFailureResponse(payResp,globalPay,NcasConstants.PAY_DETAILS_FAILED_STATUS,NcasConstants.BATCH_PAY_ONETIME_GCP);
			}catch(PaymentException pex){
				_LOGGER.info(METHOD_NAME + ":: PaymentException  : \n"+pex.getMessage());
				_LOGGER.error(METHOD_NAME + ":: PaymentException  in NCASBOSI : \n" +pex.getMessage());
				updateGCPErrorDescForPayment(pex.getMessage(),globalPay,NcasConstants.BATCH_PAY_ONETIME_GCP);
			}catch(Exception ex){
				_LOGGER.error(METHOD_NAME + "::   Inner Loop Failed \n"+ex.getMessage());
				insertGCPPaymentEmail(globalPay, globalPay.getNickName(),PORTAL_BILLING_NOTIF_TEMPLATE,globalPay.getLoginId(),METHOD_NAME,"","Exception Inner Loop Processing ::"+METHOD_NAME+"::"+ex.getMessage(),globalPay.getEpResponseCode(),Integer.toString(globalPay.getPortalTrackID()),NcasConstants.BATCH_PAY_ONETIME_GCP);
			}
		}
		}
		catch(Exception e){
			_LOGGER.error(METHOD_NAME + "::   in NCASBOSI Failed \n" +e.getMessage());
			if(globalPay == null)
				globalPay = new GlobalPay();
			insertGCPPaymentEmail(globalPay,globalPay.getNickName(), PORTAL_BILLING_NOTIF_TEMPLATE,globalPay.getLoginId(),METHOD_NAME,"","Exception Processing ::"+METHOD_NAME+"::"+e.getMessage(),globalPay.getEpResponseCode(),Integer.toString(globalPay.getPortalTrackID()),NcasConstants.BATCH_PAY_ONETIME_GCP);
		}

		_LOGGER.info(METHOD_NAME+" Exiting");

	}


	public void processPaymentGeneric(String param) throws NCASException
	{
		SelectBadRecurs();
	}

	public void doPaymentsMonitorBatch() throws NCASException {
		final String METHOD_NAME = "doPaymentsMonitorBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		SelectPaymentMonitor instance = null;
		List<PaymentMonitor> paymentsMonitorDataList = null;
		PaymentMonitor record = null;
		boolean oneTimeSummaryInd = false;
		boolean recurSummaryInd = false;
		boolean oneTimeViewInd = false;
		boolean recurViewInd = false;
		
		try{
			StringBuffer oneTimeViewToken = new StringBuffer(); //EMAIL_TOKEN_ONETIME_VIEW
			StringBuffer oneTimeSummaryToken = new StringBuffer(); //EMAIL_TOKEN_ONETIME_SUMMARY
			StringBuffer wirelessFailuresToken = new StringBuffer(); //EMAIL_TOKEN_ONETIME_WIRELESS_FAILURES
			StringBuffer nonWirelessFailuresToken = new StringBuffer(); //EMAIL_TOKEN_ONETIME_NONWIRELESS_FAILURES

			StringBuffer recurViewToken = new StringBuffer(); //EMAIL_TOKEN_RECUR_VIEW
			StringBuffer recurSummaryToken = new StringBuffer(); //EMAIL_TOKEN_RECUR_SUMMARY
			StringBuffer recurFailuresToken = new StringBuffer(); //EMAIL_TOKEN_RECUR_FAILURES
			_LOGGER.info(METHOD_NAME+" trying to get one-time payment complete view..");
			instance = new SelectPaymentMonitor(SELECT_ONETIME_PAYMENTS_COMPLETE_VIEW_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				oneTimeViewInd = true;
				for (int j=0;j<paymentsMonitorDataList.size();j++) {
					record = paymentsMonitorDataList.get(j);
					oneTimeViewToken.append("<TR><TD><STRONG>").append(record.getPaymentStatus()).append("</STRONG></TD>");
					oneTimeViewToken.append("<TD>").append(record.getCount()).append("</TD></TR>");
				   _LOGGER.debug("record -> "+record.toString());
				}
				_LOGGER.info(METHOD_NAME+" got data back for one-time payment complete view..");
			}

			_LOGGER.info(METHOD_NAME+" trying to get recurring payment complete view..");
			instance = new SelectPaymentMonitor(SELECT_RECUR_PAYMENTS_COMPLETE_VIEW_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				recurViewInd = true;
				for (int j=0;j<paymentsMonitorDataList.size();j++) {
					record = paymentsMonitorDataList.get(j);
					recurViewToken.append("<TR><TD><STRONG>").append(record.getPaymentStatus()).append("</STRONG></TD>");
					recurViewToken.append("<TD>").append(record.getCount()).append("</TD></TR>");
				   _LOGGER.debug("record -> "+record.toString());
				}				
				_LOGGER.info(METHOD_NAME+" got data back for recurring payment complete view..");
			}
			
			instance = new SelectPaymentMonitor(SELECT_ONETIME_PAYMENT_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				oneTimeSummaryInd = true;
			for (int j=0;j<paymentsMonitorDataList.size();j++) {
				record = paymentsMonitorDataList.get(j);
				oneTimeSummaryToken.append("<TR><TD><STRONG>").append(record.getPaymentStatus()).append("</STRONG></TD>");
				oneTimeSummaryToken.append("<TD>").append(record.getCount()).append("</TD></TR>");
			   _LOGGER.debug("record -> "+record.toString());
			}
			instance = new SelectPaymentMonitor(SELECT_ONETIME_PAYMENT_WIRELESS_FAILURE_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				wirelessFailuresToken.append("<TABLE id=\"Table1\" cellSpacing=\"1\" cellPadding=\"1\" width=\"1200\" border=\"1\">")
				                     .append("<TR bgColor=\"lightgreen\"><TD><STRONG>OneTime Wireless Payment Failures</STRONG></TD></TR></TABLE>")
				                     .append("<TABLE id=\"Table1\" cellSpacing=\"1\" cellPadding=\"1\" width=\"1200\" border=\"1\">")
				                     .append("<TR><TD><STRONG>").append("SERVICE_ID").append("</STRONG></TD>")
								     .append("<TD><STRONG>").append("EP_TRACK_ID").append("</STRONG></TD>")
				                     .append("<TD><STRONG>").append("EP_TRACK_DATE").append("</STRONG></TD>")
				                     .append("<TD><STRONG>").append("EP_RESPONSE_CODE").append("</STRONG></TD>")
				                     .append("<TD><STRONG>").append("EP_RESPONSE_TXT").append("</STRONG></TD></TR>");

				for (int j=0;j<paymentsMonitorDataList.size();j++) {
					record = paymentsMonitorDataList.get(j);
					wirelessFailuresToken.append("<TR><TD>").append(record.getServiceID()).append("</TD>")
					                     .append("<TD>").append(record.getEpTrackID()).append("</TD>")
                                         .append("<TD>").append(record.getEpTrackDate()).append("</TD>")
                                         .append("<TD>").append(record.getEpRespCode()).append("</TD>")
                                         .append("<TD>").append(record.getEpRespText()).append("</TD></TR>");
				   _LOGGER.debug("record -> "+record.toString());
				}
				wirelessFailuresToken.append("</TABLE>");
			}

			instance = new SelectPaymentMonitor(SELECT_ONETIME_PAYMENT_NONWIRELESS_FAILURE_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				nonWirelessFailuresToken.append("<TABLE id=\"Table1\" cellSpacing=\"1\" cellPadding=\"1\" width=\"1200\" border=\"1\">")
                                        .append("<TR bgColor=\"lightgreen\"><TD><STRONG>OneTime NonWireless Payment Failures</STRONG></TD></TR></TABLE>")
                                        .append("<TABLE id=\"Table1\" cellSpacing=\"1\" cellPadding=\"1\" width=\"1200\" border=\"1\">")
                                        .append("<TR><TD><STRONG>").append("SERVICE_ID").append("</STRONG></TD>")
			                            .append("<TD><STRONG>").append("EP_TRACK_ID").append("</STRONG></TD>")
                                        .append("<TD><STRONG>").append("EP_TRACK_DATE").append("</STRONG></TD>")
                                        .append("<TD><STRONG>").append("EP_RESPONSE_CODE").append("</STRONG></TD>")
                                        .append("<TD><STRONG>").append("EP_RESPONSE_TXT").append("</STRONG></TD></TR>");

				for (int j=0;j<paymentsMonitorDataList.size();j++) {
					record = paymentsMonitorDataList.get(j);
					nonWirelessFailuresToken.append("<TR><TD>").append(record.getServiceID()).append("</TD>")
					                        .append("<TD>").append(record.getEpTrackID()).append("</TD>")
                                            .append("<TD>").append(record.getEpTrackDate()).append("</TD>")
                                            .append("<TD>").append(record.getEpRespCode()).append("</TD>")
                                            .append("<TD>").append(record.getEpRespText()).append("</TD></TR>");
				   _LOGGER.debug("record -> "+record.toString());
				}
				nonWirelessFailuresToken.append("</TABLE>");
			}
			} else {
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Scheduled</STRONG></TD><TD>0</TD></TR>");
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Processedd</STRONG></TD><TD>0</TD></TR>");
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Pending</STRONG></TD><TD>0</TD></TR>");
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Failed</STRONG></TD><TD>0</TD></TR>");
			}

			instance = new SelectPaymentMonitor(SELECT_RECUR_PAYMENT_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				recurSummaryInd = true;
			for (int j=0;j<paymentsMonitorDataList.size();j++) {
				record = paymentsMonitorDataList.get(j);
				recurSummaryToken.append("<TR><TD><STRONG>").append(record.getPaymentStatus()).append("</STRONG></TD>");
				recurSummaryToken.append("<TD>").append(record.getCount()).append("</TD><TR>");
			   _LOGGER.debug("record -> "+record.toString());
			}
			instance = new SelectPaymentMonitor(SELECT_RECUR_PAYMENT_FAILURE_MONITOR);
			paymentsMonitorDataList = instance.getPaymentMonitorData(null);
			if (paymentsMonitorDataList.size()>0) {
				recurFailuresToken.append("<TABLE id=\"Table1\" cellSpacing=\"1\" cellPadding=\"1\" width=\"1200\" border=\"1\">")
                                  .append("<TR bgColor=\"lightgreen\"><TD><STRONG>Recurring Payment Failures</STRONG></TD></TR></TABLE>")
                                  .append("<TABLE id=\"Table1\" cellSpacing=\"1\" cellPadding=\"1\" width=\"1200\" border=\"1\">")
                                  .append("<TR><TD><STRONG>").append("SERVICE_ID").append("</STRONG></TD>")
                                  .append("<TD><STRONG>").append("ORIG_SYSTEM_ID").append("</STRONG></TD>")
                                  .append("<TD><STRONG>").append("ERROR_DESCRIPTION").append("</STRONG></TD>")
                                  .append("<TD><STRONG>").append("EP_TRACK_ID").append("</STRONG></TD>")
                                  .append("<TD><STRONG>").append("EP_TRACK_DATE").append("</STRONG></TD>")
                                  .append("<TD><STRONG>").append("EP_RESPONSE_CODE").append("</STRONG></TD>")
                                  .append("<TD><STRONG>").append("EP_RESPONSE_TXT").append("</STRONG></TD></TR>");
				for (int j=0;j<paymentsMonitorDataList.size();j++) {
					record = paymentsMonitorDataList.get(j);
					recurFailuresToken.append("<TR><TD>").append(record.getServiceID()).append("</TD>")
                                      .append("<TD>").append(record.getOsid()).append("</TD>")
                                      .append("<TD>").append(record.getErrorDesc()).append("</TD>")
					                  .append("<TD>").append(record.getEpTrackID()).append("</TD>")
                                      .append("<TD>").append(record.getEpTrackDate()).append("</TD>")
                                      .append("<TD>").append(record.getEpRespCode()).append("</TD>")
                                      .append("<TD>").append(record.getEpRespText()).append("</TD></TR>");
				   _LOGGER.debug("record -> "+record.toString());
				}
				recurFailuresToken.append("</TABLE>");
			}
			} else {
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Scheduled</STRONG></TD><TD>0</TD></TR>");
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Processedd</STRONG></TD><TD>0</TD></TR>");
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Pending</STRONG></TD><TD>0</TD></TR>");
				oneTimeSummaryToken.append("<TR><TD><STRONG>Total Failed</STRONG></TD><TD>0</TD></TR>");
			}

			if (oneTimeSummaryInd||recurSummaryInd||oneTimeViewInd||recurViewInd) {
				//send email only if we get data
				EmailTemplateInfo templateInfo = new EmailTemplateInfo();
				templateInfo = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo().get(PAY_MONITOR_EMAIL_TEMPLATE);
				String template = templateInfo.getTemplateDesc();
				_LOGGER.debug("pay monitor email template -> "+template);
			
				String emailContent = template.replaceFirst(EMAIL_TOKEN_ONETIME_VIEW, oneTimeViewToken.toString())
                                          .replaceFirst(EMAIL_TOKEN_RECUR_VIEW, recurViewToken.toString())
                                          .replaceFirst(EMAIL_TOKEN_ONETIME_SUMMARY, oneTimeSummaryToken.toString())
                                          .replaceFirst(EMAIL_TOKEN_ONETIME_WIRELESS_FAILURES, wirelessFailuresToken.toString())
                                          .replaceFirst(EMAIL_TOKEN_ONETIME_NONWIRELESS_FAILURES, nonWirelessFailuresToken.toString())
                                          .replaceFirst(EMAIL_TOKEN_RECUR_SUMMARY, recurSummaryToken.toString())
                                          .replaceFirst(EMAIL_TOKEN_RECUR_FAILURES, recurFailuresToken.toString());
				Map<String,Object> emailMap = new HashMap<String,Object>();
				List<String> toAddrList = null;
				List<String> ccAddrList = null;
				toAddrList = JMSUtility.getSplittedMailList(SystemParamConfig.getProperty(PAY_MONITOR_EMAIL_DISTRO));
				_LOGGER.debug("email list -> "+toAddrList.toString());
				emailMap.put(NcasConstants.EMAIL_TO_ADDR, toAddrList);
				emailMap.put(NcasConstants.EMAIL_CC_ADDR, ccAddrList);
				emailMap.put(NcasConstants.EMAIL_SUBJECT, templateInfo.getSubject());
				emailMap.put(NcasConstants.EMAIL_MESSAGE, emailContent);
				commonUtil.sendEmail(emailMap);
			}
		} catch(Exception e){
			_LOGGER.error(METHOD_NAME + "::   in NCASBOSI Failed \n" +e.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}
}
