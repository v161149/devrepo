package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.common.CommonUtil; // contains formatting from double to String method

import com.verizon.enterprise.common.util.commonUtil; //contains Decimal Place formatting Method


public class SPGetInterestCalculationDetails extends BaseStoredProcedure {
	
	private static final Logger _LOGGER = Logger.getLogger(SPGetInterestCalculationDetails.class);
	private static List spInOutList;
	 
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
	     spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetInterestCalculationDetailsMapper()}); 
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});	 
		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS_DESC",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUBSTATUS_DESC",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"NET_INTEREST_ADJ",  getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});	 
	 }
	
	public SPGetInterestCalculationDetails(DataSource dataSource){
		super(dataSource, getVACSchemaName() + "." + NCASBOSIConstants.SP_GET_INT_CALC_DTL, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		String claimNumber = (String)inputMap.get("claimNumber");
		_LOGGER.info("claimNumber::"+claimNumber);

		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add(claimNumber);  //ESG_CLAIM_NUMBER

		/* execute sp */
		Map resMap = executeSP(callList, false);

		String netAmt = null;
		try {
			netAmt = CommonUtil.formatDouble((Double)resMap.get("NET_INTEREST_ADJ")); 
		} catch (Exception e) {
			netAmt = null;
		}
		String formattedNetAmt = commonUtil.formatNumber(netAmt,"#,##0.00 ; -#,##0.00");
		_LOGGER.info("Formatted Net Interest Adjustment Amount"+formattedNetAmt);
		resMap.put("NET_INTEREST_ADJ",formattedNetAmt);
		
		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
