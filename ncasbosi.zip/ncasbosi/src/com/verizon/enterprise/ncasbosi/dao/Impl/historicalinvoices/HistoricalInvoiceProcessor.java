package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.historicalinvoice.HistoricalInvoiceInterface;

/*
 * This class decides which operation to be performed
 */
public class HistoricalInvoiceProcessor {
	private static HistoricalInvoiceInterface interfaceObj;
	private static final Logger _LOGGER = Logger.getLogger(HistoricalInvoiceProcessor.class);
	
	private static synchronized HistoricalInvoiceInterface getHIObject(){
		if(interfaceObj==null){
			_LOGGER.info("Getting the singleton HistoricalInvoice Object");
			interfaceObj = DAOFactory.getInstance().getHistoricalInvoiceImplementationReference();
			_LOGGER.info("Successfully retrieved handle to the HistoricalInvoice Object");
		}
		return interfaceObj;
	}
	
	public static Map processHistoricalInvoice(Object input,String function)throws NCASException{
		_LOGGER.info("Entering processHistoricalInvoice");
		Map responseMap = null;
		try{
			Method method = getHIObject().getClass().getMethod(function, new Class[]{Object.class});
			responseMap = (Map)method.invoke(getHIObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException("HI1001",HistoricalInvoiceProcessor.class,exception.getTargetException());
		}catch(Exception exception){
			throw new NCASException("HI1001",HistoricalInvoiceProcessor.class,exception);
		}
//		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processHistoricalInvoice");
		return responseMap;
	}
}
