package com.verizon.enterprise.ncasbosi.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;


/**
 * This class finds out the url of different DBs from the datasources which are created from it(a reverse process)
 *
 */
public class DataSourceInfo {
	
	private static final Logger _LOGGER = Logger.getLogger(DataSourceInfo.class);

	private static String getDataSourceUrl(DataSource ds){
		Connection conn = null;
		DatabaseMetaData dbMetaData = null;
		String url = "";
		try {
			conn = ds.getConnection();
			dbMetaData = conn.getMetaData();
			if(dbMetaData!=null){
				url = dbMetaData.getURL();				
			}
		} catch (Exception e) {
			_LOGGER.info("unable to get the DB info:"+e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (Exception e) {					
					_LOGGER.info("Error is closing connection resource:"+e);
				}
			}
		}
		return url;
	}
	
	public static Map<String,Object> getDBUrls(){
		Map<String,Object> urlMap = new HashMap<String, Object>();
		urlMap.put("VAM", getDataSourceUrl(DAOFactory.getInstance().getVAMDataSource()));
		urlMap.put("VAC", getDataSourceUrl(DAOFactory.getInstance().getVACDataSource()));
		urlMap.put("VGW", getDataSourceUrl(DAOFactory.getInstance().getVGWDataSource()));
		return urlMap;
	}
	
	
}
