package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPStartPage extends BaseStoredProcedure {
		static private final Logger _LOGGER = Logger.getLogger(SPStartPage.class);
		private static List spInOutList;


		public SPStartPage(DataSource dataSource, String schemaName)
		{
			super(dataSource, schemaName + "." + NCASBOSIConstants.SP_START_PAGE, spInOutList);
		}

		static
		{
			 spInOutList = new ArrayList();
			 spInOutList.add(new Object[]{"ORIG_SYSTEM_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"ACCOUNT_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"INPUT_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PORTAL_API_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		}



		public String executeStoredProcedure(String userId, String debugLevel, Map params) throws Exception
		{
			String osid  = (String) params.get("OSID");
			String accountId  = (String) params.get("ACCOUNT");
			String inputType = (String)params.get("TYPE");

			_LOGGER.info("SpStartPage--accountId------>"+accountId);
			_LOGGER.info("SpStartPage--inputType------>"+inputType);
			String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
			List paramValueList = new ArrayList();
			paramValueList.add(osid);//OSID
			paramValueList.add(accountId);//ACCOUNTID
			paramValueList.add(inputType);//inputType
			paramValueList.add(userId);//APP_USER_ID
			paramValueList.add(debugLevel);//DEBUG_LEVEL
			Map procMap = (HashMap)executeStoredProcedure(paramValueList);

			int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
			String debugStr = (String)procMap.get("MSG_STRING");
			if( returnCode > 0 ) {
			    String[] errMsg = new String[3];
			    errMsg[0] = "getStartPage";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_START_PAGE;
			    errMsg[2] = debugStr;

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			Integer pageID = (Integer)procMap.get("PAGE_ID");
			 return pageID.toString();
		}


		public Map executeStoredProcedure(Object paramValues)throws Exception
		{
			List paramValueList = (List) paramValues;
			return executeSP(paramValueList, false);
		}
}


