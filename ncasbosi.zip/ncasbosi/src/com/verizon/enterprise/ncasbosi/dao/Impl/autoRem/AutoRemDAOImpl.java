package com.verizon.enterprise.ncasbosi.dao.Impl.autoRem;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.BatchSqlUpdate;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.common.ncas.User;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.payments.PaymentDetails;
import com.verizon.enterprise.common.ncas.payments.RecurPayment;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;

public class AutoRemDAOImpl extends JdbcDaoSupport implements NCASBOSIConstants
{
	private static final Logger _LOGGER = Logger.getLogger(AutoRemDAOImpl.class);
	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	private JdbcTemplate dbTemplate;
	
	//SQL
	String SELECT_ELIGIBLE_FOR_AUTO_REM = "SELECT ACCESS_TYPE, BAN, MAN, IMP_LOGIN_ID, PORTAL_LOGIN_ID, CREATED_TIMESTAMP FROM " + getSchemaName() + ".PL_VIEW_AUDIT_T WHERE (ACCESS_TYPE LIKE \'PAY%VW%\' OR ACCESS_TYPE LIKE \'PFB%VW%\') AND CREATED_TIMESTAMP = LAST_UPD_TIMESTAMP ORDER BY ACCESS_TYPE, PORTAL_LOGIN_ID ASC WITH UR";
	String UPDATE_LAST_UPD_TIMESTAMP = "UPDATE " + getSchemaName() + ".PL_VIEW_AUDIT_T SET LAST_UPD_TIMESTAMP=?, LAST_UPDATED_BY=? WHERE CREATED_TIMESTAMP=? AND ACCESS_TYPE=? AND IMP_LOGIN_ID=? AND BAN=?";
	
	protected void initDao() throws Exception
	{
		super.initDao();
	}

	public String getSchemaName()
	{
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		return schemaName;
	}

	protected JdbcTemplate getDBTemplate()
	{
		if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}
	
	public List<Map<String, Object>> getListEligibleForAutoRem() throws NCASException
	{
		final String METHOD_NAME = "getListEligibleForAutoRem::";
		_LOGGER.info(METHOD_NAME + " Entering");
		
		try
		{
			String sql = SELECT_ELIGIBLE_FOR_AUTO_REM;
			_LOGGER.info(METHOD_NAME + "SQL: " + sql);
			SelectAuditDetails selAudDetObj = new SelectAuditDetails(sql);
			List<Map<String, Object>> result = selAudDetObj.getAuditDetails(null);
			_LOGGER.info(METHOD_NAME + " Exiting");
			return result;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
	}
	
	public void updateAuditDetails(List<Map<String, Object>> itemList) throws NCASException
	{
		final String METHOD_NAME = "updateAuditDetails::";
		BatchSqlUpdate updAuditDer = null;
		_LOGGER.info(METHOD_NAME + " Entering");
		_LOGGER.info(METHOD_NAME + " Size=" + itemList.size() + ", Value=" + itemList.toString());
		
		try
		{
			String sql = UPDATE_LAST_UPD_TIMESTAMP;
			_LOGGER.info(METHOD_NAME + "SQL: " + sql);
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			
			updAuditDer = new BatchSqlUpdate(getDataSource(), UPDATE_LAST_UPD_TIMESTAMP);
			
			updAuditDer.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
			updAuditDer.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
			updAuditDer.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
			updAuditDer.declareParameter(new SqlParameter("ACCESS_TYPE", Types.VARCHAR));
			updAuditDer.declareParameter(new SqlParameter("IMP_LOGIN_ID", Types.VARCHAR));
			updAuditDer.declareParameter(new SqlParameter("BAN", Types.CHAR));
					
			updAuditDer.compile();
			
			for(int i=0;i<itemList.size();i++)
			{
				Map<String, Object> item = itemList.get(i);
				Object[] parameterValues = new Object[]{lastUpdated, "AutoRemBatch",
														(Timestamp)item.get("CREATED_TS"),
														(String)item.get("ACCESS_TYPE"),
														(String)item.get("IMP_LOGIN_ID"),
														(String)item.get("BAN")};
				
				updAuditDer.update(parameterValues);
			}
			updAuditDer.flush();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
	}
	
	
	
	class SelectAuditDetails extends JdbcDaoSupport
	{
		private String sql;
		
		public SelectAuditDetails(String sql)
		{
		       this.sql = sql;
		}

		public List<Map<String, Object>> getAuditDetails(Object[] params)
		{
			final String METHOD_NAME = "getAuditDetails => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			return  (List<Map<String, Object>>) getDBTemplate().query(sql, params, new ResultSetExtractor(){
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 	  List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
					          while (rs.next())
					          {
					        	  HashMap<String, Object> auditDetMap =   new HashMap<String, Object>();
					        	  
					        	  auditDetMap.put("ACCESS_TYPE", rs.getString("ACCESS_TYPE").trim());
					        	  auditDetMap.put("BAN", rs.getString("BAN").trim());
					        	  auditDetMap.put("MAN", rs.getString("MAN").trim());
					        	  auditDetMap.put("IMP_LOGIN_ID", rs.getString("IMP_LOGIN_ID").trim());
					        	  auditDetMap.put("PORTAL_LOGIN_ID", rs.getString("PORTAL_LOGIN_ID").trim());
					        	  auditDetMap.put("CREATED_TS", rs.getTimestamp("CREATED_TIMESTAMP"));
    	  
					        	  result.add(auditDetMap);
					          }
					          return result;
				        }});
		}
	}
	
	protected String getBanFromRecuPayId(String recPayId) throws NCASException
	{
		final String METHOD_NAME = "getBanFromRecuPayId => ";
		try
		{
			_LOGGER.info(METHOD_NAME + ", RecPayId=" + recPayId);
			Map<String,RecurPayment> result = DAOFactory.getInstance().getPayments().selectRecurPaymentIDDetails(Integer.parseInt(recPayId));
			RecurPayment recPay = result.get("recurPaymentDetails");
			return recPay.getServiceID().trim();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
	}
	
	protected List getUserEmail(String loginId) throws NCASException
	{
		final String METHOD_NAME = "getUserEmail::";
		_LOGGER.info(METHOD_NAME+"Entering");
		List<String> emailList = new ArrayList<String>();
		try
		{
			User user = DAOFactory.getInstance().getPaymentsBeanForECP().getUserFromECP(loginId);
			_LOGGER.info(METHOD_NAME +" PortalLoginId: " + loginId + ", email: " + user.getEmail());
			emailList.add(user.getEmail());
			return emailList;
		}
		catch(Exception ex){
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
	}
}
