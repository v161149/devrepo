package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.SecabsCandidateApiInput;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/**
 * @author v992473
 * This class represents the vam sp:SERVICE_SECABS_V10
 *
 */
public class SPGetSecabsAcctsByService extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetSecabsAcctsByService.class);
	private static List<Object[]> spInOutList;
	
	static
	{
		 spInOutList = new ArrayList<Object[]>();		 
		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new GetSecabsAcctsByServiceRowMapperImpl()});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"SERVICE_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_STMT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_ID_TS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPGetSecabsAcctsByService(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_SECABS_ACCTS_BY_SUBSCRIPTION, spInOutList);	
	}
	
	public Map executeStoredProcedure(SecabsCandidateApiInput candidateApiInput) throws Exception
	{
		List<Object> paramValueList = new ArrayList<Object>();
		_LOGGER.info("secabsCandidateApiInput::"+candidateApiInput);
		paramValueList.add(NCASBOSIConstants.VAM_USER_ID);//APP_USER_ID
		paramValueList.add(NCASBOSIConstants.VAM_DEBUG_LEVEL);//DEBUG_LEVEL
		
		String serviceId = candidateApiInput.getServiceId();
		String configSubsOid = candidateApiInput.getConfigSubsOid();
		String wherePhrase = candidateApiInput.getWhereStmt();
		String sortOrder = candidateApiInput.getSortOrder();
		String tokenString = candidateApiInput.getTokenString();
		Pagination pagination = candidateApiInput.getPagination();
		
		if(serviceId == null ) {
			serviceId = "";
		}
		if(wherePhrase == null) {
			wherePhrase = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(tokenString == null) {
			tokenString = "";
		}
		
		paramValueList.add(serviceId);//SERVICE_ID
		paramValueList.add(candidateApiInput.getDecimalValue(configSubsOid));//CONFIG_SUBS_OID
		paramValueList.add(wherePhrase);//WHERE_STMT
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(tokenString);//REPORT_ID_TS
		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(pagination.isAllSelect()){
			lineOffSet = "1";
			pageSize = pagination.getMaxSize();
		}else{
			if(lineOffSet==null) {
				lineOffSet = "1";
			}
			if(pageSize==null) {
				pageSize = "50";
			}
		}
		
		paramValueList.add(candidateApiInput.getIntegerValue(lineOffSet));//LINE_OFFSET
		paramValueList.add(candidateApiInput.getIntegerValue(pageSize));//PAGE_SIZE		
		Map<String,Object> resultMap = new HashMap<String,Object>();
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(procMap);
		pagination.setAllSelect(false);
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		Map acctMap = (HashMap)procMap.get("accounts");
		if(acctMap!=null)
			pagination.setResultSize(Integer.toString(acctMap.size()));
		else 
			pagination.setResultSize("0");
		resultMap.put("accountsMap", acctMap);
		resultMap.put("pagination", pagination);
		resultMap.put("RETURN_CODE", procMap.get("RETURN_CODE"));
		resultMap.put("REASON_CODE", procMap.get("REASON_CODE"));
		resultMap.put("ERROR_TEXT", procMap.get("ERROR_TEXT"));
		resultMap.put("SP_SQLCODE", procMap.get("SP_SQLCODE"));
		resultMap.put("SP_SQLTOKENS", procMap.get("SP_SQLTOKENS"));
		resultMap.put("SP_SQLSTATE", procMap.get("SP_SQLSTATE"));

		return resultMap ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
