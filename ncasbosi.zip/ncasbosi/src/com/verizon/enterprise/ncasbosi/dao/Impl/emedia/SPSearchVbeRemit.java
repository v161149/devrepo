package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import com.verizon.enterprise.common.ncas.gbr.VbeRemitPoint;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPSearchVbeRemit extends BaseStoredProcedure
{
	static private final Logger logger = Logger.getLogger(SPSearchVbeRemit.class);

	private static List spInOutList;
	private static List spDownloadInOutList;
	private static List spCommonInOutList;
	private static List spFullDownloadInOutList;

	private static SearchVbeRemitRowMapper rowMapper = null;
	private static SearchVbeRemitDownloadRowMapper downloadRowMapper = null;
	private static SearchVbeRemitFullDownloadRowMapper fullDownloadRowMapper=null;

	static
	{
		rowMapper = new SearchVbeRemitRowMapper();
		downloadRowMapper = new SearchVbeRemitDownloadRowMapper();
        fullDownloadRowMapper=new SearchVbeRemitFullDownloadRowMapper();
		spInOutList = new ArrayList();
		spDownloadInOutList = new ArrayList();
		spCommonInOutList = new ArrayList();
		spFullDownloadInOutList=new ArrayList();
		//only 1 result set is returned
		//however, the way the result set data is stored is different in view vs. download process
		//DOWNLOAD_RESULT_SET_TWO is for Full Download Remit Management Screen
		spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, rowMapper});
		spDownloadInOutList.add(new Object[]{"DOWNLOAD_RESULT_SET_ONE", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, downloadRowMapper});
		spFullDownloadInOutList.add(new Object[]{"DOWNLOAD_RESULT_SET_TWO", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, fullDownloadRowMapper});
		spCommonInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SERVICE_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		spInOutList.addAll(spCommonInOutList);
		spDownloadInOutList.addAll(spCommonInOutList);
		spFullDownloadInOutList.addAll(spCommonInOutList);
	}


	public SPSearchVbeRemit(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SEARCH_VBE_REMIT, spInOutList);
	}


	//used for download functionality
	public SPSearchVbeRemit(DataSource dataSource, String schemaName, boolean downloadVersion)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SEARCH_VBE_REMIT, spDownloadInOutList);
	}
	//used for Full Download Functionality
    public SPSearchVbeRemit(DataSource dataSource, String schemaName, boolean downloadVersion,String fullDownload)
    {
    	super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SEARCH_VBE_REMIT, spFullDownloadInOutList);
    }

	public Map executeStoredProcedure(Map inputMap, String dummyString) throws Exception
	{
		final String METHOD_NAME = "SPSearchVbeRemit::executeStoredProcedure(Map, String) ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		String debugLevel = "0";

		List paramValueList = new ArrayList();
		paramValueList.add("esgportal"); // APP_USER_ID
		paramValueList.add(debugLevel); // IN_DEBUG_LEVEL
		paramValueList.add((String) inputMap.get("SERVICE_TYPE")); //SERVICE_TYPE
		paramValueList.add((String) inputMap.get("CONFIG_SUBS_OID")); //CONFIG_SUBS_OID
		paramValueList.add((String) inputMap.get("WHERE_FILTER")); //WHERE_FILTER
		paramValueList.add((String) inputMap.get("SORT_ORDER")); //SORT_ORDER
		paramValueList.add((String) inputMap.get("LINE_OFFSET")); //LINE_OFFSET
		paramValueList.add((String) inputMap.get("PAGE_SIZE")); //PAGE_SIZE

		return executeStoredProcedure(paramValueList);
	}


	public Map executeStoredProcedure(Object paramValues) throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}

