package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import javax.sql.DataSource;

import com.verizon.enterprise.ncasbosi.dao.Impl.emedia.SPGetEMediaDropDown;

/**
 * @author v898809
 * This class re-uses the GET_EM_DROPDOWN api declared for the emedia project
 */

public class SPGetUsageDropDown extends SPGetEMediaDropDown
{
    public SPGetUsageDropDown(DataSource dataSource){
        super(dataSource, getVAMSchemaName());
    }
}
