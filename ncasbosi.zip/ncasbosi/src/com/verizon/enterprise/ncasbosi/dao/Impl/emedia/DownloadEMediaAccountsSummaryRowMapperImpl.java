package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadEMediaAccountsSummaryRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadEMediaAccountsSummaryRowMapperImpl.class);

	//public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadEMediaAccountsSummaryRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List profilesList = new ArrayList();
		List summary = new ArrayList();
		
		try {
			while(rs.next()) {
				summary = new ArrayList();
				
				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");
				String ban = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String man = rs.getString("MAN");
				String manDan = rs.getString("MAN_DAN");
				String tnType = rs.getString("TN_TYPE");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String startBillPeriod = rs.getString("START_BP_DATE");
				String endBillPeriod = rs.getString("END_BP_DATE");
				String accountName = rs.getString("ACCT_NAME");
				String billPeriod = rs.getString("BILL_PERIOD");
				String verified = rs.getString("VERIFIED_FLAG");
				String mediaType = rs.getString("BM_MEDIA_TYPE");
				String bmCustConfig = rs.getString("BM_CUST_CONFIG_ID");
				String bmNatlInd = rs.getString("BM_NATL_IND");
				String ediNatlInd = rs.getString("EDI_NATL_IND");
				String vz450NatlInd = rs.getString("VZ450_NATL_IND");
				String edi05 = rs.getString("EDI_PROD_ISA_05");
				String edi06 = rs.getString("EDI_PROD_ISA_06");
				String edi02 = rs.getString("EDI_PROD_GS_02");
				String channelCode = rs.getString("CHANNEL_DESC");
				String ediDeliveryOption = rs.getString("EDI_DELIV_OPT");
				String ediDataGroup = rs.getString("EDI_DATA_GROUP");
				String vz450DeliveryOption = rs.getString("VZ450_DELIV_OPT");
				String vz450CustConfig = rs.getString("VZ450_CUST_CFG_ID");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String paperSuppressInd = rs.getString("PAPER_SUPPRESS_IND");
				String paperChargeCode = rs.getString("PAPER_CHARGE_CODE");
				String paperChargeDesc = rs.getString("PAPER_CHARGE_DESC");
				String ebid = rs.getString("EBID");
				String nationalAccount = rs.getString("NBBE_ACCT_NUM");
				String acctSubscriptionOid = rs.getString("ACCT_SUBS_OID");
				
				if(CommonUtil.isNotNull(enterpriseId)) {
					summary.add(new Cell(enterpriseId.trim()));
				}
				if(CommonUtil.isNotNull(corpId)) {
					summary.add(new Cell(corpId.trim()));
				}

				if(CommonUtil.isNotNull(banDan)) {
					summary.add(new Cell(banDan.trim()));
				}
				if(CommonUtil.isNotNull(accountName)) {
					summary.add(new Cell(accountName.trim()));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
					summary.add(new Cell(billPeriod.trim()));
				}
				if(CommonUtil.isNotNull(verified)) {
					summary.add(new Cell(verified.trim()));
				}
				if(CommonUtil.isNotNull(channelCode)) {
					summary.add(new Cell(channelCode.trim()));
				}
				if(CommonUtil.isNotNull(bmCustConfig)) {
					summary.add(new Cell(bmCustConfig.trim()));
				}
				if(CommonUtil.isNotNull(ebid)) {
					summary.add(new Cell(ebid.trim()));
				}
				if(CommonUtil.isNotNull(vz450CustConfig)) {
					summary.add(new Cell(vz450CustConfig.trim()));
				}
				if(CommonUtil.isNotNull(edi05)) {
					summary.add(new Cell(edi05.trim()));
				}
				if(CommonUtil.isNotNull(edi06)) {
					summary.add(new Cell(edi06.trim()));
				}
				if(CommonUtil.isNotNull(edi02)) {
					summary.add(new Cell(edi02.trim()));
				}
				if(CommonUtil.isNotNull(systemAbbrv)) {
					summary.add(new Cell(systemAbbrv.trim()));
				}
				if(CommonUtil.isNotNull(nationalAccount)) {
					summary.add(new Cell(nationalAccount.trim()));
				}
				
				if(CommonUtil.isNotNull(paperSuppressInd)) {
					summary.add(new Cell(paperSuppressInd.trim()));
				}
				if(CommonUtil.isNotNull(paperChargeDesc)) {
					summary.add(new Cell(paperChargeDesc.trim()));
				}
				if(CommonUtil.isNotNull(ediDataGroup)) {
					summary.add(new Cell(ediDataGroup.trim()));
				}

				profilesList.add(summary);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadEMediaAccountsSummaryRowMapperImpl's summary  " + summary);
		}
		return profilesList;
	}
}
