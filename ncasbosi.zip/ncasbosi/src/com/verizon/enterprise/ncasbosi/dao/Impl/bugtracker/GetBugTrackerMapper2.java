package com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import java.util.Map;
import com.verizon.enterprise.common.ncas.bugtracker.IssueDetails;
import java.util.Date;
public class GetBugTrackerMapper2 implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetBugTrackerMapper2 .class);
	

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException	{		
		IssueDetails issueDetail=null;
		_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker.GetBugTrackerMapper2");
		if(rs != null)
		{
			 issueDetail=new IssueDetails();
			
				 Date reporteddate=rs.getDate("CREATED_DATE");
	             String	logged_user=rs.getString("REPORTED_BY");
	             String	comments=rs.getString("COMMENTS");
	             issueDetail.setReportedDate(reporteddate);
	             issueDetail.setUserNameValue(logged_user);
	             issueDetail.setComments(comments);
				
			 
		}
		return issueDetail;
	}
	
	
}

