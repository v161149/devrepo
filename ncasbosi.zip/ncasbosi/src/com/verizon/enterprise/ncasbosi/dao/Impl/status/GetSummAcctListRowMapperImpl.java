package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.status.SSAccountsRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetSummAcctListRowMapperImpl  implements ResultSetExtractor {
	
	static private final Logger _LOGGER = Logger.getLogger(GetSummAcctListRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetSummAcctListRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		_LOGGER.info("After printing  printMetaDataInfo -> ");

		Map returnMap = new HashMap();
		SSAccountsRecord ssAcctsRecord = null;
		double acctSubscriptionOid = 0.0;
		double previousOid = 0.0;
		List refList = new ArrayList();
		String key = "";
		try {
			while (rs.next()) {
				_LOGGER.info("Inside while -> ");
				ssAcctsRecord = new SSAccountsRecord();

				int lineNum = rs.getInt("LINE_NUM");
				String lineNumStr = Integer.toString(lineNum);
				String corpId = rs.getString("CORP_ID");
				String banDan = rs.getString("BAN_DAN");
				String ban = rs.getString("BAN");
				String man = rs.getString("MAN");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String tnType = rs.getString("TN_TYPE");
				
				String acctName = rs.getString("ACCNT_NAME");
				String nbrAcctNum = rs.getString("NBR_NUMBER");
				String billCity = rs.getString("BILL_CITY");
				String billState = rs.getString("BILL_STATE");
				String billType = rs.getString("BILL_TYPE");				
				acctSubscriptionOid = rs.getDouble("SUBSCRIPTION_OID");
				String invoiceType = rs.getString("INVOICE_TYPE");
				

				if (CommonUtil.isNotNull(lineNumStr)) {
					ssAcctsRecord.setLineNum(lineNumStr.trim());
				}
				
				
				if (CommonUtil.isNotNull(corpId)) {
					ssAcctsRecord.setCorpId(corpId.trim());
				}				

				if (CommonUtil.isNotNull(banDan)) {
					ssAcctsRecord.setBan_dan(CommonUtil.getFormattedAccount(
							banDan.trim(), ssAcctsRecord.getOrigSysId(), ""));
				}

				if (CommonUtil.isNotNull(ban)) {
					ssAcctsRecord.setBan(ban.trim());
				}

				if (CommonUtil.isNotNull(ban)) {
					ssAcctsRecord.setBan(ban.trim());
				}

				// if(CommonUtil.isNotNull( banDan))
				// {ssAcctsRecord.setBan_dan(banDan.trim());}
				if (CommonUtil.isNotNull(origSysId)) {
					ssAcctsRecord.setOrigSysId(origSysId.trim());
				}

				if (CommonUtil.isNotNull(tnType)) {
					ssAcctsRecord.setTnType(tnType.trim());
				}

				if (CommonUtil.isNotNull(acctName)) {
					ssAcctsRecord.setAccountName(acctName.trim());
				}
				
				if (CommonUtil.isNotNull(nbrAcctNum)) {
					ssAcctsRecord.setNbrAcctNum(nbrAcctNum.trim());
				}


				if (CommonUtil.isNotNull(billCity)) {
					ssAcctsRecord.setBillCity(billCity.trim());
				}
				
				if (CommonUtil.isNotNull(billState)) {
					ssAcctsRecord.setBillState(billState.trim());
				}

				if (CommonUtil.isNotNull(billType)) {
					ssAcctsRecord.setBillType(billType.trim());
				}

				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				ssAcctsRecord.setAcctSubscriptionOid(key);

				if (CommonUtil.isNotNull(invoiceType)) {
					ssAcctsRecord.setInvoiceType(invoiceType.trim());
				}

				_LOGGER.info("adding record to the list");

				refList.add(ssAcctsRecord);
			}
			returnMap.put("acctList", refList);
			

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			return returnMap;
		}
}