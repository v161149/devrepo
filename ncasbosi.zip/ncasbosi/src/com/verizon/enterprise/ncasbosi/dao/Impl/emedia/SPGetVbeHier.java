package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import com.verizon.enterprise.common.ncas.gbr.VbeReportPoint;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPGetVbeHier extends BaseStoredProcedure
{
	static private final Logger logger = Logger.getLogger(SPGetVbeHier.class);

	private static List spInOutList;
	private static List spDownloadInOutList;
	private static List spCommonInOutList;

	private static GetVbeHierRowMapper1 rowMapper1 = null;
	private static GetVbeHierRowMapper2 rowMapper2 = null;
	private static GetVbeHierDownloadRowMapper2 downloadRowMapper = null;

	static
	{
		rowMapper1 = new GetVbeHierRowMapper1();
		rowMapper2 = new GetVbeHierRowMapper2();
		downloadRowMapper = new GetVbeHierDownloadRowMapper2();

		spInOutList = new ArrayList();
		spDownloadInOutList = new ArrayList();
		spCommonInOutList = new ArrayList();

		spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, rowMapper1});
		spInOutList.add(new Object[]{"RESULT_SET_TWO", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, rowMapper2});
		spDownloadInOutList.add(new Object[]{"DOWNLOAD_RESULT_SET_ONE", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, rowMapper1});
		spDownloadInOutList.add(new Object[]{"DOWNLOAD_RESULT_SET_TWO", getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, downloadRowMapper});

		spCommonInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"USER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spCommonInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spCommonInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		spInOutList.addAll(spCommonInOutList);
		spDownloadInOutList.addAll(spCommonInOutList);
	}


	public SPGetVbeHier(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + "GET_VBE_HIER", spInOutList);
	}


	//used for download functionality
	public SPGetVbeHier(DataSource dataSource, String schemaName, boolean downloadVersion)
	{
		super(dataSource, schemaName + "." + "GET_VBE_HIER", spDownloadInOutList);
	}


	public Map executeStoredProcedure(Map inputMap, String dummyString) throws Exception
	{
		final String METHOD_NAME = "SPGetVbeHier::executeStoredProcedure(Map, String) ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		String debugLevel = "0";

		List paramValueList = new ArrayList();
		paramValueList.add("esgportal"); // APP_USER_ID
		paramValueList.add((String) inputMap.get("USER_ID")); //USER_ID
		paramValueList.add((String) inputMap.get("USER_NAME")); //USER_NAME
		paramValueList.add(debugLevel); // IN_DEBUG_LEVEL
		paramValueList.add((String) inputMap.get("CONFIG_SUBS_OID")); //CONFIG_SUBS_OID

		return executeStoredProcedure(paramValueList);
	}


	public Map executeStoredProcedure(Object paramValues) throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}

