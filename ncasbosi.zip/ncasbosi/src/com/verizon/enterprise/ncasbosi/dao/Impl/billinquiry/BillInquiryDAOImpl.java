package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Properties;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.dao.Interface.billinquiry.BillInquiryInterface;
import com.verizon.enterprise.ncasbosi.dao.Impl.common.SPGetBillAddress;
import com.verizon.enterprise.ncasbosi.billinquiry.bo.OVBillInquiryBO;
import com.verizon.enterprise.ncasbosi.billinquiry.util.BillInquiryHelper;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiryForm;
import com.verizon.kernel.config.Config;
import com.verizon.kernel.xml.XmlParseException;
import com.verizon.enterprise.common.ncas.claim.Claim;

import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_InsertSR_Input;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_InsertSR_Output;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.Default_BindingStub;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.Default_Binding_VzB_spcService_spcRequest;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.VzB_spcSiebel_spcService_spcRequestLocator;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.srvRequest.FinServiceRequestNotes;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.srvRequest.ServiceRequest;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.WSHandlers.VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output;
import com.verizon.enterprise.ncasbosi.webservice.EMEA.axis14.srvRequest.ServiceRequestAttachment;

import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingrequest.pipelines.biztalk.ebillingtooneview.networx.Request;
import com.verizon.enterprise.ncasbosi.webservice.oneview.clientgen.xsd_ebillingresponse.pipelines.biztalk.ebillingtooneview.networx.Response;

import com.verizon.enterprise.common.StackTraceGenerator;
import com.verizon.enterprise.common.ncas.NcasConstants;

public class BillInquiryDAOImpl extends NCASSpringJDBCBase implements
		BillInquiryInterface, NCASBOSIConstants, NcasConstants {

	static private final Logger _LOGGER = Logger
			.getLogger(BillInquiryDAOImpl.class);
	private JdbcTemplate vamJdbcTemplate;// jdbctemplate created for VAM
											// dataSource

	public void setVAMDataSource(DataSource dataSource) {
		vamJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[VAMjdbcTemplate datasource set ]");
	}

	public DataSource getVAMDataSource() {
		return vamJdbcTemplate.getDataSource();
	}

	public Map createBillInquiry(BillInquiry bi) throws NCASException {
		_LOGGER.info("Entering CreateBillInquiry");
		_LOGGER.info("createBI criteria: " + bi);
		String biCategory = null;

		Map resMap = null;
		try
		{
			if (bi != null) {
				biCategory = bi.getBICategory();
			} else {
				_LOGGER.error("throwing exception Bill Inquiry is Null");
				throw new Exception("Bill Inquiry is Null");
			}

			if (biCategory != null && biCategory.equalsIgnoreCase("POV"))
			{
			    resMap = processOVCreateBIUsingSOAP(bi);
			}
			else if (biCategory != null && biCategory.equalsIgnoreCase("ECP"))
			{
				resMap = processECPCreateBI(bi);
			}
			else if (biCategory != null && biCategory.equalsIgnoreCase("PIBI"))
			{
			    resMap = processCreateIBI(bi);
			}
			else
			{
				_LOGGER
						.error("throwing exception BI Category is Null OR Invalid BI Category");
				throw new Exception(
						"BI Category is Null OR Invalid BI Category: "
								+ biCategory);
			}
		} catch (NCASException createBIEx) {
			_LOGGER
					.error("rethrowing exception occured in the processCreateBill Inquiry "
							+ createBIEx.getMessage());
			throw createBIEx;
		} catch (Exception biEx) {
			_LOGGER
					.error("rethrowing exception occured in while identifying category "
							+ biEx.getMessage());
			throw new NCASException("BI0906", BillInquiryDAOImpl.class, biEx);
		}

		_LOGGER.info("CreateBI Result Map is\n "
				+ CommonUtil.mapToString(resMap));
		_LOGGER.info("Exiting CreateBillInquiry");
		return resMap;

	}

	public Map createIBIWS (Map inputparams)throws NCASException
	{
	    _LOGGER.info("Entering createIBIWS");
	    String Default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEA_WS_URL);

	    Map resMap = new HashMap();
		BillInquiry inquiry = null;
		String descriptionText = null;
		String acct_id = null;
		String note = null;
		String noteType = "Note";


	    String soap_in = "null";
		String soap_out = "null";

		String activity_Filename_log = "";  // to log all the filenames in BIWS_AUDIT (filenames seperated by ,)
		String activity_Comment_log = "";  // to log all the comments in BIWS_AUDIT (filecomments seperated by ,)


		// WS Response Object
		String ErrDesc = "N/A";
		String Reason = "N/A";
		String SRNumber = "N/A";
		String Stat = "N/A";

		ArrayList par_urls= null;
		ArrayList activity_comments= null;
		String work_phone = null;
		String mobile_phone = null;
		ArrayList file_ind = null;

		if(inputparams!=null)
		{
			inquiry =  (BillInquiry)inputparams.get("BILLINQUIRY");
			descriptionText = (String)inputparams.get("DESCRIPTION");
			acct_id = (String)inputparams.get("CUST_SIEBEL_ROWID");
			par_urls = (ArrayList) inputparams.get("PARURLS");
			activity_comments = (ArrayList) inputparams.get("ACTIVITYCOMMENT");
			work_phone = (String)inputparams.get("WORKPHONE");
			mobile_phone = (String)inputparams.get("MOBILEPHONE");
			file_ind = (ArrayList)inputparams.get("FILEINDICATOR");
		}
		_LOGGER.info("BillInquiry "+inquiry);

		String acctID = acct_id;

		String integrationId = inquiry.getSrcSysBIID().trim();
		String priority = "3-Medium";
		String Source = "VEC Billing Inquiry";
		String Type = inquiry.getSubcategoryValue();
		String email = inquiry.getSenderEmail();
		String firstName = inquiry.getSenderFirstName();
		String lastName = inquiry.getSenderLastName();
		String mobilePhone = mobile_phone;
		String workPhone = work_phone;
		String description = descriptionText;
		note = descriptionText;

		FinServiceRequestNotes sRNotes = new FinServiceRequestNotes();
		_LOGGER.info("Note :"+note);
		sRNotes.setNote(note);
		sRNotes.setNoteType(noteType);

		FinServiceRequestNotes listsRNotes[]= new FinServiceRequestNotes[1];
		listsRNotes[0] = sRNotes;

		_LOGGER.info("par_urls size "+par_urls.size());

		ServiceRequestAttachment sRAttachments = new ServiceRequestAttachment();
		ServiceRequestAttachment[] SerREqAttachments = new ServiceRequestAttachment[par_urls.size()];

		if(par_urls != null && par_urls.size()>0)
		{
			for(int i=0;i<par_urls.size();i++)
			{
				String ind = (String) file_ind.get(i);
				if(ind!= null && ind.equals("7"))
				{
				String activityComment = (String) activity_comments.get(i);
				String activityFileName = (String) par_urls.get(i);
				_LOGGER.info("par_urls size "+par_urls.get(i));
				_LOGGER.info("Activity Comments size "+activity_comments.get(i));
				activity_Filename_log+=activityFileName+",";
				_LOGGER.info("Activity FileName"+activity_Filename_log);
				activity_Comment_log+=activityComment+",";
				_LOGGER.info("Activity Comment"+activity_Comment_log);

				//Construct Attachments Complex Type
				sRAttachments.setActivityFileName(activityFileName);
				sRAttachments.setActivityComments(activityComment);
				SerREqAttachments[i]=sRAttachments;
				}
			}
		}

		//Construct ServiceRequest Complex Type
		ServiceRequest sR = new ServiceRequest();
		sR.setAccountId(acctID);
		sR.setDescription(description);
		sR.setIntegrationId(integrationId);
		sR.setPriority(priority);
		sR.setSource(Source);
		sR.setType(Type);
		sR.setVzBEmailAddress(email);
		sR.setVzBFirstName(firstName);
		sR.setVzBLastName(lastName);
		sR.setVzBMobilePhone(mobilePhone);
		sR.setVzBWorkPhone(workPhone);
		sR.setListOfFinServiceRequestNotes(listsRNotes);
		if(par_urls != null && par_urls.size()>0)
		{
			sR.setListOfServiceRequestAttachment(SerREqAttachments);
		}
		ServiceRequest[] SerReqs = new ServiceRequest[1];
		SerReqs[0]=sR;


		try{
		VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_InsertSR_Input in1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_InsertSR_Input();
		in1.setListOfVzb_ServiceRequest(SerReqs);
		VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_InsertSR_Output out1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_InsertSR_Output();
		VzB_spcSiebel_spcService_spcRequestLocator inter = new VzB_spcSiebel_spcService_spcRequestLocator();
		Default_Binding_VzB_spcService_spcRequest bindStub= new Default_BindingStub();
		inter.setDefaultEndpointAddress(Default_address);
		bindStub = inter.getDefault();
		out1 = bindStub.insertSR(in1);

		if(out1.getErrDesc()!=null && !out1.getErrDesc().equals(""))
		{
	   	ErrDesc = out1.getErrDesc();
		}
		if(out1.getReason()!=null && !out1.getReason().equals(""))
		{
		Reason = out1.getReason();
		}
		if(out1.getSRNumber()!=null && !out1.getSRNumber().equals(""))
		{
		SRNumber = out1.getSRNumber();
		}
		if(out1.getStatus()!=null && !out1.getStatus().equals(""))
		{
		Stat = out1.getStatus();
		}

		resMap.put("STATUS", Stat);
		resMap.put("EMEA_SR_NUMBER", SRNumber);
		resMap.put("ERR_DESCRIPTION", ErrDesc);
		resMap.put("ERR_REASON", Reason);


		soap_out=Stat+","+SRNumber+","+Reason+","+ErrDesc;
		_LOGGER.info("::SOAPOUT::"+soap_out);

		}catch(Exception biEx)
		{
			_LOGGER.info("rethrowing exception"+biEx.getMessage());
			soap_out = StackTraceGenerator.getExceptionStackInfo(biEx);
			_LOGGER.info("::SOAPOUT::"+soap_out);
			throw new NCASException("IBI1001",BillInquiryDAOImpl.class,biEx);
		}
		finally
		{
		Map input = new HashMap();
		soap_in=acctID+","+integrationId+","+priority+","+Source+","+Type+","+firstName+","+lastName+","+mobilePhone+","+workPhone+","+description+","+note+","+activity_Filename_log+activity_Comment_log;
		_LOGGER.info("::SOAPIN::"+soap_in);
		String action= "INSERT_SR";
		String last_updated_by = "BillInquiry";
		input.put("EMEA_SRKEY", SRNumber);
		input.put("ACTION", action);
		input.put("SOAPIN", soap_in);
		input.put("SOAPOUT", soap_out);
		input.put("LAST_UPDATED_BY",last_updated_by );
		try {
		insertPortalWSLog(input);
		}catch(Exception e)
		{
		_LOGGER.info("::ERROR::"+e);

		}

		}
		_LOGGER.info("Exiting createIBIWS");
		return 	resMap;
	}

	public Map addNoteIBIWS(String note,String srKey) throws NCASException {
		_LOGGER.info("Entering addNoteIBIWS");

	    String Default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEA_WS_URL);

		Map resMap = new HashMap();

	    String soap_in = "null";
		String soap_out = "null";

		// WS Response Object
		String ErrDesc = "N/A";
		String Reason = "N/A";
		String SRNumber = "N/A";
		String Stat = "N/A";

		String noteType = "Note";
		String srNumber = srKey;

		FinServiceRequestNotes sRNotes = new FinServiceRequestNotes();
		_LOGGER.info("Note :"+note);
		sRNotes.setNote(note);
		sRNotes.setNoteType(noteType);

		FinServiceRequestNotes listsRNotes[]= new FinServiceRequestNotes[1];
		listsRNotes[0] = sRNotes;

		// Construct ServiceRequest Complex Type
		ServiceRequest sR = new ServiceRequest();

		sR.setSRNumber(srNumber);
		sR.setListOfFinServiceRequestNotes(listsRNotes);

		ServiceRequest listSerReq[]=new ServiceRequest[1];
		listSerReq[0] = sR;

		try {
			VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input in1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input();
			in1.setListOfVzb_ServiceRequest(listSerReq);
			VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output out1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output();
			VzB_spcSiebel_spcService_spcRequestLocator inter = new VzB_spcSiebel_spcService_spcRequestLocator();
			Default_Binding_VzB_spcService_spcRequest bindStub = new Default_BindingStub();
			inter.setDefaultEndpointAddress(Default_address);
			bindStub = inter.getDefault();
			out1 = bindStub.updateSR(in1);

			if (out1.getErrDesc() != null && !out1.getErrDesc().equals("")) {
				ErrDesc = out1.getErrDesc();
			}
			if (out1.getReason() != null && !out1.getReason().equals("")) {
				Reason = out1.getReason();
			}
			if (out1.getSRNumber() != null && !out1.getSRNumber().equals("")) {
				SRNumber = out1.getSRNumber();
			}
			if (out1.getStatus() != null && !out1.getStatus().equals("")) {
				Stat = out1.getStatus();
			}

			resMap.put("STATUS", Stat);
			resMap.put("EMEA_SR_NUMBER", SRNumber);
			resMap.put("ERR_DESCRIPTION", ErrDesc);
			resMap.put("ERR_REASON", Reason);


			soap_out=Stat+","+SRNumber+","+Reason+","+ErrDesc;
			_LOGGER.info("::SOAPOUT::"+soap_out);
		} catch (Exception biEx) {
			_LOGGER.info("rethrowing exception occured" + biEx.getMessage());
			soap_out = StackTraceGenerator.getExceptionStackInfo(biEx);
			_LOGGER.info("::SOAPOUT::"+soap_out);
			throw new NCASException("IBI1001", BillInquiryDAOImpl.class, biEx);
		} finally {
			Map input = new HashMap();
			soap_in=srNumber+","+note+","+noteType;
			_LOGGER.info("::SOAPIN::"+soap_in);
			String action = "UPDATE_SR_ADD_NOTE";
			String last_updated_by = "BillInquiry";
			input.put("EMEA_SRKEY", SRNumber);
			input.put("ACTION", action);
			input.put("SOAPIN", note);
			input.put("SOAPOUT", soap_out);
			input.put("LAST_UPDATED_BY", last_updated_by);
			try {
				insertPortalWSLog(input);
			} catch (Exception e) {
				_LOGGER.info("::ERROR::" + e);

			}

		}
		_LOGGER.info("Exiting addNoteIBIWS");
		return resMap;
	}

	public Map updateStatusIBIWS(String update_status,String srKey) throws NCASException {
		_LOGGER.info("-->Entering updateStatus");
		String Default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEA_WS_URL);
		Map resMap = new HashMap();

	    String soap_in = "null";
		String soap_out = "null";

		// WS Response Object
		String ErrDesc = "N/A";
		String Reason = "N/A";
		String SRNumber = "N/A";
		String Stat = "N/A";

		String srNumber = srKey;
		String update_stat = update_status;

		// Construct ServiceRequest Complex Type
		ServiceRequest sR = new ServiceRequest();

		sR.setSRNumber(srNumber);
		sR.setStatus(update_stat);

		ServiceRequest listSerReq[]=new ServiceRequest[1];
		listSerReq[0] = sR;

		try {
			VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input in1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input();
			in1.setListOfVzb_ServiceRequest(listSerReq);
			VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output out1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output();
			VzB_spcSiebel_spcService_spcRequestLocator inter = new VzB_spcSiebel_spcService_spcRequestLocator();
			Default_Binding_VzB_spcService_spcRequest bindStub = new Default_BindingStub();
			inter.setDefaultEndpointAddress(Default_address);
			bindStub = inter.getDefault();
			out1 = bindStub.updateSR(in1);

			if (out1.getErrDesc() != null && !out1.getErrDesc().equals("")) {
				ErrDesc = out1.getErrDesc();
			}
			if (out1.getReason() != null && !out1.getReason().equals("")) {
				Reason = out1.getReason();
			}
			if (out1.getSRNumber() != null && !out1.getSRNumber().equals("")) {
				SRNumber = out1.getSRNumber();
			}
			if (out1.getStatus() != null && !out1.getStatus().equals("")) {
				Stat = out1.getStatus();
			}

			resMap.put("STATUS", Stat);
			resMap.put("EMEA_SR_NUMBER", SRNumber);
			resMap.put("ERR_DESCRIPTION", ErrDesc);
			resMap.put("ERR_REASON", Reason);

			soap_out=Stat+","+SRNumber+","+Reason+","+ErrDesc;
			_LOGGER.info("::SOAPOUT::"+soap_out);

		} catch (Exception biEx) {
			_LOGGER.info("rethrowing exception occured" + biEx.getMessage());
			soap_out = StackTraceGenerator.getExceptionStackInfo(biEx);
			_LOGGER.info("::SOAPOUT::"+soap_out);
			throw new NCASException("IBI1001", BillInquiryDAOImpl.class, biEx);
		} finally {
			Map input = new HashMap();
			soap_in=srNumber+","+update_stat;
			_LOGGER.info("::SOAPIN::"+soap_in);
			String action = "UPDATE_SR_STATUS";
			String last_updated_by = "BillInquiry";
			input.put("EMEA_SRKEY", SRNumber);
			input.put("ACTION", action);
			input.put("SOAPIN", soap_in);
			input.put("SOAPOUT", soap_out);
			input.put("LAST_UPDATED_BY", last_updated_by);
			try {
				insertPortalWSLog(input);
			} catch (Exception e) {
				_LOGGER.info("::ERROR::" + e);

			}

		}
		_LOGGER.info("Exiting updateStatus");
		return resMap;
	}

public Map addAttachmentIBIWS (String activiy_comment,String activity_filename,String srKey)throws NCASException
{
    _LOGGER.info("Entering addAttachmentIBIWS");
    String Default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEA_WS_URL);

    Map resMap = new HashMap();

    String soap_in = "null";
	String soap_out = "null";

	// WS Response Object
	String ErrDesc = "N/A";
	String Reason = "N/A";
	String SRNumber = "N/A";
	String Stat = "N/A";

   ServiceRequestAttachment sRAttachments = new ServiceRequestAttachment();
   ServiceRequestAttachment[] SerREqAttachments = new ServiceRequestAttachment[1];

   if(activiy_comment!=null && activity_filename!=null)
	{
	   String activityComment = activiy_comment;
	   _LOGGER.info("activityComment :"+activityComment);
	   String activityFileName = activity_filename;
	   _LOGGER.info("activityFileName :"+activityFileName);

	   sRAttachments.setActivityFileName(activityFileName);
	   sRAttachments.setActivityComments(activityComment);
	}

	SerREqAttachments[0] = sRAttachments;

	String srNumber = srKey;
	ServiceRequest sR = new ServiceRequest();
	sR.setSRNumber(srNumber);

	if(activiy_comment != null && activity_filename!=null)
	{
		sR.setListOfServiceRequestAttachment(SerREqAttachments);
	}

	ServiceRequest[] SerReqs = new ServiceRequest[1];
	SerReqs[0] = sR;


	try{
	VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input in1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input();
	in1.setListOfVzb_ServiceRequest(SerReqs);
	VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output out1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output();
	VzB_spcSiebel_spcService_spcRequestLocator inter = new VzB_spcSiebel_spcService_spcRequestLocator();
	Default_Binding_VzB_spcService_spcRequest bindStub= new Default_BindingStub();
	inter.setDefaultEndpointAddress(Default_address);
	bindStub = inter.getDefault();
	out1 = bindStub.updateSR(in1);

	if(out1.getErrDesc()!=null && !out1.getErrDesc().equals(""))
	{
   	ErrDesc = out1.getErrDesc();
	}
	if(out1.getReason()!=null && !out1.getReason().equals(""))
	{
	Reason = out1.getReason();
	}
	if(out1.getSRNumber()!=null && !out1.getSRNumber().equals(""))
	{
	SRNumber = out1.getSRNumber();
	}
	if(out1.getStatus()!=null && !out1.getStatus().equals(""))
	{
	Stat = out1.getStatus();
	}

	resMap.put("STATUS", Stat);
	resMap.put("EMEA_SR_NUMBER", SRNumber);
	resMap.put("ERR_DESCRIPTION", ErrDesc);
	resMap.put("ERR_REASON", Reason);

	soap_out=Stat+","+SRNumber+","+Reason+","+ErrDesc;
	_LOGGER.info("::SOAPOUT::"+soap_out);
	}catch(Exception biEx)
	{
		_LOGGER.info("rethrowing exception"+biEx.getMessage());
		soap_out = StackTraceGenerator.getExceptionStackInfo(biEx);
		_LOGGER.info("::SOAPOUT::"+soap_out);
		throw new NCASException("IBI1001",BillInquiryDAOImpl.class,biEx);
	}
	finally
	{
	Map input = new HashMap();
	soap_in=srNumber+","+activiy_comment+","+activity_filename;
	_LOGGER.info("::SOAPIN::"+soap_in);
	String action= "UPDATE_SR_ADD_ATTACHMENT";
	String last_updated_by = "BillInquiry";
	input.put("EMEA_SRKEY", SRNumber);
	input.put("ACTION", action);
	input.put("SOAPIN", soap_in);
	input.put("SOAPOUT", soap_out);
	input.put("LAST_UPDATED_BY",last_updated_by );
	try {
	insertPortalWSLog(input);
	}catch(Exception e)
	{
	_LOGGER.info("::ERROR::"+e);

	}

	}
	_LOGGER.info("Exiting addAttachmentIBIWS");
	return 	resMap;
}
public void insertPortalWSLog(Map inputparams)
{
	_LOGGER.info("-->Entering insertPortalWSLog");

	int insCount = 0;

	String vacSRKey = (String)inputparams.get("VAC_SRKEY");
	String emeaSRKey = (String)inputparams.get("EMEA_SRKEY");

	if(vacSRKey==null || vacSRKey.equals(""))
	{
	vacSRKey = "N/A";
	}
	if(emeaSRKey==null || emeaSRKey.equals(""))
	{
	emeaSRKey = "N/A";
	}
	String action = (String) inputparams.get("ACTION");
	String soapin = (String) inputparams.get("SOAPIN");
	String soapout = (String) inputparams.get("SOAPOUT");
	String last_updated_by = (String) inputparams.get("LAST_UPDATED_BY");
	Date last_updated = new Date();

	_LOGGER.info("-->VAC_SR_KEY"+vacSRKey);
	_LOGGER.info("-->EMEA_SR_KEY"+emeaSRKey);
	_LOGGER.info("-->ACTION"+action);
	_LOGGER.info("-->SOAPIN"+soapin);
	_LOGGER.info("-->SOAPOUT"+soapout);
	_LOGGER.info("-->LAST_UPDATED_BY"+last_updated_by);
	_LOGGER.info("-->LAST_UPDATED"+last_updated);

	_LOGGER.info("Insert SQL: "+PORTAL_WS_LOG_INSERT_SQL);

	insCount = vamJdbcTemplate.update(PORTAL_WS_LOG_INSERT_SQL, new Object[]{vacSRKey,emeaSRKey,action,soapout,soapin,last_updated,last_updated_by});

	if(insCount > 0)
	{
	_LOGGER.info("Portal WS logged successfully \n Number of Records logged "+insCount);
	}
	_LOGGER.info("-->Exiting insertPortalWSLog");

}

	public Map getBillInquiry(BillInquiry inquiry) throws NCASException {
		_LOGGER.info("Entering getBillInquiry");
		_LOGGER.info("getBillInquiry trackingID: "
				+ inquiry.getTrackingNumber());
		_LOGGER.info("getBillInquiry Category: " + inquiry.getBICategory());
                _LOGGER.info("getBillInquiry srcSysBIID: "
				+ inquiry.getSrcSysBIID());
		_LOGGER.info("getBillInquiry sourcePortal: "
				+ inquiry.getSourcePortal());
		_LOGGER.info("getBillInquiry OrigLogin: " + inquiry.getOrigLogin());
		_LOGGER.info("getBillInquiry userOid: " + inquiry.getUserOid());
		_LOGGER.info("getBillInquiry entitlementReq: "
				+ inquiry.getEntitlementReq());

		Map resMap = null;
		List inpList = new ArrayList();
                String spMethod = "";

                if (inquiry.getBICategory()!= null && inquiry.getBICategory().equalsIgnoreCase("PIBI")) {
                    try {
                      spMethod = NCASBOSIConstants.SP_GET_INT_BIL_INQ;
                      inpList.add(inquiry.getSrcSysBIID());
                      inpList.add(inquiry.getSourcePortal());
                      inpList.add(Double.valueOf(Long.toString(inquiry.getUserOid())));

                      // PVB 09/2008 Turning on VAC based entitlement checking for any "get"
                      // if coming from VBCC.
                      if (inquiry.getSourcePortal().equals("VBCC"))
                        inpList.add("Y");
                      else
                        inpList.add("N");

                      _LOGGER.info("Called GET_INT_BIL_INQ in VAC");
                      SPGetIBI getIBI = new SPGetIBI(getDataSource());
                      resMap = getIBI.executeStoredProcedure(inpList);
                    } catch (Exception vacEx) {
                      _LOGGER.error(spMethod+" failed in VAC\n" + vacEx.getMessage());
                      throw new NCASException("IBI1001", BillInquiryDAOImpl.class, vacEx);
                    }
                    _LOGGER.info("getIBillInquiry successful");
		    _LOGGER.info("getIBI Result Map is\n " + CommonUtil.mapToString(resMap));
                } else {
                    try {
                      spMethod = NCASBOSIConstants.SP_GET_BI;
                      inpList.add(inquiry.getTrackingNumber());
                      inpList.add(inquiry.getBICategory());
                      inpList.add(inquiry.getSourcePortal());
                      // inpList.add(inquiry.getOrigLogin());
                      inpList.add(Double.valueOf(Long.toString(inquiry.getUserOid())));

                      // PVB 07/2008 Turning on VAC based entitlement checking for any "get"
                      // if coming from VBCC.
                      if (inquiry.getSourcePortal().equals("VBCC"))
                        inpList.add("Y");
                      else
                        inpList.add("N");
                      // Calling GetBI in VAC
                      _LOGGER.info("Called GET_BILL_INQUIRY in VAC");
                      SPGetBI getBI = new SPGetBI(getDataSource());
                      resMap = getBI.executeStoredProcedure(inpList);
                    } catch (Exception vacEx) {
                      _LOGGER.error(spMethod+" failed in VAC\n",vacEx);
                      throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
                    }
                    _LOGGER.info("getBillInquiry successful");
		    _LOGGER.info("getBI Result Map is\n " + CommonUtil.mapToString(resMap));
                }
		_LOGGER.info("Exiting getBillInquiry");
		return resMap;
	}

	public Map updateBillInquiry(BillInquiry bi) throws NCASException {
		_LOGGER.info("Entering updateBillInquiry");
		_LOGGER.info("UpdateBI Criteria " + bi);
		String biCategory = null;
		Map resMap = null;
		try {
			if (bi != null) {
				biCategory = bi.getBICategory();
			} else {
				_LOGGER.error("throwing exception Bill Inquiry is Null ");
				_LOGGER.debug("throwing exception Bill Inquiry is Null ");
				throw new Exception("Bill Inquiry is Null");
			}

			if (biCategory != null && biCategory.equalsIgnoreCase("POV")) {
                resMap = processOVUpdateBIUsingSOAP(bi);
			} else if (biCategory != null && biCategory.equalsIgnoreCase("ECP")) {
				resMap = processECPUpdateBI(bi);
			} else if (biCategory != null && biCategory.equalsIgnoreCase("PIBI")){
				resMap = processIBIUpdateBI(bi);
		    }



			else {
				_LOGGER
						.error("throwing exception Bill Inquiry is Null OR Invalid BI Category");
				_LOGGER
						.debug("throwing exception Bill Inquiry is Null OR Invalid BI Category");

				throw new Exception(
						"BillInquiry is null or BI Category is null or not known");
			}
		} catch (NCASException createBIEx) {
			_LOGGER
					.error("rethrowing exception occured in the processUpdateBillInquiry "
							+ createBIEx.getMessage());
			_LOGGER
					.debug("rethrowing exception occured in the processUpdateBillInquiry "
							+ createBIEx.getMessage());

			throw createBIEx;
		} catch (Exception biEx) {
			_LOGGER
					.error("rethrowing exception occured in while identifying category "
							+ biEx.getMessage());
			_LOGGER
					.debug("rethrowing exception occured in while identifying category "
							+ biEx.getMessage());

			throw new NCASException("BI0906", BillInquiryDAOImpl.class, biEx);
		}

		_LOGGER.info("UpdateBI Result Map is\n "
				+ CommonUtil.mapToString(resMap));
		_LOGGER.info("Exiting updateBillInquiry");
		return resMap;

	}

	public Map getDropdown(String drpdwnName, String biCategory,
			boolean distinctFlg, String osId) throws NCASException {


		_LOGGER.info("Entering BillInquiryDAOImpl::getDropdown()");

		
		Map resMap = null;
		List inpList = new ArrayList();
		inpList.add(drpdwnName);
		inpList.add(biCategory);
		if (distinctFlg) {
			inpList.add("Y");
		} else {
			inpList.add("N");
		}
		inpList.add(osId);

		_LOGGER.info("UpdateBI drpdwnName " + drpdwnName);
		_LOGGER.info("UpdateBI biCategory " + biCategory);
		_LOGGER.info("UpdateBI distinctFlg " + distinctFlg);
		_LOGGER.info("UpdateBI osId " + osId);

		try {
			if(NcasConstants.VBIF_CATEGORY.equalsIgnoreCase(biCategory) && "BI_REASON".equalsIgnoreCase(drpdwnName)){
				SPGetBIDropdown getBIOVDropdowns = new SPGetBIDropdown(getDataSource(),biCategory);
				resMap = getBIOVDropdowns.executeSP(inpList, false);
			}else{
				SPGetBIDropdown getBIOVDropdowns = new SPGetBIDropdown(getDataSource());
				resMap = getBIOVDropdowns.executeStoredProcedure(inpList);
			}
			
			_LOGGER.info("BillInquiryDAOImpl::getDropdown() successful");
		} catch (Exception exp) {
			_LOGGER.error("BillInquiryDAOImpl::getDropdown() failed in VAC \n"+ exp.getMessage());
			throw new NCASException("BIOV1001", BillInquiryDAOImpl.class, exp);
		}
		_LOGGER.info("BillInquiryDAOImpl::getDropdown() Result Map is\n "+ CommonUtil.mapToString(resMap));
		_LOGGER.info("Exiting BillInquiryDAOImpl::getDropdown()");
		return resMap;
	}

	public void TestVACAPI(Object trackingID) {

	}

	/**
	 * Method inserts One View transaction log into the database.
	 *
	 * @author z894579 * (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.BillInquiryInterface#insertOneViewCall(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String)
	 */
	public void insertOneViewCall(String trackId, String actType,
			String reqMsg, String respMsgCode, String respMsg) throws Exception {

		int insCount = 0;

		_LOGGER.info("One View Log trackId:" + trackId);
		_LOGGER.info("One View Log actType:" + actType);
		_LOGGER.info("One View Log reqMsg:" + reqMsg);
		_LOGGER.info("One View Log respMsgCode:" + respMsgCode);
		_LOGGER.info("One View Log respMsg:" + respMsg);

		_LOGGER.info("Insert SQL: " + WS_LOG_INSERT_SQL);
		_LOGGER.info("LAST_UPDATED_BY: " + ONE_VIEW_INSERT_USER);

		insCount = jdbcTemplate.update(WS_LOG_INSERT_SQL, new Object[] {
				trackId, actType, reqMsg, respMsgCode, respMsg,
				ONE_VIEW_INSERT_USER });

		if (insCount > 0) {
			_LOGGER
					.info("One View Response logged successfully \n Number of Records logged "
							+ insCount);
		}

		_LOGGER.info("Exiting inertOneView");

	}

	public Map getBillInquiries(BillInquiryForm input) throws NCASException {
		try {
			_LOGGER.info("Enterrring getBillInquiries");
			if (input == null) {
				_LOGGER.error("throwing exception Bill Inquiry Form is Null ");
				_LOGGER.debug("throwing exception Bill Inquiry Form is Null ");
				throw new Exception("Bill Inquiry Form is Null");
			}
			_LOGGER.info("BI Search:" + input);

			Map output;
			SPGetBIs getBIs = new SPGetBIs(getDataSource());
			output = getBIs.executeStoredProcedure(input);

			_LOGGER.info("Leaving getBillInquirySearch");

			return output;
		} catch (Exception vacEx) {
			_LOGGER.debug("GET BillInquiries\n" + vacEx.getMessage());
			_LOGGER.error("GET BillInquiries\n" + vacEx.getMessage());
			throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
		}

	}// end getBillInquiries

	public Map searchClaims(Map myMap) throws NCASException {
		try {
			_LOGGER.info("Enterrring searchClaims");
			if (myMap == null) {
				_LOGGER.error("throwing exception searchClaims map is Null ");
				_LOGGER.debug("throwing exception searchClaims map is Null ");
				throw new Exception("searchClaims map is Null");
			} else {

			}
			_LOGGER.info("Search Claims Map OK");

			Map resMap;
			SPSearchClaims mySC = new SPSearchClaims(getDataSource());
			resMap = mySC.executeStoredProcedure(myMap);

			_LOGGER.info("search claims  Result Map is\n "
					+ CommonUtil.mapToString(resMap));
			_LOGGER.info("Leaving search claims");

			return resMap;
		} catch (Exception vacEx) {
			_LOGGER.debug("search Claims\n" + vacEx.getMessage());
			_LOGGER.error("search Claims\n" + vacEx.getMessage());
			throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
		}

	}// end searchClaims

	public Map getClaim(Claim claim) throws NCASException {
		try {
			_LOGGER.info("Entering getClaim");
			if (claim == null) {
				_LOGGER
						.error("throwing exception :: claim input object is Null ");
				_LOGGER
						.debug("throwing exception :: claim input object is Null ");
				throw new Exception("claim input object is Null");
			}
			_LOGGER.info("claim input Object::" + claim);

			Map resMap;
			SPGetClaim spGetClaim = new SPGetClaim(getDataSource());
			resMap = spGetClaim.executeStoredProcedure(claim);

			_LOGGER.info("getClaim Result Map is\n "
					+ CommonUtil.mapToString(resMap));
			_LOGGER.info("Leaving getClaim");

			return resMap;
		} catch (Exception vacEx) {
			_LOGGER.debug("getClaim\n" + vacEx.getMessage());
			_LOGGER.error("getClaim\n" + vacEx.getMessage());
			throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
		}
	}

	/** ******************Helper Function ECP/OV******************* */

    private Map processOVCreateBIUsingSOAP(BillInquiry bi) throws NCASException
    {
        _LOGGER.info("Entering processOVCreateBIUsingSOAP");
        Map resMap = null;
        SPCreateBI createBI = null;
        
        try
        {
        	// Creating BI in the VAC
            createBI = new SPCreateBI(getDataSource());
            resMap = createBI.executeStoredProcedure(bi);
        }
        catch (Exception vacEx)
        {
        	_LOGGER.error("Create BI in VAC Failed \n"
                              + vacEx.getMessage());
            throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
        }
           
        _LOGGER.info("Exiting processOVCreateBI");
        return resMap;
    }

	private Map processECPCreateBI(BillInquiry bi) throws NCASException {
		_LOGGER.info("Entering processECPCreateBI");
		Map resMap = null;

		SPCreateBI createBI = null;
		try {
			// Creating BI in the VAC
			createBI = new SPCreateBI(getDataSource());
			resMap = createBI.executeStoredProcedure(bi);
			// resMap.put("TRACKING_ID", ovVO.getTrackingID());

		} catch (Exception vacEx) {

			_LOGGER.debug("Create BI in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("Create BI in VAC Failed \n" + vacEx.getMessage());

			throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
		}

		return resMap;
	}

	private Map processOVUpdateBIUsingSOAP(BillInquiry bi) throws NCASException
	{
        Map resMap = null;
        SPUpdateBI updateBI = null;
        OVBillInquiryBO ovBO = null;
        OneViewRespVO ovVO = null;
        boolean hasOVSucceeded = false;
        SPCreateBI createBI = null;
        BillInquiryHelper biHelper = null;
        //String inputXML = "";
        //String outXML = "";
        Request myRequest = null;
        Response myResponse = null;

        try
        {
            // Sending Create Inquiry to One View
            ovBO = new OVBillInquiryBO();
            ovVO = new OneViewRespVO();
            biHelper = new BillInquiryHelper();

            if (SINGLEVIEW.equalsIgnoreCase(bi.getOSID()))
            {
                myRequest = biHelper.getCancelInputSOAPRequestForSingleView(bi);
			}
			else
			{
	            myRequest = biHelper.getCancelInputSOAPRequest(bi);
			}

            myResponse = ovBO.cancelOVBillInquiryUsingSOAP(myRequest);
            hasOVSucceeded = true;

            ovVO = biHelper.transformOVSOAPResponse(myResponse);
            ovVO.setRequestXML(myRequest.toString());
            ovVO.setResponseXML(myResponse.toString());

            bi.setSrcSysBIID(ovVO.getTrackingID());
            bi.setAction("CANCEL");
            _LOGGER.info("One View Response\n" + ovVO.toString());
        }
        catch (XmlParseException xmlEx)
        {
            hasOVSucceeded = false;
            ovVO = new OneViewRespVO();
            ovVO.setAction("Cancel");
            ovVO.setTrackingID("N/A");
            ovVO
                    .setRequestXML("Could not submit request to One View- Xml creation failed xml was not built due to an error  "
                            + xmlEx.getMessage());
            ovVO.setResponseCode("Create Xml failed");
            ovVO
                    .setResponseXML("Could not submit request to One View- Xml creation failed xml was not built due to an error "
                            + xmlEx.getMessage());
            _LOGGER
                    .error("Could not submit request to One View- Xml creation failed xml was not built due to an error \n"
                            + xmlEx.getMessage());
            throw new NCASException("BI0906", BillInquiryDAOImpl.class, xmlEx);
        }
        catch (Exception oneViewEx)
        {
            hasOVSucceeded = false;
            String ovExMsg = new String();
            ovExMsg = "One View Request not completed due to an error  "
                    + "Error= " + oneViewEx.getMessage() + " URL= "
                    + ovBO.getUrlWSString();
            ovVO.setAction("Cancel");
            ovVO.setTrackingID("N/A");
            ovVO.setResponseCode("One View Call Failed");
            //ovVO.setRequestXML(inputXML);
            ovVO.setRequestXML(myRequest.toString());
            ovVO.setResponseXML(ovExMsg);
            _LOGGER.error("One View Request not completed\n"
                    + oneViewEx.getMessage());
            throw new NCASException("BI0906", BillInquiryDAOImpl.class,
                    oneViewEx);
        }
        finally
        {
            try
            {
                insertOneViewCall(ovVO.getTrackingID(), ovVO.getAction(), ovVO
                        .getRequestXML(), ovVO.getResponseCode(), ovVO
                        .getResponseXML());
            }
            catch (Exception auditEx)
            {
                _LOGGER.error("Audit Log in the VAC Failed \n"
                        + auditEx.getMessage(), auditEx);
                _LOGGER.error("OneView Response\n " + ovVO);
            }
        }
        if (hasOVSucceeded)
        {
            try
            {
                updateBI = new SPUpdateBI(getDataSource());
                resMap = updateBI.executeStoredProcedure(bi);
            }
            catch (Exception vacEx)
            {
                _LOGGER
                        .debug("UPDATE BI in VAC Failed \n"
                                + vacEx.getMessage());
                _LOGGER
                        .error("UPDATE BI in VAC Failed \n"
                                + vacEx.getMessage());
            }
        }
        return resMap;
    }



	private Map processECPUpdateBI(BillInquiry bi) throws NCASException {
		Map resMap = null;
		SPUpdateBI updateBI = null;

		try {
			updateBI = new SPUpdateBI(getDataSource());
			resMap = updateBI.executeStoredProcedure(bi);

		} catch (Exception vacEx) {
			_LOGGER.debug("UPDATE BI in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("UPDATE BI in VAC Failed \n" + vacEx.getMessage());
			throw new NCASException("BI0906", BillInquiryDAOImpl.class, vacEx);
		}

		return resMap;
	}

	private Map processIBIUpdateBI(BillInquiry bi) throws NCASException {
			Map resMap = null;
			SPUpdateBI updateBI = null;

			try {
				updateBI = new SPUpdateBI(getDataSource());
				resMap = updateBI.executeStoredProcedure(bi);

			} catch (Exception vacEx) {
				_LOGGER.debug("UPDATE BI in VAC Failed \n" + vacEx.getMessage());
				_LOGGER.error("UPDATE BI in VAC Failed \n" + vacEx.getMessage());
				throw new NCASException("IBI1001", BillInquiryDAOImpl.class, vacEx);
			}

			return resMap;
	}

	public Map getBillAddress(String ban, String man, String tntype,
			String osId, String billdate) throws NCASException

	{
		_LOGGER.info("Entering getBillAddress");

		_LOGGER.info("ban " + ban);
		_LOGGER.info("man" + man);
		_LOGGER.info("tntype" + tntype);
		_LOGGER.info("osid" + osId);
		_LOGGER.info("billdate" + billdate);

		SPGetBillAddress getbilladdress = new SPGetBillAddress(
				getVAMDataSource());

		List inpList = new ArrayList();

		String appuserid = "USSLBMG";
		String debuglevel = "1";

		inpList.add(appuserid);
		inpList.add(debuglevel);
		inpList.add(man);
		inpList.add(billdate);
		inpList.add(ban);
		inpList.add(billdate);
		inpList.add(osId);

		Map resMap = null;
		try {
			resMap = getbilladdress.executeStoredProcedure(inpList);
			_LOGGER.info("getbilladdress successful");
		}

		catch (Exception vamEx)

		{
			_LOGGER.debug("GET BILL ADDRESS in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("GET BILL ADDRESS in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("GET BILL ADDRESS Failed\n"
					+ vamEx.toString(), BillInquiryDAOImpl.class, vamEx);
		}

		_LOGGER.info("getBillAddress Result Map is\n "
				+ CommonUtil.mapToString(resMap));
		_LOGGER.info("Exiting getBillAddress");
		return resMap;
	}

	public Map getIBICATDropdowns() throws NCASException {
		_LOGGER.info("Entering BillInquiryDAOImpl::getIBICATDropdowns()");

		SPGetIBICATDropdowns getIBICATDropdowns = new SPGetIBICATDropdowns(getDataSource());
		Map resMap = null;
		List inpList = new ArrayList();
		inpList.add(null);

		try {
			resMap = getIBICATDropdowns.executeStoredProcedure(inpList);
			_LOGGER.info("BillInquiryDAOImpl::getIBICATDropdowns() successful");
		} catch (Exception exp) {
			_LOGGER.error("BillInquiryDAOImpl::getIBICATDropdowns() failed in VAC \n"+ exp.getMessage());
			throw new NCASException("IBI1001", BillInquiryDAOImpl.class, exp);
		}
		_LOGGER.info("BillInquiryDAOImpl::getIBICATDropdowns() Result Map is\n "+ CommonUtil.mapToString(resMap));
		_LOGGER.info("Exiting BillInquiryDAOImpl::getIBICATDropdowns()");
		return resMap;
	}

        public Map getIBIDropdowns() throws NCASException {
                _LOGGER.info("Entering BillInquiryDAOImpl::getIBIDropdowns()");

                SPGetIBIDropdowns getIBIDropdowns = new SPGetIBIDropdowns(getDataSource());
                Map resMap = null;
                List inpList = new ArrayList();
                inpList.add(null);

                try {
                        resMap = getIBIDropdowns.executeStoredProcedure(inpList);
                        _LOGGER.info("BillInquiryDAOImpl::getIBIDropdowns() successful");
                } catch (Exception exp) {
                        _LOGGER.error("BillInquiryDAOImpl::getIBIDropdowns() failed in VAC \n"+ exp.getMessage());
                        throw new NCASException("IBI1001", BillInquiryDAOImpl.class, exp);
                }
                _LOGGER.info("BillInquiryDAOImpl::getIBIDropdowns() Result Map is\n "+ CommonUtil.mapToString(resMap));
                _LOGGER.info("Exiting BillInquiryDAOImpl::getIBIDropdowns()");
                return resMap;
        }

        private Map processCreateIBI(BillInquiry bi) throws NCASException {
                _LOGGER.info("Entering processCreateIBI");
                Map resMap = null;

                SPCreateIBI createIBI = null;
                try {
                        // Creating IBI in the VAC
                        createIBI = new SPCreateIBI(getDataSource());
                        resMap = createIBI.executeStoredProcedure(bi);
                } catch (Exception vacEx) {
                        _LOGGER.debug("Create IBI in VAC Failed \n" + vacEx.getMessage());
                        _LOGGER.error("Create IBI in VAC Failed \n" + vacEx.getMessage());
                        throw new NCASException("IBI1001", BillInquiryDAOImpl.class, vacEx);
                }
                return resMap;
        }

        public Map deferredDownloadBillInquiries(BillInquiryForm input) throws NCASException {
                try {
                        _LOGGER.info("Enterrring deferredDownloadBillInquiries");
                        if (input == null) {
                                _LOGGER.error("throwing exception Bill Inquiry Form is Null ");
                                _LOGGER.debug("throwing exception Bill Inquiry Form is Null ");
                                throw new Exception("Bill Inquiry Form is Null");
                        }
                        _LOGGER.info("BI Search download:" + input);

                        Map output;
                        SPGetDLVerBIs getDLVerBIs = new SPGetDLVerBIs(getDataSource());
                        output = getDLVerBIs.executeStoredProcedure(input);

                        _LOGGER.info("Leaving deferredDownloadBillInquiries");

                        return output;
                } catch (Exception vacEx) {
                        _LOGGER.debug("GET deferredDownloadBillInquiries\n" + vacEx.getMessage());
                        _LOGGER.error("GET deferredDownloadBillInquiries\n" + vacEx.getMessage());
                        throw new NCASException("IBI1001", BillInquiryDAOImpl.class, vacEx);
                }
        }

    	public Map testEMEAWS(BillInquiry bi) throws NCASException {
    		_LOGGER.info("Entering testEMEAWS");
    		Map resMap = new HashMap();
    		String defaultAddress = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEA_WS_URL);

    		// WS Response Object
    		String ErrDesc = "N/A";
    		String Reason = "N/A";
    		String SRNumber = "N/A";
    		String Stat = "N/A";

    		_LOGGER.info("trackingNum = " + bi.getTrackingNumber());
    		_LOGGER.info("Note  = " + bi.getInquiryMemo());

    		//added to allow us to enter WS endpoint on test jsp and
    		// call that instead. PVB 03/2009
    		_LOGGER.info("defaultAddress (from properties file) = " + defaultAddress);
    		String passedDefaultAddress = bi.getCustWO().trim();
    		_LOGGER.info("passed endpoint = " + passedDefaultAddress);
    		if ((passedDefaultAddress != null) && (passedDefaultAddress.length() > 0))
    			defaultAddress = passedDefaultAddress;
    		_LOGGER.info("default address (after logic to see if passed from jsp) = " + defaultAddress);

    		String note = bi.getInquiryMemo();
    		String noteType = "Note";
    		String srNumber = bi.getTrackingNumber();


    		FinServiceRequestNotes sRNotes = new FinServiceRequestNotes();
    		_LOGGER.info("Note :"+note);
    		sRNotes.setNote(note);
    		sRNotes.setNoteType(noteType);

    		FinServiceRequestNotes listsRNotes[]= new FinServiceRequestNotes[1];
    		listsRNotes[0] = sRNotes;


    		// Construct ServiceRequest Complex Type
    		ServiceRequest sR = new ServiceRequest();

    		sR.setSRNumber(srNumber);
    		sR.setListOfFinServiceRequestNotes(listsRNotes);

    		ServiceRequest listSerReq[]=new ServiceRequest[1];
    		listSerReq[0] = sR;

    		try {
    			VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input in1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Input();
    			in1.setListOfVzb_ServiceRequest(listSerReq);
    			VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output out1 = new VzB_spcMNCGOGI_spcSiebel_spcServiceRequest_spcWrapper_UpdateSR_Output();
    			VzB_spcSiebel_spcService_spcRequestLocator inter = new VzB_spcSiebel_spcService_spcRequestLocator();
    			Default_Binding_VzB_spcService_spcRequest bindStub = new Default_BindingStub();
    			inter.setDefaultEndpointAddress(defaultAddress);
    			bindStub = inter.getDefault();

    			out1 = bindStub.updateSR(in1);

    			if (out1.getErrDesc() != null && !out1.getErrDesc().equals("")) {
    				ErrDesc = out1.getErrDesc();
    			}
    			if (out1.getReason() != null && !out1.getReason().equals("")) {
    				Reason = out1.getReason();
    			}
    			if (out1.getSRNumber() != null && !out1.getSRNumber().equals("")) {
    				SRNumber = out1.getSRNumber();
    			}
    			if (out1.getStatus() != null && !out1.getStatus().equals("")) {
    				Stat = out1.getStatus();
    			}

    			resMap.put("STATUS", Stat);
    			resMap.put("EMEA_SR_NUMBER", SRNumber);
    			resMap.put("ERR_DESCRIPTION", ErrDesc);
    			resMap.put("ERR_REASON", Reason);
				resMap.put("SERVICE_ENDPOINT",defaultAddress);


    			_LOGGER.info("STATUS"+Stat);
    			_LOGGER.info("EMEA_SR_NUMBER"+SRNumber);
    			_LOGGER.info("ERR_DESCRIPTION"+ErrDesc);
    			_LOGGER.info("ERR_REASON"+Reason);
    			_LOGGER.info("SERVICE_ENDPOINT"+defaultAddress);


    		} catch (Exception biEx) {
    			_LOGGER.info("rethrowing exception occured" + biEx.getMessage());
    			_LOGGER.info(StackTraceGenerator.getExceptionStackInfo(biEx));
    			throw new NCASException("IBI1001", BillInquiryDAOImpl.class, biEx);
    		}
    		_LOGGER.info("Exiting testEMEAWS");

    		return resMap;
    	}


	public Map testOneView(BillInquiry bi) throws NCASException {
		// This is 'test' method - allows us to call OV in prod without
		// really doing anything - but checking connectivity. - 03/2009
		_LOGGER.info("Entering testOneView: " + bi);
		Map resMap = new HashMap();
		BillInquiryHelper biHelper = null;
		Request myRequest = null;
		Response myResponse = null;
		OVBillInquiryBO ovBO = null;
		String Default_address = NCASBOSIConfig
				.getProperty(NCASBOSIConstants.ONE_VIEW_WS_URL_IDENTIFIER);
		_LOGGER.info("One View WS URL=" + Default_address);
		try {
			ovBO = new OVBillInquiryBO();
			biHelper = new BillInquiryHelper();
			// Sending test cancel to One View
			_LOGGER.info("One View Response\n + Entering Try");
			myRequest = biHelper.getCancelInputSOAPRequest(bi);
			_LOGGER.info("One View WS Req: " + myRequest.toString());
			myResponse = ovBO.cancelOVBillInquiryUsingSOAP(myRequest);
			_LOGGER.info("One View WS Resp: " + myResponse.toString());
			resMap.put("TRACKINGID",myResponse.getTrackingID());
			resMap.put("RESPONSE_CODE", myResponse.getReturnMsgCode() +  myResponse.getReturnMsgText() );
			resMap.put("RESPONSE_MESSAGE", myResponse.toString());
			resMap.put("ACTION", "Cancel");
			resMap.put("SERVICE_ENDPOINT",Default_address);
		} catch (Exception ex) {
			throw new NCASException("BI0906", BillInquiryDAOImpl.class, ex);
		}
		return resMap;
	}//end testOneView

} // end BillInquiryImpl
