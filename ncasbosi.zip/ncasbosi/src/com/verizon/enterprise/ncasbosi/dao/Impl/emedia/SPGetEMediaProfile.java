package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.core.RowCallbackHandler;

import org.apache.log4j.Logger;

public class SPGetEMediaProfile extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetEMediaProfile.class);
	
	private static List spInOutList;
	
	private static GetEMediaProfileRowMapperImpl rowMapper;

	static
	{
		 rowMapper = new GetEMediaProfileRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"profiles",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPGetEMediaProfile(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_EM_PROFILE, spInOutList);	
	}

	public Map executeStoredProcedure(String userId, String debugLevel, String configSubsOid)throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(configSubsOid);//CONFIG_SUBS_OID
		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
