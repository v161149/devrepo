package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaKeyProfile;
import com.verizon.enterprise.common.eMedia.EMediaSubscriber;
import com.verizon.enterprise.common.eMedia.GBREMediaProfile;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.gbr.GbrComponent;
import com.verizon.enterprise.common.ncas.gbr.GbrOrgPair;
import com.verizon.enterprise.common.ncas.gbr.GbrOrgPairComparator;
import com.verizon.enterprise.common.ncas.gbr.GetGbrComponentDO;

public class GetGBROrgsRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger
			.getLogger(GetGBROrgsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetGBROrgsRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();

		ArrayList orgPairs = new ArrayList();
		ArrayList org1s = new ArrayList();
		GbrOrgPair orgPair = null;

		Date todayDate = new Date();

		try {
			while (rs.next()) {

				orgPair = new GbrOrgPair();
				// int lineNum = rs.getInt("LINE_NUM");
				String orgLevel1Name = rs.getString("ORG_LEVEL1_NAME");
				String orgLevel1Number = rs.getString("ORG_LEVEL1_NO");
				String orgLevel2Name = rs.getString("ORG_LEVEL2_NAME");
				String orgLevel2Number = rs.getString("ORG_LEVEL2_NO");
				String orgAcctInd = rs.getString("ACCT_IND");

				List valuesList = new ArrayList();
				valuesList.add(orgLevel1Name);
				valuesList.add(orgLevel1Number);
				valuesList.add(orgLevel2Name);
				valuesList.add(orgLevel2Number);
				valuesList.add(orgAcctInd);
				CommonUtil.prettyPrintValues(valuesList);
				
				String status = "";

				if (CommonUtil.isNotNull(orgLevel1Name)) {
					orgPair.setOrg1(orgLevel1Name.trim());
				}
				if (CommonUtil.isNotNull(orgLevel1Number)) {
					orgPair.setOrg1Oid(orgLevel1Number.trim());
				}
				if (CommonUtil.isNotNull(orgLevel2Name)) {
					orgPair.setOrg2(orgLevel2Name.trim());
				}
				if (CommonUtil.isNotNull(orgLevel2Number)) {
					orgPair.setOrg2Oid(orgLevel2Number.trim());
				}
				_LOGGER.info("in Use Value " + orgAcctInd);
				if (CommonUtil.isNotNull(orgAcctInd)) {
					orgPair.setIsActive(orgAcctInd.trim());
				}

				// refList.add(waiverRecord);
				orgPairs.add(orgPair);
				org1s.add(orgPair);
			}

			// return drop down list of org 1's.
			// list is sorted by org 1 and does not have duplicates
			GbrOrgPairComparator cmpr = new GbrOrgPairComparator();
			int length = org1s.size();
			Collections.sort(org1s, cmpr);
			String org1 = null;
			// remove dups - start at and and work way to beginning because
			// remove() changes .get numbering.
			for (int i = (length - 1); i >= 0; i--) {
				_LOGGER.debug("Comparing " + org1 + "and" + orgPair.getOrg1());
				orgPair = (GbrOrgPair) org1s.get(i);
				if (stringsEqual(org1, orgPair.getOrg1())) {
					org1s.remove(i); // already seen this org1 before so remove
										// it.
				} else {
					org1 = orgPair.getOrg1(); // new org1, leave ArrayList alone
												// and remember value for next
												// time.
				}

			}
			returnMap.put("orgPairs", orgPairs);
			returnMap.put("org1s", org1s);

		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			throw nfe;
		}
		return returnMap;
	}
	/* compare 2 strings for equality */
	boolean stringsEqual(String in1, String in2)
	{
		if (in1 == null && in2 == null)
			return true;

		if (in1 == null && in2 != null)
			return false;

		if (in1 != null && in2 == null)
			return false;

		if (in1.equals(in2))
			return true;
		else
			return false;

	}
}
