package com.verizon.enterprise.ncasbosi.dao.Impl.ticket;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.ticket.Reason;


public class GetReasonResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetReasonResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetReasonResultSetRowMapper::mapRow rowNum - " + rowNum);

		Reason reasonRow = new Reason();


		reasonRow.setReasonId(rs.getInt("REASON_ID"));
		reasonRow.setCategory(rs.getString("CAT_DESC"));
		reasonRow.setCategoryCode(rs.getString("CAT_CODE"));
		reasonRow.setCode(rs.getString("REASON_CODE"));
		reasonRow.setDesc(rs.getString("REASON_DESC"));
		reasonRow.setFilter(rs.getString("FILTER"));
		reasonRow.setLinkParam(rs.getString("LINKPARAM"));
		reasonRow.setMarkup1(rs.getString("MARKUP1"));
		reasonRow.setMarkup2(rs.getString("MARKUP2"));
		reasonRow.setPageId(rs.getInt("PAGE_ID"));
		String pageSubset = rs.getString("PAGE_SUBSET");
		if (pageSubset==null)
			pageSubset = "";
		pageSubset = pageSubset.trim();
		if(pageSubset.isEmpty())
			pageSubset = "ALL";
		reasonRow.setPageSubset(pageSubset);
		reasonRow.setPortal(rs.getString("PORTAL"));
		reasonRow.setUserList(rs.getString("USERLIST"));

		return reasonRow;
	}
}


