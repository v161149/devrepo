package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadEMediaRecreateRequestRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadEMediaRecreateRequestRowMapperImpl.class);

	//public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	public Object extractData(ResultSet rs) throws SQLException {
		//_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::mapRow rowNumber -> " + rowNum);
		_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List recreateList = new ArrayList();
		List recreate = new ArrayList();
		
		try {
			/*
			recreate.add(new Cell("Request Number"));
			recreate.add(new Cell("Request Status"));
			recreate.add(new Cell("Config Type"));
			recreate.add(new Cell("Request Year"));
			recreate.add(new Cell("Request Month"));
			recreate.add(new Cell("Profile Indicator"));
			recreate.add(new Cell("User ID"));
			recreate.add(new Cell("User"));
			recreate.add(new Cell("Profile"));
			recreate.add(new Cell("Customer"));
			recreate.add(new Cell("Comments"));
			
			//Add header
			recreateList.add(recreate);
			*/

			while(rs.next()) {
				recreate = new ArrayList();
	
				
				int requestNumber = rs.getInt("REQUEST_NUMBER");				
				String requestStatus = rs.getString("REQUEST_STATUS");
				String serviceType = rs.getString("SERVICE_TYPE");
				String requestYear = rs.getString("REQUEST_YEAR");
				String requestMonth = rs.getString("REQUEST_MONTH");
				String recreateProfileIndicator = rs.getString("RECREATE_PROF_IND");
				String userId = rs.getString("EXT_UPDT_USR_ID");
				String userName = rs.getString("EXT_UPDT_USR_NAME");
				String configId = rs.getString("CONFIG_ID");
				String companyName = rs.getString("COMPANY_NAME");
				String requestComment = rs.getString("REQUEST_COMMENT");
		
				recreate.add(new Cell(new Integer(requestNumber).toString()));
				if(CommonUtil.isNotNull(requestStatus)) {
					recreate.add(new Cell(requestStatus.trim()));
				}
				if(CommonUtil.isNotNull(serviceType)) {
					recreate.add(new Cell(serviceType.trim()));
				}
				if(CommonUtil.isNotNull(requestYear)) {
					recreate.add(new Cell(requestYear.trim()));
				}
				if(CommonUtil.isNotNull(requestMonth)) {
					recreate.add(new Cell(requestMonth.trim()));
				}
				if(CommonUtil.isNotNull(recreateProfileIndicator)) {
					recreate.add(new Cell(recreateProfileIndicator.trim()));
				}
				if(CommonUtil.isNotNull(userId)) {
					recreate.add(new Cell(userId.trim()));
				}
				if(CommonUtil.isNotNull(userName)) {
					recreate.add(new Cell(userName.trim()));
				}
				if(CommonUtil.isNotNull(configId)) {
					recreate.add(new Cell(configId.trim()));
				}
				if(CommonUtil.isNotNull(companyName)) {
					recreate.add(new Cell(companyName.trim()));
				}
				if(CommonUtil.isNotNull(requestComment)) {
					recreate.add(new Cell(requestComment.trim()));
				}
												
				recreateList.add(recreate);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			//throw new NCASException("Exception occured while parsing the resultset \n"+pe.toString(),GetProfileRowMapperImpl.class,pe);
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("SearchEMediaProfile's recreate  " + recreate);
		}
		return recreateList;
	}
}

