package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.status.SSAccountsRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetNamedAcctListsRowMapperImpl  implements ResultSetExtractor {
	
	static private final Logger _LOGGER = Logger.getLogger(GetNamedAcctListsRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetNamedAcctListsRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		SSAccountsRecord ssacctRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = new ArrayList();
		String key = "";
		try{
			while(rs.next()) {
				
				ssacctRecord = new SSAccountsRecord();
				int lineNum = rs.getInt("LINE_NUM");
				String acctListName = rs.getString("ACCT_LIST_NAME");
				double subOid 		= rs.getDouble("SUBSCRIBER_OID");
				String subName 		= rs.getString("SUBSCRIBER_NAME");
			
				if(CommonUtil.isNotNull(acctListName)) {ssacctRecord.setAcctListName(acctListName.trim());}
				
				key = CommonUtil.convertStringFromDouble(subOid);
				ssacctRecord.setSubscriberOid(key);
				if(CommonUtil.isNotNull( subName)) {ssacctRecord.setAccountName(subName.trim());}

				refList.add(ssacctRecord);
				returnMap.put("customList",refList);
					
			}

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			return returnMap;
		}
}