package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetSecabsSummaryRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetSecabsSummaryRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetSecabsSummaryRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();

		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = null;
		String key = "";

		try{
			while(rs.next()) {
				emediaRecord = new EMediaRecord();

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");
				String ban = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String man = rs.getString("MAN");
				String manDan = rs.getString("MAN_DAN");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String backEndSystem = rs.getString("BACKEND_SYSTEM"); 
				String billPeriod = rs.getString("BILL_PERIOD");
				String channelCode = rs.getString("CHANNEL_CODE");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String systemDesc = rs.getString("SYST_DESCRIPTION");
				acctSubscriptionOid = rs.getDouble("ACCT_SUBS_OID");
				String accountName = rs.getString("ACCT_NAME");

				
				if(CommonUtil.isNotNull(enterpriseId)) {emediaRecord.setEnterprise(enterpriseId.trim());}
				if(CommonUtil.isNotNull(corpId)) {emediaRecord.setCorp(corpId.trim());}
				if(CommonUtil.isNotNull(ban)) {emediaRecord.setBan(ban.trim());}
				if(CommonUtil.isNotNull(banDan)) {emediaRecord.setBan_dan(CommonUtil.getFormattedAccount(banDan.trim(),emediaRecord.getOrigSysId(), ""));}
				if(CommonUtil.isNotNull(man)) {emediaRecord.setMan(man.trim());}
				if(CommonUtil.isNotNull(manDan)) {emediaRecord.setMan_dan(CommonUtil.getFormattedAccount(manDan.trim(),emediaRecord.getOrigSysId(), ""));}
				if(CommonUtil.isNotNull(origSysId)) {emediaRecord.setOrigSysId(origSysId.trim());}
				if(CommonUtil.isNotNull(backEndSystem)) {emediaRecord.setBackEndSYstem(backEndSystem.trim());}
				if(CommonUtil.isNotNull(billPeriod)) {emediaRecord.setBillPeriod(billPeriod.trim());}
				if(CommonUtil.isNotNull(channelCode)) {emediaRecord.setChannelCode(channelCode.trim());}
				if(CommonUtil.isNotNull(systemAbbrv)) {emediaRecord.setSystemAbbrv(systemAbbrv.trim());}
				if(CommonUtil.isNotNull(systemDesc)) {emediaRecord.setSystemDesc(systemDesc.trim());}
				if(CommonUtil.isNotNull(accountName)) {emediaRecord.setAccountName(accountName.trim());}
                
				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				emediaRecord.setAcctSubscriptionOid(key);

				if(previousOid!=acctSubscriptionOid){
					refList = new ArrayList();
					returnMap.put(key,refList);
				}
				refList.add(emediaRecord);
				previousOid = acctSubscriptionOid;
			}

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			return returnMap;
		}
}
