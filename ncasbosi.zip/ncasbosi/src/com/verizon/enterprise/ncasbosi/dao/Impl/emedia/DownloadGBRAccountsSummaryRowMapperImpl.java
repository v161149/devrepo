package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadGBRAccountsSummaryRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadGBRAccountsSummaryRowMapperImpl.class);

	//public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadGBRAccountsSummaryRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List profilesList = new ArrayList();
		List summary = new ArrayList();
		double acctSubscriptionOid=0.0;
		
		try {
			while(rs.next()) {
				summary = new ArrayList();
				
				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");
				String ban = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String man = rs.getString("MAN");
				String manDan = rs.getString("MAN_DAN");
				String tnType = rs.getString("TN_TYPE");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String backEndSYstem = rs.getString("BACKEND_SYSTEM");
				String accountName = rs.getString("ACCT_NAME");
				String billPeriod = rs.getString("BILL_PERIOD");
				String channelCode = rs.getString("CHANNEL_CODE");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String systemDesc = rs.getString("SYST_DESCRIPTION");
				acctSubscriptionOid = rs.getDouble("ACCT_SUBS_OID");
                String invoiceType = rs.getString("INVOICE_TYPE");
                String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");
                String regionName = rs.getString("GBR_REGION_NAME");
                
                String eligibilityInd = rs.getString("ELIGIBILITY_IND");
                String manBillDate = rs.getString("MAN_BILL_DATE"); 
                String billingFrequency = rs.getString("BILLING_FREQ");
				
				if(CommonUtil.isNotNull(corpId)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(corpId.trim())));
				}
				
				if(ban.trim().equals(banDan.trim()))
				{
					if(CommonUtil.isNotNull(ban)) {
						summary.add(new Cell(commonUtil.excelTextValueOf(ban.trim())));
					}
				}else {
					if(CommonUtil.isNotNull(ban)) {
						summary.add(new Cell(commonUtil.excelTextValueOf(ban.trim() +" (" + banDan.trim() + ")")));
					}
				}
				

				if(CommonUtil.isNotNull(accountName)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(accountName.trim())));
				}
				if(CommonUtil.isNotNull(gbrInvoiceType) || CommonUtil.isNotNull(regionName)) {
					summary.add(new Cell(regionName.trim() + "/" + gbrInvoiceType.trim()));
				}

				if(CommonUtil.isNotNull(systemAbbrv)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(systemAbbrv.trim())));
				}
				/*
				if(CommonUtil.isNotNull(paperChargeCode)) {
					summary.add(new Cell(paperChargeCode.trim()));
				}
				*/
				
				if(CommonUtil.isNotNull(billPeriod)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(billPeriod.trim())));
				}
				if(CommonUtil.isNotNull(billingFrequency)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(billingFrequency.trim())));
				}
				if(CommonUtil.isNotNull(manBillDate)) {
					//summary.add(new Cell(commonUtil.excelTextValueOf(manBillDate.trim())));
					summary.add(new Cell(CommonUtil.getDisplayDateFromString(manBillDate.trim())));
				}
				

				profilesList.add(summary);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadEMediaAccountsSummaryRowMapperImpl's summary  " + summary);
		}
		return profilesList;
	}
}
