package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDownloadAFTReportViewRequest extends BaseStoredProcedure {
	
	static private final Logger _LOGGER = Logger.getLogger(SPDownloadAFTRequest.class);

	private static List spInOutList;
	
	private static DownloadAFTReportViewRequestRowMapperImpl rowMapper = null;

	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new DownloadAFTReportViewRequestRowMapperImpl();
		 spInOutList.add(new Object[]{"aftInfo",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"FILTER_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
         spInOutList.add(new Object[]{"REQUEST_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPDownloadAFTReportViewRequest(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_AFT_INFO, spInOutList);
	}

	public Content executeStoredProcedure(String appUserId, String debugLevel, 
				String whereFilter, String sortFilter, String requestType) throws Exception {
		List paramValueList = new ArrayList();
		paramValueList.add(appUserId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(whereFilter);//FILTER_STRING
		paramValueList.add(sortFilter);//SORT_STRING
        paramValueList.add(requestType);//REQUEST_TYPE
		paramValueList.add("1");//PAGE_OFFSET
		paramValueList.add("10000");//PAGE_SIZE

		Map procMap = (HashMap)executeStoredProcedure(paramValueList);	
		List actualList = (List)procMap.get("aftInfo");
		Content retObj = new Content();
		retObj.setRows(actualList);

		return retObj ;
	}

	protected Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
