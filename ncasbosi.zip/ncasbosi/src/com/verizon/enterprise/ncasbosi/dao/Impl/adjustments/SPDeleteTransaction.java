package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDeleteTransaction extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPDeleteTransaction.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"VAC_TRANSACTION_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPDeleteTransaction(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_DELETE_TRANSACTION, spInOutList);
	}

	public Map executeStoredProcedure(String vacTransactionId)throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(vacTransactionId);	//VAC_TRANSACTION_ID

		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
