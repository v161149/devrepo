package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.gbr.VbeReportPoint;

public class GetVbeReportRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger
			.getLogger(GetGBROrgsRowMapperImpl.class);

	public Object mapRow(ResultSet rs,  int rowNum) throws SQLException {
		_LOGGER.info("Inside GetVbeReportRowMapper -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		VbeReportPoint reportPoint = null;

		if(rs!=null)
		{
			reportPoint = new VbeReportPoint();
			reportPoint.setConfigSubsOid (rs.getString("CONFIG_SUBS_OID"));
			reportPoint.setConfigId (rs.getString("CONFIG_ID"));
			reportPoint.setServiceType (rs.getString("SERVICE_TYPE"));
			reportPoint.setReportOid (rs.getString("REPORT_OID"));
			reportPoint.setReportId (rs.getString("REPORT_ID"));
			reportPoint.setReportName(rs.getString("REPORT_NAME"));
			reportPoint.setReportStart (rs.getString("REPORT_START"));
			reportPoint.setReportEnd (rs.getString("REPORT_END"));
			reportPoint.setCustAddrType (rs.getString("CUST_ADDR_TYPE"));
			reportPoint.setCustAddr1 (rs.getString("CUST_ADDR_1"));
			reportPoint.setCustAddr2 (rs.getString("CUST_ADDR_2"));
			reportPoint.setCustAddr3 (rs.getString("CUST_ADDR_3"));
			reportPoint.setCustCity (rs.getString("CUST_CITY"));
			reportPoint.setCustState (rs.getString("CUST_STATE"));
			reportPoint.setCustZip (rs.getString("CUST_ZIP"));
			reportPoint.setPostalCode (rs.getString("POSTAL_CODE"));
			reportPoint.setCustCountry (rs.getString("CUST_COUNTRY"));
			reportPoint.setLanguage_code (rs.getString("LANGUAGE_CODE"));
			reportPoint.setCurrency_code (rs.getString("CURRENCY_CODE"));
			reportPoint.setExtUpdtUserName (rs.getString("EXT_UPDT_USR_NAME"));
			reportPoint.setExtUpdtUserId (rs.getString("EXT_UPDT_USR_ID"));
			reportPoint.setUpdateTimestamp (rs.getString("UPDATE_TIMESTAMP"));
//			reportPoint.setNodeType (rs.getString("NODE_TYPE"));
//			reportPoint.setParentNodeType(rs.getString("PARENT_NODE_TYPE"));
			reportPoint.setRemitOid (rs.getString("REMIT_OID"));
			reportPoint.setRemitId (rs.getString("REMIT_ID"));
			reportPoint.setRemitName (rs.getString("REMIT_NAME"));
			reportPoint.setDefaultRemit(rs.getString("DEFAULT_REMIT"));
			reportPoint.setProfileComplete (rs.getString("PROFILE_COMPLETE"));
			reportPoint.setProfileComment (rs.getString("PROFILE_COMMENT"));
			reportPoint.setSubscriberOid (rs.getString("SUBSCRIBER_OID"));
			reportPoint.setSubscriberName (rs.getString("SUBSCRIBER_NAME"));
			reportPoint.setBic (rs.getString("BIC"));
			reportPoint.setGuduns (rs.getString("GUDUNS"));


		}

		return reportPoint;
	}
}
