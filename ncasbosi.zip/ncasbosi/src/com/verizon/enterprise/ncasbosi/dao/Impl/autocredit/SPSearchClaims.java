package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.autocredit.AcClaimSearchForm;
import com.verizon.enterprise.common.ncas.autocredit.ACSearchClaim;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * Author:PVB
 */

public class SPSearchClaims extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPSearchClaims.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"SEARCH_RESULTS", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new GetSearchClaimMapper()});
		 
		 spInOutList.add(new Object[]{"CLAIM_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCOUNT_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"OWNER_VZID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_STATUS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ENTRY_DATE_FROM", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ENTRY_DATE_TO", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_FIELD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_DIR", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_POS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NUM_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SVC_CENTER_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	 }
	
	public SPSearchClaims(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_SEARCH_AC_CLAIMS, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception
	{
		_LOGGER.info("Enterring executeStoredProcedure");

		AcClaimSearchForm acclaimSearchForm = (AcClaimSearchForm)input;
		ACSearchClaim myACS = null;
		Pagination myPag = null;
		List paramValueList = new ArrayList();

		// Check/Process  Input Map
		if ((acclaimSearchForm != null) && (acclaimSearchForm instanceof AcClaimSearchForm)){
			myACS = acclaimSearchForm.getMyCS();   // get data user entered into screen
			myPag = acclaimSearchForm.getMyPag();   // get pagination data so know which page to retrieve
		}else{
			throw new Exception("SPSearchClaims: bad input expect ClaimSearchForm got:" + acclaimSearchForm);
		}
		if (myACS == null){
			throw new Exception("SPSearchClaims: Search bill inquiry data is null");
		}
		if (myPag == null){
			throw new Exception("SPSearchClaims: Bill inquiry pagination is null");
		}

		//convert date user entered into date db2 can use.
		String formatIn = "MM/dd/yyyy";
		String formatOut = "yyyy-MM-dd";

		String claimnumber= myACS.getClaimNumber();
		String ban = myACS.getBan();
		String ownervzid = myACS.getOwnerVzid();
		String claimstatus = myACS.getClaimStatus();
		String fromentrydate = CommonUtil.formatDate(myACS.getFromEntryDate(),formatIn, formatOut);
		String toentrydate= CommonUtil.formatDate(myACS.getToEntryDate(),formatIn, formatOut);
		
		

		paramValueList.add(getV(claimnumber));
		paramValueList.add(getV(ban));
		paramValueList.add(getV(ownervzid));
		paramValueList.add(getV(claimstatus));
		paramValueList.add(getV(fromentrydate));
		paramValueList.add(getV(toentrydate));
		
		//pagination fields
		String sortField = myPag.getSortField();

		paramValueList.add(getV(sortField));		 	// SORT_FIELD
		String sortDir = myPag.getSortDirection();
		if(sortDir != null)
		{
			if(sortDir.equalsIgnoreCase("A") ||sortDir.equalsIgnoreCase("D"))
			{
				paramValueList.add(sortDir);		 	// SORT_DIR
			}
			else
			{
				paramValueList.add(null);
			}
		}
		else
		{
			paramValueList.add(null);
		}

		paramValueList.add(new Integer(myPag.getLineOffset()));	 // START_POS
		paramValueList.add(new Integer(myPag.getPageSize()));	 	// NUM_ROWS
		paramValueList.add(myACS.getServiceCenterString());  //SVC_CENTER_STRING
		
		/***** call the SP *************/
		Map resMap = executeSP(paramValueList, false);
		//Map resMap = getBIS();
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;

	}

	//get value from variable, if empty string set to null.
	private String getV (String input)
	{
		if (input != null && !"".equals(input))
		{
			return input;
		}
		else
		{
			return null;
		}
	}
}
