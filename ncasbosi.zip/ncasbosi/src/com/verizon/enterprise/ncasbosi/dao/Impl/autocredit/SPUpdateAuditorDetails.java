package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import java.sql.Types;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPUpdateAuditorDetails extends BaseStoredProcedure
{
    private static final Logger _LOGGER = Logger
            .getLogger(SPUpdateAuditorDetails.class);

    private static ArrayList spInOutList = new ArrayList();
    static
    {
        spInOutList.add(new Object[] { "ACTION", getSqlDataType(Types.CHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "AUDITOR_VZID",
                getSqlDataType(Types.CHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "AUDITOR_NAME",
                getSqlDataType(Types.VARCHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "SERVICE_CENTER",
                getSqlDataType(Types.VARCHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "RETURN_CODE",
                getSqlDataType(Types.INTEGER),
                NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "REASON_CODE",
                getSqlDataType(Types.CHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "ERROR_TEXT",
                getSqlDataType(Types.VARCHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "SP_SQLCODE",
                getSqlDataType(Types.INTEGER),
                NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "SP_SQLTOKENS",
                getSqlDataType(Types.CHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_OUT, });
        spInOutList.add(new Object[] { "SP_SQLSTATE",
                getSqlDataType(Types.CHAR),
                NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    }

    public SPUpdateAuditorDetails(DataSource dataSource)
    {
        super(dataSource, NCASBOSIConstants.SP_UPDATE_AUDITOR_DETAILS,
                spInOutList);
    }

    public Map executeStoredProcedure(Object input) throws Exception
    {
        /*
         * _LOGGER.info("Entering executeStoredProcedure"); Map resMap = new
         * HashMap(); Map inputMap = (Map)input; String key =
         * (String)inputMap.get("KEY"); resMap.put("RESULT",
         * DummyAuditorDetail.getAuditorDetails(key)); _LOGGER.info("Exiting
         * ExecuteStoredProcedure in "+ getStoredProcedureName());
         */
        _LOGGER.info("Entering executeStoredProcedure");
        Map inputMap = (Map) input;
        String action = (String) inputMap.get("ACTION");
        String auditor_VZId = (String) inputMap.get("AUDITOR_VZID");
        String auditor_name = (String) inputMap.get("AUDITOR_NAME");
        String service_center = (String) inputMap.get("SERVICE_CENTER");
        _LOGGER.info("ACTION::" + action);
        _LOGGER.info("AUDITOR_VZID::" + auditor_VZId);
        _LOGGER.info("AUDITOR_NAME::" + auditor_name);
        _LOGGER.info("SERVICE_CENTER::" + service_center);
        List paramValueList = new ArrayList();
        paramValueList.add(action); // ACTION
        paramValueList.add(auditor_VZId); // AUDITOR_VZID
        paramValueList.add(auditor_name); // AUDITOR_NAME
        paramValueList.add(service_center); // SERVICE_CENTER
        // * *** call the SP ************
        Map resMap = executeSP(paramValueList, false);
        _LOGGER
                .info("Now calling checkVACErrors to identify any errors or issued warnings");
        checkVACErrors(resMap);
        _LOGGER.info("Exiting ExecuteStoredProcedure in "
                + getStoredProcedureName());
        return resMap;
    }
}
