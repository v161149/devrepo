package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import com.sapient.framework.config.Config;
import com.verizon.enterprise.ncasbosi.common.StoredProcConfig;
import com.verizon.enterprise.common.ncas.adjustments.Adjustment;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.SPErrorInfo;
import org.springframework.jdbc.core.RowCallbackHandler;

import com.verizon.enterprise.common.ncas.adjustments.Tax;
import com.verizon.enterprise.common.ncas.adjustments.AdjustmentUtil;
import com.verizon.enterprise.common.ncas.adjustments.AdjustmentDetails;
import com.verizon.enterprise.common.ncas.adjustments.AdjustmentHelper;

import com.verizon.enterprise.ncasbosi.dao.Interface.adjustments.AdjustmentInterface;

public class AdjustmentDAOImpl extends NCASSpringJDBCBase implements AdjustmentInterface, NCASBOSIConstants {
	private static final String SCHEMA_NAME = "verizon.ncasbosi.vac.schemaName";

	private static final String NBBE_TAX_ENGINE_SCHEMA_NAME = "verizon.ebosi.bill.nbbetaxengine.schema";
	private static final String NBBE_TAX_ENGINE_SP_NAME = "verizon.ebosi.bill.nbbetaxengine.nbbeTaxSPName";

	static private final Logger _LOGGER = Logger.getLogger(AdjustmentDAOImpl.class);

	private JdbcTemplate nbbeTaxEngineJdbcTemplate;// jdbctemplate created for NBBETaxEngine DataSource

	public void setNBBETaxEngineDataSource(DataSource dataSource) {
		nbbeTaxEngineJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[nbbeTaxEngineJdbcTemplate datasource set ]");
	}

	public DataSource getNBBETaxEngineDataSource() {
		return nbbeTaxEngineJdbcTemplate.getDataSource();
	}


	public Map createLineAdjustments(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.createLineAdjustments():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;
		StringBuffer infoStringBuffer = new StringBuffer();
		String[] errMsg = new String[3];

		try
		{
			String schemaName = getSchemaName();
			SPCreateLineAdjustment createLineAdjStoredProc = new SPCreateLineAdjustment(getDataSource(),schemaName);

			String loginId = (String) inputMap.get("ORIGINATOR_LOGINID");
			String vzid = (String) inputMap.get("ORIGINATOR_VZID");
			String loginName = (String) inputMap.get("ORIGINATOR_NAME");
			String firstName = (String) inputMap.get("ORIGINATOR_FIRST");
			String lastName = (String) inputMap.get("ORIGINATOR_LAST");
			String middleName = (String) inputMap.get("ORIGINATOR_MID_IN");
			String suffix = (String) inputMap.get("ORIGINATOR_SUFF");
			String batchId = (String) inputMap.get("BATCH_ID");
			int noOfRows = ((Integer) inputMap.get("INPUT_ROWS")).intValue();

			Map paramMap = (Map) inputMap.get("DATA_MAP");
			paramMap.put("APP_USER_ID", loginId);

			List<Adjustment> adjustmentList = (List<Adjustment>) getAdjustmentList(paramMap).get("adjList");

			/*
			 * The adjustmentList will have list of
			 * Adjustment(com.verizon.enterprise.common.ncas.adjustments) objects
			 *
			 *  getInputString() in Adjustment object is self contained
			 *  it has the logic to create inputString like
			 *  col1^col2^col3^....^col100|col1^col2^col3^....^col100
			 *  where ^ is field separator and | is row separator.
			 */
	        StringBuffer sb= new StringBuffer();
 	    	Iterator<Adjustment> itr = adjustmentList.iterator();

	        while (itr.hasNext())
	        {
	            Adjustment adj = itr.next();
	            /*
	             * getInputString() in Adjustment object is self contained
	             * it has the logic to create inputString like
	             * col1^col2^col3^....^col100|col1^col2^col3^....^col100
	             * where ^ is field separator and | is row separator.
	             */
	            sb.append(adj.getInputString());
	        }

			String inputString = sb.toString();

			infoStringBuffer.append("API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_CREATE_PORTAL_ADJ);
			infoStringBuffer.append("(");
			infoStringBuffer.append("ORIGINATOR_LOGINID=" + loginId);
			infoStringBuffer.append(", ORIGINATOR_VZID=" + vzid);
			infoStringBuffer.append(", ORIGINATOR_NAME=" + loginName);
			infoStringBuffer.append(", ORIGINATOR_FIRST=" + firstName);
			infoStringBuffer.append(", ORIGINATOR_LAST=" + lastName);
			infoStringBuffer.append(", ORIGINATOR_MID_IN=" + middleName);
			infoStringBuffer.append(", ORIGINATOR_SUFF=" + suffix);
			infoStringBuffer.append(", BATCH_ID=" + batchId);
			infoStringBuffer.append(", INPUT_STRING=" + inputString);
			infoStringBuffer.append(", INPUT_ROWS=" + noOfRows);
			infoStringBuffer.append(")");

			_LOGGER.info(METHOD_NAME + " " + infoStringBuffer.toString());

			errMsg[0] = infoStringBuffer.toString();

			responseMap = createLineAdjStoredProc.executeStoredProcedure(loginId, vzid, loginName, firstName, lastName, middleName, suffix, batchId, inputString, noOfRows);
		}
		catch(NCASException ncasException)
		{
			_LOGGER.debug("createLineAdjustments in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("createLineAdjustments in VAC Failed \n" + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug("createLineAdjustments in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("createLineAdjustments in VAC Failed \n" + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}

		return responseMap;
	}


	public Map getAdjustmentList(Map  adjustmentMap) throws NCASException{
		Map responseMap = null;
		try {
			String schemaName = getVAMSchemaName();
			SPGetAdjustmentList AdjStoredProc = new SPGetAdjustmentList(getDataSource(),schemaName);
			String userID = null;
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			adjustmentMap.put("DEBUG_LEVEL", debugLevel);
	        responseMap = AdjStoredProc.executeStoredProcedure(adjustmentMap);

		}catch(NCASException ncasException ) {
			_LOGGER.debug("getAdjustmentList in VAM Failed \n" + ncasException.getMessage());
			_LOGGER.error("getAdjustmentList in VAM Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("getAdjustmentList in VAM Failed \n" + vamEx.getMessage());
			_LOGGER.error("getAdjustmentList in VAM Failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vamEx);
		}
		return responseMap;
	}


	public Map getAdjustmentListByStatus(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.getAdjustmentListByStatus():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;
		StringBuffer infoStringBuffer = new StringBuffer();
		String[] errMsg = new String[3];

		try
		{
			String schemaName = getSchemaName();
			SPGetAdjustmentsByStatus getAdjByStatusStoredProc = new SPGetAdjustmentsByStatus(getDataSource(), schemaName);

			String ban = (String) inputMap.get("BAN");
			String osid = (String) inputMap.get("ORIGINATING_SYS_ID");
			String loginId = (String) inputMap.get("ORIGINATOR_LOGINID");
			String adjustmentStatus = (String) inputMap.get("ADJ_STATUS");
			String adjustmentLevel = (String) inputMap.get("ADJ_LEVEL");
			String notificationStatus = (String) inputMap.get("NOTIFICATION_STAT");
			String resultSetType = (String) inputMap.get("RESULT_SET_TYPE");
			int offset = Integer.parseInt((String) inputMap.get("START_POSITION"));
			String claimNumber = (String) inputMap.get("ESG_CLAIM_NUMBER");

			infoStringBuffer.append("API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_GET_ADJ_BY_STATUS);
			infoStringBuffer.append("(");
			infoStringBuffer.append("BAN=" + ban);
			infoStringBuffer.append(", ORIGINATING_SYS_ID=" + osid);
			infoStringBuffer.append(", ORIGINATOR_LOGINID=" + loginId);
			infoStringBuffer.append(", ADJ_STATUS=" + adjustmentStatus);
			infoStringBuffer.append(", ADJ_LEVEL=" + adjustmentLevel);
			infoStringBuffer.append(", NOTIFICATION_STAT=" + notificationStatus);
			infoStringBuffer.append(", RESULT_SET_TYPE=" + resultSetType);
			infoStringBuffer.append(", START_POSITION=" + offset);
			infoStringBuffer.append(", ESG_CLAIM_NUMBER=" + claimNumber);
			infoStringBuffer.append(")");

			_LOGGER.info(METHOD_NAME + " " + infoStringBuffer.toString());

			errMsg[0] = infoStringBuffer.toString();

			responseMap = getAdjByStatusStoredProc.executeStoredProcedure(ban, osid, loginId, adjustmentStatus, adjustmentLevel, notificationStatus, resultSetType, offset, claimNumber);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug("getAdjustmentListByStatus in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("getAdjustmentListByStatus in VAC Failed \n" + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug("getAdjustmentListByStatus in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("getAdjustmentListByStatus in VAC Failed \n" + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}

		return responseMap;
	}


	public Map getAdjustmentListById(List idList) throws NCASException {
		Map responseMap = null;
		try {
			String schemaName = getSchemaName();
			SPGetAdjustmentById getAdjustmentsByIdStoredProc = new SPGetAdjustmentById(getDataSource(), schemaName);
			_LOGGER.info("Input Params:: idList - " + idList);
			String inputString = getCommaSeparatedString(idList);
			int noOfRows = idList.size();
			_LOGGER.info("Params for SPGetAdjustmentById :: inputString - " + inputString + " , noOfRows - " + noOfRows);
			responseMap = getAdjustmentsByIdStoredProc.executeStoredProcedure(inputString, noOfRows);
			_LOGGER.info("responseMap - " + responseMap);
		}  catch(NCASException ncasException ) {
			_LOGGER.debug("getAdjustmentListById in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("getAdjustmentListById in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("getAdjustmentListById in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("getAdjustmentListById in VAC Failed \n" + vacEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}
		return responseMap;
	}


	public Map getRepClaimList(String vzid) throws NCASException {
		Map responseMap = null;
		try {
			String schemaName = getSchemaName();
			SPGetRepClaimList getRepClaimListStoredProc = new SPGetRepClaimList(getDataSource(), schemaName);
			responseMap = getRepClaimListStoredProc.executeStoredProcedure(vzid);
		}  catch(NCASException ncasException ) {
			_LOGGER.debug("getRepClaimList in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("getRepClaimList in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("getRepClaimList in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("getRepClaimList in VAC Failed \n" + vacEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}
		return responseMap;
	}

	public Map deleteAdjustments(List adjustmentIdsList) throws NCASException {
		Map responseMap = null;
		try {
			String schemaName = getSchemaName();
			SPDeleteAdjustments deleteAdjustmentsStoredProc = new SPDeleteAdjustments(getDataSource(), schemaName);
			_LOGGER.info("adjustmentIdsList - " + adjustmentIdsList);
			int noOfRows = adjustmentIdsList.size();
			String adjustmentIdsString = getCommaSeparatedString(adjustmentIdsList);
			_LOGGER.info("adjustmentIdsString - " + adjustmentIdsString);
			responseMap = deleteAdjustmentsStoredProc.executeStoredProcedure(adjustmentIdsString, noOfRows);
		}  catch(NCASException ncasException ) {
			_LOGGER.debug("deleteAdjustments in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("deleteAdjustments in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("deleteAdjustments in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("deleteAdjustments in VAC Failed \n" + vacEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}
		return responseMap;
	}

	public Map getNBBETaxInfo(String reqInputString) throws NCASException {
		final String METHOD_NAME = "AdjustmentDAOImpl.getNBBETaxInfo():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = new HashMap();
		String [] exceptionDisplay = {reqInputString};

		try
		{
			String schemaName = getNBBETaxEngineSchemaName();
			String spName = schemaName + "." + getNBBETaxEngineSPName();

			SPGetNBBETaxInfo getNBBETaxInfoStoredProc = new SPGetNBBETaxInfo(getNBBETaxEngineDataSource(), spName);

			_LOGGER.info(METHOD_NAME + "reqInputString - " + reqInputString);

			responseMap = getNBBETaxInfoStoredProc.executeStoredProcedure(reqInputString);
			responseMap.put("reqInputString", (String) reqInputString);

			_LOGGER.info(METHOD_NAME + "responseMap - " + responseMap);
		}
		catch(NCASException ncasException)
		{
			_LOGGER.debug(METHOD_NAME + "getNBBETaxInfo Failed \n" + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "getNBBETaxInfo Failed \n" + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug(METHOD_NAME + "getNBBETaxInfo Failed \n" + vacEx.getMessage());
			_LOGGER.error(METHOD_NAME + "getNBBETaxInfo Failed \n" + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, exceptionDisplay);
		}

		return responseMap;
	}


	//Calls NBBE Tax Engine API with request limit processing built into it.
	//Map headerDataMap = contains account level information
	//List dataStringList = List of String (nbbe tax engine formatted input string).
	public Map getNBBETaxInfoWithRequestLimitProcessing(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.getNBBETaxInfoWithRequestLimitProcessing():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;
		Map nbbeTaxEngineResultSetMap = new HashMap();
		int taxEngineMaxRequestCount = 0;

		try
		{
			taxEngineMaxRequestCount = Integer.parseInt(BOSIConfig.getProperty("verizon.ebosi.bill.nbbetaxengine.getNBBETaxSizePerCall"));

			if (_LOGGER.isInfoEnabled())
			{
				_LOGGER.info(METHOD_NAME + " taxEngineMaxRequestCount=" + taxEngineMaxRequestCount);
			}
		}
		catch (Exception e)
		{
			if (_LOGGER.isEnabledFor(Level.ERROR))
			{
				_LOGGER.error(METHOD_NAME + " Unable to get getNBBETaxSizePerCall from config xml: " + e);
			}

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, e);
		}

		try
		{
			Map headerDataMap = (Map) inputMap.get("HEADER_DATA_MAP");
			List dataStringList = (List) inputMap.get("DATA_STRING_LIST");

			if (_LOGGER.isInfoEnabled())
			{
				_LOGGER.info(METHOD_NAME + " headerDataMap=" + headerDataMap);
				_LOGGER.info(METHOD_NAME + " dataStringList=" + dataStringList);
			}

			String dataString = null;
			StringBuffer taxEngineInputStringBuffer = new StringBuffer();
			int dataStringCounter = 0;
			StringBuffer inputDataStringBuffer = new StringBuffer();
			List nbbeTaxEngineResultSetList = new ArrayList();

			Iterator it = dataStringList.iterator();

			while (it.hasNext())
			{
				dataString = (String) it.next();
				inputDataStringBuffer.append(dataString);
				dataStringCounter++;

				if (dataStringCounter == taxEngineMaxRequestCount || !it.hasNext())
				{
					//get today's date in "yyMMddHHmmssS" format
					String currentDateString = AdjustmentUtil.getCurrentDateInStringFormat("yyMMddHHmmssS");

					//build tax engine header input string
					taxEngineInputStringBuffer = new StringBuffer();
					taxEngineInputStringBuffer.append((String) headerDataMap.get("SYSTEM_INDICATOR"));
					taxEngineInputStringBuffer.append((String) headerDataMap.get("OSID"));
					taxEngineInputStringBuffer.append((String) headerDataMap.get("TAX_STATUS_INDICATOR_FEDERAL"));
					taxEngineInputStringBuffer.append((String) headerDataMap.get("TAX_STATUS_INDICATOR_STATE"));
					taxEngineInputStringBuffer.append((String) headerDataMap.get("TAX_STATUS_INDICATOR_E911"));
					taxEngineInputStringBuffer.append((String) headerDataMap.get("TAX_STATUS_INDICATOR_SURCHARGE"));
					taxEngineInputStringBuffer.append((String) headerDataMap.get("TAX_STATUS_INDICATOR_LOCAL"));
					taxEngineInputStringBuffer.append(",");
					taxEngineInputStringBuffer.append(currentDateString.substring(0, 13));
					taxEngineInputStringBuffer.append(",");
					taxEngineInputStringBuffer.append(AdjustmentUtil.padCharToString((String) headerDataMap.get("ACCOUNT_TYPE_CODE"), '0', 1, AdjustmentUtil.PAD_LEFT, true));
					taxEngineInputStringBuffer.append(AdjustmentUtil.padCharToString(Integer.toString(dataStringCounter), '0', 3, AdjustmentUtil.PAD_LEFT, true));
					taxEngineInputStringBuffer.append("'");
					taxEngineInputStringBuffer.append(inputDataStringBuffer.toString());

					if (_LOGGER.isInfoEnabled())
					{
						_LOGGER.info(METHOD_NAME + " taxEngineInputStringBuffer=" + taxEngineInputStringBuffer.toString());
					}

					//call NBBE Tax Engine API to calculate tax
					responseMap = getNBBETaxInfo(taxEngineInputStringBuffer.toString());

					if (_LOGGER.isInfoEnabled())
					{
						_LOGGER.info(METHOD_NAME + " responseMap=" + responseMap);
					}

					Integer returnCode = (Integer) responseMap.get("RETURN_CODE");

					//check the return code
					if(returnCode != 0)
					{
						throw new Exception(METHOD_NAME + " getNBBETaxInfoWithRequestLimitProcessing FAILED: responseMap=" + responseMap + " inputString=" + taxEngineInputStringBuffer.toString());
					}

					if((List) responseMap.get("taxInfo") != null)
					{
						//append the result
						nbbeTaxEngineResultSetList.addAll((List) responseMap.get("taxInfo"));
					}

					//reset dataString processed counter
					dataStringCounter = 0;

					//reset tax engine input StringBuffer
					inputDataStringBuffer.setLength(0);
				}
			}

			//process the result returned by the NBBE Tax Engine API call
			//create a List of Tax object and stores it in a Map using taxId as the key
			Map taxGroupMap = null;
			String key = null;
			String taxGroupKey = null;

			if (nbbeTaxEngineResultSetList == null || nbbeTaxEngineResultSetList.size() == 0)
			{
				_LOGGER.info(METHOD_NAME + " nbbeTaxEngineResultSetList=" + nbbeTaxEngineResultSetList);
				_LOGGER.info(METHOD_NAME + " nbbeTaxEngineResultSetList IS EMPTY");
			}
			else
			{
				if (_LOGGER.isInfoEnabled())
				{
					_LOGGER.info(METHOD_NAME + " nbbeTaxEngineResultSetList=" + nbbeTaxEngineResultSetList);
				}

				it = nbbeTaxEngineResultSetList.iterator();
				Tax nbbeTaxEngineResultSetRowTaxDetails = null;

				while (it.hasNext())
				{
					nbbeTaxEngineResultSetRowTaxDetails = (Tax) it.next();
					key = nbbeTaxEngineResultSetRowTaxDetails.getTaxId();

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " nbbeTaxEngineResultSetRowTaxDetails=" + nbbeTaxEngineResultSetRowTaxDetails.toString());
					}

					if (nbbeTaxEngineResultSetMap.containsKey(key))
					{
						taxGroupMap = (Map) nbbeTaxEngineResultSetMap.get(key);
					}
					else
					{
						taxGroupMap = new HashMap();
					}

					taxGroupKey = nbbeTaxEngineResultSetRowTaxDetails.getTaxGroup();

					if (taxGroupMap.containsKey(taxGroupKey))
					{
						//get the tax details
						Tax taxDetails = (Tax) taxGroupMap.get(taxGroupKey);

						if (_LOGGER.isDebugEnabled())
						{
							_LOGGER.debug(METHOD_NAME + " taxDetails=" + taxDetails);
						}

						//add NBBE Result taxAmount to existing taxAmount
						double taxAmount = Double.parseDouble(taxDetails.getTaxAmount()) + Double.parseDouble(nbbeTaxEngineResultSetRowTaxDetails.getTaxAmount());

						//convert it to BigDecimal
						BigDecimal taxAmountBD = new BigDecimal(taxAmount);

						//round it to 2 decimal places
						taxAmountBD = taxAmountBD.setScale(2, BigDecimal.ROUND_HALF_UP);

						if (_LOGGER.isDebugEnabled())
						{
							_LOGGER.debug(METHOD_NAME + " taxAmount=" + taxAmount);
							_LOGGER.debug(METHOD_NAME + " taxAmountBD=" + taxAmountBD);
						}

						//store newly calculated taxAmount
						taxDetails.setTaxAmount(taxAmountBD.toPlainString());
						taxGroupMap.put(taxGroupKey, taxDetails);
					}
					else
					{
						taxGroupMap.put(taxGroupKey, nbbeTaxEngineResultSetRowTaxDetails);
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " taxGroupMap=" + taxGroupMap);
					}

					nbbeTaxEngineResultSetMap.put(key, taxGroupMap);
				}
			}

			if (_LOGGER.isInfoEnabled())
			{
				_LOGGER.info(METHOD_NAME + " nbbeTaxEngineResultSetMap=" + nbbeTaxEngineResultSetMap);
			}

			if (_LOGGER.isDebugEnabled())
			{
				_LOGGER.debug(METHOD_NAME + " EXIT");
			}
		}
		catch(NCASException ncasException)
		{
			_LOGGER.error("getNBBETaxInfoWithRequestLimitProcessing Failed \n" + ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.error("getNBBETaxInfoWithRequestLimitProcessing Failed \n" + vacEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}

		return nbbeTaxEngineResultSetMap;
	}


	public Map getReasonCode(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.getReasonCode():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;
		StringBuffer infoStringBuffer = new StringBuffer();
		String[] errMsg = new String[3];

		_LOGGER.info(METHOD_NAME + "inputMap=" + inputMap);

		try
		{
			String schemaName = getSchemaName();
			SPGetReasonCode getReasonCodeStoredProc = new SPGetReasonCode(getDataSource(), schemaName);

			String category = (String) inputMap.get("CATEGORY");
			String osid = (String) inputMap.get("ORIGINATING_SYS_ID");
			String rao = (String) inputMap.get("RAO");
			String entityCode = (String) inputMap.get("ENTITY_CODE");
			String ecpBackendSystem = (String) inputMap.get("ECP_BACKEND_SYS");
			String writeOffIndicator = (String) inputMap.get("WRITEOFF_IND");
			String type = (String) inputMap.get("TYPE");

			infoStringBuffer.append("API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_GET_REASON_CODE);
			infoStringBuffer.append("(");
			infoStringBuffer.append("CATEGORY=" + category);
			infoStringBuffer.append(", ORIGINATING_SYS_ID=" + osid);
			infoStringBuffer.append(", RAO=" + rao);
			infoStringBuffer.append(", ENTITY_CODE=" + entityCode);
			infoStringBuffer.append(", ECP_BACKEND_SYS=" + ecpBackendSystem);
			infoStringBuffer.append(", WRITEOFF_IND=" + writeOffIndicator);
			infoStringBuffer.append(", TYPE=" + type);
			infoStringBuffer.append(")");

			_LOGGER.info(METHOD_NAME + infoStringBuffer.toString());

			errMsg[0] = infoStringBuffer.toString();

			responseMap = getReasonCodeStoredProc.executeStoredProcedure(category, osid, rao, entityCode, ecpBackendSystem, writeOffIndicator, type);

			_LOGGER.info(METHOD_NAME + "responseMap=" + responseMap);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug(METHOD_NAME + "getReasonCode in VAC Failed \n" + errMsg[0] + " " + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "getReasonCode in VAC Failed \n" + errMsg[0] + " " + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug(METHOD_NAME + "getReasonCode in VAC Failed \n" + errMsg[0] + " " + vacEx.getMessage());
			_LOGGER.error(METHOD_NAME + "getReasonCode in VAC Failed \n" + errMsg[0] + " " + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}

		return responseMap;
	}


	public Map updateAdjustment(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl::updateAdjustment() ";

		if (_LOGGER.isEnabledFor(Level.DEBUG))
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;

		try
		{
			List idList	= (List) inputMap.get("INPUT_STRING_LIST");
			String adjustmentReasonCode = (String) inputMap.get("ADJ_REASON_CODE");
			String adjustmentClassificationCode = (String) inputMap.get("ADJ_CLASSIF_CODE");
			String adjustmentStatus = (String) inputMap.get("ADJ_STATUS");
			String adjustmentCreditDebit = (String) inputMap.get("ADJ_CREDIT_DEBIT");
			String notificationStatus = (String) inputMap.get("NOTIFICATION_STAT");
			String additionalReasonCode = (String) inputMap.get("ADDL_REASON_CODE");
			String adjustmentAmount = (String) inputMap.get("ADJ_AMOUNT");
			String numberOfMonths = (String) inputMap.get("NO_OF_MONTHS");
			String revenueCode = (String) inputMap.get("REV_CODE");
			String accountStatus = (String) inputMap.get("ACCT_STATUS");
			String writeOffIndicator = (String) inputMap.get("WRITEOFF_IND");

			_LOGGER.info(METHOD_NAME + " idList=" + idList);
			_LOGGER.info(METHOD_NAME + " adjustmentReasonCode=" + adjustmentReasonCode);
			_LOGGER.info(METHOD_NAME + " adjustmentClassificationCode=" + adjustmentClassificationCode);
			_LOGGER.info(METHOD_NAME + " adjustmentStatus=" + adjustmentStatus);
			_LOGGER.info(METHOD_NAME + " adjustmentCreditDebit=" + adjustmentCreditDebit);
			_LOGGER.info(METHOD_NAME + " notificationStatus=" + notificationStatus);
			_LOGGER.info(METHOD_NAME + " additionalReasonCode=" + additionalReasonCode);
			_LOGGER.info(METHOD_NAME + " adjustmentAmount=" + adjustmentAmount);
			_LOGGER.info(METHOD_NAME + " numberOfMonths=" + numberOfMonths);
			_LOGGER.info(METHOD_NAME + " revenueCode=" + revenueCode);
			_LOGGER.info(METHOD_NAME + " accountStatus=" + accountStatus);
			_LOGGER.info(METHOD_NAME + " writeOffIndicator=" + writeOffIndicator);

			String inputString = getCommaSeparatedString(idList);
			int numberOfRows = idList.size();

			_LOGGER.info(METHOD_NAME + " inputString=" + inputString);
			_LOGGER.info(METHOD_NAME + " numberOfRows=" + numberOfRows);

			String schemaName = getSchemaName();
			SPUpdateAdjustment updateAdjustmentStoredProc = new SPUpdateAdjustment(getDataSource(), schemaName);

			responseMap = updateAdjustmentStoredProc.executeStoredProcedure(inputString, numberOfRows, adjustmentReasonCode,
					adjustmentClassificationCode, adjustmentStatus, adjustmentCreditDebit, notificationStatus, additionalReasonCode,
					adjustmentAmount, numberOfMonths, revenueCode, accountStatus, writeOffIndicator);

			_LOGGER.info(METHOD_NAME + "responseMap=" + responseMap);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug(METHOD_NAME + "updateAdjustment in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "updateAdjustment in VAC Failed \n" + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug(METHOD_NAME + "updateAdjustment in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error(METHOD_NAME + "updateAdjustment in VAC Failed \n" + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}

		return responseMap;
	}

	public Map updateAdjustmentDetails(List inputStringList) throws NCASException {
		Map responseMap = null;
		String schemaName = getSchemaName();
		String inputString = "";
		int numberOfRows = 0;
		try {
			SPUpdateAdjustmentDetails updateAdjustmentDetailsStoredProc = new SPUpdateAdjustmentDetails(getDataSource(), schemaName);
			_LOGGER.info("Input Params:: inputStringList - " + inputStringList);
			inputString = getRowDelimitedString(inputStringList);
			numberOfRows = inputStringList.size();
			_LOGGER.info("Params for SPUpdateAdjustmentDetails :: inputString - " + inputString + " , numberOfRows - " + numberOfRows);
			responseMap = updateAdjustmentDetailsStoredProc.executeStoredProcedure(inputString, numberOfRows);
			_LOGGER.info("responseMap - " + responseMap);
		}  catch(NCASException ncasException ) {
			_LOGGER.debug("updateAdjustmentDetails in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("updateAdjustmentDetails in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("updateAdjustmentDetails in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("updateAdjustmentDetails in VAC Failed \n" + vacEx.getMessage());
			String[] errMsg = new String[3];
			errMsg[0] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_UPDATE_ADJUSTMENT_DETAILS;
			errMsg[1] = " " ;
			errMsg[1] = errMsg[1] + ": " + "INPUT_STRING=" + inputString;
			errMsg[1] = errMsg[1] + ", " + "INPUT_ROWS=" + numberOfRows;
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}
		return responseMap;
	}

	public Map updateAdjustmentTaxes(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.updateAdjustmentTaxes():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;
		StringBuffer infoStringBuffer = new StringBuffer();
		List inputStringList = null;
		String claimNumber = null;

		String[] errMsg = new String[3];

		try
		{
			_LOGGER.info(METHOD_NAME + " inputMap=" + inputMap);

			String schemaName = getSchemaName();
			SPUpdateAdjustmentTaxes updateAdjustmentTaxesStoredProc = new SPUpdateAdjustmentTaxes(getDataSource(), schemaName);

			inputStringList = (List) inputMap.get("INPUT_STRING_LIST");
			String inputString = getRowDelimitedString(inputStringList);
			int numberOfRows = inputStringList.size();

			claimNumber = (String) inputMap.get("ESG_CLAIM_NUMBER");

			infoStringBuffer.append("API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_UPDATE_ADJUSTMENT_TAXES);
			infoStringBuffer.append("(");
			infoStringBuffer.append("INPUT_STRING=" + inputString);
			infoStringBuffer.append(", INPUT_ROWS=" + numberOfRows);
			infoStringBuffer.append(", ESG_CLAIM_NUMBER=" + claimNumber);
			infoStringBuffer.append(")");

			_LOGGER.info(METHOD_NAME + " " + infoStringBuffer.toString());

			errMsg[0] = infoStringBuffer.toString();

			responseMap = updateAdjustmentTaxesStoredProc.executeStoredProcedure(inputString, numberOfRows, claimNumber);

			_LOGGER.info(METHOD_NAME + " responseMap=" + responseMap);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug("updateAdjustmentTaxes in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("updateAdjustmentTaxes in VAC Failed \n" + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug("updateAdjustmentTaxes in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("updateAdjustmentTaxes in VAC Failed \n" + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}

		return responseMap;
	}

	public Map updateAdjustmentInterest(List inputStringList) throws NCASException {
		Map responseMap = null;
		try {
			String schemaName = getSchemaName();
			SPUpdateAdjustmentInterest updateAdjustmentInterestStoredProc = new SPUpdateAdjustmentInterest(getDataSource(), schemaName);
			_LOGGER.info("Input Params:: inputStringList - " + inputStringList);
			String inputString = getRowDelimitedString(inputStringList);
			int numberOfRows = inputStringList.size();
			_LOGGER.info("Params for SPUpdateAdjustmentInterest :: inputString - " + inputString + " , numberOfRows - " + numberOfRows);
			responseMap = updateAdjustmentInterestStoredProc.executeStoredProcedure(inputString, numberOfRows);
			_LOGGER.info("responseMap - " + responseMap);
		}  catch(NCASException ncasException ) {
			_LOGGER.debug("updateAdjustmentInterest in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("updateAdjustmentInterest in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("updateAdjustmentInterest in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("updateAdjustmentInterest in VAC Failed \n" + vacEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}
		return responseMap;
	}

	public Map submitAdjustment(Map inputMap) throws NCASException {
		Map responseMap = null;
		try {
			String schemaName = getSchemaName();
			SPSubmitAdjustment submitAdjustmentStoredProc = new SPSubmitAdjustment(getDataSource(), schemaName);
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.info("Params for SPSubmitAdjustment :: inputMap - " + inputMap + " , debugLevel - " + debugLevel);
	        responseMap = submitAdjustmentStoredProc.executeStoredProcedure(inputMap, debugLevel);
	        _LOGGER.info("responseMap - " + responseMap);
		}catch(NCASException ncasException ) {
			_LOGGER.debug("submitAdjustment in VAM Failed \n" + ncasException.getMessage());
			_LOGGER.error("submitAdjustment in VAM Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("submitAdjustment in VAM Failed \n" + vamEx.getMessage());
			_LOGGER.error("submitAdjustment in VAM Failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vamEx);
		}
		return responseMap;
	}

	public Map getTaxDetails(String vacAdjustId) throws NCASException {
		Map responseMap = null;
		String schemaName = getSchemaName();
		try {
			SPGetTaxDetails getTaxDetailsStoredProc = new SPGetTaxDetails(getDataSource(), schemaName);
			_LOGGER.info("Params for SPGetTaxDetails :: vacAdjustId - " + vacAdjustId);
			responseMap = getTaxDetailsStoredProc.executeStoredProcedure(vacAdjustId);
			_LOGGER.info("responseMap - " + responseMap);
		}  catch(NCASException ncasException ) {
			_LOGGER.debug("getTaxDetails in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("getTaxDetails in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("getTaxDetails in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("getTaxDetails in VAC Failed \n" + vacEx.getMessage());
			String[] errMsg = new String[3];
			errMsg[0] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_GET_TAX_DETAILS;
			errMsg[1] = " " ;
			errMsg[1] = errMsg[1] + ": " + "VAC_ADJUST_ID=" + vacAdjustId;
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}
		return responseMap;
	}


	public Map claimCalculateInterest(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.claimCalculateInterest():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		Map responseMap = null;
		String schemaName = getSchemaName();
		StringBuffer info = new StringBuffer();
		List inputStringList = null;
		String inputString = null;
		int numberOfRows = 0;
		String esgClaimNumber = null;
		String state = null;
		String type = null;
		String permanentLPCExempt = null;
		String calculateInterest = null;

		try
		{
			_LOGGER.info(METHOD_NAME + " inputMap=" + inputMap);

			esgClaimNumber = (String) inputMap.get("ESG_CLAIM_NUMBER");
			state = (String) inputMap.get("STATE");
			type = (String) inputMap.get("TYPE");
			permanentLPCExempt = (String) inputMap.get("PERM_LPC_EXMPT");
			calculateInterest = (String) inputMap.get("CALC_INTEREST");

			inputStringList = (List) inputMap.get("INPUT_STRING_LIST");
			inputString = getRowDelimitedString(inputStringList);
			numberOfRows = inputStringList.size();

			info.append("API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_CLAIM_CALCULATE_INTEREST);
			info.append("(");
			info.append("ESG_CLAIM_NUMBER=" + esgClaimNumber);
			info.append(", STATE=" + state);
			info.append(", TYPE=" + type);
			info.append(", PERM_LPC_EXMPT=" + permanentLPCExempt);
			info.append(", CALC_INTEREST=" + calculateInterest);
			info.append(", INPUT_STRING=" + inputString);
			info.append(", INPUT_ROWS=" + numberOfRows);
			info.append(")");

			_LOGGER.info(METHOD_NAME + " " + info.toString());

			SPClaimCalculateInterest claimCalculateInterestStoredProc = new SPClaimCalculateInterest(getDataSource(), schemaName);
			responseMap = claimCalculateInterestStoredProc.executeStoredProcedure(esgClaimNumber, state, type, permanentLPCExempt, calculateInterest, inputString, numberOfRows);

			_LOGGER.info(METHOD_NAME + " responseMap=" + responseMap);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug("claimCalculateInterest in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("claimCalculateInterest in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug("claimCalculateInterest in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("claimCalculateInterest in VAC Failed \n" + vacEx.getMessage());
			String[] errMsg = new String[3];
			errMsg[0] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_CLAIM_CALCULATE_INTEREST;
			errMsg[1] = " " ;
			errMsg[1] = errMsg[1] + ": " + info.toString();
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}

		return responseMap;
	}


	public Map deleteTransaction(String vacTransactionId) throws NCASException
	{
		Map responseMap = null;
		String schemaName = getSchemaName();

		try
		{
			_LOGGER.info("Params for SPDeleteTransaction :: vacTransactionId=" + vacTransactionId);

			SPDeleteTransaction deleteTransactionStoredProc = new SPDeleteTransaction(getDataSource(), schemaName);
			responseMap = deleteTransactionStoredProc.executeStoredProcedure(vacTransactionId);

			_LOGGER.info("responseMap=" + responseMap);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug("deleteTransaction in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("deleteTransaction in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug("deleteTransaction in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("deleteTransaction in VAC Failed \n" + vacEx.getMessage());

			String[] errMsg = new String[3];
			errMsg[0] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_DELETE_TRANSACTION;
			errMsg[1] = " " ;
			errMsg[1] = errMsg[1] + ": " + "VAC_TRANSACTION_ID=" + vacTransactionId;

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}

		return responseMap;
	}

	public Map updateInterestRate(Map inputMap) throws NCASException {
		Map responseMap = null;
		try {
			String schemaName = getSchemaName();
			SPUpdateInterestRate storedProc = new SPUpdateInterestRate(getDataSource(),schemaName);
	        responseMap = storedProc.executeStoredProcedure(inputMap);
		}catch(NCASException ncasException ) {
			_LOGGER.debug("updateInterestRate in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error("updateInterestRate in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		} catch(Exception vacEx) {
			_LOGGER.debug("updateInterestRate in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error("updateInterestRate in VAC Failed \n" + vacEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}
		return responseMap;
	}


	public void calculateTaxAndSave(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl::calculateTaxAndSave() ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " ENTER");
		}

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + " inputMap=" + inputMap);
		}

		final int INPUT_STRING_LIMIT = 29000;
		Map responseMap = null;
		Map returnMap = new HashMap();
		List adjustmentsList = null;
		AdjustmentDetails firstAdjustmentDetails = null;
		String claimNumber = (String) inputMap.get("CLAIM_NUMBER");

		Map taxEngineInputMap = new HashMap();
		taxEngineInputMap.put("LOGIN_USER_ID", (String) inputMap.get("LOGIN_USER_ID"));

		try
		{
			Map getAdjustmentListByStatusInputMap = new HashMap();
			getAdjustmentListByStatusInputMap.put("BAN", null);
			getAdjustmentListByStatusInputMap.put("ORIGINATING_SYS_ID", null);
			getAdjustmentListByStatusInputMap.put("ORIGINATOR_LOGINID", null);
			getAdjustmentListByStatusInputMap.put("ADJ_STATUS", null);
			getAdjustmentListByStatusInputMap.put("ADJ_LEVEL", "L");
			getAdjustmentListByStatusInputMap.put("NOTIFICATION_STAT", null);
			getAdjustmentListByStatusInputMap.put("RESULT_SET_TYPE", "A");
			getAdjustmentListByStatusInputMap.put("START_POSITION", "0");
			getAdjustmentListByStatusInputMap.put("ESG_CLAIM_NUMBER", claimNumber);

/*
 * 	Step1: get all adjustments in the claim
 */
			//get adjustments
			Map adjustmentListByStatusOutputMap = getAdjustmentListByStatus(getAdjustmentListByStatusInputMap);

			if (_LOGGER.isInfoEnabled())
			{
				_LOGGER.info(METHOD_NAME + " adjustmentListByStatusOutputMap=" + adjustmentListByStatusOutputMap);
			}

			if(adjustmentListByStatusOutputMap != null)
			{
				adjustmentsList = (List) adjustmentListByStatusOutputMap.get("adjustments");
			}

			if (adjustmentsList == null || adjustmentsList.size() == 0)
			{
				_LOGGER.info(METHOD_NAME + " adjustmentsList IS EMPTY");
				throw new Exception("adjustmentsList IS EMPTY - no adjustments to calculate taxes on");
			}
			else
			{
				AdjustmentDetails adjustmentDetails = null;
				int taxId = 1;

				if (_LOGGER.isDebugEnabled())
				{
					_LOGGER.debug(METHOD_NAME + " adjustmentsList.size()=" + adjustmentsList.size());
				}

/*
 *  Step 1a: Loop thru the list of adjustments adding a unique tax id integer field
 */
				//set the tax id information for each AdjustmentDetails objects in the List
				for (int i = 0; i < adjustmentsList.size(); i++)
				{
					adjustmentDetails = (AdjustmentDetails) adjustmentsList.get(i);

					//set taxId
					adjustmentDetails.setTaxId(AdjustmentUtil.padCharToString(Integer.toString(taxId), '0', 6, AdjustmentUtil.PAD_LEFT, false));

					//add it back the List
					adjustmentsList.set(i, adjustmentDetails);

					//increase taxId
					taxId++;
				}

				if (_LOGGER.isDebugEnabled())
				{
					_LOGGER.debug(METHOD_NAME + " after adding taxId - adjustmentsList=" + adjustmentsList);
				}

				//get first adustment details to store account level information
				firstAdjustmentDetails = (AdjustmentDetails) adjustmentsList.get(0);

/*
 *  Step 1b: Loop thru the list of adjustments again, this time convert the list into a new list of strings to be used to call taxing
 */

				Iterator it = adjustmentsList.iterator();
				adjustmentDetails = null;
				List nbbeTaxEngineInputStringList = new ArrayList();

				//build a List of NBBE Tax Engine input strings
				while (it.hasNext())
				{
					//get data
					adjustmentDetails = (AdjustmentDetails) it.next();

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " adjustmentDetails=" + adjustmentDetails.toString());
					}

					if(adjustmentDetails != null)
					{
						//for full month line adjustment request: based on months
						if(Integer.parseInt(adjustmentDetails.getNumberOfMonths()) > 0)
						{
							//set the months or days adjustment indicator so appropriate taxes are calculated
							adjustmentDetails.setMonthsOrDaysAdjustmentIndicator(AdjustmentUtil.MONTHS_ADJUSTMENT);

							taxEngineInputMap.put("ADJUSTMENT_DETAILS", (AdjustmentDetails) adjustmentDetails);

							//then add to nbbe tax engine string
							nbbeTaxEngineInputStringList.add(AdjustmentHelper.getTaxEngineInputString(taxEngineInputMap));
						}

						//for partial month line adjustment request: based on days
						if(Integer.parseInt(adjustmentDetails.getNumberOfDays()) > 0)
						{
							//set the months or days adjustment indicator so appropriate taxes are calculated
							adjustmentDetails.setMonthsOrDaysAdjustmentIndicator(AdjustmentUtil.DAYS_ADJUSTMENT);

							taxEngineInputMap.put("ADJUSTMENT_DETAILS", (AdjustmentDetails) adjustmentDetails);

							//then add to nbbe tax engine string
							nbbeTaxEngineInputStringList.add(AdjustmentHelper.getTaxEngineInputString(taxEngineInputMap));
						}
					}
				}

				Map headerMap = new HashMap();
				headerMap.put("SYSTEM_INDICATOR", "1");
				headerMap.put("OSID", firstAdjustmentDetails.getOsid());
				headerMap.put("TAX_STATUS_INDICATOR_FEDERAL", firstAdjustmentDetails.getTaxStatusFed());
				headerMap.put("TAX_STATUS_INDICATOR_STATE", firstAdjustmentDetails.getTaxStatusState());
				headerMap.put("TAX_STATUS_INDICATOR_E911", firstAdjustmentDetails.getTaxStatusE911());
				headerMap.put("TAX_STATUS_INDICATOR_SURCHARGE", firstAdjustmentDetails.getTaxStatusSurcharge());
				headerMap.put("TAX_STATUS_INDICATOR_LOCAL", firstAdjustmentDetails.getTaxStatusLocal());
				headerMap.put("ACCOUNT_TYPE_CODE ", firstAdjustmentDetails.getAccountTypeCode());

				Map nbbeTaxInfoWithRequestLimitProcessingInputMap = new HashMap();
				nbbeTaxInfoWithRequestLimitProcessingInputMap.put("HEADER_DATA_MAP", headerMap);
				nbbeTaxInfoWithRequestLimitProcessingInputMap.put("DATA_STRING_LIST", nbbeTaxEngineInputStringList);

/*
 * Step 2: Get tax info for all of the adjustments
 * send all of the converted adjustments to process which will then send batches of 25 adjs to taxing at at time till done then
 * return with the taxing results for all of the adjustments
 */
				//get tax data by calling nbbe tax engine api
				Map nbbeTaxEngineResultSetMap = getNBBETaxInfoWithRequestLimitProcessing(nbbeTaxInfoWithRequestLimitProcessingInputMap);

				if (_LOGGER.isInfoEnabled())
				{
					_LOGGER.info(METHOD_NAME + " nbbeTaxEngineResultSetMap=" + nbbeTaxEngineResultSetMap);
				}

/*
 * Step 3 Combine adjustments with the taxes and save info back to VAC.
 * need to match the taxes and adjustments based on key we put on both, then sum all the tax buckets into the adjustment
 * then send the adjustments back to vac, may have to call vac multiple times because the vac api can only accept a set number
 * of adjustments at a time.
 */

				//save tax data
				it = adjustmentsList.iterator();
				Tax firstTaxDetails = null;
				StringBuffer inputString = null;
				int inputStringLength = 0;
				List inputStringList = new ArrayList();
				String key = null;
				Map taxGroupMap = null;
				Collection taxGroupMapCollection = null;
				Map updateAdjustmentTaxesInputMap = new HashMap();
				Map updateAdjustmentTaxesOutputMap = null;

				//for each AdjustmentDetails objects in the List
				while (it.hasNext())
				{
					adjustmentDetails = (AdjustmentDetails) it.next();

					//reset inputString
					inputString = new StringBuffer();

					key = adjustmentDetails.getTaxId();

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " key=" + key);
					}

					if (nbbeTaxEngineResultSetMap.containsKey(key))
					{
						taxGroupMap = (Map) nbbeTaxEngineResultSetMap.get(key);
						taxGroupMapCollection = taxGroupMap.values();
						Iterator taxGroupMapIterator = taxGroupMapCollection.iterator();

						//get the first Tax object to retrieve tax level information
						while (taxGroupMapIterator.hasNext())
						{
							firstTaxDetails = (Tax) taxGroupMapIterator.next();
							break;
						}
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " firstTaxDetails=" + firstTaxDetails);
					}

					//set adjustment id
					inputString.append(adjustmentDetails.getAdjustmentId());

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [adjustment id] inputString=" + inputString);
					}

					//set tax applied indicator
					inputString.append(Adjustment.fsep);
					inputString.append(AdjustmentUtil.TAX_APPLIED_IND_YES);

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [tax applied indicator] inputString=" + inputString);
					}

					// set the tax amount
					inputString.append(Adjustment.fsep);

					if (nbbeTaxEngineResultSetMap.containsKey(key))
					{
						double totalTaxAmount = 0;
						Tax taxDetails = null;

						if (taxGroupMap != null)
						{
							Iterator iter = taxGroupMapCollection.iterator();

							while (iter.hasNext())
							{
								taxDetails = (Tax) iter.next();

								totalTaxAmount = totalTaxAmount + Double.parseDouble(taxDetails.getTaxAmount());
							}
						}

						if (_LOGGER.isDebugEnabled())
						{
							_LOGGER.debug(METHOD_NAME + " totalTaxAmount=" + totalTaxAmount);
						}

						BigDecimal totalTaxAmountBD = new BigDecimal(totalTaxAmount);

						//round it to 2 decimal places
						totalTaxAmountBD = totalTaxAmountBD.setScale(2, BigDecimal.ROUND_HALF_UP);

						if (_LOGGER.isDebugEnabled())
						{
							_LOGGER.debug(METHOD_NAME + " totalTaxAmountBD=" + totalTaxAmountBD);
						}

						inputString.append(totalTaxAmountBD.toPlainString());
					}
					else
					{
						inputString.append("0.00");
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [tax amount] inputString=" + inputString);
					}

					//set geocode
					inputString.append(Adjustment.fsep);

					if (nbbeTaxEngineResultSetMap.containsKey(key))
					{
						//pass back geocode returned from NBBE Tax Engine call
						inputString.append(firstTaxDetails.getGeoCode());
					}
					else
					{
						//pass back original value
						inputString.append(adjustmentDetails.getGeoCode());
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [geocode] inputString=" + inputString);
					}

					//set tax location
					inputString.append(Adjustment.fsep);

					if(nbbeTaxEngineResultSetMap.containsKey(key))
					{
						inputString.append(firstTaxDetails.getTaxLocationTypeCode());
					}
					else
					{
						//pass back original value
						inputString.append(adjustmentDetails.getTaxLocation());
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [tax location] inputString=" + inputString);
					}

					//set tax engine code
					inputString.append(Adjustment.fsep);

					if(nbbeTaxEngineResultSetMap.containsKey(key))
					{
						inputString.append(firstTaxDetails.getTaxEngineCode());
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [tax engine code] inputString=" + inputString);
					}

					//set TAX_GROUP_ID(x), TAX_GROUP_DESC(x), TAX_GROUP_AMOUNT(x)
					if(nbbeTaxEngineResultSetMap.containsKey(key))
					{
						Tax taxDetails = null;

						if (taxGroupMap != null)
						{
							Iterator iter = taxGroupMapCollection.iterator();

							while (iter.hasNext())
							{
								taxDetails = (Tax) iter.next();

								if (_LOGGER.isDebugEnabled())
								{
									_LOGGER.debug(METHOD_NAME + " taxDetails=" + taxDetails);
								}

								//tax group
								inputString.append(Adjustment.fsep);
								inputString.append(taxDetails.getTaxGroup());

								//tax description
								inputString.append(Adjustment.fsep);
								inputString.append(taxDetails.getTaxDescription());

								//tax amount
								inputString.append(Adjustment.fsep);

								BigDecimal taxAmountBD = new BigDecimal(taxDetails.getTaxAmount());

								//round it to 2 decimal places
								taxAmountBD = taxAmountBD.setScale(2, BigDecimal.ROUND_HALF_UP);

								inputString.append(taxAmountBD.toPlainString());
							}
						}
					}
					else
					{
						inputString.append(Adjustment.fsep);
						inputString.append(Adjustment.fsep);
						inputString.append(Adjustment.fsep);
					}

					if (_LOGGER.isDebugEnabled())
					{
						_LOGGER.debug(METHOD_NAME + " [TAX_GROUP_ID(x), TAX_GROUP_DESC(x), TAX_GROUP_AMOUNT(x)] inputString=" + inputString);
					}

					if ((inputStringLength + inputString.length()) > INPUT_STRING_LIMIT)
					{
						updateAdjustmentTaxesInputMap.put("INPUT_STRING_LIST", (List) inputStringList);
						updateAdjustmentTaxesInputMap.put("ESG_CLAIM_NUMBER", null);

						updateAdjustmentTaxesOutputMap = updateAdjustmentTaxes(updateAdjustmentTaxesInputMap);

						//reset list
						inputStringList.clear();

						//reset length
						inputStringLength = inputString.length();
					}
					else
					{
						//update the total length
						inputStringLength = inputStringLength + inputString.length();
					}

					//add to list
					inputStringList.add(inputString.toString());
				} //END while

				//handle remaining data
				if (inputStringList.size() > 0)
				{
					updateAdjustmentTaxesInputMap.put("INPUT_STRING_LIST", (List) inputStringList);
					updateAdjustmentTaxesInputMap.put("ESG_CLAIM_NUMBER", claimNumber);

					updateAdjustmentTaxesOutputMap = updateAdjustmentTaxes(updateAdjustmentTaxesInputMap);
				}
			}
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug("calculateTaxAndSave Failed \n" + ncasException.getMessage());
			_LOGGER.error("calculateTaxAndSave Failed \n" + ncasException.getMessage());

			throw ncasException;

		}
		catch(Exception vacEx)
		{
			_LOGGER.debug("calculateTaxAndSave Failed \n" + vacEx.getMessage());
			_LOGGER.error("calculateTaxAndSave Failed \n" + vacEx.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx);
		}
	}


	public Map updateClaim(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "AdjustmentDAOImpl.updateClaim():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "ENTER");
		}

		Map responseMap = null;
		String schemaName = getSchemaName();
		String claimNumber = null;
		String inputString = null;

		try
		{
			_LOGGER.info(METHOD_NAME + "inputMap=" + inputMap);

			claimNumber = (String) inputMap.get("ESG_CLAIM_NUMBER");
			inputString = (String) inputMap.get("INPUT_STRING");

			SPUpdateClaim updateClaimStoredProc = new SPUpdateClaim(getDataSource(), schemaName);
			responseMap = updateClaimStoredProc.executeStoredProcedure(claimNumber, inputString);

			_LOGGER.info(METHOD_NAME + "responseMap=" + responseMap);
		}
		catch(NCASException ncasException )
		{
			_LOGGER.debug(METHOD_NAME + "updateClaim in VAC Failed \n" + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "updateClaim in VAC Failed \n" + ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vacEx)
		{
			_LOGGER.debug(METHOD_NAME + "updateClaim in VAC Failed \n" + vacEx.getMessage());
			_LOGGER.error(METHOD_NAME + "updateClaim in VAC Failed \n" + vacEx.getMessage());

			String[] errMsg = new String[3];
			errMsg[0] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_UPDATE_CLAIM;
			errMsg[1] = " " ;
			errMsg[1] = errMsg[1] + ": " + inputMap;

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, AdjustmentDAOImpl.class, vacEx, errMsg);
		}

		return responseMap;
	}


	private String getCommaSeparatedString(List list) {
		final String COMMA_SEPARATOR = ",";
		String retValue = "";
		int noOfRows = list.size();
		if (noOfRows > 1) {
			for (int index=0; index<noOfRows; index++) {
				String adjustmentId = (String) list.get(index);
				if (index==0) {
					retValue = adjustmentId;
				} else {
					retValue = retValue + COMMA_SEPARATOR + adjustmentId;
				}
			}
		} else {
			retValue = (String) list.get(0);
		}
		return retValue;
	}

	private String getRowDelimitedString(List list) {
		final String ROW_SEPARATOR = "|";
		String retValue = "";
		int noOfRows = list.size();
		for (int index=0; index<noOfRows; index++) {
			String inputString = (String) list.get(index);
			if (index==0){
				retValue = inputString + ROW_SEPARATOR;
			} else {
				retValue = retValue + inputString + ROW_SEPARATOR;
			}
		}
		return retValue;
	}

	private String getSchemaName() {
		String schemaName = NCASBOSIConfig.getProperty(SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	private String getVAMSchemaName() {
		String schemaName = BOSIConfig.getProperty(VAM_SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	private String getNBBETaxEngineSchemaName() {
		String schemaName = BOSIConfig.getProperty(NBBE_TAX_ENGINE_SCHEMA_NAME, " ");
		_LOGGER.info("NBBE TAX ENGINE SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	private String getNBBETaxEngineSPName() {
		String spName = BOSIConfig.getProperty(NBBE_TAX_ENGINE_SP_NAME);
		_LOGGER.info("NBBE TAX ENGINE SP NAME ##  -> " + spName);
		return spName;
	}
}
