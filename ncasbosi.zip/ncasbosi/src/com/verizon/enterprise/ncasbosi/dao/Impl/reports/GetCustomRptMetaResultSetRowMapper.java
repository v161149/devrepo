package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.reports.CustomRptMeta;

public class GetCustomRptMetaResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetCustomRptMetaResultSetRowMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetCustomRptMetaResultSetRowMapper::mapRow rowNum - " + rowNum);

		CustomRptMeta customRptMetaItem = new CustomRptMeta(rs.getString("REPORT_SECTION"), rs.getString("REPORT_TYPE"),rs.getString("FIELD_GROUP"),
				rs.getString("VIEWBY_NAME"), rs.getString("FIELD_NAME"),rs.getString("SOURCE_ABBR"));

		_LOGGER.debug(customRptMetaItem.toString());
		return customRptMetaItem;
	}
}
