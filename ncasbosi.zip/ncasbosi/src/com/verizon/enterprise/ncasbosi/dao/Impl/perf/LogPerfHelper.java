package com.verizon.enterprise.ncasbosi.dao.Impl.perf;

import java.util.Map;
import java.util.List;
import java.util.Iterator;
import java.util.HashMap;
import java.util.ArrayList;
import com.verizon.enterprise.common.ncas.LogEmailUtility;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.dao.Impl.batch.BatchRequestDAOImpl;


public class LogPerfHelper
{
	private static final org.apache.log4j.Logger __Logger = org.apache.log4j.Logger.getLogger(LogPerfHelper.class);
	private static LogPerfHelper defaultInstance;
	
	public LogPerfHelper()
	{
	}

	public static LogPerfHelper getInstance()
	{
		if (defaultInstance == null)
		{
			defaultInstance = new LogPerfHelper();
		}
		return defaultInstance;
	}
	
	/**
	 * This method is used to analyse the records in PL_LOGS_PERF_T table and get all the related rows
	 * for the domain.
	 * @param domain
	 */
	public void logAnalysis(String domain) throws Exception
	{
		LogPerfDAOImpl logPerfDaoObj = new LogPerfDAOImpl();
		Map<String, String> inputMap = new HashMap<String, String>();
		inputMap.put("domain", domain);
		Map<String, List> respMap = new HashMap<String, List>();
		try
		{
			respMap = logPerfDaoObj.processLogPerf("L", inputMap);
		}
		catch(Exception re)
		{
			//send internal mail
		}
		Iterator it = respMap.entrySet().iterator();
		StringBuilder message = new StringBuilder();
		message.append("<TR>");
		while(it.hasNext())
		{
			Map.Entry<String, List> pairs = (Map.Entry<String, List>) it.next();
			List list = pairs.getValue();
			for(int i = 0; i < list.size(); i++)
			{
				Object obj = list.get(i);
				message.append("<TD>");
				message.append(obj);
				message.append("</TD>");
			}
			message.append("</TR>");
		}
		setMessage(domain, "Log details for "+domain, message.toString());
	}

	private void setMessage(String domain, String subject, String message) throws Exception
	{
		String str = "<HTML>" +
					 "<BODY>" +
					 "<TABLE cellSpacing=0 cellPadding=0 border=0 style='PADDING-RIGHT: 20px; PADDING-LEFT: 20px; FONT: 12px Arial; COLOR: #000000; PADDING-TOP: 17px; TEXT-ALIGN: left'>" +
					 "<TR><TD>" +
					 "<BR><BR>" +
					 "This email is being sent with the log details of the new bill view pages accessed today:<BR><BR>" +
					 "<TABLE cellSpacing=0 cellPadding=3 border=1 width='100%' style='font-family: arial; font-size: 14px;'>" +
					 "<TR>" +
					 "<TH rowspan='2'><b>Page</b></TH>" +
					 "<TD colspan='3' align='center'><b>" + domain + "</b></TD>" +
					 "<TD colspan='3' align='center'><b>BOSI</b></TD>" +
					 "<TH rowspan='2'><b>Login Id</b></TH>" +
					 "</TR>" +
					 "<TR>" +
					 "<TD><b>Start TS</b></TD>" +
					 "<TD><b>End TS</b></TD>" +
					 "<TD><b>Elasped TS</b></TD>" +
					 "<TD><b>Start TS</b></TD>" +
					 "<TD><b>End TS</b></TD>" +
					 "<TD><b>Elasped TS</b></TD>" +
					 "</TR>" +
					 message +
				     "</TABLE>" +
				     "</TD></TR></TBODY></TABLE></BODY></HTML>";
		__Logger.info("Log Analysis --->" + str);
		LogEmailUtility email = LogEmailUtility.getInstance();
		List<String> toInAddr = new ArrayList<String>();
		toInAddr.add("perfTracker@lists.verizonbusiness.com");
		email.setContent(subject, str);
		email.sendMail(toInAddr);
	}
}
