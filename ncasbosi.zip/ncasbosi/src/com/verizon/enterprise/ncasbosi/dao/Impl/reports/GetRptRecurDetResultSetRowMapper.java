package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.reports.RptRecur;

public class GetRptRecurDetResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetRptRecurDetResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetRptRecurDetResultSetRowMapper::mapRow rowNum - " + rowNum);

		RptRecur rptRecurItem = new RptRecur();

		int rptRecurId = rs.getInt("RPT_RECUR_ID");                                                          //RPT_RECUR_ID
		int rptId = rs.getInt("RPT_ID");                                                                     //RPT_ID
		String portalLoginId = rs.getString("PORTAL_LOGIN_ID");                                                    //PORTAL_LOGIN_ID
		String structType = rs.getString("STRUCT_TYPE");                                                           //STRUCT_TYPE
		double structOid = rs.getDouble("STRUCT_OID");                                                             //STRUCT_OID
		String positionType = rs.getString("POSITION_TYPE");                                                       //POSITION_TYPE
		double positionOid = rs.getDouble("POSITION_OID");                                                         //POSITION_OID
		String status = rs.getString("STATUS");                                                                    //STATUS
		int recurDay = rs.getInt("RECUR_DAY");                                                                     //RECUR_DAY
		String frequency = rs.getString("FREQUENCY");                                                              //FREQUENCY
		String startDate = CommonUtil.getDisplayVAMDateFromStringEx(rs.getDate("START_DATE"));                       //START_DATE
		String endDate = CommonUtil.getDisplayVAMDateFromStringEx(rs.getDate("END_DATE"));                           //END_DATE
		String nextScheduleDate = CommonUtil.getDisplayVAMDateFromStringEx(rs.getDate("NEXT_SCHEDULE_DATE"));        //NEXT_SCHEDULE_DATE
		String emailAddr = rs.getString("EMAIL_ADDR");                                                             //EMAIL_ADDR
		String pageSubset = rs.getString("PAGE_SUBSET");                                                           //PAGE_SUBSET
		String rqstLinkParam = rs.getString("RQST_LINK_PARAM");                                                    //RQST_LINK_PARAM
		String rqstSortParam = rs.getString("RQST_SORT_PARAM");                                                    //RQST_SORT_PARAM
		String rqstFilterParam = rs.getString("RQST_FILTER_PARAM");                                                //RQST_FILTER_PARAM
		double userOid = rs.getDouble("USER_OID");                                                                 //USER_OID
		String createdTimestamp = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("CREATED_TIMESTAMP"));
		String lastUpdTimestamp = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("LAST_UPD_TIMESTAMP"));
		String lastUpdatedBy = rs.getString("LAST_UPDATED_BY");

		rptRecurItem.setRptRecurId(rptRecurId);
		rptRecurItem.setRptId(rptId);
		rptRecurItem.setPortalLoginId(portalLoginId);
		rptRecurItem.setStructType(structType);
		rptRecurItem.setStructOid(structOid);
		rptRecurItem.setPositionType(positionType);
		rptRecurItem.setPositionOid(positionOid);
		rptRecurItem.setStatus(status);
		rptRecurItem.setRecurDay(recurDay);
		rptRecurItem.setFrequency(frequency);
		rptRecurItem.setStartDate(startDate);
		rptRecurItem.setEndDate(endDate);
		rptRecurItem.setNextScheduleDate(nextScheduleDate);
		rptRecurItem.setEmailAddr(emailAddr);
		rptRecurItem.setPageSubset(pageSubset);
		rptRecurItem.setRqstLinkParam(rqstLinkParam);
		rptRecurItem.setRqstSortParam(rqstSortParam);
		rptRecurItem.setRqstFilterParam(rqstFilterParam);
		rptRecurItem.setUserOid(userOid);
		rptRecurItem.setCreatedTimestamp(createdTimestamp);
		rptRecurItem.setLastUpdTimestamp(lastUpdTimestamp);
		rptRecurItem.setLastUpdatedBy(lastUpdatedBy);
		boolean isRecur = true;
		if (recurDay==-1) 
			isRecur = false;
		
		rptRecurItem.setRecur(isRecur);
		_LOGGER.debug(rptRecurItem.toString());
		return rptRecurItem;
	}
}
