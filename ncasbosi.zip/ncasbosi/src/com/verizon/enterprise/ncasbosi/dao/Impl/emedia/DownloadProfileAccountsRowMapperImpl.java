	package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;
	
	import org.apache.log4j.Logger;
	import org.springframework.jdbc.core.ResultSetExtractor;

	import com.verizon.enterprise.common.eMedia.EMediaProfileConstants;
	import com.verizon.enterprise.common.ncas.display.Cell;
	import com.verizon.enterprise.ncasbosi.common.CommonUtil;

	public class DownloadProfileAccountsRowMapperImpl implements ResultSetExtractor {

		static private final Logger _LOGGER = Logger.getLogger(DownloadProfileAccountsRowMapperImpl.class);
		private String profileType;
		
		public Object extractData(ResultSet rs) throws SQLException {
			//_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::mapRow rowNumber -> " + rowNum);
			_LOGGER.info("Inside DownloadProfileAccountsRowMapperImpl::extractData ");
			CommonUtil.printMetaDataInfo(rs.getMetaData());
			List<List<Cell>> profilesList = new ArrayList<List<Cell>>();
			List<Cell> summary = new ArrayList<Cell>();

			try {
				/*
				summary.add(new Cell("Enterprise ID"));
				summary.add(new Cell("Corp/Group ID"));
				summary.add(new Cell("Account Number"));
				summary.add(new Cell("Source System"));
				summary.add(new Cell("Account Name"));
				summary.add(new Cell("Start Date"));
				summary.add(new Cell("End Date"));
				summary.add(new Cell("Bill Period/Cycle"));
				summary.add(new Cell("LOB"));
				summary.add(new Cell("Account Status"));

				profilesList.add(summary);
				*/
				while(rs.next()) {
					summary = new ArrayList<Cell>();

					String enterpriseId = rs.getString("ENTERPRISE_ID");
					String banDan = rs.getString("BAN_DAN");
					String man = rs.getString("MAN");
					//String manDan = rs.getString("MAN_DAN");
					String origSysId = rs.getString("ORIG_SYSTEM_ID");
					String startBillPeriod = rs.getString("START_DATE");
					String endBillPeriod = rs.getString("END_DATE");
					String accountName = rs.getString("COMPANY_NAME");
					String billPeriod = rs.getString("BP_DAY");
					String edi05 = rs.getString("PROD_ISA_05");
					String edi06 = rs.getString("PROD_ISA_06");
					String edi02 = rs.getString("PROD_GS_02");
					String channelCode = rs.getString("LOB_IND");
					String ediDataGroup = rs.getString("DATA_GROUP");
					String systemAbbrv = rs.getString("SYST_ABBREVIATION");
					String acctStatus = rs.getString("ACCT_STATUS");

					
					if(getProfileType()!=null && getProfileType().trim().equalsIgnoreCase(EMediaProfileConstants.SECABS_CONFIG)){//this is for secabs
						if(CommonUtil.isNotNull(enterpriseId)){
							summary.add(new Cell(enterpriseId.trim()));
						}
						if(CommonUtil.isNotNull( man)){
							summary.add(new Cell(CommonUtil.getFormattedAccount(man.trim(),origSysId, "")));
						}
						if(CommonUtil.isNotNull( banDan)){
							summary.add(new Cell(CommonUtil.getFormattedAccount(banDan.trim(),origSysId, "")));
						}
						if(CommonUtil.isNotNull(systemAbbrv)) {
							summary.add(new Cell(systemAbbrv.trim()));
						}
						if(CommonUtil.isNotNull( accountName)){
							summary.add(new Cell(accountName.trim()));
						}
						if(CommonUtil.isNotNull( startBillPeriod)){
							summary.add(new Cell(CommonUtil.getDisplayDateFromString(startBillPeriod.trim())));
						}
						if(CommonUtil.isNotNull( endBillPeriod)){
							summary.add(new Cell(CommonUtil.getDisplayDateFromString(endBillPeriod.trim())));
						}
						if(CommonUtil.isNotNull( billPeriod)){
							summary.add(new Cell(billPeriod.trim()));
						}
						if(CommonUtil.isNotNull( channelCode)){
							summary.add(new Cell(channelCode.trim()));
						}
						if(CommonUtil.isNotNull( acctStatus)){ 
							summary.add(new Cell(acctStatus.trim()));
						}
					}else{//rest of the emedia types
						if(CommonUtil.isNotNull( origSysId)){ origSysId = origSysId.trim();}
						else origSysId = "";


						if(!origSysId.startsWith("M") && (banDan==null ||(banDan!=null && banDan.trim().equals("")))){
							banDan = man;
							man = "";
						}
						if(CommonUtil.isNotNull(enterpriseId)) {
							summary.add(new Cell(enterpriseId.trim()));
						}
						if(CommonUtil.isNotNull( man)) {summary.add(new Cell(CommonUtil.getFormattedAccount(man.trim(),origSysId, "")));}
						if(CommonUtil.isNotNull( banDan)) {summary.add(new Cell(CommonUtil.getFormattedAccount(banDan.trim(),origSysId, "")));}
						if(CommonUtil.isNotNull(systemAbbrv)) {
							summary.add(new Cell(systemAbbrv.trim()));
						}
						if(CommonUtil.isNotNull(accountName)) {
							summary.add(new Cell(accountName.trim()));
						}

						if(CommonUtil.isNotNull( startBillPeriod)) {summary.add(new Cell(CommonUtil.getDisplayDateFromString(startBillPeriod.trim())));}
						if(CommonUtil.isNotNull( endBillPeriod)) {summary.add(new Cell(CommonUtil.getDisplayDateFromString(endBillPeriod.trim())));}

						if(CommonUtil.isNotNull(billPeriod)) {
							summary.add(new Cell(billPeriod.trim()));
						}
						if(CommonUtil.isNotNull(channelCode)) {
							summary.add(new Cell(channelCode.trim()));
						}
						
						if(CommonUtil.isNotNull( edi05)) {
							summary.add(new Cell(edi05.trim()));
						}
						
						if(CommonUtil.isNotNull( edi06)) {
							summary.add(new Cell(edi06.trim()));
						}
						
						if(CommonUtil.isNotNull( edi02)) {
							summary.add(new Cell(edi02.trim()));
						}
						
						if(CommonUtil.isNotNull( ediDataGroup)) {
							summary.add(new Cell(ediDataGroup.trim()));
						}					
						
						if(CommonUtil.isNotNull(acctStatus)) {
							summary.add(new Cell(acctStatus.trim()));
						}
					}										
					profilesList.add(summary);
				}
			}  catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				//throw new NCASException("Exception occured while parsing the resultset \n"+pe.toString(),DownloadProfileAccountsRowMapperImpl.class,pe);
			} catch(Exception e) {
				e.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
			}
			return profilesList;
		}

		public String getProfileType() {
			return profileType;
		}

		public void setProfileType(String profileType) {
			this.profileType = profileType;
		}
	}
