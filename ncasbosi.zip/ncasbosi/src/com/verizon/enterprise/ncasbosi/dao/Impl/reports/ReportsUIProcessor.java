package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.reports.ReportsUIInterface;

/*
 * This class decides which operation to be performed
 */
public class ReportsUIProcessor implements NCASBOSIConstants {
	private static ReportsUIInterface interfaceObj;
	private static final Logger _LOGGER = Logger.getLogger(ReportsUIProcessor.class);
	
	private static synchronized ReportsUIInterface getProcessorObject(){
		if(interfaceObj==null){
			_LOGGER.info("Getting the singleton Reports UI Object");
			interfaceObj = DAOFactory.getInstance().getReportsUIImpl();
			_LOGGER.info("Successfully retrieved the reference to the Reports UI Object");
		}
		return interfaceObj;
	}
	
	public static Map processRptUIRequest(Object input,String function)throws NCASException, Exception, NoSuchMethodException{
		_LOGGER.info("Entering processRptUIRequest");
		Map responseMap = null;
		try{
			Method method = getProcessorObject().getClass().getMethod(function, new Class[]{Map.class});
			responseMap = (Map)method.invoke(getProcessorObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException(BILLING_EXCEPTION_850,ReportsUIProcessor.class,exception.getTargetException());
		}
		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processRptUIRequest");
		return responseMap;
	}
}
