package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiryNote;

public class CommentsMapper implements RowMapper {
  static private final Logger _LOGGER = Logger.getLogger(CommentsMapper.class);

  public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
    BillInquiryNote biNote = null;
    if(rs != null) {
      biNote =new BillInquiryNote();
      biNote.setNoteType(rs.getString("COMMENT_TYPE"));
      biNote.setNoteDate(rs.getDate("COMMENT_DATE"));
      biNote.setNoteText(rs.getString("COMMENT_TEXT"));
      if (rs.getString("PUBLIC_PRIVATE_IND").equalsIgnoreCase("1"))
        biNote.setPublicNote(true);
      else
        biNote.setPublicNote(false);
      _LOGGER.info(biNote.toString());
    }
    return biNote;
  }
}
