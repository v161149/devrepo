package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDownloadGCPAccountsSummary extends BaseStoredProcedure {

	private static List spInOutList;
	static
	{
		spInOutList = SPInoutListAccounts_v10.getInoutListForAccount_v10(new DownloadGCPAccountsSummaryRowMapperImpl());
	}
	
	public SPDownloadGCPAccountsSummary(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_GCP_SUMMARY, spInOutList);	
	}

	public Content executeStoredProcedure(String userId, String debugLevel,
			String customerNo, String customerType,
			String whereFilter, String sortOrder,
			String cursorId, String configSubsOid) throws Exception
			{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		if(customerNo == null ) {
			customerNo = "";
		}
		if(customerType == null) {
			customerType = "";
		}
		if(whereFilter == null) {
			whereFilter = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(cursorId == null) {
			cursorId = "";
		}
		// clearing out token_st for each call, so doesn't execute same 
		cursorId = "";

		paramValueList.add(customerNo);//CUST_NO
		paramValueList.add(customerType);//CUSTOMER_TYPE
		paramValueList.add(configSubsOid);//CONFIG_SUBS_OID
		paramValueList.add(whereFilter!=null?whereFilter.trim():whereFilter);//WHERE_PHRASE
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(cursorId);//TOKEN_ST


		paramValueList.add("1");// LINE_OFFSET
		paramValueList.add("15000");// PAGE_SIZE
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		checkVACErrors(procMap);//call this method to identify any errors using the return code and throw exception accordingly
		List actualList = (List)procMap.get("accounts");

		Content retObj = new Content();
		retObj.setRows(actualList);

		return retObj;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
