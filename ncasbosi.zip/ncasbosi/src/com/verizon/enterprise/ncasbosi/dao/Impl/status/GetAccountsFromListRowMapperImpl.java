package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.status.ListDetails;
import com.verizon.enterprise.common.status.ReportsAddParam;
import com.verizon.enterprise.common.status.SSAccountsRecord;
import com.verizon.enterprise.common.status.ScheduledReports;
import com.verizon.enterprise.common.status.StatusSchedulingUtility;
import com.verizon.enterprise.common.status.TableCell;
import com.verizon.enterprise.common.status.TableHeaderCell;
import com.verizon.enterprise.common.status.TableRow;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAccountsFromListRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger
			.getLogger(GetAccountsFromListRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetAccountsFromListRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid = 0.0;
		double previousOid = 0.0;
		List refList = null;
		String key = "";
		ArrayList al = new ArrayList();
		
		al.add(new String[] { "CORP_ID", "BAN_DAN",
				"ACCNT_NAME", "BILL_CITY", "BILL_STATE", "NBR_NUMBER" });
		try {

			
			 while(rs.next()) {			

				String corpId = rs.getString("CORP_ID");
				String acctNum = rs.getString("BAN_DAN");
				String acctName = rs.getString("ACCNT_NAME");
				String billCity = rs.getString("BILL_CITY");
				String billState = rs.getString("BILL_STATE");
				String nbrAcctNum = rs.getString("NBR_NUMBER"); 
				
				
				// Adding additional Parameters.....
				ReportsAddParam listDetailsAddParam = new ReportsAddParam();
				listDetailsAddParam.setSubscriptionOid(rs.getString("SUBSCRIPTION_OID"));
				listDetailsAddParam.setOsid(rs.getString("ORIG_SYSTEM_ID"));
				listDetailsAddParam.setBan(rs.getString("BAN"));
				listDetailsAddParam.setMan(rs.getString("MAN"));
				listDetailsAddParam.setTnType(rs.getString("TN_TYPE"));
				listDetailsAddParam.setBillTypeFilter(rs.getString("BILL_TYPE"));
				
				al.add(new Object[] { corpId, acctNum, acctName,billCity,billState,nbrAcctNum,listDetailsAddParam});
			
			 }
			 
			 _LOGGER.info("al size = "  + al.size());
			 _LOGGER.info("al DATA = "  + al.toString());

			 ListDetails object = populateListDetailsDataModel(al);
			
		     printListDetailsDataModel(object);	 
		     returnMap.put("listDetails", (ListDetails) object);
		     
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			throw nfe;
		}
		return returnMap;
	}

	private static void printListDetailsDataModel(ListDetails listDetails) {
		if (listDetails != null) {
			//System.out.println(listDetails.toString());
		} else {
			//System.out.println("list details data Model not created");
		}
	}

	public static ListDetails populateListDetailsDataModel(ArrayList al) {
		
		String METHOD_NAME = " populateListDetailsDataModel";
		_LOGGER.debug(METHOD_NAME + "Exception occured while parsing the resultset \n");
		
		ListDetails listDetails = new ListDetails();
		/*
		 * String[] total = (String[]) al.get(0);
		 * currentReports.setPageOffset(Integer.parseInt(total[0]));
		 * currentReports.setPageSize(Integer.parseInt(total[1]));
		 * currentReports.setTotalRows(Integer.parseInt(total[2]));
		 */
		listDetails.setRecordsReturned(al.size() - 1);
		
		_LOGGER.debug(METHOD_NAME + "records returned = " + listDetails.getRecordsReturned());
		

		// Setting Header row
		ArrayList objectHeader = new ArrayList();
		String[] dbName = (String[]) al.get(0);
		for (int k = 0; k < dbName.length; k++) {
			TableHeaderCell header = new TableHeaderCell();
			header.setDbName((String)dbName[k]);
			header.setRightJustify(StatusSchedulingUtility
					.getRightJustificationInfo("ListDetails", dbName[k]));
			header.setUiName(StatusSchedulingUtility.getUIName("ListDetails",
					dbName[k]));
			header.setSortInfo(StatusSchedulingUtility.getSortInfo(
					"ListDetails", dbName[k]));
			header.setFilterInfo(StatusSchedulingUtility.getFilterInfo(
					"ListDetails", dbName[k]));
			objectHeader.add(header);
		}
		listDetails.setTableHeaderRow((TableHeaderCell[]) objectHeader
				.toArray(new TableHeaderCell[0]));

		// setting data row.
		ArrayList object = new ArrayList();
		for (int i = 1; i < al.size(); i++) {
			TableRow tableRow = new TableRow();
			Object[] cellValues = (Object[]) al.get(i);
			ArrayList cellArrayList = new ArrayList();
			for (int z = 0; z < cellValues.length; z++) {
				TableCell tableCell = new TableCell();
				
				if(cellValues[z] != null)
					tableCell.setCellValue(cellValues[z]);
				else if(cellValues[z] == null)
					tableCell.setCellValue("");
				if(z!=6) {
				//tableCell.setCellValue(cellValues[z]);
				tableCell.setDataType(StatusSchedulingUtility.getDataType(
						"ListDetails", dbName[z]));
				tableCell.setRightJustify(StatusSchedulingUtility
						.getRightJustificationInfo("ListDetails", dbName[z]));
				tableCell.setWrapInfo(StatusSchedulingUtility.getColWrapInfo(
						"ListDetails", dbName[z]));
				}
				cellArrayList.add(tableCell);
			}
			tableRow.setTableCell((TableCell[]) cellArrayList
					.toArray(new TableCell[0]));
			object.add(tableRow);
		}
		listDetails.setTableRows((TableRow[]) object
				.toArray(new TableRow[0]));
		return listDetails;
	}
}