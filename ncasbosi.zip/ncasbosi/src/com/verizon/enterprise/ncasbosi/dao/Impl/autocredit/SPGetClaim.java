package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * Author:Ram/v992473
 * 
 */


public class SPGetClaim extends BaseStoredProcedure {
	
	private static final Logger _LOGGER = Logger.getLogger(SPGetClaim.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"CLAIM_DETAIL", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new GetClaimMapper()});
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	 }
	
	public SPGetClaim(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_GET_VZB_CLAIM, spInOutList);
	}
	
	public Map executeStoredProcedure(Object pClaimNumber)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		String claimNumber = (String)pClaimNumber;
		_LOGGER.info("claim Number::"+claimNumber);
		List inputList = new ArrayList();
		inputList.add(new BigDecimal(claimNumber));//ESG_CLAIM_NUMBER
		Map resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
