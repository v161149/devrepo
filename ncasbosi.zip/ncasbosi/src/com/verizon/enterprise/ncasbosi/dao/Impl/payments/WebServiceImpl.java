package com.verizon.enterprise.ncasbosi.dao.Impl.payments;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.StringWriter;
import org.apache.log4j.Logger;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.DecimalFormat;

import com.verizon.enterprise.ncasbosi.dao.Interface.payments.EpaymentsInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.VisionInterface;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.VisionPaymentsStatusInfo.PaymentStatus;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.VisionPaymentsStatusInfo.PaymentStatusInfo;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.VisionPaymentsStatusInfo.PaymentStatusInfoServiceLocator;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.VisionPaymentsStatusInfo.PaymentStatusInfoSoapBindingStub;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.VisionPaymentsStatusInfo.PaymentStatusReturn;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.*;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.gcp.GCPaymentBean;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.gcp.GCPaymentBeanPortBindingStub;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.gcp.GCPaymentBeanServiceLocator;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.gcp.GcpInvoice;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.gcp.PaymentResult;
import com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.paymentBeanPortBinding.*;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.common.ncas.exception.InvalidPaymentException;
import com.verizon.enterprise.common.ncas.exception.PaymentException;
import com.verizon.enterprise.common.ncas.payments.GlobalPay;
import com.verizon.enterprise.common.ncas.payments.GlobalSub;
import com.verizon.enterprise.common.ncas.payments.PayRef;
import com.verizon.enterprise.common.ncas.payments.PaymentDetails;
import com.verizon.enterprise.common.ncas.payments.RecurPayment;
import com.verizon.enterprise.common.ncas.payments.Pay;
import com.verizon.enterprise.common.ncas.payments.PaymentProfile;
import com.verizon.enterprise.common.ncas.payments.PaymentResponse;
import com.verizon.kernel.xml.XmlParse;
import com.verizon.enterprise.common.ncas.NcasConstants;

//import com.verizon.enterprise.eBOSI.middleware.common.BOSIUtil;
import org.exolab.castor.xml.Marshaller;
import org.apache.xerces.dom.DocumentImpl;
import org.w3c.dom.Document;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;

public class WebServiceImpl implements EpaymentsInterface, VisionInterface, NCASBOSIConstants
{
	private final Logger _LOGGER = Logger.getLogger(WebServiceImpl.class);

	public PaymentResponse managePaymentProfile(PaymentProfile profile)throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "managePaymentProfile => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		CreditCardBean creditCardBean = null;
		PaymentResponse paymentResponseObject = null;
		PaymentResults paymentResult = null;
		AccountsResponse accountResponseReturnObject = null;
		String default_address = "";
		try
		{
			String paymentType = profile.getPaymentType();

			if(paymentType.equals(CREDIT_CARD_PAYMENT_TYPE))
			{
				//default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.CREDITCARD_WS_URL);
				default_address = SystemParamConfig.getProperty("CREDITCARD_WS_URL");
				if (default_address != null)
					default_address = default_address.trim();
				_LOGGER.info("authorizeCreditCard WS URL from DB ==>"+default_address);
				creditCardBean = getCreditCardWebserviceObject(default_address);
				_LOGGER.info("Before Calling authorizeCreditCard WS in managePaymentProfile");
				accountResponseReturnObject = creditCardBean.authorizeCreditCard(setCreditCardInfo(profile));
				_LOGGER.info("updatePayProfile:::Exiting");
				paymentResponseObject =  setPaymentResponse(accountResponseReturnObject);
			}
			else if(paymentType.equals(BANK_EFT_PAYMENT_TYPE) || (paymentType.equals(INTL_PAYMENT_TYPE)))
			{
				//default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.PAYMENT_WS_URL);
				default_address = SystemParamConfig.getProperty("PAYMENT_WS_URL");
				if (default_address != null)
					default_address = default_address.trim();
				_LOGGER.info("bankAccount WS URL from DB ==>"+default_address);
				MakeCCEFTPayment makeCCEFTPayment = getPaymentWebserviceObject(default_address);
				_LOGGER.info("Before Calling bankAccount WS in managePaymentProfile");
				paymentResult = makeCCEFTPayment.makePayment(paymentInput(profile,"encryptBankAccount"));
				paymentResponseObject = setPaymentResponse(paymentResult,-1);

			}
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex){
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_PROFILE,errMsg,ex);
		}
		_LOGGER.info("managePaymentProfile:::Exiting");
		return paymentResponseObject;
	}

	public PaymentResponse managePayment(Pay payment, PaymentProfile profile, String paymentType)throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "managePayment => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		PaymentResults paymentResult = null;
		PaymentResponse paymentResponse = null;
		String default_address = "";

		try
		{
			//default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.PAYMENT_WS_URL);
			default_address = SystemParamConfig.getProperty("PAYMENT_WS_URL");
			if (default_address != null)
				default_address = default_address.trim();
			_LOGGER.info("makePayment WS URL from DB ==>"+default_address);
			MakeCCEFTPayment makeCCEFTPayment = getPaymentWebserviceObject(default_address);
			_LOGGER.info("Before Calling makePayment WS in addPayment");
			paymentResult = makeCCEFTPayment.makePayment(paymentInput(payment, profile,paymentType));
			paymentResponse = setPaymentResponse(paymentResult,payment.getPaymentID());
		}
		catch(PaymentException ex){
				throw ex;
		}
		catch(Exception ex){
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_PAY,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return paymentResponse;
	}

	public PaymentResponse manageGCPPayment(GlobalPay payment, PaymentProfile profile,List<PayRef> payRefList)throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "manageGCPPayment => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		PaymentResult paymentResult = null;
		PaymentResponse paymentResponse = null;
		String default_address = "";

		try
		{
			//default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.GCP_PAYMENT_WS_URL);
			default_address = SystemParamConfig.getProperty("GCP_PAYMENT_WS_URL");
			if (default_address != null)
				default_address = default_address.trim();
			_LOGGER.info("manageGCPPayment WS URL ==>"+default_address);
			GCPaymentBean gcpPaymentBean = getGCPaymentBean(default_address);
			_LOGGER.info("Before Calling manageGCPPayment WS");

			int size = payment.getSubs().size();
			GcpInvoice[] invoices = new GcpInvoice[size+1];
			GlobalSub sub = null;
			GcpInvoice invoice = null;
			int index = 0;
			_LOGGER.info("************************************************************");
			_LOGGER.info(METHOD_NAME + "INPUTS ::");

			String shortPayTxt = " ";

			for (Iterator it = payment.getSubs().entrySet().iterator(); it.hasNext();) {
				Map.Entry mapEntry = (Map.Entry) it.next();
				sub = (GlobalSub)mapEntry.getValue();
				invoice = new GcpInvoice();


				if((sub.getOrigSystemID()).equals("VW") || sub.getOrigSystemID().equals("M1") || sub.getOrigSystemID().equals("M2"))
					invoice.setAccountNumber(sub.getServiceID());
				else invoice.setAccountNumber(sub.getCustAcctNum());

				invoice.setInvoiceDate(CommonUtil.getDisplayDateFromString(CommonUtil.getDateFromString(sub.getInvoiceDate())));

				if(sub.getInvoiceNum().isEmpty())
					sub.setInvoiceNum("  ");
				invoice.setInvoiceNumber(sub.getInvoiceNum());
				if(sub.getOpco().isEmpty())
					sub.setOpco("  ");
				invoice.setOpco(sub.getOpco());
				if(sub.getLegalEntity().isEmpty())
					sub.setLegalEntity("  ");
				invoice.setLegalEntity(sub.getLegalEntity());
				if(sub.getNsapAccount().isEmpty())
					sub.setNsapAccount("  ");
				invoice.setNsapAccount(sub.getNsapAccount());
				if(sub.getBillingName().isEmpty())
					sub.setBillingName("  ");
				invoice.setCustomerName(sub.getBillingName());


				invoice.setOsid(sub.getOrigSystemID());
				BigDecimal pmntAmnt = new BigDecimal(sub.getPaymentAmnt());
				BigDecimal exchangeRt = new BigDecimal(sub.getExchangeRate());

				NumberFormat nf = new DecimalFormat("###0.00");
				invoice.setPaymentAmount(new BigDecimal(String.valueOf(nf.format(pmntAmnt))));
				invoice.setAmountDue(new BigDecimal("0.00"));//DEFAULT NOT USED
				BigDecimal amntDue = new BigDecimal(sub.getInvAmtDue());
				invoice.setTotalAmountBilledCurrency(new BigDecimal(String.valueOf(nf.format(amntDue))));
				BigDecimal pmntAmntBilledCur = pmntAmnt.multiply(exchangeRt);
				pmntAmntBilledCur = pmntAmntBilledCur.setScale(2, BigDecimal.ROUND_HALF_UP);
				_LOGGER.info("pmntAmntBilledCur::"+pmntAmntBilledCur);
				invoice.setPaymentAmountBilledCurrency(pmntAmntBilledCur);


				invoice.setArPostDate("");
				shortPayTxt = getTypeText(payRefList,sub.getShortPayCode());
				invoice.setArComment(shortPayTxt);
				if(sub.getShortPayCode().isEmpty())
					sub.setShortPayCode("  ");
				invoice.setCommentCode(sub.getShortPayCode());

		  	    invoice.setBillCurrency(sub.getInvCurrencyCD());
				invoice.setPaymentCurrency(profile.getPmntCurrency());
				_LOGGER.info("PaymentCurrency::"+profile.getPmntCurrency());
				nf = new DecimalFormat("###0.000000");
				invoice.setExchangeRate(new BigDecimal(String.valueOf(nf.format(exchangeRt))));
				_LOGGER.info("invoice :"+index+"  -->" + invoice);
				invoices[index++] = invoice;
			}

			_LOGGER.info("GCP Payment::"+payment.toString());
			_LOGGER.info("Pay Profile used::"+profile.toString());
			_LOGGER.info("************************************************************");


			paymentResult = gcpPaymentBean.makePayment(payment.getLoginId(),payment.getCustAcctNum(),profile.getName(),
								profile.getSafeKey(),"VEC", payment.getProfileEmailAddr(),
								profile.getPmntCountry(), profile.getPmntCurrency(), payment.getPaymentAmnt(),profile.getMandate(),
								profile.getBankName(),profile.getAddress(),profile.getAddress2(),profile.getCity(),
								profile.getState(),profile.getCountry(),profile.getZip()," ",
								invoices )	;
			paymentResponse = setPaymentResponse(paymentResult,payment.getPaymentID());
		}
		catch(PaymentException ex){
				throw ex;
		}
		catch(Exception ex){
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_PAY,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return paymentResponse;
	}

	private String getTypeText(List<PayRef>payRefList, String typeCode)
	{
		if(payRefList==null)
		return " ";

		Iterator<PayRef> it = payRefList.iterator();
		PayRef item = null;
		while (it.hasNext()) {
			item = it.next();
			if(item.getCode().equalsIgnoreCase(typeCode))
			{
				return item.getText();
			}
		}

		return " ";
	}

	public List getPaymentHistory(String accountNumber, String startDate, String endDate) throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "getPaymentHistory => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		PaymentStatusInfo paymentStatusInfo = null;
		PaymentStatus paymentStatus = null;
		String default_address = "";
		ArrayList<PaymentStatusReturn> statusList = new ArrayList<PaymentStatusReturn>();
		try
		{
			//default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.PAYMENT_HISTORY_URL);
			default_address = SystemParamConfig.getProperty("PAYMENT_HISTORY_URL");
			if (default_address != null)
				default_address = default_address.trim();
			_LOGGER.info("\n\n getPaymentHistory URL from DB --> "+default_address);

			paymentStatusInfo = getPaymentStatusInfoObject(default_address);

			_LOGGER.info("\n\n Input's For getPaymentHistory WS ********************\n");
			_LOGGER.info("AccountNumber --> "+accountNumber);
			_LOGGER.info("StartDate --> "+startDate);
			_LOGGER.info("EndDate --> "+endDate);
			_LOGGER.info("\n\n *********************************************************");

			_LOGGER.info("Before Calling Payments WS");

			paymentStatus = paymentStatusInfo.getPaymentStatusReturn(accountNumber, startDate, endDate);

			_LOGGER.info("\n\n output of getPaymentHistory WS ********************");

			_LOGGER.info("ErrorCode -->"+paymentStatus.getErrorCode());
			_LOGGER.info("StatusCode -->"+paymentStatus.getStatusCode());
			_LOGGER.info("PaymentStatusReturn  -->"+paymentStatus.getPaymentStatusReturn());

			_LOGGER.info("\n\n ******************************************************");
			handleVZWResponse(paymentStatus.getErrorCode(),paymentStatus.getStatusCode(),METHOD_NAME);
			PaymentStatusReturn[] paymentStatRet =paymentStatus.getPaymentStatusReturn();
			if(paymentStatRet!=null && paymentStatRet.length> 0){
				for(int i=0;i<paymentStatRet.length;i++)
				{
					statusList.add(paymentStatRet[i]);
				}
			}

		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex){
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(VISION_PAY_HISTORY,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return statusList;
	}


	public Double getWirelessRealTimeBalance(String accountNumber) throws PaymentException
	{
		final String METHOD_NAME = "getWirelessRealTimeBalance => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		PaymentInput paymentInputObject = new PaymentInput() ;
		paymentInputObject.setWhatTodo("visionRealTime");
		paymentInputObject.setBan(accountNumber);
		paymentInputObject.setOsid("VW");
		String default_address = "";
		PaymentResults paymentResult = null;
		Double retValue = 0.00;
		try{
			//default_address = NCASBOSIConfig.getProperty(NCASBOSIConstants.PAYMENT_WS_URL);
			default_address = SystemParamConfig.getProperty("PAYMENT_WS_URL");
			if (default_address != null)
				default_address = default_address.trim();
			_LOGGER.info("\n\n getWirelessRealTimeBalance URL --> " + default_address);
			MakeCCEFTPayment makeCCEFTPayment = getPaymentWebserviceObject(default_address);
			_LOGGER.info("Before Calling makePayment WS in getWirelessRealTimeBalance");
			paymentResult = makeCCEFTPayment.makePayment(paymentInputObject);
			_LOGGER.info("After Calling makePayment WS in getWirelessRealTimeBalance");
			if(paymentResult!=null)
			{
				_LOGGER.info("Payment Result::"+paymentResult.toString());
				if(paymentResult.getReturnCode().equals("00"))
				{
					retValue = Double.parseDouble(paymentResult.getRealTimeBalance());
					_LOGGER.info("\n\n\n realtimebalance for accountNumber::"+accountNumber+"-->"+retValue);
				}else{
					throw new Exception("Return Code::"+paymentResult.getReturnCode()+"::ReturnText::"+paymentResult.getReturnText()+"::");
				}
			}else{
				throw new Exception("Got an empty result back from ePay");
			}
		}
	    catch (Exception ex)
	    {
	    	String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = "Unable to retrieve realtimebalance:"+ex.getMessage();
		    throw new PaymentException(VISION_RT_BALANCE,errMsg,ex);
		}
		_LOGGER.info("getWirelessRealTimeBalance:::Exiting");
		return retValue;
	}






	public CreditCardBean getCreditCardWebserviceObject(String default_address)throws PaymentException
	{
		final String METHOD_NAME = "getCreditCardWebserviceObject => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try{
			CreditCardBeanServiceLocator creditCardBeanLocator = new CreditCardBeanServiceLocator();
			CreditCardBean creditCardBean = new CreditCardBeanPortBindingStub();
			creditCardBeanLocator.setCreditCardBeanPortEndpointAddress(default_address);
			creditCardBean = creditCardBeanLocator.getCreditCardBeanPort();
			_LOGGER.info(METHOD_NAME+" Exiting");
			return creditCardBean;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_CONNECT,errMsg,ex);
		}
	}

	public MakeCCEFTPayment getPaymentWebserviceObject(String default_address)throws PaymentException
	{
		final String METHOD_NAME = "getPaymentWebserviceObject => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		try{
			MakeCCEFTPaymentServiceLocator cceftPaymentServiceLocator = new MakeCCEFTPaymentServiceLocator();
			MakeCCEFTPayment cceftPayment = new MakeCCEFTPaymentSoapBindingStub();
			cceftPaymentServiceLocator.setMakeCCEFTPaymentEndpointAddress(default_address);
			cceftPayment = cceftPaymentServiceLocator.getMakeCCEFTPayment();
			_LOGGER.info(METHOD_NAME+" Exiting");
			return cceftPayment;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_CONNECT,errMsg,ex);
		}
	}

	public GCPaymentBean getGCPaymentBean(String default_address)throws PaymentException
	{
		final String METHOD_NAME = "getGCPaymentBean => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		try{
			GCPaymentBeanServiceLocator gcpPaymentServiceLocator = new GCPaymentBeanServiceLocator();
			GCPaymentBean gcpPayment = new GCPaymentBeanPortBindingStub();
			gcpPaymentServiceLocator.setGCPaymentBeanPortEndpointAddress(default_address);
			gcpPayment = gcpPaymentServiceLocator.getGCPaymentBeanPort();
			_LOGGER.info(METHOD_NAME+" Exiting");
			return gcpPayment;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_CONNECT,errMsg,ex);
		}
	}


	public PaymentStatusInfo getPaymentStatusInfoObject(String default_address)throws PaymentException
	{
		final String METHOD_NAME = "getPaymentStatusInfoObject => ";
		_LOGGER.info(METHOD_NAME+" ::: Entering");
		try
		{
			PaymentStatusInfoServiceLocator paymentStatusInfoLocator = new PaymentStatusInfoServiceLocator();
			PaymentStatusInfo paymentStatusBean = new PaymentStatusInfoSoapBindingStub();
			paymentStatusInfoLocator.setPaymentStatusInfoEndpointAddress(default_address);
			paymentStatusBean = paymentStatusInfoLocator.getPaymentStatusInfo();
			_LOGGER.info(METHOD_NAME+" Exiting");
			return paymentStatusBean;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[3];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = default_address;
		    errMsg[2] = ex.getMessage();
		    throw new PaymentException(EPAYMENT_ERROR_CONNECT,errMsg,ex);
		}
	}

	public com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard setCreditCardInfo(PaymentProfile profile)throws PaymentException
	{
		final String METHOD_NAME = "setCreditCardInfo => ";
		try{
			_LOGGER.info("setCreditCardInfo profile :::Entering");
			com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard creditCardObject = null;

			_LOGGER.info("***** setCreditCardInfo PaymentProfile Obj Values from UI **********");

            _LOGGER.debug("RealAccountNumber -->"+profile.getRealAccountNumber());
            _LOGGER.debug("CVVAcctDigits -->"+profile.getCVVAcctDigits());
            _LOGGER.info("RealAccountNumber -->**********************");
            _LOGGER.info("CVVAcctDigits -->********");

			_LOGGER.info("TypeDescription -->"+profile.getTypeCode());
			_LOGGER.info("Name -->"+profile.getName());
			_LOGGER.info("ExpDateMM -->"+profile.getExpDateMM());
			_LOGGER.info("ExpDateYY -->"+profile.getExpDateYY());

			_LOGGER.info("************************************************************");

			creditCardObject = new com.verizon.enterprise.ncasbosi.webservice.payments.clientgen.creditCardBeanService.CreditCard();
			creditCardObject.setCardNumber(CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
	//		_LOGGER.info("Credit Card Decoded number -->"+CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
			creditCardObject.setCvvDigits(CommonUtil.decode(profile.getCVVAcctDigits().toCharArray()));
			creditCardObject.setCardType(profile.getTypeCode());
			creditCardObject.setNameOnCard(profile.getName());
			creditCardObject.setExperationMonth(Integer.parseInt(profile.getExpDateMM()));
			creditCardObject.setExperationYear(Integer.parseInt(profile.getExpDateYY()));
			creditCardObject.setZip(profile.getZip());

			_LOGGER.info("setCreditCardInfo profile :::Exiting");
			return creditCardObject;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);
		}

	}



	public PaymentInput paymentInput(Pay payment, PaymentProfile profile,String paymentType)throws PaymentException
	{
		final String METHOD_NAME = "paymentInput => ";
		try
		{
			_LOGGER.info("paymentInput :::Entering");
			PaymentInput paymentInputObject = new PaymentInput() ;
			_LOGGER.info("PaymentProfile Object Values -->"+profile.toString());
			if(paymentType.equals(NcasConstants.PAYMENT_TYPE_ONETIME))
				_LOGGER.info("PaymentDetails Object Values -->"+((PaymentDetails)payment).toString());
			else if(paymentType.equals(NcasConstants.PAYMENT_TYPE_RECURRING))
				_LOGGER.info("RecurPayment Object Values -->"+((RecurPayment)payment).toString());

			String whatToDoField = "";
			NumberFormat nf = new DecimalFormat("###0.00");
			paymentInputObject.setAlias(profile.getNickName());
			paymentInputObject.setBan(payment.getCustAcctNum());
			paymentInputObject.setBanDan(payment.getServiceID());
			paymentInputObject.setCustomerName(profile.getName());
			if((payment.getOrigSystemID()).equals("VW"))
			{
				paymentInputObject.setBan(payment.getServiceID());
				if(paymentType.equals(NcasConstants.PAYMENT_TYPE_RECURRING))
				{
					paymentInputObject.setAmountDue("");
					paymentInputObject.setInvoiceDate("01/01/2001");
					paymentInputObject.setInvoiceNumber("");
					paymentInputObject.setSettleDays(String.valueOf(((RecurPayment)payment).getSettleDay()));
					paymentInputObject.setAmount("1.00");
					whatToDoField = setWhatToDoField(((RecurPayment)payment).getUpdateType(), profile.getPaymentType(), paymentType);
				}
				else if(paymentType.equals(NcasConstants.PAYMENT_TYPE_ONETIME))
				{
					BigDecimal bd = new BigDecimal(((PaymentDetails)payment).getInvAmtDue());
					//NumberFormat nf = new DecimalFormat("###0.00");
					paymentInputObject.setAmountDue(String.valueOf(nf.format(bd)));
					_LOGGER.info("InvoiceDate VZW -->"+CommonUtil.getDisplayDateFromString(CommonUtil.getDateFromString(((PaymentDetails)payment).getInvoiceDate())));
					paymentInputObject.setInvoiceDate(CommonUtil.getDisplayDateFromString(CommonUtil.getDateFromString(((PaymentDetails)payment).getInvoiceDate())));
					paymentInputObject.setInvoiceNumber(((PaymentDetails)payment).getInvoiceNum());
					//paymentInputObject.setAmount(String.valueOf(((PaymentDetails)payment).getPaymentAmnt()));
					//Change made to stick to the format prescribed xx.xx on 06/08/2012
					BigDecimal amtBd = new BigDecimal(((PaymentDetails)payment).getPaymentAmnt());
					paymentInputObject.setAmount(String.valueOf(nf.format(amtBd)));
					
					_LOGGER.info(METHOD_NAME+ "Service ID:"+payment.getServiceID()+":: CUST REF CODE ::"+payment.getCustRefCode());
					paymentInputObject.setCustomerCode(payment.getCustRefCode());
					paymentInputObject.setSettleDays("0");
					whatToDoField = setWhatToDoField("", profile.getPaymentType(), paymentType);
				}
				_LOGGER.info("Got whatToDoField VZW --> "+whatToDoField);
				paymentInputObject.setWhatTodo(whatToDoField);
			}
			else
			{
				if((payment.getOrigSystemID()).equals("M1") || (payment.getOrigSystemID()).equals("M2"))
					paymentInputObject.setBan(payment.getServiceID());
				if(paymentType.equals(NcasConstants.PAYMENT_TYPE_ONETIME))
				{
					BigDecimal bd = new BigDecimal(((PaymentDetails)payment).getInvAmtDue());
					//NumberFormat nf = new DecimalFormat("###0.00");
					paymentInputObject.setAmountDue(String.valueOf(nf.format(bd)));
					_LOGGER.info("InvoiceDate Non VZW -->"+CommonUtil.getDisplayDateFromString(CommonUtil.getDateFromString(((PaymentDetails)payment).getInvoiceDate())));
					paymentInputObject.setInvoiceDate(CommonUtil.getDisplayDateFromString(CommonUtil.getDateFromString(((PaymentDetails)payment).getInvoiceDate())));
					paymentInputObject.setInvoiceNumber(((PaymentDetails)payment).getInvoiceNum());
					//paymentInputObject.setAmount(String.valueOf(((PaymentDetails)payment).getPaymentAmnt()));
					//Change made to stick to the format prescribed xx.xx on 06/08/2012
					BigDecimal amtBd = new BigDecimal(((PaymentDetails)payment).getPaymentAmnt());
					paymentInputObject.setAmount(String.valueOf(nf.format(amtBd)));
				}
				_LOGGER.info("whatToDoField field would be VZB for non VZW");
				paymentInputObject.setWhatTodo("VZB");
				paymentInputObject.setSettleDays("0");
			}
			if(profile.getPaymentType().equals(CREDIT_CARD_PAYMENT_TYPE))
			{
				paymentInputObject.setCardType(profile.getTypeCode());
				paymentInputObject.setCreditCardNumber(profile.getSafeKey());
				paymentInputObject.setExpMonth(profile.getExpDateMM());
				paymentInputObject.setExpYear(profile.getExpDateYY());
				paymentInputObject.setExpDate(profile.getExpDateMM()+"/"+profile.getExpDateYY());
				paymentInputObject.setBankAccountNumber("");
			}
			else
			{
				paymentInputObject.setBankAccountNumber(profile.getSafeKey());
				paymentInputObject.setCreditCardNumber("");
				paymentInputObject.setCardType("");
				paymentInputObject.setExpDate("");
				paymentInputObject.setExpMonth("");
				paymentInputObject.setExpYear("");
			}
			String osId = payment.getOrigSystemID();
			String merchantId = payment.getMerchantID().trim();
			if(merchantId.length()>0)
			osId = osId+" "+merchantId;
			paymentInputObject.setOsid(osId);
			String stateCode = payment.getStateCode();
			if ((stateCode == null) || (stateCode.trim().length() == 0))
			{
				stateCode = "  ";
			}
			paymentInputObject.setStateCode(stateCode);
			paymentInputObject.setRoutingNumber(profile.getRoutingNumber());
			paymentInputObject.setSystemID(profile.getPortalLoginID());
			paymentInputObject.setUserid(payment.getLoginId());
			paymentInputObject.setZipCode(profile.getZip());
			paymentInputObject.setUspo(payment.getOpCode());
			_LOGGER.info(METHOD_NAME+"::payment type:"+profile.getPaymentType()+"::vzbvzw flag:"+payment.getVzbVzwFlag()+"::pmnt currency:"+payment.getPmntCurrency());
			if((profile.getPaymentType().trim().equalsIgnoreCase(CREDIT_CARD_PAYMENT_TYPE)) && (payment.getVzbVzwFlag().trim().equalsIgnoreCase(VZB_VZW_FLAG_VZB)) && (payment.getPmntCurrency().trim().equalsIgnoreCase("USD"))){
				Lv2Lv3Handler lv2Lv3Handler=new Lv2Lv3Handler(payment, profile);
				String level_2_3=lv2Lv3Handler.getLevel_2_3();
				paymentInputObject.setLevel_2_3(level_2_3);
			}
			_LOGGER.info(METHOD_NAME+ "stateCode:"+ paymentInputObject.getStateCode() + ", stateCode length=" + paymentInputObject.getStateCode().length());

			//Document handler = BOSIUtil.createDOMDocument();
			Document handler = new DocumentImpl();
			Marshaller marshaller = new Marshaller(handler);
			marshaller.marshal(paymentInputObject);
			//String resultXmlPaymentInputObject = BOSIUtil.getXMLString(handler);
			_LOGGER.info(METHOD_NAME+ " EPAY - PARAMS :" + getXMLString(handler));
			_LOGGER.info("paymentInput :::Exiting");

			return paymentInputObject;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);
		}
	}
	
	protected String getXMLString(Document doc) throws Exception
	{
		final String METHOD_NAME = "getXMLString()::";
		// converts a given DOM document to xml string
		try
		{
			OutputFormat format = new OutputFormat(doc);    // Serialize DOM
	        StringWriter stringOut = new StringWriter();    // Writer will be a String
	        XMLSerializer serial = new XMLSerializer(stringOut, format);
	        serial.asDOMSerializer();                       // As a DOM Serializer
	        serial.serialize(doc.getDocumentElement());
	            
	        return stringOut.toString(); // return DOM as a string
	    }
	    catch(Exception ex)
	    {
	    	_LOGGER.info(METHOD_NAME + " Exception::" + ex);
	    	throw ex;
	    }
	}



// For encryptBankAccount we are using the same WS call as makePayment with different whattodo field

	public PaymentInput paymentInput(PaymentProfile profile,String paymentType)throws PaymentException
	{
		final String METHOD_NAME = "paymentInput for encryptBankAccount => ";
		_LOGGER.info("paymentInput for encryptBankAccount :::Entering");
		try
		{
			PaymentInput paymentInputObject = new PaymentInput() ;

			_LOGGER.info("***** paymentInput Params from UI PaymentProfile Obj for encryptBankAccount  **********");

			_LOGGER.info("PaymentType -->"+paymentType);

            _LOGGER.debug("RealAccountNumber -->"+profile.getRealAccountNumber());
            _LOGGER.debug("RoutingNumber -->"+profile.getRoutingNumber());
            _LOGGER.info("RealAccountNumber -->************************");
            _LOGGER.info("RoutingNumber -->**********************");

			_LOGGER.info("************************************************************");

			paymentInputObject.setBankAccountNumber(CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
			_LOGGER.debug("RealAccountNumber decoded one -->"+CommonUtil.decode(profile.getRealAccountNumber().toCharArray()));
			paymentInputObject.setRoutingNumber(profile.getRoutingNumber());
			paymentInputObject.setWhatTodo(paymentType);
			_LOGGER.info("paymentInput for encryptBankAccount  :::Exiting");
			return paymentInputObject;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);
		}

	}

	public PaymentResponse setPaymentResponse(AccountsResponse accountResponseReturnObject)throws InvalidPaymentException, PaymentException
	{
		final String METHOD_NAME = "setPaymentResponse => ";
		try{

			_LOGGER.info("After Calling authorizeCreditCard WS");
			_LOGGER.info("setPaymentResponse AccountsResponse :::Entering");

			_LOGGER.info("\n *****output from WS for authorizeCreditCard  ********* \n");
			_LOGGER.info("Approval_code -->"+accountResponseReturnObject.getApproval_code());
			_LOGGER.info("Avs_check -->"+accountResponseReturnObject.getAvs_check());
			_LOGGER.info("Response_code -->"+accountResponseReturnObject.getResponse_code());
			_LOGGER.info("Response_text -->"+accountResponseReturnObject.getResponse_text());
			_LOGGER.info("Tracking_id -->"+accountResponseReturnObject.getTracking_id());
			_LOGGER.info("Seq_number -->"+accountResponseReturnObject.getSeq_number());
			_LOGGER.info("Order_number -->"+accountResponseReturnObject.getOrder_number());
			_LOGGER.info("SafeValue -->"+accountResponseReturnObject.getSafeValue());
			_LOGGER.info("\n *********************************************************** \n ");


			PaymentResponse paymentResponseObject = new PaymentResponse(accountResponseReturnObject.getTracking_id(), accountResponseReturnObject.getResponse_code(),accountResponseReturnObject.getResponse_text(), accountResponseReturnObject.getSafeValue());

			String response_code = accountResponseReturnObject.getResponse_code();
			String[] errMsg = new String[1];
		    errMsg[0] = METHOD_NAME;
			if(response_code!=null){
				if(response_code.equals("08")||response_code.equalsIgnoreCase("null"))
					throw new PaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);
				else if(!(response_code.equals("00")||response_code.equals("0")||response_code.equals("")))
					throw new InvalidPaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);
			}else throw new PaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);

			_LOGGER.info("setPaymentResponse AccountsResponse :::Exiting");
			return paymentResponseObject;
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_POST,errMsg,ex);
		}

	}

	private void handleVZWResponse(String response_code, String response_text,String methodName)throws InvalidPaymentException
	{
		String[] errMsg = new String[1];
	    errMsg[0] = methodName;
	    if(response_code==null || (response_code!=null && !(response_code.equals("00")||response_code.equals("0")||response_code.equals(""))))
			throw new InvalidPaymentException(BILLING_EPAY_POST,errMsg,null,"WL",response_code+"::"+response_text);

	}


	public PaymentResponse setPaymentResponse(PaymentResults paymentResult,int paymentID)throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "setPaymentResponse => ";
		try{
			_LOGGER.info("setPaymentResponse paymentResult :::Entering");

			_LOGGER.info("\n output from WS for makePayment WS ******************** \n");
			_LOGGER.info("ReturnCode -->"+paymentResult.getReturnCode());
			_LOGGER.info("ReturnText -->"+paymentResult.getReturnText());
			_LOGGER.info("TrackingID -->"+paymentResult.getTrackingID());
			_LOGGER.info("SafeValue -->"+paymentResult.getSafeValue());
			_LOGGER.info("CICSReturnText -->"+paymentResult.getCICSReturnText());
			_LOGGER.info("StatusCode -->"+paymentResult.getStatusCode());
			_LOGGER.info("StatusIndicators -->"+paymentResult.getStatusIndicators());
			_LOGGER.info("\n ****************************************************** \n");



			String[] errMsg = new String[1];
		    errMsg[0] = METHOD_NAME;
			String response_code = paymentResult.getReturnCode();
			String response_text = paymentResult.getReturnText();
			String status_code = paymentResult.getStatusCode();
			String cics_text = paymentResult.getCICSReturnText();

			String status_ind = paymentResult.getStatusIndicators();
			String epRefundFlag="";
			String epUfundFlag="";
			String epEnrollFlag="";
			String epDeEnrollFlag="";
			String epObPpFlag="";
			String epvalidateObPpFlag="";
			if(status_code==null)
				status_code = "";


			if(cics_text==null)
				cics_text = "";

			if(status_ind!=null&&!status_ind.isEmpty()){
				try{
					int status = Integer.parseInt(status_ind);
					epObPpFlag = (status & 1)==1?"Y":"N";
					epvalidateObPpFlag = (status & 2)==2?"Y":"N";
					epDeEnrollFlag = 	(status & 4)==4?"Y":"N";
					epRefundFlag = (status & 8)==8?"Y":"N";
					epUfundFlag = (status & 16)==16?"Y":"N";
					epEnrollFlag = (status & 32)==32?"Y":"N";

					if(epObPpFlag.equals("N")||epvalidateObPpFlag.equals("N"))
						epObPpFlag = "N";
				}
				catch(Exception e)
				{
					_LOGGER.info(METHOD_NAME + "  error exception " + e);
				}
			}


			PaymentResponse paymentResponseObject = new PaymentResponse(paymentResult.getTrackingID(),paymentResult.getReturnCode(),paymentResult.getReturnText()
					,paymentResult.getSafeValue(),"",	paymentResult.getStatusCode(),	paymentResult.getCICSReturnText(),	epObPpFlag, epRefundFlag,epUfundFlag, epDeEnrollFlag, epEnrollFlag) ;

			if(response_code!=null){
				if(response_code.equals("08")||response_code.equalsIgnoreCase("null"))
					throw new PaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);
				else if(!(response_code.equals("00")||response_code.equals("0")||response_code.equals(""))||(status_code!= null && status_code.equals("99")))
					throw new InvalidPaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);
			}else 	throw new PaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);


			_LOGGER.info("setPaymentResponse paymentResult :::Exiting");
			return paymentResponseObject;
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_POST,errMsg,ex);
		}
	}


	public PaymentResponse setPaymentResponse(PaymentResult paymentResult,int paymentID)throws InvalidPaymentException,PaymentException
	{
		final String METHOD_NAME = "setPaymentResponse => ";
		try{
			_LOGGER.info("setPaymentResponse paymentResult :::Entering");

			_LOGGER.info("\n output from WS for makePayment WS ******************** \n");
			_LOGGER.info("ReturnCode -->"+paymentResult.getErrorCode());
			_LOGGER.info("ReturnText -->"+paymentResult.getErrorText());
			_LOGGER.info("TrackingID -->"+paymentResult.getGcpId());

			_LOGGER.info("\n ****************************************************** \n");



			String[] errMsg = new String[1];
		    errMsg[0] = METHOD_NAME;
			int response_code = paymentResult.getErrorCode();
			String response_text = paymentResult.getErrorText();

			if(response_text==null)
				response_text = "";
			PaymentResponse paymentResponseObject = new PaymentResponse();
			paymentResponseObject.setEpResponseCode(String.valueOf(response_code));
			paymentResponseObject.setEpResponseText(response_text);
			paymentResponseObject.setEpTrackID(paymentResult.getGcpId());


				if(response_code==8)
					throw new PaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);
				else if(response_code != 0)
					throw new InvalidPaymentException(BILLING_EPAY_POST,errMsg,null,paymentResponseObject);



			_LOGGER.info("setPaymentResponse paymentResult :::Exiting");
			return paymentResponseObject;
		}
		catch(PaymentException ex){
			throw ex;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_POST,errMsg,ex);
		}
	}


	public String setWhatToDoField(String whatToDo,String profileType, String paymentType)throws PaymentException
	{
		final String METHOD_NAME = "setWhatToDoField => ";
		// For Bank and Credit-Card Transactions
		_LOGGER.info(METHOD_NAME+" :::Entering");

		_LOGGER.info("whatToDo --> "+whatToDo);
		_LOGGER.info("profileType --> "+profileType);
		_LOGGER.info("paymentType --> "+paymentType);

		String whatToDoValue = "";
		try{
			if((whatToDo.equals("AC") || whatToDo.equals("BO")) && profileType.equals(BANK_EFT_PAYMENT_TYPE) )
			{
			   whatToDoValue = "upenrollBank";
			}
			else if(whatToDo.equals("SD") && profileType.equals(BANK_EFT_PAYMENT_TYPE) )
			{
			   whatToDoValue = "updateSettleCCBank";
			}
			else if(whatToDo.equals("CA") && profileType.equals(BANK_EFT_PAYMENT_TYPE) )
			{
			   whatToDoValue = "denrollCC";
			}
			else if(whatToDo.equals("") && profileType.equals(BANK_EFT_PAYMENT_TYPE) && paymentType.equals(NcasConstants.PAYMENT_TYPE_ONETIME) )
			{
			   whatToDoValue = "onetimeBank";
			}
			else if(whatToDo.equals("") && profileType.equals(BANK_EFT_PAYMENT_TYPE) )
			{
			   whatToDoValue = "enrollBank";
			}
			else if((whatToDo.equals("AC")  || whatToDo.equals("BO")) && profileType.equals(CREDIT_CARD_PAYMENT_TYPE) )
			{
			   whatToDoValue = "upenrollCC";
			}
			else if(whatToDo.equals("SD") && profileType.equals(CREDIT_CARD_PAYMENT_TYPE) )
			{
			   whatToDoValue = "updateSettleCCBank";
			}
			else if(whatToDo.equals("DT") && profileType.equals(CREDIT_CARD_PAYMENT_TYPE) )
			{
			   whatToDoValue = "creditCardUpdate";
			}
			else if(whatToDo.equals("CA") && profileType.equals(CREDIT_CARD_PAYMENT_TYPE) )
			{
			   whatToDoValue = "denrollCC";
			}
			else if(whatToDo.equals("") && paymentType.equals(NcasConstants.PAYMENT_TYPE_ONETIME)  && profileType.equals(CREDIT_CARD_PAYMENT_TYPE) )
			{
				whatToDoValue = "onetimeccpayment";
			}
			else if(whatToDo.equals("") && profileType.equals(CREDIT_CARD_PAYMENT_TYPE) )
			{
			   whatToDoValue = "enrollCC";
			}
			_LOGGER.info("Got whatToDoValue in setWhatToDoField()  --> "+whatToDoValue);
			_LOGGER.info(METHOD_NAME+" :::Exiting");
			return whatToDoValue;
		}
		catch(Exception ex)
		{
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
		    throw new PaymentException(BILLING_EPAY_PRE,errMsg,ex);
		}
	}

}
