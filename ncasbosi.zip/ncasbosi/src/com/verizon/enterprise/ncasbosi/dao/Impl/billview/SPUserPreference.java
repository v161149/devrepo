package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Integer;
import javax.sql.DataSource;
import org.apache.log4j.Logger;



import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.common.ncas.NcasConstants;


public class SPUserPreference extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPUserPreference.class);
	private static List spInOutList;
	private static GetUserPreferenceRowMapperImpl uPrefrowMapper1;
	private static GetUserPrefReportMapperImpl uPrefrowMapper2;

	public SPUserPreference(DataSource dataSource, String schemaName, String storedProcName)
	{
		super(dataSource, schemaName + "." + storedProcName, spInOutList);
	}
	static
	{
		 spInOutList = new ArrayList();
		 uPrefrowMapper1 = new GetUserPreferenceRowMapperImpl();
		 uPrefrowMapper2 = new GetUserPrefReportMapperImpl();

		 spInOutList.add(new Object[]{"userpreference",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,uPrefrowMapper1});
		 spInOutList.add(new Object[]{"userreporttext",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,uPrefrowMapper2});
		 spInOutList.add(new Object[]{"PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"REPORT_HEADER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"REPORT_TRAILER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"REPORT_COLUMNS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public Map executeStoredProcedure(String userId, String debugLevel, Map params) throws Exception
	{
		String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
		List paramValueList = new ArrayList();
		Map procMap = null;
		String reportCol = (String)params.get("REPORT_COLUMNS");
		if(reportCol == null) reportCol = "";
		String reportName = (String)params.get("REPORT_NAME");
		if(reportName == null) reportName = "";
		String reportHdr = (String)params.get("REPORT_HEADER");
		if(reportHdr == null) reportHdr = "";
		String reportFtr = (String)params.get("REPORT_TRAILER");
		if(reportFtr == null) reportFtr = "";
		String reportText = (String)params.get("REPORT_TEXT");
		if(reportText == null) reportText = "";
		String action = (String)params.get("ACTION");
		if(action == null) action = "";
		String lang = (String)params.get("LANG");
		if(lang==null||(lang!=null&&lang.trim().equals("")))
			lang=NcasConstants.LANG_CODE_US_ENGLISH_VAM;
		paramValueList.add((String)params.get("PAGE_ID"));//PAGE_ID
		paramValueList.add((String)params.get("USER_ID"));//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(action);//ACTION
		paramValueList.add(reportName);//REPORT_NAME
		paramValueList.add(reportHdr);//REPORT_HEADER
		paramValueList.add(reportFtr);//REPORT_TRAILER
		paramValueList.add(reportCol);//REPORT_COLUMNS
		paramValueList.add(reportText);//REPORT_TEXT

		paramValueList.add(lang);//LANGUAGE_CODE


		procMap = (HashMap)executeStoredProcedure(paramValueList);

		int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
		String debugStr = (String)procMap.get("MSG_STRING");
		if( returnCode > 0 ) {
		    String[] errMsg = new String[3];
		    errMsg[0] = "getUserPreference";
		    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_USER_PREF;
		    errMsg[2] = debugStr;

		    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
		}
		return procMap;

	}
	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}