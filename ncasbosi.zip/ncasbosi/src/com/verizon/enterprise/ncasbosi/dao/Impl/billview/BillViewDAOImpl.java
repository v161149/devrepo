package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowCallbackHandler;


import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.exception.ConnectionException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.SPErrorInfo;
import com.verizon.enterprise.ncasbosi.common.StoredProcConfig;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.billview.BillViewInterface;

public class BillViewDAOImpl  extends NCASSpringJDBCBase implements BillViewInterface , NCASBOSIConstants {

	private static final String USER_ID_CONFIG_READ_ERROR = "Errors in reading config : "
														+ VAM_USER_ID_CONFIG_PATH;
	static private final Logger _LOGGER = Logger.getLogger(BillViewDAOImpl.class);
	
	private static String logUsers = "";
	
	
	public  String getLogUsers() {
		if(logUsers==null|| logUsers!=null && logUsers.isEmpty()){
			try{
				logUsers=SystemParamConfig.getProperty("PERF.LOG");
			}
			catch(Exception ex){
				_LOGGER.info("EXCEPTION - BillViewDAOImpl::getLogUsers"+ex);
				logUsers = "";
			}
		}
			
		return logUsers;
	}
	
	public  void resetLogUsers() {
		BillViewDAOImpl.logUsers = "";
	}

	
	private String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(VAM_SCHEMA_NAME, " ");
		_LOGGER.debug("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	public Map getBillView(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::getBillView";

		String schemaName = getSchemaName();

		//Caching the osid-stored procedure names in a map. This cached map
		//gets refreshed every two hours.
		StoredProcConfig spConfig = StoredProcConfig.getInstance();
		String osidName = (String)params.get("OSID");
		String storedProcName = NCASBOSIConstants.SP_BILL_VIEW;
		_LOGGER.debug("Before calling spConfig.getOSIDStoredProcs") ;
		if(osidName != null)
		{
			storedProcName = spConfig.getOSIDStoredProcs(osidName, NCASBOSIConstants.SP_BILL_VIEW);
		}
		_LOGGER.debug("storedProcName : is -"+storedProcName) ;
		SPBillView getBillViewStoredProc = new SPBillView(getDataSource(),schemaName, storedProcName);
		Map retValue = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getBillView";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.debug("Before calling into getBillViewStoredProc.executeStoredProcedure") ;
			_LOGGER.info("***PERF LOG ***:Entering "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String startTime = NCASDataUtil.getCurrentTime();			
			retValue = getBillViewStoredProc.executeStoredProcedure(userID,debugLevel,params);
			_LOGGER.info("***PERF LOG ***:Exiting "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String endTime = NCASDataUtil.getCurrentTime();
			NCASDataUtil.logPerfMessageBosi(startTime,endTime,(String)params.get("PERF_KEY"),(String)params.get("PERF_PAGE"),METHOD_NAME,(String)params.get("LOGIND"),getLogUsers());

			_LOGGER.debug("getBillView responseMap -> " + retValue);
		} catch(NCASException ncasException) {
			_LOGGER.debug("getBillView in VAM Failed \n"+ncasException.getMessage());
            _LOGGER.error("getBillView in VAM Failed \n"+ncasException.getMessage());
            _LOGGER.error("getBillView in VAM Failed", ncasException);
			ncasException.setSPInputMap(params);
			throw ncasException;
		}catch(org.springframework.jdbc.CannotGetJdbcConnectionException ex){
			_LOGGER.debug("getBillView in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ex.getMessage());
            _LOGGER.error("getBillView in VAM Failed", ex);
			throw new ConnectionException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,ex);  
		}catch(Exception vamEx) {
			_LOGGER.debug("getBillView in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+vamEx.getMessage());
            _LOGGER.error("getBillView in VAM Failed", vamEx);
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,vamEx);
		}
		return retValue;
	}

	public String getStartPage(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::getStartPage";

		String schemaName = getSchemaName();
		SPStartPage getBillViewStoredProc = new SPStartPage(getDataSource(),schemaName);
		String retValue="";
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getStartPage";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);

			retValue = getBillViewStoredProc.executeStoredProcedure(userID,debugLevel,params);
			_LOGGER.info("getStartPage responseMap -> " + retValue);

		} catch(NCASException ncasException) {
			_LOGGER.debug("getStartPage in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("getStartPage in VAM Failed \n"+ncasException.getMessage());
			ncasException.setSPInputMap(params);
			throw ncasException;
		}catch(org.springframework.jdbc.CannotGetJdbcConnectionException ex){
			_LOGGER.debug("getBillView in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ex.getMessage());
			throw new ConnectionException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,ex);  
		}catch(Exception vamEx) {
			_LOGGER.debug("getStartPage in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getStartPage in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException("VAM getStartPage Failed\n"+vamEx.toString(),BillViewDAOImpl.class,vamEx);
		}
		return retValue;
	}


	public Map deferredDownloadRequest(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::deferredDownloadRequest";

		Map responseMap = null;
		String schemaName = getSchemaName();

		SPDeferredDownloadRequest deferredDownloadRequest = new SPDeferredDownloadRequest(
				getDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "deferredDownloadRequest";
				errMsg[1] = "deferredDownloadRequest";
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.info("***PERF LOG ***:Entering "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String startTime = NCASDataUtil.getCurrentTime();			

			responseMap = deferredDownloadRequest.executeStoredProcedure(userID, debugLevel,params);

			_LOGGER.info("***PERF LOG ***:Exiting "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String endTime = NCASDataUtil.getCurrentTime();
			NCASDataUtil.logPerfMessageBosi(startTime,endTime,(String)params.get("PERF_KEY"),(String)params.get("PERF_PAGE"),METHOD_NAME,(String)params.get("LOGIND"),getLogUsers());

			
		
			
			
			_LOGGER.info("deferredDownloadRequest responseMap -> " + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "deferredDownloadRequest";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_REQUEST_REPORT_DL;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

			//_LOGGER.info("deferredDownloadRequest" + acctListName);

		} catch (NCASException ncasException) {
			_LOGGER.debug("Request deferredDownload report in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("Request deferredDownload report in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("deferredDownloadRequest in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("deferredDownloadRequest in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("deferredDownloadRequest Failed\n"
					+ vamEx.toString(), BillViewDAOImpl.class, vamEx);
		}

		return responseMap;
	}

	public Map getStoredProcNames() throws NCASException{
		String SELECT_STORED_PROCS = "SELECT ORIG_SYSTEM_ID, PORTAL_API_NAME FROM " + getSchemaName() + ".ORIGIN_SYSTEM_T";

		final Map responseMap = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_STORED_PROCS);

		try
		{
			jdbcTemplate.query(SELECT_STORED_PROCS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String osid		= rs.getString("ORIG_SYSTEM_ID");
					String apiName	= rs.getString("PORTAL_API_NAME");
					responseMap.put(osid, apiName);
				}
			});
			//Displaying the response Map
			_LOGGER.info("values of the response Map::"+responseMap);
		}catch (Exception vamEx) {
			_LOGGER.debug("Method getStoredProcNames in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("Method getStoredProcNames in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("Method getStoredProcNames in VAM Failed\n"
					+ vamEx.toString(), BillViewDAOImpl.class, vamEx);
		}

		return responseMap;
	}
	public Map getUserPreferenceMap(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::getUserPreferenceMap";

		String schemaName = getSchemaName();
		Map retMap = null;
		StoredProcConfig spConfig = StoredProcConfig.getInstance();
		String osidName = (String)params.get("OSID");
		String storedProcName = NCASBOSIConstants.SP_USER_PREF;
		if(osidName != null)
		{
			storedProcName = spConfig.getOSIDStoredProcs(osidName, NCASBOSIConstants.SP_USER_PREF);
		}
		_LOGGER.info("storedProcName -> "+storedProcName);

		SPUserPreference getUserPreferenceStoredProc = new SPUserPreference(getDataSource(),schemaName, storedProcName);

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getUserPreferenceMap";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}
			_LOGGER.info("***PERF LOG ***:Entering "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String startTime = NCASDataUtil.getCurrentTime();
			
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			retMap = getUserPreferenceStoredProc.executeStoredProcedure(userID,debugLevel,params);
			_LOGGER.info("***PERF LOG ***:Exiting "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String endTime = NCASDataUtil.getCurrentTime();
			NCASDataUtil.logPerfMessageBosi(startTime,endTime,(String)params.get("PERF_KEY"),(String)params.get("PAGE_ID"),METHOD_NAME,(String)params.get("USER_ID"),getLogUsers());
			

			_LOGGER.info("getUserPreferenceMap responseMap -> " + retMap);
		} catch(NCASException ncasException) {
			_LOGGER.debug("getUserPreferenceMap in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("getUserPreferenceMap in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("getUserPreferenceMap in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getUserPreferenceMap in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,vamEx);
		}
		return retMap;
	}

	public Map saveCustomTagDigex(Map paramsMap) throws NCASException {
		String schemaName = getSchemaName();
		Map retMap = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "saveCustomTagDigex";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}
			SPSaveCustomTagDigex saveCustomTagDigexStoredProc = new SPSaveCustomTagDigex(getDataSource(),schemaName);
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			retMap = saveCustomTagDigexStoredProc.executeStoredProcedure(userID, debugLevel, paramsMap);
		} catch(NCASException ncasException) {
			_LOGGER.debug("saveCustomTagDigex in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("saveCustomTagDigex in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("saveCustomTagDigex in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("saveCustomTagDigex in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,vamEx);
		}
		return retMap;
	}

	public Map doSearch(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::doSearch";

		String schemaName = getSchemaName();
		String storedProcName = NCASBOSIConstants.SP_BILL_VIEW;
		SPBillView getBillViewStoredProc = new SPBillView(getDataSource(),schemaName, storedProcName);
		Map retValue = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getBillView";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.debug("Before calling into getBillViewStoredProc.executeStoredProcedure") ;
			_LOGGER.info("doSearch input map -> " + params);
			_LOGGER.info("***PERF LOG ***:Entering "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String startTime = NCASDataUtil.getCurrentTime();			
			
			retValue = getBillViewStoredProc.doSearch(userID,debugLevel,params);
			_LOGGER.info("***PERF LOG ***:Exiting "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String endTime = NCASDataUtil.getCurrentTime();
			NCASDataUtil.logPerfMessageBosi(startTime,endTime,(String)params.get("PERF_KEY"),(String)params.get("PERF_PAGE"),METHOD_NAME,(String)params.get("LOGIND"),getLogUsers());
			
			_LOGGER.info("doSearch Output responseMap -> " + retValue);
		} catch(NCASException ncasException) {
			_LOGGER.debug("getBillView in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ncasException.getMessage());
			ncasException.setSPInputMap(params);
			throw ncasException;
		}catch(org.springframework.jdbc.CannotGetJdbcConnectionException ex){
			_LOGGER.debug("getBillView in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ex.getMessage());
			throw new ConnectionException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,ex);  
		}catch(Exception vamEx) {
			_LOGGER.debug("getBillView in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,vamEx);
		}
		return retValue;
	}
	public void executeGeneric(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::executeGeneric";

		String schemaName = getSchemaName();
		String storedProcName = NCASBOSIConstants.SP_BILL_VIEW;
		SPBillView getBillViewStoredProc = new SPBillView(getDataSource(),schemaName, storedProcName);
		Map retValue = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getBillView";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.debug("Before calling into getBillViewStoredProc.executeStoredProcedure") ;
			retValue = getBillViewStoredProc.doSearch(userID,debugLevel,params);
			_LOGGER.debug("getBillView responseMap -> " + retValue);
		} catch(NCASException ncasException) {
			_LOGGER.debug("getBillView in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("getBillView in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,vamEx);
		}
	}

/*
	*
    * Developer - z894652
	* Date - Dec 02 2009
	* Name - setArchive
	* Comment - new archive method for retrieving archived bills
	*
*/
	public Map setArchive(Map params) throws NCASException
	{
        Map retValue = null;

        try
        {
            String userID = null;
            userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
            if (userID == null)
            {
                userID = "USSLBMG";
            }

            SPArchivedBill archivedBill = new SPArchivedBill(getDataSource(),
                    getSchemaName());
            String debugLevel = CommonUtil
                    .getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
            _LOGGER
                    .debug("Before calling into archivedBill.executeStoredProcedure");
            retValue = archivedBill.executeStoredProcedure(userID, debugLevel,
                    params);
            _LOGGER.debug("setArchive responseMap -> " + retValue);
        }
        catch (Exception e)
        {
            _LOGGER.error("setArchive()  Exception : ", e);

            String[] errMsg = new String[3];
            errMsg[0] = "setArchive";
            errMsg[1] = e.getMessage();
            throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,
                    BillViewDAOImpl.class, e, errMsg);
        }

        return retValue;
    }

	public Map checkPaperBills(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::checkPaperBills";


        Map retValue = null;
        try {
            String userID = null;
            userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
            if (userID == null) {
                userID = "USSLBMG";
            }
            SPCheckPaperBills spCheckPaperBills = new SPCheckPaperBills(getDataSource(),getSchemaName());
            String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
            _LOGGER.debug("Before calling SPCheckPaperBills.executeStoredProcedure");
			_LOGGER.info("***PERF LOG ***:Entering "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String startTime = NCASDataUtil.getCurrentTime();			
			
            retValue = spCheckPaperBills.executeStoredProcedure(userID, debugLevel,params);
			_LOGGER.info("***PERF LOG ***:Exiting "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String endTime = NCASDataUtil.getCurrentTime();
			NCASDataUtil.logPerfMessageBosi(startTime,endTime,(String)params.get("PERF_KEY"),"0",METHOD_NAME,(String)params.get("LOGIND"),getLogUsers());
			
            _LOGGER.debug("checkPaperBills responseMap -> " + retValue);
        }
        catch (Exception e) {
            _LOGGER.error("checkPaperBills()  Exception : ", e);
            String[] errMsg = new String[3];
            errMsg[0] = "checkPaperBills";
            errMsg[1] = e.getMessage();
            retValue = new HashMap<String, Object>();
 //           throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850, BillViewDAOImpl.class, e, errMsg);
        }
        return retValue;
	}

	public Map getExtBillView(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::getExtBillView";
		String schemaName = getSchemaName();
		StoredProcConfig spConfig = StoredProcConfig.getInstance();
		String osidName = (String)params.get("OSID");
		String storedProcName = NCASBOSIConstants.SP_EXT_BILL_VIEW;
//		_LOGGER.debug("Before calling spConfig.getOSIDStoredProcs") ;
//		if(osidName != null)
//			storedProcName = spConfig.getOSIDStoredProcs(osidName, storedProcName);
		_LOGGER.debug("storedProcName : is -"+storedProcName) ;


		SPExtBillView getBillViewStoredProc = new SPExtBillView(getDataSource(),schemaName, storedProcName);
		Map retValue = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null)
			    	userID = "USSLBMG";
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getExtBillView";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.debug("Before calling into getBillViewStoredProc.executeStoredProcedure") ;
			_LOGGER.info("***PERF LOG ***:Entering "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String startTime = NCASDataUtil.getCurrentTime();			
			retValue = getBillViewStoredProc.executeStoredProcedure(userID,debugLevel,params);
			_LOGGER.info("***PERF LOG ***:Exiting "+ "MODULE:"+ METHOD_NAME + params.get("PERFSTRING"));
			String endTime = NCASDataUtil.getCurrentTime();
			NCASDataUtil.logPerfMessageBosi(startTime,endTime,(String)params.get("PERF_KEY"),(String)params.get("PERF_PAGE"),METHOD_NAME,(String)params.get("LOGIND"),getLogUsers());
			
			_LOGGER.debug("getBillView responseMap -> " + retValue);
		} catch(NCASException ncasException) {
			_LOGGER.debug("getBillView in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ncasException.getMessage());
			ncasException.setSPInputMap(params);
			throw ncasException;
		}catch(org.springframework.jdbc.CannotGetJdbcConnectionException ex){
			_LOGGER.debug("getBillView in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+ex.getMessage());
			throw new ConnectionException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,ex);  
		}catch(Exception vamEx) {
			_LOGGER.debug("getBillView in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getBillView in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850,BillViewDAOImpl.class,vamEx);
		}
		return retValue;
	}
	
	public Map getUserSearchList(Map params) throws NCASException {
		final String METHOD_NAME = "BillViewDAOImpl::getUserSearchList";
		String schemaName = getSchemaName();
		StoredProcConfig spConfig = StoredProcConfig.getInstance();
		String loginid = (String)params.get("LOGINID");
		String storedProcName = NCASBOSIConstants.SP_SEARCH_LIST;
		_LOGGER.debug("storedProcName : is -"+storedProcName) ;


		SPUserAccounts userAcctStoredProc = new SPUserAccounts(getDataSource(),schemaName, storedProcName);
		Map retValue = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(VAM_USER_ID_CONFIG_PATH, " ");
			    if (userID == null)
			    	userID = "USSLBMG";
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getExtBillView";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, BillViewDAOImpl.class, e, errMsg);
			}

			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			_LOGGER.debug("Before calling into userAcctStoredProc") ;
			retValue = userAcctStoredProc.executeStoredProcedure(userID,debugLevel,params);
			_LOGGER.debug("After calling into userAcctStoredProc");
		} catch(Exception vamEx) {
			_LOGGER.debug("getUserSearchList in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getUserSearchList in VAM Failed \n"+vamEx.getMessage());
		}
		return retValue;
	}	
}