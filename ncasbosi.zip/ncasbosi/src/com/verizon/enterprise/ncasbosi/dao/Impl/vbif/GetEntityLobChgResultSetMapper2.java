package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.vbif.EntityLobChgResultSet2;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.util.DateUtility;

public class GetEntityLobChgResultSetMapper2 implements RowMapper
{
    static private final Logger _LOGGER = Logger.getLogger(GetEntityLobChgResultSetMapper2.class);

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        _LOGGER.debug("Inside GetEntityLobChgResultSetMapper2::mapRow rowNum - " + rowNum);
        CommonUtil.printMetaDataInfo(rs.getMetaData());
        
        EntityLobChgResultSet2 record = new EntityLobChgResultSet2();
        record.setLineNum(Integer.toString(rs.getInt("LINE_NUM"))); //INTEGER
		record.setBan(rs.getString("BAN"));
		record.setBillDate((rs.getDate("BILL_DATE")).toString()); //DATE
		record.setAban(rs.getString("ABAN"));
		record.setEntityCd(rs.getString("ENTITY_CD"));
		record.setInvBillInd(rs.getString("INV_BILL_IND"));
		record.setChgCd(rs.getString("CHG_CD"));
		record.setTblName(rs.getString("TBL_NAME"));
		record.setReportName(rs.getString("REPORT_NAME"));
		record.setDtlAmt((rs.getBigDecimal("DTL_AMT")).toString()); //DECIMAL
		record.setLevel(rs.getString("LEVEL"));
		record.setLinkOrder(rs.getString("LINK_ORDER"));
		record.setAdjustable(rs.getString("ADJUSTABLE"));
		record.setIban(rs.getString("IBAN"));
		record.setIbanOsid(rs.getString("IBAN_OSID"));
		record.setDtlCount(Integer.toString(rs.getInt("DTL_COUNT"))); //INTEGER     
        return record;
    }
}
