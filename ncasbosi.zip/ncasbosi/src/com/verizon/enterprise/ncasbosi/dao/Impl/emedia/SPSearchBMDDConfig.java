package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import org.apache.log4j.Logger;

public class SPSearchBMDDConfig extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetEMediaAccounts.class);
	
	private static List spInOutList;

	private static SearchBMDDConfigRowMapperImpl rowMapper;
	
	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new SearchBMDDConfigRowMapperImpl();
		 
		 spInOutList.add(new Object[]{"config",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"SERVICE_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"COMPANY_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUSTOMER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPSearchBMDDConfig(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SEARCH_BM_DD_CFGS, spInOutList);	
	}
	
	public Map executeStoredProcedure(String userId, String debugLevel, 
							EMediaProfile profile,  String sortOrder, 
							Pagination pagination) throws Exception
	{
		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}

		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		
		paramValueList.add(profile.getServiceType());//SERVICE_TYPE
		paramValueList.add(profile.getCustInfo().getCustCpnyName());//COMPANY_NAME
		paramValueList.add(profile.getCustInfo().getCustId());//CUSTOMER_ID
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE
		
		Map procMap = (Map)executeStoredProcedure(paramValueList);
		
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		List requestsList = (List)procMap.get("config");
		pagination.setResultSize(Integer.toString(requestsList.size()));
		procMap.put("pagination", pagination);
		
		return procMap;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
