package com.verizon.enterprise.ncasbosi.dao.Impl.admin;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;

import com.verizon.enterprise.ncasbosi.dao.Interface.admin.AdminUploadInterface;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.fileupload.AdminUpload;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.RowCallbackHandler;

import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.jdbc.object.MappingSqlQuery;

import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Iterator;

import javax.sql.DataSource;

public class AdminUploadDAOImpl extends NCASSpringJDBCBase implements
		AdminUploadInterface, NCASBOSIConstants {

	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	private BatchSqlUpdate insertAdminUploadSqlUpdate = null;
	private SqlUpdate updateAdminUploadSqlUpdate = null;
	private SqlUpdate deleteAdminUploadSqlUpdate = null;
	private SqlUpdate deleteAdminUploadErrorSqlUpdate = null;
	private SelectRequestId selectRequestId = null;
	private List requestList = null;
	private SelectAllFiles files;
	private HashMap selectFiles = null;
	private SelectSectionsForFile selectSectionsForFile;
	private HashMap sectionsForFile = null;
	private SelectVamSectionDetails sectionDetails;
	private HashMap sectionDetailsMap = null;

	
	private String SELECT_REQUEST_ID = "SELECT DISTINCT REQUEST_ID FROM "
			+ getSchemaName() + ".PL_UPLOAD";
	private String SELECT_SECTIONS_FOR_FILE = "SELECT SECTION FROM "+getSchemaName()+".PL_UPLOAD WHERE FILE = ?";
	private String SELECT_ADMIN_UPLOAD = "SELECT ERROR_MSG, LAST_UPDATED_BY FROM "+getSchemaName()+".PL_UPLOAD WHERE FILE = ? AND SECTION = ?";
	private String SELECT_ADMIN_UPLOAD_FILES = "SELECT DISTINCT FILE FROM "+getSchemaName()+".PL_UPLOAD";
	static private final Logger _LOGGER = Logger
			.getLogger(AdminUploadDAOImpl.class);

	private String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	public Map insertAdminUpload(AdminUpload adminUpload) throws NCASException {
		boolean status = false;
		String INSERT_ADMIN_UPLOAD_SQL = "INSERT INTO "
				+ getSchemaName()
				+ ".PL_UPLOAD(REQUEST_ID,FILE,SECTION,ERROR_MSG,LAST_UPDATED_BY,LAST_UPDATED) VALUES(?,?,?,?,?,?)";
		Map responseMap = new HashMap();
		_LOGGER.info(" SQL: " + INSERT_ADMIN_UPLOAD_SQL);
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System
					.currentTimeMillis()));
			// String updateDate = "";
			if (insertAdminUploadSqlUpdate == null) {
				insertAdminUploadSqlUpdate = new BatchSqlUpdate(jdbcTemplate
						.getDataSource(), INSERT_ADMIN_UPLOAD_SQL);
				insertAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"REQUEST_ID", Types.INTEGER));
				insertAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"FILE", Types.VARCHAR));
				insertAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"SECTION", Types.VARCHAR));
				insertAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"ERROR_MSG", Types.VARCHAR));
				insertAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"LAST_UPDATED_BY", Types.CHAR));
				insertAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"LAST_UPDATED", Types.TIMESTAMP));
				insertAdminUploadSqlUpdate.compile();
			}
			int req_id = 0;
			if (req_id == 0) {
				req_id = getGeneratedKey(selectRequestId());
			} else {
				req_id++;
			}
			_LOGGER.debug("The new generated key for the PL_Upload table is :"+ req_id);
			String flag = adminUpload.getFlag();
			_LOGGER.info("FLAG IS ->"+flag);
			//_LOGGER.info("FLAG IS boolean  ->"+ (flag.trim()!="vamfileupload"));
			if(flag!=null){
				if(!flag.equals("vamfileupload")){
					_LOGGER.debug("The new generated key for the PL_Upload table is :"+ req_id);
					List adminUploadList = adminUpload
							.getAdminUploadList();
					_LOGGER.info("size  adminUploadList ->"
							+ adminUploadList.size());
	
					adminUpload = (AdminUpload) adminUploadList.get(0);
	
				}
			}
			_LOGGER.info("REQUEST_ID ->"+req_id);
			_LOGGER.info("FILE ->"+adminUpload.getFile());
			
			insertAdminUploadSqlUpdate.update(new Object[] {new Integer(req_id), adminUpload.getFile(),	adminUpload.getSection(), adminUpload.getErrorMSG(), adminUpload.getLastUpdatedBy(), lastUpdated });
			 if (insertAdminUploadSqlUpdate != null)
			 insertAdminUploadSqlUpdate.flush();
			status = true;
		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertAdminUpload in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("insertAdminUpload in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					AdminUploadDAOImpl.class, vamEx);
		}
		_LOGGER.info("Exiting insertAdminUpload");
		responseMap.put("status", new Boolean(status));
		return responseMap;
	}

	public Map updateAdminUpload(AdminUpload adminUpload) throws NCASException {
		boolean status = false;

		String UPDATE_ADMIN_UPLOAD_SQL = "UPDATE "
				+ getSchemaName()
				+ ".PL_UPLOAD SET FILE=?,SECTION=?,ERROR_MSG=?,LAST_UPDATED_BY=?,lAST_UPDATED=? WHERE REQUEST_ID=?";
		Map responseMap = new HashMap();

		_LOGGER.info("UPDATE ADMIN UPLOAD SQL: " + UPDATE_ADMIN_UPLOAD_SQL);

		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System
					.currentTimeMillis()));

			if (updateAdminUploadSqlUpdate == null) {

				updateAdminUploadSqlUpdate = new SqlUpdate(jdbcTemplate
						.getDataSource(), UPDATE_ADMIN_UPLOAD_SQL);
				updateAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"FILE", Types.VARCHAR));
				updateAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"SECTION", Types.VARCHAR));
				updateAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"ERROR_MSG", Types.VARCHAR));
				updateAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"LAST_UPDATED_BY", Types.CHAR));
				updateAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"LAST_UPDATED", Types.TIMESTAMP));
				updateAdminUploadSqlUpdate.declareParameter(new SqlParameter(
						"REQUEST_ID", Types.INTEGER));
				updateAdminUploadSqlUpdate.compile();
			}

			List adminUploadList = adminUpload.getAdminUploadList();

			Object[] parameterValues = null;

			if (adminUploadList != null && adminUploadList.size() > 0) {
				// AdminUpload adminUpload =
				// (AdminUpload)adminUploadList.get(0);
				parameterValues = new Object[] { adminUpload.getFile(),
						adminUpload.getSection(), adminUpload.getErrorMSG(),
						adminUpload.getLastUpdatedBy(), lastUpdated,
						new Integer(adminUpload.getRequestId()) };

				updateAdminUploadSqlUpdate.update(parameterValues);

				status = true;
			}

		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateAdminUpload in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("updateAdminUpload in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					AdminUploadDAOImpl.class, vamEx);
		}
		_LOGGER.info("Exiting updateAdminUpload");
		responseMap.put("status", new Boolean(status));
		return responseMap;

	}

	public Map deleteAdminUpload(AdminUpload adminUpload) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String addAll = adminUpload.getAddAll();
		boolean deleteSingle = false;
		String DELETE_ADMIN_UPLOAD = "DELETE FROM " + getSchemaName()
				+ ".PL_UPLOAD WHERE FILE = ?";
		_LOGGER.info("Delete SQL: " + DELETE_ADMIN_UPLOAD);
		try {
			if (addAll.equalsIgnoreCase("ALL")) {
				if (deleteAdminUploadSqlUpdate == null) {
					deleteAdminUploadSqlUpdate = new SqlUpdate(jdbcTemplate
							.getDataSource(), DELETE_ADMIN_UPLOAD);
					deleteAdminUploadSqlUpdate
							.declareParameter(new SqlParameter("FILE",
									Types.CHAR));
					deleteAdminUploadSqlUpdate.compile();
				}

				Object[] parameterValues = null;
				parameterValues = new Object[] {adminUpload.getFile()};
				deleteAdminUploadSqlUpdate.update(parameterValues);

			} else {
				deleteAdminUploadError(adminUpload.getFile(), adminUpload.getSection());
			}

			status = true;

		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAdminUpload in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("deleteAdminUpload in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					AdminUploadDAOImpl.class, vamEx);
		}
		_LOGGER.info("Exiting deleteAdminUpload");
		responseMap.put("status", new Boolean(status));
		return responseMap;

	}

	public void deleteAdminUploadError(String file, String section)
			throws NCASException {
		boolean status = false;
		String DELETE_ADMIN_UPLOAD = "DELETE FROM " + getSchemaName()
				+ ".PL_UPLOAD WHERE FILE = ? and SECTION = ?";
		_LOGGER.info("Delete SQL: " + DELETE_ADMIN_UPLOAD);
		try {
			if (deleteAdminUploadErrorSqlUpdate == null) {
				_LOGGER.info("Yes delete Admin is null");
				deleteAdminUploadErrorSqlUpdate = new SqlUpdate(jdbcTemplate
						.getDataSource(), DELETE_ADMIN_UPLOAD);
				deleteAdminUploadErrorSqlUpdate
						.declareParameter(new SqlParameter("FILE",
								Types.VARCHAR));
				deleteAdminUploadErrorSqlUpdate
						.declareParameter(new SqlParameter("SECTION",
								Types.VARCHAR));
				deleteAdminUploadErrorSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[] {file, section};
			deleteAdminUploadErrorSqlUpdate.update(parameterValues);
			status = true;

		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAdminUploadSection in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("deleteAdminUploadSection in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					AdminUploadDAOImpl.class, vamEx);
		}
		_LOGGER.info("Exiting deleteAdminUploadSection");
	}
	
	class SelectAllFiles extends AbstractSelect{
		List fileList = new ArrayList();
		public SelectAllFiles(DataSource dataSource){
			super(dataSource,SELECT_ADMIN_UPLOAD_FILES);
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		    String file = rs.getString("FILE");
		    fileList.add(file);
		    selectFiles.put("files", fileList);
		    return selectFiles;
		}
	}

	public Map selectAllFiles() throws NCASException {
		 _LOGGER.info("Select SQL: " + SELECT_ADMIN_UPLOAD_FILES);
		 selectFiles = new HashMap();
		 files = new SelectAllFiles(getDataSource());
		 //files.declareParameter(new SqlParameter("FILE", Types.VARCHAR));
		 files.execute(new Object[]{});
		 _LOGGER.info("Exiting files");
		 return selectFiles;
	}

	
	class SelectSectionsForFile extends AbstractSelect{
		List sectionList = new ArrayList();
		public SelectSectionsForFile(DataSource dataSource){
			super(dataSource,SELECT_SECTIONS_FOR_FILE);
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		    String sections = rs.getString("SECTION");
		    sectionList.add(sections);
		    sectionsForFile.put("sections", sectionList);
		    return sectionsForFile;
		}
	}

	public Map selectSectionsForFile(String file) throws NCASException {
		 _LOGGER.info("Select SQL: " + SELECT_SECTIONS_FOR_FILE);
		 sectionsForFile = new HashMap();
		 selectSectionsForFile = new SelectSectionsForFile(getDataSource());
		 selectSectionsForFile.declareParameter(new SqlParameter("FILE", Types.VARCHAR));
		 selectSectionsForFile.execute(new Object[]{file});
		 _LOGGER.info("Exiting selectSectionsForFile");
		 return sectionsForFile;
	}
	
	class SelectVamSectionDetails extends AbstractSelect{
		List errormsgList = new ArrayList();
		public SelectVamSectionDetails(DataSource dataSource){
			super(dataSource,SELECT_ADMIN_UPLOAD);
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		      String error_msg = rs.getString("ERROR_MSG");
		      errormsgList.add(error_msg);
		      String lastUpdatedBy = rs.getString("LAST_UPDATED_BY");
		      sectionDetailsMap.put("error_msg", errormsgList);
		      sectionDetailsMap.put("lastUpdatedBy", lastUpdatedBy);
		      return sectionDetailsMap;
		}
	}

	public Map selectVamSectionDetails(String file, String section) throws NCASException {
		 _LOGGER.info("Select SQL: " + SELECT_ADMIN_UPLOAD);
		 sectionDetailsMap = new HashMap();
		 sectionDetails = new SelectVamSectionDetails(getDataSource());
		 sectionDetails.declareParameter(new SqlParameter("FILE", Types.VARCHAR));
		 sectionDetails.declareParameter(new SqlParameter("SECTION", Types.VARCHAR));
		 sectionDetails.execute(new Object[]{file, section});
		 _LOGGER.info("Exiting selectAdminUpload");
		 return sectionDetailsMap;
	}

	class SelectRequestId extends AbstractSelect {
		public SelectRequestId(DataSource dataSource) {
			super(dataSource, SELECT_REQUEST_ID);
		}

		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			int request_id = rs.getInt("REQUEST_ID");
			requestList.add(new Integer(request_id));
			return requestList;
		}
	}

	public List selectRequestId() throws NCASException {

		requestList = new ArrayList();
		selectRequestId = new SelectRequestId(getDataSource());
		selectRequestId.execute(new Object[] {});
		_LOGGER.info("Exiting SelectRequestId");
		return requestList;
	}

	private int getGeneratedKey(List currentKeyList) {
		int maxLinkNbrPlusOne = 0;
		int maxValueCalculated = 0;
		if (currentKeyList != null && currentKeyList.size() > 0) {
			maxValueCalculated = ((Integer) Collections.max(currentKeyList))
					.intValue();
		}
		maxLinkNbrPlusOne = maxValueCalculated + 1;
		return maxLinkNbrPlusOne;
	}

	abstract class AbstractSelect extends MappingSqlQuery {

		public AbstractSelect(DataSource dataSource, String sql) {
			super(dataSource, sql);
		}

	}


}
