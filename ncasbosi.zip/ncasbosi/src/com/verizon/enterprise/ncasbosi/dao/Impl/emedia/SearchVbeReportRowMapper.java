package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.gbr.VbeReportPoint;

public class SearchVbeReportRowMapper implements RowMapper
{
	static private final Logger logger = Logger.getLogger(SearchVbeReportRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "SearchVbeReportRowMapper::mapRow() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		VbeReportPoint reportPoint = null;

		if(rs != null)
		{
			reportPoint = new VbeReportPoint();

			
			
			//config 
			reportPoint.setConfigSubsOid(val(rs.getString("CONFIG_SUBS_OID")));
			reportPoint.setConfigId(val(rs.getString("CONFIG_ID")));
			reportPoint.setServiceType(val(rs.getString("SERVICE_TYPE")));
			
			//report identity
			reportPoint.setReportOid(val(rs.getString("REPORT_OID")));
			reportPoint.setReportId(val(rs.getString("REPORT_ID")));
			reportPoint.setReportName(val(rs.getString("REPORT_NAME")));
			reportPoint.setReportStart(val(rs.getString("REPORT_START")));
			reportPoint.setReportEnd(val(rs.getString("REPORT_END")));
			//report address
			reportPoint.setCustAddrType (val(rs.getString("CUST_ADDR_TYPE")));
			reportPoint.setCustAddr1 (val(rs.getString("CUST_ADDR_1")));
			reportPoint.setCustAddr2 (val(rs.getString("CUST_ADDR_2")));
			reportPoint.setCustAddr3 (val(rs.getString("CUST_ADDR_3")));
			reportPoint.setCustCity (val(rs.getString("CUST_CITY")));
			reportPoint.setCustState (val(rs.getString("CUST_STATE")));
			reportPoint.setCustZip (val(rs.getString("CUST_ZIP")));
			reportPoint.setPostalCode (val(rs.getString("POSTAL_CODE")));
			reportPoint.setCustCountry (val(rs.getString("CUST_COUNTRY")));
			//report fields
			reportPoint.setLanguage_code (val(rs.getString("LANGUAGE_CODE")));
			reportPoint.setCurrency_code (val(rs.getString("CURRENCY_CODE")));
			
			//node 
//			reportPoint.setNodeType (val(rs.getString("NODE_TYPE")));
//			reportPoint.setParentNodeType(val(rs.getString("PARENT_NODE_TYPE")));
			
			//remit
			reportPoint.setRemitOid (val(rs.getString("REMIT_OID")));
			reportPoint.setRemitId (val(rs.getString("REMIT_ID")));
			reportPoint.setRemitName (val(rs.getString("REMIT_NAME")));
			reportPoint.setDefaultRemit(val(rs.getString("DEFAULT_REMIT")));

		}

		return reportPoint;
	}
	
	private String val (String in)
	{
		if (in == null) return "";
		return in.trim();

	}
}
