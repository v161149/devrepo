package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
public class GetBarsWestSubAccountBillListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetBarsWestSubAccountBillListMapper.class);	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetAdjustmentsMapper - Mapping Row# "+rowNum);
		HiSelectDO hiDO = null;

		if(rs!=null){			hiDO = new HiSelectDO();			String startSection = rs.getString(3).trim();			String endSection = rs.getString(4).trim();			int sections = Integer.parseInt(endSection) - Integer.parseInt(startSection) + 1;			hiDO.setBillPayer(trimSpace(rs.getString(2)));			hiDO.setStartSection(startSection);			hiDO.setSections(sections + "");			hiDO.setDocType("Invoice");//			hiDO.setAcctLevel(hiDO.SUB);			hiDO.setAcctLevel("");  //set to empty string, bars is now sending in S for standalone subs where we have to call 08 to get the master info
									// here we already have the master info so setting account level to anything other than S
		}		return hiDO;
	}

	private String trimSpace(String input){
		return input!=null?input.trim():input;
	}
}
