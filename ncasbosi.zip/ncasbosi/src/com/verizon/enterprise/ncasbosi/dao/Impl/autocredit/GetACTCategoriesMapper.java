package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.autocredit.ACTCategoriesHelper;

/**
 * @author v992473
 * This class gets the complete resultset of GET_ACT_CATEGORIES
 * and constructs a map of ACTCategory objects.
 * 
 */

public class GetACTCategoriesMapper implements ResultSetExtractor{
	private final Logger _LOGGER = Logger.getLogger(this.getClass());

	public Object extractData(ResultSet rs) throws SQLException,DataAccessException{
		_LOGGER.info("Entering extractData()");
		_LOGGER.info("Is resultSet Null::"+(rs==null)); 
		Map categoryMap = ACTCategoriesHelper.constructACTCategoryMap(rs);
		_LOGGER.info("Exiting extractData()");
		return categoryMap;
	}
}
