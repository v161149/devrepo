package com.verizon.enterprise.ncasbosi.dao.Impl.dbadmin;

import java.util.Map;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.verizon.kernel.xml.XmlParse;
import com.verizon.enterprise.common.ncas.BillViewConstants;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.display.Page;
import com.verizon.enterprise.common.ncas.display.PageContent;
/**
 * A HelperClass to create PageNavigatorXml
 * Class responsible for creating PagenavigatorXml that includes main elements such as BillDisplay, Markup, ExternalLinks
 * @author Z894579
 *
 */
public class PageNavigatorXmlHelper
{
	static private final Logger _LOGGER = Logger.getLogger(PageNavigatorXmlHelper.class);


	public String generatePageNavigatorXml(Map billViewMap, Map markupMap, Map buttonMap)throws Exception
	{
		_LOGGER.info("Entering createPageNavigatorXml ");
		String pageNavXmlString = null;
		XmlParse xp = null;
		try
		{
		  xp = new XmlParse("<verizon><BillDisplay></BillDisplay><MarkupTemplate></MarkupTemplate></verizon>");
		  xp.moveToRoot();
		  xp.moveTo("BillDisplay");
		  //xp.addNode("page");
		  //xp.moveToNextNode();
		  xp = createBillViewXml(xp, billViewMap,buttonMap);
		  /* Calling creteMarkupXml */
		  xp=  createMarkupXml(xp, markupMap);
		  pageNavXmlString = xp.toString(false, true);
		  pageNavXmlString=pageNavXmlString.replaceAll("&lt;", "<");
		  pageNavXmlString=pageNavXmlString.replaceAll("&gt;",">");
		  pageNavXmlString=pageNavXmlString.replaceAll("&amp;","&");
		  _LOGGER.info("pageNavXmlString is ------>"+ pageNavXmlString);
		}
		catch(Exception xpEx)
		{
			_LOGGER.error("Exception in creating PageNavigator XML "+ xpEx);
			throw xpEx;
		}
		_LOGGER.info("Entering createPageNavigatorXml ");
		return pageNavXmlString;
	}

	/**
	 * Method responsible for creating BillDisplay element of the Xml
	 * @param xp
	 * @param billViewMap
	 * @return
	 * @throws Exception
	 */

	private XmlParse createBillViewXml(XmlParse xp, Map billViewMap,Map buttonMap)throws Exception
	{
		Integer key = null;
		String pageKey = "";
		String pageAttr = "";
		Page page = null;
		String pageId = null;

		List pcList = null;
		int count = 0;
		 for(Iterator itr = billViewMap.keySet().iterator(); itr.hasNext();)
		  {
			pageKey = (String)itr.next();
			key = new Integer(NCASDataUtil.getPageIDFromPageKey(pageKey));
			pageAttr  = NCASDataUtil.getPageAttrFromPageKey(pageKey);
			page = (Page)billViewMap.get(pageKey);
			pageId = String.valueOf(key.intValue());
			count++;

			if(count <= billViewMap.size())//&& (page.getType() != null && !page.getType().equalsIgnoreCase("N")))
			 {

			  xp.addNode("page");
			  xp.moveToLastNode();
			  pcList = page.getContent();
			  xp = addPage(xp, pageId, page, pcList,pageAttr,buttonMap);
			  xp.moveToParentNode();
			  //xp.moveToParentNode();
			 }

		  }
		 _LOGGER.info(xp.toString(false, true));
		 //System.out.println(key);
		return xp;
	}

	/**
	 * Method responsible for creating BillDisplay element of the Xml
	 * @param xp
	 * @param markupMap
	 * @return
	 * @throws Exception
	 */
	private XmlParse createMarkupXml(XmlParse xp, Map markupMap)throws Exception
	{	_LOGGER.info("Entering into createMarkupXml");
		String key = null;
		String cData = null;
		int count = 0;
		xp.moveToRoot();
		xp.moveTo("MarkupTemplate");

		 for(Iterator itr = markupMap.keySet().iterator(); itr.hasNext();)
		  {
			key = (String)itr.next();
			cData = (String)markupMap.get(key);
			cData= new String("<![CDATA["+cData+"]]>");
			count++;
			if(count <= markupMap.size())//&& (page.getType() != null && !page.getType().equalsIgnoreCase("N")))
			 {

			  xp.addNode("page");
			  xp.moveToLastNode();
			  xp.addAttribute("name", key);
			  xp.addNode("value", cData);
			  xp.moveToParentNode();


			   //pcList = page.getContent();
			  //xp = addPage(xp, pageId, page, pcList);
			  //xp.moveToParentNode();
			  //xp.moveToParentNode();
			 }

		  }
		 _LOGGER.info("key--->"+key+"cData"+cData);
		 _LOGGER.info(xp.toString(false, true));
		 _LOGGER.info("Exiting from createMarkupXml" );
		 //System.out.println(key);
		return xp;
	}

	private XmlParse addPage(XmlParse xp, String pageId, Page page, List pcList,String pageAttr,Map buttonMap)throws Exception
	{

		PageContent pc = null;
		String var = null;
		xp.addAttribute("name", pageId);
		var = page.getType();
		boolean remove = false;
		List<String> btnList = null;
		if(!var.equalsIgnoreCase("N"))
		{
		  xp.addNode("type", page.getType());
		}
		var = page.getBcrumb();
		if(!var.equalsIgnoreCase(BillViewConstants.BRCUMB_MARKUP_DEFAULT))
		{
			xp.addNode("bcrumb",page.getBcrumb());
		}
		var = page.getLeftNav();
		if(!var.equalsIgnoreCase(BillViewConstants.LEFTNAV_MARKUP_DEFAULT))
		{
			xp.addNode("leftNav", page.getLeftNav());
		}
		var = page.getLeftNavSize();
		if(!var.equalsIgnoreCase(BillViewConstants.LEFTNAV_WIDTH_DEFAULT))
		{
			xp.addNode("leftNavSize", page.getLeftNavSize());
		}
		var = page.getHeader();
		if(!var.equalsIgnoreCase(BillViewConstants.HEADER_MARKUP_DEFAULT))
		{
			xp.addNode("header", page.getHeader());
		}
		var = page.getHeaderSize();
		if(!var.equalsIgnoreCase(BillViewConstants.HEADER_WIDTH_DEFAULT))
		{
			xp.addNode("headerSize", page.getHeaderSize());
		}

		var = page.getAsyncclass();
		if(!var.equalsIgnoreCase(BillViewConstants.ASYNC_CLASS_DEFAULT))
		{
			xp.addNode("asyncClass", page.getAsyncclass());
		}
		var = page.getStructType();
		if(!var.equalsIgnoreCase(BillViewConstants.STRUCT_TYPE_DEFAULT))
		{
			xp.addNode("structType", page.getStructType());
		}

		var = page.getTrack();
		if(!var.equals(""))
		{
			xp.addNode("track", var);
		}
		var = page.getTrackAttr();
		if(!var.equals(""))
		{
			xp.addNode("trackAttr", var);
		}


		if(!pageAttr.equals(""))
		{
			xp.addNode("pageAttr", pageAttr);
		}

			if(pcList != null)
			{
				for(int i=0; i<pcList.size(); i++)
				{
					pc = (PageContent)pcList.get(i);
					xp.addNode("content"+i);
					xp.moveTo("content"+i);
					var = pc.getName();
					if(!var.equalsIgnoreCase(BillViewConstants.TABLE_MARKUP_DEFAULT))
					{
						xp.addNode("name", pc.getName());
					}

					btnList = (List)buttonMap.get(NCASDataUtil.getButtonKey(pageId,pageAttr,String.valueOf(i)));
					if(btnList!=null)
					{
						xp.addNode("btnsize", String.valueOf(btnList.size()));
						for(int k=0;k<btnList.size();k++)
							xp.addNode("btnname"+k, btnList.get(k));
					}
					var = pc.getSize();
					if(!var.equalsIgnoreCase(BillViewConstants.TABLE_WIDTH_DEFAULT))
					{
						xp.addNode("size", pc.getSize());
					}
					var = pc.getPaginate();
					if(!var.equalsIgnoreCase(BillViewConstants.PAGINATE_DEFAULT))
					{
						xp.addNode("paginate", pc.getPaginate());
					}
					if(!xp.hasChildNodes())
					{
					  	remove = true;
					}
					xp.moveToParentNode();
					if(remove)
					{
					  xp.removeNode("content"+i);
					  remove = false;
					}

				}

			}
		return xp;
	}


}

