package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import org.apache.log4j.Logger;
/*
 * PVB 12-07-2009
 * 	Added logic for OUTPUT_DSN field - hardcoded value as for now.
 */

public class SPManageEMediaProfile extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPManageEMediaProfile.class);

	private static List spInOutList;
//	 Donnelly  9/2007 - added logic for Digix, MWAN and Millenium


	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIBER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"BP_DAY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"START_DATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"COMM_EDI_CUST_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PROF_STATUS_COMM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"COMPANY_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUSTOMER_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"DIVISION_SUBSID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_1", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_2", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_CITY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_STATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ZIP", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_COUNTRY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LOA", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SERV_PVDR_LOC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LOB_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"TOT_BILL_INV_AMT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"TRANS_SW_PKG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PLATFORM1", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PLATFORM2", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"BUS_APP_SW_PKG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_SUPP_EDI_TRAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_SUPP_EDI_VER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"FILE_READY_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ENTERPRISE_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EDI_DELIV_OPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_DATA_GRP_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_DATA_GRP_NAM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_ENTERPRISE_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_USER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_VBCC_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_USER_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_USER_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_REV_LOC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_BILL_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_SEGMENT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EFTP_APP_ACTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"COMM_METHOD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"VAN_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EDI_ENVIRONMENT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ASCII_EBCDIC_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"GCS_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"WIN_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LBS_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"IXPLUS_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"MEGAVOICE_CNV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"IBRS_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"VISION_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"MILLEN_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SVIEW_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CAS_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"REGIONAL_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"DATABASE_PW", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CONFIG_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SOFTWARE_VER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"MEDIA_OPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"NAT_BILL_PAY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"MAIL_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"OVERNIGHT_MAIL_OPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CONFIG_NATL_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"BM_CD_CHG_WAIVER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"BM_CD_CHG_ACCT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"BM_CD_CHG_WAIVE_CM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_COMM_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"TPV_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"DD_DELIV_OPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"DD_AUTO_ADD_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PROFILE_COMPLETE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"OTH_CONTACT_INFO_1", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"OTH_CONTACT_INFO_2", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ORIG_SYSTEM_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});

		 spInOutList.add(new Object[]{"EDI_864", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_CONTRACT_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SFTP_MAILBOX_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SFTP_MAILBOX_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CALL_DETAIL_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});

		 //added for secabs  12/2009
		 spInOutList.add(new Object[]{"SECABS_DELIV_OPT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IP_ADDRESS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NDM_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NDM_PASSWORD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SFTP_HOSTNAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SFTP_DEST_DIR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SFTP_PASSWORD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"OUTPUT_DSN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INDUSTRY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SEND_997_EMAIL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SFTP_ZIP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BM_CALL_DETAIL_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BP_OVERRIDE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROFILE_COMMENT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SERV_PVDR_NBR", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"HOLD_DAYS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SMP_CONTRACT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ACNA", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		//vallabh added for pm accounts
		 spInOutList.add(new Object[]{"PB_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"US_PB_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"VBE_CONV_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
	}
	public SPManageEMediaProfile(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_MANAGE_EM_PROFILE, spInOutList);
	}

	/**
	 * @param userId
	 * @param debugLevel
	 * @param profile
	 * @return
	 * @throws Exception
	 */
	/**
	 * @param userId
	 * @param debugLevel
	 * @param profile
	 * @return
	 * @throws Exception
	 */
	public Map executeStoredProcedure(String userId, String debugLevel,
			EMediaProfile profile, String action)throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(profile.getUserId());//USER_ID
		paramValueList.add(profile.getUserName());//USER_NAME
		paramValueList.add(debugLevel);//DEBUG_LEVEL
        DecimalFormat decimalFormatter = new DecimalFormat("##########");
		String configSubscriptionOid = decimalFormatter.format(profile.getProfileKey().getConfigSubscriptionOid());
		_LOGGER.info("configSubscriptionOid - " + configSubscriptionOid);
		paramValueList.add(configSubscriptionOid);//CONFIG_SUBS_OID
		paramValueList.add(profile.getSubscriber().getSubscriberOid());//SUBSCRIBER_OID
		paramValueList.add(action);//ACTION

		Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = formatter.format(profile.getStartDate());
		_LOGGER.info("Formatted Expected Start Date = " + strDate);

		paramValueList.add(profile.getBillPeriod());//BP_DAY
		paramValueList.add(strDate);//START_DATE
		paramValueList.add(profile.getCustIndicator());//COMM_EDI_CUST_IND
		paramValueList.add(profile.getProfStatusComnts());//PROF_STATUS_COMM
		paramValueList.add(profile.getCustInfo().getCustCpnyName());//COMPANY_NAME
		paramValueList.add(profile.getCustInfo().getCustType());//CUSTOMER_TYPE
		paramValueList.add(profile.getCustInfo().getDivSub());//DIVISION_SUBSID
		paramValueList.add(profile.getCustInfo().getAddress().getAddTypeInd());//CUST_ADDR_TYPE
		paramValueList.add(profile.getCustInfo().getAddress().getAddress1());//CUST_ADDR_1
		paramValueList.add(profile.getCustInfo().getAddress().getAddress2());//CUST_ADDR_2
		paramValueList.add(profile.getCustInfo().getAddress().getCity());//CUST_CITY
		paramValueList.add(profile.getCustInfo().getAddress().getState());//CUST_STATE
		paramValueList.add(profile.getCustInfo().getAddress().getZip());//CUST_ZIP
		paramValueList.add(profile.getCustInfo().getAddress().getCountry());//CUST_COUNTRY
		paramValueList.add(profile.getSrvcProviderInfo().getLoa());//LOA
		paramValueList.add(profile.getSrvcProviderInfo().getProviderLoc());//SERV_PVDR_LOC
		paramValueList.add(profile.getAcctTeamInfo().getLob());//LOB_IND
		paramValueList.add(String.valueOf(profile.getAcctTeamInfo().getTotalMnthBillAmt()));//TOT_BILL_INV_AMT
		paramValueList.add(profile.getTransDetailInfo().getTransSoftPackage());//TRANS_SW_PKG
		paramValueList.add(profile.getTransDetailInfo().getPlatform1());//PLATFORM1
		paramValueList.add(profile.getTransDetailInfo().getPlatform2());//PLATFORM2
		paramValueList.add(profile.getTransDetailInfo().getBsnsSoftPackage());//BUS_APP_SW_PKG
		paramValueList.add(profile.getTransDetailInfo().getCustSuppTrans());//CUST_SUPP_EDI_TRAN
		paramValueList.add(profile.getTransDetailInfo().getCustSuppVers());//CUST_SUPP_EDI_VER
		paramValueList.add(profile.getTransDetailInfo().getFlag811());//FILE_READY_EMAIL
		paramValueList.add(profile.getTransDetailInfo().getEnterpriseID());//ENTERPRISE_ID
		paramValueList.add(profile.getDlvryOptCommMeth().getDelOptCommMeth());//EDI_DELIV_OPT
		paramValueList.add(profile.getDlvryOptCommMeth().getDataGrpID());//EFTP_DATA_GRP_ID
		paramValueList.add(profile.getDlvryOptCommMeth().getDataGrpName());//EFTP_DATA_GRP_NAM
		paramValueList.add("");//paramValueList.add(profile.getDlvryOptCommMeth());//EFTP_ENTERPRISE_ID
		paramValueList.add(profile.getDlvryOptCommMeth().getUserName());//EFTP_USER_NAME
		paramValueList.add(profile.getDlvryOptCommMeth().getUserID());//EFTP_VBCC_USER_ID
		paramValueList.add(profile.getDlvryOptCommMeth().getPhoneNum());//EFTP_USER_PHONE
		paramValueList.add(profile.getDlvryOptCommMeth().getEmailID());//EFTP_USER_EMAIL
		paramValueList.add(profile.getDlvryOptCommMeth().getRevLOC());//EFTP_REV_LOC
		paramValueList.add(profile.getDlvryOptCommMeth().getBillCorpID());//EFTP_BILL_ID
		paramValueList.add(profile.getDlvryOptCommMeth().getSegment());//EFTP_SEGMENT
		paramValueList.add(profile.getDlvryOptCommMeth().getAppAction());//EFTP_APP_ACTION
		paramValueList.add(profile.getDlvryOptCommMeth().getCommMethod2());//COMM_METHOD
		paramValueList.add(profile.getDlvryOptCommMeth().getVanName());//VAN_NAME
		paramValueList.add(profile.getEnvISAGSRecInfo().getEnvironment());//EDI_ENVIRONMENT
		paramValueList.add(profile.getEnvISAGSRecInfo().getAsciiEBCDICFlag());//ASCII_EBCDIC_FLAG
		paramValueList.add(profile.getConversionComments().getGcsCnvrsnFlg());//GCS_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getWinCnvrsnFlg());//WIN_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getLbsCnvrsnFlg());//LBS_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getIxPlusCnvrsnFlg());//IXPLUS_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getMegaVoiceCnfrCnvrsnFlg());//MEGAVOICE_CNV_FLAG
		paramValueList.add(profile.getConversionComments().getIbrsCnvrsnFlg());//IBRS_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getVisionCnvrsnFlg());//VISION_CONV_FLAG
//		 Donnelly  9/2007 - added logic for Digix, MWAN and Millenium
		paramValueList.add(profile.getConversionComments().getMillenCnvrsnFlg());//MILLEN_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getSingleViewCnvrsnFlg());//SVIEW_CONV_FLAG
		paramValueList.add("");//CAS_IND
		paramValueList.add("");//REGIONAL_IND
		paramValueList.add(profile.getDatabasePW());//DATABASE_PW
		paramValueList.add(profile.getProfileKey().getConfigName());//CONFIG_NAME
		paramValueList.add(profile.getSoftwareVersion());//SOFTWARE_VER
		paramValueList.add(profile.getMediaOpt());//MEDIA_OPT
		paramValueList.add(profile.getNatBillPay());//NAT_BILL_PAY
		paramValueList.add(profile.getMailInd());//MAIL_IND
		paramValueList.add(profile.getOvernightMailOpt());//OVERNIGHT_MAIL_OPT
		paramValueList.add(profile.getNationalInd());//CONFIG_NATL_IND
		paramValueList.add(profile.getCdChargeWaiver());//BM_CD_CHG_WAIVER
		paramValueList.add("");//BM_CD_CHG_ACCT
		paramValueList.add("");//BM_CD_CHG_WAIVE_CM
		paramValueList.add("");//CUST_COMM_EMAIL
		paramValueList.add("");//TPV_NAME
		paramValueList.add(profile.getDdDeliveryOpt());//DD_DELIV_OPT
		paramValueList.add("");//DD_AUTO_ADD_IND
		paramValueList.add(profile.getProfComplete());//PROFILE_COMPLETE
		paramValueList.add(profile.getCustInfo().getOtherContactInfo1());//OTH_CONTACT_INFO_1
		paramValueList.add(profile.getCustInfo().getOtherContactInfo2());//OTH_CONTACT_INFO_2
		paramValueList.add(profile.getOrigSystemId());//ORIG_SYSTEM_ID

		paramValueList.add(profile.getEnvISAGSRecInfo().getEdi864()); //EDI_864
		paramValueList.add(profile.getCustInfo().getCustContractId());//CUST_CONTRACT_ID
		paramValueList.add(profile.getSFtpMailboxId());
		paramValueList.add(profile.getSFtpMailboxName());
		paramValueList.add(profile.getCallDetailInd());

		//added for secabs - Ram 12/02/09
		paramValueList.add(profile.getSecabsDeliveryOption());//SECABS_DELIV_OPT
		paramValueList.add(profile.getIpAddress());//IP_ADDRESS
		paramValueList.add(profile.getNdmUserId());//NDM_USER_ID
		paramValueList.add(profile.getNdmPassword());//NDM_PASSWORD
		paramValueList.add(profile.getSftpHostname());//SFTP_HOSTNAME
		paramValueList.add(profile.getSftpDestDir());//SFTP_DEST_DIR
		paramValueList.add(profile.getSftpPassword());//SFTP_PASSWORD
		paramValueList.add(profile.getOutputDSN());//OUTPUT_DSN
		//added for eMedia Feb 2010 changes - Nach. (INDUSTRY, SEND_997_EMAIL, SFTP_ZIP, BM_CALL_DETAIL_IND, BP_OVERRIDE
		paramValueList.add(profile.getCustInfo().getIndustry());//INDUSTRY
		paramValueList.add(profile.getTransDetailInfo().getSend997email());//SEND_997_EMAIL
		paramValueList.add(profile.getDlvryOptCommMeth().getSFtpZip());//SFTP_ZIP
		paramValueList.add(profile.getBmCallDetSumInd());//BM_CALL_DETAIL_IND
		paramValueList.add(profile.getBpOverRideInd());//BP_OVERRIDE
		paramValueList.add(profile.getComments());//PROFILE_COMMENT
		paramValueList.add(String.valueOf(profile.getSrvcProviderInfo().getProviderNumber()));//SERV_PVDR_NBR
		paramValueList.add(String.valueOf(profile.getHoldDays()));//HOLD_DAYS
		if (profile.getSmpContractId().equalsIgnoreCase("N/A")) {
			paramValueList.add("");//SMP_CONTRACT_ID
		} else {
			paramValueList.add(profile.getSmpContractId());//SMP_CONTRACT_ID
		}
		paramValueList.add(profile.getAcna());//ACNA Field for the SECABS Profile 
		
		//vallabh added for pm PB_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getPrimebillerCnvrsnFlg());//PB_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getUsPrimebillerCnvrsnFlg());//US_PB_CONV_FLAG
		paramValueList.add(profile.getConversionComments().getVbeCnvrsnFlg());//VBE_FLAG
		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
