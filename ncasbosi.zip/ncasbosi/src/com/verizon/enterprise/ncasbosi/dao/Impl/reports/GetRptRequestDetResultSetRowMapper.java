package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.reports.RptRequest;

public class GetRptRequestDetResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetRptRequestDetResultSetRowMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetRptRequestDetResultSetRowMapper::mapRow rowNum - " + rowNum);

		RptRequest rptRequestItem = new RptRequest();

		int rptId = rs.getInt("RPT_ID");                                                                     //RPT_ID
		String portalLoginId = rs.getString("PORTAL_LOGIN_ID");                                                    //PORTAL_LOGIN_ID
		String rptType = rs.getString("RPT_TYPE");                                                                 //RPT_TYPE
		int rptRecurId = rs.getInt("RPT_RECUR_ID");                                                          //RPT_RECUR_ID		
		String structType = rs.getString("STRUCT_TYPE");                                                           //STRUCT_TYPE
		double structOid = rs.getDouble("STRUCT_OID");                                                             //STRUCT_OID
		String positionType = rs.getString("POSITION_TYPE");                                                       //POSITION_TYPE
		double positionOid = rs.getDouble("POSITION_OID");                                                         //POSITION_OID
		String requestStatus = rs.getString("REQUEST_STATUS");                                                     //STATUS
		String errDescription = rs.getString("ERROR_DESCRIPTION");                                                 //ERROR_DESCRIPTION
		String rptRequestTs = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("RPT_REQUEST_TS"));                  //RPT_REQUEST_TS 
		String rptProcessTs = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("RPT_PROCESS_TS"));                  //RPT_PROCESS_TS
        String emailAddr = rs.getString("EMAIL_ADDR");                                                             //EMAIL_ADDR
        int pageId = rs.getInt("PAGE_ID");                                                                         //PAGE_ID
		String pageSubset = rs.getString("PAGE_SUBSET");                                                           //PAGE_SUBSET
		String downloadDescription = rs.getString("DOWNLOAD_DESCRIPTION");                                         //DOWNLOAD_DESCRIPTION
		String rqstLinkParam = rs.getString("RQST_LINK_PARAM");                                                    //RQST_LINK_PARAM 
		String rqstSortParam = rs.getString("RQST_SORT_PARAM");                                                    //RQST_SORT_PARAM
		String rqstFilterParam = rs.getString("RQST_FILTER_PARAM");                                                //RQST_FILTER_PARAM
		double userOid = rs.getDouble("USER_OID");                                                                 //USER_OID 
		String createdTimestamp = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("CREATED_TIMESTAMP"));
		String lastUpdTimestamp = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("LAST_UPD_TIMESTAMP"));
		String lastUpdatedBy = rs.getString("LAST_UPDATED_BY");
		
		rptRequestItem.setRptId(rptId);
		rptRequestItem.setPortalLoginId(portalLoginId);
		rptRequestItem.setRptType(rptType);
		rptRequestItem.setRptRecurId(rptRecurId);
		rptRequestItem.setStructType(structType);
		rptRequestItem.setStructOid(structOid);
		rptRequestItem.setPositionType(positionType);
		rptRequestItem.setPositionOid(positionOid);
		rptRequestItem.setRequestStatus(requestStatus);
		rptRequestItem.setErrDescription(errDescription);
		rptRequestItem.setRptRequestTs(rptRequestTs);
		rptRequestItem.setRptProcessTs(rptProcessTs);
		rptRequestItem.setEmailAddr(emailAddr);
		rptRequestItem.setPageId(pageId);
		rptRequestItem.setPageSubset(pageSubset);
		rptRequestItem.setDownloadDescription(downloadDescription);
		rptRequestItem.setRqstLinkParam(rqstLinkParam);
		rptRequestItem.setRqstSortParam(rqstSortParam);
		rptRequestItem.setRqstFilterParam(rqstFilterParam);
		rptRequestItem.setUserOid(userOid);
		rptRequestItem.setCreatedTimestamp(createdTimestamp);
		rptRequestItem.setLastUpdTimestamp(lastUpdTimestamp);
		rptRequestItem.setLastUpdatedBy(lastUpdatedBy);
		return rptRequestItem;
	}
}
