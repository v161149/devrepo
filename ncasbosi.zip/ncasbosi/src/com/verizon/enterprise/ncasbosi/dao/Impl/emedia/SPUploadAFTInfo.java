package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPUploadAFTInfo extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPUploadAFTInfo.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"REQUEST_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"UPLOAD_COMPLETE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"HL_LEVEL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RECORD_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LIST_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPUploadAFTInfo(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_UPLOAD_AFT_INFO, spInOutList);
	}

	protected Map executeStoredProcedure(String appUserId, String debugLevel,
			String requestNumber, String ediDataGroup, String accounts, int recordCount, boolean uploadComplete) throws Exception {

		List paramValueList = new ArrayList();
		paramValueList.add(appUserId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL

		paramValueList.add(requestNumber);//REQUEST_NO
		
		if(uploadComplete) {
			paramValueList.add("Y"); //UPLOAD_COMPLETE
		} else {
			paramValueList.add("N"); //UPLOAD_COMPLETE
		}

		paramValueList.add(ediDataGroup);//HL_LEVEL
		paramValueList.add(String.valueOf(recordCount));//RECORD_COUNT
		paramValueList.add(accounts);//LIST_IN
		//_LOGGER.debug("Input List - " + paramValueList);
		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}

}
