package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Preference;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

	public class GetUserPrefReportMapperImpl  implements ResultSetExtractor {
		static private final Logger _LOGGER = Logger.getLogger(GetUserPrefReportMapperImpl.class);
		public Object extractData(ResultSet rs) throws SQLException {
			_LOGGER.info("Inside GetUserPrefReportMapperImpl -> ");
			CommonUtil.printMetaDataInfo(rs.getMetaData());

			ArrayList rows = new ArrayList();
			Preference preference = null;
		
			while(rs.next()) {
				
				preference = new Preference();
				String tab_order = Integer.toString(rs.getInt("CURSOR_NBR"));
				String report_filter = rs.getString("REPORT_FILTER");
				String report_tab = rs.getString("TAB_NAME");
				preference.setReport_name(report_tab.trim());
				preference.setTab_order(tab_order.trim());
				preference.setReport_fltr(report_filter.trim());
				rows.add(preference);
			}
				return rows;
			}
	}
	