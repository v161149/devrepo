package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.reports.VbeAftInfo;

public class GetVbeAftInfoResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetVbeAftInfoResultSetRowMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetVbeAftInfoResultSetRowMapper::mapRow rowNum - " + rowNum);

		VbeAftInfo vbeAftInfo = new VbeAftInfo();
        String requestNo = rs.getString("REQUEST_NO");
        String requestType = rs.getString("CUSTOMER_NAME");         
		String comments = rs.getString("COMMENTS");

		vbeAftInfo.setRequestNo(requestNo);
		vbeAftInfo.setRequestType(requestType);
		vbeAftInfo.setComments(comments);
		
		return vbeAftInfo;
	}
}
