package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaProfileInterface;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.common.eMedia.GBREMediaProfile;
import com.verizon.enterprise.common.ncas.gbr.GetGbrComponentDO;

/*
 * Author - Ram/v992473
 * This class decides which method to be performed
 * for  GBR/GCP. 
 */

public class GBR_GCPMethodInvocationProcessor {
	private static EMediaProfileInterface emediaProfileObject;
	private static final Logger _LOGGER = Logger.getLogger(GBR_GCPMethodInvocationProcessor.class);
	
	private static synchronized EMediaProfileInterface getEMediaProfileObject(){
		if(emediaProfileObject==null){
			_LOGGER.info("Getting the singleton EMediaProfile Object");
			emediaProfileObject = DAOFactory.getInstance().getEMediaProfile();
			_LOGGER.info("Successfully retrieved handle to the EMediaProfile Object");
		}
		return emediaProfileObject;
	}
	
	/**
	 * @param input - list containing the inputs
	 * @param function - method to be called
	 * @return Map
	 * @throws NCASException
	 */
	public static Object processGBR_GCPMethodInvocationTask(Object input,String function)throws NCASException{
		_LOGGER.info("Entering processGBR_GCPMethodInvocationTask");
		Object responseObject = null;
		try{
			EMediaProfileInterface emediaProfileObj = getEMediaProfileObject();
			Method method = emediaProfileObj.getClass().getMethod(function, getClassTypes(input));
			responseObject = method.invoke(emediaProfileObj,getInputValues(input));
		}catch(InvocationTargetException exception){
			throw new NCASException("AC1001",GBR_GCPMethodInvocationProcessor.class,exception.getTargetException());
		}catch(Exception exception){
			throw new NCASException("AC1001",GBR_GCPMethodInvocationProcessor.class,exception);
		}
		_LOGGER.info("responseObject=" + responseObject);
		_LOGGER.info("Exiting processGBR_GCPMethodInvocationTask");
		return responseObject;
	}
	
	/**
	 * @param input of Object type
	 * @return Class[]
	 * the idea is the UI passes all the inputs in the form of list from now on(also supports previously coded single argument types)
	 * and this method reads the input param types from the list
	 * and creates a Class[] of the param types of all the input params passed in the list
	 */
	private static Class[] getClassTypes(Object input){
		if(input==null){
			return new Class[0];//so this is to call no-argument method
		}
		if(input instanceof List){
			ArrayList inputList = (ArrayList)input; 
				if (inputList.size()==0){
					return new Class[0];//to call a method that has no arguments
				}else{
						Class[] classArray = new Class[inputList.size()];
					    for(int i=0;i<inputList.size();i++){
							Object value = (Object)inputList.get(i);
							classArray[i] = getClassType(value);
					    }
					    return classArray;
				}
		}else if (input instanceof Map){
			return new Class[]{Map.class};
		}else{
			return new Class[]{Object.class};//this is for cases where Object itself passed as an argument
		}
	}
	
	/**
	 * @param input of Object type
	 * @return Object[]
	 * converts the list of input params into array of params
	 *
	 */
	private static Object[] getInputValues(Object input){
		if(input==null){
			return new Object[0];//this is to call no-argument method
		}
		if(input instanceof List){
			return ((ArrayList)input).toArray();
		}else{
			return new Object[]{input};
		}
	}
	
	private static Class getClassType(Object value){
		if(value instanceof String){
			return String.class;
		}else if(value instanceof Integer){
			return Integer.class;
		}else if(value instanceof Pagination){
			return Pagination.class;
		}else if(value instanceof GBREMediaProfile){
			return GBREMediaProfile.class;
		}else if(value instanceof GetGbrComponentDO){
			return GetGbrComponentDO.class;
		}else if(value instanceof Map){
			return Map.class;
		}else{
			return Object.class;
		}
	}
	
	
}

