package com.verizon.enterprise.ncasbosi.dao.Impl.brinetworx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.brinetworx.BriNetworxInterface;
import com.verizon.enterprise.common.ncas.brinetworx.BriAccount;
import com.verizon.enterprise.common.ncas.exception.NCASException;

public class BriNetworxDAOImpl extends NCASSpringJDBCBase implements BriNetworxInterface{
	
	private static final Logger _LOGGER = Logger.getLogger(BriNetworxDAOImpl.class);

	public Map getBRIAccountList (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		BriAccount briAccount = (BriAccount)requestMap.get("briAccount");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in briAccount = " + briAccount);
			}
			
			responseMap = new SPGetBriAccountList(getBRIDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getBRIAccountList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1002",BriNetworxDAOImpl.class,e);
		}

		List selectList = (ArrayList) responseMap.get("RESULT_SET_ONE");
		BriAccount selectItem;
		if (selectList != null)
		{
			for (int i = 0; i < selectList.size(); i ++)
			{
				selectItem = (BriAccount)selectList.get(i);
				selectItem.setEmail(briAccount.getEmail());
				selectItem.setPortal(briAccount.getPortal());
			}
			responseMap.put("RESULT_SET_ONE", selectList);

		}

		return responseMap;
	}
	
	public Map searchBRIAccount (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		BriAccount briAccount = (BriAccount)requestMap.get("briAccount");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in briAccount = " + briAccount);
			}
			
			responseMap = new SPSearchBRIAccount(getBRIDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("searchBRIAccount - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1002",BriNetworxDAOImpl.class,e);
		}

		return responseMap;
	}

}
