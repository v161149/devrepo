package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.approval.Designation;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


public class VBIFGetActiveDesignee{
	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	private JdbcTemplate jdbcTemplate;
	private static VBIFGetActiveDesignee.SearchActiveDesigneeRowMapper mapperObj;
	
	static{
		//single mapperObject is created that services mutliple calls
		mapperObj = new VBIFGetActiveDesignee.SearchActiveDesigneeRowMapper();
	}
	
	public VBIFGetActiveDesignee(JdbcTemplate jdbcTemplate){
		this.jdbcTemplate = jdbcTemplate;
	}
	
	@SuppressWarnings("unchecked")
	public List<Designation> getActiveDesignee(String sql, List<String> whereInputs){
		String METHOD_NAME = "VBIFGetActiveDesignee->getActiveDesignee::";
		_LOGGER.info(METHOD_NAME + sql);
		int inputSize = whereInputs.size();
		Object[] params = new Object[inputSize];
		int[] types = new int[inputSize];
		for(int i=0;i<inputSize;i++){
			params[i] = whereInputs.get(i);
			types[i] = Types.VARCHAR;
		}
		List<Designation> designeeList = this.jdbcTemplate.query(sql, params, types, mapperObj);
		return designeeList;
	}

	private static class SearchActiveDesigneeRowMapper implements RowMapper{
		@Override
		public Object mapRow(ResultSet rs, int num) throws SQLException {
			Designation designeeList = null;
			if (rs != null) {
				designeeList = new Designation();
				designeeList.setDesignatorName(rs.getString("DESIGNATOR"));
				designeeList.setApproverName(rs.getString("APPROVER"));
				designeeList.getUserDelegation().setDesignatorVZID(rs.getString("DESIGNATOR_VZID"));
				designeeList.getUserDelegation().setApproverVZID(rs.getString("APPROVER_VZID"));
				String startDate=rs.getString("START_DATE");
				String formattedStartDate=CommonUtil.getFormattedDate(startDate,NcasConstants.INTERNATIONAL_DATE_FORMAT);
				designeeList.getUserDelegation().setStartDate(formattedStartDate);
				String endDate=rs.getString("END_DATE");
				String formattedEndDate=CommonUtil.getFormattedDate(endDate,NcasConstants.INTERNATIONAL_DATE_FORMAT);				
				designeeList.getUserDelegation().setEndDate(formattedEndDate);
				designeeList.getUserDelegation().setLastUpdatedBy(rs.getString("LAST_UPDATED_BY"));
				String lastUpdTimestamp=rs.getString("LAST_UPD_TIMESTAMP");
				String formattedLastUpdTimestamp=CommonUtil.getFormattedDate(lastUpdTimestamp,NcasConstants.INTERNATIONAL_DATE_FORMAT);				
				designeeList.getUserDelegation().setLastUpdatedTimestamp(formattedLastUpdTimestamp);
			}
			return designeeList;
		}
	}
}