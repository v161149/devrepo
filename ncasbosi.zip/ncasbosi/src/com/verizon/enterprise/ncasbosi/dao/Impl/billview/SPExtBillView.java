package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.io.Serializable;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.custom.CLink;
import com.verizon.enterprise.common.ncas.display.BillViewPagination;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.display.CellWork;
import com.verizon.enterprise.common.ncas.display.CellBase;
import com.verizon.enterprise.common.ncas.display.CellHeader;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.common.ncas.display.Navigation;
import com.verizon.enterprise.common.ncas.display.PageCache;
import com.verizon.enterprise.common.ncas.display.PageView;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import com.verizon.enterprise.dataobjects.Structure;
/**
 * @author V238591
 *
 */
public class SPExtBillView extends BaseStoredProcedure {
		static private final Logger _LOGGER = Logger.getLogger(SPExtBillView.class);
		private static List<Object[]> spInOutList;
		private static GetBreadCrumbRowMapperImpl bCrumbrowMapper;
		private static GetLeftNavRowMapperImpl leftNavrowMapper;
		private static GetHeaderRowMapperImpl headerrowMapper;
		private static GetExtContentRowMapperImpl contentrowMapper;
		private static GetLinkedObjectRowMapperImpl linkObjectrowMapper;

		public SPExtBillView(DataSource dataSource, String schemaName, String storedProcName)
		{
			super(dataSource, schemaName + "." + storedProcName, spInOutList);
		}

		static
		{
			 spInOutList = new ArrayList<Object[]>();
			 bCrumbrowMapper = new GetBreadCrumbRowMapperImpl();
			 leftNavrowMapper = new GetLeftNavRowMapperImpl();
			 headerrowMapper = new GetHeaderRowMapperImpl();
			 contentrowMapper = new GetExtContentRowMapperImpl();
			 linkObjectrowMapper = new GetLinkedObjectRowMapperImpl();

			 spInOutList.add(new Object[]{"breadcrumb",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,bCrumbrowMapper});
			 spInOutList.add(new Object[]{"leftnav",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,leftNavrowMapper});
			 spInOutList.add(new Object[]{"header",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,headerrowMapper});
			 spInOutList.add(new Object[]{"tables",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,contentrowMapper});
			 spInOutList.add(new Object[]{"linkobject",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,linkObjectrowMapper});

			 spInOutList.add(new Object[]{"PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"LINK_PARAMS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"FILTER_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"SORT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"PAGE_SUBSET", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"BEGIN_ROW", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"SCROLL_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"EMPLOYEE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

			 spInOutList.add(new Object[]{"PORTAL_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"MISC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"KEYSTRING", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"VALUSETRING", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PAGE_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PAGE_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});


			 spInOutList.add(new Object[]{"TABLE_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_1_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_2_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_3_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_4_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_5_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_6_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_7_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_8_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_9_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

			 spInOutList.add(new Object[]{"TBL_10_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_11_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_12_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PARENT_PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PAGINATE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"STRUCTURE_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"STRUCTURE_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"POSITION_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"POSITION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"CHANNEL_CD_LIST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

			 spInOutList.add(new Object[]{"ALIAS_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"MATCH_FOUND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"BILL_FOUND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"FIND_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"IMP_LOGIN_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		}

		public Map<String, Serializable> executeStoredProcedure(String userId, String debugLevel, Map params) throws Exception
		{
			String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
			List paramValueList = new ArrayList();
			Map<String, Serializable> returnMap = new HashMap<String, Serializable>();

			PageCache page = (PageCache) params.get("PAGE");
			String employeeFlag  = (String) params.get("EMPLFLAG");
			String portalUserID  = (String) params.get("LOGIND");
			String portalInd = (String)params.get("PORTAL");
			Boolean isAdmin = (Boolean)params.get("ISADMIN");
			List<String> userPermissions = (List<String>)params.get("USER_PERM");
			Structure struct = (Structure)params.get("STRUCTURE");
			String keys = (String)params.get("KEY");
			String values = (String)params.get("VALUE");
			if(keys==null)
				keys = "";
			if(values==null)
				values = "";

			String misc = page.getMisc();
			String action = page.getAction();
			Link linkObject = page.getLink();
			BillViewPagination pagination = page.getPagination();

			if (action.equals("") || action.length() == 0) {
				action = "O";
			}

		    String downloadType = page.getDownloadType();

			paramValueList.add(linkObject.getPageId().trim());    //PAGE_ID
			paramValueList.add(linkObject.getLinkParam()); //LINK_PARAMS
			String filterString = linkObject.getFilterString();
			String searchString = linkObject.getSearchString();
			String sortString = linkObject.getSortString();
			if(filterString == null) {
				filterString = "";
			}
			if(sortString == null) {
				sortString = "";
			}
			if(searchString == null) {
				searchString = "";
			}

			paramValueList.add(filterString);//FILTER_STRING
			//paramValueList.add(searchString);//FILTER_STRING
			paramValueList.add(sortString);  //SORT_STRING


			paramValueList.add(linkObject.getPageSubset());//PAGE_SUBSET
			int lineOffSet = pagination.getLineOffset();
			int pageSize = pagination.getItemsPerPage();
			if (pagination.isSelectAll()) {
				lineOffSet = 1;
				pageSize = pagination.getRowCount();
			}


			paramValueList.add(lineOffSet); //LINE_OFFSET
			paramValueList.add(pageSize);   //PAGE_SIZE

			paramValueList.add(userId);     //APP_USER_ID
			paramValueList.add(debugLevel); //DEBUG_LEVEL

			paramValueList.add(employeeFlag); //EMPLOYEE_FLAG
			paramValueList.add(portalUserID); //PORTAL_USER_ID
			paramValueList.add(misc);  //MISC
			paramValueList.add(action);//ACTION
			paramValueList.add(keys);//KEYSTRING
			paramValueList.add(values);//VALUESTRING

			paramValueList.add(struct.getStructureType());    //STRUCTURE_TYPE inout
			paramValueList.add(struct.getStructureValue());   //STRUCTURE_OID inout
			paramValueList.add(struct.getPositionType());    //POSITION_TYPE inout
			paramValueList.add(struct.getPositionValue());   //POSITION_OID inout


			paramValueList.add("");  //CHANNEL_CD_LIST in (not used)
			String aliasFlag = (String) params.get("ALIAS_FLAG");
			if(aliasFlag==null||(aliasFlag!=null&&aliasFlag.equals("")))
				aliasFlag = "N";
			paramValueList.add(aliasFlag);  //ALIAS_FLAG in

			String lang = (String)params.get("LANG");
			if(lang==null||(lang!=null&&lang.trim().equals("")))
				lang=NcasConstants.LANG_CODE_US_ENGLISH_VAM;
			paramValueList.add(lang);
			paramValueList.add(searchString);//FIND_STRING
			String impLoginID = (String)params.get("IMPLOGIND");
			if(impLoginID == null)
				impLoginID = "";
			paramValueList.add(impLoginID);//IMP_LOGIN_ID

			Map procMap = executeStoredProcedure(paramValueList);

			int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
			String debugStr = (String)procMap.get("MSG_STRING");
			if (debugStr == null) {
			    debugStr = "";
			}
			if( returnCode > 0 ) {
				if(returnCode == 2) {
					returnMap.put("RETURNCODE", "2");
				  returnMap.put("RETURNMSG", debugStr.trim());
				} else{
                    _LOGGER.error("In executeStoredProcedure - debugStr = " + debugStr);
					String[] errMsg = new String[3];
				    errMsg[0] = "getBillView";
				    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_EXT_BILL_VIEW;
				    errMsg[2] = debugStr;
				    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
				}
			}



			Navigation bcrumb = (Navigation)procMap.get("breadcrumb");
			Navigation leftNav = (Navigation)procMap.get("leftnav");
			Content header = (Content)procMap.get("header");
			Content newTables = (Content)procMap.get("tables");
			Map linkMap = (LinkedHashMap<String, List<Cell>>)procMap.get("linkobject");
			String pageTitle = (String)procMap.get("PAGE_TITLE");

			Navigation newLeftNav = populateLeftNav(leftNav, userPermissions, portalInd, isAdmin.booleanValue());
			Content newHeader = populateContent(header,linkMap);

			//Pagination on table
			Integer allcountrStr = (Integer)procMap.get("TOTAL_ROWS");
			Integer rowcountrStr = (Integer)procMap.get("PAGE_ROWS");
			Integer tableCount = (Integer)procMap.get("TABLE_COUNT");
			Integer beginRow = (Integer)procMap.get("BEGIN_ROW");
			String paginate_flag = (String)procMap.get("PAGINATE_FLAG");
			if(paginate_flag!=null && paginate_flag.equalsIgnoreCase("N"))
				pagination.setPaginate(false);

			pagination.updateCurrentPageFromServer(allcountrStr, rowcountrStr,0) ;
			newTables.setLink(linkObject);
			newTables.setPagination(pagination);

			if(linkObject.getLinkParam().equals(""))
				linkObject.setLinkParam("  ");
			String tblName = "";
			int tableCountInt = tableCount.intValue();
			if(tableCountInt >= 1 && tableCountInt <= 12){
				List<String> tabHeader = new ArrayList<String>();
				for(int i=0;i<tableCountInt;i++){
					tblName = "TBL_"+ String.valueOf(i+1)+"_TITLE";
					tabHeader.add((String)procMap.get(tblName));
				}
				newTables.setTabHeaders(tabHeader);
			}
			if(action.equalsIgnoreCase("D")) {
		 	      if (downloadType.equals(""))
				  	    newTables =  populateDownload(newTables,newHeader);
		 	      else  newTables =  populateDownload2(newTables,newHeader);
			}

			if(bcrumb!=null && bcrumb.getCells()!=null && bcrumb.getCells().size()==0)
				bcrumb = null;
			if(newLeftNav!=null && newLeftNav.getCells()!=null && newLeftNav.getCells().size()==0)
				newLeftNav = null;
			if(newHeader!=null && newHeader.getRows()!=null && newHeader.getRows().size()==0)
				newHeader = null;
			if(newTables==null || ( newTables!=null && newTables.getRows()==null))
				newTables = null;

			String parentPageID = ((Integer)procMap.get("PARENT_PAGE_ID")).toString();
			PageView pgView = new PageView(bcrumb,newLeftNav,newHeader,newTables,pageTitle, parentPageID);
			_LOGGER.debug("In SPExtBillView - Return pgView :: "+pgView);

			returnMap.put("PAGEVIEW", pgView);

			return returnMap;
		}

		private Content populateDownload(Content table, Content header) {
			Content newTable =  new Content();
			ArrayList<ArrayList<CellHeader>> newRows = new ArrayList<ArrayList<CellHeader>>();
			String valCell = "";
			newTable.setRows(newRows);
			ArrayList<CellHeader> newCellList = null;


			ArrayList<CellHeader> headerNameList = new ArrayList<CellHeader>();
			ArrayList<CellHeader> headerDataList = new ArrayList<CellHeader>();
			if(header!=null){
				List rows_header = header.getRows();
				if(rows_header!=null){
					Iterator rowIter_header = rows_header.iterator() ;
					while (rowIter_header.hasNext()){
						valCell = "";
						List cellList_header = (List)rowIter_header.next();
						if(cellList_header != null){
							CellHeader headerCell = (CellHeader)cellList_header.get(0);
							if(!headerCell.getName().equals("")){
								headerNameList.add(new Cell(headerCell.getName()) );
								if (headerCell.getValue().isEmpty() && cellList_header.size() > 1) {
									CellHeader headerCell1 = (CellHeader)cellList_header.get(1);
									valCell = headerCell1.getValue();
								} else {
									valCell = headerCell.getValue();
								}
								headerDataList.add(new Cell(valCell));
							}
						}
					}
				}
			}

			if(table!=null){
				List rows = table.getRows();
				if(rows!=null){
					Iterator rowIter = rows.iterator() ;
					newCellList = new ArrayList();
					newCellList.addAll(headerNameList);

					while (rowIter.hasNext()){

						List cellList = (List)rowIter.next();
						Iterator cellIter = cellList.iterator() ;
						boolean first = true;
						while (cellIter.hasNext()){
							Cell item = (Cell)cellIter.next();
							if(!item.getFormat().equals("TBL_TL")&& !item.getFormat().equals("TBL_GRAND_TL") && !item.getType().equals("LEGEND")){
								if(first&&!item.getFormat().equals("COL_HDR")){
									newCellList.addAll(headerDataList);
									first = false;
								}
								newCellList.add(item);
							}
						}
						//newCellList.addAll(cellList);
						newRows.add(newCellList);
						newCellList = new ArrayList();
					}
				}

			}
			return newTable;
	}
	private Content populateDownload2(Content table, Content header) {
	  Content newTable =  new Content();
	  ArrayList newRows = new ArrayList();
	  newTable.setRows(newRows);
	  ArrayList newCellList = null;

	  if (table!=null){
		List rows = table.getFooter();
		if (rows!=null){
		  Iterator rowIter = rows.iterator() ;
		  newCellList = new ArrayList();
		  while (rowIter.hasNext()){
			Cell cellItem = (Cell)rowIter.next();
			if (cellItem != null){
			  newCellList.add(cellItem);
			  newRows.add(newCellList);
			  newCellList = new ArrayList();
			}
		  }
		}
	  }
	  if (header!=null){
		List rows_header = header.getRows();
		if (rows_header!=null){
		  Iterator rowIter_header = rows_header.iterator();
		  newCellList = new ArrayList();
		  while (rowIter_header.hasNext()){
			List cellList_header = (List)rowIter_header.next();
			if (cellList_header != null){
  			  CellHeader headerCell = (CellHeader)cellList_header.get(0);
  			  newCellList.add(new Cell(headerCell.getName()));
  			  newCellList.add(new Cell(headerCell.getValue()));
			  newRows.add(newCellList);
			  newCellList = new ArrayList();
			}
		  }
		}
	  }
	  if(table!=null){
		List rows = table.getRows();
		if (rows!=null){
		  Iterator rowIter = rows.iterator() ;
		  newCellList = new ArrayList();
		  while (rowIter.hasNext()){
			List cellList = (List)rowIter.next();
			Iterator cellIter = cellList.iterator() ;
			while (cellIter.hasNext()){
			  Cell item = (Cell)cellIter.next();
			  if(!item.getFormat().equals("TBL_TL")&& !item.getFormat().equals("TBL_GRAND_TL") && !item.getType().equals("LEGEND")){
				newCellList.add(item);
			  }
			}
			newRows.add(newCellList);
			newCellList = new ArrayList();
 		  }
		}
	  }
	  return newTable;
	}

   private Navigation populateLeftNav(Navigation leftNav,
			List userPermissions, String portalInd, boolean isAdmin) throws Exception {
		Navigation newLeftNav = new Navigation();
		ArrayList newCellList = new ArrayList();
		newLeftNav.setCells(newCellList);
		String newFormat = null;
		String newName = null;
		String newValue = null;
		boolean overrideBoolean = false;

		if (leftNav != null) {
			List cellList = leftNav.getCells();
			if (cellList != null) {
				Iterator cellIter = cellList.iterator();
				while (cellIter.hasNext()) {
					CellBase element = (CellBase) cellIter.next();
					String lnkType = element.getLnkType();
					if (lnkType != null && lnkType.length() > 0) {
						if (!CommonUtil.linkHasExclusion(lnkType, portalInd, isAdmin)) {
							_LOGGER.debug("The link " + lnkType + "  for portal " + portalInd	+ " doesn't have exclusion.So displaying it");
							int currentLink = CommonUtil.getLinkKeyFromFormat(lnkType);
							int overrideLink = CommonUtil.linkHasOverride(currentLink, lnkType, portalInd);
							if (currentLink != overrideLink) {
								_LOGGER.debug("The link " + lnkType + "  for portal " + portalInd + " has an override.");
								// There is a override. So modify the CELL.
								CLink newCLink = CommonUtil.getCLinkFromKey(overrideLink);
								if (newCLink != null) {
									newName = newCLink.getName();
									newFormat = newCLink.getType();
									newValue = newCLink.getExtFunc();
									_LOGGER	.debug("The new link will have the name ->"	+ newName + " And the new format-> " + newFormat	+ " And the new javascript func->" + newValue);
									element.setName(newName);
									element.setFormat(newFormat);
									element.setLnkType(newValue);
									overrideBoolean = true;
									// Anything else that can be overriden
									// should be updated in the CELL as well.
								}
							}
							if (overrideBoolean)
								lnkType = newFormat;

							if (CommonUtil.userHasPermission(userPermissions,lnkType)) {
								_LOGGER.debug("The user has permission to view this link->" + lnkType);
								newCellList.add(element);
							}
							overrideBoolean = false;
						}
					} else {
						newCellList.add(element);
					}
				}
			}
		}
		return newLeftNav;
	}

        /*
         * header
         */
		private Content populateContent(Content header,Map linkMap)throws Exception
		{
			Content newHeader =  new Content();
			ArrayList newRows = new ArrayList();
			newHeader.setRows(newRows);
			ArrayList newCellList = null;

			if(header!=null && linkMap!=null){
				List rows = header.getRows();
				if(rows!=null){
					Iterator rowIter = rows.iterator() ;
					while (rowIter.hasNext()){
						List cellList = (List)rowIter.next();
						Iterator cellIter = cellList.iterator() ;
						newCellList = new ArrayList();
						while (cellIter.hasNext()){
							CellWork element = (CellWork)cellIter.next();
							if(!element.getName().equals("") || !element.getValue().equals("")){
								CellHeader ch = new CellHeader(element.getName(),element.getValue(), element.getToolTip(), element.getLink(),
										 element.getType(), element.getFormat(), element.getLnkType(), element.getSelectType(), element.getCurrencyCode());
								newCellList.add(ch);
								if(!element.getLinkKey().equals("0")){
									List linkList = (List)linkMap.get(element.getLinkKey());
									if(linkList!=null){
										Iterator linkIter = linkList.iterator() ;
										while (linkIter.hasNext()){
											Cell item = (Cell)linkIter.next();
											CellHeader ch1 = new CellHeader(item.getName(),item.getValue(), item.getToolTip(), item.getLink(),
													item.getType(), item.getFormat(), item.getLnkType(), item.getSelectType(), item.getCurrencyCode());
											newCellList.add(ch1);
										}
									}
								}
							}
						}
						if (newCellList.size() > 0) {
						  newRows.add(newCellList);
						}
					}
				}
			}
			return newHeader;
		}



		public Map executeStoredProcedure(Object paramValues)throws Exception
		{
			List paramValueList = (List) paramValues;
			return executeSP(paramValueList, false);
		}


}


