package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiPrintAndMailDO;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPSubmitZipRequest extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPSubmitZipRequest.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"IN_USERID",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_DEBUG_LEVEL",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_REQUESTED_TS",  getSqlDataType(Types.TIMESTAMP),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_MAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_BAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ABAN",        getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_OSID",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_DOCUMENT_TYPE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_BILL_DATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_FILE_NAME",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"IN_NAME",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_EMAIL",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_PHONE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"DOCUMENT_NUMBER",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	}

	public SPSubmitZipRequest(DataSource dataSource){
		super(dataSource, getVGWSchemaName() + "." + "VGWD403", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map requestMap = (HashMap)input;
		HiPrintAndMailDO zipRequestDO = (HiPrintAndMailDO)requestMap.get("zipRequestDO");

		String debugLevel = "0";
//		if (_LOGGER.isDebugEnabled()) debugLevel = "1";

		Calendar cal = new GregorianCalendar();  // get current date time
		Timestamp ts = new Timestamp(cal.getTimeInMillis()); //save current date time as time stamp

		List callList = new ArrayList();
		callList.add(zipRequestDO.getUserId()); // IN_USERID
		callList.add(debugLevel);    // IN_DEBUG_LEVEL
		callList.add(ts);            //IN_REQUESTED_TS
		callList.add(zipRequestDO.getMan()); //IN_MAN
		callList.add(zipRequestDO.getBan()); //IN_BAN
		callList.add(zipRequestDO.getAban());
		callList.add(zipRequestDO.getOsid()); //IN_OSID
		callList.add(zipRequestDO.getDocType()); //IN_DOCUMENT_TYPE
		callList.add(zipRequestDO.getBillDate()); //BILL_DATE

		callList.add(zipRequestDO.getFileName() + ".zip");

		callList.add(zipRequestDO.getRequestorName());
		callList.add(zipRequestDO.getRequestorEmail());
		callList.add(zipRequestDO.getRequestorPhoneNumber());

		Map responseMap = executeSP(callList, false);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(responseMap, VGW);

		Number documentNumber = (Number)responseMap.get("DOCUMENT_NUMBER");

		_LOGGER.debug("Zip request confirmation - document number returned from back-end = " + documentNumber);

		return responseMap;
	}
}
