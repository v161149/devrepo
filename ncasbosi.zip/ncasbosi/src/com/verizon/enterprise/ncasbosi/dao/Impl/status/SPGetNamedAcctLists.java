package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;


public class SPGetNamedAcctLists extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetNamedAcctLists.class);
	
	private static List spInOutList;
	
	private static GetNamedAcctListsRowMapperImpl rowMapper;
	
	static
	{
		 rowMapper = new GetNamedAcctListsRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"acctlists",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
	}
	
	public SPGetNamedAcctLists(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_NAMED_AC_LISTS, spInOutList);	
	}

	public Map executeStoredProcedure(String userId, String debugLevel, 
			String userOid,String sortOrder,String tokenSt, Pagination pagination)throws Exception
	{
		
		_LOGGER.debug("entering  executeStoredProcedure api");
		
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		
		StringBuffer myParams = new StringBuffer();

		myParams.append("SP Params [");

		paramValueList.add(userId);//APP_USER_ID
		myParams.append(userId + "^");
		
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		myParams.append(debugLevel + "^");
		
		paramValueList.add(userOid);//USER_OID
		myParams.append(userOid + "^");
		
		if(sortOrder == null || sortOrder.equals("")) {
			paramValueList.add("");//SORT_ORDER
		} else {
			paramValueList.add(sortOrder);//SORT_ORDER
		}
		myParams.append(sortOrder + "^");

		paramValueList.add(tokenSt);	// TOKEN_ST
		myParams.append(tokenSt);
		
		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}

		paramValueList.add(lineOffSet);//PAGE_OFFSET
		myParams.append(lineOffSet + "^");
		
		paramValueList.add(pageSize);//PAGE_SIZE
		myParams.append(pageSize + "^");
		
		_LOGGER.debug(myParams.toString());
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		//return executeStoredProcedure(paramValueList);
		
		_LOGGER.debug("after executing api");
		
		Integer rowcountrStr = (Integer)procMap.get("TOTAL_ROWS");
		_LOGGER.debug("rowcountrStr" + rowcountrStr);

		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		
		Map acctMap = (HashMap)procMap.get("acctlists");
		
		resultMap.put("recordsMap", procMap);
		resultMap.put("pagination", pagination);


		return resultMap ;
				
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
