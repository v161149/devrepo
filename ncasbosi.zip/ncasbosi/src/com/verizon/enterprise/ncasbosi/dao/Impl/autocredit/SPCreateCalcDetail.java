package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/**
 * @author v992473
 *
 */
public class SPCreateCalcDetail extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPCreateCalcDetail.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN",               getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN",               getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_VZID",   getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATING_SYS_ID",getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_TYPE",         getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_SUB_TYPE",         getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SERVICE_ID",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_FROM_DT",      getSqlDataType(Types.DATE),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_THRU_DT",      getSqlDataType(Types.DATE),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALL_TYPE",         getSqlDataType(Types.VARCHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIG_TERM_TYPE",         getSqlDataType(Types.VARCHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TERM_COUNTRY",         getSqlDataType(Types.VARCHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TERM_STATE",         getSqlDataType(Types.VARCHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CREDIT_METHOD",         getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"IN_BATCH_ID",         getSqlDataType(Types.DECIMAL),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_STRING",      getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_ROWS",        getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS",        getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MORE_IND",          getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"OUT_BATCH_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
	 }
	
	public SPCreateCalcDetail(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_CREATE_CALC_DTL, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		VamDO vamDO = (VamDO)inputMap.get("vamDO");
		_LOGGER.info("input DO::"+vamDO);
		String vacString = (String)inputMap.get("vacString");
		String inputRows = (String)inputMap.get("inputRows");
		String totalRows = (String)inputMap.get("totalRows");
		String moreInd = (String)inputMap.get("moreInd");
		
		if (vamDO == null){
			throw new Exception("SPCreateCalcDetail: input data object is null");
		}
		if (vacString == null){
			throw new Exception("SPCreateCalcDetail: input vacString String is null");
		}
		if (inputRows == null){
			throw new Exception("SPCreateCalcDetail: input inputRows String is null");
		}
		if (totalRows == null){
			throw new Exception("SPCreateCalcDetail: input totalRows String is null");
		}
		if (moreInd == null){
			throw new Exception("SPCreateCalcDetail: input moreInd String is null");
		}

		String formatIn = "MM/dd/yyyy";
		String formatOut = "yyyy-MM-dd";
		//convert date user entered into date db2 can use.
		String fromDate = CommonUtil.formatDate(vamDO.getFromDate(), formatIn, formatOut);
		String thruDate = CommonUtil.formatDate(vamDO.getThruDate(), formatIn, formatOut);
		
		String batchId = (String)inputMap.get("batchId");

		//vac does not like empty string in subtype, if get empty string set it to null
		String subType = vamDO.getSubType();
		if (subType != null)
			if (subType.trim().equals(""))
				subType = null;
		
		/* display inputs */
		_LOGGER.info("fromDate db2 ::"+fromDate);
		_LOGGER.info("thruDate db2 ::"+thruDate);
		
		_LOGGER.info("vac input string ::"+vacString);
		
		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add(vamDO.getClaimNumber());  //ESG_CLAIM_NUMBER    
		callList.add(vamDO.getBan());      // BAN             
		callList.add(vamDO.getMan());      // MAN               
		callList.add(vamDO.getVzid());     // ORIGINATOR_VZID
		callList.add(vamDO.getOsid());     // ORIGINATING_SYS_ID
		callList.add(vamDO.getCreditType()); // CALC_TYPE
		callList.add(subType);             //CALC_SUB_TYPE
		callList.add(vamDO.getServiceId());// SERVICE_ID    
		callList.add(fromDate);            // CALC_FROM_DT         
		callList.add(thruDate);            // CALC_THRU_DT
		callList.add(vamDO.getCallTypeText()); // CALL_TYPE
		callList.add(vamDO.getOrigTermTypeText()); // ORIG_TERM_TYPE
		callList.add(vamDO.getTermCountryText()); // TERM_COUNTRY
		callList.add(vamDO.getTermStateText()); // TERM_STATE
		callList.add(vamDO.getCreditMethod()); // CREDIT_METHOD
		callList.add(batchId!=null?new BigDecimal(batchId):null); // IN_BATCH_ID
		callList.add(vacString);         // INPUT_STRING
		callList.add(Integer.valueOf(inputRows));      // INPUT_ROWS
		callList.add(Integer.valueOf(totalRows));      // TOTAL_ROWS
		callList.add(moreInd);      // MORE_IND
		
		/* execute sp */
		Map resMap = executeSP(callList, false);
		
		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
