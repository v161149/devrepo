package com.verizon.enterprise.ncasbosi.dao.Impl.admin;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.Interface.admin.AdminCompareInterface;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import javax.sql.DataSource;
import com.verizon.enterprise.common.ncas.admin.CompareEcpDb;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

import org.springframework.jdbc.object.MappingSqlQuery;

import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;



public class AdminCompareDAOImpl extends JdbcDaoSupport implements AdminCompareInterface, NCASBOSIConstants {

	private static final Logger _LOGGER = Logger.getLogger(AdminCompareDAOImpl.class);

		
	private SelectCompareDBdetails selectCompareDBdetails;

	String SELECT_COMPARE_ECP_XLS ="SELECT METH.METHOD_OID,METH.NAME,PERM.ACRONYM,PERMISSION_METHOD_MAP_OID FROM METHOD METH, PERMISSION PERM, MODULE ABC, PERMISSION_METHOD_MAP DEF WHERE ABC.MODULE_OID = 155 AND METH.MODULE_OID =  155  AND METH.METHOD_OID = DEF.METHOD_OID AND DEF.PERMISSION_OID = PERM.PERMISSION_OID ORDER BY METH.NAME";
	Map<String,CompareEcpDb>  dataMap = null;
	//List<CompareEcpDb> compecpList = new ArrayList<CompareEcpDb>();
	
	abstract class AbstractSelect extends MappingSqlQuery{

		public AbstractSelect(DataSource dataSource,String sql){
			super(dataSource,sql);
		}

	}

	
	class SelectCompareDBdetails extends AbstractSelect{
		public SelectCompareDBdetails(DataSource dataSource){
			super(dataSource,SELECT_COMPARE_ECP_XLS);
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
			CompareEcpDb comparecpdb = null;
			double methodoid = rs.getDouble("METHOD_OID");
			String name = rs.getString("NAME");
			String acronym = rs.getString("ACRONYM");
			double permission = rs.getDouble("PERMISSION_METHOD_MAP_OID");
			comparecpdb = new CompareEcpDb(methodoid, name, acronym, permission);
			dataMap.put(comparecpdb.getKey(), comparecpdb);
			return comparecpdb;
		}
	}

	public Map<String,CompareEcpDb>  selectCompareDBdetails() throws NCASException {
		 _LOGGER.info("Select SQL: " + SELECT_COMPARE_ECP_XLS);
		 dataMap = new LinkedHashMap<String,CompareEcpDb>();
		 selectCompareDBdetails = new SelectCompareDBdetails(getDataSource()) ;
		 selectCompareDBdetails.execute(new Object[]{});
		 _LOGGER.info("Exiting selectCompareDBdetails");
		 return dataMap;
		}
	
	//_LOGGER.info("Exiting selectCompareDBdetails"+compecpList.size());
	
}
	





