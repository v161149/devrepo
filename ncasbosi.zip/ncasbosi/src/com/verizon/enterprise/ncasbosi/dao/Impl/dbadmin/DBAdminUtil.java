package com.verizon.enterprise.ncasbosi.dao.Impl.dbadmin;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.NCASDataUtil;

public final class DBAdminUtil  {
	
	static private final Logger _LOGGER = Logger.getLogger(DBAdminUtil.class);
	
	private DBAdminUtil() {
	}
	public static int randomNumber(int min, int max) {
		return min + (new Random()).nextInt(max-min);
	}
	public static int randomNumberGenerator(int min, int max, int dbArray[]) {
	    boolean checkNumber = false;
	    int dbArrayLn= dbArray.length;
		int randomNumber =  randomNumber(min, max);
		randomsearch:
		for(int i=0; i< dbArrayLn; i++){
			if(randomNumber == dbArray[i]) {
				checkNumber = true;
				break randomsearch;
			} 
		}
			if(checkNumber) {
				randomNumberGenerator(min, max, dbArray);
			}
		return randomNumber;	
	}
	/**
	 * Method responsible for creating treeMap from the given billViewMap
	 * markup and extlink implementations to be added
	 * @param billViewMap
	 * @param markupMap
	 * @param extLinkMap
	 * @return
	 * @throws Exception
	 */
	public static String generatePageNavigatorXml(Map billViewMap, Map markupMap, Map buttonMap)throws Exception
	{
		_LOGGER.info("Entering createPageNavigatorXml ");		
		PageNavigatorXmlHelper pnHelper = new PageNavigatorXmlHelper();
		TreeMap billViewTree = null;
		String pageNavXml = null;
		String key = null;
		//billView Map needs to be sorted inorder to create pages in their natural order
		try
		{
			if(billViewMap != null && billViewMap.size() > 0)
			{
				billViewTree = new TreeMap();
				 for(Iterator itr = billViewMap.keySet().iterator(); itr.hasNext();)
				  {
					key = (String)itr.next();
					billViewTree.put(key, billViewMap.get(key));  
				  }
				 _LOGGER.info("treeMap created from the regular billViewMap");
				 pageNavXml= pnHelper.generatePageNavigatorXml(billViewTree, markupMap, buttonMap);
			}
			
		}
		catch(Exception xmlEx)
		{
			_LOGGER.error("Exception in creating PageNavigator XML "+ xmlEx);
		}
		_LOGGER.info("Exiting createPageNavigatorXml ");
		return pageNavXml; 
	}
}

