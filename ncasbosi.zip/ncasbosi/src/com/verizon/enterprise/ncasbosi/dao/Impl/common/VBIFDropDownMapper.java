package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.domain.SelectOption;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

/*
 * Author:Anand Lourdes/v778093
 */

public class VBIFDropDownMapper implements RowMapper {
	
	private static final Logger _LOGGER = Logger.getLogger(VBIFDropDownMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("VBIFDropDownMapper - Mapping Row# "+rowNum);
		SelectOption selectOption = null;
		String columnName = null;
		selectOption = new SelectOption(trimSpace(rs.getString(3)),trimSpace(rs.getString(2)));//treating the first argument(getString(2)) as text and the second(getString(1)) as code which will be behind the text in the dropdown.		
		_LOGGER.info("select option::"+selectOption);
		return selectOption;
	}
	
	//Trimmer to remove spaces that VAC sends
	private String trimSpace(String input){
		return input!=null?input.trim():input;
	}
}
