package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import java.math.BigDecimal;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * Author:Ram/v992473
 * This class represents the VAC api RETARGET_VZB_ADJ
 */
public class SPRetargetAdjustment extends BaseStoredProcedure{

	private static final Logger _LOGGER = Logger.getLogger(SPRetargetAdjustment.class);
	private static List spInOutList;
	
	static{
		_LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
		 spInOutList.add(new Object[]{"VAC_ADJUST_ID",getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_VZID",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TARGET_ADJ_AMOUNT",getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TARGET_INVOICE_DT",getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TARGET_INVOICE_NUM",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CLM_STATUS",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS_DESC",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUB_STATUS",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUBSTATUS_DESC",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		
	}
	
	public SPRetargetAdjustment(DataSource dataSource){
		super(dataSource,NCASBOSIConstants.SP_RETARGET_VZB_ADJ,spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map inputMap = (HashMap)input;
		_LOGGER.info("InputMap::"+inputMap);
		List inputList = new ArrayList();
		inputList.add(new BigDecimal((String)inputMap.get("VAC_ADJUST_ID")));//VAC_ADJUST_ID
		inputList.add((String)inputMap.get("LAST_UPD_VZID"));//LAST_UPD_VZID
		inputList.add(new BigDecimal((String)inputMap.get("TARGET_ADJ_AMOUNT")));//TARGET_ADJ_AMOUNT
		inputList.add((String)inputMap.get("TARGET_INVOICE_DT"));//TARGET_INVOICE_DT
		inputList.add((String)inputMap.get("TARGET_INVOICE_NUM"));//TARGET_INVOICE_NUM
		Map resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
