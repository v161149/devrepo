package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.autocredit.BillingElement;

/*
 * get late payment charges for all bills between from date and thru date.
 * this api is not called by ul directly, the get adjustments api calls this.
 */

public class SPCalcActAdjs extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPCalcActAdjs.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();

		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ACTION",       getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_STRING",      getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_ROWS",        getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS",        getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MORE_IND",          getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_TYPE",         getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_SUB_TYPE",         getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_VZID",   getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SERVICE_ID",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BATCH_ID",          getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"DUPE_FOUND",   getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	 }

	public SPCalcActAdjs(DataSource dataSource){
		super(dataSource, getVACSchemaName() + "." + NCASBOSIConstants.SP_CALC_ACT_ADJS, spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		VamDO vamDO = (VamDO)inputMap.get("vamDO");
		_LOGGER.info("input DO::"+vamDO);
		String vacString = (String)inputMap.get("vacString");
		String inputRows = (String)inputMap.get("inputRows");
		String totalRows = (String)inputMap.get("totalRows");
		String moreInd = (String)inputMap.get("moreInd");
		String batchId = (String)inputMap.get("batchId");

		if (vamDO == null){
			throw new Exception("SPCalcActAdjs: input data object is null");
		}
		if (vacString == null){
			throw new Exception("SPCalcActAdjs: input vacString String is null");
		}
		if (inputRows == null){
			throw new Exception("SPCalcActAdjs: input inputRows String is null");
		}
		if (totalRows == null){
			throw new Exception("SPCalcActAdjs: input totalRows String is null");
		}
		if (moreInd == null){
			throw new Exception("SPCalcActAdjs: input moreInd String is null");
		}

		String formatIn = "MM/dd/yyyy";
		String formatOut = "yyyy-MM-dd";
		//convert date user entered into date db2 can use.
		String fromDate = CommonUtil.formatDate(vamDO.getFromDate(), formatIn, formatOut);
		String thruDate = CommonUtil.formatDate(vamDO.getThruDate(), formatIn, formatOut);

		/* display inputs */
		_LOGGER.info("fromDate db2 ::"+fromDate);
		_LOGGER.info("thruDate db2 ::"+thruDate);

		_LOGGER.info("vac input string ::"+vacString);

		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add(vamDO.getClaimNumber());  //ESG_CLAIM_NUMBER
		callList.add(vamDO.getButtonClicked());      // USER_ACTION
		callList.add(vacString);         // INPUT_STRING
		callList.add(inputRows);      // INPUT_ROWS
		callList.add(totalRows);      // TOTAL_ROWS
		callList.add(moreInd);      // MORE_IND
		callList.add(vamDO.getCreditType()); // CALC_TYPE
		callList.add(nullVal(vamDO.getSubType())); // CALC_SUB_TYPE
		callList.add(vamDO.getVzid());     // ORIGINATOR_VZID
		callList.add(vamDO.getServiceId());// SERVICE_ID
		callList.add(null);// BATCH_ID

		/* execute sp */
		Map resMap = executeSP(callList, false);

		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}

	private String nullVal(String input)
	{
		if (input == null)
			return null;
		if (input.equals(""))
			return null;
		return input;
	}


	/**
	 * @param input
	 * @return
	 * @throws Exception
	 *
	 * This is called on action = override_duplicate
	 */
	public Map executeStoredProcedure_OverrideDuplicate(Object input)throws Exception{
		_LOGGER.info("Entering executeStoredProcedure_OverrideDuplicate in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		String esgClaimNumber = (String)inputMap.get("CLM_NUM");
		String batchId = (String)inputMap.get("BATCH_ID");

		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add(esgClaimNumber);  //ESG_CLAIM_NUMBER
		callList.add("OVERRIDE_DUPLICATE");      // USER_ACTION
		callList.add(null);         // INPUT_STRING
		callList.add(null);      // INPUT_ROWS
		callList.add(null);      // TOTAL_ROWS
		callList.add(null);      // MORE_IND
		callList.add(null); // CALC_TYPE
		callList.add(null); // CALC_SUB_TYPE
		callList.add(null);     // ORIGINATOR_VZID
		callList.add(null);// SERVICE_ID
		if(batchId==null || batchId.trim().length()==0){
			callList.add(null);// BATCH_ID
		}else{
			callList.add(batchId);// BATCH_ID
		}

		/* execute sp */
		Map resMap = executeSP(callList, false);

		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);

		_LOGGER.info("Exiting executeStoredProcedure_OverrideDuplicate in "+getStoredProcedureName());
		return resMap;
	}
}
