package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import org.apache.log4j.Logger;

public class SPDownloadsEmediaProfileAccounts extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetEMediaAccounts.class);	
	private static List<Object[]> spInOutList;
	private String profileType;
			
	static
	{
		 spInOutList = new ArrayList<Object[]>();
		 
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RECREATE_PROF_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RQST_MONTH", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RQST_YEAR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPDownloadsEmediaProfileAccounts(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_EM_ACCTS, getInoutList());	
	}
	
	//forms a new in/out List with unique mapper object bound to each SP call 
	private static List getInoutList(){
		List<Object[]> inOutList = new ArrayList<Object[]>();
		inOutList.add(new Object[]{"records",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new DownloadProfileAccountsRowMapperImpl()});
		inOutList.addAll(spInOutList);
		return inOutList;
	}
	
	public Content executeStoredProcedure(String userId, String debugLevel, 
							String configSubscriptionOid,  String whereFilter, 
							String sortOrder) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		
		Map resultMap = new HashMap();
		paramValueList.add(configSubscriptionOid);//CONFIG_SUBS_OID
		paramValueList.add("C");//RECREATE_PROF_IND
		paramValueList.add("");//RQST_MONTH
		paramValueList.add("");//RQST_YEAR
		paramValueList.add(whereFilter);//WHERE_FILTER
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add("1");//PAGE_OFFSET
		paramValueList.add("10000");//PAGE_SIZE
		
		//populate profileType of the DownloadProfileAccounts Mapper class before executing the stored procedure
		Object[] resultSetDeclarationArray = (Object[])this.getAllParamList().get(0);
		DownloadProfileAccountsRowMapperImpl downloadProfileAccounts = (DownloadProfileAccountsRowMapperImpl)resultSetDeclarationArray[3];
		downloadProfileAccounts.setProfileType(getProfileType());
		
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);	
		List actualList = (List)procMap.get("records");
		Content retObj = new Content();
		retObj.setRows(actualList);

		return retObj ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
}

