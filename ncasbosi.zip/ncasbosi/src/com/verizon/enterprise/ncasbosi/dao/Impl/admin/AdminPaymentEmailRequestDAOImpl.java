package com.verizon.enterprise.ncasbosi.dao.Impl.admin;

import org.springframework.jdbc.core.RowCallbackHandler;
import org.apache.log4j.Logger;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncasbosi.beans.paymentsEmailRequest;
import com.verizon.enterprise.common.ncasbosi.beans.memobillEmailRequest;
import com.verizon.enterprise.ncasbosi.dao.Interface.admin.AdminPaymentEmailRequestinterface;




public class AdminPaymentEmailRequestDAOImpl extends NCASSpringJDBCBase implements AdminPaymentEmailRequestinterface, NCASBOSIConstants {


     private static final Logger _LOGGER = Logger.getLogger(AdminPaymentEmailRequestDAOImpl.class);

      public Map selectPaymentEmailDetailsRequest(String FromDate,String ToDate) throws RemoteException, NCASException {

    	  final List Paymentresponselist = new ArrayList();
    	  List EmailResponse = new ArrayList();
    	  Map resMap = new HashMap();
       paymentsEmailRequest paymentsEmailRequestObj = null;
	 		 boolean status_id;

	// String user = adminPermission.getUserId();
	// final List modules = new ArrayList();
     final List<Double> emailTrackingOidList = new ArrayList();
	 String SELECT_PL_PAY_EMAIL = "SELECT PAY_EMAIL_OID,EMAIL_TRACKING_OID,USER_EMAIL_ADDR FROM BMGVZP.PL_PAY_EMAIL  WHERE DATE(LAST_UPD_TIMESTAMP) BETWEEN '" + FromDate + "' AND '" + ToDate + "' ORDER BY LAST_UPD_TIMESTAMP DESC";

	 _LOGGER.info(" SELECT_PL_PAY_EMAIL Select SQL:----------> " + SELECT_PL_PAY_EMAIL);
	    try {

	    	vamJdbcTemplate.query(SELECT_PL_PAY_EMAIL, new RowCallbackHandler() {
	    		int Pay_email_oid;
	    		double Email_tracking_oid =0.0;
	    		String User_mail_addr;
	    	  public void processRow(ResultSet rs) throws SQLException {

	        	Email_tracking_oid = rs.getDouble("EMAIL_TRACKING_OID");
	        	if(Email_tracking_oid != 0.0)
	        	{
	        	Pay_email_oid = rs.getInt("PAY_EMAIL_OID");
	        	emailTrackingOidList.add(Double.valueOf(Email_tracking_oid));
	        	User_mail_addr = rs.getString("USER_EMAIL_ADDR");
	        	Paymentresponselist.add(new paymentsEmailRequest(Pay_email_oid,Email_tracking_oid,User_mail_addr));
	        	}
	        	//selectMaildataDetailsRequest(Email_tracking_oid);

	           // modules.add((String)rs.getString("MODULE"));


               _LOGGER.info("Paymentresponselist :----------> " + Paymentresponselist);
	        }
	      });
	      _LOGGER.info("emailTrackingOidList::"+emailTrackingOidList);

	      status_id = emailTrackingOidList.isEmpty();
          if(status_id == false)
             {
	                EmailResponse = selectMaildataDetailsRequest(emailTrackingOidList);
             }


	      _LOGGER.info("EmailResponse is:----------> " + EmailResponse);
	    }
	    catch (Exception vamEx) {
	      _LOGGER.debug("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
	       throw new NCASException(NCASBOSIConstants.EMAIL_STATUS_EXCEPTION,AdminPaymentEmailRequestDAOImpl.class, vamEx);
	    }
	    _LOGGER.debug("Paymentresponselist" + Paymentresponselist);
	    resMap.put("PAYMENTLIST", Paymentresponselist);
        resMap.put("MAILLIST", EmailResponse);
        return resMap;

}
 public List selectMaildataDetailsRequest(List<Double> emailTrackingOidList) throws NCASException {
     final List Mailresponselist = new ArrayList();
	 paymentsEmailRequest paymentsEmailRequestObj = null;

	// String user = adminPermission.getUserId();
	// final List modules = new ArrayList();
	   boolean first = true;
       String SELECT_MAIL_DATA = "select MAIL_DATA_OID,STATUS_MESSAGE,TO_ADDRESS,SUBJECT,RETURN_TIME,MAIL_CONTENT from ESG.MAIL_DATA where MAIL_DATA_OID IN (";
	    try {
	    	for(Double doubleObject: emailTrackingOidList){
	    		if(first){
	    			first=false;
	    			SELECT_MAIL_DATA += doubleObject.doubleValue();
	    		}
	    		else{
	    			SELECT_MAIL_DATA += "," + doubleObject.doubleValue();
	    		}
	        }
	    	SELECT_MAIL_DATA += ")" ;
	   	 _LOGGER.info("SELECT_MAIL_DATA Select SQL: " + SELECT_MAIL_DATA);

	    	ecpJdbcTemplate.query(SELECT_MAIL_DATA, new RowCallbackHandler() {

	    	  public void processRow(ResultSet rs) throws SQLException {
	        	double Email_tracking_oid = rs.getDouble("MAIL_DATA_OID");
	        	String Status_Message = rs.getString("STATUS_MESSAGE");
                 String To_Address = rs.getString("TO_ADDRESS");
                 String Subject = rs.getString("SUBJECT");
                 String Return_Time = rs.getString("RETURN_TIME");
                 String Mail_Content = rs.getString("MAIL_CONTENT");


	           // modules.add((String)rs.getString("MODULE"));

               Mailresponselist.add(new paymentsEmailRequest(Email_tracking_oid,Status_Message,To_Address,Subject,Return_Time,Mail_Content));
	        }
	      });

	    }
	    catch (Exception vamEx) {
	      _LOGGER.debug("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());

   throw new NCASException(NCASBOSIConstants.EMAIL_STATUS_EXCEPTION,AdminPaymentEmailRequestDAOImpl.class, vamEx);
	    }
	    _LOGGER.debug("Mailresponselist size" + Mailresponselist.size());

	   return Mailresponselist;
}
	// code for memo bill



public List selectMemobilldataDetailsRequest(List<Integer> requestidList) throws NCASException {
final List Mailresponselist = new ArrayList();
memobillEmailRequest MemobillEmailRequestObj = null;

// String user = adminPermission.getUserId();
// final List modules = new ArrayList();
  boolean first = true;
  String SELECT_MAIL_DATA = "select USER_ID,STATUS_MESSAGE,TO_ADDRESS,SUBJECT,RETURN_TIME,MAIL_CONTENT from ESG.MAIL_DATA where SENDER_USER_OID IN (";
   try {
   	for(Integer intObject: requestidList){
   		if(first){
   			first=false;
   			SELECT_MAIL_DATA += intObject.intValue();
   		}
   		else{
   			SELECT_MAIL_DATA += "," + intObject.intValue();
   		}
       }
   	SELECT_MAIL_DATA += ")" ;
  	 _LOGGER.info("SELECT_MAIL_DATA Select SQL: " + SELECT_MAIL_DATA);

   	ecpJdbcTemplate.query(SELECT_MAIL_DATA, new RowCallbackHandler() {

   	  public void processRow(ResultSet rs) throws SQLException {
       	    int userid = rs.getInt("USER_ID");
       	    String Status_Message = rs.getString("STATUS_MESSAGE");
            String To_Address = rs.getString("TO_ADDRESS");
            String Subject = rs.getString("SUBJECT");
            String Return_Time = rs.getString("RETURN_TIME");
            String Mail_Content = rs.getString("MAIL_CONTENT");


          // modules.add((String)rs.getString("MODULE"));

          Mailresponselist.add(new memobillEmailRequest(userid,Status_Message,To_Address,Subject,Return_Time,Mail_Content));
       }
     });

   }
   catch (Exception vamEx) {
     _LOGGER.debug("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
     _LOGGER.error("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
     throw new NCASException(NCASBOSIConstants.EMAIL_STATUS_EXCEPTION,AdminPaymentEmailRequestDAOImpl.class, vamEx);
   }
   _LOGGER.debug("Mailresponselist size" + Mailresponselist.size());

  return Mailresponselist;
}

public Map selectMemobillEmailDetailsRequest(String FromDate,String ToDate,String loginid,String Memo_date, String type,String status) throws RemoteException, NCASException {

	  final List Plreqstatuslist = new ArrayList();

	  Map resMap = new HashMap();
	  memobillEmailRequest MemobillEmailRequestObj = null;
      boolean status_id;

      _LOGGER.info(" Memo date:----------> " + Memo_date);
      String baseSql = "SELECT REQUEST_ID,TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,PARAM6,PARAM7,STATUS,ITERATION,ERROR_MSG,PORTAL,EMPLOYEE_FLAG,LOGINID,LAST_UPDATED_BY,LAST_UPDATED FROM BMGVZP.PL_REQSTATUS  WHERE DATE(CREATED_TIMESTAMP) BETWEEN '" + FromDate + "' AND '" + ToDate+"'";
      String selectSql;
   try {
	   selectSql = baseSql;
	   if(!Memo_date.trim().equals("-"))
		   selectSql +=  " AND PARAM7 = '" + Memo_date + "'";
	   if(!loginid.trim().isEmpty())
		   selectSql +=  " AND UCASE(LOGINID) = '" + loginid.trim().toUpperCase() + "'";
	   if(!type.trim().isEmpty())
		   selectSql +=  " AND TYPE = '" + type+ "'";
	   if(!status.trim().isEmpty())
		   selectSql +=  " AND STATUS = '" + status+ "'";

	   selectSql +=  " ORDER BY LAST_UPDATED DESC";



	   _LOGGER.info(" SELECT_PL_REQSTATUS Select SQL:----------> " + selectSql);
   	vamJdbcTemplate.query(selectSql, new RowCallbackHandler() {

   		int request_id=0;
   		String param1;
   		String param2;
   		String param3;
   		String param4;
   		String param5;
   		String param6;
   		String param7;
   		int iteration;
   		String status;
   		String last_updated;
   		String login_id;
   		String Type=null;
		String Error_msg=null;
		String Portal=null;
		String Employee_Flag=null;
		String Last_Updated_by=null;

   	  public void processRow(ResultSet rs) throws SQLException {

   		request_id = rs.getInt("REQUEST_ID");
       	if(request_id != 0)
       	{
        Type=rs.getString("TYPE");
        param1=rs.getString("PARAM1");
        param2=rs.getString("PARAM2");
        param3=rs.getString("PARAM3");
        param4=rs.getString("PARAM4");
        param5=rs.getString("PARAM5");
        param6=rs.getString("PARAM6");
        param7=rs.getString("PARAM7");
        iteration=rs.getInt("ITERATION");
        status=rs.getString("STATUS");
        Error_msg=rs.getString("ERROR_MSG");
        Portal=rs.getString("PORTAL");
        Employee_Flag=rs.getString("EMPLOYEE_FLAG");
        login_id=rs.getString("LOGINID");
        Last_Updated_by=rs.getString("LAST_UPDATED_BY");
        last_updated=rs.getString("LAST_UPDATED");


       	Plreqstatuslist.add(new memobillEmailRequest(request_id,Type,param1,param2,param3,param4,param5,param6,param7,status,iteration,Error_msg,Portal,Employee_Flag,login_id,Last_Updated_by,last_updated));
       	}

          _LOGGER.info("Plreqstatuslist :----------> " + Plreqstatuslist);
       }
     });

   }
   catch (Exception vamEx) {
     _LOGGER.debug("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
     _LOGGER.error("SELECT_PL_PAY_EMAIL in VAM Failed \n" +vamEx.getMessage());
     throw new NCASException(NCASBOSIConstants.EMAIL_STATUS_EXCEPTION,AdminPaymentEmailRequestDAOImpl.class, vamEx);
   }
   _LOGGER.debug("Plreqstatuslist" + Plreqstatuslist);
   resMap.put("PLREQDETAILSSTATUS", Plreqstatuslist);

   return resMap;

}
}











