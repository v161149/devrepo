package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.approval.ApprovalAudit;
import com.verizon.enterprise.common.ncas.approval.UserDelegation;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.approval.Designation;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface;

/**
 * This class is the impl class that has all the data access code for approval_audit project
 * This class extends JdbcDaoSupport so that it gets the DataSource object and
 * also the JdbcTemplate object which is core object that provides apis for all database operations
 * This class uses spring's JdbcTemplate and SqlUpdate objects to perform data access operations
 *
 */
public class ApprovalAuditDAOImpl extends JdbcDaoSupport implements ApprovalAuditInterface{

	private String APPROVAL_AUDIT_TABLE = NCASBOSIConstants.VAC_TABLESCHEMA + ".VAC_APPROVAL_AUDIT_T";
	/**
	 * mapper object to converts resulset rows into ApprovalAudit objects
	 */
	private ApprovalAuditDAOImpl.ApprovalAuditRowMapperImpl.AuditMapperWithParams auditRowMapper;
	/**
	 * mapperImpl class which actually has that mapper object enclosed in it
	 *
	 */
	private ApprovalAuditDAOImpl.ApprovalAuditRowMapperImpl  mapperImpl;
	private SqlUpdate insertApproval;
	private SqlUpdate updateApproval;

	// Designation Functions
	private VBIFGetActiveDesignee vbifGetActiveDesignee = null;
	private VBIFGetActiveiCIUser vbifGetActiveiCIUser = null;
	private VBIFInsertDesignation vbifInsertDesignation = null;
	private VBIFUpdateDesignation vbifUpdateDesignation = null;
	private VBIFDeleteDesignation vbifDeleteDesignation = null;	

	//SQL Queries
	private String INSERT_APPROVAL_AUDIT_QUERY = "INSERT INTO "+APPROVAL_AUDIT_TABLE+"(SRC_SYS_BI_ID,"+
			"APPROVAL_AMOUNT,APPROVER_VZID,APPROVER_FIRSTNAME,APPROVER_LASTNAME,APPROVER_CAR_BAND," +
			"APPROVER_MAN_LEVEL,APPROVER_AMT_LIMIT,CUSTOM_APPROVER,ASSIGNED_TIMESTAMP,ACTION_TIMESTAMP,"+
			"USER_ACTION,DESIGNATOR_VZID,DESIGNATOR_FNAME,DESIGNATOR_LNAME,APPROVAL_COMPLETE,"+
			"LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private String UPDATE_APPROVAL_AUDIT_QUERY = "UPDATE "+APPROVAL_AUDIT_TABLE+" SET APPROVER_CAR_BAND = ?,APPROVER_MAN_LEVEL = ?,"+
			"APPROVER_AMT_LIMIT = ?,CUSTOM_APPROVER = ?,ACTION_TIMESTAMP = ?,USER_ACTION = ?,"+
			"DESIGNATOR_VZID = ?,DESIGNATOR_FNAME = ?,DESIGNATOR_LNAME = ?,APPROVAL_COMPLETE = ?,"+
			"LAST_UPDATED_BY = ?,LAST_UPD_TIMESTAMP = ? WHERE APPROVAL_ROW_ID = ?";
	private String SELECT_AUDIT_ROWS_FOR_APPROVER = "select * from "+APPROVAL_AUDIT_TABLE+" where src_sys_bi_id=? and approver_vzid=? and user_action is NULL";
	private String COUNT_AUDIT_ROWS_FOR_TKT = "select count(*) from "+APPROVAL_AUDIT_TABLE+" where src_sys_bi_id=?";
	private String SELECT_AUDIT_ROWS_FOR_TKT_N = "SELECT AA.*, BC.COMMENT_TEXT FROM " + APPROVAL_AUDIT_TABLE + " AA LEFT OUTER JOIN " +
                     " (SELECT COMMENT_TEXT, SRC_SYS_COMMENT_ID FROM " + NCASBOSIConstants.VAC_TABLESCHEMA + ".VAC_BI_COMMENT " + 
                     " WHERE SRC_SYS_BI_ID = ?  AND SRC_SYS_COMMENT_ID IS NOT NULL) BC " +
                     " ON CHAR(AA.APPROVAL_ROW_ID) = BC.SRC_SYS_COMMENT_ID " +
                     " WHERE AA.SRC_SYS_BI_ID = ? ORDER BY AA.LAST_UPD_TIMESTAMP DESC FOR FETCH ONLY WITH UR";
	private String SELECT_AUDIT_ROWS_FOR_TKT = "SELECT * FROM "+APPROVAL_AUDIT_TABLE+" WHERE SRC_SYS_BI_ID=? ORDER BY LAST_UPD_TIMESTAMP DESC";
	private String COUNT_AUDIT_ROWS_FOR_APPROVER = "SELECT COUNT(*) FROM "+APPROVAL_AUDIT_TABLE+" WHERE APPROVER_VZID=? AND USER_ACTION IS NULL WITH UR";
	private String SELECT_NCAS_APPROVAL_RULES = "SELECT * FROM "+NCASBOSIConstants.VAC_TABLESCHEMA+".NCAS_APPROVAL_RULES_T ? WITH UR";
	private String SELECT_APPROVAL_AMT_LIMIT = "SELECT * FROM "+NCASBOSIConstants.VAC_TABLESCHEMA+".CLM_APPROVAL_REF_T WHERE CAREER_BAND=? AND MANAGER_LEVEL=? WITH UR";
	private String SELECT_APPR_LIST_OF_CUST_APPROVERS_BY_TKT = "SELECT * FROM "+APPROVAL_AUDIT_TABLE+" WHERE SRC_SYS_BI_ID = ? AND USER_ACTION = 'CUSTOM' ORDER BY ACTION_TIMESTAMP DESC";
	private String SELECT_DESIGNEE_BY_DESIGNATOR = "SELECT * FROM "+NCASBOSIConstants.VAC_TABLESCHEMA+".VAC_DESIGNATION_T WHERE DESIGNATOR_VZID = ? AND START_DATE <= (CURRENT DATE) AND END_DATE >= (CURRENT DATE)";

	private int[] singleVarcharTypeArray = new int[]{Types.VARCHAR};
	private int[] doubleVarcharTypeArray = new int[]{Types.VARCHAR,Types.VARCHAR};
	private int[] doubleCharTypeArray = new int[]{Types.CHAR,Types.CHAR};

	// Designee SQL Queries
	/** Select all active designee list	*/
	public static final String SELECT_ACTIVE_DESIGNEE = "SELECT RTRIM (C.LAST_NAME) || ', '|| RTRIM(C.FIRST_NAME) AS DESIGNATOR, A.DESIGNATOR_VZID,  " +
			"RTRIM(E.LAST_NAME) || ', '  || RTRIM(E.FIRST_NAME) AS APPROVER, A.APPROVER_VZID, A.START_DATE, A.END_DATE, A.LAST_UPDATED_BY, A.LAST_UPD_TIMESTAMP " +
			"FROM VARVZP.VAC_DESIGNATION_T A, "+ NCASBOSIConstants.VAM_SCHEMA +".USER_PROFILE B, "+ NCASBOSIConstants.VAM_SCHEMA +".PERSON C, "+ NCASBOSIConstants.VAM_SCHEMA +".USER_PROFILE D, "+ NCASBOSIConstants.VAM_SCHEMA +".PERSON E " +
			"WHERE A.DESIGNATOR_VZID = B.LOGIN_ID AND B.PERSON_OID = C.PERSON_OID AND APPROVER_VZID = D.LOGIN_ID AND D.PERSON_OID = E.PERSON_OID AND B.STATUS = 'A' " +
			"AND D.STATUS = 'A' AND A.END_DATE >= (CURRENT DATE)";

	/** Select all active iCI User */
	public static final String SELECT_USER = "SELECT P.LAST_NAME, P.FIRST_NAME, UP.LOGIN_ID FROM "+ NCASBOSIConstants.VAM_SCHEMA +".PL_VBIF_USER_T VUSR, "+ NCASBOSIConstants.VAM_SCHEMA +".USER_PROFILE UP, "+ NCASBOSIConstants.VAM_SCHEMA +".PERSON P " +
			"WHERE VUSR.USER_OID = UP.USER_OID AND UP.PERSON_OID =  P.PERSON_OID AND VUSR.STATUS = 'A' AND UP.STATUS = 'A'";

	/** Insert new row in Designation table */
	public static final String INSERT_DESIGNATION = "INSERT INTO VARVZP.VAC_DESIGNATION_T (DESIGNATOR_VZID, APPROVER_VZID, START_DATE, END_DATE, LAST_UPDATED_BY, LAST_UPD_TIMESTAMP) VALUES (?, ?, ?, ?, ?, ?)";

	/** Update existing row in Designation table if valid */
	public static final String UPDATE_DESIGNATION = "UPDATE VARVZP.VAC_DESIGNATION_T SET START_DATE=?, END_DATE=?, LAST_UPDATED_BY=?, LAST_UPD_TIMESTAMP=? WHERE DESIGNATOR_VZID = ? AND APPROVER_VZID = ? AND END_DATE > DATE (current timestamp)";

	/** Permanent deletion of the desingee */
	public static final String DELETE_DESIGNATION = "DELETE FROM VARVZP.VAC_DESIGNATION_T WHERE DESIGNATOR_VZID=? AND APPROVER_VZID=? AND START_DATE=? AND END_DATE=?";

	public ApprovalAuditDAOImpl(){
		super();
		mapperImpl = new ApprovalAuditDAOImpl.ApprovalAuditRowMapperImpl();
		auditRowMapper =   mapperImpl.new AuditMapperWithParams();
	}


	/* (non-Javadoc)
	 * @see org.springframework.dao.support.DaoSupport#initDao()
	 * This method is called after all the bean properties have been set
	 */
	protected void initDao() throws Exception {
		super.initDao();
		//initialising DAO objects here
		//initialising insert Approval object - creating just one insert object for all requests
		int[] INSERT_APPROVAL_TYPES = new int[]{Types.VARCHAR,Types.DECIMAL,Types.VARCHAR,Types.VARCHAR,
									Types.VARCHAR,Types.CHAR,Types.CHAR,Types.DECIMAL,Types.CHAR,Types.TIMESTAMP,
									Types.TIMESTAMP,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
									Types.CHAR,Types.VARCHAR};
		insertApproval = new SqlUpdate(getJdbcTemplate().getDataSource(), INSERT_APPROVAL_AUDIT_QUERY, INSERT_APPROVAL_TYPES);
		insertApproval.setReturnGeneratedKeys(true);
		insertApproval.compile();

		//initialising update Approval object
		int[] UPDATE_APPROVAL_TYPES = new int[]{Types.CHAR,Types.CHAR,Types.DECIMAL,Types.CHAR,Types.TIMESTAMP,
				  Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.CHAR,
				  Types.VARCHAR,Types.TIMESTAMP,Types.INTEGER};
		updateApproval = new SqlUpdate(getJdbcTemplate().getDataSource(), UPDATE_APPROVAL_AUDIT_QUERY, UPDATE_APPROVAL_TYPES);
		updateApproval.compile();

		// Get Active Designee
		vbifGetActiveDesignee = new VBIFGetActiveDesignee(this.getJdbcTemplate());
		//Not Assigned User Search in Designation table
		vbifGetActiveiCIUser = new VBIFGetActiveiCIUser(this.getJdbcTemplate());
		//Inserting new row in Designation Table
		vbifInsertDesignation = new VBIFInsertDesignation(this.getDataSource(),INSERT_DESIGNATION);
		//Inserting new row in Designation Table
		vbifUpdateDesignation = new VBIFUpdateDesignation(this.getDataSource(),UPDATE_DESIGNATION);
		//Deleting row in Designation Table
		vbifDeleteDesignation = new VBIFDeleteDesignation(this.getDataSource(),DELETE_DESIGNATION);
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getApprovalAuditForApprover(java.util.Map)
	 * This method returns a approval audit row for a given approver
	 */
	public ApprovalAudit getApprovalAuditForApprover(Map<String, Object> param)throws NCASException {
		Map<String,Object> inMap = (Map<String,Object>)param;
		String ticketId = (String)inMap.get("SRC_SYS_BI_ID");
		String approverVZId = (String)inMap.get("APPROVER_VZID");
		Object[] params = new Object[]{ticketId,approverVZId};
		List<ApprovalAudit> auditList = (List<ApprovalAudit>)this.getJdbcTemplate().query(SELECT_AUDIT_ROWS_FOR_APPROVER, params, doubleVarcharTypeArray, auditRowMapper);
		if(auditList.size()>0){
			return auditList.get(0);
		}
		else{
			return null;
		}
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#insertApprovalAudit(com.verizon.enterprise.common.ncas.approval.ApprovalAudit)
	 * This method inserts an approval audit row into approval audit table
	 */
	public Integer insertApprovalAudit(ApprovalAudit audit)throws NCASException {
		Object[] params = new Object[]{audit.getTicketID(),new BigDecimal(audit.getApprovalAmount()),
				audit.getApproverVZID(),audit.getApproverFirstName(),audit.getApproverLastName(),
				audit.getApproverCareerBand(),audit.getApproverManagerLevel(),
				new BigDecimal(audit.getApproverApprovalAmountLimit()),audit.getCustomApprover(),audit.getAssignedTimestamp(),
				audit.getActionTimestamp(),audit.getUserAction(),audit.getDesignatorVZID(),
				audit.getDesignatorFirstName(),audit.getDesignatorLastName(),audit.getApprovalComplete(),
				audit.getLastUpdatedBy()};
		KeyHolder keyHolder = new GeneratedKeyHolder();
		insertApproval.update(params, keyHolder);
		return keyHolder.getKey().intValue();
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#updateApprovalAudit(com.verizon.enterprise.common.ncas.approval.ApprovalAudit)
	 * This method update a audit row in approval audit table
	 */
	public Integer updateApprovalAudit(ApprovalAudit audit)throws NCASException {
		Object[] params = new Object[]{audit.getApproverCareerBand(),audit.getApproverManagerLevel(),
						  new BigDecimal(audit.getApproverApprovalAmountLimit()),audit.getCustomApprover(),
						  audit.getActionTimestamp(),audit.getUserAction(),audit.getDesignatorVZID(),
						  audit.getDesignatorFirstName(),audit.getDesignatorLastName(),
						  audit.getApprovalComplete(),audit.getLastUpdatedBy(),getCurrentTimestamp(),
						  new Integer(audit.getApprovalRowID())};
		return updateApproval.update(params);
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getCountOfApprovalAuditsByTicketID(java.lang.String)
	 * This method counts the number of audit rows for a ticket id
	 */
	public Integer getCountOfApprovalAuditsByTicketID(String ticketId)throws NCASException {
		Object[] params = new Object[]{ticketId};
		return this.getJdbcTemplate().queryForInt(COUNT_AUDIT_ROWS_FOR_TKT, params, singleVarcharTypeArray);
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getApprovalAudits(java.lang.String)
	 * This method returns a list of approval audit rows for a ticket id - New version
	 */
	public List<ApprovalAudit> getApprovalAuditN(String tktId)throws NCASException {

		Object[] params = new Object[]{tktId,tktId};
		List<String> keys = Arrays.asList("COMMENT_TEXT");
		List<ApprovalAudit> auditList = (List<ApprovalAudit>)this.getJdbcTemplate().query(SELECT_AUDIT_ROWS_FOR_TKT_N, params, doubleVarcharTypeArray, mapperImpl.new AuditMapperWithParams(keys));
		return auditList;
	}
	
	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getApprovalAudits(java.lang.String)
	 * This method returns a list of approval audit rows for a ticket id
	 */
	public List<ApprovalAudit> getApprovalAudits(String tktId)throws NCASException {
		Object[] params = new Object[]{tktId};
		List<ApprovalAudit> auditList = (List<ApprovalAudit>)this.getJdbcTemplate().query(SELECT_AUDIT_ROWS_FOR_TKT, params, singleVarcharTypeArray, auditRowMapper);
		return auditList;
	}

	/**
	 * This is the row mapper class used to convert each row returned from audit table into ApprovalAudit object
	 *
	 */
	private static class ApprovalAuditRowMapperImpl {

			class AuditMapperWithParams implements RowMapper{
				List<String> keys;

				AuditMapperWithParams(List<String> keys) {
					this.keys = keys;
				}
				AuditMapperWithParams() {

				}
				public Object mapRow(ResultSet rs, int rowNum)throws SQLException {
					return ApprovalAuditRowMapperImpl.this.mapRow(rs, rowNum, keys);
				}
			}

			private Object mapRow(ResultSet rs, int rowNum,List<String> keys) throws SQLException {
				ApprovalAudit audit = null;
				if(rs!=null){
					audit = new ApprovalAudit();
					audit.setApprovalRowID(CommonUtil.trimSpace(rs.getString("APPROVAL_ROW_ID")));
					audit.setTicketID(CommonUtil.trimSpace(rs.getString("SRC_SYS_BI_ID")));
					audit.setApprovalAmount(commonUtil.formatNumber(rs.getBigDecimal("APPROVAL_AMOUNT"), "#,###,##0.00"));
					audit.setApproverVZID(CommonUtil.trimSpace(rs.getString("APPROVER_VZID")));
					audit.setApproverFirstName(CommonUtil.trimSpace(rs.getString("APPROVER_FIRSTNAME")));
					audit.setApproverLastName(CommonUtil.trimSpace(rs.getString("APPROVER_LASTNAME")));
					audit.setApproverCareerBand(CommonUtil.trimSpace(rs.getString("APPROVER_CAR_BAND")));
					audit.setApproverManagerLevel(CommonUtil.trimSpace(rs.getString("APPROVER_MAN_LEVEL")));
					audit.setApproverApprovalAmountLimit(commonUtil.formatNumber(rs.getBigDecimal("APPROVER_AMT_LIMIT"), "#,###,##0.00"));
					audit.setCustomApprover(CommonUtil.trimSpace(rs.getString("CUSTOM_APPROVER")));
					audit.setUserAction(CommonUtil.trimSpace(rs.getString("USER_ACTION")));
					audit.setDesignatorVZID(CommonUtil.trimSpace(rs.getString("DESIGNATOR_VZID")));
					audit.setDesignatorFirstName(CommonUtil.trimSpace(rs.getString("DESIGNATOR_FNAME")));
					audit.setDesignatorLastName(CommonUtil.trimSpace(rs.getString("DESIGNATOR_LNAME")));
					audit.setApprovalComplete(CommonUtil.trimSpace(rs.getString("APPROVAL_COMPLETE")));
					audit.setLastUpdatedBy(CommonUtil.trimSpace(rs.getString("LAST_UPDATED_BY")));
					//audit.setLastUpdatedTimestamp(CommonUtil.trimSpace(rs.getString("LAST_UPD_TIMESTAMP")));
					try{
						audit.setAssignedTimestamp(CommonUtil.getFormattedDateString(rs.getDate("ASSIGNED_TIMESTAMP"),"dd/MMM/yyyy HH.mm.ss"));
						audit.setActionTimestamp(CommonUtil.getFormattedDateString(rs.getDate("ACTION_TIMESTAMP"),"dd/MMM/yyyy HH.mm.ss"));
 						audit.setLastUpdatedTimestamp(CommonUtil.getFormattedDateString(rs.getDate("LAST_UPD_TIMESTAMP"),"dd/MMM/yyyy HH.mm.ss"));
					}catch (Exception e) {
						e.printStackTrace();//for now no logger
					}




					if(keys!=null){
						for(Iterator<String> it = keys.iterator();it.hasNext();){
							String key = it.next();
							String commentText = "COMMENT_TEXT";
							if(commentText.equals(key)){
								audit.setComment(CommonUtil.trimSpace(rs.getString(commentText)));
							}
							//more ifs can follow here if needed
						}
					}
				}
				return audit;
			}
	}


	private String getCurrentTimestamp(){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		return simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getCountOfAuditRowsByApprovedVzid(java.lang.String)
	 * This method returns the count of rows available for a given vzId
	 */
	public Integer getCountOfAuditRowsByApprovedVzid(String vzid)throws NCASException {
		Object[] params = new Object[]{vzid};
		return this.getJdbcTemplate().queryForInt(COUNT_AUDIT_ROWS_FOR_APPROVER, params, singleVarcharTypeArray);
	}

	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#selectFromNCASApprovalRulesTable(java.lang.String)
	 * This method returns an approval rule from NCAS_APPROVAL_RULES_T table based on the where criteria passed
	 * the spring api queryForMap returns exactly only one row - if the query is made to return 0 (or) more than one row,
	 * queryForMap will throw IncorrectResultSizeDataAccessException
	 */
	public Map<String,Object> selectFromNCASApprovalRulesTable(String whereClause)throws NCASException {
		StringBuilder builder = new StringBuilder(SELECT_NCAS_APPROVAL_RULES);
		int whereIndex = SELECT_NCAS_APPROVAL_RULES.indexOf("?");
		builder.replace(whereIndex, whereIndex+1, whereClause);
		String revisedQuery = builder.toString();
		Map<String,Object> retMap = null;
		try {
			retMap = this.getJdbcTemplate().queryForMap(revisedQuery);
			convertOtherTypesInMapToString(retMap);
		} catch (IncorrectResultSizeDataAccessException e) {}
		return retMap;
	}


	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getApprovalAmountLimit(java.util.Map)
	 * This method returns a row from CLM_APPROVAL_REF_T table based on career band & manager level
	 * the spring api queryForMap returns exactly only one row - if the query is made to return 0 (or) more than one row,
	 * queryForMap will throw IncorrectResultSizeDataAccessException
	 */
	public Map<String,Object> getApprovalAmountLimit(Map<String, Object> inputMap)throws NCASException {
		String career_band = (String)inputMap.get("CAREER_BAND");
		String manager_level = (String)inputMap.get("MANAGER_LEVEL");
		Object[] params = new Object[]{career_band,manager_level};
		Map<String,Object> retMap = null;
		try {
			retMap = this.getJdbcTemplate().queryForMap(SELECT_APPROVAL_AMT_LIMIT, params,doubleCharTypeArray);
			convertOtherTypesInMapToString(retMap);
		} catch (IncorrectResultSizeDataAccessException e) {}
		return retMap;
	}

	/**
	 * @param retMap
	 * This method converts the all the values of the map to string type and shaves the spaces also
	 */
	private void convertOtherTypesInMapToString(Map<String,Object> retMap){
		Set<String> mapKeys = retMap.keySet();
		Iterator<String> it = mapKeys.iterator();
		while(it.hasNext()){
			String key = it.next();
			Object val = retMap.get(key);
			if(val instanceof Date || val instanceof Timestamp){
				val = val.toString();
			}else if(val instanceof BigDecimal){
				val = ((BigDecimal) val).toPlainString();
			}
			if(val!=null){
				retMap.put(key,((String)val).trim());
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getApprovalAuditListOfCustomApproversByTicket(java.lang.String)
	 * This method returns a list of ApprovalAudit rows for custom approvers for a given ticketId
	 */
	public List<ApprovalAudit> getApprovalAuditListOfCustomApproversByTicket(String tktId) throws NCASException {
		Object[] param = new Object[]{tktId};
		return this.getJdbcTemplate().query(SELECT_APPR_LIST_OF_CUST_APPROVERS_BY_TKT, param, singleVarcharTypeArray, auditRowMapper);
	}

	/* (non-Javadoc)
	 * @see com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface#getDesigneeByDesignator(java.lang.String)
	 * This method returns a UserDelegation object based on the designator vzid passed
	 * the spring api queryForMap returns exactly only one row - if the query is made to return 0 (or) more than one row,
	 * queryForMap will throw IncorrectResultSizeDataAccessException
	 */
	public UserDelegation getDesigneeByDesignator(String vzId) throws NCASException {
		Object[] param = new Object[]{vzId};
		Map<String,Object> designeeMap = null;
		UserDelegation user = null;
		try{
			designeeMap = this.getJdbcTemplate().queryForMap(SELECT_DESIGNEE_BY_DESIGNATOR, param, singleVarcharTypeArray);
			if(designeeMap!=null){
				 convertOtherTypesInMapToString(designeeMap);
				 user = new UserDelegation();
				 user.setApproverVZID((String)designeeMap.get("APPROVER_VZID"));
				 user.setDesignatorVZID((String)designeeMap.get("DESIGNATOR_VZID"));
				 user.setStartDate((String)designeeMap.get("START_DATE"));
				 user.setEndDate((String)designeeMap.get("END_DATE"));
				 user.setLastUpdatedBy((String)designeeMap.get("LAST_UPDATED_BY"));
				 user.setLastUpdatedTimestamp((String)designeeMap.get("LAST_UPD_TIMESTAMP"));
			 }
		} catch (IncorrectResultSizeDataAccessException e) {}
		return user;
	}

	/**
	 * Function for searching all active designee in VAC_DESGINATION_T Table
	 * @param inputMap Given object
	 * @return Map containing the list of DESIGNATION
	 * @throws NCASException
	 */
	public Map<String, Object> getActiveDesignee(Designation designationObj) throws NCASException {
		Map<String,Object> returnMap = new HashMap<String,Object>();
		List<Designation> designeeList = new ArrayList<Designation>();
		List<String> whereInputs = new ArrayList<String>();

		String sql = SELECT_ACTIVE_DESIGNEE;
		// default condition
		String orderBy = " ORDER BY A.LAST_UPD_TIMESTAMP DESC";

		//check for OrderBy Condition
		String sortOrder = designationObj.getSortOrder().toUpperCase();
		String sortBy = designationObj.getSortID();
		if(sortBy.equals("DESIGNATOR_NAME")){
			orderBy = " ORDER BY DESIGNATOR " + sortOrder;
		}else if(sortBy.equals("DESIGNATOR_ID")){
			orderBy = " ORDER BY A.DESIGNATOR_VZID " + sortOrder;
		}else if(sortBy.equals("APRROVAL_NAME")){
			orderBy = " ORDER BY APPROVER " + sortOrder;
		}else if(sortBy.equals("APPROVAL_ID")){
			orderBy = " ORDER BY A.APPROVER_VZID " + sortOrder;
		}else if(sortBy.equals("START_DATE")){
			orderBy = " ORDER BY A.START_DATE " + sortOrder;
		}else if(sortBy.equals("END_DATE")){
			orderBy = " ORDER BY A.END_DATE " + sortOrder;
		}else if(sortBy.equals("LAST_UPDATED")){
			orderBy = " ORDER BY A.LAST_UPDATED_BY " + sortOrder;
		}else if(sortBy.equals("LAST_UPD_TIMESTAMP")){
			orderBy = " ORDER BY A.LAST_UPD_TIMESTAMP " + sortOrder;
		}
		//appending the orderBy clause to the sql
		sql += orderBy;
		try {
			designeeList = vbifGetActiveDesignee.getActiveDesignee(sql, whereInputs);
		} catch(Exception vacEx) {
			throw new NCASException("VBIF1001",ApprovalAuditDAOImpl.class,vacEx);
		}
		returnMap.put("DESIGNEE_LIST",designeeList);
		return returnMap;
	}

	private boolean isValidInput(String input){
		return (input!=null && input.trim().length()>0)?Boolean.TRUE:Boolean.FALSE;
	}

	/** Function for getting the active iCI users */
	public Map<String, Object> getActiveiCIUser(Designation inputDesignation) throws NCASException {
		String sql = SELECT_USER;
		String AND = " AND ";
		String orderBy = " ORDER BY P.LAST_NAME ASC ";
		List<String> whereInputs = new ArrayList<String>();

		//check for last name
		String lastName = inputDesignation.getLastName();
		if(isValidInput(lastName)){
			whereInputs.add(lastName.trim().toUpperCase() + '%');
			sql += AND + " UPPER(P.LAST_NAME) LIKE ? ";
		}
		//appending the orderBy clause to the sql
		sql += orderBy;

		List<Designation> designeeList = new ArrayList<Designation>();
		try {
			designeeList = vbifGetActiveiCIUser.getActiveiCIUser(sql,whereInputs);
		} catch(Exception vacEx) {
			throw new NCASException("VBIF1001",ApprovalAuditDAOImpl.class,vacEx);
		}
		Map<String,Object> returnMap = new HashMap<String,Object>();
		returnMap.put("USER_LIST",designeeList);
		return returnMap;
	}

	/** Function for inserting row in DESIGNATION Table */
	public Map<String, Object> insertDesignation(Designation input)throws NCASException,Exception {
		Map<String,Object> returnMap = new HashMap<String,Object>();
		//inserting in the VAC_DESIGNATION_T table
		vbifInsertDesignation.insertDesignation(input);
		returnMap.put("INSERT_DESINGATION","SUCCESS");
		return returnMap;
	}

	/** Function for updating row in DESIGNATION Table */
	public Map<String, Object> updateDesignation(Designation input)throws NCASException,Exception {
		//updating the existing row in the DESIGNATION table
		vbifUpdateDesignation.updateDesignation(input);

		Map<String,Object> returnMap = new HashMap<String,Object>();
		returnMap.put("UPDATE_DESINGATION","SUCCESS");
		return returnMap;
	}
	
	/** Function for deleting row in DESIGNATION Table */
	public Map<String, Object> deleteDesignation(Designation input)throws NCASException,Exception {
		//deleting the existing row in the DESIGNATION table
		vbifDeleteDesignation.deleteDesignation(input);

		Map<String,Object> returnMap = new HashMap<String,Object>();
		returnMap.put("DELETE_DESINGATION","SUCCESS");
		return returnMap;
	}


}