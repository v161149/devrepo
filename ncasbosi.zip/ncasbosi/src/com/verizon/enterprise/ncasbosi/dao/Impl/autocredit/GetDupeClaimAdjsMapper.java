package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;


import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.autocredit.DupeClaimAdjs;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


/**
 * @author v992473
 * This class serves as the resultset-object mapper to SPGetDupeClaimAdjs
 *
 */
public class GetDupeClaimAdjsMapper implements RowMapper{


	private static final Logger _LOGGER = Logger.getLogger(GetDupeClaimAdjsMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetDupeClaimAdjsMapper - Mapping Row# "+rowNum);

		DupeClaimAdjs dupeClm = null;
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";
		if(rs!=null){
			dupeClm = new DupeClaimAdjs();
			dupeClm.setDupeClaimNumber(trimSpace(rs.getString("DUP_SRC_SYS_CLM_ID")));
			dupeClm.setOrigInvoiceDate(CommonUtil.formatDate(rs.getString("ORIG_INVOICE_DT"), formatDb2, formatDisplayed));
			dupeClm.setServiceId(trimSpace(rs.getString("SERVICE_ID")));
			dupeClm.setAdjAmount(commonUtil.formatNumber(rs.getBigDecimal("INCR_ADJUST_AMT"), "#,##0.00"));
			dupeClm.setCreditDebit(trimSpace(rs.getString("CREDIT_DEBIT")));
			dupeClm.setCalcTypeDesc(trimSpace(rs.getString("CALC_TYPE_DESC")));
			dupeClm.setCalcSubTypeDesc(trimSpace(rs.getString("CALC_SUB_TYPE_DESC")));
			dupeClm.setCallType(trimSpace(rs.getString("CALL_TYPE")));
			dupeClm.setOrigTermType(trimSpace(rs.getString("ORIG_TERM_TYPE")));
			dupeClm.setTermCountry(trimSpace(rs.getString("TERM_COUNTRY")));
			dupeClm.setTermState(trimSpace(rs.getString("TERM_STATE")));
			dupeClm.setDuplicateIndicator(trimSpace(rs.getString("DUPLICATE_IND")));
			dupeClm.setDupeOverrideIndicator(trimSpace(rs.getString("OVERRIDE_DUP_IND")));
		}
		_LOGGER.info("Dupe Claim/Adj::"+dupeClm);
		return dupeClm;
	}

	
	//Trimmer to remove spaces that VAC sends
	private String trimSpace(String input){
		return input!=null?input.trim():input;
	}

}

