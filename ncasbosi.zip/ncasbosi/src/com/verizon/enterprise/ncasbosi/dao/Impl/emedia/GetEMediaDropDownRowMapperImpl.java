package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;


public class GetEMediaDropDownRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaDropDownRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetEMediaDropDownRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		Map refTablesMap = new HashMap();
		
		String dropDownField = "";
		String prevDropDownField = "";
		EMediaDropDown dropDown = null;
		List refList = null;
		while(rs.next()) {
			dropDown = new EMediaDropDown();
			dropDownField = rs.getString("DROPDOWN_FIELD");
			String dropDownCode = rs.getString("DROPDOWN_CODE");
			String dropDownDisplay = rs.getString("DROPDOWN_DISPLAY");

			if(CommonUtil.isNotNull(dropDownCode)) {
				dropDown.setDropDownCode(dropDownCode.trim());
			}
			if(CommonUtil.isNotNull(dropDownDisplay)) {
				dropDown.setDropDownDisplay(dropDownDisplay.trim());
			}
			if(!dropDownField.equals(prevDropDownField)){
				refList = new ArrayList();
				refTablesMap.put(dropDownField.trim(),refList);
			}	
			refList.add(dropDown);
			prevDropDownField = dropDownField;
		}
		return refTablesMap;
	}
}
