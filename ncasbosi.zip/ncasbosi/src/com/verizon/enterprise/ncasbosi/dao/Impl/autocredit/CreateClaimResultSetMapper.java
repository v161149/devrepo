package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.TicketStatus;

/**
 * This class maps the row of the CREATE_VZB_CLAIM result set to the TicketStatus Object.<br>
 * The result set will have only one row for the ticket that was passed as input param
 * 
 *
 */
public class CreateClaimResultSetMapper implements RowMapper{
	
	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		_LOGGER.info("CreateClaimResultSetMapper - Mapping Row# "+rowNum);
		TicketStatus ticketStatus = null;
		if(rs!=null){
			ticketStatus = new TicketStatus();
			ticketStatus.setStatus(spaceTrimmer(String.valueOf(rs.getInt("TKT_STATUS"))));
			ticketStatus.setStatusText(spaceTrimmer(rs.getString("TKT_STATUS_DESC")));
			ticketStatus.setSubStatus(spaceTrimmer(String.valueOf(rs.getInt("TKT_SUB_STATUS"))));
			ticketStatus.setSubStatusText(spaceTrimmer(rs.getString("TKT_SUB_STAT_DESC")));
			ticketStatus.setSendNotification(spaceTrimmer(rs.getString("SEND_NOTIFICATION")));
		}
		return ticketStatus;
	}
	
	//Trimmer Function to removes spaces that comes from VAC
	private String spaceTrimmer(String input){
		return input!=null?input.trim():input;
	}

}
