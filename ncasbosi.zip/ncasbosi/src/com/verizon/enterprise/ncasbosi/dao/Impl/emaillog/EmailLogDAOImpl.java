package com.verizon.enterprise.ncasbosi.dao.Impl.emaillog;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.core.PreparedStatementCreator;
import java.sql.PreparedStatement;
import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.verizon.enterprise.common.ncas.emaillog.EmailLog;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.dao.Interface.emaillog.EmailLogInterface;;



public class EmailLogDAOImpl extends JdbcDaoSupport implements EmailLogInterface, NCASBOSIConstants {

	private static final Logger _LOGGER = Logger.getLogger(EmailLogDAOImpl.class);
	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	String SELECT_EMAIL_LOG_DETAILS = null;
	String INSERT_EMAIL_LOG_DTLS = "INSERT INTO  " + getSchemaName() + ".PL_EMAIL_LOG(EMAIL_REF_ID, EMAIL_SUBJ, EMAIL_TEXT, EMAIL_TO_ADDR, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, SERVICE_ID, EMAIL_TRACKING_OID) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
	private JdbcTemplate dbTemplate;
	private SelectEmailLogDetails selectEmailLogDetails;

	protected void initDao() throws Exception{
		super.initDao();
		SELECT_EMAIL_LOG_DETAILS = "SELECT EMAIL_REF_ID,EMAIL_SUBJ,EMAIL_TEXT,EMAIL_TO_ADDR,LAST_UPD_TIMESTAMP FROM "+getSchemaName()+".PL_EMAIL_LOG WHERE EMAIL_REF_ID IN (SELECT REQUEST_ID FROM "+getSchemaName()+".PL_REQSTATUS WHERE DATE(CREATED_TIMESTAMP) BETWEEN ? AND ? AND LOGINID=?)";
		selectEmailLogDetails = new SelectEmailLogDetails(SELECT_EMAIL_LOG_DETAILS,0);
	}
	public EmailLogDAOImpl() {
		super();
	}
	public String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		return schemaName;
	}

	public Integer getSqlDataType(int i)
	{
		return new Integer(i);
	}

	protected JdbcTemplate getDBTemplate()
	{
		if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}

	class SelectEmailLogDetails extends JdbcDaoSupport{
		   private String sql;
		   private int startRange = 0;
			public SelectEmailLogDetails(String sql, int startRange) {
		       this.sql = sql;
		       this.startRange = startRange;
		   }


	public Map<Integer,EmailLog> getEmailLogDetails(String fromDate,String toDate, String loginId) {
	final String METHOD_NAME = "getEmailLogDetails => ";
	final String frDate = fromDate;
	final String tDate = toDate;
	final String lgId = loginId;
	 _LOGGER.info(METHOD_NAME+"Entering");
		PreparedStatementCreator psc = new PreparedStatementCreator(){
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException{
				PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ps.setString(1,frDate);
				ps.setString(2,tDate);
				ps.setString(3,lgId);
				return ps;
			}
		};
	 return  (Map<Integer,EmailLog>)getDBTemplate().query(psc, new ResultSetExtractor() {
		 int count = 0;
	 public Object extractData(ResultSet rs) throws SQLException {
		 rs.absolute(startRange);
		 Map<Integer,EmailLog> logInfoMap =   new HashMap<Integer,EmailLog>();
	  while (rs.next()) {
		 	int emailRefId 		= rs.getInt("EMAIL_REF_ID");
			String emailSubj	= rs.getString("EMAIL_SUBJ");
			String emailText	= rs.getString("EMAIL_TEXT");
			String emailToAddr 	= rs.getString("EMAIL_TO_ADDR");
			String lastUpdated 	= rs.getString("LAST_UPD_TIMESTAMP");

			EmailLog emailLogInfo = new EmailLog(emailRefId, emailSubj, emailText, emailToAddr,lastUpdated);
			logInfoMap.put(count,emailLogInfo);
			count ++;
	      }
	      	_LOGGER.info("emaillog size:"+logInfoMap.size());
			return logInfoMap;
		}});
	   }
	  }

	public Map<Integer,EmailLog> selectEmailLogDetails(String fromDate, String toDate, String loginId) throws NCASException {
		final String METHOD_NAME = "selectEmailLogDetails => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_EMAIL_LOG_DETAILS);
		Map<Integer,EmailLog> emailLogMap =  null;
		try{
			emailLogMap =  selectEmailLogDetails.getEmailLogDetails(fromDate, toDate, loginId.toUpperCase());
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+"selectEmailLogDetails Failed \n"+vamEx.getMessage());
		     throw new NCASException(NCASBOSIConstants.EMAIL_STATUS_EXCEPTION,EmailLogDAOImpl.class, vamEx);
		}
		return emailLogMap;
	}

	public int insertEmailLogDetails(EmailLog emailLog){
		final String METHOD_NAME = "insertEmailLogDetails => ";
		_LOGGER.info(METHOD_NAME + " Entering");
		SqlUpdate insertEmailLogDetails = null;
		int logTrackingId = 0;

		if(emailLog!=null)
		{
			_LOGGER.info(METHOD_NAME+"Insert SQL: " + INSERT_EMAIL_LOG_DTLS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				insertEmailLogDetails = new SqlUpdate(getDataSource(),INSERT_EMAIL_LOG_DTLS);
				insertEmailLogDetails.setReturnGeneratedKeys(true);
				insertEmailLogDetails.declareParameter(new SqlParameter("EMAIL_REF_ID", Types.INTEGER));
				insertEmailLogDetails.declareParameter(new SqlParameter("EMAIL_SUBJ", Types.VARCHAR));
				insertEmailLogDetails.declareParameter(new SqlParameter("EMAIL_TEXT", Types.VARCHAR));
				insertEmailLogDetails.declareParameter(new SqlParameter("EMAIL_TO_ADDR", Types.VARCHAR));
				insertEmailLogDetails.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertEmailLogDetails.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertEmailLogDetails.declareParameter(new SqlParameter("SERVICE_ID", Types.VARCHAR));
				insertEmailLogDetails.declareParameter(new SqlParameter("EMAIL_TRACKING_OID", Types.DECIMAL));
				insertEmailLogDetails.compile();

				Object[] parameterValues = new Object[]{new Integer(emailLog.getEmailRefId()),
														emailLog.getEmailSubj(),
														emailLog.getEmailText(),emailLog.getEmailToAddr(),
														lastUpdated, lastUpdated, emailLog.getMtn(),
														new Double(emailLog.getEmailTrackOid())};
				KeyHolder autoGeneratedKeyHolder = new GeneratedKeyHolder();
				insertEmailLogDetails.update(parameterValues,autoGeneratedKeyHolder);
				logTrackingId =  autoGeneratedKeyHolder.getKey().intValue();
			}
			catch(Exception ex) {
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			}
		}

		_LOGGER.info(METHOD_NAME+"Exiting");
		return logTrackingId;
	}

}