package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetTaxDetailsRowMapperImpl implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetAdjustmentsByIdRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetTaxDetailsRowMapperImpl::extractData()";

		logger.info(METHOD_NAME + " ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List taxDetailsList = new ArrayList();

		try
		{
			while(rs.next())
			{
				Map columnMap = new HashMap();
				String taxGroupId = rs.getString("TAX_GROUP_ID");
				String taxGroupAmount = rs.getString("TAX_GROUP_AMT");
				String taxGroupDescription = rs.getString("TAX_GROUP_DESC");

				if(CommonUtil.isNotNull(taxGroupId))
				{
					columnMap.put("taxGroupId", taxGroupId.trim());
				}

				if(CommonUtil.isNotNull(taxGroupAmount))
				{
					columnMap.put("taxGroupAmount",taxGroupAmount.trim());
				}

				if(CommonUtil.isNotNull(taxGroupDescription))
				{
					columnMap.put("taxGroupDescription",taxGroupDescription.trim());
				}

				//finally add the map to the list
				taxDetailsList.add(columnMap);
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.debug(METHOD_NAME + " Exception occured while parsing the resultset \n"+nfe.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"+nfe.getMessage());
			throw nfe;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			logger.debug(METHOD_NAME + " Exception occured while parsing the resultset \n"+ex.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"+ex.getMessage());
		}

		logger.info(METHOD_NAME + " EXIT");

		return taxDetailsList;
	}
}
