package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetGBREMediaAccountsRowMapperImpl  implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetGBREMediaAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetGBREMediaAccountsRowMapperImpl::extractData()";

		logger.debug(METHOD_NAME + " ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();
		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = new ArrayList();
		String key = "";

		try
		{
			while(rs.next())
			{
				emediaRecord = new EMediaRecord();
				// resultSet
				String corpId = rs.getString("CORP_ID");
				String man = rs.getString("MAN");
				String ban = rs.getString("BAN");
				String manDan = rs.getString("MAN_DAN");
				String banDan = rs.getString("BAN_DAN");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String startBillPeriod = rs.getString("START_DATE");
				String endBillPeriod = rs.getString("END_DATE");
				String accountName = rs.getString("COMPANY_NAME");
				String channelCode = rs.getString("LOB_IND");
				String acctStatus = rs.getString("ACCT_STATUS");
				String allBPInd = rs.getString("ALL_BILL_PAYER_IND");
				String allSubAcctInd = rs.getString("ALL_SUB_ACCT_IND");
				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String billPeriod = rs.getString("BP_DAY");
				String configId = rs.getString("CONFIG_ID");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");
				String gbrRegionName = rs.getString("GBR_REGION_NAME");
				acctSubscriptionOid = rs.getDouble("SUBSCRIPTION_OID");
				String orgLevel1No = rs.getString("ORG_LEVEL1_NO");
				String orgLevel1Name = rs.getString("ORG_LEVEL1_NAME");
				String orgLevel2No = rs.getString("ORG_LEVEL2_NO");
				String orgLevel2Name = rs.getString("ORG_LEVEL2_NAME");
				String billingFrequency = rs.getString("BILLING_FREQ");
                String manBillDate = rs.getString("MAN_BILL_DATE");

				//Pretty print the DB Values - GBR - as per Paul request.
				List valuesList = new ArrayList();
				valuesList.add("CORP_ID="+corpId);
				valuesList.add("MAN="+man);
				valuesList.add("BAN="+ban);
				valuesList.add("MAN_DAN="+manDan);
				valuesList.add("BAN_DAN="+banDan);
				valuesList.add("ORIG_SYSTEM_ID="+origSysId);
				valuesList.add("START_DATE="+startBillPeriod);
				valuesList.add("END_DATE="+endBillPeriod);
				valuesList.add("COMPANY_NAME="+accountName);
				valuesList.add("LOB_IND="+channelCode);
				valuesList.add("ACCT_STATUS="+acctStatus);
				valuesList.add("ALL_BILL_PAYER_IND="+allBPInd);
				valuesList.add("ALL_SUB_ACCT_IND="+allSubAcctInd);
				valuesList.add("ENTERPRISE_ID="+enterpriseId);
				valuesList.add("BP_DAY="+billPeriod);
				valuesList.add("CONFIG_ID="+configId);
				valuesList.add("SYST_ABBREVIATION="+systemAbbrv);
				valuesList.add("GBR_INVOICE_TYPE="+gbrInvoiceType);
				valuesList.add("GBR_REGION_NAME="+gbrRegionName);
				valuesList.add("SUBSCRIPTION_OID="+acctSubscriptionOid);
				valuesList.add("ORG_LEVEL1_NO="+orgLevel1No);
				valuesList.add("ORG_LEVEL1_NAME="+orgLevel1Name);
				valuesList.add("ORG_LEVEL2_NO="+orgLevel2No);
				valuesList.add("ORG_LEVEL2_NAME="+orgLevel2Name);
				valuesList.add("BILLING_FREQ="+billingFrequency);
				valuesList.add("MAN_BILL_DATE="+manBillDate);
				CommonUtil.prettyPrintValues(valuesList);

				if(CommonUtil.isNotNull(corpId))
				{
					emediaRecord.setCorp(corpId.trim());
				}

				if(CommonUtil.isNotNull(enterpriseId))
				{
					emediaRecord.setEnterprise(enterpriseId.trim());
				}

				if(CommonUtil.isNotNull(ban))
				{
					emediaRecord.setBan(ban.trim());
				}

				if(CommonUtil.isNotNull(man))
				{
					emediaRecord.setMan(man.trim());
				}

				if(CommonUtil.isNotNull(manDan))
				{
					emediaRecord.setMan_dan(manDan.trim());
				}

				if(CommonUtil.isNotNull(configId))
				{
					emediaRecord.setCustConfigId(configId.trim());
				}

				if(CommonUtil.isNotNull(manDan))
				{
					emediaRecord.setMan_dan(manDan.trim());
				}

				if(CommonUtil.isNotNull(allBPInd))
				{
					emediaRecord.setAllBPInd(allBPInd.trim());
				}

				if(CommonUtil.isNotNull(allSubAcctInd))
				{
					emediaRecord.setAllSubAcctInd(allSubAcctInd.trim());
				}

				if(CommonUtil.isNotNull(gbrInvoiceType))
				{
					emediaRecord.setGbrInvoiceType(gbrInvoiceType.trim());
				}

				if(CommonUtil.isNotNull(gbrRegionName))
				{
					emediaRecord.setRegionName(gbrRegionName.trim());
				}

				if(CommonUtil.isNotNull( origSysId))
				{
					origSysId = origSysId.trim();
				}
				else
				{
					origSysId = "";
				}

				if((!origSysId.startsWith("M1") && !origSysId.startsWith("M2") && !origSysId.startsWith("M3") && !origSysId.startsWith("M9")) && (banDan==null || (banDan!=null && banDan.trim().equals(""))))
				{
					banDan = man;
					man = "";
				}

				emediaRecord.setOrigSysId(origSysId);

				if(CommonUtil.isNotNull(banDan))
				{
					emediaRecord.setBan_dan(banDan.trim());
				}

				if(CommonUtil.isNotNull(man))
				{
					emediaRecord.setMan_dan(man.trim());
				}

				if(CommonUtil.isNotNull(accountName))
				{
					emediaRecord.setAccountName(accountName.trim());
				}

				if(CommonUtil.isNotNull(billPeriod))
				{
					emediaRecord.setBillPeriod(billPeriod.trim());
				}

				if(CommonUtil.isNotNull(channelCode))
				{
					emediaRecord.setChannelCode(channelCode.trim());
				}

				if(CommonUtil.isNotNull(systemAbbrv))
				{
					emediaRecord.setSystemAbbrv(systemAbbrv.trim());
				}

				if(CommonUtil.isNotNull(startBillPeriod))
				{
					emediaRecord.setStartBillPeriod(CommonUtil.getDisplayDateFromString(startBillPeriod.trim()));
				}

				if(CommonUtil.isNotNull(endBillPeriod))
				{
					emediaRecord.setEndBillPeriod(CommonUtil.getDisplayDateFromString(endBillPeriod.trim()));
				}

				if(CommonUtil.isNotNull(acctStatus))
				{
					emediaRecord.setStatus(acctStatus.trim());
				}

				if(CommonUtil.isNotNull(orgLevel1No))
				{
					emediaRecord.setOrgLevel1No(orgLevel1No.trim());
				}

				if(CommonUtil.isNotNull(orgLevel2No))
				{
					emediaRecord.setOrgLevel2No(orgLevel2No.trim());
				}

				if(CommonUtil.isNotNull(orgLevel1Name))
				{
					emediaRecord.setOrgLevel1Name(orgLevel1Name.trim());
				}

				if(CommonUtil.isNotNull(orgLevel2Name))
				{
					emediaRecord.setOrgLevel2Name(orgLevel2Name.trim());
				}

				if(CommonUtil.isNotNull(billingFrequency))
				{
					emediaRecord.setBillingFrequency(billingFrequency.trim());
				}

				if(CommonUtil.isNotNull(manBillDate))
				{
					emediaRecord.setManBillDate(CommonUtil.getDisplayDateFromString(manBillDate.trim()));
				}

				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				emediaRecord.setAcctSubscriptionOid(key);

				refList.add(emediaRecord);
			}
		}
		catch(NumberFormatException nfe)
		{
				nfe.printStackTrace();
				logger.info(METHOD_NAME + " Exception occured while parsing the resultset \n"+nfe.getMessage());
				logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}

		logger.debug(METHOD_NAME + " EXIT");

		return refList;
	}
}