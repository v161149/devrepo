package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.verizon.enterprise.common.ncas.autocredit.AuditorInfo;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;


/**
 * @author v898809
 * This class provides helper methods to construct Auditor Details Map Structure
 */

public class AuditorDetailsHelper {
	private static final org.apache.log4j.Logger Logger = org.apache.log4j.Logger.getLogger(AuditorDetailsHelper.class);
	
	 public static Map<String,List> constructAuditorDetailsMap(ResultSet rs,String key) throws SQLException{
			Map<String,List> audDtlresultsMap = new HashMap<String,List>();
			List<String> servicecenterList = new ArrayList<String>();
			List<AuditorInfo> aiList = new ArrayList<AuditorInfo>();
			if(key!=null && key.trim().equals(""))
				Logger.info("KEY::::"+key);
			if(rs!=null){			
				while(rs.next()){
					if(key.trim().equals(NCASBOSIConstants.Get_AUDITOR_DTL_ALL)){
						AuditorInfo ai = new AuditorInfo();
						if(!servicecenterList.contains(rs.getString(1)))
							servicecenterList.add(rs.getString(1));
						ai.setAuditorVZID(rs.getString(2));
						ai.setAuditorName(rs.getString(3));
						if(!aiList.contains(ai))
							aiList.add(ai);
					}else if(key.trim().equals(NCASBOSIConstants.Get_AUDITOR_DTL_By_SERVICE_CENTER)){
						AuditorInfo ai = new AuditorInfo();
						ai.setAuditorVZID(rs.getString(2));
						ai.setAuditorName(rs.getString(3));
                        if(!aiList.contains(ai))
                            aiList.add(ai);
						//servicecenterList=null;
					}else{
						//AuditorInfo ai = new AuditorInfo();
						//ai = null;
						//aiList.add(i,ai);
					    if(!servicecenterList.contains(rs.getString(1)))
					        servicecenterList.add(rs.getString(1));
					}
				}
				Logger.info("servicecenterList::::"+servicecenterList);
				Logger.info("aiList::::"+aiList);
				audDtlresultsMap.put("SERVICE_CENTER_LIST",servicecenterList);
				audDtlresultsMap.put("AUDITOR_INFO_LIST",aiList);
			}
		 return audDtlresultsMap;
	 }
}