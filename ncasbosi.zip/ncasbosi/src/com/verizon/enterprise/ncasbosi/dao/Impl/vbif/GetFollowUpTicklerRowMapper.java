package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.FollowUpTicklerData;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
public class GetFollowUpTicklerRowMapper implements RowMapper {
	//Release Aug2012. Srihari.
	static private final Logger _LOGGER = Logger.getLogger(GetFollowUpTicklerRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetFollowUpTicklerRowMapper::mapRow rowNum - " + rowNum);
		FollowUpTicklerData followUpTicklerData = new FollowUpTicklerData();
		try {

			String followUpID = rs.getString("VAC_FOLLOWUP_ID");
			String status = rs.getString("FOLLOWUP_STATUS");
			String type= rs.getString("FOLLOWUP_TYPE");
			String typeDesc = rs.getString("FOLLOWUP_TYPE_DESC");
			String createTimeStr = CommonUtil.getFormattedDateString(rs.getDate("CREATE_TIMESTAMP"),"dd/MMM/yyyy HH:mm:ss");
			String closedTimeStr = CommonUtil.getFormattedDateString(rs.getDate("CLOSED_TIMESTAMP"),"dd/MMM/yyyy HH:mm:ss");			
			//Following are not part of Tickler. Belong to follow-up only.
			String dueDateStr = "";
			String dueTimeHHMMStr ="";
			String desc="";
			ResultSetMetaData rsMetaData = rs.getMetaData();
			int numberOfColumns = rsMetaData.getColumnCount();
			if(numberOfColumns>6){//Follow-up only. 
				dueDateStr = CommonUtil.getFormattedDateString(rs.getDate("DUE_DATE"), "dd/MMM/yyyy");
				dueTimeHHMMStr= rs.getString("DUE_TIME"); //CHAR(5) Format - HH:MM	
				desc= rs.getString("FOLLOWUP_DESC");
			}

			if (CommonUtil.isNotNull(followUpID)) {
				followUpTicklerData.setFollowUpID(followUpID.trim());
			}
			if (CommonUtil.isNotNull(status)) {
				followUpTicklerData.setStatus(status);
			}
			if (CommonUtil.isNotNull(type)) {
				followUpTicklerData.setType(type); 
			}
			if (CommonUtil.isNotNull(typeDesc)) {
				followUpTicklerData.setTypeDesc(typeDesc);
			}
			if (CommonUtil.isNotNull(createTimeStr)) {
				followUpTicklerData.setCreateTime(createTimeStr); 
			}
			if (CommonUtil.isNotNull(closedTimeStr)) {
				followUpTicklerData.setClosedTime(closedTimeStr); 
			}
			if (CommonUtil.isNotNull(dueDateStr)) {
				followUpTicklerData.setDueDate(dueDateStr); 
			}
			if (CommonUtil.isNotNull(dueTimeHHMMStr)) {
				followUpTicklerData.setDueTime(dueTimeHHMMStr); 
			}
			if (CommonUtil.isNotNull(desc)) {
				followUpTicklerData.setDesc(desc); 
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return followUpTicklerData;
	}
}
