package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaHistory;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;

public class GetEMediaHistoryRowMapperImpl implements RowMapper {
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaHistoryRowMapperImpl.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.info("Inside GetEMediaHistoryRowMapperImpl::mapRow rowNumber -> " + rowNum);
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		EMediaHistory history = new EMediaHistory();
		history.setConfigSubscriptionOid(CommonUtil.convertStringFromDouble(rs.getDouble("CONFIG_SUBS_OID")));
		history.setNoteTimeStamp(CommonUtil.getDisplayDateTime(rs.getTimestamp("NOTE_TIMESTAMP")));
		
		String noteType = rs.getString("NOTE_TYPE");
		String userId = rs.getString("EXT_UPDT_USR_ID");
		String userName = rs.getString("EXT_UPDT_USR_NAME");
		String noteText = rs.getString("NOTE_TEXT");

		if(CommonUtil.isNotNull(noteType)) {
			history.setNoteType(noteType.trim());
		}
		if(CommonUtil.isNotNull(userId)) {
			history.setUserId(userId.trim());
		}
		if(CommonUtil.isNotNull(userName)) {
			history.setUserName(userName.trim());
		}
		if(CommonUtil.isNotNull(noteText)) {
			history.setNoteText(noteText.trim());
		}
			
		_LOGGER.info("GetEMediaHistoryRowMapperImpl's history ==> " + history);
		return history;
	}
}