package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


/**
 * This class gets the list of all HOT nasp Ids
 *
 */
public class SPGetHotNaspId extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetHotNaspId.class);
	private static List spInOutList;
	   
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"DROP_DOWN_LIST", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET), NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, new VACDropDownMapper()});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPGetHotNaspId(DataSource datasource){
		super(datasource, NCASBOSIConstants.SP_GET_NASP_ID, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map resMap = executeSP(new ArrayList(), false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		_LOGGER.info("Printing the response Map::"+resMap);
		return resMap;
	}
}
