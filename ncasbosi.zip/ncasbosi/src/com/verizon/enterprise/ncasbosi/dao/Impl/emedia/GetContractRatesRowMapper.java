package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.gbr.GbrContractRate;

public class GetContractRatesRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger
			.getLogger(GetContractRatesRowMapper.class);

	public Object mapRow(ResultSet rs,  int rowNum) throws SQLException {
		_LOGGER.info("Inside GetVbeRemitRowMapper -> ");
//		CommonUtil.printMetaDataInfo(rs.getMetaData());

		GbrContractRate out = null;

		if(rs!=null)
		{
			out = new GbrContractRate();
			out.setDropdownField (trim(rs.getString("DROPDOWN_FIELD")));
			out.setFieldSeq (trim(rs.getString("FIELD_SEQ")));
			out.setDropdownCode (trim(rs.getString("CCY")));
			out.setDropdownDisplay (trim(rs.getString("CCY_DESC")));
			out.setFxDate (trim(rs.getString("FX_DATE")));
			out.setPxLastRate (trim(rs.getString("PX_LAST_RATE")));
			out.setContRateYN (trim(rs.getString("CONT_RATE_YN")));
			out.setContractRate (trim(rs.getString("CONTRACT_RATE")));
		}

		return out;
	}
	
	private String trim(String in)
	{
		if (in == null) return null;
		
		return in.trim();
		
	}
}
