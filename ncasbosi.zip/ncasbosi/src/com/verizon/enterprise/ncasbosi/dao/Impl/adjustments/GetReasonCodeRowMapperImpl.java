package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetReasonCodeRowMapperImpl implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetReasonCodeRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetReasonCodeRowMapperImpl::extractData() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List reasonCodesList = new ArrayList();

		try
		{
			while(rs.next())
			{
				Map columnsMap = new HashMap();
				String adjustmentReasonCode = rs.getString("ADJ_REASON_CODE");
				String adjustmentReasonText = rs.getString("ADJ_REASON_TEXT");
				String indicatorProdSel = rs.getString("IND_PRODUCT_SEL");
				String indicatorTaxes = rs.getString("IND_TAXES");
				String indicatorInterest = rs.getString("IND_INTEREST");
				String indicatorAdditionalReason = rs.getString("IND_ADDL_REASON");
				String revenueCode = rs.getString("REV_CODE");

				if(CommonUtil.isNotNull(adjustmentReasonCode))
				{
					columnsMap.put("adjustmentReasonCode", adjustmentReasonCode.trim());
				}

				if(CommonUtil.isNotNull(adjustmentReasonText))
				{
					columnsMap.put("adjustmentReasonText", adjustmentReasonText.trim());
				}

				if(CommonUtil.isNotNull(indicatorProdSel))
				{
					columnsMap.put("indicatorProdSel", indicatorProdSel.trim());
				}

				if(CommonUtil.isNotNull(indicatorTaxes))
				{
					columnsMap.put("indicatorTaxes", indicatorTaxes.trim());
				}

				if(CommonUtil.isNotNull(indicatorInterest))
				{
					columnsMap.put("indicatorInterest", indicatorInterest.trim());
				}

				if(CommonUtil.isNotNull(indicatorAdditionalReason))
				{
					columnsMap.put("indicatorAdditionalReason", indicatorAdditionalReason.trim());
				}

				if(CommonUtil.isNotNull(revenueCode))
				{
					columnsMap.put("revenueCode", revenueCode.trim());
				}

				//finally add the columnsMap to the list
				reasonCodesList.add(columnsMap);
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			throw nfe;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + ex.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + ex.getMessage());
		}

		return reasonCodesList;
	}
}

