package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.AuditorDetailsHelper;

/**
 * @author v898809 This class gets the complete resultset of GET_AUDITOR_DTL and
 *         constructs a map of AuditorDetail objects.
 * 
 */
public class GetAuditorDetailsMapper implements ResultSetExtractor
{
    private final Logger _LOGGER = Logger.getLogger(this.getClass());

    private String key;

    public GetAuditorDetailsMapper(String key)
    {
        this.key = key;
    }

    public Object extractData(ResultSet rs) throws SQLException,
            DataAccessException
    {
        _LOGGER.info("Entering extractData()");
        _LOGGER.info("Is resultSet Null::" + (rs == null));
        Map categoryMap = AuditorDetailsHelper.constructAuditorDetailsMap(rs,
                key);
        _LOGGER.info("Exiting extractData()");
        return categoryMap;
    }
}