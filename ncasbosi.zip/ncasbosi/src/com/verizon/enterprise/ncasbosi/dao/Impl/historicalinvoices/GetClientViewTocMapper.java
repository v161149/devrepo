package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiTocDO;import com.verizon.enterprise.common.util.DateUtility;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetClientViewTocMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetClientViewTocMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.debug("GetClientViewTocMapper - Mapping Row# "+rowNum);				HiTocDO hiTocDO = null;
		if(rs!=null){
			hiTocDO = new HiTocDO();
			hiTocDO.setLocationId(rs.getString("LOCATION_ID"));			hiTocDO.setSectionName(rs.getString("SECTION_NAME"));			hiTocDO.setStartPage(rs.getString("START_PAGE"));			hiTocDO.setEndPage(rs.getString("END_PAGE"));			hiTocDO.setBillSectionNumber(rs.getString("BILL_SECTION_NUM"));			hiTocDO.setSectionSubAccount(rs.getString("SECTION_SUBACCOUNT"));			hiTocDO.setBillCycle(rs.getString("BILL_CYCLE"));		}
		return hiTocDO;
	}
}
