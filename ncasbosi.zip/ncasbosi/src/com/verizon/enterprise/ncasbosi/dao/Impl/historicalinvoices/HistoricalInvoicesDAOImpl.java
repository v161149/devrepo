package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Collections;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.historicalinvoice.HistoricalInvoiceInterface;
import com.verizon.enterprise.common.ncas.exception.NCASException;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;
import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectComparator;
import com.verizon.enterprise.common.ncas.historicalinvoice.DocType;
import com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices.DocTypes;
import com.verizon.enterprise.common.util.DateUtility;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.common.util.AccountNumberUtil;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiPrintAndMailDO;



public class HistoricalInvoicesDAOImpl extends NCASSpringJDBCBase implements HistoricalInvoiceInterface{

	private static final Logger _LOGGER = Logger.getLogger(HistoricalInvoicesDAOImpl.class);

	private static final String WEST_AFP_DB = "Bars West";
	private static final String EAST_AFP_DB = "VGW Archive";

	// for fvz accounts replaces same named api from VAMBillArchive.java
	public Map getAfpBillList(Object input)throws NCASException
	{
		HashMap requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");
		String backendDB = "";
		backendDB = setBackendDB(hiDO.getOsid());
		String preferredLanguageCode = (String)requestMap.get("preferredLanguageCode");

		try
		{
			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in Man = " + hiDO.getMan());
				_LOGGER.info("in Ban = " + hiDO.getBan());
				_LOGGER.info("in Userid = " + hiDO.getUserId());
				_LOGGER.info("in backendDb = " + backendDB);

			}

			if (hiDO.getMan().equals("TEST"))
			{

				FileReader inputfile = new FileReader("c://CVdata.txt");
				BufferedReader bufRead = new BufferedReader(inputfile);
				List selectList = new ArrayList();
				String line;    // String that holds current file line
				int count = 0;  // Line number of count
				// Read first line
				line = bufRead.readLine();
				count++;
				while (line != null){
					if (!line.startsWith("#"))
					{
						HiSelectDO selectItem = new HiSelectDO();
						StringTokenizer strToken = new StringTokenizer(line,";");

						selectItem.setMan((String)strToken.nextToken().trim());
						selectItem.setBan((String)strToken.nextToken().trim());
						selectItem.setOsid((String)strToken.nextToken().trim());

						selectItem.setBillDate((String)strToken.nextToken().trim());  //date
						selectItem.setSections((String)strToken.nextToken().trim()); //sections
						selectItem.setStartSection("0"); // start section
						selectItem.setLocation((String)strToken.nextToken().trim()); //location -> D=disk T=tape
						selectItem.setAcctLevel((String)strToken.nextToken().trim()); //acctLevel -> M=master S=standalone
						selectItem.setFileType((String)strToken.nextToken().trim()); //fileType -> afp or pdf
						selectItem.setAban((String)strToken.nextToken().trim()); //aban (invoice number)
						selectItem.setDocType((String)strToken.nextToken().trim());
						strToken.nextToken();

						selectItem.setYearMonth(DateUtility.convertDate(selectItem.getBillDate(), "yyyy-MM-dd", "yyyy MMM"));
						selectItem.setBillPayer(selectItem.getBan());
						selectItem.setInvNbr(selectItem.getAban());
						selectItem.setInvDate(selectItem.getBillDate());

						selectList.add(selectItem);
					}

					line = bufRead.readLine();
					count++;
				}

				bufRead.close();

				_LOGGER.debug(selectList);
				responseMap.put("RESULT_SET_ONE", selectList);

				return responseMap;
			}

			//"VGW Archive"
			if (backendDB.equals(EAST_AFP_DB))
			{
				responseMap = new SPGetVgwAfpBillList(getVGWDataSource()).executeStoredProcedure(requestMap);
			}

			//"Bars West"
			if (backendDB.equals(WEST_AFP_DB))
				responseMap = new SPGetBarsWestAfpBillList(getBWDS()).executeStoredProcedure(requestMap);


			//loop thru result set
			List selectList = (ArrayList) responseMap.get("RESULT_SET_ONE");
			HiSelectDO selectItem;
			if (selectList != null)
			{
				if (backendDB.equals(WEST_AFP_DB))
				{
					//make sure the list is sorted descending, bars changed their code to do union so get 2 sorted lists bashed together, one for regular accounts one for subordinate accounts.
					HiSelectComparator compare = new HiSelectComparator(new HiSelectDO().DATE, "DESC");
					Collections.sort(selectList, compare);
				}

				int docTypeIdx = 0;
				for (int i = 0; i < selectList.size(); i ++)
				{
					selectItem = (HiSelectDO)selectList.get(i);
					selectItem=formatDatesForInternational(selectItem, preferredLanguageCode);
					selectItem.setDocTypeObj(DocTypes.getDocTypeObj(selectItem.getDocType(), selectItem.getOsid(), preferredLanguageCode)); //labels displayed to user
				}
				responseMap.put("RESULT_SET_ONE", selectList);
			}

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getAfpBillList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		return responseMap;
	}

//	 for fvz accounts replaces same named api from VAMBillArchive.java
	public Map getAfpSubAcctBillList (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");
		String preferredLanguageCode = (String)requestMap.get("preferredLanguageCode");

		String backendDB = "";
		backendDB = setBackendDB(hiDO.getOsid());
		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in Man = " + hiDO.getMan());
				_LOGGER.info("in backendDb = " + backendDB);

			}
			//"VGW Archive"
			if (backendDB.equals(EAST_AFP_DB))
			{
				responseMap = new SPGetVgwSubAccountBillList(getVGWDataSource()).executeStoredProcedure(requestMap);
			}
			//"Bars West"
			if (backendDB.equals(WEST_AFP_DB))
			{
				responseMap = new SPGetBarsWestSubAccountBillList(getBWDS()).executeStoredProcedure(requestMap);

				if (_LOGGER.isEnabledFor(Level.DEBUG))
				{
					_LOGGER.info("responseMap = " + responseMap);
				}
			}
		}catch(Exception e){
			_LOGGER.error("getAfpSubAcctBillList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		//the list of subs does not contain all the data necessary to get the bill, copy data we already have to the results.
		List selectList = (ArrayList) responseMap.get("RESULT_SET_ONE");
		HiSelectDO selectItem;
		if (selectList != null)
		{
			for (int i = 0; i < selectList.size(); i ++)
			{
				selectItem = (HiSelectDO)selectList.get(i);
				selectItem.setMan(hiDO.getMan());
				selectItem.setOsid(hiDO.getOsid());
				selectItem.setInvNbr("");
				selectItem.setLocation(hiDO.getLocation());
				selectItem.setFileType(hiDO.getFileType());
				selectItem.setDocType(hiDO.getDocType());
				selectItem.setDocTypeObj(hiDO.getDocTypeObj());
				if (backendDB.equals(WEST_AFP_DB))
				{
					selectItem.setBan(hiDO.getBan());  // for west bills subs are part of master so have same man ban and bill date
					selectItem.setBillDate(hiDO.getBillDate());
					selectItem.setInvDate(hiDO.getInvDate());
					selectItem.setInvNbr(hiDO.getInvNbr());
				}

				selectItem=formatDatesForInternational(selectItem, preferredLanguageCode);

				selectList.set(i, selectItem);
			}

			responseMap.put("RESULT_SET_ONE", selectList);

		}

		return responseMap;
	}


	private String setBackendDB(String backendSystem) {
		if (backendSystem.equals("03") ||
	        backendSystem.equals("13"))
			return WEST_AFP_DB;

		return EAST_AFP_DB;

	}


//	functions for fMCI data (client view)
	//get list of doctypes and dates to show in left pane of window
	public Map getClientViewDateList (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");
		String preferredLanguageCode = (String)requestMap.get("preferredLanguageCode");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in hiDO = " + hiDO);
			}

			//"VGW Archive"
			responseMap = new SPGetClientViewDateList(getVGWDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getClientViewDateList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		//the list does not contain all the data necessary to get the bill, copy data we already have to the results.
		List selectList = (ArrayList) responseMap.get("RESULT_SET_ONE");
		HiSelectDO selectItem;
		if (selectList != null)
		{
			int docTypeIdx = 0;
			for (int i = 0; i < selectList.size(); i ++)
			{
				selectItem = (HiSelectDO)selectList.get(i);
				selectItem.setMan(hiDO.getMan());
				selectItem.setBan(hiDO.getBan());
				selectItem.setOsid(hiDO.getOsid());
				selectItem.setAltKey(hiDO.getAltKey());

				selectItem=formatDatesForInternational(selectItem, preferredLanguageCode);

				//get the english version of doctype.
				selectItem.setDocTypeObj(DocTypes.getDocTypeObj(selectItem.getDocType(), selectItem.getOsid(), preferredLanguageCode));
			}

			responseMap.put("RESULT_SET_ONE", selectList);

		}

		return responseMap;
	}

	//get detail for month/doctype use selected to show in large middle pane.
	public Map getClientViewDetailList (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");
		String preferredLanguageCode = (String)requestMap.get("preferredLanguageCode");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in hiDO = " + hiDO);
			}

			//"VGW Archive"
			responseMap = new SPGetClientViewDetailList(getVGWDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getClientViewDetailList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		//the list does not contain all the data necessary to get the bill, copy data we already have to the results.
		List selectList = (ArrayList) responseMap.get("RESULT_SET_ONE");
		HiSelectDO selectItem;
		if (selectList != null)
		{
			int docTypeIdx = 0;
			for (int i = 0; i < selectList.size(); i ++)
			{
				selectItem = (HiSelectDO)selectList.get(i);
				selectItem.setBillPayer(selectItem.getBan());

				selectItem=formatDatesForInternational(selectItem, preferredLanguageCode);

				//get the doctype object, has text displayed on screen.
				selectItem.setDocTypeObj(DocTypes.getDocTypeObj(selectItem.getDocType(), selectItem.getOsid(), preferredLanguageCode));
			}

			responseMap.put("RESULT_SET_ONE", selectList);
		}

		return responseMap;
	}

	public Map getClientViewToc (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in hiDO = " + hiDO);
			}

			//"VGW Archive"
			responseMap = new SPGetClientViewToc(getVGWDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getClientViewToc - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		return responseMap;
	}

	public Map submitPrintAndMailRequest(Object input) throws NCASException	{
		HashMap requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiPrintAndMailDO hiPrintAndMailDO = (HiPrintAndMailDO)requestMap.get("hiPrintAndMailDO");

		try
		{
			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in Man = " + hiPrintAndMailDO.getMan());
				_LOGGER.info("in Ban = " + hiPrintAndMailDO.getBan());
				_LOGGER.info("in Userid = " + hiPrintAndMailDO.getUserId());

			}


			responseMap = new SPSubmitPrintAndMail(getVGWDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("submitPrintAndMailRequest - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		return responseMap;
	}

	public Map submitZipRequest(Object input) throws NCASException	{
		HashMap requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiPrintAndMailDO zipRequestDO = (HiPrintAndMailDO)requestMap.get("zipRequestDO");

		try
		{
			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in Man = " + zipRequestDO.getMan());
				_LOGGER.info("in Ban = " + zipRequestDO.getBan());
				_LOGGER.info("in Userid = " + zipRequestDO.getUserId());

			}


			responseMap = new SPSubmitZipRequest(getVGWDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("submitZipRequest - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		return responseMap;
	}


//	support for the print/download paper invoice link where user is on bill view and wants to see the bill as a pdf with out clicking thur view historical.
//  api takes man/ban/osid/billdate/aban and sees if anything is in archive and returns list that matches (hopfully only 1)
	public Map getClientViewPaperInvList (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");
		String preferredLanguageCode = (String)requestMap.get("preferredLanguageCode");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in hiDO = " + hiDO);
			}

			//"VGW Archive"
			responseMap = new SPGetClientViewPaperInvList(getVGWDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getClientViewPaperInvList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		//the list does not contain all the data necessary to get the bill, copy data we already have to the results.
		List selectList = (ArrayList) responseMap.get("RESULT_SET_ONE");
		HiSelectDO selectItem;
		if (selectList != null)
		{
			for (int i = 0; i < selectList.size(); i ++)
			{
				selectItem = (HiSelectDO)selectList.get(i);
				selectItem.setMan(hiDO.getMan());
				selectItem.setBan(hiDO.getBan());
				selectItem.setOsid(hiDO.getOsid());
				
				if ("VW".equals(selectItem.getOsid()))
				{
					selectItem.setBillPayer(AccountNumberUtil.base36ToBase10(selectItem.getBan()));
				}
				else
				{
					selectItem.setBillPayer(selectItem.getBan());
				}

				String formatDb2 = "yyyy-MM-dd";
				String formatDisplayed = "MM/dd/yyyy";
				selectItem.setInvNbr(hiDO.getAban());
				selectItem.setInvDate(CommonUtil.formatDate(hiDO.getBillDate(), formatDb2, formatDisplayed));

				selectItem=formatDatesForInternational(selectItem, preferredLanguageCode);

				//get the english version of doctype.
				selectItem.setDocTypeObj(DocTypes.getDocTypeObj(selectItem.getDocType(), selectItem.getOsid(), preferredLanguageCode));
			}

			responseMap.put("RESULT_SET_ONE", selectList);

		}

		return responseMap;
	}

//	support for download csv left nav link, works like print/download where user is able to get csv file with 1 click instead of
//  going into historical invoices.  this api takes man/ban/osid/billdate/aban/doctype as input, and returns the gas key to retrieve the
//  zip file, the user gets a download dialog after clicking on the link.
	public Map getClientViewZipDocList (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");

		try
		{
			_LOGGER.info("in hiDO = " + hiDO);

			//"VGW Archive"
			responseMap = new SPGetClientViewZipDocList(getVGWDataSource()).executeStoredProcedure(requestMap);
			_LOGGER.info("responseMap = " + responseMap);

		}catch(Exception e){
			_LOGGER.error("getClientViewZipDocList - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		return responseMap;
	}

	private HiSelectDO formatDatesForInternational (HiSelectDO hiDO, String preferredLanguageCode)
	{
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "dd/MM/yyyy";
		String formatYearMonthDisplayed = "yyyy MM";

		//if english just return obj, it is already set for english
		if (preferredLanguageCode == null || "en-US".equals(preferredLanguageCode))
			return hiDO;

		//if we get to here we need to reformat the dates to the international formats.
		hiDO.setInvDate(CommonUtil.formatDate(hiDO.getBillDate(), formatDb2, formatDisplayed));
		hiDO.setYearMonth(CommonUtil.formatDate(hiDO.getBillDate(), formatDb2, formatYearMonthDisplayed));

		return hiDO;

	}

	//VAM api to get the merged bill master number
	// a merged bill is an etrak (osid 04) concept.  it is a printing arrangment where the merged master get a copy of its 'subordinates' bills.
	// vam stores these sub accounts with man=ban because they are stand alone accounts (MBM is seperate field).
	// the archive stores with man=MBM and ban=ban because in order to print correctly etrak pretends in its bill stream that they are a real master/sub
	// this api calls vam and asks for the MBM for a ban so when we call the archive we can pass the man and ban they expect.
	// if this api finds no match it returns the input ban as the man.
	public Map getMergedBillMan (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in requestMap = " + requestMap);
			}

			//"VAM"
			responseMap = new SPGetMergedBillMan(getVAMDataSource()).executeStoredProcedure(requestMap);

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("responseMap = " + responseMap);
			}
		}catch(Exception e){
			_LOGGER.error("getMergedBillMan - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("HI1001",HistoricalInvoicesDAOImpl.class,e);
		}

		return responseMap;
	}
}
