package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author v992473
 * This class is used to map the Active users' group id and rel_type<br>
 * This mapper class is used by both VBIFGetActiveUser and VBIFGetActiveGroupUserRelForMgrCheck
 */
public class GetActiveUserRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Map<String,Object> userMap = null;
		String GROUP_ID = "GROUP_ID";
		String REL_TYPE = "REL_TYPE";
		if(rs!=null){
			userMap = new HashMap<String,Object>();
			userMap.put(GROUP_ID,rs.getInt(GROUP_ID));
			userMap.put(REL_TYPE, rs.getString(REL_TYPE));			
		}
		return userMap;
	}

}
