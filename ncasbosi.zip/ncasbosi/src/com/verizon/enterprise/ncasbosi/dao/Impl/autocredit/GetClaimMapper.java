package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.ClaimDetail;

/*
 * Author:Ram/v992473
 */

public class GetClaimMapper implements RowMapper{

	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetClaimMapper - Mapping Row# "+rowNum);
		ClaimDetail claim = null;
		if(rs!=null){
			claim = new ClaimDetail();
			claim.setClaimNumber(spaceTrimmer(String.valueOf(rs.getBigDecimal("ESG_CLAIM_NUMBER"))));
			claim.setRepVZId(spaceTrimmer(rs.getString("CLM_REP_VZID")));
			claim.setSubscriberOid(spaceTrimmer(String.valueOf(rs.getDouble("SUBSCRIBER_OID"))));
			claim.setBillingAccount(spaceTrimmer(rs.getString("CLM_MAIN_BAN")));
			claim.setMan(spaceTrimmer(rs.getString("CLM_MAN")));
			claim.setBillingSystemName(spaceTrimmer(rs.getString("CLM_BILLING_SYSTEM")));
			claim.setOriginating_sys_id(spaceTrimmer(rs.getString("ORIGINATING_SYS_ID")));
			claim.setCustomerName(spaceTrimmer(rs.getString("CUST_NAME")));
			claim.setContactType(spaceTrimmer(rs.getString("CONTACT_TYPE")));
			claim.setContactName(spaceTrimmer(rs.getString("CONTACT_NAME")));
			claim.setTelephone(spaceTrimmer(rs.getString("TEL_NUM")));
			//extension ?
			claim.setEmail(spaceTrimmer(rs.getString("EMAIL")));
			claim.setCustomerCommDate((Date)rs.getObject("CLM_COMM_DATE"));
			claim.setCenterReceiptDate((Date)rs.getObject("CENTER_RCPT_DATE"));
			claim.setSystemEntryDate((Date)rs.getObject("CLM_ENTRY_DATE"));
			claim.setCircuitDetail(spaceTrimmer(rs.getString("CLM_CKT_DETAIL")));
			claim.setOverallCategory(spaceTrimmer(rs.getString("CLM_OVERALL_CAT")));
			claim.setClaimType(spaceTrimmer(rs.getString("CLM_CLAIM_TYPE")));
			claim.setClaimDesc(spaceTrimmer(rs.getString("CLM_DESCRIPTION")));
			claim.setClaimStatus(spaceTrimmer(String.valueOf(rs.getInt("CLM_STATUS"))));
			claim.setStatusLiteral(spaceTrimmer(rs.getString("CLM_STATUS_DESC")));
			claim.setClaimSubStatus(spaceTrimmer(String.valueOf(rs.getInt("CLM_SUB_STATUS"))));
			claim.setSubStatusLiteral(spaceTrimmer(rs.getString("CLM_SUBSTATUS_DESC")));
			claim.setApprovedAmount(rs.getDouble("CLM_APPROV_AMOUNT"));
			claim.setSupportingDoc(spaceTrimmer(rs.getString("SUPPORTING_DOC")));
			claim.setAuditorVZId(spaceTrimmer(rs.getString("AUDITOR_VZID")));
			claim.setAuditDate((Date)rs.getObject("AUDIT_DATE"));
			claim.setErrortext_FACT(spaceTrimmer(rs.getString("FACT_RESPONSE")));
			claim.setOneviewSRN(spaceTrimmer(rs.getString("SRC_SYS_BI_ID")));
			
			//Investigation Fields
			claim.setAreaOfOrigination(spaceTrimmer(rs.getString("AREA_OF_ORIG")));
			claim.setInvestigatingServiceCenter(spaceTrimmer(rs.getString("SERVICE_CENTER")));
			claim.setCustomerUnderContract(spaceTrimmer(rs.getString("ACCOUNT_IS_ICB")));
						
			//Resolution fields - Issues,Causes And Actions
			claim.setRootCause(spaceTrimmer(rs.getString("ROOT_CAUSE")));
			claim.setRootCauseDept(spaceTrimmer(rs.getString("ROOT_CAUSE_DEPT")));
			claim.setProbableRootCauseOwner(spaceTrimmer(rs.getString("ROOT_CAUSE_OWNER")));
			claim.setRespDirector(spaceTrimmer(rs.getString("RESPONSIBLE_DIR")));
			claim.setRespVP(spaceTrimmer(rs.getString("RESPONSIBLE_VP")));
			claim.setCorrectiveActions(spaceTrimmer(rs.getString("CORRECTIVE_ACTIONS")));
			
			//Resolution fields - Accounting details
			claim.setOrig_current_Balance(rs.getBigDecimal("CURRENT_BALANCE"));
			claim.setOrig_days0_30(rs.getBigDecimal("BALANCE_AGE_0_30"));
			claim.setOrig_days31_60(rs.getBigDecimal("BALANCE_AGE_31_60"));
			claim.setOrig_days61_90(rs.getBigDecimal("BALANCE_AGE_61_90"));
			claim.setOrig_days91_120(rs.getBigDecimal("BALANCE_AGE_OV_90"));
			claim.setOrig_totalBalance(rs.getBigDecimal("TOTAL_BALANCE"));
			claim.setOrig_days_Aged(rs.getInt("DAYS_AGED"));
			claim.setHowDisposed(spaceTrimmer(rs.getString("HOW_DISPOSED")));
			
			//Phase 2 - May 2009
			claim.setOrig_days121_150(rs.getBigDecimal("BALANCE_AGE_121_150"));
			claim.setOrig_days151More(rs.getBigDecimal("BALANCE_AGE_OV_150"));
			claim.setCustomApprover(spaceTrimmer(rs.getString("CUST_APPROVER_NAME")));
			claim.setDenyText(spaceTrimmer(rs.getString("DENY_TEXT")));
			claim.setSegment(spaceTrimmer(rs.getString("SEGMENT")));
			claim.setCreditType(spaceTrimmer(rs.getString("CALC_TYPE")));
			claim.setSubType(spaceTrimmer(rs.getString("CALC_SUB_TYPE")));
			claim.setCreditType_Desc(spaceTrimmer(rs.getString("CALC_TYPE_DESC")));
			claim.setSubType_Desc(spaceTrimmer(rs.getString("CALC_SUB_TYPE_DESC")));
			claim.setICBNumber(spaceTrimmer(rs.getString("ICB_NUMBER")));
			
			//Phase 3 - ACT 04/2010
			claim.setNaspSource(spaceTrimmer(rs.getString("NASP_SOURCE")));
			claim.setNaspId(spaceTrimmer(rs.getString("NASP_ID")));
			claim.setDupeOverrideIndicator(spaceTrimmer(rs.getString("OVERRIDE_DUP_IND")));
			// To know whether it is created from BI or VBIF
			claim.setPassedfromBI(toUpperCase(spaceTrimmer(rs.getString("CREATED_FROM_BI"))));
			claim.setFactReturnText(spaceTrimmer(rs.getString("FACT_DENY_TEXT")));
			claim.setClaimTypeCode(spaceTrimmer(rs.getString("CLAIM_TYPE_CD")));
			claim.setClaimTypeDesc(spaceTrimmer(rs.getString("CLAIM_TYPE_DESC")));
			claim.setSubRootCause(spaceTrimmer(rs.getString("SUB_ROOT_CAUSE")));
		}
		_LOGGER.info("[claim Object::]"+claim);
		return claim;
	}
	
	//Trimmer Function to removes spaces that comes from VAC
	private String spaceTrimmer(String input){
		return input!=null?input.trim():input;
	}
	
	private String toUpperCase(String input){
		return input!=null?input.toUpperCase():input;
	}
	
}
