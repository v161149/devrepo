package com.verizon.enterprise.ncasbosi.dao.Impl.tracking;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.bills.BillTrackingVO;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquirySearch;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPBillTracking  extends BaseStoredProcedure
{

	static private final Logger _LOGGER = Logger.getLogger(SPBillTracking.class);
	private static List spInOutList;

	static
	{
		_LOGGER.info("Static init SPBillTracking");
		spInOutList = new ArrayList();
		spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		
		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		
		spInOutList.add(new Object[]{"TARGET_CATEGORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"PORTAL_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"EMPLOYEE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"CUSTOMER_ACCT_NUM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"ORIG_SYSTEM_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"BILL_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"TARGET", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		
	}

	public SPBillTracking(DataSource dataSource)
	{
      super(dataSource, getVAMSchemaName() + "." + NCASBOSIConstants.SP_BILL_TRACKING, spInOutList);
	}

	public Map executeStoredProcedure(Object bt)throws Exception
	{
		_LOGGER.info("Entering executeStoredProcedure "+getStoredProcedureName());
		BillTrackingVO myBTVO =(BillTrackingVO)bt;
		Map resMap = new HashMap();	
		List paramValueList = new ArrayList();
	
		if(bt != null)
		{
		  paramValueList.add("NBR User");
		  paramValueList.add("0");
		  paramValueList.add("NBR");
		  paramValueList.add(new Double(myBTVO.getUserOID())); //string to decimal
		  paramValueList.add(myBTVO.getLoginID());
		  paramValueList.add(myBTVO.getEmployeeFlag());
		  paramValueList.add(myBTVO.getAcctNum());
		  paramValueList.add(myBTVO.getOSID());
		  paramValueList.add(myBTVO.getBillDate());
		  paramValueList.add(myBTVO.getTrackingEntity());
		  _LOGGER.info("ExecStoredProcedure "+getStoredProcedureName() + " parms " + paramValueList);	
		  resMap = executeSP(paramValueList, false);
		}  
		else
		  {
			_LOGGER.info("In "+getStoredProcedureName()+ " BIllTrackingVO is nulllll");
			throw new Exception("In "+getStoredProcedureName()+ " BIllTrackingVO is nulllll");
		  }
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}

}
