package com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import java.util.Map;
import com.verizon.enterprise.common.ncas.bugtracker.IssueDetails;
import java.util.Date;
public class GetBugTrackerMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetBugTrackerMapper.class);
	private String operation = null;
	
	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException	{		
		IssueDetails issueDetail=null;
		_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker.GetBugTrackerMapper");
		if(rs != null)
		{
			 issueDetail=new IssueDetails();
			 if(operation.equals("SEARCH")){ 
				 String	issueId=String.valueOf(rs.getInt("ISSUE_ID"));
				 String	title=rs.getString("TITLE");
				 String	severity=rs.getString("SEVERITY");
				 String	project=rs.getString("PROJECT_NAME");
				 String projectId = rs.getString("PROJECT_ID");
				 String	status=rs.getString("STATUS");
				 String	environment=rs.getString("ENVIRONMENT");
				 String portal=rs.getString("PORTAL");
				 String	reported_by=rs.getString("REPORTED_BY");
				 Date reported_date=rs.getDate("LOGGED_DATE");
				 String itoissue=rs.getString("ITOISSUE");
				 String	owner=rs.getString("OWNER");
				 String description=rs.getString("DESCRIPTION");
				 String stepstoCreate=rs.getString("STEPSTORECREATE");
				 String projectRel=rs.getString("PROJECT_RELEASE");
				 //  String comments= rs.getString("COMMENTS");
				 //String createdDate=String.valueOf(rs.getDate("CREATED_DATE"));
				 //String reproduced=rs.getString("REPRODUCED");
				 issueDetail.setIssueId(issueId!=null?issueId.trim():issueId);
				 issueDetail.setTitle(title!=null?title.trim():title);
				 issueDetail.setStatus(status!=null?status.trim():status);
				 issueDetail.setSeverity(severity!=null?severity.trim():severity);
				 //issueDetail.setReproduced(reproduced!=null?reproduced.trim():reproduced);
				 issueDetail.setEnvironment(environment!=null?environment.trim():environment);
				 issueDetail.setOwner(owner!=null?owner.trim():owner);
				 issueDetail.setPortal(portal!=null?portal.trim():portal);
				 issueDetail.setStepstorecreate(stepstoCreate!=null?stepstoCreate.trim():stepstoCreate);
				 issueDetail.setReportedDate(reported_date);
				 issueDetail.setItoIssue(itoissue!=null?itoissue.trim():itoissue);
				 /*issueDetail.setComments(comments!=null?comments.trim():comments);*/
			      issueDetail.setReportedBy(reported_by!=null?reported_by.trim():reported_by);
				 issueDetail.setProjectdesc(project!=null?projectId.trim()+" - "+project.trim():project);
				 issueDetail.setDescription(description!=null?description.trim():description);
				 issueDetail.setProjectRelease(projectRel!=null?projectRel.trim():projectRel);
				
			 }else if(operation.equals("ADD")){
				 String	issueId=String.valueOf(rs.getInt("ISSUE_ID"));
				 issueDetail.setIssueId(issueId!=null?issueId.trim():issueId);
			 }
			 else if(operation.equals("VIEW")){
				 String	issueId=String.valueOf(rs.getInt("ISSUE_ID"));
				 String	title=rs.getString("TITLE");
				 String	severity=rs.getString("SEVERITY");
				 String	project=rs.getString("PROJECT_NAME");
				 String	status=rs.getString("STATUS");
				 String	environment=rs.getString("ENVIRONMENT");
				 String portal=rs.getString("PORTAL");
				 //String	reported_by=rs.getString("REPORTED_BY");
				 Date reported_date=rs.getDate("LOGGED_DATE");
				 String itoissue=rs.getString("ITOISSUE");
				 String	owner=rs.getString("OWNER");
				// String createdDate=String.valueOf(rs.getDate("CREATED_DATE"));
				 issueDetail.setIssueId(issueId!=null?issueId.trim():issueId);
				 issueDetail.setTitle(title!=null?title.trim():title);
				 issueDetail.setStatus(status!=null?status.trim():status);
				 issueDetail.setSeverity(severity!=null?severity.trim():severity);
				 issueDetail.setEnvironment(environment!=null?environment.trim():environment);
				 issueDetail.setOwner(owner!=null?owner.trim():owner);
				 issueDetail.setPortal(portal!=null?portal.trim():portal);
				 issueDetail.setReportedDate(reported_date);
				 issueDetail.setItoIssue(itoissue!=null?itoissue.trim():itoissue);
				 //issueDetail.setReportedBy(reported_by!=null?reported_by.trim():reported_by);
				 //issueDetail.setProject(projectid!=null?projectid.trim():projectid);
				 issueDetail.setProjectdesc(project!=null?project.trim():project);
				 
			 }
			 else if(operation.equals("EDIT")) {
				 String issueId=String.valueOf(rs.getInt("ISSUE_ID"));
				 String title=rs.getString("TITLE");
				 String description=rs.getString("DESCRIPTION");
				 String status=rs.getString("STATUS");
				 String projectId=rs.getString("PROJECT_ID");
				 String projectName=rs.getString("PROJECT_NAME");
				 String severity=rs.getString("SEVERITY");
				 String reproduced=rs.getString("REPRODUCED");
				 String environment=rs.getString("ENVIRONMENT");
				 String owner=rs.getString("OWNER");
				 String portal=rs.getString("PORTAL");
				 String stepstorecreate=rs.getString("STEPSTORECREATE");
				 String itoIssue=rs.getString("ITOISSUE");
				 String reportedBy=rs.getString("REPORTED_BY");
				 issueDetail.setIssueId(issueId!=null?issueId.trim():issueId);
				 issueDetail.setTitle(title!=null?title.trim():title);
				 issueDetail.setDescription(description!=null?description.trim():description);
				 issueDetail.setStatus(status!=null?status.trim():status);
				 issueDetail.setProject(projectId!=null?projectId.trim():projectId);
				 issueDetail.setProjectdesc(projectName!=null?projectName.trim():projectName);
				 issueDetail.setSeverity(severity!=null?severity.trim():severity);
				 issueDetail.setReproduced(reproduced!=null?reproduced.trim():reproduced);
				 issueDetail.setEnvironment(environment!=null?environment.trim():environment);
				 issueDetail.setOwner(owner!=null?owner.trim():owner);
				 issueDetail.setPortal(portal!=null?portal.trim():portal);
				 issueDetail.setStepstorecreate(stepstorecreate!=null?stepstorecreate.trim():stepstorecreate);
				 issueDetail.setItoIssue(itoIssue!=null?itoIssue.trim():itoIssue);
				 issueDetail.setReportedBy(reportedBy!=null?reportedBy.trim():reportedBy);
			 }
		}
		return issueDetail;
	}
	
	
}
