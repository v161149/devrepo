package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.PortalLinkDBConfig;

public class GetLinkedObjectRowMapperImpl  implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetLinkedObjectRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
        if (_LOGGER.isDebugEnabled()) {
        	_LOGGER.debug("Inside GetLinkedObjectRowMapperImpl -> ");
        }
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();
		ArrayList rows = new ArrayList();
		Cell cell = null;
		Link link = null;
		String linkKey="";
		String previouslinkKey = "";
		
		while(rs.next()) {

			String name = rs.getString("NAME");
			if(name == null) {
				name = "";
			}
			String value = rs.getString("D_VALUE");	
			if(value == null) {
				value = "";
			}
			String tooltip = rs.getString("MISC_STRING");
			if(tooltip == null) {
				tooltip = "";
			}
			String type = rs.getString("TYPE");
			if(type == null) {
				type = "";
			}
			String lType = rs.getString("L_TYPE");
			if(lType == null) {
				lType = "";
			}
			String format = rs.getString("FMT");
			if(format == null) {
				format = "";
			}
			String pageID = Integer.toString(rs.getInt("TARGET_PAGE_ID"));
			String linkParam = rs.getString("TARGET_PARMS");
			if(linkParam == null) {
				linkParam = "";
			}
			String pageSubset = rs.getString("TARGET_SUBSET");
			if(pageSubset == null) {
				pageSubset = "";
			}
			String sortAble = rs.getString("SORTABLE");
			if(sortAble == null) {
				sortAble = "";
			}
			String filterAble = rs.getString("FILTERABLE");
			if(filterAble == null) {
				filterAble = "";
			}
			String currencyCode = rs.getString("CURRENCY_CD");
			if(currencyCode == null) {
				currencyCode = "";
			}
			String selectType = rs.getString("SELECT_LINK");	
			if(selectType == null) {
				selectType = "";
			}
			linkKey = Integer.toString(rs.getInt("XREF_ID"));
			 
			cell = new Cell();
			//ltype that starts with NOLNK is used so we can add it's value NOLINK_XXXX
			//to the link table to be used for exclusion/permission
			//normally the omission of a ltype is enough not to have a link			
			if (lType !=null && lType.trim().length() > 0 && !lType.startsWith("NOLNK")){		
			    link = new Link();
			    link.setPageId(pageID.trim());
			    link.setPageSubset(pageSubset.trim());
			    link.setLinkParam(PortalLinkDBConfig.getInstance().getExternalLink(lType.trim(), linkParam.trim()));			    
			    cell.setLink(link);
			} 
			cell.setName(name.trim());
  		    cell.setValue(CommonUtil.getFormattedDisplayValue(type.trim(), format.trim(),  value.trim(), currencyCode.trim(), false));
			cell.setToolTip(tooltip.trim());
			cell.setFormat(format.trim());
			cell.setType(type.trim());
			cell.setLnkType(lType.trim());
			cell.setSelectType(selectType.trim());
			cell.setCurrencyCode(currencyCode.trim());
			
			if(filterAble!=null)
				cell.setFilterAble(filterAble.trim());
			if(sortAble!=null)
			    cell.setSortAble(sortAble.trim());			

			if(!previouslinkKey.equalsIgnoreCase(linkKey)){
				rows = new ArrayList();
				returnMap.put(linkKey,rows);
			}		
			rows.add(cell);
			previouslinkKey = linkKey;	
		}
		return returnMap;
	}
}