package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.eMedia.manage.Profile;

public class GetProfilesBySubsOidRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(GetProfilesBySubsOidRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.debug("Inside GetProfilesBySubsOidRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		Map profilesMap = new HashMap();
		while(rs.next()) {
			String number = rs.getString("CONFIG_ID");
			String name = rs.getString("CONFIG_NAME");
			String mediaType = rs.getString("SERVICE_TYPE");
			String bmmediaType = rs.getString("MEDIA_OPT");
			String billPeriod = rs.getString("BP_DAY");
			String osid = rs.getString("ORIG_SYSTEM_ID");
			String nationalInd = rs.getString("CONFIG_NATL_IND");
			//int cdCopies = rs.getInt("CD_COPIES");
			String softwareVersion = rs.getString("SOFTWARE_VER");
//			 Donnelly  9/2007 - added logic for Digix, MWAN and Millenium			
			String gcsConvFlag = rs.getString("GCS_CONV_FLAG");
			String lbsConvFlag = rs.getString("LBS_CONV_FLAG");
			String ixplusConvFlag = rs.getString("IXPLUS_CONV_FLAG");
			String megaVoiceCnvFlag = rs.getString("MEGAVOICE_CNV_FLAG");
			String ibrsConvFlag = rs.getString("IBRS_CONV_FLAG");
			String visionConvFlag = rs.getString("VISION_CONV_FLAG");
			String millenConvFlag = rs.getString("MILLEN_CONV_FLAG");
			String singleViewConvFlag = rs.getString("SVIEW_CONV_FLAG");
			double configSubsOid = rs.getDouble("CONFIG_SUBS_OID");
			String profileStatus = rs.getString("PROF_STATUS");
			String custType = rs.getString("CUSTOMER_TYPE");
			String bpOverride = rs.getString("BP_OVERRIDE");
			String winCnvrsnFlg = rs.getString("WIN_CONV_FLAG");
			String primebillerCnvrsnFlg = rs.getString("PB_CONV_FLAG");
			String usPrimebillerCnvrsnFlg = rs.getString("US_PB_CONV_FLAG");
			String vbeCnvrsnFlg = rs.getString("VBE_CONV_FLAG");
			
		
		   if(mediaType!=null){
			   mediaType = mediaType.trim();
	        	if(mediaType.equals("VZ450_CONFIG"))
	        		mediaType = "VZ450";
	        	else if(mediaType.equals("EDI_CONFIG"))
	        		mediaType = "EDI";
	        	else if(mediaType.equals("BM_CONFIG"))
	        		mediaType = "BM";           	
	        }			 
			Profile profile = new Profile();

			if(CommonUtil.isNotNull(number)) {
				profile.setNumber(number.trim());
			}
			if(CommonUtil.isNotNull(name)) {
				profile.setName(name.trim());
			}
			if(CommonUtil.isNotNull(bmmediaType)) {
				profile.setBmMediaType(bmmediaType.trim());
			}				
			if(CommonUtil.isNotNull(mediaType)) {
				profile.setMediaType(mediaType.trim());
			}
			if(CommonUtil.isNotNull(billPeriod)) {
				profile.setBillPeriod(billPeriod.trim());
			}
			if(CommonUtil.isNotNull(osid)) {
				profile.setOsid(osid.trim());
			}
			if(CommonUtil.isNotNull(gcsConvFlag)) {
				profile.setGcsConversionFlag(gcsConvFlag.trim());
			}
			if(CommonUtil.isNotNull(ibrsConvFlag)) {
				profile.setIbrsConversionFlag(ibrsConvFlag.trim());
			}
			if(CommonUtil.isNotNull(ixplusConvFlag)) {
				profile.setIxplusConversionFlag(ixplusConvFlag.trim());
			}
			if(CommonUtil.isNotNull(lbsConvFlag)) {
				profile.setLbsConversionFlag(lbsConvFlag.trim());
			}
			if(CommonUtil.isNotNull(mediaType)) {
				profile.setMediaType(mediaType.trim());
			}
			if(CommonUtil.isNotNull(megaVoiceCnvFlag)) {
				profile.setMegaVoiceConversionFlag(megaVoiceCnvFlag.trim());
			}
			if(CommonUtil.isNotNull(nationalInd)) {
				profile.setNationalIndicator(nationalInd.trim());
			}
			if(CommonUtil.isNotNull(softwareVersion)) {
				profile.setVersion(softwareVersion.trim());
			}
			if(CommonUtil.isNotNull(visionConvFlag)) {
				profile.setVisionConversionFlag(visionConvFlag.trim());
			}
			
			if (CommonUtil.isNotNull(profileStatus))
				profile.setProfileStatus(profileStatus.trim());

			if(CommonUtil.isNotNull(millenConvFlag)) {
				profile.setMillenConversionFlag(millenConvFlag.trim());
			}
			if (CommonUtil.isNotNull(singleViewConvFlag)) {
				profile.setSingleViewConversionFlag(singleViewConvFlag.trim());
			}
			if(CommonUtil.isNotNull(custType)) {
				profile.setCustomerType(custType.trim());
			}
			if (CommonUtil.isNotNull(winCnvrsnFlg)) {
				profile.setWinConversionFlag(winCnvrsnFlg.trim());
			}
			if (CommonUtil.isNotNull(primebillerCnvrsnFlg)) {
				profile.setPrimebillerConversionFlg(primebillerCnvrsnFlg.trim());
			}
			if (CommonUtil.isNotNull(bpOverride)) {
				profile.setBpOverrideIndicator(bpOverride.trim());
			}
			if (CommonUtil.isNotNull(usPrimebillerCnvrsnFlg)) {
				profile.setUsPrimebillerConversionFlg(usPrimebillerCnvrsnFlg.trim());
			}
			if (CommonUtil.isNotNull(vbeCnvrsnFlg)) {
				profile.setVbeConversionFlg(vbeCnvrsnFlg.trim());
			}
			
			//profile.setCdCopies(String.valueOf(cdCopies));
			String key = CommonUtil.convertStringFromDouble(configSubsOid);

			profile.setConfigSubsOid(key);
			String configSubsOidStr = rs.getString("CONFIG_SUBS_OID");
			_LOGGER.debug("inserting key - " + configSubsOidStr + " , value - " + profile);
			profilesMap.put(configSubsOidStr, profile);
		}
		return profilesMap;
	}
}
