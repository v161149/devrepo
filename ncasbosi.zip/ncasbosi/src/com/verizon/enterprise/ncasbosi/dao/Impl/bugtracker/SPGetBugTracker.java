package com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker;

import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker.GetBugTrackerMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import com.verizon.enterprise.common.ncas.billmanager.BillManager;
import com.verizon.enterprise.common.ncas.bugtracker.IssueDetails;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import org.apache.log4j.Logger;
public class SPGetBugTracker extends BaseStoredProcedure{
	static private final Logger _LOGGER = Logger.getLogger(SPGetBugTracker.class);
	private static List spInOutList;
	
	public SPGetBugTracker(DataSource dataSource,String schemaName, String operation){
		super(dataSource, schemaName + "." +NCASBOSIConstants.SP_GET_BUG_TRACKER,getInoutList());
		Object[] mapperRow = (Object[])this.getAllParamList().get(0);
		((GetBugTrackerMapper)mapperRow[3]).setOperation(operation);
	}
	
	//forms a new in/out List with unique mapper object bound to each SP call 
	private static List getInoutList(){
		List inOutList = new ArrayList();
		inOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetBugTrackerMapper()});
		inOutList.add(new Object[]{"RESULT_SET_THREE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetBugTrackerMapper2()});
		
		inOutList.addAll(spInOutList);
		return inOutList;
	}
	
	static{
		 _LOGGER.info("Static Init");
		 spInOutList = new ArrayList();		 
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"WHERE_PHRASE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PORTAL_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ISSUE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ENVIRONMENT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PORTAL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROJECT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RECURRING_IND", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SEVERITY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ASSIGNED_TO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROCESS_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DESCRIPTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STEPSTORECREATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"COMMENTS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STATUS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ITOISSUE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public Map executeStoredProcedure(Object input)throws Exception
	{ _LOGGER.info("Entering Execute SP in " + getStoredProcedureName());
	   IssueDetails issueDetail=(IssueDetails)input;
	  
	  String operation=issueDetail.getOperation();
	  _LOGGER.info("operation::: "+operation);
	  Pagination myPag = null; 
		List paramValueList = new ArrayList();
		
		if((issueDetail !=null) && (issueDetail instanceof IssueDetails )) {
			myPag=issueDetail.getMyPag();
		}else{
			throw new Exception("SPGetBugTracker: bad input expect IssueDetails got:" + issueDetail);
		}
		if (myPag == null){
			throw new Exception("SPGetBugTracker: BugTracker pagination is null");
		}
		
	    try{
		if(operation !=null && operation.equals("ADD")){
			_LOGGER.info("Inside ADD:::");
			_LOGGER.info("Line Offset::::"+myPag.getLineOffset());
			_LOGGER.info("Page Size::::"+myPag.getPageSize());
			_LOGGER.info("Reported By::::"+issueDetail.getReportedBy());
			_LOGGER.info("Environment::::"+issueDetail.getEnvironment().trim());
			_LOGGER.info("Portal::::"+issueDetail.getPortal().trim());
			_LOGGER.info("Project::::"+issueDetail.getProject().trim());
			_LOGGER.info("Reproduced::::"+issueDetail.getReproduced().trim());
			_LOGGER.info("Severity::::"+issueDetail.getSeverity().trim());
			_LOGGER.info("Owner::::"+issueDetail.getOwner().trim());
			_LOGGER.info("Operation::::"+operation);
			_LOGGER.info("Title::::"+issueDetail.getTitle());
			_LOGGER.info("Description:::::"+issueDetail.getDescription());
			_LOGGER.info("Steps to Create::::"+issueDetail.getStepstorecreate());
			_LOGGER.info("Comment::::"+issueDetail.getComment());
		 paramValueList.add(""); //For App UserId
		 paramValueList.add("1"); //For Debug Level
		 paramValueList.add(""); //For Where Pharase
		 paramValueList.add("");   //For Sort Order
		 paramValueList.add(new Integer(myPag.getLineOffset())); //For Page Offset
		 paramValueList.add(new Integer(myPag.getPageSize()));   //For Page Size
		 paramValueList.add(issueDetail.getReportedBy());    //For portal_userid 
		 paramValueList.add(new Integer(0)); //For Issue Id
		 paramValueList.add(issueDetail.getEnvironment().trim());  //For Environment
		 paramValueList.add(issueDetail.getPortal().trim());   //For portal
		 paramValueList.add(issueDetail.getProject().trim());   //For project_id
		 paramValueList.add(issueDetail.getReproduced().trim());   //For Recurring
		 paramValueList.add(issueDetail.getSeverity().trim()); // For priority
		 paramValueList.add(issueDetail.getOwner().trim()); // For Assigned to
		 paramValueList.add(operation);  // For PROCESS_FLAG
		 paramValueList.add(issueDetail.getTitle()); // For Title
		 paramValueList.add(issueDetail.getDescription()); //For project_desc
		 paramValueList.add(issueDetail.getStepstorecreate());  //For steps to create
		 paramValueList.add(issueDetail.getComment());  //For comments
		 paramValueList.add("OPEN"); //Status
		 paramValueList.add("NA"); //ITO Issue
		 		 		
		}
		else if(operation !=null && operation.equals("VIEW")){
			 String portalUserid=issueDetail.getUserProfile()!=null?issueDetail.getUserProfile().trim():"";
			paramValueList.add(""); //For App UserId
			 paramValueList.add("1"); //For Debug Level
			 paramValueList.add(""); //For Where Pharase
			 paramValueList.add("");   //For Sort Order
			 paramValueList.add(new Integer(myPag.getLineOffset())); //For Page Offset
			 paramValueList.add(new Integer(myPag.getPageSize()));   //For Page Size
			 paramValueList.add(portalUserid);    //For portal_userid 
			 paramValueList.add(new Integer(0)); //For Issue Id
			 paramValueList.add("");  //For Environment
			 paramValueList.add("");   //For portal
			 paramValueList.add("");   //For project_id
			 paramValueList.add("");   //For Recurring
			 paramValueList.add(""); // For priority
			 paramValueList.add(""); // For Assigned to
			 paramValueList.add(operation);  // For PROCESS_FLAG
			 paramValueList.add(""); // For Title
			 paramValueList.add(""); //For project_desc
			 paramValueList.add("");  //For steps to create
			 paramValueList.add("");  //For comments
			 paramValueList.add(""); //Status
			 paramValueList.add("NA"); //ITO Issue	
		}
		else if(operation !=null && operation.equals("EDIT")){
			
			 paramValueList.add(""); //For App UserId
			 paramValueList.add("1"); //For Debug Level
			 paramValueList.add(""); //For Where Pharase
			 paramValueList.add("");   //For Sort Order
			 paramValueList.add(new Integer(myPag.getLineOffset())); //For Page Offset
			 paramValueList.add(new Integer(myPag.getPageSize()));   //For Page Size
			 paramValueList.add("");    //For portal_userid 
			 paramValueList.add(Integer.parseInt(issueDetail.getIssueId())); //For Issue Id
			 paramValueList.add("");  //For Environment
			 paramValueList.add("");   //For portal
			 paramValueList.add("");   //For project_id
			 paramValueList.add("");   //For Recurring
			 paramValueList.add(""); // For priority
			 paramValueList.add(""); // For Assigned to
			 paramValueList.add(operation);  // For PROCESS_FLAG
			 paramValueList.add(""); // For Title
			 paramValueList.add(""); //For project_desc
			 paramValueList.add("");  //For steps to create
			 paramValueList.add("");  //For comments
			 paramValueList.add(""); //Status
			 paramValueList.add(""); //ITO Issue	
		}
		else if(operation !=null && operation.equals("SEARCH")){
			String wherePharse=issueDetail.getWhereCondition()!=null?issueDetail.getWhereCondition():"";
			
			paramValueList.add(""); //For App UserId
			 paramValueList.add("1"); //For Debug Level
			 paramValueList.add(wherePharse); //For Where Pharase
			 paramValueList.add("");   //For Sort Order
			 paramValueList.add(new Integer(myPag.getLineOffset())); //For Page Offset
			 paramValueList.add(new Integer(myPag.getPageSize()));   //For Page Size
			 paramValueList.add("");    //For portal_userid 
			 paramValueList.add(new Integer(0)); //For Issue Id
			 paramValueList.add("");  //For Environment
			 paramValueList.add("");   //For portal
			 paramValueList.add("");   //For project_id
			 paramValueList.add("");   //For Recurring
			 paramValueList.add(""); // For priority
			 paramValueList.add(""); // For Assigned to
			 paramValueList.add(operation);  // For PROCESS_FLAG
			 paramValueList.add(""); // For Title
			 paramValueList.add(""); //For project_desc
			 paramValueList.add("");  //For steps to create
			 paramValueList.add("");  //For comments
			 paramValueList.add(""); //Status
			 paramValueList.add(""); //ITO Issue	
		}
		if(operation !=null && operation.equals("UPDATE")){
			String portalUserid=issueDetail.getUserProfile()!=null?issueDetail.getUserProfile().trim():"";
			 String reportedBy=issueDetail.getReportedBy()!=null?issueDetail.getReportedBy().trim():"";
			 String environment=issueDetail.getEnvironment()!=null?issueDetail.getEnvironment().trim():"";
			 String portal=issueDetail.getPortal()!=null?issueDetail.getPortal().trim():"";
			 String project=issueDetail.getProject()!=null?issueDetail.getProject().trim():"";
			 String reproduced=issueDetail.getReproduced()!=null?issueDetail.getReproduced().trim():"";
			 String severity=issueDetail.getSeverity()!=null?issueDetail.getSeverity().trim():"";
			 String title=issueDetail.getTitle()!=null?issueDetail.getTitle():"";
			 String description=issueDetail.getDescription()!=null?issueDetail.getDescription():"";
			 String stepstocreate=issueDetail.getStepstorecreate()!=null?issueDetail.getStepstorecreate():"";
			 String comment= issueDetail.getComments()!=null?issueDetail.getComments():"";
			 String status=issueDetail.getStatus()!=null?issueDetail.getStatus():"";
			 String itoIssue=issueDetail.getItoIssue()!=null?issueDetail.getItoIssue():"";
			 paramValueList.add(""); //For App UserId
			 paramValueList.add("1"); //For Debug Level
			 paramValueList.add(""); //For Where Pharase
			 paramValueList.add("");   //For Sort Order
			 paramValueList.add(new Integer(myPag.getLineOffset())); //For Page Offset
			 paramValueList.add(new Integer(myPag.getPageSize()));   //For Page Size
			 paramValueList.add(portalUserid);    //For portal_userid 
			 paramValueList.add(Integer.parseInt(issueDetail.getIssueId())); //For Issue Id
			 paramValueList.add(environment);  //For Environment
			 paramValueList.add(portal);   //For portal
			 paramValueList.add(project);   //For project_id
			 paramValueList.add(reproduced);   //For Recurring
			 paramValueList.add(severity); // For priority
			 paramValueList.add(issueDetail.getOwner().trim()); // For Assigned to
			 paramValueList.add(operation);  // For PROCESS_FLAG
			 paramValueList.add(title); // For Title
			 paramValueList.add(description); //For project_desc
			 paramValueList.add(stepstocreate);  //For steps to create
			 paramValueList.add(comment);  //For comments
			 paramValueList.add(status); //Status
			 paramValueList.add(itoIssue); //ITO Issue
			 		 		
			}
		}
	    catch(Exception e){
	    	_LOGGER.error("SPGetBugTracker Error"+e.getMessage());
	    }
		Map resMap = executeSP(paramValueList, false);
		_LOGGER.info("Response Map value is"+resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
