package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;

public class DownloadVBECorpSummaryRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadVBECorpSummaryRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadVBECorpSummaryRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List summaryList = new ArrayList();
		List summary = new ArrayList();
		double acctSubscriptionOid = 0.0;

		try {
			
			while(rs.next()) {
				summary = new ArrayList();

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");

				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String backendSystem = rs.getString("BACKEND_SYSTEM");
				String accountName = rs.getString("ACCT_NAME");				
				String billPeriod = rs.getString("BILL_PERIOD");
				String channelCode = rs.getString("CHANNEL_CODE");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String systemDesc = rs.getString("SYST_DESCRIPTION");
				acctSubscriptionOid = rs.getDouble("ACCT_SUBS_OID");
				String invoiceType = rs.getString("INVOICE_TYPE");
				String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");
				String regionName = rs.getString("GBR_REGION_NAME");

				
				String eligibilityInd = rs.getString("ELIGIBILITY_IND");
				String billingFrequency = rs.getString("BILLING_FREQ");
                String manBillDate = rs.getString("MAN_BILL_DATE");
				
				
				if(CommonUtil.isNotNull(corpId)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(corpId.trim())));
				}
				summary.add(new Cell()); // account number NA for corp ?
				if(CommonUtil.isNotNull(accountName)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(accountName.trim())));
				}
				if(CommonUtil.isNotNull(gbrInvoiceType)){
					if (CommonUtil.isNotNull(regionName)){
						if (!(regionName.trim().isEmpty()))
							summary.add(new Cell(regionName.trim() + "/" + gbrInvoiceType.trim()));
						else 
							summary.add(new Cell(gbrInvoiceType.trim()));
					}else 
						summary.add(new Cell(gbrInvoiceType.trim()));
				}

				if(CommonUtil.isNotNull(systemAbbrv)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(systemAbbrv.trim())));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(billPeriod.trim())));
				}	
				if(CommonUtil.isNotNull(billingFrequency)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(billingFrequency.trim())));
				}
				if(CommonUtil.isNotNull(manBillDate)) {
					//summary.add(new Cell(commonUtil.excelTextValueOf(manBillDate.trim())));
					summary.add(new Cell(CommonUtil.getDisplayDateFromString(manBillDate.trim())));
				}
				
				
				summaryList.add(summary);
			}
		}catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadVBECorpSummaryRowMapperImpl  " + summary);
		}
		return summaryList;
	}

}
