package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.eMedia.EMediaRecreateRequest;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import com.verizon.enterprise.common.ncas.display.Pagination;

import org.apache.log4j.Logger;

public class SPGetEMediaRecreateRequest extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetEMediaRecreateRequest.class);
	
	private static GetEMediaRecreateRequestRowMapperImpl rowMapper;

	private static List spInOutList;
	
	static
	{
		 rowMapper = new GetEMediaRecreateRequestRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"requests",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetEMediaRecreateRequest(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_EM_RECREATE_RQST, spInOutList);	
	}

	public Map executeStoredProcedure(String appUserId, String debugLevel, 
									String whereFilter, String sortOrder,
									Pagination pagination)throws Exception
	{
		if(whereFilter == null ) {
			whereFilter = "";
		}
		if(sortOrder == null ) {
			sortOrder = "";
		}
		
		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}

		List paramValueList = new ArrayList();

		paramValueList.add(appUserId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(whereFilter);//WHERE_FILTER
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE
		
		Map procMap = (Map)executeStoredProcedure(paramValueList);

		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		List requestsList = (List)procMap.get("requests");
		pagination.setResultSize(Integer.toString(requestsList.size()));
		procMap.put("pagination", pagination);

		return procMap;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}

