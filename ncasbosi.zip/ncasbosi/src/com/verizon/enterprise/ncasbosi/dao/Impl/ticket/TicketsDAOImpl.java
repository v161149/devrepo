package com.verizon.enterprise.ncasbosi.dao.Impl.ticket;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NCASIntlUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.fileupload.FileUploadDO;
import com.verizon.enterprise.common.ncas.search.InquirySearch;
import com.verizon.enterprise.common.ncas.ticket.Email;


import com.verizon.enterprise.common.ncas.ticket.EmailAttachment;
import com.verizon.enterprise.common.ncas.ticket.FormFlds;
import com.verizon.enterprise.common.ncas.ticket.GlobalFlds;
import com.verizon.enterprise.common.ncas.ticket.Reason;
import com.verizon.enterprise.common.ncas.ticket.ReasonEmail;
import com.verizon.enterprise.common.ncas.ticket.TicketAudit;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;


public class TicketsDAOImpl extends JdbcDaoSupport implements NCASBOSIConstants
{
	private static final Logger _LOGGER = Logger.getLogger(TicketsDAOImpl.class);
	private JdbcTemplate dbTemplate;




	//VAM table PL_VBIF_REASON_T  starts...
	String SELECT_REASON_CACHE = "SELECT A.REASON_ID,A.REASON_CODE,A.CAT_CODE, A.CAT_DESC,A.PAGE_ID,A.PAGE_SUBSET,A.MARKUP1,A.MARKUP2,C.LANG,C.VALUE FROM " + getSchemaName() +".PL_VBIF_REASON_T A, " + getSchemaName() +".PL_DYNAM_TEXT_T B, " + getSchemaName() +".PL_LANG_T C where A.CAT_DESC!='' AND A.TYPE=B.TYPE AND B.LANG_OID=C.LANG_OID ORDER BY C.LANG,A.CAT_CODE,A.REASON_SORT_ORDER ASC";

	String SELECT_REASON_EMAIL_CACHE = "SELECT REASON_ID,ORIG_SYTEM_ID,OPCO,EMAIL FROM " + getSchemaName() +".PL_VBIF_REASON_EMAIL_T where PORTAL = ?";





	String INSERT_TICKET_AUDIT = "INSERT INTO " + getSchemaName() + ".PL_VBIF_AUDIT_T(REASON_ID, ACTION_TYPE, PAGE_ID, ACCOUNT, TICKET, PORTAL, PORTAL_LOGIN_ID, USER_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?)";



	String INSERT_TICKET = "INSERT INTO " + getSchemaName() + ".PL_VBIF_TICKET_T(TICKET,REASON_ID, SERVICE_ID, PORTAL_LOGIN_ID, USER_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?)";
	String INSERT_TICKET_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_VBIF_TICKET_DETAILS_T(TICKET, ELE_NAME, ELE_VALUE) VALUES(?,?,?)";

	String SELECT_TICKET_DETAILS = "Select B.ELE_NAME,B.ELE_VALUE from " + getSchemaName() + ".PL_VBIF_TICKET_T A, "+ getSchemaName() + ".PL_VBIF_TICKET_DETAILS_T B where A.Ticket=? and A.Ticket = B.Ticket order by B.ticket_det_id asc ";

	String SELECT_EMAILS = "Select EMAIL_TYPE, SUBJECT, SRC_SYS_BI_ID, FROM_ADDRESS, TO_ADDRESS, CC_ADDRESS, BC_ADDRESS, PUBLIC_PRIVATE_IND, GAS_SYSTEM_ID, EMAIL_TS, GAS_DOC_NBR, EMAIL_SOURCE, VAC_EMAIL_ID from " + NCASBOSIConstants.VAC_TABLESCHEMA + ".VAC_EMAIL_T A WHERE  GAS_DOC_NBR IS NOT NULL AND SRC_SYS_BI_ID = ? ";

	String SELECT_ATTACH_EMAILS = "Select GAS_SYSTEM_ID, GAS_DOC_NBR, GAS_FILE_NAME, DOC_SIZE, USER_ID from " + NCASBOSIConstants.VAC_TABLESCHEMA + ".VAC_ATTACHMENT_T WHERE  VAC_EMAIL_ID = ? ";

	String SELECT_EMAIL = "select SUBJECT,FROM_ADDRESS,TO_ADDRESS,CC_ADDRESS,SRC_SYS_BI_ID,GAS_DOC_NBR,GAS_SYSTEM_ID,EMAIL_SOURCE  from "+ NCASBOSIConstants.VAC_TABLESCHEMA +".VAC_EMAIL_T where VAC_EMAIL_ID = ?";



	String SEARCH_REASON = "SELECT  RI.REASON_ID,RI.REASON_DESC,RI.CAT_DESC,PSA.KEYWORD,PSA.RANK FROM " + getSchemaName() + ".pl_vbif_reason_t RI  LEFT OUTER JOIN  " + getSchemaName() + ".PL_SEARCH_APPS_t PSA ON RI.REASON_ID=PSA.APP_ID ORDER BY REASON_ID, RANK DESC";

	protected void initDao() throws Exception{
		super.initDao();
	}


	public String getSchemaName()
	{
		String schemaName = NCASBOSIConstants.VAM_SCHEMA;
		return schemaName;
	}

	protected JdbcTemplate getDBTemplate()
	{
		if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}



	public void insertPLTicket(GlobalFlds globalFld, List<FormFlds> inqFields,	String userOid, String login_id)throws  NCASException{
		final String METHOD_NAME = "insertPLTicket::";
		_LOGGER.info(METHOD_NAME+"Entering");
		SqlUpdate insertTix = null;
		_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_TICKET);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			insertTix = new SqlUpdate(getDataSource(), INSERT_TICKET);


			insertTix.declareParameter(new SqlParameter("TICKET", Types.VARCHAR));
			insertTix.declareParameter(new SqlParameter("REASON_ID", Types.INTEGER));
			insertTix.declareParameter(new SqlParameter("SERVICE_ID", Types.VARCHAR));

			insertTix.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
			insertTix.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
			insertTix.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
			insertTix.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
			insertTix.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

			insertTix.compile();

			Object[] parameterValues = new Object[]{globalFld.getTicketNum(),
													globalFld.getReason().getReasonId(),
													globalFld.getAccountInfo().getBan(),
													login_id,
					                                new Double(userOid),
													lastUpdated.trim(),
					                                lastUpdated.trim(),
					                                login_id};

			insertTix.update(parameterValues);

		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}


	public void insertPLTicketDetails(GlobalFlds globalFld, List<FormFlds> inqFields,	String userOid, String login_id)throws  NCASException{
		final String METHOD_NAME = "insertPLTicketDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate insertTix = null;
		_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_TICKET_DETAILS);

		try
		{
			insertTix = new BatchSqlUpdate(getDataSource(), INSERT_TICKET_DETAILS);
			insertTix.declareParameter(new SqlParameter("TICKET", Types.VARCHAR));
			insertTix.declareParameter(new SqlParameter("ELE_NAME", Types.VARCHAR));
			insertTix.declareParameter(new SqlParameter("ELE_VALUE", Types.VARCHAR));

			insertTix.compile();
			Object[] parameterValues = null;

			for(int i = 0;i<inqFields.size();i++)
			{
				FormFlds fld = inqFields.get(i);
				String value = fld.getValue();
				boolean moreFlds = true;
				int maxSize = 2000;
				int startIndex = 0;
				String newvalue = "";


				while(moreFlds){
					if(value.length()>= (startIndex+maxSize)){
						newvalue = value.substring(startIndex,startIndex+maxSize);
						startIndex += maxSize;
					}else{
						moreFlds = false;
						newvalue = value.substring(startIndex);
					}
					if(!newvalue.isEmpty()){
						parameterValues = new Object[]{globalFld.getTicketNum(),fld.getName(),	newvalue};
						insertTix.update(parameterValues);
					}
				}
			}
			insertTix.flush();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	@SuppressWarnings("unchecked")
	public Map getReasonCache() throws NCASException
	{
		final String METHOD_NAME = "getReasonCache::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_REASON_CACHE);

			Object[] params = new Object[]{};

	        return  (Map)getDBTemplate().query(SELECT_REASON_CACHE, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map 	 reasonMap = new HashMap();
		   		 	  Map 	 returnMap = new HashMap();
		   		 	  Map 	 langMap = new HashMap();
		   		 	  String catCode = "";
		   		 	  String category = "";
		   		 	  Reason reasonRow;
		   		 	  String priorCatCode = "";
		   		 	  String priorlangCode = "";
		   		 	  String langCode = "";
		   		 	  int reasonId;
		   		 	  List<Reason> reasonList = new ArrayList();


			          while (rs.next()) {
			      		reasonRow = new Reason();


			      		reasonId = rs.getInt("REASON_ID");
			    		reasonRow.setReasonId(reasonId);
			    		category = rs.getString("CAT_DESC");
			    		catCode = rs.getString("CAT_CODE");
			    		reasonRow.setCategoryCode(catCode);
			    		reasonRow.setCode(rs.getString("REASON_CODE"));
			    		reasonRow.setDesc(rs.getString("VALUE"));
			    		reasonRow.setMarkup1(rs.getString("MARKUP1"));
			    		reasonRow.setMarkup2(rs.getString("MARKUP2"));
			    		reasonRow.setPageId(rs.getInt("PAGE_ID"));
			    		String pageSubset = rs.getString("PAGE_SUBSET");
			    		if (pageSubset==null)
			    			pageSubset = "";
			    		pageSubset = pageSubset.trim();
			    		if(pageSubset.isEmpty())
			    			pageSubset = "ALL";
			    		reasonRow.setPageSubset(pageSubset);
			    		langCode = rs.getString("LANG");
			    		langCode = langCode.trim();
			    		category = DAOFactory.getInstance().getInternationalImpl().getTranslation(category,langCode);
			    		reasonRow.setCategory(category);

			    		if(!priorlangCode.equals(langCode)){
			    			  reasonMap = new HashMap();
			    			  reasonList = new ArrayList();
			    			  langMap.put("LIST", reasonList);
			    			  langMap.put("MAP", reasonMap);
			    			  returnMap.put(NCASIntlUtil.getECPLangCode(langCode), langMap);
			    			  priorlangCode = langCode;
			    		}


			    		if(!priorCatCode.equals(catCode)){
			    			priorCatCode = catCode;
			    			Reason reasonSeptRow = new Reason();
			    			reasonSeptRow.setSeparator(category);
			    			reasonRow.setCategory(category);
			    			reasonList.add(reasonSeptRow);
			    		}
			    		reasonList.add(reasonRow);
			    		reasonMap.put(reasonId,reasonRow);

			          }

				      return returnMap;
		        }});
	}


	@SuppressWarnings("unchecked")
	public List getReasonEmailCache(String portal) throws NCASException
	{
		final String METHOD_NAME = "getReasonEmailCache::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_REASON_EMAIL_CACHE);

		if(NCASDataUtil.isInternal(portal))
			portal = "VBC";
		else portal = "CC";

			Object[] params = new Object[]{portal};

	        return  (List)getDBTemplate().query(SELECT_REASON_EMAIL_CACHE, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  ReasonEmail reasonRow;
		   		 	  List<ReasonEmail> reasonList = new ArrayList();


			          while (rs.next()) {
			      		reasonRow = new ReasonEmail(rs.getInt("REASON_ID"), rs.getString("ORIG_SYTEM_ID"), rs.getString("OPCO"), rs.getString("EMAIL"));
			    		reasonList.add(reasonRow);
			          }

				      return reasonList;
		        }});
	}







	@SuppressWarnings("unchecked")
	public int insertTicketAuditDetail(TicketAudit ticketAudit) throws NCASException
	{
		final String METHOD_NAME = "insertTicketAuditDetail::";
		_LOGGER.info(METHOD_NAME+"Entering");
		SqlUpdate insertAuditDet = null;
		int rowsUpdated = 0;
		_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_TICKET_AUDIT);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			insertAuditDet = new SqlUpdate(getDataSource(), INSERT_TICKET_AUDIT);
			KeyHolder keyHolder = new GeneratedKeyHolder();

			insertAuditDet.setReturnGeneratedKeys(true);


			insertAuditDet.declareParameter(new SqlParameter("REASON_ID", Types.INTEGER));
			insertAuditDet.declareParameter(new SqlParameter("ACTION_TYPE", Types.VARCHAR));
			insertAuditDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
			insertAuditDet.declareParameter(new SqlParameter("ACCOUNT", Types.VARCHAR));
			insertAuditDet.declareParameter(new SqlParameter("TICKET", Types.VARCHAR));
			insertAuditDet.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
			insertAuditDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
			insertAuditDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
			insertAuditDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
			insertAuditDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
			insertAuditDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

			insertAuditDet.compile();

			Object[] parameterValues = new Object[]{ticketAudit.getReasonId(),
					                                ticketAudit.getActionType(),
					                                ticketAudit.getPageId(),
					                                ticketAudit.getAccount(),
					                                ticketAudit.getTicket(),
					                                ticketAudit.getPortal(),
					                                ticketAudit.getPortalLoginId(),
					                                new Double(ticketAudit.getUserOid()),
													lastUpdated.trim(),
					                                lastUpdated.trim(),
					                                ticketAudit.getLastUpdatedBy()};

			rowsUpdated = insertAuditDet.update(parameterValues, keyHolder);
			ticketAudit.setAuditId(keyHolder.getKey().intValue());
			_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + rowsUpdated);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return rowsUpdated;
	}


	public List<FormFlds> getDynamicFields(String ticket)
	{
		final String METHOD_NAME = "getDynamicFields => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		Object[] params = new Object[]{ticket};

		return  (List<FormFlds>) getDBTemplate().query(SELECT_TICKET_DETAILS, params, new ResultSetExtractor(){
			String eleName = "";
			String eleValue = "";
			String priorEleName = "";
			String newValue = "";
			
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 	  List<FormFlds> result = new ArrayList<FormFlds>();
				          while (rs.next()){
				        	  eleName =  rs.getString("ELE_NAME").trim();
				        	  eleValue = rs.getString("ELE_VALUE").trim();
				        	  if(priorEleName.isEmpty()) priorEleName = eleName;
				        	  
				      		if(priorEleName.equals(eleName)){
				      			newValue += eleValue;
				    		}
				      		else{				      			
				      			result.add(new FormFlds(priorEleName,newValue,""));	
				      			priorEleName = eleName;
				      			newValue = "";
				      		}
				      		
				      		
				        	  
				          }
				          if(!priorEleName.isEmpty()&&!newValue.isEmpty())
			      			result.add(new FormFlds(priorEleName,newValue,""));	

				          return result;
			        }});
	}
	
	
	public Map getEmail(Map paramMap)throws NCASException{
		String vacEmailId = (String)paramMap.get(NcasConstants.VAC_EMAIL_ID);
		Email email = null;
		Map<String,Object> retMap = getDBTemplate().queryForMap(SELECT_EMAIL,new Object[]{new BigDecimal(vacEmailId)},new int[]{Types.DECIMAL});
		if(retMap!=null){
			email = new Email();
			email.setToEmail(CommonUtil.trimSpace((String)retMap.get("TO_ADDRESS")));
			email.setFromEmail(CommonUtil.trimSpace((String)retMap.get("FROM_ADDRESS")));
			email.setCcEmail(CommonUtil.trimSpace((String)retMap.get("CC_ADDRESS")));
			email.setSubject(CommonUtil.trimSpace((String)retMap.get("SUBJECT")));
			email.getAttach().getContentDoc().setTrackingId(((BigDecimal)(retMap.get("GAS_DOC_NBR"))).toPlainString());
			email.getAttach().getContentDoc().setFileSystem(CommonUtil.trimSpace((String)retMap.get("GAS_SYSTEM_ID")));
			email.setTicketNum(CommonUtil.trimSpace((String)retMap.get("SRC_SYS_BI_ID")));
			email.setSource(CommonUtil.trimSpace((String)retMap.get("EMAIL_SOURCE")));
			
		}
		Map<String,Object> outMap = new HashMap<String, Object>();
		outMap.put(NcasConstants.EMAIL_CONTENT_OBJ, email);
		return outMap;
	}
	
	
	
	
	

	@SuppressWarnings("unchecked")
	public Map getEmails(String ticket, String isPublic) throws NCASException
	{
		final String METHOD_NAME = "getEmails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		String sql = SELECT_EMAILS;
		String isPublicAlter = "N";
		Map 	 returnMap = new HashMap();

		if(isPublic!=null&&!isPublic.isEmpty())
			sql  += " and PUBLIC_PRIVATE_IND IN (?,?)";

		sql +=  " order by EMAIL_TS DESC ";
		_LOGGER.info(METHOD_NAME + "SQL: " + sql);

			Object[] params = null;
			if(isPublic!=null&&!isPublic.isEmpty()){
				if(isPublic.equals("1"))isPublicAlter = "Y";
				params = new Object[]{ticket,isPublic,isPublicAlter};
			}else params = new Object[]{ticket};

			List<Email> emailList =  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );
		   		 	  List<Email> emailList = new ArrayList();
		   		 	  String type = "";
		   		 	  String subject = "";
		   		 	  String ticketNum = "";
		   		 	  String fromEmail = "";
		   		 	  String toEmail = "";
		   		 	  String ccEmail = "";
		   		 	  String bccEmail = "";
		   		 	  String publicInd = "";
		   		 	  String archiveId = "";
		   		 	  String createTs = "";
		   		 	  String source = "";
		   		 	  double docNum = 0.0;
		   		 	  double emailId = 0.0;
		   		 	  Email email;

			          while (rs.next()) {
			        	  type = rs.getString("EMAIL_TYPE");
			        	  subject = rs.getString("SUBJECT");
			        	  ticketNum = rs.getString("SRC_SYS_BI_ID");
			        	  fromEmail = rs.getString("FROM_ADDRESS");
			        	  toEmail = rs.getString("TO_ADDRESS");
			        	  ccEmail = rs.getString("CC_ADDRESS");
			        	  bccEmail = rs.getString("BC_ADDRESS");
			        	  publicInd = rs.getString("PUBLIC_PRIVATE_IND");
			        	  archiveId = rs.getString("GAS_SYSTEM_ID");
			        	  try { 
			        		  createTs = CommonUtil.getFormattedDateString(rs.getTimestamp("EMAIL_TS"),"dd-MMM-yyyy HH.mm.ss.SSS");			        			
			        	  } catch (Exception e) {
			        		  e.printStackTrace();
			        	  }
			        	  docNum = rs.getDouble("GAS_DOC_NBR");
			        	  source = rs.getString("EMAIL_SOURCE");
			        	  emailId = rs.getDouble("VAC_EMAIL_ID");
			        	  email = new Email(type, subject, ticketNum, fromEmail, toEmail, ccEmail, bccEmail, publicInd, archiveId, createTs, docNum,source);
			        	  email.setEmailId(emailId);
			        	  emailList.add(email);
			          }

				      return emailList;
		        }});
			getAttachEmails(emailList);
	        returnMap.put("LIST", emailList);
	        return returnMap;
	}


	public void getAttachEmails(List<Email> emailList) throws NCASException
	{
		final String METHOD_NAME = "getAttachEmails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		String sql = SELECT_ATTACH_EMAILS;
		_LOGGER.info(METHOD_NAME + "SQL: " + sql);
		Email email = null;
		Object[] params = null;

		for (Iterator emailIter = emailList.iterator(); emailIter.hasNext();) {
			email = (Email) emailIter.next();
			if(email!=null)
				params = new Object[]{email.getEmailId()};


			List<FileUploadDO> attachDocList = (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  EmailAttachment attach = new EmailAttachment();

		   		 	  String archiveId = "";
		   		 	  double docNum = 0.0;
		   		 	  String fileName = "";
		   		 	  String docSize = "";
		   		 	  String userId = "";
		   		 	  List<FileUploadDO> attachDocList = new ArrayList();
		   		 	  FileUploadDO fudo = null;

			          while (rs.next()) {
			        	  fudo = new FileUploadDO();
			        	  archiveId = rs.getString("GAS_SYSTEM_ID");
			        	  fudo.setFileSystem(archiveId.trim());
			        	  docNum = rs.getDouble("GAS_DOC_NBR");
			        	  fudo.setFileNumber(new Double(docNum).toString());
			        	  fileName = rs.getString("GAS_FILE_NAME");
			        	  fudo.setFileName(fileName.trim());
			        	  docSize = rs.getString("DOC_SIZE");
			        	  fudo.setFileSize(new Integer(docSize.trim()));
			        	  userId = rs.getString("USER_ID");
			        	  fudo.setUserId(userId.trim());
			        	  attachDocList.add(fudo);
			          }


				      return attachDocList;
		        }});
			email.getAttach().setAttachDoc(attachDocList);
		}
	}



	public Map buildInquirySearch(String portal) throws NCASException
	{
		final String METHOD_NAME = "buildInquirySearch::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Statement stmt = null;
		ResultSet rs=null;
		Connection con=null;

		List<InquirySearch> InquirySearchList	=	new ArrayList<InquirySearch>();
		Map retMap = new HashMap();

		try {
			 con= getConnection();
			 stmt = con.createStatement();
			 rs = stmt.executeQuery(SEARCH_REASON);

			 InquirySearch InquirySearch	=	null;
			 Map<String,String> keywordRankMap	=	null;
			while(rs.next()){
				String reasonId = rs.getString("REASON_ID");
				String rdesc = rs.getString("REASON_DESC");
				String catDesc = rs.getString("CAT_DESC");
				String keyWord = rs.getString("KEYWORD");
				String rank = rs.getString("RANK");

				if(InquirySearch!=null && InquirySearch.getReasonId()!=null
						&& !reasonId.trim().equalsIgnoreCase(InquirySearch.getReasonId())){
					InquirySearchList.add(InquirySearch);
				}
				if(InquirySearch!=null && InquirySearch.getReasonId()!=null
						&& reasonId.trim().equalsIgnoreCase(InquirySearch.getReasonId())){
					if(rank!=null && rank.trim().length()>0
							&& InquirySearch.getRankId()!=null && InquirySearch.getRankId().trim().length()>0
							&& rank.equalsIgnoreCase(InquirySearch.getRankId())){
						keywordRankMap.put(rank, keywordRankMap.get(InquirySearch.getRankId())+","+keyWord);
					}else{
						keywordRankMap.put(rank, keyWord);
					}
					InquirySearch.setKeywordRankMap(keywordRankMap);

				}else{
					InquirySearch	=	new InquirySearch();
					keywordRankMap =	new HashMap<String,String>();
					InquirySearch.setReasonId(reasonId);
					InquirySearch.setReasonDesc(rdesc);
					InquirySearch.setCatDesc(catDesc);
					InquirySearch.setRankId(rank);
					keywordRankMap.put(rank, keyWord);
					InquirySearch.setKeywordRankMap(keywordRankMap);
				}
			}
			if(InquirySearch!=null && InquirySearch.getReasonId()!=null){
				InquirySearchList.add(InquirySearch);
				InquirySearch	=	null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				if(rs!=null)rs.close();
				if(stmt!=null)stmt.close();
				if(con!=null)con.close();
				System.out.println("Finished indexing");
 			}catch(Exception ex){
				ex.printStackTrace();
			}
 		}
		retMap.put("LIST", InquirySearchList);
		return retMap;
	}
}