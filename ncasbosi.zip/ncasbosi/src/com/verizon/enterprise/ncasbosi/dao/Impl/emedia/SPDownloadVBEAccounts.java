package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDownloadVBEAccounts extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPDownloadVBEAccounts.class);
	
	private static List spInOutList;	
	private static List spFullDownloadList;
	private static List spInOutCommonList;
	private static DownloadVBEAccountsRowMapperImpl rowMapper;
	private static FullDownloadVBEAccountsRowMapperImpl fullDownloadMapper;
	static
	{
		 rowMapper = new DownloadVBEAccountsRowMapperImpl();
		 fullDownloadMapper=new FullDownloadVBEAccountsRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutCommonList=new ArrayList();
		 spFullDownloadList=new ArrayList();
		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 //Full Download
		 spFullDownloadList.add(new Object[]{"fullAccounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,fullDownloadMapper});
		 spInOutCommonList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutCommonList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutCommonList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutCommonList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutCommonList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutCommonList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutCommonList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutCommonList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"REMIT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"REPORT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"TAB", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutCommonList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.addAll(spInOutCommonList);
		 spFullDownloadList.addAll(spInOutCommonList);
		 
	}
	
	public SPDownloadVBEAccounts(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_VBE_ACCTS, spInOutList);
		
	}
	public SPDownloadVBEAccounts(DataSource dataSource, String schemaName,String fullDownload) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_VBE_ACCTS, spFullDownloadList);
		
	}
	public Content executeStoredProcedure(String userId, String debugLevel, String whereClause, String sortOrder,String tabInd,String configSubscriptionOid,String gbrAcct, String remitOid, String reportOid) throws Exception	{

		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();		
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(configSubscriptionOid);
		paramValueList.add(remitOid);//REMIT_OID
		paramValueList.add(reportOid);//REPORT_OID
		paramValueList.add(tabInd);//TAB
		paramValueList.add(whereClause);//WHERE_FILTER
		if(sortOrder == null || sortOrder.equals("")) {
			paramValueList.add("");//SORT_ORDER
		} else {
			paramValueList.add(sortOrder);//SORT_ORDER
		}

		paramValueList.add("1");//LINE_OFFSET
		paramValueList.add("10000");//PAGE_SIZE

		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		List accountList;
		if(tabInd != null && tabInd.equals("DOWNLOAD_REMIT")){
		 accountList = (List)procMap.get("fullAccounts");
		}
		else{
	     accountList = (List)procMap.get("accounts");	
		}
		
		_LOGGER.debug("vbeAcct = " + gbrAcct);
		
		Content retObj = new Content();
		retObj.setRows(accountList);
		
		List account = new ArrayList();
		
		for(int i=0;i<accountList.size();i++)
		{
			account = (List) accountList.get(i);
			if(CommonUtil.isNotNull(gbrAcct)) {
				account.add(0, new Cell(gbrAcct.trim()));				
			}
		}

		return retObj ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
