package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.vbif.EntityLobChgResultSet1;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.util.DateUtility;

public class GetEntityLobChgResultSetMapper implements RowMapper
{
    static private final Logger _LOGGER = Logger.getLogger(GetEntityLobChgResultSetMapper.class);

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        _LOGGER.debug("Inside GetEntityLobChgResultSetMapper::mapRow rowNum - " + rowNum);
        CommonUtil.printMetaDataInfo(rs.getMetaData());
        
        EntityLobChgResultSet1 record = new EntityLobChgResultSet1();
        record.setLineNum (Integer.toString(rs.getInt("LINE_NUM"))); //INTEGER
		record.setBan(rs.getString("BAN"));
		record.setAban(rs.getString("ABAN"));
		record.setEntityCd(rs.getString("ENTITY_CD"));
		record.setEntityNm(rs.getString("ENTITY_NM"));
		record.setInvBillInd(rs.getString("INV_BILL_IND"));
		record.setChgCd(rs.getString("CHG_CD"));
		record.setDescription(rs.getString("DESCRIPTION"));
		record.setAmount((rs.getBigDecimal("AMOUNT")).toString()); //DECIMAL
		record.setTaxStatusIndFd(rs.getString("TAX_STATUS_IND_FD"));
		record.setTaxStatusIndSt(rs.getString("TAX_STATUS_IND_ST"));
		record.setTaxStatusE911(rs.getString("TAX_STATUS_E911"));
		record.setTaxStatusSchg(rs.getString("TAX_STATUS_SCHG"));
		record.setTaxStatusIndLoc(rs.getString("TAX_STATUS_IND_LOC"));
		record.setClsOfSvcType(rs.getString("CLS_OF_SVC_TYPE"));
		record.setGeoCd(rs.getString("GEO_CD"));
		record.setStateCode(rs.getString("STATE_CODE"));
		record.setBlackFip(rs.getString("BLACK_FIP"));
		record.setBillSystemId(rs.getString("BILL_SYSTEM_ID"));
		record.setRao(rs.getString("RAO"));
		record.setChannelCode(rs.getString("CHANNEL_CODE"));
		record.setChannelSubCode(rs.getString("CHANNEL_SUB_CODE"));
		record.setDbSegmentId(rs.getString("DB_SEGMENT_ID"));
		record.setReportIdTs((rs.getTimestamp("REPORT_ID_TS")).toString()); //TIMESTAMP     
        return record;
    }
}
