package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.adjustments.Adjustment;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAdjListDetailRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetAdjListDetailRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetAdjListDetailRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List<Adjustment> adjustmentList = new ArrayList<Adjustment>();
		try {
			while (rs.next()) {
				Adjustment adjustment = new Adjustment();

				String childIp = rs.getString("CHILD_IP"); // Varchar(13)
				String adjLevel = rs.getString("ADJ_LEVEL"); // Varchar(1)
				String classificationCd = rs.getString("CLASSIFICATION_CD"); // Varchar(1)
				double amtAdjExist = rs.getDouble("AMT_ADJ_EXIST"); // Decimal(11,2)
				double amtAdjTot = rs.getDouble("AMT_ADJ_TOT"); // Decimal(11,2)
				double amount = rs.getDouble("AMOUNT"); // Decimal(11,2)
				String adjCreditDebit = rs.getString("ADJ_CREDIT_DEBIT"); // Varchar(2)
				String adjType = rs.getString("ADJUSTMENT_TYPE"); // Varchar(2)
				String circuit = rs.getString("CIRCUIT");// Char(42)
				String workingTelNumber = rs.getString("WORKING_TEL_NBR"); 
				String revId = rs.getString("REV_ID"); // Char(8)
				String geoCode = rs.getString("GEO_CODE"); // Char(16)
				String taxInd = rs.getString("TAX_IND"); // Varchar(1)
				String pof = rs.getString("POF"); // Varchar(8)
				String poeItemId = rs.getString("POE_ITEM_ID"); // Char(9)
				String rem = rs.getString("REM"); // Varchar(8)
				String balanceTypeCode = rs.getString("BAL_TYPE_CD"); // Varchar(8)
				String usoc = rs.getString("USOC"); 
				String description = rs.getString("DESCRIPTION"); // Char(80)
				String rao = rs.getString("RAO"); // Char(3)
				String channelCode = rs.getString("CHANNEL_CODE"); // Char(2)
				String channelSubCode = rs.getString("CHANNEL_SUB_CODE"); // Char(3)
				String entityCd = rs.getString("ENTITY_CD"); // Char(5)
				String chargeType = rs.getString("CHARGE_TYPE"); // Varchar(1)
				String interstateIndicator = rs.getString("INTERSTATE_IND"); // Varchar(1)
				String productJurisdictionCode = rs.getString("PROD_JURIS_CD"); // Varchar(2)
				String promotionId = rs.getString("PROMOTION_ID"); // Varchar(2)
				String vendorId = rs.getString("VENDOR_ID"); // Varchar(3)
				String emrCategory = rs.getString("EMR_CATEGORY"); 
				String emrGroup = rs.getString("EMR_GROUP"); 
				String emrRecType = rs.getString("EMR_REC_TYPE"); 
				String sensorId = rs.getString("SENSOR_ID"); // Varchar(6)
				String emrNaToPlace = rs.getString("EMR_NA_TO_PLACE"); 
				String emrNaToState = rs.getString("EMR_NA_TO_STATE"); 
				String emrRecDate = rs.getString("EMR_REC_DATE"); 
				String emrConnectTime = rs.getString("EMR_CONNECT_TIME"); 
				String emrToNbr = rs.getString("EMR_TO_NBR"); 
				String emrRatePeriod = rs.getString("EMR_RATE_PERIOD"); 
				String emrRateClass = rs.getString("EMR_RATE_CLASS"); 
				String emrSettleCode = rs.getString("EMR_SETTLE_CODE"); 
				String intlFromNbr15 = rs.getString("INTL_FROM_NBR_15"); 
				String intlToNbr15 = rs.getString("INTL_TO_NBR_15"); 
				String emrFromNbr = rs.getString("EMR_FROM_NBR"); 
				String emrTaxExemptInd = rs.getString("EMR_TAX_EXEMPT_IND"); 
				int emrBillableMin = rs.getInt("EMR_BILLABLE_MIN"); 
				int emrBillableSec = rs.getInt("EMR_BILLABLE_SEC"); 
				String vz450RecordNbr = rs.getString("VZ450_RECORD_NBR"); 
				String custIdDeptCd = rs.getString("CUST_ID_DEPT_CD"); 
				String fromDate = rs.getString("FROM_DATE"); 
				String thruDate = rs.getString("THRU_DATE"); 
				String taxGroupId = rs.getString("TAX_GROUP_ID"); 
				int vz450SequenceNumber = rs.getInt("VZ450_SEQ_NBR"); //currently not used
				String tableName = rs.getString("TBL_NAME"); 
				String irbBan = rs.getString("IRB_BAN"); 
				String taxState = rs.getString("TAX_STATE"); 
                String typeAdj = rs.getString("TYPE_ADJ");
                String grsInd = rs.getString("GRS_IND"); 
				
				if (CommonUtil.isNotNull(childIp)) {
					adjustment.setChild_ip(childIp.trim());
				}
				if (CommonUtil.isNotNull(adjLevel)) {
					adjustment.setAdjLevel(adjLevel.trim());
				}
				if (CommonUtil.isNotNull(classificationCd)) {
					adjustment.setClassificationCode(classificationCd.trim());
				}
				//
				//
				adjustment.setBilledAmount(amount);
				if (amtAdjExist >= 0) {
					adjustment.setAdjustmentAmount(amount);
				} else {
					adjustment.setAdjustmentAmount(amount + amtAdjExist);
				}
				adjustment.setAdjustmentAmount(amount + amtAdjExist);
				adjustment.setBCredit(true); //default to credit
				if (CommonUtil.isNotNull(adjCreditDebit)) {
					if (adjCreditDebit.trim().equalsIgnoreCase(adjustment.CREDIT)) {
						adjustment.setBCredit(true);
					} else if (adjCreditDebit.trim().equalsIgnoreCase(adjustment.DEBIT)){
						adjustment.setBCredit(false);
					} else {
						adjustment.setBCredit(true);
					}
				}
				if (CommonUtil.isNotNull(adjType)) {
					adjustment.setAdjustmentType(adjType.trim());
				}
				if (CommonUtil.isNotNull(circuit)) {
					adjustment.setCircuit(circuit.trim());
				}
				if (CommonUtil.isNotNull(workingTelNumber)) {
					adjustment.setWtn(workingTelNumber.trim());					 
				}
				if (CommonUtil.isNotNull(revId)) {
					adjustment.setRevenueAccountId(revId.trim());
				}
				if (CommonUtil.isNotNull(geoCode)) {
					adjustment.setGeoCode(geoCode.trim());
				}
				if (CommonUtil.isNotNull(taxInd)) {
					adjustment.setTaxInd(taxInd.trim());
				}
				if (CommonUtil.isNotNull(pof)) {
					adjustment.setPof(pof.trim());
				}
				if (CommonUtil.isNotNull(poeItemId)) {
					adjustment.setPoe(poeItemId.trim());
				}
				if (CommonUtil.isNotNull(rem)) {
					adjustment.setRem(rem.trim());
				}
				if (CommonUtil.isNotNull(balanceTypeCode)) {
					adjustment.setBalanceTypeCode(balanceTypeCode.trim());
				}
				if (CommonUtil.isNotNull(usoc)) {
					adjustment.setUsoc(usoc.trim());
				}
				if (CommonUtil.isNotNull(description)) {
					adjustment.setProductDesc(description.trim());
				}
				if (CommonUtil.isNotNull(rao)) {
					adjustment.setRao(rao.trim());
				}
				if (CommonUtil.isNotNull(channelCode)) {
					adjustment.setChannelCode(channelCode.trim());
				}
				if (CommonUtil.isNotNull(channelSubCode)) {
					adjustment.setChannelSubCode(channelSubCode.trim());
				}
				if (CommonUtil.isNotNull(entityCd)) {
					adjustment.setEntityCode(entityCd.trim());
				}
				if (CommonUtil.isNotNull(chargeType)) {
					adjustment.setChargeType(chargeType.trim());
				}
				if (CommonUtil.isNotNull(interstateIndicator) && interstateIndicator.trim().length() > 0) {
					int tmpInt = Integer.parseInt(interstateIndicator);
					adjustment.setTaxDeterminant(tmpInt);
				} else {
					adjustment.setTaxDeterminant(-1);
				}
				if (CommonUtil.isNotNull(productJurisdictionCode)) {
					adjustment.setProduct_Jurisdiction(productJurisdictionCode.trim());
				}
				if (CommonUtil.isNotNull(promotionId)) {
					adjustment.setPromotion_Id(promotionId.trim());
				}
				if (CommonUtil.isNotNull(vendorId)) {
					adjustment.setVendorId(vendorId.trim());
				}
				if (CommonUtil.isNotNull(emrCategory)) {
					adjustment.setUsageCategory(emrCategory.trim());
				}
				if (CommonUtil.isNotNull(emrGroup)) {
					adjustment.setGroup(emrGroup.trim());
				}
				if (CommonUtil.isNotNull(emrRecType)) {
					adjustment.setRecordType(emrRecType.trim());
				}
				if (CommonUtil.isNotNull(sensorId)) {
					adjustment.setSensor_Id(sensorId.trim());
				}
				if (CommonUtil.isNotNull(emrNaToPlace)) {
					adjustment.setTerm_City(emrNaToPlace.trim());
				}
				if (CommonUtil.isNotNull(emrNaToState)) {
					adjustment.setTerm_State(emrNaToState.trim());
				}
				if (CommonUtil.isNotNull(emrRecDate)) {
					adjustment.setCall_Date(emrRecDate.trim());
				}
				if (CommonUtil.isNotNull(emrConnectTime)) {
					adjustment.setStart_Time(emrConnectTime.trim());
				}
				if (CommonUtil.isNotNull(emrToNbr)) {
					if (emrToNbr.length() > 0) {
					  adjustment.setTo_NPA(emrToNbr.substring(0,3));
					  adjustment.setTo_NXX(emrToNbr.substring(3,6));
					  adjustment.setTo_Line_number(emrToNbr.substring(6,10));
					}
				}
				if (CommonUtil.isNotNull(emrRatePeriod)) {
					adjustment.setMsg_Rate_Period(emrRatePeriod.trim());
				}
				if (CommonUtil.isNotNull(emrRateClass)) {
					adjustment.setRate_Class(emrRateClass.trim());
				}
				if (CommonUtil.isNotNull(emrSettleCode)) {
					adjustment.setSettle_Code(emrSettleCode.trim());
				}
				if (CommonUtil.isNotNull(intlFromNbr15)) {
					adjustment.setIntl_From_Num(intlFromNbr15.trim());
				}
				if (CommonUtil.isNotNull(intlToNbr15)) {
					adjustment.setIntl_To_Num(intlToNbr15.trim());
				}
				if (CommonUtil.isNotNull(emrFromNbr)) {
					if (emrFromNbr.length() > 0) {
					  adjustment.setFrom_NPA(emrFromNbr.substring(0,3));
					  adjustment.setFrom_NXX(emrFromNbr.substring(3,6));
					  adjustment.setFrom_Line_Num(emrFromNbr.substring(6,10));
					}
				}
				if (CommonUtil.isNotNull(emrTaxExemptInd)) {
					adjustment.setEmrTaxExemptId(emrTaxExemptInd.trim());
				}
			  adjustment.setCallMinutes(emrBillableMin);
 			  adjustment.setCallSeconds(emrBillableSec);
				if (CommonUtil.isNotNull(vz450RecordNbr)) {
					adjustment.setVz450RecNbr(vz450RecordNbr.trim());
				}
				if (CommonUtil.isNotNull(custIdDeptCd)) {
					adjustment.setCustIdDeptCd(custIdDeptCd.trim());
				}
				if (CommonUtil.isNotNull(fromDate)) {
					adjustment.setFromDate(fromDate.trim());
				}
				if (CommonUtil.isNotNull(thruDate)) {
					adjustment.setThruDate(thruDate.trim());
				}
				if (CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(thruDate) &&
						fromDate.length() > 0 && thruDate.length() > 0) {
					//adjustment.setFractionalNumOfDays();
				} else {
					adjustment.setFractionalNumOfDays(-1);
				}
				if (CommonUtil.isNotNull(taxGroupId)) {
					adjustment.setTaxGroupId(taxGroupId.trim());
				}
				if (CommonUtil.isNotNull(tableName)) {
					adjustment.setVamRptName(tableName.trim());
				}
				if (CommonUtil.isNotNull(irbBan)) {
					adjustment.setIrb_ban(irbBan.trim());
				}
				//for taxes this is set here. else in the base sp.
				if (CommonUtil.isNotNull(taxState) && taxState.trim().length() > 0) {
					adjustment.setState(taxState);
				} else {
					adjustment.setState("");
				}
				if (CommonUtil.isNotNull(irbBan)) {
					adjustment.setType_adjust(typeAdj);
				} 

                if (!"Y".equals(grsInd)) {
                    grsInd = "N";
                } 
                adjustment.setGrsInd(grsInd);
                
				adjustmentList.add(adjustment);
			}
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n" + nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n" + nfe.getMessage());
			throw nfe;
		}
		return adjustmentList;
	}
}
