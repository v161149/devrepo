package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.reports.RptCntl;

public class GetRptCntlDetResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetRptCntlDetResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetRptCntlDetResultSetRowMapper::mapRow rowNum - " + rowNum);

		RptCntl rptCntlItem = new RptCntl();

		
		rptCntlItem.setRptId(rs.getInt("RPT_ID"));
		rptCntlItem.setStdReport(rs.getString("STANDARD_RPT"));
		rptCntlItem.setCustomRpt(rs.getString("CUSTOM_RPT"));
		rptCntlItem.setRptName(rs.getString("RPT_NAME"));
		rptCntlItem.setRptSubGroup(rs.getString("REPORT_SUB_GROUP"));
		rptCntlItem.setRptSection(rs.getString("RPT_SECTION"));
		rptCntlItem.setRptCategory(rs.getString("RPT_CATEGORY"));
		rptCntlItem.setPageId(rs.getInt("PAGE_ID"));
		String pageSubset = rs.getString("PAGE_SUBSET");
		String reportType = rs.getString("REPORT_TYPE");
		if (pageSubset==null)
			pageSubset = "";
		
		pageSubset = pageSubset.trim();
		if(pageSubset.isEmpty())
			pageSubset = "ALL";
		else pageSubset += "_ALL";
		
		
		rptCntlItem.setPageSubset(pageSubset);
		rptCntlItem.setInterPageId(rs.getInt("INTER_PAGE_ID"));

		rptCntlItem.setRptCatDescription(rs.getString("RPT_CATEGORY_DESCRIPTION"));
		rptCntlItem.setRptDescription(rs.getString("REPORT_DESCRIPTION"));	
		rptCntlItem.setEmailTemplateName(rs.getString("EMAIL_TEMPLATE_NAME"));
		rptCntlItem.setArchiveSystemId(rs.getString("ARCHIVE_SYSTEM_ID"));		
		rptCntlItem.setCreatedTimestamp(CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("CREATED_TIMESTAMP")));
		rptCntlItem.setLastUpdTimestamp(CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("LAST_UPD_TIMESTAMP")));
		rptCntlItem.setLastUpdatedBy(rs.getString("LAST_UPDATED_BY"));
		rptCntlItem.setReportType(reportType);

		return rptCntlItem;
	}
}


