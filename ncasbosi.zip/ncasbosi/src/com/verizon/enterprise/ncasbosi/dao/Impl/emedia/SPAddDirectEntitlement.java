package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.common.DirectEntitlement;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPAddDirectEntitlement extends BaseStoredProcedure {
	static private final Logger logger = Logger.getLogger(SPAddDirectEntitlement.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CUSTOMER_ACCT_NUM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIG_SYSTEM_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIPTION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIBER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_EO_MAP_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_PERM_MAP_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PERMISSION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ALL_CHILDREN_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PERSON_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LOGIN_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

	}

	public SPAddDirectEntitlement(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_ADD_DIR_ENTL, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel, Map inputMap) throws Exception
	{
		DirectEntitlement directEntitlement = (DirectEntitlement) inputMap.get("DIRECT_ENTITLEMENT");
		List paramValueList = new ArrayList();

		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(directEntitlement.getCustomerAccountNumber());//CUSTOMER_ACCT_NUM
		paramValueList.add(directEntitlement.getOriginatingSystemId());//ORIG_SYSTEM_ID

		//SUBSCRIPTION_OID
		String subscriptionOid = directEntitlement.getSubscriptionOid();

		//validate SUBSCRIPTION_OID value
		if (subscriptionOid != null && subscriptionOid.trim().length() == 0)
		{
			subscriptionOid = "0";
		}

		paramValueList.add(subscriptionOid);

		//SUBSCRIBER_OID
		String subscriberOid = directEntitlement.getSubscriberOid();

		//validate SUBSCRIBER_OID value
		if (subscriberOid != null && subscriberOid.trim().length() == 0)
		{
			subscriberOid = "0";
		}

		paramValueList.add(subscriberOid);

		//USER_OID
		String userOid = directEntitlement.getUserOid();

		//validate USER_OID value
		if (userOid != null && userOid.trim().length() == 0)
		{
			userOid = "0";
		}

		paramValueList.add(userOid);

		//USER_EO_MAP_OID
		String userEntitledObjectMapOid = directEntitlement.getUserEntitledObjectMapOid();

		//validate USER_EO_MAP_OID value
		if (userEntitledObjectMapOid != null && userEntitledObjectMapOid.trim().length() == 0)
		{
			userEntitledObjectMapOid = "0";
		}

		paramValueList.add(userEntitledObjectMapOid);

		//USER_PERM_MAP_OID
		String userPermissionMapOid = directEntitlement.getUserPermissionMapOid();

		//validate USER_PERM_MAP_OID value
		if (userPermissionMapOid != null && userPermissionMapOid.trim().length() == 0)
		{
			userPermissionMapOid = "0";
		}

		paramValueList.add(userPermissionMapOid);

		//PERMISSION_OID
		String permissionOid = directEntitlement.getPermissionOid();

		//validate PERMISSION_OID value
		if (permissionOid != null && permissionOid.trim().length() == 0)
		{
			permissionOid = "0";
		}

		paramValueList.add(permissionOid);

		//ALL_CHILDREN_FLAG
		paramValueList.add(directEntitlement.getAllChildrenFlag());

		//PERSON_OID
		String personOid = directEntitlement.getPersonOid();

		//validate PERSON_OID value
		if (personOid != null && personOid.trim().length() == 0)
		{
			personOid = "0";
		}

		paramValueList.add(personOid);

		paramValueList.add(directEntitlement.getLoginId());//LOGIN_ID

		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
