package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetRepClaimListRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetRepClaimListRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetRepClaimListRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List claimList = new ArrayList();
		try{
			while(rs.next()) {
				Map map = new HashMap();
				String esgClaimNumber = rs.getString("ESG_CLAIM_NUMBER");
				String claimDesc = rs.getString("CLM_DESCRIPTION");
				map.put("claimNumber", esgClaimNumber);
				map.put("claimDescription", claimDesc);
				claimList.add(map);
			}
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			throw nfe;
		}catch(Exception ex) {
			ex.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+ex.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+ex.getMessage());
		}
		return claimList;
	}
}
