package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.Clob;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.common.status.CustomListData;
import com.verizon.enterprise.common.status.SSAccountsRecord;



public class SPGetSummAcctList extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetSummAcctList.class);

	private static List spInOutList;

	private static GetSummAcctListRowMapperImpl rowMapper;

	static
	{
		rowMapper = new GetSummAcctListRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"BILL_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"MAN_LIST1", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN_LIST2", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN_LIST3", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN_LIST4", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN_LIST5", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TN_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_PHRASE ", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetSummAcctList(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SUMM_ACCT_LIST_V63, spInOutList);
	}


	public Map executeStoredProcedure(String userId, String debugLevel, 
			Date billDate,List multiList, String tnType,String filterBy,String sortOrder,
			String tokenSt, Pagination pagination)throws Exception
	{
		//List  multiList = new ArrayList();
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		StringBuffer myParams = new StringBuffer();

		myParams.append("SP Params [");

		paramValueList.add(userId);//APP_USER_ID
		myParams.append(userId + "^");
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		myParams.append(debugLevel + "^");	
		
		String dateString = ""	; 
		if (billDate !=  null)
		{
			SimpleDateFormat formatter
			= new SimpleDateFormat("yyyy-MM-dd");
			      
			dateString = formatter.format(billDate);
		}
		paramValueList.add(dateString);		// BILL_DATE	
		myParams.append(dateString + "^");
		
		//VAMHelper vmHelper = new VAMHelper();
	
        //multiList = vmHelper.getCombinedServiceIDMultiVarchar(acctList,osidList, false);
        
//		VAMHelper vmHelper = new VAMHelper();

        //multiList = getCombinedServiceIDMultiVarchar(acctList,osidList, false);

        int len = ((String) multiList.get(0)).length();
        if (len > 50)
        {
            len = 50;
        }
        paramValueList.add(multiList.get(0));//MAN_LIST1
        myParams.append(((String) multiList.get(0)).substring(0,
                len)
                + "...^");
        len = ((String) multiList.get(1)).length();
        if (len > 50)
        {
            len = 50;
        }
        paramValueList.add(multiList.get(1));//MAN_LIST2
        myParams.append(((String) multiList.get(1)).substring(0,
                len)
                + "...^");
        len = ((String) multiList.get(2)).length();
        if (len > 50)
        {
            len = 50;
        }
        paramValueList.add(multiList.get(2));//MAN_LIST3
        myParams.append(((String) multiList.get(2)).substring(0,
                len)
                + "...^");
        len = ((String)multiList.get(3)).length();
        if (len > 50)
        {
            len = 50;
        }
        paramValueList.add(multiList.get(3));//MAN_LIST4
        myParams.append(((String) multiList.get(3)).substring(0,
                len)
                + "...^");
        len = ((String) multiList.get(4)).length();
        if (len > 50)
        {
            len = 50;
        }
        paramValueList.add(multiList.get(3)); //MAN_LIST5
        myParams.append(((String) multiList.get(4)).substring(0,
                len)
                + "...^");


		paramValueList.add(tnType);	// TN_TYPE
		myParams.append(tnType + "^");

		paramValueList.add(filterBy);	// WHERE_PHRASE
		myParams.append(filterBy + "^");

		if(sortOrder == null || sortOrder.equals("")) {
			paramValueList.add("");//SORT_ORDER
		} else {
			paramValueList.add(sortOrder);//SORT_ORDER
		}
		myParams.append(sortOrder + "^");

		paramValueList.add(tokenSt);	// TOKEN_ST
		myParams.append(tokenSt);



		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}

		paramValueList.add(lineOffSet);//PAGE_OFFSET
		myParams.append(lineOffSet + "^");
		paramValueList.add(pageSize);//PAGE_SIZE
		myParams.append(pageSize + "^");

		_LOGGER.debug(myParams.toString());

		Map procMap = (HashMap)executeStoredProcedure(paramValueList);


		//pagination.updateCurrPageNum();
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		_LOGGER.debug("rowcountrStr" + rowcountrStr);

		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());

		Map acctMap = (HashMap)procMap.get("accounts");

		if( acctMap != null){

			List accountList = (List) acctMap.get("acctList");

			int listSize = accountList.size();
			for (int i=0;i<listSize;i++)
			{
				SSAccountsRecord ssAcctRecord = (SSAccountsRecord) accountList.get(i);
				logger.debug(ssAcctRecord.getAccountName());
				logger.debug(ssAcctRecord.getBan());
			}
		}


		//List actualList = (List)procMap.get("accounts");
		//pagination.setResultSize(Integer.toString(actualList.size()));

		resultMap.put("recordsMap", procMap);
		resultMap.put("pagination", pagination);


		return resultMap ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		_LOGGER.debug("Calling executeStoredProcedure");
		List paramValueList = (List) paramValues;
		_LOGGER.debug("After adding parameters ");
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
