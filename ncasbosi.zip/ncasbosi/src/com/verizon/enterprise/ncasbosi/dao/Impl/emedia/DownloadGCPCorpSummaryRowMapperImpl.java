package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;


public class DownloadGCPCorpSummaryRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadGCPCorpSummaryRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadGCPCorpSummaryRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> summaryList = new ArrayList<List<Cell>>();
		List<Cell> summary = new ArrayList<Cell>();

		try {
			
			while(rs.next()) {
				summary = new ArrayList<Cell>();

				String corpId = rs.getString("CORP_ID");
				String accountName = rs.getString("ACCT_NAME");				
				String billPeriod = rs.getString("BILL_PERIOD");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");
				String regionName = rs.getString("GBR_REGION_NAME");
				String billingFrequency = rs.getString("BILLING_FREQ");

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String backendSystem = rs.getString("BACKEND_SYSTEM");
				String channelCode = rs.getString("CHANNEL_CODE");
				String systemDesc = rs.getString("SYST_DESCRIPTION");
				String eligibilityInd = rs.getString("ELIGIBILITY_IND");
				String invoiceType = rs.getString("INVOICE_TYPE");
                String manBillDate = rs.getString("MAN_BILL_DATE");

				if(CommonUtil.isNotNull(corpId)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(corpId.trim())));
				}
				
				summary.add(new Cell());
				
				if(CommonUtil.isNotNull(accountName)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(accountName.trim())));
				}
				if(CommonUtil.isNotNull(gbrInvoiceType) || CommonUtil.isNotNull(regionName)) {
					summary.add(new Cell((regionName!=null?regionName.trim():"") + "/" + (gbrInvoiceType!=null?gbrInvoiceType.trim():"")));
				}

				if(CommonUtil.isNotNull(systemAbbrv)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(systemAbbrv.trim())));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(billPeriod.trim())));
				}
				if(CommonUtil.isNotNull(billingFrequency)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(billingFrequency.trim())));
				}

				if(CommonUtil.isNotNull(manBillDate)) {
					summary.add(new Cell(commonUtil.excelTextValueOf(manBillDate.trim())));
				}				

				summaryList.add(summary);

			
			}
		}catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("GCPCorpAccounts' summary  " + summary);
		}
		return summaryList;
	}

}
