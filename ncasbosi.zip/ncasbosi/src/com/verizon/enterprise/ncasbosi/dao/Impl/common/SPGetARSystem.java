package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * Author:v992473
 * This class gets the AR System for a given Originating system Id.
 */

public class SPGetARSystem extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPGetARSystem.class);
	private static List spInOutList;
	
	static{
		_LOGGER.info("Static init ");
		spInOutList = new ArrayList();
		spInOutList.add(new Object[]{"ORIGINATING_SYS_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
				
		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"A_R_SYSTEM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});		 
	}
	
	public SPGetARSystem(DataSource dataSource){
		super(dataSource,NCASBOSIConstants.SP_GET_AR_SYSTEM,spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		_LOGGER.info("printing the input Object::"+input);
		Map inputMap = (Map)input;
		List inputList = new ArrayList();
		inputList.add((String)inputMap.get("ORIGINATING_SYS_ID"));//ORIGINATING_SYS_ID
		Map resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		_LOGGER.info("Printing the response Map::"+resMap);
		return resMap;
	}
}
