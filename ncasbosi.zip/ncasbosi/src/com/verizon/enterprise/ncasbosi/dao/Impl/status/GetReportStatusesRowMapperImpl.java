package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.status.CurrentReports;
import com.verizon.enterprise.common.status.ReportsAddParam;
import com.verizon.enterprise.common.status.StatusSchedulingUtility;
import com.verizon.enterprise.common.status.TableCell;
import com.verizon.enterprise.common.status.TableHeaderCell;
import com.verizon.enterprise.common.status.TableRow;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetReportStatusesRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger
			.getLogger(GetReportStatusesRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetReportStatusesRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid = 0.0;
		double previousOid = 0.0;
		List refList = null;
		String key = "";
		ArrayList al = new ArrayList();
		
		
		al.add(new String[] { "REPORT_TITLE", "SUBSCRIBER_NAME",
				"ACCT_LIST_NAME", "BILL_DATE", "TRIGGER_TIMESTAMP",
				"STATUS", "STATUS_TIMESTAMP", "STATUS_MESSAGE" });
		try {

			
			 while(rs.next()) { //emediaRecord = new EMediaRecord();
			 /* //acctsListRecord
			 */
				 
			// Adding header row.
			/*
			 * al.add(new
			 * String[]{"LINE_NUM","REPORT_TITLE","SELECTION_TYPE","BILL_TYPE_FILTER","ACCT_LIST_TYPE",
			 * "ACCT_LIST_NAME","SUBSCRIBER_NAME","ORIG_SYSTEM_ID","CORP_ID","BAN_DAN",
			 * "SCHEDULED_IND","BILL_DATE","THRU_DATE","TRIGGER_TIMESTAMP","STATUS",
			 * "STATUS_TIMESTAMP","RETRY_COUNT","STATUS_MESSAGE"});
			 */

			ReportsAddParam currRptAddParam = new ReportsAddParam();

			String reportTitle = rs.getString("REPORT_TITLE");
			String subName = rs.getString("SUBSCRIBER_NAME");
			String selType = rs.getString("SELECTION_TYPE");
			String listName = null;
			String acctListName = rs.getString("ACCT_LIST_NAME");
			String acctListType = rs.getString("ACCT_LIST_TYPE");
			
			if(selType!=null){
				selType = selType.trim();
			}
			if(acctListName!=null){
				acctListName = acctListName.trim();
			}
			if(acctListType!=null){
				acctListType = acctListType.trim();
			}
			
			if ("A".equalsIgnoreCase(selType)) {
				listName = "All";
			} else if ("B".equalsIgnoreCase(selType)) {
				listName = "Invoice Type " + rs.getString("BILL_TYPE_FILTER");
			} else if ("L".equalsIgnoreCase(selType)) {
				if ("ANON".equalsIgnoreCase(acctListType))
				{
					currRptAddParam.setAnonListName(rs.getString("ACCT_LIST_NAME"));
					listName = "Account Selection List";			
				}
				else 
					listName = acctListName;
			}
			String billDate = rs.getString("BILL_DATE");
			String runDate = CommonUtil.getDisplayDateFromString(rs
					.getDate("TRIGGER_TIMESTAMP"));
			String status = rs.getString("STATUS");
			if("S".equalsIgnoreCase(status)) {
				status = "Scheduled";			
			}
			else if("A".equalsIgnoreCase(status)) {
				status = "Actively Running";			
			}
			else if("C".equalsIgnoreCase(status)) {
				status = "Completed";			
			}
			else if("R".equalsIgnoreCase(status))	{
				status = "Re-scheduled ";			
			}
			else if("E".equalsIgnoreCase(status))	{
				status = "Errored";			
			}

			
			String compDate = CommonUtil.getDisplayDateFromString(rs
					.getDate("STATUS_TIMESTAMP"));
			String statusMsg = rs.getString("STATUS_MESSAGE");
			
			
			currRptAddParam.setSelectionType(selType);
			currRptAddParam.setAcctListType(acctListType);
			currRptAddParam.setAcctListName(listName);
			currRptAddParam.setBillTypeFilter(rs.getString("BILL_TYPE_FILTER"));
			currRptAddParam.setSubscriberName(rs.getString("SUBSCRIBER_NAME"));
			currRptAddParam.setOsid(rs.getString("ORIG_SYSTEM_ID"));
			currRptAddParam.setCorpId(rs.getString("CORP_ID"));
			currRptAddParam.setBanDan(rs.getString("BAN_DAN"));
			currRptAddParam.setTnType(rs.getString("TN_TYPE"));
			currRptAddParam.setSchedledInd(rs.getString("SCHEDULED_IND"));
			currRptAddParam.setThruDate(rs.getString("THRU_DATE"));
			currRptAddParam.setRetryCout(rs.getString("RETRY_COUNT"));
			
			if(selType != null && selType.trim().equalsIgnoreCase("S")){
				currRptAddParam.setAcctListName(currRptAddParam.getBanDan());
			}
			

			al.add(new Object[] { reportTitle, subName, currRptAddParam, billDate,
					runDate, status, compDate, statusMsg });
			
			 }
			 
			 _LOGGER.info("al size = "  + al.size());
			 _LOGGER.info("al DATA = "  + al.toString());

			CurrentReports object = populateCurrentReportsDataModel(al);
			
		     printCurrentReportsDataModel(object);
		     //_LOGGER.info("currRptAddParam = "  + currRptAddParam.toString());
		     returnMap.put("currReport", object);
		     
			
		     //return object;

			/*
			 * int lineNum = rs.getInt("LINE_NUM"); String reportTitle =
			 * rs.getString("REPORT_TITLE"); String selectionType =
			 * rs.getString("SELECTION_TYPE"); billTypeFilter =
			 * rs.getString("BILL_TYPE_FILTER"); String acctListType =
			 * rs.getString("ACCT_LIST_TYPE"); String acctListName =
			 * rs.getString("ACCT_LIST_NAME"); String custName =
			 * rs.getString("SUBSCRIBER_NAME"); String corpId =
			 * rs.getString("CORP_ID "); String banDan =
			 * rs.getString("BAN_DAN");
			 * 
			 * 
			 * String scheduledInd = rs.getString("SCHEDULED_IND"); String
			 * billDate = rs.getString("BILL_DATE"); String thruDate =
			 * rs.getString("THRU_DATE");
			 * 
			 * String triggTimeStamp = rsgetString("TRIGGER_TIMESTAMP"); String
			 * status = rs.getString("STATUS"); String statusTimeStamp =
			 * rs.getString("STATUS_TIMESTAMP"); String retryCount =
			 * rs.getString("RETRY_COUNT"); String statusMessage =
			 * rs.getString("STATUS_MESSAGE"); // we will use the same record
			 * what Lou is going to create to populate Account List. // Need to
			 * modify this code to build the account list. // talk with Lou if
			 * his object is ready.... /* if(CommonUtil.isNotNull(lineNum))
			 * {emediaRecord.setEnterprise(enterpriseId.trim());}
			 * 
			 * 
			 * if(CommonUtil.isNotNull( ban)) {emediaRecord.setBan(ban.trim());}
			 * if(CommonUtil.isNotNull( man)) {emediaRecord.setMan(man.trim());}
			 * 
			 * if(banDan==null ||(banDan!=null && banDan.trim().equals(""))){
			 * banDan = manDan; manDan = ""; }
			 * 
			 * if(CommonUtil.isNotNull( origSysId))
			 * {emediaRecord.setOrigSysId(origSysId.trim());}
			 * 
			 * if(CommonUtil.isNotNull( banDan))
			 * {emediaRecord.setBan_dan(CommonUtil.getFormattedAccount(banDan.trim(),emediaRecord.getOrigSysId()));}
			 * if(CommonUtil.isNotNull( manDan))
			 * {emediaRecord.setMan_dan(CommonUtil.getFormattedAccount(manDan.trim(),emediaRecord.getOrigSysId()));}
			 * 
			 * 
			 * 
			 * 
			 * if(CommonUtil.isNotNull( accountName))
			 * {emediaRecord.setAccountName(accountName.trim());}
			 * if(CommonUtil.isNotNull( billPeriod))
			 * {emediaRecord.setBillPeriod(billPeriod.trim());}
			 * if(CommonUtil.isNotNull( edi05))
			 * {emediaRecord.setEdi05(edi05.trim());} if(CommonUtil.isNotNull(
			 * edi06)) {emediaRecord.setEdi06(edi06.trim());}
			 * if(CommonUtil.isNotNull( edi02))
			 * {emediaRecord.setEdi02(edi02.trim());} if(CommonUtil.isNotNull(
			 * channelCode)) {emediaRecord.setChannelCode(channelCode.trim());}
			 * if(CommonUtil.isNotNull( ediDeliveryOption))
			 * {emediaRecord.setEdiDeliveryOption(ediDeliveryOption.trim());}
			 * if(CommonUtil.isNotNull( ediDataGroup))
			 * {emediaRecord.setEdiDataGroup(ediDataGroup.trim());}
			 * if(CommonUtil.isNotNull( vz450DeliveryOption))
			 * {emediaRecord.setVz450DeliveryOption(vz450DeliveryOption.trim());}
			 * if(CommonUtil.isNotNull( systemAbbrv))
			 * {emediaRecord.setSystemAbbrv(systemAbbrv.trim());}
			 * if(CommonUtil.isNotNull( startBillPeriod))
			 * {emediaRecord.setStartBillPeriod(startBillPeriod.trim());}
			 * if(CommonUtil.isNotNull( endBillPeriod))
			 * {emediaRecord.setEndBillPeriod(endBillPeriod.trim());}
			 * 
			 * key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
			 * emediaRecord.setAcctSubscriptionOid(key);
			 * 
			 * 
			 * if(previousOid!=acctSubscriptionOid){ refList = new ArrayList();
			 * returnMap.put(key,refList); } refList.add(emediaRecord);
			 * previousOid = acctSubscriptionOid; }
			 */

		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			throw nfe;
		}
		return returnMap;
	}

	private static void printCurrentReportsDataModel(CurrentReports currRep) {
		if (currRep != null) {
			//System.out.println(currRep.toString());
		} else {
			//System.out.println("current report data Model not created");
		}
	}

	public static CurrentReports populateCurrentReportsDataModel(ArrayList al) {
		
		String METHOD_NAME = " populateCurrentReportsDataModel";
		_LOGGER.debug(METHOD_NAME + "Exception occured while parsing the resultset \n");
		
		CurrentReports currentReports = new CurrentReports();
		/*
		 * String[] total = (String[]) al.get(0);
		 * currentReports.setPageOffset(Integer.parseInt(total[0]));
		 * currentReports.setPageSize(Integer.parseInt(total[1]));
		 * currentReports.setTotalRows(Integer.parseInt(total[2]));
		 */
		currentReports.setRecordsReturned(al.size() - 1);
		
		_LOGGER.debug(METHOD_NAME + "records returned = " + currentReports.getRecordsReturned());
		

		// Setting Header row
		ArrayList objectHeader = new ArrayList();
		String[] dbName = (String[]) al.get(0);
		for (int k = 0; k < dbName.length; k++) {
			TableHeaderCell header = new TableHeaderCell();
			header.setDbName((String)dbName[k]);
			header.setRightJustify(StatusSchedulingUtility
					.getRightJustificationInfo("CurrentReport", dbName[k]));
			header.setUiName(StatusSchedulingUtility.getUIName("CurrentReport",
					dbName[k]));
			header.setSortInfo(StatusSchedulingUtility.getSortInfo(
					"CurrentReport", dbName[k]));
			header.setFilterInfo(StatusSchedulingUtility.getFilterInfo(
					"CurrentReport", dbName[k]));
			objectHeader.add(header);
		}
		currentReports.setTableHeaderRow((TableHeaderCell[]) objectHeader
				.toArray(new TableHeaderCell[0]));

		// setting data row.
		ArrayList object = new ArrayList();
		for (int i = 1; i < al.size(); i++) {
			TableRow tableRow = new TableRow();
			Object[] cellValues = (Object[]) al.get(i);
			ArrayList cellArrayList = new ArrayList();
			for (int z = 0; z < cellValues.length; z++) {
				TableCell tableCell = new TableCell();
				if(cellValues[z] != null)
					tableCell.setCellValue(cellValues[z]);
				else if(cellValues[z] == null)
					tableCell.setCellValue("");

				//tableCell.setCellValue(cellValues[z]);
				
				tableCell.setDataType(StatusSchedulingUtility.getDataType(
						"CurrentReport", dbName[z]));
				tableCell.setRightJustify(StatusSchedulingUtility
						.getRightJustificationInfo("CurrentReport", dbName[z]));
				tableCell.setWrapInfo(StatusSchedulingUtility.getColWrapInfo(
						"CurrentReport", dbName[z]));
				cellArrayList.add(tableCell);
			}
			tableRow.setTableCell((TableCell[]) cellArrayList
					.toArray(new TableCell[0]));
			object.add(tableRow);
		}
		currentReports.setTableRows((TableRow[]) object
				.toArray(new TableRow[0]));
		return currentReports;
	}

}