package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowCallbackHandler;

public class RowCallbackHandlerImpl implements RowCallbackHandler {
	
	static private final Logger _LOGGER = Logger.getLogger(RowCallbackHandlerImpl.class);
	
	public void processRow(ResultSet rs) throws SQLException {
		_LOGGER.info("CONFIG_SUBS_OID --> " + rs.getBigDecimal("CONFIG_SUBS_OID"));
		_LOGGER.info("CONFIG_ID" + rs.getString("CONFIG_ID"));
		_LOGGER.info("CUSTOMER_ID" + rs.getString("CUSTOMER_ID"));
		_LOGGER.info("COMPANY_NAME" + rs.getString("COMPANY_NAME") + "\n\n");
	}
}
