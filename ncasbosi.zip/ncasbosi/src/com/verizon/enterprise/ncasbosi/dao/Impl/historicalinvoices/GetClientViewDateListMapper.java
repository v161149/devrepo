package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetClientViewDateListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetClientViewDateListMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.debug("GetClientViewDateListMapper - Mapping Row# "+rowNum);
		HiSelectDO hiDO = null;
		if(rs!=null){
			hiDO = new HiSelectDO();
			hiDO.setDocType(val(rs.getString("DOCUMENT_TYPE")));			String yearDashMonth = rs.getString("YEAR_MONTH");			hiDO.setBillDate(yearDashMonth + "-01");  //set billdate to first of month, this field is used when building the list of months to the getDetails api			String yearMonth = CommonUtil.formatDate(yearDashMonth, "yyyy-MM", "yyyy MMM");			hiDO.setYearMonth(yearMonth);					}				_LOGGER.debug("GetClientViewDateListMapper" + hiDO);
		return hiDO;
	}		private String val(String input)	{		if (input == null)			return "";				return input.trim();	}
}
