package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.reports.*;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.dao.Interface.reports.*;
import com.verizon.enterprise.common.ncas.EmailUtil;
import com.verizon.enterprise.common.ncas.payments.EmailTemplateInfo;
import com.verizon.enterprise.ncasbosi.common.PaymentsTemplateConfig;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.common.ncas.common.JMSUtility;

public  class ReportsBatchImpl extends ReportsDAOImpl implements NCASBOSIConstants,ReportsBatchInterface {

	private static final Logger _LOGGER = Logger.getLogger(ReportsBatchImpl.class);

	public void processScheduledReports(Object requestMap) throws NCASException
	{
		final String METHOD_NAME = "processScheduledReports()";
		_LOGGER.info(METHOD_NAME+" Entering");
        
		try {
			//1.pick from PL_RPT_RECUR_T & add entry to PL_RPT_REQUEST_T.
			List<RptRecur> rptRecurList = getBatchReportRecurDetails();

			List<RptRequest> rptRequestList = new ArrayList<RptRequest>();
			for(int i=0;i<rptRecurList.size();i++)
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				RptRecur rptRecurItem = rptRecurList.get(i);
				RptRequest rptRequestItem = new RptRequest();
				rptRequestItem.setRptId(rptRecurItem.getRptId());
				rptRequestItem.setPortalLoginId(rptRecurItem.getPortalLoginId());
				if (rptRecurItem.getRecurDay()==-1) {
					rptRequestItem.setRptType(NcasConstants.REPORTS_TYPE_ONETIME);
				} else {
					rptRequestItem.setRptType(NcasConstants.REPORTS_TYPE_RECURRING);
				}
				rptRequestItem.setRptRecurId(rptRecurItem.getRptRecurId());
				rptRequestItem.setStructType(rptRecurItem.getStructType());
				rptRequestItem.setStructOid(rptRecurItem.getStructOid());
				rptRequestItem.setPositionType(rptRecurItem.getPositionType());
				rptRequestItem.setPositionOid(rptRecurItem.getPositionOid());
				rptRequestItem.setRequestStatus(NcasConstants.RECUR_REPORTS_SCHEDULED_STATUS);
				rptRequestItem.setEmailAddr(rptRecurItem.getEmailAddr());
				rptRequestItem.setPageSubset(rptRecurItem.getPageSubset());
				rptRequestItem.setRqstLinkParam(rptRecurItem.getRqstLinkParam());
				rptRequestItem.setRqstSortParam(rptRecurItem.getRqstSortParam());
				rptRequestItem.setRqstFilterParam(rptRecurItem.getRqstFilterParam());
				rptRequestItem.setUserOid(rptRecurItem.getUserOid());
				rptRequestItem.setCreatedTimestamp(lastUpdated.trim());
				rptRequestItem.setRptRequestTs(lastUpdated.trim());
				rptRequestItem.setLastUpdTimestamp(lastUpdated.trim());
				rptRequestItem.setPageId(rptRecurItem.getPageId());
				// Got to set the process name here for lastUpdatedBy i guess...
				rptRequestItem.setLastUpdatedBy(NcasConstants.BATCH_RPT_RECUR);
				rptRequestList.add(rptRequestItem);
			}
			if (rptRequestList.size()>0)
			{
				insertReportReqDetails(rptRequestList);
				//To update the next_schedule_date of the recur items processed
				updateNextSchDateForRptRecur(rptRecurList);
			}
		}
		catch(NCASException ex)
		{
			_LOGGER.error(METHOD_NAME + " in ReportsBatchImpl Failed \n" + ex.getMessage());
			sendRptIssuesByEmail(stack2string(ex),METHOD_NAME);
			throw ex;
		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME + " in ReportsBatchImpl Failed \n" +e.getMessage());
			sendRptIssuesByEmail(stack2string(e),METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, ReportsBatchImpl.class, e);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public void doRptEmailBatch(Object requestMap) throws NCASException
	{
		final String METHOD_NAME = "doRptEmailBatch()";
		_LOGGER.info(METHOD_NAME+" Entering");
		String errMsg = "";
		
		try
		{
			EmailUtil emailUtil = new EmailUtil();
			EmailTemplateInfo templateInfo = null;
			List<RptEmail> emailList = getEligibleEmailItemList();
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			String  template = "";
			for (int i=0;i<emailList.size();i++)
			{
				RptEmail item = emailList.get(i);				
				
				try{
    	                if (item.getTemplateName().equals("REPORT_NOTIFICATION_VBE"))
    	                {
    	                    // get vbe aft info and place in item
    	                    List<VbeAftInfo> vbeAftList = getVbeAftList(item);
    	                    VbeAftInfo vbeAftInfo = (VbeAftInfo) vbeAftList.get(0);
    	                    item.setName(vbeAftInfo.getRequestNo());
    	                    item.setSection(vbeAftInfo.getRequestType());
                            String comments = vbeAftInfo.getComments(); 
                            if (comments.length() > 50)
                                comments = comments.substring(0, 50);
                            item.setCategory(comments);            
    	                }

						templateInfo = emailTemplateInfoMap.get(item.getTemplateName());
						if (templateInfo == null) {
							errMsg = "The report notification was cancelled because of missing email template info for the template name = "+item.getTemplateName()+"::";
							_LOGGER.warn(errMsg);
						} 
						template = templateInfo.getTemplateDesc();
						emailUtil.setMessage(getContent(item, template));							
						emailUtil.setSubject(templateInfo.getSubject());					
						List<String> emailAddrList = validateEmailAddressList(item.getEmailAddr(),emailUtil);
						if (emailAddrList!=null&&emailAddrList.size()>0) {
							long emailTrackOid = emailUtil.sendMail(emailAddrList);
							updateEmailProcDetails(item.getRptExecMailId(), emailTrackOid);							
						} else {
							_LOGGER.warn("The report notification was cancelled because of missing email address in RptEmail record:\n "+item.toString());
						}							
				}
				catch(Exception e){
					_LOGGER.error(METHOD_NAME + " in ReportsBatchImpl Failed \n", e);
					sendRptIssuesByEmail(errMsg+item.toString()+"\r\n"+stack2string(e),METHOD_NAME);
				}
			}
			
		}
		catch(NCASException ex)
		{
			_LOGGER.error(METHOD_NAME + " in ReportsBatchImpl Failed \n" + ex.getMessage());
			sendRptIssuesByEmail(stack2string(ex),METHOD_NAME);
			throw ex;
		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME + " in ReportsBatchImpl Failed \n" +e.getMessage());
			sendRptIssuesByEmail(stack2string(e),METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, ReportsBatchImpl.class, e);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}
	protected String getContent(RptEmail email, String template) throws Exception
	{
			template = getContent("{USER_ID}", email.getLoginId(), template);
			template = getContent("{REQUEST_TS}", email.getCreatedTimestamp(), template);
			template = getContent("{RPT_NAME}", email.getName(), template);
			template = getContent("{FUNC}", email.getSection(), template);
			template = getContent("{CATEGORY}", email.getCategory(), template);
			//template = getContent("{DESCRIPTION}", email.getDesc(), template);
			return template;
	}

	protected String getContent(String searchString, String replaceString, String template)
	{
		int startPos = template.indexOf(searchString);
		StringBuffer sb = new StringBuffer(template);
		
		if (startPos != -1)
			sb.replace(startPos, startPos + searchString.length(), replaceString);
		
		return sb.toString();
	}
	
	protected void sendRptIssuesByEmail(String errMsg,String method){
		final String METHOD_NAME = "sendRptIssuesByEmail()";
		_LOGGER.info(METHOD_NAME+" Entering");
        String emailSubject = "Exception or Error in Reports Batch Processing";
        
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String errDateTime = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));			
			StringBuffer contentBuf = new StringBuffer();			
			contentBuf.append("This email is to notify you that ")
			          .append(method)
			          .append(" has failed at ")
			          .append(errDateTime)
			          .append(". Below is the exception message::\r\n")
			          .append(errMsg);
			
			Map<String,Object> emailMap = new HashMap<String,Object>();
			List<String> toAddrList = null;
			List<String> ccAddrList = null;
			toAddrList = JMSUtility.getSplittedMailList(SystemParamConfig.getProperty(REPORTS_EMAIL_ADDRESS));
			_LOGGER.debug("email list -> "+toAddrList.toString());
			emailMap.put(NcasConstants.EMAIL_TO_ADDR, toAddrList);
			emailMap.put(NcasConstants.EMAIL_CC_ADDR, ccAddrList);
			String env = SystemParamConfig.getProperty(NcasConstants.PORTAL_ENV);
			if(env!=null && env.trim().equalsIgnoreCase("")){
				emailSubject = env+" - "+emailSubject;
				_LOGGER.info("Report batch is running in "+env);
			} 			
			emailMap.put(NcasConstants.EMAIL_SUBJECT, emailSubject);
			emailMap.put(NcasConstants.EMAIL_MESSAGE, contentBuf.toString());
			commonUtil.sendEmail(emailMap);	
			} catch(Exception ex){
				_LOGGER.error(METHOD_NAME + "\n" + ex.getMessage());
			}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}
	
	private List<String> validateEmailAddressList(List<String> emailAddrList, EmailUtil emailUtil) throws Exception {
		if (emailAddrList==null) return null;
		List<String> verifiedEmailAddrList = new ArrayList<String>();
		String emailAddr = null;
		Iterator<String> iterator = emailAddrList.iterator();
		while (iterator.hasNext()) {
			emailAddr = iterator.next();
			if (emailUtil.validateEmailAddress(emailAddr)) {
				verifiedEmailAddrList.add(emailAddr.trim());
			}
		}
		if (verifiedEmailAddrList.size()==0) {
			verifiedEmailAddrList = null;
		}
		return verifiedEmailAddrList;
	}	
}





