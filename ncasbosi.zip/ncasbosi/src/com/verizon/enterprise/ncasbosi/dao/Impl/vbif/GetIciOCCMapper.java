package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.vbif.IciOcc;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

/*
 * Author:PVB
 * Class to map GET_ICI_OCC SP result set to our domain object 
 * Part of development for June/2012.
 */

public class GetIciOCCMapper implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetIciOCCMapper.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetIciOCCMapper::extractData() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";

		List<IciOcc> returnList = new ArrayList<IciOcc>();

		try
		{
			while(rs.next())
			{
				IciOcc myOCC = new IciOcc();

				//save result set values for the row into object iciocc
                myOCC.setOriginatingSysId(rs.getString("VZ450_SYS_ID"));
                myOCC.setMan(rs.getString("MAN"));
                myOCC.setBan(rs.getString("BAN"));                
                myOCC.setEntityCode(rs.getString("ENTITY_CODE"));
                myOCC.setEntityName(rs.getString("ENTITY_NM"));
                myOCC.setRao(rs.getString("RAO"));
                myOCC.setBillDate(CommonUtil.formatDate(rs.getString("BILL_DATE"), formatDb2, formatDisplayed));
                myOCC.setState(rs.getString("STATE"));
                myOCC.setOccType(rs.getString("OCC_TYPE"));
                myOCC.setOccTypeDesc(rs.getString("OCC_TYPE_DESC"));
                myOCC.setConfigId(rs.getString("CONFIG_ID"));
                myOCC.setOccAmount(CommonUtil.formatDouble(rs.getDouble("PORT_OCC_AMOUNT")));
                myOCC.setOccCreditDebit(rs.getString("OCC_CREDIT_DEBIT"));
                myOCC.setFromDate(CommonUtil.formatDate(rs.getString("FROM_DATE"), formatDb2, formatDisplayed));
                myOCC.setThruDate(CommonUtil.formatDate(rs.getString("THRU_DATE"), formatDb2, formatDisplayed));
                myOCC.setPof(rs.getString("POF"));
                myOCC.setPoe(rs.getString("POE"));
                myOCC.setRem(rs.getString("REM"));
                myOCC.setUsoc(rs.getString("USOC"));
                myOCC.setProdGrpChar(rs.getString("PROD_GRP_CHAR"));
                myOCC.setProdGrpDes(rs.getString("PROD_GRP_DES"));
                myOCC.setProdSubGrpChar(rs.getString("PROD_SUBGRP_CHAR"));
                myOCC.setProdSubGrpDes(rs.getString("PROD_SUBGRP_DES"));
                myOCC.setPhraseCode(rs.getString("PHRASE_CODE"));
                myOCC.setAdjReasonText(rs.getString("ADJ_REASON_TEXT"));
                myOCC.setTextLine1(rs.getString("TEXT_LINE1"));
				myOCC.setDisableTax(rs.getString("DISABLE_TAX"));
                myOCC.setUsageType(rs.getString("USAGE_TYPE"));
                myOCC.setUsageTypeDesc(rs.getString("USAGE_TYPE_DESC"));
				myOCC.setFrn(rs.getString("FRN"));
				myOCC.setErateDiscPct(rs.getString("ERATE_DISC_PCT"));
				myOCC.setErateTotElgChgs(CommonUtil.formatDouble(rs.getDouble("ERATE_TOT_ELG_CHGS")));				
				myOCC.setErateAppNumber(rs.getString("ERATE_APP_NUMBER"));
                myOCC.setErateFundingYear(rs.getString("ERATE_FUNDING_YEAR"));
                myOCC.setEcpBackendSys(rs.getString("ECP_BACKEND_SYS"));
                myOCC.setOccStatus(rs.getInt("OCC_STATUS"));
                myOCC.setOccStatusDesc(rs.getString("OCC_STATUS_DESC"));
                myOCC.setBiStatus(rs.getInt("BI_STATUS"));
                myOCC.setBiSubStatus(rs.getInt("BI_SUB_STATUS"));
                myOCC.setOwner(rs.getString("OWNER"));								
				
				//add the occ to the list
				returnList.add(myOCC);
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			throw nfe;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + ex.getMessage());
		}

		return returnList;
	}
	
	
}

