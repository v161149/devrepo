package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.status.CurrentReports;
import com.verizon.enterprise.common.status.ScheduledReports;
import com.verizon.enterprise.common.vzbreports.ScheduleReportData;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;

public class SPGetUserRptScheduled extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger
			.getLogger(SPGetUserRptScheduled.class);

	private static List spInOutList;

	private static GetUserRptScheduledRowMapperImpl rowMapper;

	static {
		rowMapper = new GetUserRptScheduledRowMapperImpl();
		spInOutList = new ArrayList();
		spInOutList.add(new Object[] { "rptscheduled",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, rowMapper });
		spInOutList.add(new Object[] { "APP_USER_ID",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "DEBUG_LEVEL",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });

		spInOutList.add(new Object[] { "RETURN_CODE",getSqlDataType(Types.INTEGER),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "REASON_CODE",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "ERROR_TEXT",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLCODE",getSqlDataType(Types.INTEGER),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLTOKENS",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLSTATE",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });

		spInOutList.add(new Object[] { "USER_OID",getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });

		spInOutList.add(new Object[] { "WHERE_PHRASE",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "SORT_ORDER",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "TOKEN_ST",	getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT });

		spInOutList.add(new Object[] { "PAGE_OFFSET",getSqlDataType(Types.INTEGER),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "PAGE_SIZE",	getSqlDataType(Types.SMALLINT),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });

		spInOutList.add(new Object[] { "TOTAL_ROWS",	getSqlDataType(Types.INTEGER),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
	}

	public SPGetUserRptScheduled(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "."
				+ NCASBOSIConstants.SP_GET_USER_RPT_SCHED, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel,
			String userOid, String filterBy, String sortBy, String tokenSt,
			String cursor, Pagination pagination) throws Exception {
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		paramValueList.add(userId);// APP_USER_ID
		paramValueList.add(debugLevel);// DEBUG_LEVEL
		paramValueList.add(userOid); // USER_OID
		paramValueList.add(filterBy);// WHERE_FILTER
		if (sortBy == null || sortBy.equals("")) {
			paramValueList.add("");// SORT_ORDER
		} else {
			paramValueList.add(sortBy);// SORT_ORDER
		}

		paramValueList.add(tokenSt);// TOKEN_ST
		String lineOffSet = pagination.getPageOffset();
		String pageSize = pagination.getPageSize();
		if (lineOffSet == null) {
			lineOffSet = "1";
		}
		if (pageSize == null) {
			pageSize = "50";
		}

		paramValueList.add(lineOffSet);// LINE_OFFSET
		paramValueList.add(pageSize);// PAGE_SIZE

		Map procMap = (HashMap) executeStoredProcedure(paramValueList);
		// pagination.updateCurrPageNum();
		
		_LOGGER.debug("after calling stored proc");

		Integer rowcountrStr = (Integer) procMap.get("TOTAL_ROWS");
		String tokenStr = (String) procMap.get("TOKEN_ST");

		//_LOGGER.debug("after getting  TOTAL_ROWS");
		// Need to revisit this logic.
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());

		Map actualList = (Map) procMap.get("rptscheduled");

		ScheduledReports object = (ScheduledReports)actualList.get("schedReport");
		
		//System.out.println(object.toString());
		
		//pagination.setResultSize(Integer.toString(actualList.size()));

		object.setPageOffset(Integer.parseInt(lineOffSet));
		object.setPageSize(Integer.parseInt(pageSize));
		object.setTotalRows(rowcountrStr.intValue());
		//_LOGGER.debug("after setting pagination values");
		resultMap.put("recordsMap", (ScheduledReports) object);
		resultMap.put("procMap", procMap);
		//resultMap.put("tokenSt", tokenSt);

		return resultMap;
	}

	public Map executeStoredProcedure(Object paramValues) throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
