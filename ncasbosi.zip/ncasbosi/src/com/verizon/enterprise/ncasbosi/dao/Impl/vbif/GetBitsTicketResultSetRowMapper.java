package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.BitsTicketInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetBitsTicketResultSetRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetBitsTicketResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetBitsTicketResultSetRowMapper::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		BitsTicketInfo bitsTicketInfo = new BitsTicketInfo();
		
		String currentOwnerOrg = rs.getString("CURRENT_OWNER_ORG");
		String clmCurrOwnVzid = rs.getString("CLM_CURR_OWN_VZID");
		String finopsContract = rs.getString("FINOPS_CONTRACT");
		String clmStatusDesc = rs.getString("CLM_STATUS_DESCR");
		String clmSubStatusDesc = rs.getString("CLM_SUBSTATUS_DESC");
		String resolution = rs.getString("RESOLUTION");
		String bitsProduct = rs.getString("BITS_PRODUCT");
		String rootCause =  rs.getString("ROOT_CAUSE");
		String bitsUrlLink =  rs.getString("BITS_URL_LINK");
		
		if (CommonUtil.isNotNull(currentOwnerOrg)) {
			bitsTicketInfo.setCurrentOwnerOrg(currentOwnerOrg.trim());
		}
		if (CommonUtil.isNotNull(clmCurrOwnVzid)) {
			bitsTicketInfo.setClmCurrOwnVzid(clmCurrOwnVzid.trim());
		}
		if (CommonUtil.isNotNull(finopsContract)) {
			bitsTicketInfo.setFinopsContract(finopsContract.trim());
		}
		if (CommonUtil.isNotNull(clmStatusDesc)) {
			bitsTicketInfo.setClmStatusDesc(clmStatusDesc.trim());
		}
		if (CommonUtil.isNotNull(clmSubStatusDesc)) {
			bitsTicketInfo.setClmSubStatusDesc(clmSubStatusDesc.trim());
		}
		if (CommonUtil.isNotNull(resolution)) {
			bitsTicketInfo.setResolution(resolution.trim());
		}
		if (CommonUtil.isNotNull(bitsProduct)) {
			bitsTicketInfo.setBitsProduct(bitsProduct.trim());
		}
		if (CommonUtil.isNotNull(rootCause)) {
			bitsTicketInfo.setRootCause(rootCause.trim());
		}
		if (CommonUtil.isNotNull(bitsUrlLink)) {
			bitsTicketInfo.setBitsUrl(bitsUrlLink.trim());
		}
		return bitsTicketInfo;
	}
}
