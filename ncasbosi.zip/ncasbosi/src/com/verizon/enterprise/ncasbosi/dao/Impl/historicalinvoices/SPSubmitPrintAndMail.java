package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiPrintAndMailDO;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPSubmitPrintAndMail extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPSubmitPrintAndMail.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"USERID",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQUESTED_TS",  getSqlDataType(Types.TIMESTAMP),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ABAN",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIG_SYS",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DOCUMENT_TYPE",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_DATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_PAGE",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"END_PAGE",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_NAME",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_COST_CENTER",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_LOCATION",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_PHONE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_EMAIL",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_NAME",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_COMPANY",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_ADDRESS_1",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_ADDRESS_2",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_ADDRESS_3",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_CITY",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_STATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_ZIP",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_COUNTRY",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_PHONE",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SHIP_METHOD",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SHIP_ACCOUNT",        getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"REQUEST_NUMBER",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	}

	public SPSubmitPrintAndMail(DataSource dataSource){
		super(dataSource, getVGWSchemaName() + "." + "VGWD901", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map requestMap = (HashMap)input;
		HiPrintAndMailDO hiPrintAndMailDO = (HiPrintAndMailDO)requestMap.get("hiPrintAndMailDO");

		String debugLevel = "0";
//		if (_LOGGER.isDebugEnabled()) debugLevel = "1";

		Calendar cal = new GregorianCalendar();  // get current date time
		Timestamp ts = new Timestamp(cal.getTimeInMillis()); //save current date time as time stamp

		List callList = new ArrayList();
		callList.add(hiPrintAndMailDO.getUserId()); // USERID
		callList.add(debugLevel);    // DEBUG_LEVEL
		callList.add(ts);            //REQUESTED_TS
		callList.add(hiPrintAndMailDO.getMan()); //MAN
		callList.add(hiPrintAndMailDO.getBan()); //BAN
		callList.add(hiPrintAndMailDO.getAban());
		callList.add(hiPrintAndMailDO.getOsid()); //OSID
		callList.add(hiPrintAndMailDO.getDocType()); //DOCUMENT_TYPE
		callList.add(hiPrintAndMailDO.getBillDate()); //BILL_DATE

		callList.add(hiPrintAndMailDO.getPrintFromPage());
		callList.add(hiPrintAndMailDO.getPrintToPage());
		callList.add(hiPrintAndMailDO.getRequestorName());
		callList.add(hiPrintAndMailDO.getRequestorCostCenter());
		callList.add(hiPrintAndMailDO.getRequestorLocationCode());
		callList.add(hiPrintAndMailDO.getRequestorPhoneNumber());
		callList.add(hiPrintAndMailDO.getRequestorEmail());

		callList.add(hiPrintAndMailDO.getShipToName());
		callList.add(hiPrintAndMailDO.getShipToCompany());
		callList.add(hiPrintAndMailDO.getShipToAddress());
		callList.add(hiPrintAndMailDO.getShipToAddress2());
		callList.add("");  //TO_ADDRESS_3
		callList.add(hiPrintAndMailDO.getShipToCity());
		callList.add(hiPrintAndMailDO.getShipToState());
		callList.add(hiPrintAndMailDO.getShipToZip());
		callList.add(hiPrintAndMailDO.getShipToCountry()); //TO_COUNTRY
		callList.add(hiPrintAndMailDO.getShipToPhoneNumber());
		callList.add(hiPrintAndMailDO.getShippingMethod());
		callList.add(hiPrintAndMailDO.getShippingAccountNumber());

		Map responseMap = executeSP(callList, false);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(responseMap, VGW);

		int requestNumber = (Integer)responseMap.get("REQUEST_NUMBER");

		//hiPrintAndMailDO.setPrintTrackingNumber(Integer.toString(requestNumber));

		_LOGGER.debug("Print and Mail request number = " + requestNumber);

		return responseMap;
	}
}
