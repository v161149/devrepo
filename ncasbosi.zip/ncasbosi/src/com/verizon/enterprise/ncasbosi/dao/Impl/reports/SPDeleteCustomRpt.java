package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.io.Serializable;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.exception.NCASException;

public class SPDeleteCustomRpt extends BaseStoredProcedure
{
	static private final Logger _LOGGER = Logger.getLogger(SPDeleteCustomRpt.class);

	private static List spInOutList;

	static
	{
		spInOutList = new ArrayList();

		spInOutList.add(new Object[]{"IN_DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"IN_RPT_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"OUT_MSG_STRING", getSqlDataType(Types.LONGVARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPDeleteCustomRpt(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_DELETE_CUST_RPT, spInOutList);
	}

	public Map executeStoredProcedure(String debugLevel, int rptId) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(debugLevel);//DEBUG_SW
		paramValueList.add(new Integer(rptId));//IN_RPT_ID
		Map retMap = executeStoredProcedure(paramValueList);
		int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
		if (returnCode > 0)
		{
			String msgString = (String)retMap.get("OUT_MSG_STRING");
			String[] errMsg = new String[3];
			errMsg[0] = "delCustomRpt";
			errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_DELETE_CUST_RPT;
			errMsg[2] = msgString;
			throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg, returnCode);
		}
		return retMap;
	}

	protected Map executeStoredProcedure(Object paramValues) throws Exception
	{
		List paramValueList = (List)paramValues;
		return executeSP(paramValueList, false);
	}
}

