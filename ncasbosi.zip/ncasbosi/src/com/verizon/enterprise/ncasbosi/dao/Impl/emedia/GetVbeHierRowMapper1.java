package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.vbe.VbeNodeDO;

public class GetVbeHierRowMapper1 implements RowMapper
{
	static private final Logger logger = Logger.getLogger(GetVbeHierRowMapper1.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "GetVbeHierRowMapper1::mapRow() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		VbeNodeDO myDO = null;

		if(rs != null)
		{
			myDO = new VbeNodeDO();
			
			//config 
			myDO.setNodeType(val(rs.getString("NODE_TYPE")));
			BigDecimal nodeOid = rs.getBigDecimal("NODE_OID");
			myDO.setNodeOid(nodeOid.toPlainString());
			myDO.setNodeId(val(rs.getString("NODE_ID")));
			myDO.setNodeName(val(rs.getString("NODE_NAME")));

		}

		return myDO;
	}
	
	private String val (String in)
	{
		if (in == null) return "";
		return in.trim();

	}
}
