package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadAFTAccountsRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadAFTAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		_LOGGER.info("Inside DownloadAFTAccountsRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List accountsList = new ArrayList();
		List account = new ArrayList();
		try {
			while(rs.next()) {
				account = new ArrayList();

				//Set the values
				String requestNumber = rs.getString("REQUEST_NO");//Char(17)
				String appUserId = rs.getString("APP_USER_ID");//Char(20)
				String userName = rs.getString("USER_NAME");//Char(50)
				String configType = rs.getString("CONFIG_TYPE");//Char(20)
				String configId = rs.getString("CONFIG_ID");//Char(20)
				String customerName = rs.getString("CUSTOMER_NAME");//Char(55)
				String action = rs.getString("ACTION");//Char(8)
				String mode = rs.getString("MODE");//Char(8)
				String comments = rs.getString("COMMENTS");//LongVarchar(500)
				String fileName = rs.getString("SS_FILE_NAME");//Varchar(100)
				String status = rs.getString("STATUS");//Char(10)
				//int recordCount = rs.getInt("RECORD_COUNT");//SmallInt
				//int recordsFailed = rs.getInt("RECORDS_FAILED");//SmallInt
				//int recordsAdded = rs.getInt("RECORDS_ADDED");//SmallInt
				//int recordsDeleted = rs.getInt("RECORDS_DELETE");//SmallInt
				String accountNumber = rs.getString("ACCOUNT");//Char(20)
				String errorCode = rs.getString("ERROR_CODE");//Char(8)
				String errorReason = rs.getString("ERROR_REASON");//Char(50)
				String accountType = rs.getString("ACCOUNT_TYPE");//Char(4)
				String foundIndicator = rs.getString("FOUND_IND");//Char(10)
				String origSystemId = rs.getString("ORIG_SYSTEM_ID");//Char(2)
				String origSystemName = rs.getString("ORIG_SYSTEM_NAME");//Char(20)
				String man = rs.getString("MAN");//Char(13)
				String ban = rs.getString("BAN");//Char(13)
				String aban = rs.getString("ABAN");// Char(13)
				String accountName = rs.getString("ACCOUNT_NAME");//Char(30)
				String addr1 = rs.getString("ADDRESS1");//Char(30)
				String addr2 = rs.getString("ADDRESS2");//Char(30)
				String addr3 = rs.getString("ADDRESS3");//Char(30)
				String addr4 = rs.getString("ADDRESS4");//Char(30)
				String state = rs.getString("STATE");//Char(2)
				String city = rs.getString("CITY");//Char(28)
				String zipCode = rs.getString("ZIP");//Char(9)
				double subscriberOid = rs.getDouble("SUBS_OID");//Decimal(10,0)
				String subscriberName = rs.getString("SUBSCRIBER_NAME");//Char(100)
				String guduns = rs.getString("GUDUNS");//Char(10)
				String bicCode = rs.getString("BIC_CODE");//Char(20)
				String verifyFlag = rs.getString("VERIFY_FLAG");//Char(1)
				double topSubscriberOid = rs.getDouble("TOP_SUBS_OID");//Decimal(10,0)
				String topSubscriberName = rs.getString("TOP_SUBS_NAME");//Char(100)
				String topGuduns = rs.getString("TOP_GUDUNS");//Char(10)
				String topBicName = rs.getString("TOP_BIC_NAME");//Char(100)
				String topBicCode = rs.getString("TOP_BIC_CODE");//Char(20)
				String topVerifyFlag = rs.getString("TOP_VERIFY_FLAG");//Char(1)
				String paperSupressIndicator = rs.getString("PAPER_SUPPRESS_IND");//Char(1)
				String paperFeeIndicator = rs.getString("PAPER_FEE_IND");//Char(1)
				String remitAccountIndicator = rs.getString("REMIT_ACCOUNT_IND");//Char(1)
				String enterpriseId = rs.getString("ENTERPRISE_ID");//Char(10)
				String naspId = rs.getString("NASP_ID");//Char(10)
				String bmConfigId = rs.getString("BM_CONFIG_ID");//Char(20)
				String ediEbid = rs.getString("EDI_VB811_EBID");//Char(20)
				String ddConfigId = rs.getString("DD_CONFIG_ID");//Char(20) 
				String ediDataGroup = rs.getString("DATA_GROUP");//Char(3)
				
				try {
					Date startDate = rs.getDate("START_DATE");//Date
					String startDateStr =  formatter.format(startDate);
					if(CommonUtil.isNotNull(startDateStr)) {
						account.add(new Cell(startDateStr.trim()));
					}
				} catch(IllegalArgumentException iae) {
					/*_LOGGER.debug("IllegalArgumentException Exception occured while parsing the Date(START_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("IllegalArgumentException Exception occured while parsing the Date(START_DATE) \n"
							+ iae.getMessage());
					 */					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					/*_LOGGER.debug("SQL Exception occured while parsing the Date(START_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(START_DATE) \n"
							+ sqlex.getMessage());
					*/
					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				
				try {
					Date billDate = rs.getDate("BILL_DATE");//Date
					String billDateStr =  formatter.format(billDate);
					if(CommonUtil.isNotNull(billDateStr)) {
						account.add(new Cell(billDateStr));
					}
				} catch(IllegalArgumentException iae) {
					_LOGGER.debug("Exception occured while parsing the Date(BILL_DATE) \n"
							+ iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date(BILL_DATE) \n"
							+ iae.getMessage());
					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				} catch(SQLException sqlex) {
					_LOGGER.debug("SQL Exception occured while parsing the Date(BILL_DATE) \n"
							+ sqlex.getMessage());
					_LOGGER.error("SQL Exception occured while parsing the Date(BILL_DATE) \n"
							+ sqlex.getMessage());
					
					//Add a blank cell, if any exception occurs while parsing date
					account.add(new Cell(""));
				}
				
				if(CommonUtil.isNotNull(requestNumber)) {
					account.add(new Cell(requestNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(appUserId)) {
					account.add(new Cell(appUserId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(userName)) {
					account.add(new Cell(userName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(configType)) {
					account.add(new Cell(configType.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(configId)) {
					account.add(new Cell(configId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(customerName)) {
					account.add(new Cell(customerName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(action)) {
					account.add(new Cell(action.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(mode)) {
					account.add(new Cell(mode.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(comments)) {
					account.add(new Cell(comments.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(fileName)) {
					account.add(new Cell(fileName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(status)) {
					account.add(new Cell(status.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(accountNumber)) {
					account.add(new Cell(accountNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(errorCode)) {
					account.add(new Cell(errorCode.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(errorReason)) {
					account.add(new Cell(errorReason.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(accountType)) {
					account.add(new Cell(accountType.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(foundIndicator)) {
					account.add(new Cell(foundIndicator.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(origSystemId)) {
					account.add(new Cell(origSystemId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(origSystemName)) {
					account.add(new Cell(origSystemName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(man)) {
					account.add(new Cell(man.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ban)) {
					account.add(new Cell(ban.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(aban)) {
					account.add(new Cell(aban.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(accountName)) {
					account.add(new Cell(accountName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(addr1)) {
					account.add(new Cell(addr1.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(addr2)) {
					account.add(new Cell(addr2.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(addr3)) {
					account.add(new Cell(addr3.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(addr4)) {
					account.add(new Cell(addr4.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(state)) {
					account.add(new Cell(state.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(city)) {
					account.add(new Cell(city.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(zipCode)) {
					account.add(new Cell(zipCode.trim()));
				} else {
					account.add(new Cell(""));
				}
				account.add(new Cell(String.valueOf(subscriberOid)));
				if(CommonUtil.isNotNull(subscriberName)) {
					account.add(new Cell(subscriberName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(guduns)) {
					account.add(new Cell(guduns.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(bicCode)) {
					account.add(new Cell(bicCode.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(verifyFlag)) {
					account.add(new Cell(verifyFlag.trim()));
				} else {
					account.add(new Cell(""));
				}
				account.add(new Cell(String.valueOf(topSubscriberOid)));
				if(CommonUtil.isNotNull(topSubscriberName)) {
					account.add(new Cell(topSubscriberName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(topGuduns)) {
					account.add(new Cell(topGuduns.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(topBicName)) {
					account.add(new Cell(topBicName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(topBicCode)) {
					account.add(new Cell(topBicCode.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(topVerifyFlag)) {
					account.add(new Cell(topVerifyFlag.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(paperSupressIndicator)) {
					account.add(new Cell(paperSupressIndicator.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(paperFeeIndicator)) {
					account.add(new Cell(paperFeeIndicator.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(remitAccountIndicator)) {
					account.add(new Cell(remitAccountIndicator.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(enterpriseId)) {
					account.add(new Cell(enterpriseId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(naspId)) {
					account.add(new Cell(naspId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(bmConfigId)) {
					account.add(new Cell(bmConfigId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ediEbid)) {
					account.add(new Cell(ediEbid.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ddConfigId)) {
					account.add(new Cell(ddConfigId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ediDataGroup)){
					account.add(new Cell(ediDataGroup.trim()));
				} else {
					account.add(new Cell(""));
				}
				
				accountsList.add(account);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadAFTAccountsRowMapperImpl's account -  " + account);
		}
		return accountsList;
	}

}
