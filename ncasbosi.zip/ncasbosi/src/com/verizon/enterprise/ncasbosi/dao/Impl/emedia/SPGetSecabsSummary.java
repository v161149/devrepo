package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.SecabsCandidateApiInput;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import java.math.BigDecimal;
/**
 * @author v898809
 * This class represents VAM SP -> SUMMARY_SECABS_V10
 *
 */
public class SPGetSecabsSummary extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPGetSecabsSummary.class);
	private static List spInOutList;
	private static GetSecabsSummaryRowMapperImpl rowMapper;
	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new GetSecabsSummaryRowMapperImpl();
		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CUST_NO", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUSTOMER_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_STMT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_ID_TS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPGetSecabsSummary(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_SECABS_SUMMARY, spInOutList);
	}

	public Map executeStoredProc(Object InputMap) throws Exception
	{
		SecabsCandidateApiInput secabInput = (SecabsCandidateApiInput)InputMap;
		BigDecimal customerNo=secabInput.getDecimalValue(secabInput.getCustNo());
		String customerType=secabInput.getCustomerType();
		BigDecimal configSubOid=secabInput.getDecimalValue(secabInput.getConfigSubsOid());
		String whereFilter=secabInput.getWhereStmt();
		String sortOrder=secabInput.getSortOrder();
		String tokenString=secabInput.getTokenString();
		Pagination myPag=secabInput.getPagination();

		if(customerType == null) {
			customerType = "";
		}
		if(whereFilter == null) {
			whereFilter = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(tokenString == null) {
			tokenString = "";
		}

		List paramValueList = new ArrayList();
		paramValueList.add(NCASBOSIConstants.VAM_USER_ID);//APP_USER_ID
		paramValueList.add(NCASBOSIConstants.VAM_DEBUG_LEVEL);//DEBUG_LEVEL
		paramValueList.add(customerNo);//CUST_NO
		paramValueList.add(customerType);//CUSTOMER_TYPE
		paramValueList.add(configSubOid);//CONFIG_SUBS_OID
		paramValueList.add(whereFilter);//WHERE_STMT
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(tokenString);//REPORT_ID_TS
		String lineOffSet = myPag.getLineOffset(); //LINE_OFFSET
		String pageSize = myPag.getPageSize(); //PAGE_SIZE

		if(myPag.isAllSelect()){
			lineOffSet = "1";
			pageSize = myPag.getMaxSize();
		}
		else{
			if(lineOffSet==null) {
				lineOffSet = "1";
			}
			if(pageSize==null) {
				pageSize = "50";
			}
		}


		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE
		Map resultMap = new HashMap();
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		checkVACErrors(procMap);
		myPag.setAllSelect(false);
		//pagination.updateCurrPageNum();
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		myPag.updateTotalPages(rowcountrStr.intValue());
		myPag.setDefaultSize(myPag.getItemsPerPage());
		Map acctMap = (HashMap)procMap.get("accounts");
		if(acctMap!=null)
			myPag.setResultSize(Integer.toString(CommonUtil.getMapSize(acctMap)));
		else myPag.setResultSize("0");
		resultMap.put("accountsMap", acctMap);
		resultMap.put("pagination", myPag);
		resultMap.put("RETURN_CODE", procMap.get("RETURN_CODE"));
		resultMap.put("REASON_CODE", procMap.get("REASON_CODE"));
		resultMap.put("ERROR_TEXT", procMap.get("ERROR_TEXT"));
		resultMap.put("SP_SQLCODE", procMap.get("SP_SQLCODE"));
		resultMap.put("SP_SQLTOKENS", procMap.get("SP_SQLTOKENS"));
		resultMap.put("SP_SQLSTATE", procMap.get("SP_SQLSTATE"));

		return resultMap ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}