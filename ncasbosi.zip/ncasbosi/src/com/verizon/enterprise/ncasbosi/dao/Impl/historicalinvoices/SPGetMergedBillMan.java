package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * check the ban to see if it is part of a merged bill master, if so return the merged bill master man
 * else this api returns the ban in the man field.
 */

public class SPGetMergedBillMan extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetMergedBillMan.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();

		 spInOutList.add(new Object[]{"APP_USER_ID",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"BAN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIG_SYSTEM_ID",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"MAN",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"APP_RETURN_CODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	 }

	public SPGetMergedBillMan(DataSource dataSource){
		super(dataSource, getVAMSchemaName() + "." + "MERGED_BILL_MAN", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		_LOGGER.info("input map::"+inputMap);


		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add((String)inputMap.get("APP_USER_ID"));
		callList.add("0");

		callList.add((String)inputMap.get("BAN"));
		callList.add((String)inputMap.get("BILL_DATE"));
		callList.add((String)inputMap.get("ORIG_SYSTEM_ID"));


		/* execute sp */
		Map resMap = executeSP(callList, false);

		/* look for errors */
		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(resMap, VAM);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
