package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Preference;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

	public class GetUserPreferenceRowMapperImpl  implements ResultSetExtractor {
		static private final Logger _LOGGER = Logger.getLogger(GetUserPreferenceRowMapperImpl.class);
		public Object extractData(ResultSet rs) throws SQLException {
			_LOGGER.info("Inside GetUserPreferenceRowMapperImpl -> ");
			CommonUtil.printMetaDataInfo(rs.getMetaData());

			ArrayList rows = new ArrayList();
			Preference preference = null;
		
			while(rs.next()) {
				
				preference = new Preference();
				String tab_order = Integer.toString(rs.getInt("CURSOR_NBR"));
				String col_order = Integer.toString(rs.getInt("COL_ORDER"));
				String col_name = rs.getString("COL_NAME");
				String col_heading = rs.getString("DISPLAY_NAME");
				String data_type = rs.getString("DATA_TYPE");
				String filter_data = rs.getString("FILTER_DATA");

				preference.setTab_order(tab_order.trim());
				preference.setCol_order(col_order.trim());
				preference.setCol_name(col_name.trim());
				preference.setData_type(data_type.trim());
				preference.setCol_heading(col_heading.trim());
				preference.setFilter_data(filter_data.trim());
				rows.add(preference);
			}
				return rows;
			}
	}
	





	
	