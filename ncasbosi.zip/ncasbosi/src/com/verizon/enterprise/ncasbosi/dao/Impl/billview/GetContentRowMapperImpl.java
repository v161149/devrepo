package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.BillViewConstants;
import com.verizon.enterprise.common.ncas.display.CellWork;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetContentRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger
			.getLogger(GetContentRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		if (_LOGGER.isDebugEnabled()) {
			_LOGGER.debug("Inside GetContentRowMapperImpl -> ");
		}
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Content content = new Content();
		ArrayList rows = new ArrayList();
		content.setRows(rows);
		ArrayList cellList = null;

		while (rs.next()) {
			cellList = new ArrayList();
			String columnPrefix = "";
			String column = "";
			String column_linkKey = "";

			for (int i = 0; i < BillViewConstants.NUMBER_COLUMNS; i++) {
				columnPrefix = "COL_" + (i < 9 ? "0" : "")
						+ String.valueOf(i + 1);
				column = rs.getString(columnPrefix);
				if(column == null)
					column = "";
				column_linkKey = getLinkKey(rs, columnPrefix + "_XREF");
				if (!column.equals("")) 
				cellList.add(createCell(column.trim(), column_linkKey,i + 1));
			}
			rows.add(cellList);

		}
		return content;
	}
	
	public CellWork createCell(String name, String linkKey,int colIndex) {
		CellWork cell = new CellWork();
		cell.setLinkKey(linkKey);
		cell.setName(name);
		cell.setColIndex(colIndex);
		return cell;
	}

	private String getLinkKey(ResultSet rs, String column) {
		String retValue = "";
		try {
			retValue = Integer.toString(rs.getInt(column));
		} catch (Exception e) {
		}
		return retValue.trim();
	}

}