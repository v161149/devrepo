package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import java.sql.Types;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
//import com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.DummyAuditorDetail;

public class SPGetAuditorDetails extends BaseStoredProcedure {
	private static final Logger _LOGGER = Logger.getLogger(SPGetAuditorDetails.class);


	public SPGetAuditorDetails(DataSource dataSource,String key ) {
		super(dataSource, NCASBOSIConstants.SP_GET_AUDITOR_DETAILS,new ListGenerator().getList(key));
	}

	public Map executeStoredProcedure(Object input) throws Exception {
	/*	_LOGGER.info("Entering executeStoredProcedure");
		Map resMap = new HashMap();
		Map inputMap = (Map)input;
		String key = (String)inputMap.get("KEY");
		resMap.put("RESULT", DummyAuditorDetail.getAuditorDetails(key));
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+ getStoredProcedureName());
	*/
		
		_LOGGER.info("Entering executeStoredProcedure");
		Map inputMap = (Map)input;
		String service_center = null;
		String auditor_VZId = null;
		int start_pos = 1;   // hardcoded
		int num_rows = 1000; // hardcoded
		String key = (String)inputMap.get("KEY");
		if(key.equals(NCASBOSIConstants.Get_AUDITOR_DTL_By_SERVICE_CENTER)){
			service_center = (String)inputMap.get("SERVICE_CENTER");
		}else if(key!=null && key.trim().equals(NCASBOSIConstants.Get_AUDITOR_DTL_By_VZID)){
		    auditor_VZId = (String)inputMap.get("AUDITOR_VZID");
		}
		List paramValueList = new ArrayList();

		paramValueList.add(service_center); //SERVICE_CENTER
		paramValueList.add(auditor_VZId);  // AUDITOR_VZID
		paramValueList.add(start_pos); // START_POSITION
		paramValueList.add(num_rows); //NUM_ROWS
		
		//* *** call the SP ************ 
		 Map resMap = executeSP(paramValueList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+ getStoredProcedureName());

		return resMap;
	}
}

class ListGenerator{
	public List getList(String key){
		   ArrayList spInOutList = new ArrayList();
		   spInOutList.add(new Object[]{"SEARCH_RESULTS",BaseStoredProcedure.getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new GetAuditorDetailsMapper(key)});

			spInOutList.add(new Object[] { "SERVICE_CENTER",BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
			spInOutList.add(new Object[] { "AUDITOR_VZID",BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
			spInOutList.add(new Object[] { "START_POSITION",BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
			spInOutList.add(new Object[] { "NUM_ROWS",BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });

			spInOutList.add(new Object[] { "RETURN_CODE",BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
			spInOutList.add(new Object[] { "REASON_CODE",BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
			spInOutList.add(new Object[] { "ERROR_TEXT",BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
			spInOutList.add(new Object[] { "SP_SQLCODE",BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
			spInOutList.add(new Object[] { "SP_SQLTOKENS",BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT, });
			spInOutList.add(new Object[] { "SP_SQLSTATE",BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
			spInOutList.add(new Object[] { "TOTAL_ROWS",BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		return spInOutList;
	}	
}

	


