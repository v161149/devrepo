package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.dataobjects.Structure;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;



public class SPArchivedBill extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPArchivedBill.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"backendSystemID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"man", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"billDate", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"userOid", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

	}

	public SPArchivedBill(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_RETRIEVE_ARCHIVED_BILL, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel, Map inputMap)throws Exception
	{
		String METHOD_NAME = "executeStoredProcedure  ";
		List paramValueList = new ArrayList();

		_LOGGER.debug(METHOD_NAME + " Input Map " +  inputMap.toString());
		//get all the parameters from input map

		paramValueList.add(userId); //APP_USER_ID
		paramValueList.add(debugLevel); //DEBUG_LEVEL

		String backendSystemID = (String) inputMap.get("backendSystemID");
		paramValueList.add(backendSystemID); //backendSystemID
		_LOGGER.debug(METHOD_NAME + "backendSystemID = " + backendSystemID );

		String man = (String) inputMap.get("man");
		paramValueList.add(man); //man
		_LOGGER.debug(METHOD_NAME + "man = " + man );

		String billDate = (String) inputMap.get("billDate");
		paramValueList.add(billDate); //billDate
		_LOGGER.debug(METHOD_NAME + "billDate = " + billDate );

		String userOid = (String) inputMap.get("userOid");
		paramValueList.add(userOid); //userOid
		_LOGGER.debug(METHOD_NAME + "userOid = " + userOid );


		Map procMap = (HashMap)executeStoredProcedure(paramValueList);

		return procMap ;
	}
	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
