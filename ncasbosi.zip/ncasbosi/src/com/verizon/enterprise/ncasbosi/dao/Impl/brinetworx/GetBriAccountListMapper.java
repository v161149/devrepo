package com.verizon.enterprise.ncasbosi.dao.Impl.brinetworx;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.brinetworx.BriAccount;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetBriAccountListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetBriAccountListMapper.class);



	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{

		_LOGGER.info("GetBriAccountListMapper - Mapping Row# "+rowNum);

		BriAccount briAccout = null;

		if(rs!=null){

			briAccout = new BriAccount();
			
			/*  the column is named:
			 *	E6_ETMP_SV_ACCOUNT when non-lal user
			 *	ACCOUNT_NUMBER when lal user
			 *	So going with posion instead as it's always 1			 * 
			 */
				
			briAccout.setAccount(rs.getString(1));
			
		}

		return briAccout;

	}	
	
}
