package com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import java.util.Map;
import com.verizon.enterprise.common.ncas.bugtracker.IssueDetails;
import java.util.Date;
public class GetBugTrackerMapper3 implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetBugTrackerMapper3 .class);
	

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException	{		
		IssueDetails issueDetail=null;
		_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.bugtracker.GetBugTrackerMapper3");
		if(rs != null)
		{
			 issueDetail=new IssueDetails();
			 String userName=rs.getString("USER_NAME");
			 issueDetail.setReportedBy(userName!=null?userName.trim():userName);
			 
		}
		return issueDetail;
	}
	
	
}

