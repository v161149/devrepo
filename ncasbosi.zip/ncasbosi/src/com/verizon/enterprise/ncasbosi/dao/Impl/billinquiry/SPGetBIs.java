package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;


import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;


import com.verizon.enterprise.common.ncas.billinquiry.BillInquirySearch;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiryForm;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;


public class SPGetBIs extends BaseStoredProcedure
{
   static private final Logger _LOGGER = Logger.getLogger(SPGetBIs.class);
   private static List spInOutList;

   private static final String CALENDAR_FORMAT1 = "MM/dd/yyyy";
   private static final String CALENDAR_FORMAT2 = "yyyy-MM-dd";

   static
   {
	_LOGGER.info("Static Init");
    spInOutList = new ArrayList();

    spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new BISearchDataMapper()});

	spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"BI_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CREATE_DATE_FROM", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CREATE_DATE_TO", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CLOSE_DATE_FROM", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CLOSE_DATE_TO", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"BILL_DATE_FROM", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"BILL_DATE_TO", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CONTACT_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CONTACT_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CONTACT_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CUST_WORK_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"BI_REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"INVOICE_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"DISP_AMOUNT_FROM", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"DISP_AMOUNT_TO", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"INQUIRY_MEMO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"SORT_FIELD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"SORT_DIR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"START_POS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"NUM_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});



	spInOutList.add(new Object[]{"RETURN_CODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"REASON_CODE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"ERROR_TEXT", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLCODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLTOKENS", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
	spInOutList.add(new Object[]{"SP_SQLSTATE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"ACCOUNT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
   }

	public SPGetBIs(DataSource dataSource)
	{

	    super(dataSource, NCASBOSIConstants.SP_GET_BIS, spInOutList);

	}
	public Map executeStoredProcedure(Object input)throws Exception
	{
		_LOGGER.info("Enterring executeStoredProcedure");

		BillInquiryForm billInquiryForm = (BillInquiryForm)input;
		BillInquirySearch myBIS = null;
		Pagination myPag = null;
		List paramValueList = new ArrayList();

		// Check/Process  Input Map
		if ((billInquiryForm != null) && (billInquiryForm instanceof BillInquiryForm)){
			myBIS = billInquiryForm.getMyBIS();   // get data user entered into screen
			myPag = billInquiryForm.getMyPag();   // get pagination data so know which page to retrieve
		}else{
			throw new Exception("SPGetBIs: bad input expect BillInquiryForm got:" + billInquiryForm);
		}
		if (myBIS == null){
			throw new Exception("SPGetBIs: Search bill inquiry data is null");
		}
		if (myPag == null){
			throw new Exception("SPGetBIs: Bill inquiry pagination is null");
		}

		//convert date user entered into date db2 can use.
		String formatIn = "MM/dd/yyyy";
		String formatOut = "yyyy-MM-dd";
		String createDateFrom = CommonUtil.formatDate(myBIS.getCreateDateFrom(), formatIn, formatOut);
		String createDateTo   = CommonUtil.formatDate(myBIS.getCreateDateTo(),   formatIn, formatOut);
		String closeDateFrom  = CommonUtil.formatDate(myBIS.getCloseDateFrom(),  formatIn, formatOut);
		String closeDateTo    = CommonUtil.formatDate(myBIS.getCloseDateTo(),    formatIn, formatOut);
		String billDateFrom   = CommonUtil.formatDate(myBIS.getBillDateFrom(),   formatIn, formatOut);
		String billDateTo     = CommonUtil.formatDate(myBIS.getBillDateTo(),     formatIn, formatOut);


		String ban = myBIS.getBAN();
		String san = myBIS.getSAN();
		String acctInfo[] = getBan_Man_accountId(ban,san);
		String sendername = myBIS.getSenderName();
		String senderemail = myBIS.getSenderEmail();
		String senderphone = myBIS.getSenderPhone();
		String trackingid = myBIS.getSrcSysBIId();
		String custwo = myBIS.getCustWO();
		String reasoncode = myBIS.getReasonCode();
		String invoicenum = myBIS.getInvoiceNum();
		String inquirymemo = myBIS.getInquiryMemo();

		paramValueList.add(myBIS.getSourcePortal());
		paramValueList.add(new Double(myBIS.getUserOid()));		 	// USER_OID
		paramValueList.add(new Integer(Integer.parseInt(myBIS.getStatus())));		 	// BI_STATUS
		paramValueList.add(acctInfo[0]);		 			// BAN
		paramValueList.add(acctInfo[1]);				 	// MAN
		paramValueList.add(getV(createDateFrom));		// CREATE_DATE_FROM
		paramValueList.add(getV(createDateTo));			// CREATE_DATE_TO
		paramValueList.add(getV(closeDateFrom));		// CLOSE_DATE_FROM
		paramValueList.add(getV(closeDateTo));			// CLOSE_DATE_TO
		paramValueList.add(getV(billDateFrom));			// BILL_DATE_FROM
		paramValueList.add(getV(billDateTo));			// BILL_DATE_FROM
		paramValueList.add(getV(sendername));			// CONTACT_NAME
		paramValueList.add(getV(senderemail));			// CONTACT_EMAIL
		paramValueList.add(getV(senderphone));			// CONTACT_PHONE
		paramValueList.add(getV(trackingid));			// SRC_SYS_BI_ID
		paramValueList.add(getV(custwo));				// CUST_WORK_ORDER
		paramValueList.add(getV(reasoncode));			// BI_REASON_CODE
		paramValueList.add(getV(invoicenum));			// INVOICE_NUMBER
		paramValueList.add(new Double(Double.parseDouble(myBIS.getDisputeAmountFrom())));		 	// DISP_AMOUNT_FROM
		paramValueList.add(new Double(Double.parseDouble(myBIS.getDisputeAmountTo())));		 	// DISP_AMOPUNT_TO
		paramValueList.add(getV(inquirymemo)); 			// INQUIRY_MEMO

		//pagination fields
		String sortField = myPag.getSortField();

		paramValueList.add(getV(sortField));		 	// SORT_FIELD
		String sortDir = myPag.getSortDirection();
		if(sortDir != null)
		{
			if(sortDir.equalsIgnoreCase("A") ||sortDir.equalsIgnoreCase("D"))
			{
				paramValueList.add(sortDir);		 	// SORT_DIR
			}
			else
			{
				paramValueList.add(null);
			}
		}
		else
		{
			paramValueList.add(null);
		}

		paramValueList.add(new Integer(myPag.getLineOffset()));	 // START_POS
		paramValueList.add(new Integer(myPag.getPageSize()));	 	// NUM_ROWS
		paramValueList.add(acctInfo[2]);	 	// ACCOUNT_ID
		/***** call the SP *************/
		Map resMap = executeSP(paramValueList, false);
		//Map resMap = getBIS();
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;

	}

	//get value from variable, if empty string set to null.
	private String getV (String input)
	{
		if (input != null && !"".equals(input))
		{
			return input;
		}
		else
		{
			return null;
		}
	}
	//reassign ban,man and account id values
	private String[] getBan_Man_accountId(String ban,String man){
		String xBan = getV(ban);
		String xMan = getV(man);
		if(xBan==null && xMan==null){
			return new String[]{null,null,null};
		}else if(xBan!=null && xMan==null){
			return new String[]{null,null,xBan};
		}else if(xBan==null && xMan!=null){
			return new String[]{null,xMan,null};
		}else{
			return new String[]{xBan,xMan,null};
		}
	}
	//coded for populating dev-centric mickey data.
	private Map getBIS(){
		HashMap outMap = new HashMap();
		ArrayList outputList =  new ArrayList();
		BillInquiry resBI = null;
		Object[] dummyData = {
								new Object[]{"1-409121111","00160406","00160406","RGIS INVENTORY SPECIALIS","VBC","Arleen","Mallon",new Date(),"Closed",new Date(),"","OV","101"},
								new Object[]{"1-409128731","","","SAE POWER","VBC","Angela","Lipani",new Date(),"Working - Under Investigation",new Date(),"","OV","100"},
								new Object[]{"BILL2610030008086","","6178151112112",null,"VBC","Geziben","Seldron",new Date(),"Working - Under Investigation",new Date(),"","ECP","100"}
							 };
		for(int i=0;i<dummyData.length;i++){
			resBI = new BillInquiry();
			Object[] billInquiryInfo = (Object[])dummyData[i];
			resBI.setSrcSysBIID((String)billInquiryInfo[0]);
			resBI.setBAN((String)billInquiryInfo[1]);
			resBI.setSAN((String)billInquiryInfo[2]);
			resBI.setAcctName((String)billInquiryInfo[3]);
			resBI.setSourcePortal((String)billInquiryInfo[4]);
			resBI.setSenderLastName((String)billInquiryInfo[5]);
			resBI.setSenderFirstName((String)billInquiryInfo[6]);
			resBI.setCreatedDate((Date)billInquiryInfo[7]);
			resBI.setCreatedSDate((String)billInquiryInfo[7]);
			resBI.setStatus((String)billInquiryInfo[8]);
			resBI.setCloseDate((Date)billInquiryInfo[9]);
			resBI.setClaimTrackingNumber((String)billInquiryInfo[10]);
			resBI.setBICategory((String)billInquiryInfo[11]);
			resBI.setStatusCode(Integer.parseInt((String)billInquiryInfo[12]));
			outputList.add(resBI);
		}
		outMap.put("RESULT_SET_ONE",outputList);
		outMap.put("TOTAL_ROWS","3");
		outMap.put("RETURN_CODE",Integer.valueOf("0"));
		//System.out.println("printing the response Map::"+outMap);
		return outMap;
	}
}
