package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;import com.verizon.enterprise.common.util.DateUtility;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetClientViewPaperInvListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetClientViewPaperInvListMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.debug("GetClientViewPaperInvListMapper - Mapping Row# "+rowNum);				String formatDb2 = "yyyy-MM-dd";		String formatDisplayed = "MM/dd/yyyy";
		HiSelectDO hiDO = null;
		if(rs!=null){
			hiDO = new HiSelectDO();			hiDO.setDocType(rs.getString("DOCUMENT_TYPE"));
			hiDO.setLocation(rs.getString("LOCATION"));			hiDO.setTotalPages(rs.getInt("NUMBER_OF_PAGES") + "");			hiDO.setRemitInd(rs.getString("REMIT_IND"));			hiDO.setAban(rs.getString("ABAN"));			hiDO.setBillDate(rs.getString("BILL_DATE"));						hiDO.setStartSection("0");			hiDO.setSections((rs.getInt("SECTIONS") + ""));  			hiDO.setFileType(rs.getString("FORMAT"));  // afp or pdf						if (hiDO.getDocType() == null) hiDO.setDocType("vz");			if (hiDO.getDocType().trim().equals("")) hiDO.setDocType("vz");					}		_LOGGER.debug("GetClientViewPaperInvListMapper " + rs.getMetaData());		_LOGGER.debug("GetClientViewPaperInvListMapper " + hiDO);
		return hiDO;
	}
}
