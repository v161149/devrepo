package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaBMAddress;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetEMediaBMAddressRowMapperImpl implements RowMapper {
	static private final Logger _LOGGER = Logger
			.getLogger(GetEMediaBMAddressRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetEMediaBMAddressRowMapperImpl::mapRow rowNum - "
				+ rowNum);
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		EMediaBMAddress addr = new EMediaBMAddress();

		try {
			String configSubscriptionOid = rs.getString("CONFIG_SUBS_OID");
			int addrSeq = rs.getInt("ADDRESS_SEQ");
			String configId = rs.getString("CONFIG_ID");
			String serviceType = rs.getString("SERVICE_TYPE");
			String addrType = rs.getString("CUST_ADDR_TYPE");
			String addr1 = rs.getString("CUST_ADDR_1");
			String addr2 = rs.getString("CUST_ADDR_2");
			String addr3 = rs.getString("CUST_ADDR_3"); 
			String city = rs.getString("CUST_CITY");
			String state = rs.getString("CUST_STATE");
			String zipCode = rs.getString("CUST_ZIP");
			String postalCode = rs.getString("POSTAL_CODE");
			String country = rs.getString("CUST_COUNTRY");
			int cdCopies = rs.getInt("CD_COPIES");
			String lastUpdatedUserID = rs.getString("EXT_UPDT_USR_ID");
			String lastUpdatedUserName = rs.getString("EXT_UPDT_USR_NAME");
			String startDate = rs.getString("START_DATE");
			String endDate = rs.getString("END_DATE");

			//Pretty print the DB Values - GBR - as per Paul request.
			List valuesList = new ArrayList();
			valuesList.add(configSubscriptionOid);
			valuesList.add(addrSeq);
			valuesList.add(configId);
			valuesList.add(serviceType);
			valuesList.add(addrType);
			valuesList.add(addr1);
			valuesList.add(addr2);
			valuesList.add(addr3);
			valuesList.add(city);
			valuesList.add(state);
			valuesList.add(zipCode);
			valuesList.add(postalCode);
			valuesList.add(country);
			valuesList.add(cdCopies);
			valuesList.add(lastUpdatedUserID);
			valuesList.add(lastUpdatedUserName);
			valuesList.add(startDate);
			valuesList.add(endDate);
			CommonUtil.prettyPrintValues(valuesList);

			if (CommonUtil.isNotNull(configSubscriptionOid)) {
				addr.setConfigSubsOid(configSubscriptionOid.trim());
			}
			addr.setAddrSequence(addrSeq);
			if (CommonUtil.isNotNull(configId)) {
				addr.setConfigId(configId.trim());
			}
			if (CommonUtil.isNotNull(serviceType)) {
				addr.setServiceType(serviceType.trim());
			}

			try {
				String startDateStr =  formatter.format(startDate);
				if(CommonUtil.isNotNull(startDateStr)) {
					addr.setStartDate(CommonUtil.getDateFromString(startDate));
				}
			} catch(IllegalArgumentException iae) {
				//Do Nothing
				_LOGGER.debug("Exception occured while parsing the resultset \n"
						+ iae.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"
						+ iae.getMessage());
			}

			try {
				String endDateStr =  formatter.format(endDate);
				if(CommonUtil.isNotNull(endDateStr)) {
					addr.setStartDate(CommonUtil.getDateFromString(endDate));
				}
			} catch(IllegalArgumentException iae) {
				//Do Nothing
				_LOGGER.debug("Exception occured while parsing the resultset \n"
						+ iae.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"
						+ iae.getMessage());
			} 

			if (CommonUtil.isNotNull(addrType)) {
				addr.setAddTypeInd(addrType.trim());
			}
			if (CommonUtil.isNotNull(addr1)) {
				addr.setAddress1(addr1.trim());
			}
			if (CommonUtil.isNotNull(addr2)) {
				addr.setAddress2(addr2.trim());
			}
			if (CommonUtil.isNotNull(addr3)) {
				addr.setAddress3(addr3.trim());
			}
			if (CommonUtil.isNotNull(city)) {
				addr.setCity(city.trim());
			}
			if (CommonUtil.isNotNull(state)) {
				addr.setState(state.trim());
			}
			if (CommonUtil.isNotNull(zipCode)) {
				addr.setZip(zipCode.trim());
			}
			if (CommonUtil.isNotNull(postalCode)) {
				addr.setPostalCode(postalCode.trim());
			}
			if (CommonUtil.isNotNull(country)) {
				addr.setCountry(country.trim());
			}
			addr.setCdCopies(cdCopies);
			if (CommonUtil.isNotNull(lastUpdatedUserID)) {
				addr.setLastUpdatedUserId(lastUpdatedUserID.trim());
			}
			if (CommonUtil.isNotNull(lastUpdatedUserName)) {
				addr.setLastUpdatedUserName(lastUpdatedUserName.trim());
			}

		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
		} catch(SQLException sqlex) {
			//Do Nothing
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ sqlex.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ sqlex.getMessage());
		}

		return addr;
	}
}
