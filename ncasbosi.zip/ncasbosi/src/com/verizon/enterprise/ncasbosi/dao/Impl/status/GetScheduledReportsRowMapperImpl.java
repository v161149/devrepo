package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.status.BaseReportList;
import com.verizon.enterprise.common.status.CurrentReports;
import com.verizon.enterprise.common.status.ScheduledReports;
import com.verizon.enterprise.common.status.ReportsAddParam;
import com.verizon.enterprise.common.status.StatusSchedulingUtility;
import com.verizon.enterprise.common.status.TableCell;
import com.verizon.enterprise.common.status.TableHeaderCell;
import com.verizon.enterprise.common.status.TableRow;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetScheduledReportsRowMapperImpl implements RowMapper {

	static private final Logger logger = Logger.getLogger(GetScheduledReportsRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "GetScheduledReportsRowMapperImpl::mapRow()";
		logger.info("ENTER " + METHOD_NAME);

		Map returnMap = new HashMap();

		try
		{
			String userOID = null;
			String portalUserID = null;
			String employeeFlag = null;
			String selectionType = null;
			String billTypeFilter = null;
			String accountListType = null;
			String accountListName = null;
			String subscriberOID = null;
			String subscriptionOID = null;
			String reportNumber = null;
			String billDate = null;
			String thruDate = null;
			String wherePhrase = null;
			String sortOrder = null;
			String additionalParmeters = null;
			String dataformat = null;
			String frequency = null;
			String structureType = null;
			String structureOid = null;
            String positionType = null;
            String positionOid = null;
            
			if (CommonUtil.isNotNull(rs.getString("USER_OID")))
			{
				userOID = rs.getBigDecimal("USER_OID").toString();
			}

			portalUserID = rs.getString("PORTAL_USER_ID");
			employeeFlag = rs.getString("EMPLOYEE_FLAG");
			selectionType = rs.getString("SELECTION_TYPE");
			billTypeFilter = rs.getString("BILL_TYPE_FILTER");
			accountListType = rs.getString("ACCT_LIST_TYPE");
			accountListName = rs.getString("ACCT_LIST_NAME");

			if (CommonUtil.isNotNull(rs.getString("SUBSCRIBER_OID")))
			{
				subscriberOID = rs.getBigDecimal("SUBSCRIBER_OID").toString();
			}

			if (CommonUtil.isNotNull(rs.getString("SUBSCRIPTION_OID")))
			{
				subscriptionOID = rs.getBigDecimal("SUBSCRIPTION_OID").toString();
			}

			reportNumber = rs.getString("REPORT_NUMBER");
			billDate = rs.getString("BILL_DATE");
			thruDate = rs.getString("THRU_DATE");
			wherePhrase = rs.getString("WHERE_PHRASE");
			sortOrder = rs.getString("SORT_ORDER");
			additionalParmeters = rs.getString("ADDITIONAL_PARMS");
			dataformat = rs.getString("DATAFORMAT");
			frequency = rs.getString("FREQUENCY");

            structureType = rs.getString("STRUCTURE_TYPE");
            structureOid = rs.getString("STRUCTURE_OID");
            positionType = rs.getString("POSITION_TYPE");
            positionOid = rs.getString("POSITION_OID");
            

			returnMap.put("user_oid", userOID);
			returnMap.put("employee_flag", employeeFlag);
			returnMap.put("portal_user_id", portalUserID);
			returnMap.put("selection_type", selectionType);
			returnMap.put("bill_type_filter", billTypeFilter);
			returnMap.put("account_list_type", accountListType);
			returnMap.put("account_list_name", accountListName);
			returnMap.put("subscriber_oid", subscriberOID);
			returnMap.put("subscription_oid", subscriptionOID);
			returnMap.put("report_number", reportNumber);
			returnMap.put("bill_date", billDate);
			returnMap.put("thru_date", thruDate);
			returnMap.put("where_phrase", wherePhrase);
			returnMap.put("sort_order", sortOrder);
			returnMap.put("additional_parmeters", additionalParmeters);
			returnMap.put("dataformat", dataformat);
			returnMap.put("frequency", frequency);
			            
            returnMap.put("structure_type", structureType);
            returnMap.put("structure_oid", structureOid);
            returnMap.put("position_type", positionType);
            returnMap.put("position_oid", positionOid);

		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.debug("Exception occured while parsing the resultset \n" + e.getMessage());
		}

		logger.info("EXIT " + METHOD_NAME);

		return returnMap;
	}

}