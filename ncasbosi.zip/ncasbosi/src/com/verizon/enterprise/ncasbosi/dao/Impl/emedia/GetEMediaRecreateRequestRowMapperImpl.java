package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.verizon.enterprise.common.eMedia.EMediaRecreateRequest;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;

public class GetEMediaRecreateRequestRowMapperImpl implements RowMapper {
	
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaProfileRowMapperImpl.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.info("Inside GetEMediaRecreateRequestRowMapperImpl::mapRow");
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		EMediaRecreateRequest request = new EMediaRecreateRequest();
		
		request.setRequestNumber(rs.getInt("REQUEST_NUMBER"));
		request.setConfigSubscriptionOid(rs.getDouble("CONFIG_SUBS_OID"));
		
		String requestStatus = rs.getString("REQUEST_STATUS");
		String serviceType = rs.getString("SERVICE_TYPE");
		String requestYear = rs.getString("REQUEST_YEAR");
		String requestMonth = rs.getString("REQUEST_MONTH");
		String recreateProfileIndicator = rs.getString("RECREATE_PROF_IND");
		String userId = rs.getString("EXT_UPDT_USR_ID");
		String userName = rs.getString("EXT_UPDT_USR_NAME");
		String configId = rs.getString("CONFIG_ID");
		String companyName = rs.getString("COMPANY_NAME");
		String requestComment = rs.getString("REQUEST_COMMENT");
		
		if(CommonUtil.isNotNull(requestStatus)) {
			request.setRequestStatus(requestStatus.trim());
		}
		if(CommonUtil.isNotNull(serviceType)) {
			request.setServiceType(serviceType.trim());
		}
		if(CommonUtil.isNotNull(requestYear)) {
			request.setRequestYear(requestYear.trim());
		}
		if(CommonUtil.isNotNull(requestMonth)) {
			request.setRequestMonth(requestMonth.trim());
		}
		if(CommonUtil.isNotNull(recreateProfileIndicator)) {
			request.setRecreateProfileIndicator(recreateProfileIndicator.trim());
		}
		if(CommonUtil.isNotNull(userId)) {
			request.setUserId(userId.trim());
		}
		if(CommonUtil.isNotNull(userName)) {
			request.setUserName(userName.trim());
		}
		if(CommonUtil.isNotNull(configId)) {
			request.setConfigId(configId.trim());
		}
		if(CommonUtil.isNotNull(companyName)) {
			request.setCompanyName(companyName.trim());
		}
		if(CommonUtil.isNotNull(requestComment)) {
			request.setRequestComment(requestComment.trim());
		}
		
		try{
			request.setRequestTimeStamp(rs.getDate("REQUEST_TIMESTAMP"));
	    	DateFormat df = DateFormat.getDateInstance(DateFormat.LONG);
	        String dateString = df.format(rs.getDate("REQUEST_TIMESTAMP"));
			request.setRequestTimeStampString(dateString); // EMediaProfileHelper.convertTimeStampFromDate(requestTimeStamp);
			
		}
		catch(Exception e){
			_LOGGER.error("Inside GetEMediaRecreateRequestRowMapperImpl::setRequestTimeStamp failed "+e.getMessage());
		}
		return request;
	}
}
