package com.verizon.enterprise.ncasbosi.dao.Impl.payments;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.payments.*;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.*;
import com.verizon.enterprise.wisegate.ejb.WisegateCache;


public class PaymentsVZBBatchProcessor extends PaymentsBatchImpl implements NCASBOSIConstants,PaymentsBatchInterface {

	private static final Logger _LOGGER = Logger.getLogger(PaymentsVZBBatchProcessor.class);
	private static final double MIN_AMNT = 1.00;
	private static final double MAX_AMNT = 25000.00;
	private static final double INVALID_AMNT = 99.999999;

	public void createPayDetailsFromRecurring(RecurPayment item) throws NCASException
	{
		final String METHOD_NAME = "createPayDetailsFromRecurring => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		Map<String,String> eligibilityParams = null;
		String paymentStatus = NcasConstants.PAY_DETAILS_SCHEDULED_STATUS;
		paymentStatus = NcasConstants.PAY_DETAILS_SCHEDULED_STATUS;

				if(item!=null)
				{
					try{
							_LOGGER.info(METHOD_NAME + "PortalTrackId::" + item.getPortalTrackID());
							eligibilityParams = new HashMap<String,String>();
							eligibilityParams.put("userOid",Double.toString(item.getUserOID()));
							eligibilityParams.put("subscriptionOid",Double.toString(item.getSubscriptionOid()));
							eligibilityParams.put("loginId",item.getLoginId());
							PaymentProfile payProfile = (selectPaymentProfileDetails(item.getProfileID()).get("paymentProfile"));
							String profileStatus = payProfile.getProfileStatus();
							_LOGGER.info(METHOD_NAME + "The profile status for the profile ID::"+item.getProfileID()+"::is:"+profileStatus);
							boolean eligibleProfile = profileStatus.equalsIgnoreCase(NcasConstants.PROFILE_STATUS_ACTIVE);
							boolean eligibleUser = isUserEligible(eligibilityParams);
							_LOGGER.info(METHOD_NAME+"eligibleProfile:"+eligibleProfile);
							_LOGGER.info(METHOD_NAME+"eligibleUser:"+eligibleUser);
							if(eligibleProfile&&eligibleUser){
								Map<String,String> returnMap = getNextInvoiceDate(item.getLastInvoiceDate(),Double.toString(item.getSubscriptionOid()));
								String invDate = (returnMap.get("NEXT_BILL_DATE"));
								String invNumber = (returnMap.get("INVOICE_NBR"));
								_LOGGER.info(METHOD_NAME + " InvoiceDate is ::"+invDate);
								_LOGGER.info(METHOD_NAME + " InvoiceNumber is ::"+invNumber);
								if(invNumber!=null)
									invNumber = invNumber.trim();
									if((invDate!=null && !invDate.equals("")&& item.getLastInvoiceDate()!=null)&&
											((CommonUtil.compareDate(item.getNextPaymentDate(),item.getFirstPaymentDate(),"yyyy-MM-dd")==0)|| CommonUtil.compareDate(invDate,item.getLastInvoiceDate(),"yyyy-MM-dd")>0)){

											int payId = item.getPaymentID();
											double subscriptionOid = item.getSubscriptionOid();
											double realTimeBal = getRealTimeBalance(subscriptionOid,payId);

											_LOGGER.info(METHOD_NAME+"The real time balance for account::"+subscriptionOid+"::is::"+realTimeBal+"::");
											_LOGGER.info(METHOD_NAME+"The payment with ID ::"+payId+" :: is a RECURRING-PAYMENT");

											if(realTimeBal!=INVALID_AMNT){

													if(Double.compare(realTimeBal,MIN_AMNT)<0)
													{
														_LOGGER.info(METHOD_NAME+"The payment for the id :"+payId+": is not required since the payment amount is less than $1.00");
														paymentStatus = NcasConstants.PAY_DETAILS_PAY_NOT_REQ_STATUS;
													}
													/* sj July 2011 - comment this as there is no 25k limit anymore
													 * else if((item.getOrigSystemID().length() == 0 || item.getOrigSystemID().charAt(0) != 'M') && Double.compare(realTimeBal, MAX_AMNT)>0)
													{
														_LOGGER.info(METHOD_NAME+"The realTimeBal for the id :"+payId+": is greater than $25K. Payment fails as limit exceeded");
														_LOGGER.info(METHOD_NAME+"The PAYMENT_AMOUNT of PAYMENT_ID:"+payId+" is being updated to ::"+realTimeBal);
														paymentStatus = NcasConstants.PAY_DETAILS_FAILED_STATUS;
														_LOGGER.info(METHOD_NAME+"Payment Amount exceeded $25K : Payment updated with the proper error message");
													}*/

														//4.If it is a recurring payment, make sure the payment amount is not less than $1.00. If it is, update PL_PAY_DETAILS with Payment Not Required status
													RecurPaymentLinker recurLinker = createRecurLink(item,invDate,invNumber,realTimeBal,paymentStatus,payProfile);
													transferRecurPaymentDetails(recurLinker);
										}
									}

									else {
										_LOGGER.info(METHOD_NAME + " No Last Invoice - skip - " +invDate);
										//no invoice to pay on recur day of this month so Update the next payment date to next month's date. 
										int recurDay=item.getRecurDay();
										int recurPayId=item.getPaymentID();
										String recurPayDate=item.getNextPaymentDate();
										List<Integer> recurStatusList= new ArrayList<Integer>();
										recurStatusList.add(new Integer(recurPayId));
										updateRecurPaymentStatus(recurStatusList,NcasConstants.RECUR_PAY_SCHEDULED_STATUS,"",CommonUtil.getPaymentDateVZB(recurPayDate,recurDay),"","",NcasConstants.BATCH_VZB_RECUR);
									}
							}
							else{
									int pmntId = item.getPaymentID();
									String msg = "Inactive Payment Account";
									if(!eligibleUser)
										msg = "User unable to access Account";

									_LOGGER.info(METHOD_NAME + "For the payment"+pmntId+" login ::"+item.getLoginId()+"::unable to make this payment - serviceid : " + item.getServiceID()+ " :"+ msg);
									updateRecurPaymentStatus(pmntId,NcasConstants.RECUR_PAY_CANCEL_STATUS,"Cancelled::"+msg,"","",NcasConstants.BATCH_VZB_RECUR);
									_LOGGER.info(METHOD_NAME + " The Payment with ID -> "+pmntId+" has been cancelled because "+msg);
									insertPaymentEmail(item, item.getNickName(),REC_PMNT_DELETE_TEMPLATE_VZB,item.getLoginId(),METHOD_NAME,NcasConstants.EMAIL_CANCELLED,NcasConstants.BATCH_VZB_RECUR);
									_LOGGER.info(METHOD_NAME + " email entry has been created for this recur vzb cancellation scenario. Template that is being used is REC_PMNT_DELETE_TEMPLATE_VZB");
							}

					}
					catch(Exception e){
						_LOGGER.error(METHOD_NAME + " in NCASBOSI Failed - Inner Loop\n" +e.getMessage());
						throw new NCASException(PAYMENT_EXCEPTION_950,PaymentsVZBBatchProcessor.class,e);
						}
				}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public RecurPaymentLinker createRecurLink(RecurPayment item,String invDate,String invNumber,double realTimeBal,String paymentStatus,PaymentProfile payProfile) throws NCASException
	{
		final String METHOD_NAME = "createRecurLink => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		_LOGGER.info(METHOD_NAME+" Item:"+item.toString());
		_LOGGER.info(METHOD_NAME+":invDate:"+invDate+":invNumber:"+invNumber+":maskedAcct:"+payProfile.getMaskedAcctNum()+":nickName:"+payProfile.getNickName()+":realTimeBal:"+realTimeBal+":paymentStatus:"+paymentStatus);
		PaymentDetails payDetails = null;

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String paySubmitDate = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

		payDetails = new PaymentDetails(item.getPortalTrackID(),NcasConstants.PAYMENT_TYPE_RECURRING,item.getVzbVzwFlag(),item.getCustAcctNum(),item.getServiceID(),item.getOrigSystemID(),item.getProfileID(),paymentStatus,realTimeBal,realTimeBal,paySubmitDate,item.getCustomEmailAddr(),payProfile.getMaskedAcctNum(),payProfile.getNickName(),item.getUserOID(),item.getSubscriptionOid(),item.getLoginId(),paySubmitDate,paySubmitDate);
		payDetails.setInvoiceDate(invDate);
		payDetails.setInvoiceNum(invNumber);
		payDetails.setStateCode(item.getStateCode());
		payDetails.setPmntCurrency(item.getPmntCurrency());
		payDetails.setOpCode(item.getOpCode());
		//if block for lv2lv3 changes
		_LOGGER.info(METHOD_NAME+"::payment type:"+payProfile.getPaymentType()+"::vzbvzw flag:"+payDetails.getVzbVzwFlag()+"::pmnt currency:"+payDetails.getPmntCurrency());
		if((payProfile.getPaymentType().trim().equalsIgnoreCase(CREDIT_CARD_PAYMENT_TYPE)) && (payDetails.getVzbVzwFlag().trim().equalsIgnoreCase(VZB_VZW_FLAG_VZB)) && (payDetails.getPmntCurrency().trim().equalsIgnoreCase("USD"))){
			Map lv2Lv3Map=new HashMap();
			lv2Lv3Map=getLv2Lv3Data(Double.toString(item.getSubscriptionOid()), payProfile.getTypeCode(), invDate, invNumber);
			String temp=((BigDecimal)lv2Lv3Map.get("SALES_TAX_AMOUNT")).toString();
			String destZip=(String)lv2Lv3Map.get("DEST_ZIP");
			String salesTaxInd=(String)lv2Lv3Map.get("TAX_STATUS_IND");
			String destCountryCode=(String)lv2Lv3Map.get("DEST_COUNTRY_CODE");
			payDetails.setSalesTax(Double.parseDouble(temp));
			payDetails.setDestinationZip(destZip);
			payDetails.setSalesTaxIndicator(salesTaxInd);
			payDetails.setDestinationCountryCode(destCountryCode);
		}
		RecurPaymentLinker recurLinker = new RecurPaymentLinker(item.getPaymentID(),payDetails,item.getNextPaymentDate(),item.getRecurDay());
		_LOGGER.info(METHOD_NAME+" Exiting");
		return recurLinker;
	}
	public Double getRealTimeBalance(double subsOid,int payId) throws NCASException
	{
		final String METHOD_NAME = "getRealTimeBalance => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		_LOGGER.info(METHOD_NAME+"subsOid:"+subsOid+":payId:"+payId);
		Double retValue = 0.0;
		try{
			Map<String,Object> responseMap = getRealTimeBalance(Double.toString(subsOid));
			_LOGGER.info(METHOD_NAME+"Response Map:"+responseMap);
			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			_LOGGER.info(METHOD_NAME+"Return code:"+returnCode);
			if(returnCode==0)
			{
				retValue = ((BigDecimal)responseMap.get("REAL_TIME_BALANCE")).doubleValue();
				_LOGGER.info(METHOD_NAME+"Return value:"+retValue);
			}
			else{
				if(returnCode==3){
					updateRecurPaymentStatus(payId,NcasConstants.RECUR_PAY_CANCEL_STATUS,"Cancelled::REMIT_ACCT_IND CHANGE","","",NcasConstants.BATCH_VZB_RECUR);
					retValue = INVALID_AMNT;
				}
				else throw new Exception("Unable to retrieve real time balance:"+(String)responseMap.get("MSG_STRING"));
			}
		}catch(Exception vamEx) {
			_LOGGER.error("getRealTimeBalance Failed \n"+vamEx.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,PaymentsDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return retValue;
	}

	 public boolean isUserEligible(Map<String,String> eligibilityParams)throws NCASException{
			final String METHOD_NAME = "isUserEligible => ";
			_LOGGER.info(METHOD_NAME+" Entering");
		 boolean eligible = false;
		try{
			List acronyms = WisegateCache.getUserAcronyms(eligibilityParams.get("loginId"));
			_LOGGER.info(METHOD_NAME+"The acronyms list is:"+acronyms);
			eligible = NCASDataUtil.canPayVZB(acronyms);
			_LOGGER.info(METHOD_NAME+"The eligible from canPayVZB is:"+eligible);
			if(!eligible)
			{
				_LOGGER.info(METHOD_NAME+"Returning not eligible because the user cannot pay VZB");
				return eligible;
			}
			Map responseMap = isUserEligible(eligibilityParams.get("userOid"),eligibilityParams.get("subscriptionOid"));
			_LOGGER.info(METHOD_NAME+"Response Map:"+responseMap);
			if(((Integer)responseMap.get("RETURN_CODE")).intValue()==0){
				_LOGGER.info(METHOD_NAME+"Yes return code is 0");
				String isUserElig = (String)responseMap.get("ELIGABLE_FLAG");
				_LOGGER.info(METHOD_NAME+"isUserElig::"+isUserElig);
				if(eligible && isUserElig.equalsIgnoreCase("Y"))
				{
					eligible = true;
				}
				else{
					eligible = false;
				}
			}else{
				throw new Exception("Unable to confirm user eligibility:"+(String)responseMap.get("MSG_STRING"));
			}
		}catch(Exception vamEx) {
			_LOGGER.error("isUserEligible Failed \n"+vamEx.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,PaymentsDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"ELIGIBLE ->"+eligible);
		_LOGGER.info(METHOD_NAME+" Exiting");
		 return eligible;
	 }


}




