package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPCreateLineAdjustment extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPCreateLineAdjustment.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"ORIGINATOR_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BATCH_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"OUT_VAC_ADJUST_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPCreateLineAdjustment(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_CREATE_PORTAL_ADJ, spInOutList);
	}

	public Map executeStoredProcedure(String loginId, String vzid, String loginName, String firstName,
									String lastName, String middleName, String suffix,
									String batchId, String inputString, int noOfRows)throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(loginId);//ORIGINATOR_LOGINID
		paramValueList.add(vzid);//ORIGINATOR_VZID
		paramValueList.add(loginName);//ORIGINATOR_NAME
		paramValueList.add(firstName);//ORIGINATOR_FIRST
		paramValueList.add(lastName);//ORIGINATOR_LAST
		paramValueList.add(middleName);//ORIGINATOR_MID_IN
		paramValueList.add(suffix);//ORIGINATOR_SUFF

		//BATCH_ID
		if(batchId == null || batchId.trim().length() == 0)
		{
			paramValueList.add(null);
		}
		else
		{
			paramValueList.add(new BigDecimal(batchId.trim()));
		}

		paramValueList.add(inputString);//INPUT_STRING
		paramValueList.add(String.valueOf(noOfRows));//INPUT_ROWS

		Map procMap = (HashMap) executeStoredProcedure(paramValueList);

		int returnCode = ((Integer) procMap.get("RETURN_CODE")).intValue();
		String debugStr = (String) procMap.get("ERROR_TEXT");

		if (returnCode > 0)
		{
			String[] errMsg = new String[3];
			errMsg[0] = "SPCreateLineAdjustment";
			errMsg[2] = debugStr;

			throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg, returnCode);
		}

		Number outVacAdjustId = (Number) procMap.get("OUT_VAC_ADJUST_ID");
		int totalRows = ((Integer) procMap.get("TOTAL_ROWS")).intValue();

		_LOGGER.info("In SPCreateLineAdjustment: outVacAdjustId = " + outVacAdjustId);
		_LOGGER.info("In SPCreateLineAdjustment:      totalRows = " + totalRows);

		return procMap;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
