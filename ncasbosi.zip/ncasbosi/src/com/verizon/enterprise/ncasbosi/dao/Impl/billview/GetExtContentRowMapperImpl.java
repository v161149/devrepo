package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.BillViewConstants;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.PortalLinkDBConfig;
/*
				Scroll section is driven by the ROW_TYPE values.
				you would see the following in order for a typical page with
				3 detail lines, a total line, a legend line and 2 buttons

				TITLE
				DETAIL
				DETAIL
				DETAIL
				TOTAL
				LEGEND
				BUTTON
				BUTTON


				The ROW_TYPE values determine what the cell columns represent.
				Each scroll section cell has 10 columns to define it.
				.

				For(XX= 1 to whatever)
				COL_01_XX
				COL_02_XX
				COL_03_XX
				COL_04_XX
				COL_05_XX
				COL_06_XX
				COL_07_XX
				COL_08_XX =
				COL_09_XX =
				COL_10_XX =


				ROW_TYPE = "TITLE"

				COL_01_XX = LABEL
				COL_02_XX = TOOLTIP
				COL_03_XX = FMT
				COL_04_XX = TYPE
				COL_05_XX = META_NAME
				COL_06_XX = SORTABLE
				COL_07_XX = FILTERABLE
				COL_08_XX = (future)
				COL_09_XX = (future)
				COL_10_XX = (future)

				ROW_TYPE = "DETAIL" or "LEGEND" or "TOTAL"

				COL_01_XX = VALUE
				COL_02_XX = TOOLTIP
				COL_03_XX = FMT
				COL_04_XX = TYPE
				COL_05_XX = CURRENCY_CD
				COL_06_XX = L_TYPE
				COL_07_XX = TARGET_PAGE_ID
				COL_08_XX = TARGET_SUBSET
				COL_09_XX = TARGET_PARMS
				COL_10_XX = (future)

				ROW_TYPE = "BUTTON"

				COL_01_XX = LABEL
				COL_02_XX = TOOLTIP
				COL_03_XX = FMT
				COL_04_XX = TYPE
				COL_05_XX = CURRENCY_CD
				COL_06_XX = L_TYPE
				COL_07_XX = TARGET_PAGE_ID
				COL_08_XX = TARGET_SUBSET
				COL_09_XX = TARGET_PARMS
				COL_10_XX = (future)

				Buttons:
				These can be internal or external � same as standard link
				Can have multiple ROW_TYPE=�BUTTON�,  if multiple buttons are desired.
 *
 *
 */
public class GetExtContentRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger
			.getLogger(GetExtContentRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		if (_LOGGER.isDebugEnabled()) {
			_LOGGER.debug("Inside GetExtContentRowMapperImpl -> ");
		}
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Content content = new Content();
		ArrayList<ArrayList<Cell>> rows = new ArrayList<ArrayList<Cell>>();
		content.setRows(rows);
		ArrayList footer = new ArrayList();
		ArrayList actionButtonList = new ArrayList();
		content.setFooter(footer);
		content.setActionButtonList(actionButtonList);
		ArrayList<Cell> cellList = null;
		String lType = "";
		Cell cell;
		Link link;
		String rowType = "";
		String columnSuffix = "";
		String columnPrefix = "";
	    int count = rs.getMetaData().getColumnCount()-2;
	    count = count/BillViewConstants.NUMBER_ATTRS_COL;
	    boolean btnSet = false;
	    boolean skipCell = false;

		while (rs.next()) {

			cellList = new ArrayList<Cell>();
			String[] column = new String[BillViewConstants.NUMBER_ATTRS_COL];
			btnSet = false;
			rowType = rs.getString("ROW_TYPE").trim();
			for (int i = 0; i < count; i++) {
				columnSuffix = "_" + (i < 9 ? "0" : "")+ String.valueOf(i + 1);

				for(int j = 0; j < BillViewConstants.NUMBER_ATTRS_COL; j++) {
					columnPrefix = "_" + (j < 9 ? "0" : "")+ String.valueOf(j + 1);
					column[j] = rs.getString("COL"+columnPrefix+columnSuffix);
					if(column[j] == null) {
						column[j] = "";
					} else if(column[0].isEmpty()) {
						  skipCell = true;
						  break;
					}
				}

				if(!skipCell){
					for(int j = 0; j < BillViewConstants.NUMBER_ATTRS_COL; j++) {
						if (column[j] != null) { //should never be
						  column[j] = column[j].trim();
						}
					}
					cell = new Cell();
					cell.setToolTip(column[1].trim());
					cell.setFormat(column[2]);
					cell.setType(column[3]);
					if(rowType.equalsIgnoreCase("TITLE")){
						cell.setName(column[4]);
						cell.setValue(column[0]);
						cell.setFilterAble(column[6]);
					    cell.setSortAble(column[5]);
					}else{
								cell.setValue(CommonUtil.getFormattedDisplayValue(column[3], column[2],  column[0], column[4], false));
								lType = column[5];
								if (lType !=null && lType.length() > 0 && !lType.startsWith("NOLNK")){
								    link = new Link();
								    link.setPageId(column[6]);
								    link.setPageSubset(column[7]);
								    link.setLinkParam(PortalLinkDBConfig.getInstance().getExternalLink(lType, column[8]));
								    if(column[9]!=null && !column[9].isEmpty()){
								    	link.setFilterString(column[9]);
								    	link.setFiltersortMsg("Auto Filter Applied");
								    }
								    cell.setLink(link);
								}
								cell.setLnkType(lType);
								cell.setCurrencyCode(column[4]);
					}

					if(rowType.equalsIgnoreCase("LEGEND"))
						footer.add(cell);
					else if (rowType.equalsIgnoreCase("BUTTON")){
						if(!btnSet){
							actionButtonList.add(cell);
							btnSet = true;
						}
					}
					else cellList.add(cell);
				}
				skipCell = false;
			}
			if(rowType.equalsIgnoreCase("DETAIL")||rowType.equalsIgnoreCase("TITLE")||rowType.equalsIgnoreCase("TOTAL")	)
				rows.add(cellList);
		}
		return content;
	}



}