package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
/**
 * @author v898809
 *  Reusing the DownloadSecabsAcctsByServiceRowMapperImpl class 
 * This class is the resultset extractor for the vam SP: SUMMARY_SECABS_V10
 * and is the callback class for SPDownloadSecabsSummary.
 * This is used when downloading Secabs summary
 * 
 */
public class DownloadSecabsSummaryRowMapperImpl extends DownloadSecabsAcctsByServiceRowMapperImpl {
	
	private static final Logger _LOGGER = Logger.getLogger(DownloadSecabsSummaryRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Start DownloadSecabsSummaryRowMapperImpl -> ");
		Object outputObj = super.extractData(rs);
		_LOGGER.info("End DownloadSecabsSummaryRowMapperImpl -> ");
		return outputObj;
	}
}


