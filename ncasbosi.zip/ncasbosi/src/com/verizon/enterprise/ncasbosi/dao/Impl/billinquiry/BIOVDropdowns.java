package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.billinquiry.BICategory;
import com.verizon.enterprise.common.ncas.domain.SelectOption;


public class BIOVDropdowns implements RowMapper {
      private static final Logger _LOGGER = Logger.getLogger(BIOVDropdowns.class);
      private String biCategory;//category passed from SPGetBIDropdown to determine whether to populate status in Billinquiry crititeria page
      public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        BICategory BIOVCategoryObj = new BICategory();
        SelectOption selOpt = null;
        if(rs != null) {

		//populating the bicatgeory
			_LOGGER.info("biCategory::"+biCategory);
		  if(NcasConstants.BI_CATEGORY.equalsIgnoreCase(biCategory)) {
				BIOVCategoryObj.setCategorycode(rs.getString("CATEGORY_CODE"));
				_LOGGER.info("CATEGORY_CD = "+BIOVCategoryObj.getCategorycode());
				BIOVCategoryObj.setCategorydesc(rs.getString("CATEGORY_DESC"));
				_LOGGER.info("CATEGORY_DESC = "+BIOVCategoryObj.getCategorydesc());
				BIOVCategoryObj.setSubcatcode(rs.getString("DROP_DOWN_CODE"));
				_LOGGER.info("SUB_CAT_CD = "+BIOVCategoryObj.getSubcatcode());
				BIOVCategoryObj.setSubcatdesc(rs.getString("DROP_DOWN_VALUE"));
				_LOGGER.info("SUB_CAT_DESC = "+BIOVCategoryObj.getSubcatdesc());
		  } else {
				String name= null;
				String value= null;
				if (rs != null) {
				   name = rs.getString("DROP_DOWN_VALUE");
				   value = rs.getString("DROP_DOWN_CODE");
					selOpt = new SelectOption(name, value);
					_LOGGER.info("Select Option Name " + name + ",  Value "	+ value);
				}
			}
        }
        if(NcasConstants.BI_CATEGORY.equalsIgnoreCase(biCategory)) {
        	return BIOVCategoryObj;
	    } else {
        	return selOpt;
	    }
      }

    public String getBiCategory() {
		return biCategory;
	}
	public void setBiCategory(String biCategory) {
		this.biCategory = biCategory;
	}

  }