package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import javax.sql.DataSource;
import java.sql.*;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

import com.verizon.enterprise.common.ncas.approval.Designation;

public class VBIFUpdateDesignation extends SqlUpdate{
	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	
	public VBIFUpdateDesignation(DataSource dataSource,String sql) {
		super(dataSource, sql);		
		declareParametersForBusDays();//this is for type safety
		compile();		
	}
	
	private void declareParametersForBusDays(){
		declareParameter(new SqlParameter("START_DATE",Types.DATE));
		declareParameter(new SqlParameter("END_DATE",Types.DATE));
		declareParameter(new SqlParameter("LAST_UPDATED_BY",Types.VARCHAR));
		declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP",Types.TIMESTAMP));
		declareParameter(new SqlParameter("DESIGNATOR_VZID",Types.VARCHAR));
		declareParameter(new SqlParameter("APPROVER_VZID",Types.VARCHAR));
	}
	
	public int updateDesignation(Designation designationInfo) throws Exception{	
		String METHOD_NAME="VBIFUpdateDesignation->updateDesignation::";
		_LOGGER.info(METHOD_NAME+this.getSql());
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String createdTimestamp = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
		
		Object[] params = new Object[]{designationInfo.getUserDelegation().getStartDate(), designationInfo.getUserDelegation().getEndDate(),
				designationInfo.getUserDelegation().getLastUpdatedBy(),createdTimestamp,
				designationInfo.getUserDelegation().getDesignatorVZID(),designationInfo.getUserDelegation().getApproverVZID()};
		return this.update(params);
	}
}