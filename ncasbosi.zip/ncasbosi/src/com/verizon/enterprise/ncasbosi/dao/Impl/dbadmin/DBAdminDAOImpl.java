package com.verizon.enterprise.ncasbosi.dao.Impl.dbadmin;

import java.sql.PreparedStatement;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.dbadmin.DBAdminInterface;
import com.verizon.enterprise.ncasbosi.dao.Impl.dbadmin.DBAdminUtil;
import com.verizon.enterprise.ncasbosi.dao.Impl.status.GetScheduledReportsRowMapperImpl;
import com.verizon.enterprise.common.ncas.BillViewConstants;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.verizon.enterprise.common.ncas.display.Page;
import com.verizon.enterprise.common.ncas.display.DbAdminInfo;
import com.verizon.enterprise.common.ncas.display.PageContent;
import com.verizon.enterprise.common.ncasbosi.beans.LeftNav;
import com.verizon.enterprise.common.ncasbosi.beans.BreadCrumb;
import com.verizon.enterprise.common.ncasbosi.beans.AdminPage;
import com.verizon.enterprise.common.ncasbosi.beans.XrefSql;
import com.verizon.enterprise.common.ncasbosi.beans.Legend;
import com.verizon.enterprise.common.ncasbosi.beans.Scroll;
import com.verizon.enterprise.common.ncasbosi.beans.Header;
import com.verizon.enterprise.common.ncas.reports.RptCntl;
import com.verizon.enterprise.common.ncasbosi.beans.SystemParam;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import java.sql.Connection;


import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Date;
import java.util.LinkedHashMap;


import javax.sql.DataSource;

import com.verizon.enterprise.common.ncas.NcasConstants;

public class DBAdminDAOImpl extends NCASSpringJDBCBase implements DBAdminInterface, NCASBOSIConstants {

	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	private SqlUpdate insertBillViewSqlUpdate = null;
	private SqlUpdate insertBillViewMarkupSqlUpdate = null;
	private SqlUpdate insertBillViewMethodSqlUpdate = null;
	private SqlUpdate insertRptCntlDet = null;
	private SqlUpdate updateRptCntlDet = null;
	private SqlUpdate deleteRptCntlDet = null;

	private SqlUpdate insertSystemParms = null;
	private SqlUpdate updateSysParmsDet = null;
	private SqlUpdate deleteSystemParmsDet = null;
	

	private SqlUpdate updateBillViewTypeSqlUpdate = null;
	private SqlUpdate updateBillViewMarkupSqlUpdate = null;
	private SqlUpdate updateBillViewMethodSqlUpdate = null;

	private SqlUpdate deleteBillViewTypeSqlUpdate = null;
	private SqlUpdate deleteBillViewMarkupSqlUpdate = null;
	private SqlUpdate deleteBillViewExtLinkSqlUpdate = null;
	private SqlUpdate deleteBillViewMethodSqlUpdate = null;

	private BatchSqlUpdate insertLeftNavsDefSqlUpdate = null;
	private BatchSqlUpdate insertLeftNavsSqlUpdate = null;
	private SqlUpdate updateLeftNavsDefSqlUpdate = null;
	private BatchSqlUpdate updateLeftNavsSqlUpdate = null;
	private BatchSqlUpdate updateLinkOrderSqlUpdate = null;
	private SqlUpdate deleteLeftNavSqlUpdate = null;
	private SqlUpdate deleteLeftNavRefSqlUpdate = null;
	private SqlUpdate deleteLeftNavFromPageSqlUpdate = null;
	private SqlUpdate deleteAllLeftNavFromPageSqlUpdate	= null;
	private BatchSqlUpdate insertBreadCrumbSqlUpdate = null;
	private BatchSqlUpdate updateBreadCrumbsSqlUpdate = null;
	private BatchSqlUpdate updateBreadCrumbLinkSqlUpdate = null;
	private SqlUpdate deleteBreadCrumbSqlUpdate = null;
	private SqlUpdate insertReferenceSqlUpdate = null;
	private SqlUpdate updateReferenceSqlUpdate = null;
	private SqlUpdate deleteReferenceSqlUpdate = null;
	private BatchSqlUpdate insertAdminPageSqlUpdate = null;
	private SqlUpdate updateAdminPageSqlUpdate = null;
	private SqlUpdate deleteAdminPageSqlUpdate = null;
	private SqlUpdate deleteAdminPageSectionSqlUpdate = null;
	private BatchSqlUpdate insertSqlTableSqlUpdate = null;
	private SqlUpdate updateSqlTableSqlUpdate = null;
	private SqlUpdate deleteSqlTableSqlUpdate = null;
	private BatchSqlUpdate updateHeaderLinkSqlUpdate = null;
	private BatchSqlUpdate insertHeaderXrefSqlUpdate = null;
	private SqlUpdate updateHeaderXrefSqlUpdate = null;
	private SqlUpdate deleteHeaderXrefSqlUpdate = null;
	private SqlUpdate deleteHeaderElementXrefSqlUpdate = null;
	private SqlUpdate insertTargetParmsSqlUpdate = null;
	private SqlUpdate updateTargetParmsSqlUpdate = null;
	private SqlUpdate deleteTargetParmsSqlUpdate = null;
	private SqlUpdate insertXrefSqlUpdate = null;
	private SqlUpdate updateXrefSqlUpdate = null;
	private SqlUpdate deleteXrefSqlUpdate = null;
	private BatchSqlUpdate insertLegendSqlUpdate = null;
	private SqlUpdate updateLegendSqlUpdate = null;
	private SqlUpdate deleteLegendPageSqlUpdate = null;
	private SqlUpdate deleteLegendPageSectionSqlUpdate = null;
	private BatchSqlUpdate insertScrollSqlUpdate = null;
	private SqlUpdate updateScrollSqlUpdate = null;
	private SqlUpdate deleteScrollSqlUpdate = null;
	private SqlUpdate deleteScrollCursorSqlUpdate = null;
	private BatchSqlUpdate updateScrollCursorLinkSqlUpdate = null;
	private SqlUpdate deleteCacheSqlUpdate = null;
	private SqlUpdate deleteScrollCursorColSqlUpdate = null;
	private BatchSqlUpdate updateCursorColNbrSqlUpdate = null;
	//private SqlUpdate insertPLTableSqlUpdate = null;
	//private SqlUpdate deletePLTableSqlUpdate = null;

	static private final Logger _LOGGER = Logger.getLogger(DBAdminDAOImpl.class);

	public Map selectBillViewType(DbAdminInfo  dbAdminInfo) throws NCASException {
		final List responseList = new ArrayList();
		final Map responseMap = new HashMap();
		String SELECT_BILL_VIEW_TYPE = "SELECT PAGE_ID, TYPE , TRACK_NAME, BRD_MKUP , LFT_MKUP , LFT_TBSIZE, HDR_MKUP , HDR_TBSIZE, ACTION_CLS, STRUCT_TYPE, CT0_MKUP, CT0_TBSIZE, CT0_PAGINATE,  CT1_MKUP, CT1_TBSIZE, CT1_PAGINATE, CT2_MKUP, CT2_TBSIZE, CT2_PAGINATE, CT3_MKUP, CT3_TBSIZE, CT3_PAGINATE, CT4_MKUP, CT4_TBSIZE, CT4_PAGINATE, CT5_MKUP , CT5_TBSIZE, CT5_PAGINATE, CT6_MKUP, CT6_TBSIZE, CT6_PAGINATE, CT7_MKUP, CT7_TBSIZE, CT7_PAGINATE, CT8_MKUP, CT8_TBSIZE, CT8_PAGINATE, CT9_MKUP, CT9_TBSIZE, CT9_PAGINATE, CT10_MKUP, CT10_TBSIZE, CT10_PAGINATE, CT11_MKUP, CT11_TBSIZE, CT11_PAGINATE, PAGE_ATTR , TRACK_ATTR, HELP_STR    FROM " + getSchemaName() + ".PL_BVIEW_TYPE";
		String whereClause = "";

		String pagekey = dbAdminInfo.getName();

		if(pagekey!=null && !pagekey.equals("")){
			String pageAttr = NCASDataUtil.getPageAttrFromPageKey(pagekey);
			String pageId = NCASDataUtil.getPageIDFromPageKey(pagekey);
			if(Integer.parseInt(pageId) > 0) {
				whereClause = " WHERE PAGE_ID = " + pageId;
				if(pageAttr!=null && !pageAttr.equals(""))
					whereClause += " AND PAGE_ATTR = '" + pageAttr + "'";
			}
		}

		if(CommonUtil.isNotNull(whereClause)) {
			SELECT_BILL_VIEW_TYPE = SELECT_BILL_VIEW_TYPE + whereClause;
		}

		_LOGGER.info("Select SQL: " + SELECT_BILL_VIEW_TYPE);

		try
		{
			jdbcTemplate.query(SELECT_BILL_VIEW_TYPE, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String key = rs.getString("PAGE_ID");
					String type = rs.getString("TYPE");
					String track = rs.getString("TRACK_NAME");
					String trackAttr = rs.getString("TRACK_ATTR");
					String brdMkp = rs.getString("BRD_MKUP");
					String lftMkp = rs.getString("LFT_MKUP");
					String lftSize = rs.getString("LFT_TBSIZE");
					String hdrMkp = rs.getString("HDR_MKUP");
					String hdrSize = rs.getString("HDR_TBSIZE");
					String asyncclass = rs.getString("ACTION_CLS");
					String structType = rs.getString("STRUCT_TYPE");
					String pageAttr = rs.getString("PAGE_ATTR");
					String helpStr = rs.getString("HELP_STR");

					List contentList = new ArrayList();
					String columnPrefix = "";
					for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
						columnPrefix = "CT"+ String.valueOf(i);
						contentList.add(new PageContent(rs.getString(columnPrefix+"_TBSIZE"),rs.getString(columnPrefix+"_PAGINATE"),rs.getString(columnPrefix+"_MKUP")));
					}
					responseList.add(new Page(brdMkp,lftMkp,hdrMkp,contentList,type,lftSize,hdrSize,track,asyncclass,structType,trackAttr,helpStr));
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("SelectBillViewType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SelectBillViewType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectBillViewType");
		responseMap.put("file",responseList);
		return responseMap;
	}

	public Map selectBillViewMarkup(DbAdminInfo  dbAdminInfo) throws NCASException {
		final Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String SELECT_BILL_VIEW_MARKUP = "SELECT NAME, MARKUP, TYPE, MKUP_DFLT FROM " + getSchemaName() + ".PL_BVIEW_MARKUP";
		//String SELECT_BILL_VIEW_MARKUP = "SELECT NAME, MARKUP FROM " + getSchemaName() + ".PL_BVIEW_MARKUP";
		String whereClause = "";
		if(CommonUtil.isNotNull(name) && !name.trim().equals("")) {
			whereClause = " WHERE NAME = '" + name + "'";
		}

		if(CommonUtil.isNotNull(whereClause)) {
			SELECT_BILL_VIEW_MARKUP = SELECT_BILL_VIEW_MARKUP + whereClause;
		}

		_LOGGER.info("Select SQL: " + SELECT_BILL_VIEW_MARKUP);

		try
		{
			jdbcTemplate.query(SELECT_BILL_VIEW_MARKUP, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					String key = rs.getString("NAME");
					String markup = rs.getString("MARKUP");
					String type = rs.getString("TYPE");
					String defaultFlag = rs.getString("MKUP_DFLT");
					responseMap.put("name",key);
					responseMap.put("markup",markup);
					responseMap.put("type",type);
					responseMap.put("defaultFlag",defaultFlag);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("SelectBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SelectBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectBillViewMarkup");

		return responseMap;
	}

	public Map adminDropDowns() throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String ALL_ADMIN_DROP_DOWN =  "(SELECT RTRIM(CHAR(TB2.PAGE_ID))||'_'||CHAR(TB2.PAGE_ATTR),CHAR(TB2.TYPE), '','', ''  FROM "+ getSchemaName() +".PL_BVIEW_TYPE TB2) UNION ALL (SELECT '', '', TB3.NAME, TB3.TYPE,'' FROM " + getSchemaName() +".PL_BVIEW_MARKUP TB3) UNION (SELECT  '', '', '', '', TB4.NAME FROM "  + getSchemaName() +".PL_BVIEW_METHOD TB4)";

		_LOGGER.info("Admin Drop Down SQL: " + ALL_ADMIN_DROP_DOWN);
		try
		{
			jdbcTemplate.query(ALL_ADMIN_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					totalList.add(list);
				}
			});
			Collections.sort(totalList, new Comparator (){
				 public int compare(Object o1, Object o2) {
					 if( !(((List)o1).get(0).toString().equals(""))&& !(((List)o2).get(0).toString().equals("")) ){
						 int val1 = Integer.parseInt(NCASDataUtil.getPageIDFromPageKey(((List)o1).get(0).toString().trim()));
					     int val2 = Integer.parseInt(NCASDataUtil.getPageIDFromPageKey(((List)o2).get(0).toString().trim()));
					     return (val1<val2 ? -1 : (val1==val2 ? 0 : 1));
					 }else {
						 return 0;
					 }
				      }
            } );
			responseMap.put("drop_down",totalList);
			_LOGGER.info("Exiting adminDropDowns");
		} catch(Exception vamEx) {
			_LOGGER.debug("adminDropDowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("adminDropDowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("responseMap"+ responseMap.size());
		_LOGGER.info("responseMap"+ responseMap);
		return responseMap;
	}

	public Map selectBillViewMethod(DbAdminInfo  dbAdminInfo) throws NCASException {
		final Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String SELECT_BILL_VIEW_METHOD = "SELECT NAME, VERSION, METHOD, LAST_UPDATED, LAST_UPDATED_BY FROM " + getSchemaName() + ".PL_BVIEW_METHOD";
		String whereClause = "";
		boolean appendAnd = false;

		if(CommonUtil.isNotNull(name) && !name.trim().equals("")) {
			List includes = NCASDataUtil.getBillViewIncludes(name);
			Iterator iter = includes.iterator();
			whereClause = " WHERE NAME IN (";
			while (iter.hasNext()){
				whereClause += "'" + (String) iter.next() + "'";
				if(iter.hasNext())
					whereClause += "," ;
			}
			whereClause += ")" ;
			appendAnd = true;
		}

		String orderBy = " ORDER BY NAME, VERSION";

		if(CommonUtil.isNotNull(whereClause)) {
			SELECT_BILL_VIEW_METHOD = SELECT_BILL_VIEW_METHOD + whereClause + orderBy;
		}

		_LOGGER.info("Select SQL: " + SELECT_BILL_VIEW_METHOD);

		try
		{
			jdbcTemplate.query(SELECT_BILL_VIEW_METHOD, new RowCallbackHandler() {
				String key = "";   //holds the name of the method, ex STATIC
				String value = ""; //holds the entire .js
				String method = ""; //holds a fragment of the .js, if js less than 32k will hold the entire js.
				String priorKey = "zzz"; //initialze prior key
				//read methods, the max size of a db2 row is 32k, methods can be larger than that.
				// if method is more than 32k it will be written to multiple rows with the same NAME,
				// the version column is uses a a sequence column, version is not a good name for the col, should be sequence.
				public void processRow(ResultSet rs) throws SQLException {
					//read the next row into values
					key = rs.getString("NAME");
					method = rs.getString("METHOD");
					
					//if we got a new row with same name cat the method, else we got a new js name so write out the old one
					if (key.equals(priorKey))
					{
						value = value + method;
					}
					else
					{
						responseMap.put(key,value);
						value = method;
						priorKey = key;
						
					}
					responseMap.put(key,value);  //handles the last row
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("SelectBillViewMethod in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SelectBillViewMethod in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectBillViewMethod");

		return responseMap;
	}

	public Map getAllPageType() throws NCASException {
		final Map responseMap = new HashMap();
		String SELECT_ALL_PAGE_TYPE = "SELECT PAGE_ID, TYPE , TRACK_NAME, BRD_MKUP , LFT_MKUP , LFT_TBSIZE, HDR_MKUP , HDR_TBSIZE , ACTION_CLS, STRUCT_TYPE, CT0_MKUP, CT0_TBSIZE, CT0_PAGINATE,  CT1_MKUP,  CT1_TBSIZE, CT1_PAGINATE, CT2_MKUP,  CT2_TBSIZE, CT2_PAGINATE, CT3_MKUP,  CT3_TBSIZE, CT3_PAGINATE, CT4_MKUP, CT4_TBSIZE, CT4_PAGINATE, CT5_MKUP ,  CT5_TBSIZE, CT5_PAGINATE, CT6_MKUP,  CT6_TBSIZE, CT6_PAGINATE, CT7_MKUP, CT7_TBSIZE, CT7_PAGINATE, CT8_MKUP, CT8_TBSIZE, CT8_PAGINATE, CT9_MKUP, CT9_TBSIZE, CT9_PAGINATE, CT10_MKUP,  CT10_TBSIZE, CT10_PAGINATE, CT11_MKUP, CT11_TBSIZE, CT11_PAGINATE, PAGE_ATTR, TRACK_ATTR, HELP_STR FROM " + getSchemaName() + ".PL_BVIEW_TYPE";

		_LOGGER.info("Select SQL: " + SELECT_ALL_PAGE_TYPE);
		try
		{
			jdbcTemplate.query(SELECT_ALL_PAGE_TYPE, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String key = rs.getString("PAGE_ID");
					String type = rs.getString("TYPE");
					String track = rs.getString("TRACK_NAME");
					String trackAttr = rs.getString("TRACK_ATTR");
					String brdMkp = rs.getString("BRD_MKUP");
					String lftMkp = rs.getString("LFT_MKUP");
					String lftSize = rs.getString("LFT_TBSIZE");
					String hdrMkp = rs.getString("HDR_MKUP");
					String hdrSize = rs.getString("HDR_TBSIZE");
					String asyncclass = rs.getString("ACTION_CLS");
					String structType = rs.getString("STRUCT_TYPE");
					String pageAttr = rs.getString("PAGE_ATTR");
					String helpStr = rs.getString("HELP_STR");

					List contentList = new ArrayList();
					String columnPrefix = "";
					for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
						columnPrefix = "CT"+ String.valueOf(i);
						contentList.add(new PageContent(rs.getString(columnPrefix+"_TBSIZE"),rs.getString(columnPrefix+"_PAGINATE"),rs.getString(columnPrefix+"_MKUP")));
					}
					responseMap.put(NCASDataUtil.getPageKey(key, pageAttr),new Page(brdMkp,lftMkp,hdrMkp,contentList,type,lftSize,hdrSize,track,asyncclass,structType,trackAttr,helpStr));
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("GetAllPageType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetAllPageType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getAllPageType");

		return responseMap;
	}
	public Map getAllMarkup() throws NCASException {
		final Map responseMap = new LinkedHashMap();
		String SELECT_ALL_MARKUP = "SELECT NAME, MARKUP FROM " + getSchemaName() + ".PL_BVIEW_MARKUP ORDER BY NAME ASC";
		_LOGGER.info("Select SQL: " + SELECT_ALL_MARKUP);

		try
		{
			jdbcTemplate.query(SELECT_ALL_MARKUP, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String key = rs.getString("NAME");
					String value = rs.getString("MARKUP");
					responseMap.put(key,value);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("SelectBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SelectBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}

		_LOGGER.info("Exiting getAllMarkup");
		return responseMap;
	}

	public Map selectAllButtons() throws NCASException {
		final Map responseMap = new HashMap();
		 String SELECT_ALL_BUTTONS = "SELECT NAME,PAGE_ID,PAGE_ATTR,CONTENT_ID FROM "+getSchemaName()+".PL_BTN  ORDER BY BTN_ORDER ASC";
		 _LOGGER.info("Select SQL: " + SELECT_ALL_BUTTONS);

			try
			{
				jdbcTemplate.query(SELECT_ALL_BUTTONS, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						String name = rs.getString("NAME");
						String pageId = rs.getString("PAGE_ID");
						String pageAttr = rs.getString("PAGE_ATTR");
						int contentId = rs.getInt("CONTENT_ID");
					      String btnKey = NCASDataUtil.getButtonKey(pageId,pageAttr,String.valueOf(contentId));
					      List btnNameList = (List)responseMap.get(btnKey);
					      if(btnNameList==null)
					    	  btnNameList = new ArrayList();
					      btnNameList.add(name);

						responseMap.put(btnKey,btnNameList);
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("SelectBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("SelectBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}

			_LOGGER.info("Exiting getAllMarkup");
			return responseMap;
		}


	public int getNumInRange(int min, int max, String colName, String tblName) throws NCASException {
		final int responseArr[] = new int[max-min];
		int RandomNumber = 0;
		String ALL_RANGE_NUMBERS = "SELECT "+ colName +"  FROM " + getSchemaName()+""+tblName + " WHERE  "+ colName +"  BETWEEN " + min + "  AND " + max +"";
		_LOGGER.info("Select SQL: " + ALL_RANGE_NUMBERS);

		try
		{
			jdbcTemplate.query(ALL_RANGE_NUMBERS, new RowCallbackHandler() {
				int rowCount = -1 ;
				public void processRow(ResultSet rs) throws SQLException {
					rowCount = rowCount + 1;
					responseArr[rowCount] = rs.getInt("LEFT_NAV_NBR");
				}
			});
			RandomNumber = DBAdminUtil.randomNumberGenerator(min, max, responseArr);
		} catch(Exception vamEx) {
			_LOGGER.debug("getNumInRange in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getNumInRange in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}

		_LOGGER.info("Exiting getNumInRange");
		return RandomNumber;
	}
	public Map insertBillViewType(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String userId =dbAdminInfo.getUserId();
		int pageId = Integer.parseInt(dbAdminInfo.getName());
		String pageAttr =dbAdminInfo.getPageAttr();
		_LOGGER.info("PAGE ATTRIBUTE: " + pageAttr);

		Page page = dbAdminInfo.getPage();
		String INSERT_BILL_VIEW_TYPE = "INSERT INTO " + getSchemaName() + ".PL_BVIEW_TYPE( PAGE_ID, TYPE, TRACK_NAME, LAST_UPDATED, LAST_UPDATED_BY, BRD_MKUP , LFT_MKUP , LFT_TBSIZE, HDR_MKUP , HDR_TBSIZE , ACTION_CLS, STRUCT_TYPE, CT0_MKUP, CT0_BTNGRP, CT0_TBSIZE, CT0_PAGINATE,  CT1_MKUP, CT1_BTNGRP, CT1_TBSIZE, CT1_PAGINATE, CT2_MKUP, CT2_BTNGRP, CT2_TBSIZE, CT2_PAGINATE, CT3_MKUP, CT3_BTNGRP, CT3_TBSIZE, CT3_PAGINATE, CT4_MKUP,CT4_BTNGRP, CT4_TBSIZE, CT4_PAGINATE, CT5_MKUP , CT5_BTNGRP, CT5_TBSIZE, CT5_PAGINATE, CT6_MKUP, CT6_BTNGRP, CT6_TBSIZE, CT6_PAGINATE, CT7_MKUP, CT7_BTNGRP, CT7_TBSIZE, CT7_PAGINATE, CT8_MKUP, CT8_BTNGRP, CT8_TBSIZE, CT8_PAGINATE, CT9_MKUP, CT9_BTNGRP, CT9_TBSIZE, CT9_PAGINATE, CT10_MKUP, CT10_BTNGRP, CT10_TBSIZE, CT10_PAGINATE, CT11_MKUP,CT11_BTNGRP, CT11_TBSIZE, CT11_PAGINATE, PAGE_ATTR, TRACK_ATTR,HELP_STR) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";


		_LOGGER.info("Insert SQL: " + INSERT_BILL_VIEW_TYPE);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			if(insertBillViewSqlUpdate == null) {
				insertBillViewSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_BILL_VIEW_TYPE);
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("TRACK_NAME", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("BRD_MKUP", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("LFT_MKUP", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("LFT_TBSIZE", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("HDR_MKUP", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("HDR_TBSIZE", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("ACTION_CLS", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("STRUCT_TYPE", Types.VARCHAR));

				String columnPrefix = "";
				for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
					columnPrefix = "CT"+ String.valueOf(i);
					insertBillViewSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_MKUP", Types.VARCHAR));
					insertBillViewSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_BTNGRP", Types.VARCHAR));
					insertBillViewSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_TBSIZE", Types.VARCHAR));
					insertBillViewSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_PAGINATE", Types.VARCHAR));
				}
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("PAGE_ATTR", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("TRACK_ATTR", Types.VARCHAR));
				insertBillViewSqlUpdate.declareParameter(new SqlParameter("HELP_STR", Types.VARCHAR));
				insertBillViewSqlUpdate.compile();
			}


			Object[] parameterValues = new Object[BillViewConstants.NUMBER_CONTENT*4+15];
			parameterValues[0] = String.valueOf(pageId);
			parameterValues[1] = page.getType();
			parameterValues[2] = page.getTrack();
			parameterValues[3] = lastUpdated;
			parameterValues[4] = userId;
			parameterValues[5] = page.getBcrumb();
			parameterValues[6] = page.getLeftNav();
			parameterValues[7] = page.getLeftNavSize();
			parameterValues[8] = page.getHeader();
			parameterValues[9] = page.getHeaderSize();
			parameterValues[10] = page.getAsyncclass();
			parameterValues[11] = page.getStructType();
			for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
				parameterValues[12+(i*4)] = page.getContent(String.valueOf(i));
				parameterValues[13+(i*4)] = "";//page.getBtnGroup(String.valueOf(i));
				parameterValues[14+(i*4)] = page.getTableWidth(String.valueOf(i));
				parameterValues[15+(i*4)] = page.getPaginate(String.valueOf(i));
			}
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+12] = pageAttr;
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+13] = page.getTrackAttr();
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+14] = page.getHelpStr();
			int insCount = insertBillViewSqlUpdate.update(parameterValues);

			if(insCount > 0)
			{
				_LOGGER.info("Insert BillViewType Response logged successfully \n Number of Records inserted - "+insCount);
				status = true;
			}
		} catch(Exception vamEx) {
			_LOGGER.debug("InsertBillViewType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("InsertBillViewType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertBillViewType");
		 responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	public Map insertBillViewMarkup(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String userId=dbAdminInfo.getUserId();
		String name=dbAdminInfo.getName();
		String temp=dbAdminInfo.getFunction();
		String markup = "";
		if(temp != null || temp != "")
			markup = temp.replaceAll("\\p{Cntrl}+", "");

		//_LOGGER.info("MARKUP --->: " + markup);

		String type=dbAdminInfo.getType();
		String defaultFlag=dbAdminInfo.getDefaultFlag();
		String INSERT_BILL_VIEW_MARKUP = "INSERT INTO " + getSchemaName() + ".PL_BVIEW_MARKUP(NAME, MARKUP, TYPE, MKUP_DFLT, LAST_UPDATED, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_BILL_VIEW_MARKUP);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			if(insertBillViewMarkupSqlUpdate == null) {
				insertBillViewMarkupSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_BILL_VIEW_MARKUP);
				insertBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				insertBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("MARKUP", Types.VARCHAR));
				insertBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				insertBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("MKUP_DFLT", Types.CHAR));
				insertBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertBillViewMarkupSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{name, markup, type, defaultFlag, lastUpdated, userId};

			int insCount = insertBillViewMarkupSqlUpdate.update(parameterValues);

			if(insCount > 0)
			{
				_LOGGER.info("Insert BillViewMarkup Response logged successfully \n Number of Records inserted - "+insCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("InsertBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("InsertBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertBillViewMarkup");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map insertBillViewMethod(DbAdminInfo  dbAdminInfo) throws NCASException {
		final Map responseMap = new HashMap();
		boolean status = false;
		String userId=dbAdminInfo.getUserId();
		String name=dbAdminInfo.getName();
		String method=dbAdminInfo.getFunction();
		String version = "1.1";
		String INSERT_BILL_VIEW_METHOD = "INSERT INTO " + getSchemaName() + ".PL_BVIEW_METHOD(NAME, VERSION, METHOD, LAST_UPDATED, LAST_UPDATED_BY) VALUES(?,?,?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_BILL_VIEW_METHOD);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			if(insertBillViewMethodSqlUpdate == null) {
				insertBillViewMethodSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_BILL_VIEW_METHOD);
				insertBillViewMethodSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				insertBillViewMethodSqlUpdate.declareParameter(new SqlParameter("VERSION", Types.VARCHAR));
				insertBillViewMethodSqlUpdate.declareParameter(new SqlParameter("METHOD", Types.VARCHAR));
				insertBillViewMethodSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertBillViewMethodSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertBillViewMethodSqlUpdate.compile();
			}
			
			String [] methodParts = splitInParts(method, 32000);
			
			int insCount = 0;
			for (int i = 0; i < methodParts.length; i ++)
			{
				version = i + "";

				Object[] parameterValues = new Object[]{name, version, methodParts[i], lastUpdated, userId};
				insCount = insCount + insertBillViewMethodSqlUpdate.update(parameterValues);
				
			}

			if(insCount > 0)
			{
				_LOGGER.info("Insert BillViewMethod Response logged successfully \n Number of Records inserted - "+insCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("InsertBillViewMethod in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("InsertBillViewMethod in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertBillViewMethod");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateBillViewType(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		String userId=dbAdminInfo.getUserId();

		String pagekey = dbAdminInfo.getName();
		String pageIdStr = NCASDataUtil.getPageIDFromPageKey(pagekey);
		String pageAttr = NCASDataUtil.getPageAttrFromPageKey(pagekey);

		int pageId = Integer.parseInt(pageIdStr);
		String UPDATE_BILL_VIEW_TYPE = "UPDATE " + getSchemaName() + ".PL_BVIEW_TYPE SET TYPE = ?, TRACK_NAME = ?,LAST_UPDATED = ?, LAST_UPDATED_BY = ?, BRD_MKUP = ?, LFT_MKUP = ?, LFT_TBSIZE = ?, HDR_MKUP = ?, HDR_TBSIZE = ?,ACTION_CLS = ?, STRUCT_TYPE = ?,  CT0_MKUP= ?, CT0_BTNGRP= ?, CT0_TBSIZE= ?, CT0_PAGINATE= ?,  CT1_MKUP= ?, CT1_BTNGRP= ?, CT1_TBSIZE= ?, CT1_PAGINATE= ?, CT2_MKUP= ?, CT2_BTNGRP= ?, CT2_TBSIZE= ?, CT2_PAGINATE= ?, CT3_MKUP= ?, CT3_BTNGRP= ?, CT3_TBSIZE= ?, CT3_PAGINATE= ?, CT4_MKUP= ?,CT4_BTNGRP= ?, CT4_TBSIZE= ?, CT4_PAGINATE= ?, CT5_MKUP = ?, CT5_BTNGRP= ?, CT5_TBSIZE= ?, CT5_PAGINATE= ?, CT6_MKUP= ?, CT6_BTNGRP= ?, CT6_TBSIZE= ?, CT6_PAGINATE= ?, CT7_MKUP= ?, CT7_BTNGRP= ?, CT7_TBSIZE= ?, CT7_PAGINATE= ?, CT8_MKUP= ?, CT8_BTNGRP= ?, CT8_TBSIZE= ?, CT8_PAGINATE= ?, CT9_MKUP= ?, CT9_BTNGRP= ?, CT9_TBSIZE= ?, CT9_PAGINATE= ?, CT10_MKUP= ?, CT10_BTNGRP= ?, CT10_TBSIZE= ?, CT10_PAGINATE= ?, CT11_MKUP= ?,CT11_BTNGRP= ?, CT11_TBSIZE= ?, CT11_PAGINATE= ?, TRACK_ATTR= ?, HELP_STR = ?  WHERE PAGE_ID = ?";
		UPDATE_BILL_VIEW_TYPE += " AND PAGE_ATTR = ?";

		Page page=dbAdminInfo.getPage();
		final Map responseMap = new HashMap();

		_LOGGER.info("Update SQL: " + UPDATE_BILL_VIEW_TYPE);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));


			if(updateBillViewTypeSqlUpdate == null) {
				updateBillViewTypeSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_BILL_VIEW_TYPE);
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("TRACK_NAME", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("BRD_MKUP", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("LFT_MKUP", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("LFT_TBSIZE", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("HDR_MKUP", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("HDR_TBSIZE", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("ACTION_CLS", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("STRUCT_TYPE", Types.VARCHAR));


				String columnPrefix = "";
				for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
					columnPrefix = "CT"+ String.valueOf(i);
					updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_MKUP", Types.VARCHAR));
					updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_BTNGRP", Types.VARCHAR));
					updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_TBSIZE", Types.VARCHAR));
					updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter(columnPrefix+"_PAGINATE", Types.VARCHAR));
				}
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("TRACK_ATTR", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("HELP_STR", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.declareParameter(new SqlParameter("PAGE_ATTR", Types.VARCHAR));
				updateBillViewTypeSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[BillViewConstants.NUMBER_CONTENT*4+15];
			parameterValues[0] = page.getType();
			parameterValues[1] = page.getTrack();
			parameterValues[2] = lastUpdated;
			parameterValues[3] = userId;
			parameterValues[4] = page.getBcrumb();
			parameterValues[5] = page.getLeftNav();
			parameterValues[6] = page.getLeftNavSize();
			parameterValues[7] = page.getHeader();
			parameterValues[8] = page.getHeaderSize();
			parameterValues[9] = page.getAsyncclass();
			parameterValues[10] = page.getStructType();

			for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
				parameterValues[11+(i*4)] = page.getContent(String.valueOf(i));
				parameterValues[12+(i*4)] = "";//page.getBtnGroup(String.valueOf(i));
				parameterValues[13+(i*4)] = page.getTableWidth(String.valueOf(i));
				parameterValues[14+(i*4)] = page.getPaginate(String.valueOf(i));
			}
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+11] = page.getTrackAttr();
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+12] = page.getHelpStr();
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+13] = String.valueOf(pageId);
			parameterValues[BillViewConstants.NUMBER_CONTENT*4+14] = pageAttr;
			int updateCount = updateBillViewTypeSqlUpdate.update(parameterValues);

			if(updateCount > 0) {
				_LOGGER.info("Update BillViewType Response logged successfully \n Number of Records updated - "+updateCount);
				status = true;
			} else {
				Boolean satusObj = (Boolean)insertBillViewType(dbAdminInfo).get("status");
				status = satusObj.booleanValue();
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("UpdateBillViewType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("UpdateBillViewType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateBillViewType");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map updateBillViewMarkup(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		String userId=dbAdminInfo.getUserId();
		String name=dbAdminInfo.getName();
		String type = dbAdminInfo.getType();
		String defaultFlag = dbAdminInfo.getDefaultFlag();
		String temp=dbAdminInfo.getFunction();
		String markup = "";
		if(temp != null || temp != "")
			markup = temp.replaceAll("\\p{Cntrl}+", "");

		final Map responseMap = new HashMap();
		String UPDATE_BILL_VIEW_MARKUP = "UPDATE " + getSchemaName() + ".PL_BVIEW_MARKUP SET MARKUP = ?, LAST_UPDATED = ?, TYPE= ?, MKUP_DFLT= ?, LAST_UPDATED_BY = ? WHERE NAME = ?";

		_LOGGER.info("Update SQL: " + UPDATE_BILL_VIEW_MARKUP);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));


			if(updateBillViewMarkupSqlUpdate == null) {
				updateBillViewMarkupSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_BILL_VIEW_MARKUP);
				updateBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("MARKUP", Types.VARCHAR));
				updateBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updateBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				updateBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("MKUP_DFLT", Types.CHAR));
				updateBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updateBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				updateBillViewMarkupSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{markup, lastUpdated, type, defaultFlag, userId, name};

			int updateCount = updateBillViewMarkupSqlUpdate.update(parameterValues);

			if(updateCount > 0) {
				_LOGGER.info("Update BillViewMarkup Response logged successfully \n Number of Records updated - "+updateCount);
				status = true;
			} else {
				Boolean satusObj = (Boolean)insertBillViewMarkup(dbAdminInfo).get("status");
				status = satusObj.booleanValue();
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("UpdateBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("UpdateBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateBillViewMarkup");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map updateBillViewMethod(DbAdminInfo  dbAdminInfo) throws NCASException {
		
		_LOGGER.debug("Update Bill view Method, will call delete then insert: ");
		Map deleteMap = deleteBillViewMethod(dbAdminInfo);
		Map insertMap = insertBillViewMethod(dbAdminInfo);
		
		Map responseMap = new HashMap();
		
		responseMap.putAll(deleteMap);
		responseMap.putAll(insertMap);
		
		return responseMap;
	}

	public Map deleteBillViewType(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String pagekey = dbAdminInfo.getName();
		String pageIdStr = NCASDataUtil.getPageIDFromPageKey(pagekey);
		String pageAttr = NCASDataUtil.getPageAttrFromPageKey(pagekey);
		//int pageId = dbAdminInfo.getPageId();
		int pageId = Integer.parseInt(pageIdStr);
		String DELETE_BILL_VIEW_TYPE = "DELETE FROM " + getSchemaName() + ".PL_BVIEW_TYPE WHERE PAGE_ID = ?";

		if(pageAttr!=null && !pageAttr.equals(""))
			DELETE_BILL_VIEW_TYPE += " AND PAGE_ATTR = '" + pageAttr + "'";

		_LOGGER.info("Delete SQL: " + DELETE_BILL_VIEW_TYPE);

		try {
			if(deleteBillViewTypeSqlUpdate == null) {
				deleteBillViewTypeSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_BILL_VIEW_TYPE);
				deleteBillViewTypeSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteBillViewTypeSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{String.valueOf(pageId)};

			int deleteCount = deleteBillViewTypeSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete BillViewType Response logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("DeleteBillViewType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DeleteBillViewType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteBillViewType");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map deleteBillViewMarkup(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String DELETE_BILL_VIEW_MARKUP = "DELETE FROM " + getSchemaName() + ".PL_BVIEW_MARKUP WHERE NAME = ?";
		_LOGGER.info("Delete SQL: " + DELETE_BILL_VIEW_MARKUP);

		try {
			if(deleteBillViewMarkupSqlUpdate == null) {
				deleteBillViewMarkupSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_BILL_VIEW_MARKUP);
				deleteBillViewMarkupSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				deleteBillViewMarkupSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{name};

			int deleteCount = deleteBillViewMarkupSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete BillViewMarkup Response logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("DeleteBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DeleteBillViewMarkup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteBillViewMarkup");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map deleteBillViewExtLink(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String DELETE_BILL_VIEW_EXTLINK = "DELETE FROM " + getSchemaName() + ".PL_BVIEW_EXTLINK WHERE NAME = ?";
		_LOGGER.info("Delete SQL: " + DELETE_BILL_VIEW_EXTLINK);

		try {
			if(deleteBillViewExtLinkSqlUpdate == null) {
				deleteBillViewExtLinkSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_BILL_VIEW_EXTLINK);
				deleteBillViewExtLinkSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				deleteBillViewExtLinkSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{name};

			int deleteCount = deleteBillViewExtLinkSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete Bill View Ext. Link Response logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("DeleteBillViewExtLink in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DeleteBillViewExtLink in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteBillViewExtLink");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map deleteBillViewMethod(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String DELETE_BILL_VIEW_METHOD = "DELETE FROM " + getSchemaName() + ".PL_BVIEW_METHOD WHERE NAME = ?";
		_LOGGER.info("Delete SQL: " + DELETE_BILL_VIEW_METHOD);

		try {
			if(deleteBillViewMethodSqlUpdate == null) {
				deleteBillViewMethodSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_BILL_VIEW_METHOD);
				deleteBillViewMethodSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				deleteBillViewMethodSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{name};

			int deleteCount = deleteBillViewMethodSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete BillViewMethod Response logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("DeleteBillViewMethod in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DeleteBillViewMethod in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteBillViewMethod");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map insertLeftNavsDef(DbAdminInfo dbAdminInfo) throws NCASException {
		boolean status = false;
		String INSERT_LEFT_NAVS_DEF_LINK = "INSERT INTO " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF(LEFT_NAV_NBR,NAME,MISC_STRING,TYPE,FMT,TARGET_PAGE_ID,TARGET_PARMS_ID,TARGET_SUBSET,XREF_SQL_ID,L_TYPE,DISPLAY_IND) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		Map responseMap = new HashMap();
		List leftNavList = dbAdminInfo.getLeftNavList();
		LeftNav leftNav = null;
		String excelOrNot = dbAdminInfo.getDefaultFlag();
		_LOGGER.info("Insert SQL: " + INSERT_LEFT_NAVS_DEF_LINK);
		int genLeftNavNumber = 0;
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		Object[] parameterValues =  null;
		try
		{
				if(excelOrNot==null || !excelOrNot.equals("excel"))
				{
					leftNav = (LeftNav)leftNavList.get(0);
					Map leftNavRangeMap = getLeftNavNbrs(dbAdminInfo);
					List totalList = (List)leftNavRangeMap.get("leftNavNbrs");

					List leftNavRange = (List)totalList.get(0);

					int[] leftNavNbrs = new int[leftNavRange.size()];

							for (int i = 0; i < leftNavRange.size(); i++)
							{
								leftNavNbrs[i] =  ((Integer)(leftNavRange.get(i))).intValue();
							}

					genLeftNavNumber = DBAdminUtil.randomNumberGenerator(startRange, endRange, leftNavNbrs);

					_LOGGER.debug("The generated Left Nav Number is :"+genLeftNavNumber);

					leftNav.setLeftNavNbr(genLeftNavNumber);
					parameterValues = new Object[]{new Integer(leftNav.getLeftNavNbr()), leftNav.getName(), leftNav.getMiscString()
													, leftNav.getType(), leftNav.getFmt(), new Integer(leftNav.getTargetPageId())
													, leftNav.getTargetParmsId(), leftNav.getTargetSubset(), new Integer(leftNav.getXrefSqlId())
													, leftNav.getLinkType(),leftNav.getDisplayInd()};
				}



				if(insertLeftNavsDefSqlUpdate == null){


				insertLeftNavsDefSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_LEFT_NAVS_DEF_LINK);
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("MISC_STRING", Types.VARCHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
				insertLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("DISPLAY_IND", Types.CHAR));
				insertLeftNavsDefSqlUpdate.compile();
				}

			if(excelOrNot==null || !excelOrNot.equals("excel"))
			{
				insertLeftNavsDefSqlUpdate.update(parameterValues);
			}else
			{
				LeftNav lftNavObj = null;

				for(int k=0;k<leftNavList.size();k++)
				{
					lftNavObj = (LeftNav)leftNavList.get(k);
					insertLeftNavsDefSqlUpdate.update(new Object[]{new Integer(lftNavObj.getLeftNavNbr()), lftNavObj.getName(), lftNavObj.getMiscString()
													, lftNavObj.getType(), lftNavObj.getFmt(), new Integer(lftNavObj.getTargetPageId())
													, lftNavObj.getTargetParmsId(), lftNavObj.getTargetSubset(), new Integer(lftNavObj.getXrefSqlId())
													, lftNavObj.getLinkType(),lftNavObj.getDisplayInd()});
				}

			}

			if(insertLeftNavsDefSqlUpdate!=null)
			insertLeftNavsDefSqlUpdate.flush();

			status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertLeftNavDefs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertLeftNavDefs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertLeftNavDefs");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}



	public Map insertLeftNavs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		LeftNav leftNav =  null;
		List leftNavList = dbAdminInfo.getLeftNavList();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String addAll = dbAdminInfo.getAddAll();
		String excelOrNot =dbAdminInfo.getDefaultFlag();
		String INSERT_LEFT_NAV_LINK = "INSERT INTO " + getSchemaName() + ".IBRS_LEFT_NAVS(PAGE_ID,LINK_NBR,LEFT_NAV_NBR) VALUES(?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_LEFT_NAV_LINK);
		try
		{
				if(insertLeftNavsSqlUpdate == null)
				{

					insertLeftNavsSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_LEFT_NAV_LINK);
					insertLeftNavsSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					insertLeftNavsSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
					insertLeftNavsSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
					insertLeftNavsSqlUpdate.compile();
				}
			if(excelOrNot==null || !excelOrNot.equals("excel"))
			{
				leftNav = (LeftNav)(dbAdminInfo.getLeftNavList().get(0));
				Map pageIdLinkNbr = null;

				if(addAll!= null && addAll.equalsIgnoreCase("ALL")){
					pageIdLinkNbr = selectPageIds(dbAdminInfo.getStartRange(), dbAdminInfo.getEndRange());
				}
				else{
					_LOGGER.info("It is not ADD ALL");
					pageIdLinkNbr = leftNav.getPageIdLinkNbr();
				}

			    Iterator it = pageIdLinkNbr.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();

		        int linkNbrParam = ((Integer)pairs.getValue()).intValue();
		        int pageParam = ((Integer)pairs.getKey()).intValue();

				_LOGGER.info("Adjust Link Numbers getting called");

		        int latestLinkNbrParam = adjustLinkNumbers(linkNbrParam, pageParam, leftNav.getLeftNavNbr());

		        if(latestLinkNbrParam==0)
		        {
					latestLinkNbrParam = linkNbrParam;
				}

		    	insertLeftNavsSqlUpdate.update(new Object[]{new Integer(pageParam), new Integer(latestLinkNbrParam), new Integer(leftNav.getLeftNavNbr())});
			    }
			}
			else{
				LeftNav lftNavObj = null;
				for(int k=0;k<leftNavList.size();k++)
				{
					lftNavObj = (LeftNav)leftNavList.get(k);
					insertLeftNavsSqlUpdate.update(new Object[]{new Integer(lftNavObj.getLeftNavNbr()), new Integer(lftNavObj.getTargetPageId()), new Integer(lftNavObj.getTargetParmsId())});
				}
			}
				if(insertLeftNavsSqlUpdate != null)
			    insertLeftNavsSqlUpdate.flush();

				status = true;


		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertLeftNavs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertLeftNavs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertLeftNavs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}



	public Map deleteLeftNavFromPageId(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int leftNavNbr = dbAdminInfo.getLeftNavNbr();
		int pageId = dbAdminInfo.getPageId();
		String DELETE_LEFT_NAV_PAGE_ID = "DELETE FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE LEFT_NAV_NBR = ? AND PAGE_ID = ?";
		_LOGGER.info("Delete SQL: " + DELETE_LEFT_NAV_PAGE_ID);

		try {
			if(deleteLeftNavFromPageSqlUpdate == null) {
				deleteLeftNavFromPageSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_LEFT_NAV_PAGE_ID);
				deleteLeftNavFromPageSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
				deleteLeftNavFromPageSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteLeftNavFromPageSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(leftNavNbr), new Integer(pageId)};

			int deleteCount = deleteLeftNavFromPageSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete Left Nav from Page Id logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLeftNavFromPageId in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLeftNavFromPageId in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteLeftNavFromPageId");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public boolean deleteAllLeftNavFromPageId(int pageId) throws NCASException {
		boolean status = false;
		String DELETE_ALL_LEFT_NAV_PAGE_ID = "DELETE FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE PAGE_ID = ?";
		_LOGGER.info("Delete SQL: " + DELETE_ALL_LEFT_NAV_PAGE_ID);

		try {
			if(deleteAllLeftNavFromPageSqlUpdate == null) {
				deleteAllLeftNavFromPageSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_ALL_LEFT_NAV_PAGE_ID);
				deleteAllLeftNavFromPageSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteAllLeftNavFromPageSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(pageId)};

			int deleteCount = deleteAllLeftNavFromPageSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete Left Nav from Page Id logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAllLeftNavFromPageId in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteAllLeftNavFromPageId in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteAllLeftNavFromPageId");
		return status;
	}

	public int adjustLinkNumbers(int linkNbr, int pageId, int leftNavNumber) throws NCASException{

		_LOGGER.info("link nbr is >>"+linkNbr);
		_LOGGER.info("pageId is >>"+pageId);
		Map leftNavLinkNbrs = selectLeftNavNbrsLinkNbrs(pageId);

		boolean linkNbrTaken = leftNavLinkNbrs.containsValue(new Integer(linkNbr));
		boolean leftNavExists = leftNavLinkNbrs.containsKey(new Integer(leftNavNumber));
		int maxLinkNbrPlusOne = 0;
		int maxValueCalculated = 0;

		if(linkNbr==-1)
		{
			if(leftNavLinkNbrs.values()!=null && leftNavLinkNbrs.values().size()>0)
			{
				maxValueCalculated = ((Integer)Collections.max(leftNavLinkNbrs.values())).intValue();
			}
			maxLinkNbrPlusOne = maxValueCalculated+1;
			_LOGGER.info("Max Integer Plus one is: " + maxLinkNbrPlusOne);
			return maxLinkNbrPlusOne;
		}

		if(!linkNbrTaken)
		{
			//The link nbr is not taken. So the left nav that is being introduced is going to be the last link if there
			//are already links existing or it will be the first, if none exists.
			return linkNbr;
		}
		else{
			//The link nbr is taken. All the current links that are equal or greater to the user choice of the
			//link nbr should be increased by one if this link is moving down.All the current links which have their
			//current link order inbetween or equal to the chosen link order, should be increased by one and the others
			//remain the same.
		    Iterator it = leftNavLinkNbrs.entrySet().iterator();

		    Map latestLeftNavLinkNbrs = new HashMap();
			if(leftNavExists)
			{
				 int updatingLeftNavLinkNbr = ((Integer)leftNavLinkNbrs.get(new Integer(leftNavNumber))).intValue();
				_LOGGER.info("The left nav already exists. So this must be an update and not an insert");
					while (it.hasNext())
					{

						Map.Entry pairs = (Map.Entry)it.next();

						int leftNavNbr = ((Integer)(pairs.getKey())).intValue();
						int curLinkNbr = ((Integer)pairs.getValue()).intValue();
						_LOGGER.info("Current LeftNav Nbr->"+leftNavNbr+"Current linknbr-> "+curLinkNbr);
						if(leftNavNumber==leftNavNbr)
						{
							_LOGGER.info("This is the leftnav that is being modified->"+leftNavNbr+" The new link nbr is " +linkNbr);
							latestLeftNavLinkNbrs.put(new Integer(leftNavNbr), new Integer(linkNbr));
						}
						else
						{
							if(curLinkNbr<=linkNbr && (curLinkNbr>updatingLeftNavLinkNbr))
							{
								int latestLinkNbr = curLinkNbr-1;
								_LOGGER.info("The latest link nbr for the leftnav "+ leftNavNbr+" is "+latestLinkNbr);
								latestLeftNavLinkNbrs.put(new Integer(leftNavNbr), new Integer(latestLinkNbr));

							}
							else if(curLinkNbr==linkNbr ||(curLinkNbr>linkNbr && curLinkNbr<updatingLeftNavLinkNbr))
							{
								int latestLinkNbr = curLinkNbr+1;
								_LOGGER.info("The latest link nbr for the leftnav "+ leftNavNbr+" is "+latestLinkNbr);
								latestLeftNavLinkNbrs.put(new Integer(leftNavNbr), new Integer(latestLinkNbr));

							}
							else{
								_LOGGER.info("The latest link nbr for the leftnav "+ leftNavNbr+" is "+curLinkNbr);
								latestLeftNavLinkNbrs.put(new Integer(leftNavNbr), new Integer(curLinkNbr));
							}
						}
				    }
				    updateLeftNavLinkOrder(latestLeftNavLinkNbrs, pageId);

			}
			else
			{
				_LOGGER.info("The left nav doesn't exist. So this must be an insert and not an update");
					while (it.hasNext())
					{
						Map.Entry pairs = (Map.Entry)it.next();
						if(((Integer)pairs.getValue()).intValue()>=linkNbr)
						{

							int latestLinkNbr = ((Integer)(pairs.getValue())).intValue()+1;
							int leftNavNbr = ((Integer)(pairs.getKey())).intValue();

							_LOGGER.info("The latest link nbr for the leftnav "+ leftNavNbr+" is "+latestLinkNbr);

							latestLeftNavLinkNbrs.put(new Integer(leftNavNbr), new Integer(latestLinkNbr));

						}else
						{
							latestLeftNavLinkNbrs.put((Integer)pairs.getKey(), (Integer)pairs.getValue());
						}
				    }
				  updateLeftNavLinkOrder(latestLeftNavLinkNbrs, pageId);
	  	  	}

		}
		  return maxLinkNbrPlusOne;
	}

	public boolean updateLeftNavLinkOrder(Map leftNavLinkNbr, int pageId) throws NCASException{
		boolean status = false;

		String UPDATE_LINK_ORDER_SQL = "INSERT INTO " + getSchemaName() + ".IBRS_LEFT_NAVS(PAGE_ID,LINK_NBR,LEFT_NAV_NBR) VALUES(?,?,?)";

		_LOGGER.info(" SQL: " + UPDATE_LINK_ORDER_SQL);


		try
		{
			if(deleteAllLeftNavFromPageId(pageId))
			{

				if(updateLinkOrderSqlUpdate == null)
				{

					updateLinkOrderSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_LINK_ORDER_SQL);
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
					updateLinkOrderSqlUpdate.compile();
				}

			    Iterator it = leftNavLinkNbr.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		    	updateLinkOrderSqlUpdate.update(new Object[]{new Integer(pageId), (Integer)pairs.getValue(), (Integer)pairs.getKey()});
			    }
				if(updateLinkOrderSqlUpdate != null)
			    updateLinkOrderSqlUpdate.flush();

				status = true;
			}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateLinkOrder in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateLinkOrder in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateLinkOrder");
		return status;
	}


	public boolean deleteLeftNavReferences(int  leftNavNbr) throws NCASException {
		boolean status = false;
		String DELETE_LEFT_NAV = "DELETE FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE LEFT_NAV_NBR = ?";
		_LOGGER.info("Delete SQL: " + DELETE_LEFT_NAV);

		try {
			if(deleteLeftNavRefSqlUpdate == null) {
				deleteLeftNavRefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_LEFT_NAV);
				deleteLeftNavRefSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
				deleteLeftNavRefSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(leftNavNbr)};

			int deleteCount = deleteLeftNavRefSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete Left Nav References logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLeftNavReferences in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLeftNavReferences in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteLeftNavReferences");
		return status;
	}

	public Map deleteLeftNav(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int leftNavNbr = dbAdminInfo.getLeftNavNbr();
		String allPages = dbAdminInfo.getAddAll();
		int pageId = dbAdminInfo.getPageId();
		if(allPages.equalsIgnoreCase("SINGLE"))
		{
			_LOGGER.info("A page has been selected. The user wants to delete a leftnav "+leftNavNbr+" from the page ->"+pageId);
			return deleteLeftNavFromPageId(dbAdminInfo);
		}
		else if(allPages.equalsIgnoreCase("ALL") && pageId != -1)
		{
			_LOGGER.info("The user wants to delete all leftnavs from the page ->"+pageId);
			responseMap.put("status",new Boolean(deleteAllLeftNavFromPageId(pageId)));
			return responseMap;
		}
		else if(allPages.equalsIgnoreCase("ALL") && pageId == -1)
		{

 		_LOGGER.info("The user wants to delete a leftnav "+ leftNavNbr+" all together");

		String DELETE_LEFT_NAV = "DELETE FROM " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR = ?";
		_LOGGER.info("Delete SQL: " + DELETE_LEFT_NAV);

		try {

				deleteLeftNavReferences(leftNavNbr);
				if(deleteLeftNavSqlUpdate == null) {
					deleteLeftNavSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_LEFT_NAV);
					deleteLeftNavSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
					deleteLeftNavSqlUpdate.compile();
				}

				Object[] parameterValues = new Object[]{new Integer(leftNavNbr)};

				int deleteCount = deleteLeftNavSqlUpdate.update(parameterValues);

				if(deleteCount > 0) {
					_LOGGER.info("Delete Left Nav logged successfully \n Number of Records deleted - "+deleteCount);
					status = true;
				}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLeftNav in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLeftNav in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}
		_LOGGER.info("Exiting deleteLeftNav");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateLeftNavsDef(DbAdminInfo dbAdminInfo) throws NCASException {
		boolean status = false;
		String UPDATE_LEFT_NAVS_DEF_LINK = "UPDATE " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF SET NAME = ?,MISC_STRING = ? ,TYPE = ? ,FMT = ? ,TARGET_PAGE_ID = ? ,TARGET_PARMS_ID = ? ,TARGET_SUBSET = ? ,XREF_SQL_ID = ?, L_TYPE = ?, DISPLAY_IND =? WHERE LEFT_NAV_NBR = ?";
		Map responseMap = new HashMap();
		LeftNav leftNav = (LeftNav)(dbAdminInfo.getLeftNavList().get(0));
		_LOGGER.info("Update SQL: " + UPDATE_LEFT_NAVS_DEF_LINK);

		try
		{

				if(updateLeftNavsDefSqlUpdate == null){


				updateLeftNavsDefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_LEFT_NAVS_DEF_LINK);
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("MISC_STRING", Types.VARCHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("DISPLAY_IND", Types.CHAR));
				updateLeftNavsDefSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));


				updateLeftNavsDefSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{leftNav.getName(), leftNav.getMiscString()
													, leftNav.getType(), leftNav.getFmt(), new Integer(leftNav.getTargetPageId())
													, leftNav.getTargetParmsId(), leftNav.getTargetSubset()
													, new Integer(leftNav.getXrefSqlId())
													,leftNav.getLinkType(),leftNav.getDisplayInd(),new Integer(leftNav.getLeftNavNbr())};

			int updateCount =  updateLeftNavsDefSqlUpdate.update(parameterValues);

			_LOGGER.info("Update Left Nav Defs logged successfully \n Number of Records updated - "+updateCount);
			status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateLeftNavsDef in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateLeftNavsDef in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateLeftNavsDef");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	public Map updateLeftNavs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		LeftNav leftNav = (LeftNav)(dbAdminInfo.getLeftNavList().get(0));
		Map responseMap = new HashMap();
		String UPDATE_LEFT_NAV_LINK = "UPDATE " + getSchemaName() + ".IBRS_LEFT_NAVS SET LINK_NBR = ? WHERE LEFT_NAV_NBR = ? AND PAGE_ID = ?";


		_LOGGER.info("Insert SQL: " + UPDATE_LEFT_NAV_LINK);


		try
		{
				if(updateLeftNavsSqlUpdate == null)
				{

					updateLeftNavsSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_LEFT_NAV_LINK);
					updateLeftNavsSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
					updateLeftNavsSqlUpdate.declareParameter(new SqlParameter("LEFT_NAV_NBR", Types.INTEGER));
					updateLeftNavsSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));

					updateLeftNavsSqlUpdate.compile();
				}

				Map pageIdLinkNbr = leftNav.getPageIdLinkNbr();

			    Iterator it = pageIdLinkNbr.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
				Map leftNavLinkNbrs = selectLeftNavNbrsLinkNbrs(((Integer)pairs.getKey()).intValue());
				boolean linkNbrTaken = leftNavLinkNbrs.containsValue((Integer)(pairs.getValue()));
				if(!linkNbrTaken)
				{
		    		updateLeftNavsSqlUpdate.update(new Object[]{(Integer)pairs.getValue(), new Integer(leftNav.getLeftNavNbr()), (Integer)pairs.getKey()});
				}
		    	else
		    	{
					adjustLinkNumbers(((Integer)pairs.getValue()).intValue(),((Integer)pairs.getKey()).intValue(),leftNav.getLeftNavNbr());
				}
			   }
			   if(updateLeftNavsSqlUpdate != null)
			   updateLeftNavsSqlUpdate.flush();

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateLeftNavs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateLeftNavs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateLeftNavs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map selectLeftNavNbrsLinkNbrs(int pageId) throws NCASException {
		String SELECT_LEFT_NAV_LINK_NBR = "SELECT LEFT_NAV_NBR,LINK_NBR FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE PAGE_ID ="+pageId;

		final Map leftNavNbrLinkNbr = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_LEFT_NAV_LINK_NBR);

		try
		{
			jdbcTemplate.query(SELECT_LEFT_NAV_LINK_NBR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int leftNavNbr	= rs.getInt("LEFT_NAV_NBR");
					int linkNbr		= rs.getInt("LINK_NBR");
					leftNavNbrLinkNbr.put(new Integer(leftNavNbr), new Integer(linkNbr));

				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLeftNavNbrsLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLeftNavNbrsLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLeftNavNbrsLinkNbrs");

		return leftNavNbrLinkNbr;
	}

		public Map selectLinkNbrs(DbAdminInfo dbAdminInfo) throws NCASException {
			String SELECT_LINK_NBR = "SELECT LINK_NBR FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE PAGE_ID ="+dbAdminInfo.getPageId()+" AND LEFT_NAV_NBR="+dbAdminInfo.getLeftNavNbr();
			final List totalList = new ArrayList();

			final Map linkNbrs = new HashMap();
			_LOGGER.info("Select SQL: " + SELECT_LINK_NBR);

			try
			{
				jdbcTemplate.query(SELECT_LINK_NBR, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						int linkNbr		= rs.getInt("LINK_NBR");
						List list = new ArrayList();
						list.add(new Integer(linkNbr));
						totalList.add(list);
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("selectLinkNbrs in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("selectLinkNbrs in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting selectLinkNbrs");
			linkNbrs.put("order",totalList);
			linkNbrs.put("orderAll",(List)selectAllLinkNbrsFromPage(dbAdminInfo).get("order"));
			return linkNbrs;
	}

		public Map selectAllLinkNbrsFromPage(DbAdminInfo dbAdminInfo) throws NCASException {
			String SELECT_LINK_NBR = "SELECT LINK_NBR FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE PAGE_ID ="+dbAdminInfo.getPageId();
			final List totalList = new ArrayList();
			final Map linkNbrs = new HashMap();
			_LOGGER.info("Select SQL: " + SELECT_LINK_NBR);

			try
			{
				jdbcTemplate.query(SELECT_LINK_NBR, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						int linkNbr		= rs.getInt("LINK_NBR");
						List list = new ArrayList();
						list.add(new Integer(linkNbr));
						totalList.add(list);
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("selectLinkNbrs in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("selectLinkNbrs in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting selectLinkNbrs");
			linkNbrs.put("order",totalList);
			return linkNbrs;
	}

	public Map selectLeftNavNbrsLinkNbrs(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_LEFT_NAV_LINK_NBR = "SELECT A.LEFT_NAV_NBR, B.NAME FROM " + getSchemaName() + ".IBRS_LEFT_NAVS A, " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF B  WHERE A.PAGE_ID ="+dbAdminInfo.getPageId()+" AND A.LEFT_NAV_NBR = B.LEFT_NAV_NBR" ;

		final Map leftNavNbrLinkNbr = new HashMap();
		final List totalList = new ArrayList();
		_LOGGER.info("Select SQL: " + SELECT_LEFT_NAV_LINK_NBR);

		try
		{
			jdbcTemplate.query(SELECT_LEFT_NAV_LINK_NBR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt("LEFT_NAV_NBR")));
					list.add(rs.getString("NAME"));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLeftNavNbrsLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLeftNavNbrsLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLeftNavNbrsLinkNbrs");
		leftNavNbrLinkNbr.put("order",totalList);
		return leftNavNbrLinkNbr;
	}

	public Map selectAllPageIdsLeftNavsInRange(DbAdminInfo  dbAdminInfo) throws NCASException {
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String SELECT_PAGEID_LEFTNAVNBR = "(SELECT CHAR(PAGE_ID)||'--'||TBL_TITLE,'' FROM "+getSchemaName()+".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" AND SECTION_NUM=0) UNION ALL (SELECT '',CHAR(LEFT_NAV_NBR)||'--'||NAME  FROM "+getSchemaName()+".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR IN(SELECT LEFT_NAV_NBR FROM "+getSchemaName()+".IBRS_LEFT_NAVS WHERE PAGE_ID BETWEEN  "+startRange+" AND "+endRange+" UNION SELECT LEFT_NAV_NBR FROM "+getSchemaName()+".IBRS_LEFT_NAVS_DEF))";

		final Map pageIdLeftNavs = new HashMap();
		final List totalList = new ArrayList();
		_LOGGER.info("Select SQL: " + SELECT_PAGEID_LEFTNAVNBR);

		try
		{
			jdbcTemplate.query(SELECT_PAGEID_LEFTNAVNBR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectAllPageIdsLeftNavsInRange in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectAllPageIdsLeftNavsInRange in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectAllPageIdsLeftNavsInRange");
		pageIdLeftNavs.put("order",totalList);
		return pageIdLeftNavs;
	}

	public Map selectPageIds(int startRange, int endRange) throws NCASException {
		String SELECT_PAGE_IDS = "SELECT CHAR(PAGE_ID)||'--'||TBL_TITLE FROM " + getSchemaName() + ".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange +" AND SECTION_NUM=0 ORDER BY TBL_TITLE";

		final Map pageIdLinkNbr = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_PAGE_IDS);

		try
		{
			jdbcTemplate.query(SELECT_PAGE_IDS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String pageId		= rs.getString(1);
					_LOGGER.info("Page id >>>"+pageId);
					int linkNbr		= 0;
					pageIdLinkNbr.put(pageId, new Integer(linkNbr));

				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectPageIds in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectPageIds in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectPageIds");

		return pageIdLinkNbr;
	}

	public Map selectLeftNavPageIdsLinkNbrs(int leftNavNbr, int pageIdParam) throws NCASException {
		String SELECT_LEFT_NAV = "SELECT PAGE_ID,LINK_NBR FROM " + getSchemaName() + ".IBRS_LEFT_NAVS WHERE LEFT_NAV_NBR ="+leftNavNbr+" AND PAGE_ID = "+pageIdParam ;

		final Map pageIdLinkNbr = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_LEFT_NAV);

		try
		{
			jdbcTemplate.query(SELECT_LEFT_NAV, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int pageId		= rs.getInt("PAGE_ID");
					int linkNbr		= rs.getInt("LINK_NBR");
					pageIdLinkNbr.put(new Integer(pageId), new Integer(linkNbr));

				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLeftNavPageIdsLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLeftNavPageIdsLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLeftNavPageIdsLinkNbrs");

		return pageIdLinkNbr;
	}

	public Map selectPageIdTitle(String pageId)
	{
		String SELECT_PAGE_TITLE = "SELECT CHAR(PAGE_ID)||'--'||TBL_TITLE FROM " + getSchemaName() + ".IBRS_PAGES WHERE PAGE_ID="+pageId+" AND SECTION_NUM=0  ORDER BY TBL_TITLE";
		final Map tableTitle = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_PAGE_TITLE);

		try
		{
			jdbcTemplate.query(SELECT_PAGE_TITLE, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					tableTitle.put("pageid",rs.getString(1));

				}
			});
			} catch(Exception vamEx) {
				tableTitle.put("pageid",pageId);
				return tableTitle;
			}
	 return tableTitle;
	}

	public Map selectLeftNav(DbAdminInfo  dbAdminInfo) throws NCASException {
		int leftNavNbr =dbAdminInfo.getLeftNavNbr();
		//int pageId =dbAdminInfo.getPageId();
		Map responseMap = new HashMap();
		String SELECT_LEFT_NAV = "SELECT * FROM " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR ="+leftNavNbr;

		final LeftNav leftNav = new LeftNav();
		//final Map pageIdLinkNbrs = selectLeftNavPageIdsLinkNbrs(leftNavNbr, pageId);

		_LOGGER.info("Select SQL: " + SELECT_LEFT_NAV);

		try
		{
			jdbcTemplate.query(SELECT_LEFT_NAV, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int leftNavNumber		= rs.getInt("LEFT_NAV_NBR");
					String name 			= rs.getString("NAME");
					String miscString		= rs.getString("MISC_STRING");
					String fmt 				= rs.getString("FMT");
					String type 			= rs.getString("TYPE");
					String targetPageId		= rs.getString("TARGET_PAGE_ID");
					String targetParmsId	= rs.getString("TARGET_PARMS_ID");
					String targetSubset 	= rs.getString("TARGET_SUBSET");
					int xRefSqlRefId 		= rs.getInt("XREF_SQL_ID");
					String linkType			= rs.getString("L_TYPE");
					String displayInd		= rs.getString("DISPLAY_IND");

					//leftNav.setPageIdLinkNbr(pageIdLinkNbrs);
					leftNav.setName(name);
					leftNav.setMiscString(miscString);
					leftNav.setLeftNavNbr(leftNavNumber);
					leftNav.setFmt(fmt);
					leftNav.setType(type);
					String tPageId = (String)selectPageIdTitle(targetPageId).get("pageid");
					if(tPageId == null)
					{
						tPageId = "0";
					}
					leftNav.setTargetPageId(tPageId);
					_LOGGER.info("The targetPageId is ->"+tPageId);
					leftNav.setTargetParmsId(targetParmsId);
					leftNav.setTargetSubset(targetSubset);
					leftNav.setXrefSqlId(xRefSqlRefId);
					leftNav.setLinkType(linkType);
					leftNav.setDisplayInd(displayInd);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLeftNav in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLeftNav in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLeftNav");

		 responseMap.put("leftNav",leftNav);
		 return responseMap;
	}

	public Map getLeftNavDropDowns(DbAdminInfo  dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String schemaName = getSchemaName();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String LEFT_NAV_DROP_DOWN =  "(SELECT  NAME,'','','','','','','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TYPE') UNION ALL (SELECT '',CHAR(LEFT_NAV_NBR),'','','','','','',''  FROM " + schemaName +".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR IN (SELECT LEFT_NAV_NBR FROM "+getSchemaName()+".IBRS_LEFT_NAVS WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" UNION SELECT LEFT_NAV_NBR FROM "+getSchemaName()+".IBRS_LEFT_NAVS_DEF ) ) UNION ALL (SELECT '','', NAME,'','','','','',''  FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='FMT') UNION ALL (SELECT DISTINCT '','','',TARGET_PARMS_ID,'','','','','' FROM " + schemaName +".IBRS_TARGET_PARMS) UNION ALL (SELECT '','','','',CHAR(PAGE_ID)||'--'||TBL_TITLE,'','','','' FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" AND SECTION_NUM=0) UNION ALL (SELECT  '','','','','',NAME,'','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TARGET_SUBSET') UNION ALL (SELECT  DISTINCT '','','','','','',CHAR(XREF_SQL_ID),'','' FROM " + schemaName +".IBRS_XREF_SQL) UNION ALL (SELECT DISTINCT '','','','','','','',CHAR(LINK_NBR),'' FROM " + schemaName +".IBRS_LEFT_NAVS WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" ) UNION ALL (SELECT  '','','','','','','','',NAME FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='L_TYPE')";

		_LOGGER.info("Left Nav Drop Down SQL: " + LEFT_NAV_DROP_DOWN);
		try
		{
			jdbcTemplate.query(LEFT_NAV_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					list.add(rs.getString(8));
					list.add(rs.getString(9));
					totalList.add(list);
				}
			});

			responseMap.put("left_nav_drop_down",totalList);
			return responseMap;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("leftNavDropDowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("leftNavDropDowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}

	public Map getLeftNavNbrs(DbAdminInfo dbAdminInfo) throws NCASException{
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String SELECT_LEFT_NAV_NUMBER_RANGE= "SELECT LEFT_NAV_NBR FROM " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR BETWEEN "+startRange+" AND "+endRange;

		Map responseMap = new HashMap();
		final List totalList = new ArrayList();


		_LOGGER.info("Select SQL: " + SELECT_LEFT_NAV_NUMBER_RANGE);

		try
		{
			jdbcTemplate.query(SELECT_LEFT_NAV_NUMBER_RANGE, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List leftNavNbrList = new ArrayList();
					int leftNavNumber = rs.getInt("LEFT_NAV_NBR");
					leftNavNbrList.add(new Integer(leftNavNumber));
					totalList.add(leftNavNbrList);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getLeftNavNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getLeftNavNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}

		responseMap.put("leftNavNbrs", totalList);
		_LOGGER.info("Exiting getLeftNavNbrs");

		return responseMap;
	}

	public Map getLeftNavNumbersInRange(DbAdminInfo dbAdminInfo) throws NCASException{
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String SELECT_LEFT_NAV_NAME_RANGE= "SELECT LEFT_NAV_NBR, NAME FROM " + getSchemaName() + ".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR IN (SELECT LEFT_NAV_NBR FROM "+getSchemaName()+".IBRS_LEFT_NAVS WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" UNION SELECT LEFT_NAV_NBR FROM "+getSchemaName()+".IBRS_LEFT_NAVS_DEF WHERE LEFT_NAV_NBR BETWEEN "+startRange+" AND "+endRange+")" ;

		final Map leftNavNbrsNames = new HashMap();


		_LOGGER.info("Select SQL: " + SELECT_LEFT_NAV_NAME_RANGE);

		try
		{
			jdbcTemplate.query(SELECT_LEFT_NAV_NAME_RANGE, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int leftNavNbr = rs.getInt("LEFT_NAV_NBR");
					String leftNavName = rs.getString("NAME");
					leftNavNbrsNames.put(new Integer(leftNavNbr), leftNavName);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getLeftNavNumbersInRange in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getLeftNavNumbersInRange in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getLeftNavNumbersInRange");

		return leftNavNbrsNames;
	}


	public Map insertBreadCrumbs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		List breadcrumbList = dbAdminInfo.getBreadCrumbList();
		String INSERT_BREAD_CRUMBS_LINK = "INSERT INTO " + getSchemaName() + ".IBRS_BREAD_CRUMBS(PAGE_ID,LINK_NBR,NAME,MISC_STRING,TYPE,FMT,TARGET_PAGE_ID,TARGET_PARMS_ID,TARGET_SUBSET,XREF_SQL_ID,L_TYPE) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		String excelOrNot = dbAdminInfo.getDefaultFlag();
		_LOGGER.info("Insert SQL: " + INSERT_BREAD_CRUMBS_LINK);
		BreadCrumb breadcrumb = (BreadCrumb)breadcrumbList.get(0);
		String breadcrumbName = breadcrumb.getName();
		Map pageIdLinkNbr = null;
		try
		{
			if(excelOrNot==null || !excelOrNot.equals("excel"))
			{
				pageIdLinkNbr = breadcrumb.getPageIdLinkNbr();
				Object[] selectedPage = pageIdLinkNbr.keySet().toArray();
				Map curNamesLinkNbrs = getBreadCrumbLinkNbrsMap(((Integer)selectedPage[0]).intValue());
				Object[] selectedLinkNbr = pageIdLinkNbr.values().toArray();


				Object[] pageId = pageIdLinkNbr.keySet().toArray();
				int curPageId = ((Integer)pageId[0]).intValue();
				int latestLinkNbrValue = ((Integer)selectedLinkNbr[0]).intValue();
				int maxValueCalculated = 0;
				_LOGGER.info("Breadcrumb "+breadcrumbName+" updated Link nbr ->"+latestLinkNbrValue);

				if(curNamesLinkNbrs.containsValue(new Integer(latestLinkNbrValue)))
				{
					_LOGGER.info("Yes. The user picked an existing link number");
					Map latestNamesLinkNbrs = new TreeMap(Collections.reverseOrder());

					Iterator curIt = curNamesLinkNbrs.entrySet().iterator();
					boolean flag = true;
					while (curIt.hasNext()) {

						Map.Entry pairs = (Map.Entry)curIt.next();
						String bName = (String)pairs.getKey();
						int bLink = ((Integer)pairs.getValue()).intValue();
						if(!bName.equals(breadcrumbName))
						{
							if(bLink>=latestLinkNbrValue)
							{
								bLink++;

							}
							_LOGGER.info("The later links->"+bName+" - "+bLink);
						}
						latestNamesLinkNbrs.put(new Integer(bLink),bName);
					}

					updateBreadCrumbLinkNbrs(curPageId, latestNamesLinkNbrs);
				}
				else
				{

					if(latestLinkNbrValue==-1)
					{
						_LOGGER.info("Yes the linknumber chosen is -1");
						if(curNamesLinkNbrs.values()!=null && curNamesLinkNbrs.values().size()>0)
						{
							maxValueCalculated = ((Integer)Collections.max(curNamesLinkNbrs.values())).intValue();
						}
						latestLinkNbrValue = maxValueCalculated +1 ;
						_LOGGER.info("Max Integer Plus one is: " + latestLinkNbrValue);
						pageIdLinkNbr.remove(new Integer(curPageId));
						pageIdLinkNbr.put(new Integer(curPageId),new Integer(latestLinkNbrValue));
					}

				}
			}

				if(insertBreadCrumbSqlUpdate == null){


				insertBreadCrumbSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_BREAD_CRUMBS_LINK);
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("MISC_STRING", Types.VARCHAR));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				insertBreadCrumbSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));

				insertBreadCrumbSqlUpdate.compile();
			}

			if(excelOrNot==null || !excelOrNot.equals("excel"))
			{
			    Iterator it = pageIdLinkNbr.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		    	insertBreadCrumbSqlUpdate.update(new Object[]{(Integer)pairs.getKey(), (Integer)pairs.getValue(), breadcrumbName, breadcrumb.getMiscString()
													, breadcrumb.getType(), breadcrumb.getFmt(), new Integer(breadcrumb.getTargetPageId())
													, breadcrumb.getTargetParmsId(), breadcrumb.getTargetSubset(), new Integer(breadcrumb.getXrefSqlId()),breadcrumb.getLinkType()});

			    }
			}else{
					BreadCrumb bCrumbObj = null;
				 	for(int k=0;k<breadcrumbList.size();k++)
				 	{
						bCrumbObj = (BreadCrumb)breadcrumbList.get(k);
						Map pageIdLkNumb = (HashMap)bCrumbObj.getPageIdLinkNbr();
						Object[] pageIdArray = pageIdLkNumb.keySet().toArray();


						insertBreadCrumbSqlUpdate.update(new Object[]{pageIdArray[0], pageIdLkNumb.get(pageIdArray[0]), bCrumbObj.getName(), bCrumbObj.getMiscString()
													, bCrumbObj.getType(), bCrumbObj.getFmt(), new Integer(bCrumbObj.getTargetPageId())
													, bCrumbObj.getTargetParmsId(), bCrumbObj.getTargetSubset(), new Integer(bCrumbObj.getXrefSqlId()),bCrumbObj.getLinkType()});



					}


			}

				if(insertBreadCrumbSqlUpdate != null)
			    insertBreadCrumbSqlUpdate.flush();



				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertBreadCrumbs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertBreadCrumbs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertBreadCrumbs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateBreadCrumbs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		BreadCrumb breadcrumb = (BreadCrumb)dbAdminInfo.getBreadCrumbList().get(0);
		Map pageIdLinkNbr = breadcrumb.getPageIdLinkNbr();
		String UPDATE_BREAD_CRUMBS_LINK = "UPDATE " + getSchemaName() + ".IBRS_BREAD_CRUMBS SET NAME = ?,MISC_STRING = ? ,TYPE = ? ,FMT = ? ,TARGET_PAGE_ID = ? ,TARGET_PARMS_ID = ? ,TARGET_SUBSET = ? ,XREF_SQL_ID = ?,L_TYPE = ? WHERE PAGE_ID = ? AND LINK_NBR = ?";

		_LOGGER.info("Update SQL: " + UPDATE_BREAD_CRUMBS_LINK);

		try
		{
				String breadcrumbName = breadcrumb.getName();

				if(updateBreadCrumbsSqlUpdate == null){


				updateBreadCrumbsSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_BREAD_CRUMBS_LINK);
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("MISC_STRING", Types.VARCHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				updateBreadCrumbsSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));

				updateBreadCrumbsSqlUpdate.compile();
			}


			    Iterator it = pageIdLinkNbr.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		    	updateBreadCrumbsSqlUpdate.update(new Object[]{breadcrumbName, breadcrumb.getMiscString()
													, breadcrumb.getType(), breadcrumb.getFmt(), new Integer(breadcrumb.getTargetPageId())
													, breadcrumb.getTargetParmsId(), breadcrumb.getTargetSubset(), new Integer(breadcrumb.getXrefSqlId())
													,breadcrumb.getLinkType(), (Integer)pairs.getKey(), (Integer)pairs.getValue()});

			    }

				if(updateBreadCrumbsSqlUpdate != null)
			    updateBreadCrumbsSqlUpdate.flush();



				status = true;



		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateBreadCrumbs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateBreadCrumbs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateBreadCrumbs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

      public Map updateBreadCrumbLinkNbrs(int pageId, Map linkNbrName) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String UPDATE_BREAD_CRUMBS_LINK = "UPDATE " + getSchemaName() + ".IBRS_BREAD_CRUMBS SET LINK_NBR=? WHERE PAGE_ID = ? AND NAME = ?";

		_LOGGER.info("Update SQL: " + UPDATE_BREAD_CRUMBS_LINK);

		try
		{
				if(updateBreadCrumbLinkSqlUpdate == null){


				updateBreadCrumbLinkSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_BREAD_CRUMBS_LINK);
				updateBreadCrumbLinkSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
				updateBreadCrumbLinkSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				updateBreadCrumbLinkSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));


				updateBreadCrumbLinkSqlUpdate.compile();
			}

			    Iterator it = linkNbrName.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		    	updateBreadCrumbLinkSqlUpdate.update(new Object[]{(Integer)pairs.getKey(), new Integer(pageId), (String)pairs.getValue()});

			    }
				if(updateBreadCrumbLinkSqlUpdate != null)
			    updateBreadCrumbLinkSqlUpdate.flush();
				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateBreadCrumbLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateBreadCrumbLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateBreadCrumbLinkNbrs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map deleteBreadCrumb(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int pageId =dbAdminInfo.getPageId();
		int linkNbr =dbAdminInfo.getLinkNbr();
		String DELETE_BREAD_CRUMB = "DELETE FROM " + getSchemaName() + ".IBRS_BREAD_CRUMBS WHERE PAGE_ID = ? AND LINK_NBR = ?";
		_LOGGER.info("Delete SQL: " + DELETE_BREAD_CRUMB);

		try {

				if(deleteBreadCrumbSqlUpdate == null) {
					deleteBreadCrumbSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_BREAD_CRUMB);
					deleteBreadCrumbSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					deleteBreadCrumbSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
					deleteBreadCrumbSqlUpdate.compile();
				}

				Object[] parameterValues = new Object[]{new Integer(pageId),new Integer(linkNbr) };

				int deleteCount = deleteBreadCrumbSqlUpdate.update(parameterValues);

				if(deleteCount > 0) {
					_LOGGER.info("Deleted Bread Crumb logged successfully \n Number of Records deleted - "+deleteCount);
					status = true;
				}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteBreadCrumb in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteBreadCrumb in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteBreadCrumb");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map selectBreadCrumb(DbAdminInfo  dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		int pageId =dbAdminInfo.getPageId();
		int linkNbr =dbAdminInfo.getLinkNbr();
		String SELECT_BREAD_CRUMB = "SELECT * FROM " + getSchemaName() + ".IBRS_BREAD_CRUMBS WHERE PAGE_ID ="+pageId+" AND LINK_NBR ="+linkNbr;

		final BreadCrumb breadCrumb = new BreadCrumb();


		_LOGGER.info("Select SQL: " + SELECT_BREAD_CRUMB);

		try
		{
			jdbcTemplate.query(SELECT_BREAD_CRUMB, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String name 			= rs.getString("NAME");
					String miscString		= rs.getString("MISC_STRING");
					String fmt 				= rs.getString("FMT");
					String type 			= rs.getString("TYPE");
					String targetPageId		= rs.getString("TARGET_PAGE_ID");
					String targetParmsId	= rs.getString("TARGET_PARMS_ID");
					String targetSubset 	= rs.getString("TARGET_SUBSET");
					int xRefSqlRefId 		= rs.getInt("XREF_SQL_ID");
					String linkType 		= rs.getString("L_TYPE");

					breadCrumb.setName(name);
					breadCrumb.setMiscString(miscString);
					breadCrumb.setFmt(fmt);
					breadCrumb.setType(type);
					breadCrumb.setTargetPageId((String)selectPageIdTitle(targetPageId).get("pageid"));
					breadCrumb.setTargetParmsId(targetParmsId);
					breadCrumb.setTargetSubset(targetSubset);
					breadCrumb.setXrefSqlId(xRefSqlRefId);
					breadCrumb.setLinkType(linkType);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectBreadCrumb in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectBreadCrumb in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectBreadCrumb");

		 responseMap.put("breadCrumb",breadCrumb);
		 return responseMap;
	}

	public Map getBreadCrumbDropDowns(DbAdminInfo  dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String schemaName = getSchemaName();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String BREAD_CRUMB_DROP_DOWN =  "(SELECT  NAME,'','','','','','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TYPE') UNION ALL (SELECT '', NAME,'','','','','',''  FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='FMT') UNION ALL (SELECT DISTINCT '','',TARGET_PARMS_ID,'','','','','' FROM " + schemaName +".IBRS_TARGET_PARMS) UNION ALL (SELECT '','','',CHAR(PAGE_ID)||'--'||TBL_TITLE,'','','','' FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" AND SECTION_NUM=0) UNION ALL (SELECT '','','','',NAME,'','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TARGET_SUBSET') UNION ALL (SELECT  '','','','','',CHAR(XREF_SQL_ID),'','' FROM " + schemaName +".IBRS_XREF_SQL) UNION ALL (SELECT DISTINCT '','','','','','',CHAR(LINK_NBR),'' FROM " + schemaName +".IBRS_BREAD_CRUMBS WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" ) UNION ALL (SELECT  '','','','','','','',NAME FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='L_TYPE')";
		_LOGGER.info("Bread Crumb Drop Down SQL: " + BREAD_CRUMB_DROP_DOWN);
		try
		{
			jdbcTemplate.query(BREAD_CRUMB_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					list.add(rs.getString(8));
					totalList.add(list);
				}
			});

			responseMap.put("breadcrumb_drop_down",totalList);
			return responseMap;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getBreadCrumbDropDowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getBreadCrumbDropDowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}
	public Map selectBreadCrumbLinkNbrs(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_BREAD_CRUMB_LINK_NBR = "SELECT NAME, LINK_NBR FROM " + getSchemaName() + ".IBRS_BREAD_CRUMBS WHERE PAGE_ID ="+dbAdminInfo.getPageId();

		final Map brdCrumbsLinkNbr = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_BREAD_CRUMB_LINK_NBR);

		try
		{
			jdbcTemplate.query(SELECT_BREAD_CRUMB_LINK_NBR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(new Integer(rs.getInt(2)));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectBreadCrumbLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectBreadCrumbLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectBreadCrumbLinkNbrs");
		brdCrumbsLinkNbr.put("order", totalList);
		return  brdCrumbsLinkNbr;
	}

		public Map getBreadCrumbLinkNbrsMap(int pageId) throws NCASException {
			String SELECT_BREAD_CRUMB_LINK_NBR = "SELECT NAME,LINK_NBR FROM " + getSchemaName() + ".IBRS_BREAD_CRUMBS WHERE PAGE_ID ="+pageId;

			final Map brdCrumbsLinkNbr = new HashMap();
			_LOGGER.info("Select SQL: " + SELECT_BREAD_CRUMB_LINK_NBR);

			try
			{
				jdbcTemplate.query(SELECT_BREAD_CRUMB_LINK_NBR, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						brdCrumbsLinkNbr.put(rs.getString(1),new Integer(rs.getInt(2)));
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("getBreadCrumbLinkNbrsMap in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("getBreadCrumbLinkNbrsMap in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting getBreadCrumbLinkNbrsMap");
			return  brdCrumbsLinkNbr;
	}

	public Map getReportsForPages(DbAdminInfo  dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List reportList = new ArrayList();
		String PageIdList = dbAdminInfo.getName();
		String schemaName = getSchemaName();
		try
		{
			String[] splitString = PageIdList.split(",");
			for(int k=0;k<splitString.length;k++) {
			final String pageId  = splitString[k];
			final List list = new ArrayList();
			String REPORTS_FOR_PAGES =  "SELECT  "+ getSchemaName() + ".PL_BVIEW_TYPE.TYPE ," + getSchemaName() + ".PL_BVIEW_TYPE.BRD_MKUP ," + getSchemaName() + ".PL_BVIEW_TYPE.LFT_MKUP ," + getSchemaName() + ".PL_BVIEW_TYPE.LFT_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.HDR_MKUP," + getSchemaName() + ".PL_BVIEW_TYPE.HDR_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.ACTION_CLS, "+ getSchemaName() + ".PL_BVIEW_TYPE.STRUCT_TYPE, "+ getSchemaName() + ".PL_BVIEW_TYPE.CT0_MKUP,"  + getSchemaName() + ".PL_BVIEW_TYPE.CT0_TBSIZE," + getSchemaName() + ".PL_BVIEW_TYPE.CT0_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT1_MKUP,"  + getSchemaName() + ".PL_BVIEW_TYPE.CT1_TBSIZE," + getSchemaName() + ".PL_BVIEW_TYPE.CT1_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT2_MKUP," + getSchemaName() + ".PL_BVIEW_TYPE.CT2_TBSIZE," + getSchemaName() + ".PL_BVIEW_TYPE.CT2_PAGINATE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT3_MKUP," + getSchemaName()  + ".PL_BVIEW_TYPE.CT3_TBSIZE," + getSchemaName() + ".PL_BVIEW_TYPE.CT3_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT4_MKUP," + getSchemaName() + getSchemaName() + ".PL_BVIEW_TYPE.CT4_TBSIZE," + getSchemaName() + ".PL_BVIEW_TYPE.CT4_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT5_MKUP ," + getSchemaName()  + getSchemaName() + ".PL_BVIEW_TYPE.CT5_TBSIZE," + getSchemaName() + ".PL_BVIEW_TYPE.CT5_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT6_MKUP, " + getSchemaName()  + getSchemaName() + ".PL_BVIEW_TYPE.CT6_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT6_PAGINATE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT7_MKUP, " + getSchemaName()  + getSchemaName() + ".PL_BVIEW_TYPE.CT7_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT7_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT8_MKUP, " + getSchemaName()  + getSchemaName() + ".PL_BVIEW_TYPE.CT8_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT8_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT9_MKUP, " + getSchemaName() + getSchemaName() + ".PL_BVIEW_TYPE.CT9_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT9_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT10_MKUP, " + getSchemaName() + getSchemaName() + ".PL_BVIEW_TYPE.CT10_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT10_PAGINATE," + getSchemaName() + ".PL_BVIEW_TYPE.CT11_MKUP," + getSchemaName() + getSchemaName() + ".PL_BVIEW_TYPE.CT11_TBSIZE, " + getSchemaName() + ".PL_BVIEW_TYPE.CT11_PAGINATE, " +getSchemaName() + ".PL_BVIEW_TYPE.PAGE_ATTR FROM  "+ schemaName +".PL_BVIEW_TYPE  WHERE  "+ schemaName +".PL_BVIEW_TYPE.PAGE_ID="+pageId+"";
			_LOGGER.info("Reports SQL: " + REPORTS_FOR_PAGES);
			jdbcTemplate.query(REPORTS_FOR_PAGES, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						String columnPrefix = "";
						List contentList  = new ArrayList();
							for(int i=0;i<BillViewConstants.NUMBER_CONTENT;i++){
								columnPrefix = "CT"+ String.valueOf(i);
								contentList.add(new PageContent(rs.getString(columnPrefix+"_TBSIZE"),rs.getString(columnPrefix+"_PAGINATE"),rs.getString(columnPrefix+"_MKUP")));
							}

							list.add(new Page(rs.getString(2),rs.getString(3),rs.getString(5),contentList,rs.getString(1),rs.getString(4),rs.getString(6),"","","","",""));
					}

				});
			   Map reportsMap = new HashMap();
			   reportsMap.put("page",list);
			   reportsMap.put("lftNav",getLftReports(pageId));
			   reportsMap.put("BrdCmb",getBrdReports(pageId));
			   reportsMap.put("pageId",(String)pageId);
			   reportList.add(reportsMap);
			}
			responseMap.put("Reports",reportList);
			return responseMap;
		}catch(Exception vamEx)
		{
			_LOGGER.debug("getReportsForPages in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getReportsForPages in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}
	public List getLftReports(String pageId) throws NCASException {
		final List reportList = new ArrayList();
		String schemaName = getSchemaName();
		try
		{
			String REPORTS_FOR_LFT =  "SELECT  " + schemaName +".IBRS_LEFT_NAVS_DEF.NAME,  " + schemaName +".IBRS_LEFT_NAVS_DEF.FMT," + schemaName +".IBRS_LEFT_NAVS_DEF.TYPE  FROM  " + schemaName +".IBRS_LEFT_NAVS_DEF  WHERE  "+ schemaName +".IBRS_LEFT_NAVS_DEF.LEFT_NAV_NBR IN ( SELECT  LEFT_NAV_NBR FROM   " + schemaName +".IBRS_LEFT_NAVS WHERE  PAGE_ID ="+pageId+")";
			_LOGGER.info("Reports SQL: " + REPORTS_FOR_LFT);
			jdbcTemplate.query(REPORTS_FOR_LFT, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						List list = new ArrayList();
						list.add(rs.getString(1));
						list.add(rs.getString(2));
						list.add(rs.getString(3));
						reportList.add(list);
					}

				});
			return reportList;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getLftReports in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getLftReports in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}
	public List getBrdReports(String pageId) throws NCASException {
		final List reportList = new ArrayList();
		String schemaName = getSchemaName();
		try
		{
			String REPORTS_FOR_BRD =  "SELECT  " + schemaName +".IBRS_BREAD_CRUMBS.NAME,  " + schemaName +".IBRS_BREAD_CRUMBS.FMT," + schemaName +".IBRS_BREAD_CRUMBS.TYPE  FROM  " + schemaName +".IBRS_BREAD_CRUMBS  WHERE  "+ schemaName +".IBRS_BREAD_CRUMBS.PAGE_ID ="+pageId+"";
			_LOGGER.info("Reports SQL: " + REPORTS_FOR_BRD);
			jdbcTemplate.query(REPORTS_FOR_BRD, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						List list = new ArrayList();
						list.add(rs.getString(1));
						list.add(rs.getString(2));
						list.add(rs.getString(3));
						reportList.add(list);
					}

				});
			return reportList;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getBrdReports in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getBrdReports in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}

	public Map insertReferenceType(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String refType =dbAdminInfo.getType();
		String refName =dbAdminInfo.getName();
		String refDesc =dbAdminInfo.getFunction();
		String INSERT_REFERENCES = "INSERT INTO " + getSchemaName() + ".IBRS_REFERENCE(REF_ID,REF_TYPE, NAME, DESCRIPTION) VALUES(?,?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_REFERENCES);

		try
		{
				if(insertReferenceSqlUpdate == null){


				insertReferenceSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_REFERENCES);
				insertReferenceSqlUpdate.declareParameter(new SqlParameter("REF_ID", Types.INTEGER));
				insertReferenceSqlUpdate.declareParameter(new SqlParameter("REF_TYPE", Types.CHAR));
				insertReferenceSqlUpdate.declareParameter(new SqlParameter("NAME", Types.CHAR));
				insertReferenceSqlUpdate.declareParameter(new SqlParameter("DESCRIPTION", Types.VARCHAR));
				insertReferenceSqlUpdate.compile();
			}
				int maxValueCalculated = 0;

				Map refIds = selectReferenceIds();
				if(refIds.values()!=null && refIds.keySet().size()>0)
				{
					maxValueCalculated = ((Integer)Collections.max(refIds.keySet())).intValue();
				}

				    maxValueCalculated++;




				Object[] parameterValues = new Object[]{new Integer(maxValueCalculated),refType,refName,refDesc};

		    	insertReferenceSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertReferenceType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertReferenceType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertReferenceType");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}



	public Map selectReferenceIds() throws NCASException {
		String SELECT_REF_ID = "SELECT REF_ID FROM " + getSchemaName() + ".IBRS_REFERENCE WITH UR";
		final Map refIds = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_REF_ID);

		try
		{
			jdbcTemplate.query(SELECT_REF_ID, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					refIds.put(new Integer(rs.getInt(1)), "refid");
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectReferenceIds in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectReferenceIds in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectReferenceIds");
		return  refIds;
	}

	public Map updateReferenceType(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String refNewName= dbAdminInfo.getName();
		String refDesc = dbAdminInfo.getFunction();
		int refId = dbAdminInfo.getStartRange();
		String UPDATE_REFERENCES = "UPDATE " + getSchemaName() + ".IBRS_REFERENCE SET NAME = ?,DESCRIPTION = ? WHERE REF_ID=?";

		_LOGGER.info("Update SQL: " + UPDATE_REFERENCES);

		try
		{
				if(updateReferenceSqlUpdate == null){


				updateReferenceSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_REFERENCES);
				updateReferenceSqlUpdate.declareParameter(new SqlParameter("NAME", Types.CHAR));
				updateReferenceSqlUpdate.declareParameter(new SqlParameter("DESCRIPTION", Types.VARCHAR));
				updateReferenceSqlUpdate.declareParameter(new SqlParameter("REF_ID", Types.INTEGER));
				updateReferenceSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{refNewName,refDesc,new Integer(refId)};

		    	updateReferenceSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateReferenceType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateReferenceType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateReferenceType");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	//TODO..This delete has to be cascaded to other tables.
	public Map deleteReferenceType(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int refId= dbAdminInfo.getStartRange();

		String DELETE_REFERENCES = "DELETE FROM " + getSchemaName() + ".IBRS_REFERENCE WHERE REF_ID=?";

		_LOGGER.info("Delete SQL: " + DELETE_REFERENCES);

		try
		{
				if(deleteReferenceSqlUpdate == null){


				deleteReferenceSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_REFERENCES);
				deleteReferenceSqlUpdate.declareParameter(new SqlParameter("REF_ID", Types.INTEGER));
				deleteReferenceSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{new Integer(refId)};

		    	deleteReferenceSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteReferenceType in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteReferenceType in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteReferenceType");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map selectReferenceNameDesc(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_REF_ID_NAME_DESC = "SELECT REF_ID,NAME,DESCRIPTION FROM " + getSchemaName() + ".IBRS_REFERENCE WHERE REF_TYPE ='"+dbAdminInfo.getType()+"'";
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		_LOGGER.info("Select SQL: " + SELECT_REF_ID_NAME_DESC);

		try
		{
			jdbcTemplate.query(SELECT_REF_ID_NAME_DESC, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectReferenceNameDesc in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectReferenceNameDesc in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		responseMap.put("refidnamedesc",totalList);
		_LOGGER.info("Exiting selectReferenceNameDesc");

		return responseMap;
	}

	public Map getReferenceTypeDropDowns() throws NCASException {
		String GET_REF_NAME = "SELECT REF_ID, NAME,DESCRIPTION FROM " + getSchemaName() + ".IBRS_REFERENCE WHERE REF_TYPE ='FMT'";
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		_LOGGER.info("Select SQL: " + GET_REF_NAME);

		try
		{
			jdbcTemplate.query(GET_REF_NAME, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getReferenceTypeDropDowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getReferenceTypeDropDowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getReferenceTypeDropDowns");
		responseMap.put("refidnamedesc",totalList);
		return responseMap;
	}

	public Map insertAdminPage(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String INSERT_ADMIN_PAGE_SQL = "INSERT INTO " + getSchemaName() + ".IBRS_PAGES(PAGE_ID,SECTION_NUM,TBL_TITLE,TITLE_SCROLL,TOTAL_SCROLL, GR_TOTAL_SCROLL, DISABLE_SCROLL,FILTER_STRING,PARENT_PAGE_ID,USER_REPORT_NAME,NBR_OF_HITS,RESTAGE_IND,USER_ID, UPDATE_DATE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Map responseMap = new HashMap();

		_LOGGER.info(" SQL: " + INSERT_ADMIN_PAGE_SQL);


		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			String updateDate = "";



				if(insertAdminPageSqlUpdate == null)
				{

					insertAdminPageSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_ADMIN_PAGE_SQL);
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("TBL_TITLE", Types.VARCHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("TITLE_SCROLL", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("TOTAL_SCROLL", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("GR_TOTAL_SCROLL", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("DISABLE_SCROLL", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("FILTER_STRING", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("PARENT_PAGE_ID", Types.INTEGER));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("USER_REPORT_NAME", Types.VARCHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("NBR_OF_HITS", Types.INTEGER));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("RESTAGE_IND", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("USER_ID", Types.CHAR));
					insertAdminPageSqlUpdate.declareParameter(new SqlParameter("UPDATE_DATE", Types.TIMESTAMP));
					insertAdminPageSqlUpdate.compile();
				}

			    List adminPageList = dbAdminInfo.getAdminPageList();
			    _LOGGER.info("size  adminPageList ->"+adminPageList.size());
			    for(int i = 0; i<adminPageList.size();i++) {
					AdminPage adminPage = (AdminPage)adminPageList.get(i);
					updateDate = adminPage.getUpdateDate();

					if(updateDate.equals(""))
					{
						updateDate = lastUpdated;
					}
		    		insertAdminPageSqlUpdate.update(new Object[]{new Integer(adminPage.getPageId()),new Integer(adminPage.getSectionNum()),adminPage.getTblTitle(),adminPage.getTitleScroll(),adminPage.getTotalScroll(),adminPage.getGrTotalScroll(),adminPage.getDisableScroll(),adminPage.getFilterString(),new Integer(adminPage.getParentPageId()),adminPage.getUserReportName(),new Integer(adminPage.getNumOfHits()),adminPage.getRestageInd(),adminPage.getUserId(),updateDate});
			    }
				if(insertAdminPageSqlUpdate != null)
			    insertAdminPageSqlUpdate.flush();

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertAdminPage in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertAdminPage in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertAdminPage");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map updateAdminPage(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String UPDATE_ADMIN_PAGE_SQL = "UPDATE " + getSchemaName() + ".IBRS_PAGES SET TBL_TITLE=?,TITLE_SCROLL=?, TOTAL_SCROLL=?, GR_TOTAL_SCROLL=?, DISABLE_SCROLL=?,FILTER_STRING=?,PARENT_PAGE_ID=?,USER_REPORT_NAME=?, RESTAGE_IND=?, UPDATE_DATE=?, USER_ID=? WHERE PAGE_ID=? AND SECTION_NUM=?";
		Map responseMap = new HashMap();

		_LOGGER.info("UPDATE ADMIN PAGE SQL: " + UPDATE_ADMIN_PAGE_SQL);


		try
		{
			    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(updateAdminPageSqlUpdate == null)
				{

					updateAdminPageSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_ADMIN_PAGE_SQL);
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("TBL_TITLE", Types.VARCHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("TITLE_SCROLL", Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("TOTAL_SCROLL", Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("GR_TOTAL_SCROLL", Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("DISABLE_SCROLL", Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("FILTER_STRING", Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("PARENT_PAGE_ID", Types.INTEGER));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("USER_REPORT_NAME", Types.VARCHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("RESTAGE_IND", Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("UPDATE_DATE",Types.TIMESTAMP));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("USER_ID",Types.CHAR));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateAdminPageSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
					updateAdminPageSqlUpdate.compile();
				}

			    List adminPageList = dbAdminInfo.getAdminPageList();


		    	Object[] parameterValues = null;

		    	if(adminPageList != null && adminPageList.size()>0){
					AdminPage adminPage  = (AdminPage)adminPageList.get(0);
		    	parameterValues = new Object[]{adminPage.getTblTitle(),adminPage.getTitleScroll(),adminPage.getTotalScroll(),adminPage.getGrTotalScroll(),adminPage.getDisableScroll(),adminPage.getFilterString(),new Integer(adminPage.getParentPageId()),adminPage.getUserReportName(),adminPage.getRestageInd(),lastUpdated,adminPage.getUserId(),new Integer(adminPage.getPageId()),new Integer(adminPage.getSectionNum())};

			    updateAdminPageSqlUpdate.update(parameterValues);

				status = true;
				}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateAdminPage in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateAdminPage in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateAdminPage");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	//TODO....This delete has to be cascaded to other tables.
	public Map deleteAdminPage(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String addAll= dbAdminInfo.getAddAll();
		boolean deleteSingle = false;

		String DELETE_ADMIN_PAGE = "DELETE FROM " + getSchemaName() + ".IBRS_PAGES WHERE PAGE_ID = ?";


		_LOGGER.info("Delete SQL: " + DELETE_ADMIN_PAGE);

		try
		{
			if(addAll.equalsIgnoreCase("ALL")){
				if(deleteAdminPageSqlUpdate == null){
				deleteAdminPageSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_ADMIN_PAGE);
				deleteAdminPageSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteAdminPageSqlUpdate.compile();
				}

				Object[] parameterValues = null;
				parameterValues = new Object[]{new Integer(dbAdminInfo.getPageId())};
				deleteAdminPageSqlUpdate.update(parameterValues);

			}else{
				deleteAdminPageSection(dbAdminInfo.getPageId(), dbAdminInfo.getStartRange());
			}

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAdminPage in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteAdminPage in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteAdminPage");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public void deleteAdminPageSection(int pageId, int  sectionNum) throws NCASException {
		boolean status = false;
		String DELETE_ADMIN_PAGE = "DELETE FROM " + getSchemaName() + ".IBRS_PAGES WHERE PAGE_ID = ? AND SECTION_NUM = ?" ;

		_LOGGER.info("Delete SQL: " + DELETE_ADMIN_PAGE);

		try
		{
				if(deleteAdminPageSectionSqlUpdate == null){
				_LOGGER.info("Yes delete Admin is null");
				deleteAdminPageSectionSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_ADMIN_PAGE);
				deleteAdminPageSectionSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteAdminPageSectionSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
				deleteAdminPageSectionSqlUpdate.compile();
			}

				Object[] parameterValues = new Object[]{new Integer(pageId),new Integer(sectionNum)};
				deleteAdminPageSectionSqlUpdate.update(parameterValues);
			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAdminPageSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteAdminPageSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteAdminPageSection");
	}

	public Map getPageIdsforApp(DbAdminInfo dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String schemaName = getSchemaName();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String ADMIN_PAGE_DROP_DOWN =  "SELECT CHAR(PAGE_ID)||'--'||TBL_TITLE FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" AND SECTION_NUM=0 ORDER BY TBL_TITLE";

		_LOGGER.info("Admin Page Drop Down SQL: " + ADMIN_PAGE_DROP_DOWN);
		try
		{
			jdbcTemplate.query(ADMIN_PAGE_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					totalList.add(list);
				}
			});

			responseMap.put("adminpage_drop_down",totalList);
			return responseMap;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getPageIdsforApp in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getPageIdsforApp in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}

	public Map getSectionNumsforPageId(DbAdminInfo dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String schemaName = getSchemaName();
		String ADMIN_SECTION_DROP_DOWN =  "SELECT SECTION_NUM FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID ="+dbAdminInfo.getPageId()+"";

		_LOGGER.info("Admin Page Drop Down SQL: " + ADMIN_SECTION_DROP_DOWN);
		try
		{
			jdbcTemplate.query(ADMIN_SECTION_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					totalList.add(list);
				}
			});

			responseMap.put("adminsection_drop_down",totalList);
			return responseMap;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getSectionNumsforPageId in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getSectionNumsforPageId in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}

	public Map getAdminPageObj(DbAdminInfo dbAdminInfo) throws NCASException {
		final Map responseMap = new HashMap();
		String schemaName = getSchemaName();
		final int pageId = dbAdminInfo.getPageId();
		final int sectionNum = dbAdminInfo.getStartRange();

		String ADMIN_PAGE_OBJ =  "SELECT TBL_TITLE, TITLE_SCROLL,TOTAL_SCROLL, GR_TOTAL_SCROLL, DISABLE_SCROLL,FILTER_STRING,PARENT_PAGE_ID,NBR_OF_HITS,USER_REPORT_NAME,RESTAGE_IND FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID = "+pageId+" AND SECTION_NUM = "+sectionNum;

		_LOGGER.info("Admin Page SQL: " + ADMIN_PAGE_OBJ);
		try
		{
			jdbcTemplate.query(ADMIN_PAGE_OBJ, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					AdminPage adminPage = new AdminPage(Integer.toString(pageId), sectionNum, rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),"",rs.getString(6),rs.getString(7),"",rs.getInt(8),rs.getString(9),rs.getString(10));
					responseMap.put("adminPage",adminPage);
				}
			});

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getAdminPageObj in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getAdminPageObj in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		return responseMap;
	}


	public Map insertSqlTable(DbAdminInfo  dbAdminInfo) throws NCASException {
			boolean status = false;

			String INSERT_SQL_TABLE = "INSERT INTO " + getSchemaName() + ".IBRS_SQL(PAGE_ID,RESULTSET_ID,SQL_TYPE,REF_NAME,SQL_TEXT) VALUES(?,?,?,?,?)";
			Map responseMap = new HashMap();

			_LOGGER.info(" INSERT_IBRS_SQL: " + INSERT_SQL_TABLE);


			try
			{

					if(insertSqlTableSqlUpdate == null)
					{

						insertSqlTableSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_SQL_TABLE);
						insertSqlTableSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
						insertSqlTableSqlUpdate.declareParameter(new SqlParameter("RESULTSET_ID", Types.INTEGER));
						insertSqlTableSqlUpdate.declareParameter(new SqlParameter("SQL_TYPE", Types.INTEGER));
						insertSqlTableSqlUpdate.declareParameter(new SqlParameter("REF_NAME", Types.CHAR));
						insertSqlTableSqlUpdate.declareParameter(new SqlParameter("SQL_TEXT", Types.VARCHAR));
						insertSqlTableSqlUpdate.compile();
					}

				    List adminHeaderList = dbAdminInfo.getAdminHeaderList();
				    _LOGGER.info("size  adminHeaderList"+adminHeaderList.size());
				    for(int i = 0; i<adminHeaderList.size();i++) {
						Header header = (Header)adminHeaderList.get(i);
			    		insertSqlTableSqlUpdate.update(new Object[]{new Integer(header.getPageId()),new Integer(header.getResultsetId()),new Integer(header.getSqlType()),header.getRefName(),header.getSqlText()});
				    }
					if(insertSqlTableSqlUpdate != null)
				    insertSqlTableSqlUpdate.flush();

					status = true;
			} catch(Exception vamEx) {
				vamEx.printStackTrace();
				_LOGGER.debug("insertSqlTable in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("insertSqlTable in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting insertSqlTable");
			 responseMap.put("status",new Boolean(status));
			 return responseMap;
		}

	public Map updateSqlTable(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String UPDATE_SQL_TABLE = "UPDATE " + getSchemaName() + ".IBRS_SQL SET SQL_TEXT=? WHERE PAGE_ID=? AND RESULTSET_ID=? AND SQL_TYPE=? AND REF_NAME=?";
		Map responseMap = new HashMap();

		_LOGGER.info("UPDATE SQL TABLE: " + UPDATE_SQL_TABLE);


		try
		{

				if(updateSqlTableSqlUpdate == null)
				{

					updateSqlTableSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_SQL_TABLE);
					updateSqlTableSqlUpdate.declareParameter(new SqlParameter("SQL_TEXT", Types.CHAR));
					updateSqlTableSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.VARCHAR));
					updateSqlTableSqlUpdate.declareParameter(new SqlParameter("RESULTSET_ID", Types.CHAR));
					updateSqlTableSqlUpdate.declareParameter(new SqlParameter("SQL_TYPE", Types.CHAR));
					updateSqlTableSqlUpdate.declareParameter(new SqlParameter("REF_NAME", Types.CHAR));
					updateSqlTableSqlUpdate.compile();
				}

			    List adminHeaderList = dbAdminInfo.getAdminHeaderList();


		    	Object[] parameterValues = null;

		    	if(adminHeaderList != null && adminHeaderList.size()>0){
					Header header  = (Header)adminHeaderList.get(0);
		    	parameterValues = new Object[]{header.getSqlText(),new Integer(header.getPageId()), new Integer(header.getResultsetId()),new Integer(header.getSqlType()),header.getRefName()};

			    updateSqlTableSqlUpdate.update(parameterValues);

				status = true;
				}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateSqlTable in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateSqlTable in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateSqlTable");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	//TODO....This delete has to be cascaded to other tables.
	public Map deleteSqlFromSqlTable(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		final Map sqlTextMap = new HashMap();

		String DELETE_SQL_TABLE = "DELETE FROM " + getSchemaName() + ".IBRS_SQL WHERE PAGE_ID = ? AND RESULTSET_ID = ? AND SQL_TYPE = ? AND REF_NAME = ?";


		_LOGGER.info("Delete SQL: " + DELETE_SQL_TABLE);

		try
		{

				if(deleteSqlTableSqlUpdate == null){
				deleteSqlTableSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_SQL_TABLE);
				deleteSqlTableSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteSqlTableSqlUpdate.declareParameter(new SqlParameter("RESULTSET_ID", Types.INTEGER));
				deleteSqlTableSqlUpdate.declareParameter(new SqlParameter("SQL_TYPE", Types.INTEGER));
				deleteSqlTableSqlUpdate.declareParameter(new SqlParameter("REF_NAME", Types.VARCHAR));
				deleteSqlTableSqlUpdate.compile();
				}

				Object[] parameterValues = null;
				parameterValues = new Object[]{new Integer(dbAdminInfo.getPageId()),new Integer(dbAdminInfo.getLinkNbr()),new Integer(dbAdminInfo.getType()),dbAdminInfo.getName()};
				deleteSqlTableSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteSqlFromSqlTable in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteSqlFromSqlTable in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteSqlFromSqlTable");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map selectSqlText(DbAdminInfo dbAdminInfo) throws NCASException {
		final Map sqlTextMap = new HashMap();

		String SELECT_SQL_TEXT = "SELECT SQL_TEXT FROM " + getSchemaName() + ".IBRS_SQL WHERE PAGE_ID="+dbAdminInfo.getPageId()+" AND RESULTSET_ID="+dbAdminInfo.getLinkNbr()+"  AND SQL_TYPE="+dbAdminInfo.getType()+" AND REF_NAME ='"+dbAdminInfo.getName()+"'";

		_LOGGER.info("Select SQL: " + SELECT_SQL_TEXT);

		try
		{
			jdbcTemplate.query(SELECT_SQL_TEXT, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String sqlText	= rs.getString("SQL_TEXT");
					sqlTextMap.put("sqlText",sqlText);

				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectSqlText in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectSqlText in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectSqlText");
		return sqlTextMap;
	}
	public Map selectSqlName(DbAdminInfo dbAdminInfo) throws NCASException {
		final Map sqlTextMap = new HashMap();
		final List totalList = new ArrayList();
		String SELECT_SQL_NAME = "SELECT REF_NAME FROM " + getSchemaName() + ".IBRS_SQL WHERE PAGE_ID="+dbAdminInfo.getPageId();

		_LOGGER.info("Select SQL: " + SELECT_SQL_NAME);

		try
		{
			jdbcTemplate.query(SELECT_SQL_NAME, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					totalList.add(rs.getString("REF_NAME"));

				}
			});
			sqlTextMap.put("sqlName",totalList);
		} catch(Exception vamEx) {
			_LOGGER.debug("selectSqlName in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectSqlName in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectSqlName");
		return sqlTextMap;
	}
	public Map selectSqlResult(DbAdminInfo dbAdminInfo) throws NCASException {
		final Map sqlTextMap = new HashMap();

		String SELECT_SQL_RESULT = "SELECT RESULTSET_ID, SQL_TYPE FROM " + getSchemaName() + ".IBRS_SQL WHERE PAGE_ID="+dbAdminInfo.getPageId()+" AND REF_NAME ='"+dbAdminInfo.getName()+"'";

		_LOGGER.info("Select SQL: " + SELECT_SQL_RESULT);

		try
		{
			jdbcTemplate.query(SELECT_SQL_RESULT, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int sqlId	= rs.getInt("RESULTSET_ID");
					String sqlName	= rs.getString("SQL_TYPE");
					sqlTextMap.put("sqlName",sqlName);
					sqlTextMap.put("sqlId",new Integer(sqlId));

				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("SELECT_SQL_RESULT in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SELECT_SQL_RESULT in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting SELECT_SQL_RESULT");
		return sqlTextMap;
	}

	public Map getHeaderRecords(DbAdminInfo  dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String schemaName = getSchemaName();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String HEADER_DROP_DOWN =  "(SELECT DISTINCT NAME,'','','','','','','','' FROM " + schemaName +".IBRS_HEADER_XREF ) UNION ALL (SELECT  '',NAME,'','','','','','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TYPE') UNION ALL (SELECT '','',CHAR(PAGE_ID)||'--'||TBL_TITLE,'','','','','',''  FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" AND SECTION_NUM=0) UNION ALL (SELECT '','','', NAME,'','','','',''  FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='FMT') UNION ALL (SELECT DISTINCT '','','','',TARGET_PARMS_ID,'','','','' FROM " + schemaName +".IBRS_TARGET_PARMS) UNION ALL (SELECT DISTINCT '','','','','',CHAR(LINK_NBR),'','','' FROM " + schemaName +".IBRS_HEADER_XREF) UNION ALL (SELECT  '','','','','','',NAME,'','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TARGET_SUBSET') UNION ALL (SELECT  DISTINCT '','','','','','','',CHAR(XREF_SQL_ID),'' FROM " + schemaName +".IBRS_XREF_SQL) UNION ALL (SELECT '','','','','','','','',NAME  FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='L_TYPE')";

		_LOGGER.info("Header Drop Down SQL: " + HEADER_DROP_DOWN);
		try
		{
			jdbcTemplate.query(HEADER_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					list.add(rs.getString(8));
					list.add(rs.getString(9));
					totalList.add(list);
				}
			});

			responseMap.put("header_drop_down",totalList);
			return responseMap;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getHeaderDropDowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getHeaderDropDowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}

		public Map getHeaderLinkNbrsMap(int pageId) throws NCASException {
			String SELECT_HEADER_LINK_NBR = "SELECT NAME,LINK_NBR FROM " + getSchemaName() + ".IBRS_HEADER_XREF WHERE PAGE_ID ="+pageId;

			final Map headerLinkNbr = new HashMap();
			_LOGGER.info("Select SQL: " + SELECT_HEADER_LINK_NBR);

			try
			{
				jdbcTemplate.query(SELECT_HEADER_LINK_NBR, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						headerLinkNbr.put(rs.getString(1),new Integer(rs.getInt(2)));
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("getHeaderLinkNbrsMap in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("getHeaderLinkNbrsMap in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting getHeaderLinkNbrsMap");
			return  headerLinkNbr;
	}

	public Map insertHeaderXrefs(DbAdminInfo dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String excelOrNot = dbAdminInfo.getDefaultFlag();
		String INSERT_HEADER_XREF_LINK = "INSERT INTO " + getSchemaName() + ".IBRS_HEADER_XREF(PAGE_ID,LINK_NBR,NAME,MISC_STRING,TYPE,FMT,TARGET_PAGE_ID,TARGET_PARMS_ID,TARGET_SUBSET,XREF_SQL_ID, SELECT_LINK,L_TYPE,D_VALUE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";

		_LOGGER.info("Insert Header SQL: " + INSERT_HEADER_XREF_LINK);

		try
		{


			List adminHeaderList = dbAdminInfo.getAdminHeaderList();
			_LOGGER.info("size  adminHeaderList"+adminHeaderList.size());
			for(int i = 0; i<adminHeaderList.size();i++)
			{
				Header header = (Header)adminHeaderList.get(i);
				int pageId = Integer.parseInt(header.getPageId());

				if(excelOrNot==null || !excelOrNot.equals("excel"))
				{
					Map curNamesLinkNbrs = getHeaderLinkNbrsMap(pageId);
					String headerElemName = header.getName();
					int latestLinkNbrValue =  header.getLinkNbr();

					_LOGGER.info("Header Element "+headerElemName+" updated Link nbr ->"+latestLinkNbrValue);

					if(curNamesLinkNbrs.containsValue(new Integer(latestLinkNbrValue)))
					{
						_LOGGER.info("Yes. The user picked an existing link number");
						Map latestNamesLinkNbrs = new TreeMap(Collections.reverseOrder());

						Iterator curIt = curNamesLinkNbrs.entrySet().iterator();
						boolean flag = true;
						while (curIt.hasNext()) {

							Map.Entry pairs = (Map.Entry)curIt.next();
							String bName = (String)pairs.getKey();
							int bLink = ((Integer)pairs.getValue()).intValue();
							if(!bName.equals(headerElemName))
							{
								if(bLink>=latestLinkNbrValue)
								{
									bLink++;

								}
								_LOGGER.info("The later links->"+bName+" - "+bLink);
							}
							latestNamesLinkNbrs.put(new Integer(bLink),bName);
						}

						updateHeaderLinkNbrs(pageId, latestNamesLinkNbrs);
					}
				}

				if(insertHeaderXrefSqlUpdate == null){


				insertHeaderXrefSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_HEADER_XREF_LINK);
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("MISC_STRING", Types.VARCHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("SELECT_LINK", Types.CHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
				insertHeaderXrefSqlUpdate.declareParameter(new SqlParameter("D_VALUE", Types.VARCHAR));
				insertHeaderXrefSqlUpdate.compile();
			}



		    		insertHeaderXrefSqlUpdate.update(new Object[]{new Integer(header.getPageId()),new Integer(header.getLinkNbr()),header.getName(), header.getMiscString()
													, header.getType(), header.getFmt(), new Integer(header.getTargetPageId())
													, header.getTargetParmsId(), header.getTargetSubset()
													, new Integer(header.getXrefSqlId()), header.getSelectLink()
													, header.getLinkType(), header.getDValue()});

			    }

				if(insertHeaderXrefSqlUpdate != null)
				insertHeaderXrefSqlUpdate.flush();

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertHeaderXrefs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertHeaderXrefs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertHeaderXrefs");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

      public Map updateHeaderLinkNbrs(int pageId, Map linkNbrName) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String UPDATE_HEADER_LINK = "UPDATE " + getSchemaName() + ".IBRS_HEADER_XREF SET LINK_NBR=? WHERE PAGE_ID = ? AND NAME = ?";

		_LOGGER.info("Update SQL: " + UPDATE_HEADER_LINK);

		try
		{
				if(updateHeaderLinkSqlUpdate == null){


				updateHeaderLinkSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_HEADER_LINK);
				updateHeaderLinkSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
				updateHeaderLinkSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				updateHeaderLinkSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));


				updateHeaderLinkSqlUpdate.compile();
			}

			    Iterator it = linkNbrName.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		    	updateHeaderLinkSqlUpdate.update(new Object[]{(Integer)pairs.getKey(), new Integer(pageId), (String)pairs.getValue()});

			    }
				if(updateHeaderLinkSqlUpdate != null)
			    updateHeaderLinkSqlUpdate.flush();
				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateHeaderLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateHeaderLinkNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateHeaderLinkNbrs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map updateHeaderXrefs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String UPDATE_HEADER_XREF_TABLE = "UPDATE " + getSchemaName() + ".IBRS_HEADER_XREF SET MISC_STRING=?, TYPE=?, FMT=?, TARGET_PAGE_ID=?, TARGET_PARMS_ID=?, TARGET_SUBSET=?, XREF_SQL_ID=?,SELECT_LINK=?,L_TYPE=?, D_VALUE=? WHERE PAGE_ID=? AND LINK_NBR=? AND NAME=?";
		Map responseMap = new HashMap();

		_LOGGER.info("UPDATE HEADER XREF TABLE: " + UPDATE_HEADER_XREF_TABLE);


		try
		{

				if(updateHeaderXrefSqlUpdate == null)
				{

					updateHeaderXrefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_HEADER_XREF_TABLE);
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("MISC_STRING", Types.VARCHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("SELECT_LINK", Types.CHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("D_VALUE", Types.VARCHAR));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("LINK_NBR", Types.INTEGER));
					updateHeaderXrefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));

					updateHeaderXrefSqlUpdate.compile();
				}

			    List adminHeaderList = dbAdminInfo.getAdminHeaderList();


		    	Object[] parameterValues = null;
				_LOGGER.info("The admin header list>"+adminHeaderList.size());
		    	if(adminHeaderList != null && adminHeaderList.size()>0){
					Header header  = (Header)adminHeaderList.get(0);
					_LOGGER.info("THE HEADER MISC STRING IS "+header.getMiscString());
					_LOGGER.info("THE HEADER PAGEID IS "+header.getPageId());
					_LOGGER.info("THE HEADER LINKNBR IS "+header.getLinkNbr());
					_LOGGER.info("THE HEADER NAME STRING IS "+header.getName());
		    	parameterValues = new Object[]{ header.getMiscString(), header.getType(), header.getFmt(), new Integer(header.getTargetPageId())
													, header.getTargetParmsId(), header.getTargetSubset(), new Integer(header.getXrefSqlId()), header.getSelectLink()
													,header.getLinkType(), header.getDValue(), new Integer(header.getPageId()),new Integer(header.getLinkNbr()),header.getName()};

			    updateHeaderXrefSqlUpdate.update(parameterValues);

				 status = true;
				}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateHeaderXrefs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateHeaderXrefs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateHeaderXrefs");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}



	public Map deleteHeaderXref(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String addAll = dbAdminInfo.getAddAll();
		boolean deleteSingle = false;

		String DELETE_HEADER_XREF_TABLE = "DELETE FROM " + getSchemaName() + ".IBRS_HEADER_XREF WHERE PAGE_ID = ?";


		_LOGGER.info("Delete HEADER XREF SQL: " + DELETE_HEADER_XREF_TABLE);

		try
		{
			if(addAll.equalsIgnoreCase("ALL"))
			{
				if(deleteHeaderXrefSqlUpdate == null){
				deleteHeaderXrefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_HEADER_XREF_TABLE);
				deleteHeaderXrefSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteHeaderXrefSqlUpdate.compile();
				}

				Object[] parameterValues = null;
				parameterValues = new Object[]{new Integer(dbAdminInfo.getPageId())};
				deleteHeaderXrefSqlUpdate.update(parameterValues);

			}else{
				deleteSingleElementFromHeaderSection(dbAdminInfo.getPageId(), dbAdminInfo.getName());
			}

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteHeaderXref in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteHeaderXref in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteHeaderXref");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public void deleteSingleElementFromHeaderSection(int pageId, String name) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		boolean deleteSingle = false;

		String DELETE_HEADER_XREF_TABLE = "DELETE FROM " + getSchemaName() + ".IBRS_HEADER_XREF WHERE PAGE_ID = ? AND NAME = ?";


		_LOGGER.info("Delete HEADER XREF SQL: " + DELETE_HEADER_XREF_TABLE);

		try
		{
				if(deleteHeaderElementXrefSqlUpdate == null){
				deleteHeaderElementXrefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_HEADER_XREF_TABLE);
				deleteHeaderElementXrefSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteHeaderElementXrefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				deleteHeaderElementXrefSqlUpdate.compile();
				}

				Object[] parameterValues = null;
				parameterValues = new Object[]{new Integer(pageId),name};
				deleteHeaderElementXrefSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteSingleElementFromHeaderSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteSingleElementFromHeaderSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteSingleElementFromHeaderSection");
	}

	public Map selectNameLinkNbrsFromHeaderXref(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_HEADER_NAME_LINK_NBR = "SELECT LINK_NBR, NAME FROM " + getSchemaName() + ".IBRS_HEADER_XREF WHERE PAGE_ID ="+dbAdminInfo.getPageId();

		final Map nameLinkNbr = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_HEADER_NAME_LINK_NBR);

		try
		{
			jdbcTemplate.query(SELECT_HEADER_NAME_LINK_NBR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					list.add(rs.getString(2));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectNameLinkNbrsFromHeaderXref in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectNameLinkNbrsFromHeaderXref in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectNameLinkNbrsFromHeaderXref");
		nameLinkNbr.put("namelinknbrs", totalList);
		return  nameLinkNbr;
	}

	public Map selectElementsFromHeaderXref(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_HEADER_XREF_ELEMENTS = "SELECT MISC_STRING, FMT, TYPE, TARGET_PAGE_ID, TARGET_PARMS_ID, TARGET_SUBSET, XREF_SQL_ID, LINK_NBR,L_TYPE, D_VALUE FROM " + getSchemaName() + ".IBRS_HEADER_XREF WHERE PAGE_ID ="+dbAdminInfo.getPageId()+ " AND NAME ='"+dbAdminInfo.getName()+"'";

		final Map headerElements = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_HEADER_XREF_ELEMENTS);

		try
		{
			jdbcTemplate.query(SELECT_HEADER_XREF_ELEMENTS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add((String)selectPageIdTitle(rs.getString(4)).get("pageid"));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(new Integer(rs.getInt(7)));
					list.add(new Integer(rs.getInt(8)));
					list.add(rs.getString(9));
					list.add(rs.getString(10));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectNamLinkNbrsFromHeaderXref in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectNamLinkNbrsFromHeaderXref in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectNamLinkNbrsFromHeaderXref");
		headerElements.put("headerelements", totalList);
		return  headerElements;
	}

	public List getXrefSqls(int startRange, int endRange) throws NCASException{
		String SELECT_XREF_SQLS_RANGE= "SELECT * FROM " + getSchemaName() + ".IBRS_XREF_SQL WHERE XREF_SQL_ID BETWEEN "+startRange+" AND "+endRange;

		final List xrefSqlIds = new ArrayList();


		_LOGGER.info("Select SQL: " + SELECT_XREF_SQLS_RANGE);

		try
		{
			jdbcTemplate.query(SELECT_XREF_SQLS_RANGE, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int xrefSqlId = rs.getInt("XREF_SQL_ID");
					xrefSqlIds.add(new Integer(xrefSqlId));
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getXrefSqls in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getXrefSqls in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getXrefSqls");

		return xrefSqlIds;
	}

	public Map insertXrefSql(DbAdminInfo dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		XrefSql xrefSql = dbAdminInfo.getXrefSql();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();
		String INSERT_XREF_SQL = "INSERT INTO " + getSchemaName() + ".IBRS_XREF_SQL(XREF_SQL_ID, NAME, SQL_TEXT,SELECT_LINK,FMT,TYPE,TARGET_PAGE_ID,TARGET_SUBSET,L_TYPE) VALUES(?,?,?,?,?,?,?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_XREF_SQL);

		try
		{
				if(insertXrefSqlUpdate == null){


				insertXrefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_XREF_SQL);
				insertXrefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.CHAR));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("SQL_TEXT", Types.VARCHAR));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("SELECT_LINK", Types.CHAR));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				insertXrefSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
				//insertXrefSqlUpdate.declareParameter(new SqlParameter("D_VALUE", Types.VARCHAR));
				insertXrefSqlUpdate.compile();
			}
				List xrefRange = getXrefSqls(startRange, endRange);

				if(xrefRange.size()>0)
				{
					_LOGGER.debug("There are existing xrefsqlids in the given range->"+startRange+" and "+endRange);
				}

				int[] xrefSqlIds = new int[xrefRange.size()];

						for (int i = 0; i < xrefRange.size(); i++)
						{
							xrefSqlIds[i] =  ((Integer)(xrefRange.get(i))).intValue();
						}

				int genXrefId = DBAdminUtil.randomNumberGenerator(startRange, endRange, xrefSqlIds);

				Object[] parameterValues = new Object[]{new Integer(genXrefId),xrefSql.getName(),
														xrefSql.getSqlText(),xrefSql.getSelectLink(),
														xrefSql.getFmt(),xrefSql.getType(),
														xrefSql.getTargetPageId(),
														xrefSql.getTargetSubset(),xrefSql.getLinkType()};

		    	insertXrefSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertXrefSql in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertXrefSql in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertXrefSql");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateXrefSql(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		XrefSql xrefSql = dbAdminInfo.getXrefSql();
		String UPDATE_XREF_SQL = "UPDATE " + getSchemaName() + ".IBRS_XREF_SQL SET NAME = ?,SQL_TEXT = ?, SELECT_LINK =?,FMT=?,TYPE=?,TARGET_PAGE_ID=?,TARGET_SUBSET=?,L_TYPE=?  WHERE XREF_SQL_ID=?";

		_LOGGER.info("Update SQL: " + UPDATE_XREF_SQL);

		try
		{
				if(updateXrefSqlUpdate == null){


				updateXrefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_XREF_SQL);
				updateXrefSqlUpdate.declareParameter(new SqlParameter("NAME", Types.CHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("SQL_TEXT", Types.VARCHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("SELECT_LINK", Types.CHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.CHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_PAGE_ID", Types.INTEGER));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("TARGET_SUBSET", Types.CHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
				updateXrefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				updateXrefSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{xrefSql.getName(),xrefSql.getSqlText(),
														xrefSql.getSelectLink(),xrefSql.getFmt(),
														xrefSql.getType(),xrefSql.getTargetPageId(),
														xrefSql.getTargetSubset(),xrefSql.getLinkType(),
														new Integer(xrefSql.getXrefSqlId())};

		    	updateXrefSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateXrefSql in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateXrefSql in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateXrefSql");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	//TODO....This delete has to be cascaded to other tables.
	public Map deleteXrefSql(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int refId= dbAdminInfo.getStartRange();
		String DELETE_XREF_SQL = "DELETE FROM " + getSchemaName() + ".IBRS_XREF_SQL WHERE XREF_SQL_ID=?";

		_LOGGER.info("Delete SQL: " + DELETE_XREF_SQL);

		try
		{
				if(deleteXrefSqlUpdate == null){


				deleteXrefSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_XREF_SQL);
				deleteXrefSqlUpdate.declareParameter(new SqlParameter("XREF_SQL_ID", Types.INTEGER));
				deleteXrefSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{new Integer(refId)};

		    	deleteXrefSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteXrefSql in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteXrefSql in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteXrefSql");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map selectXrefIdName(DbAdminInfo  dbAdminInfo) throws NCASException {
		//int startRange = dbAdminInfo.getStartRange();
		//int endRange = dbAdminInfo.getEndRange();
		String schemaName = getSchemaName();
		String SELECT_XREF_NAME = "(SELECT CHAR(XREF_SQL_ID)||'--'||NAME,'','','','','' FROM " +schemaName + ".IBRS_XREF_SQL) UNION ALL (SELECT '', NAME,'','','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='FMT') UNION ALL (SELECT  '','',NAME,'','','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TYPE') UNION ALL(SELECT '','','',CHAR(PAGE_ID)||'--'||TBL_TITLE,'','' FROM " + schemaName +".IBRS_PAGES WHERE SECTION_NUM=0) UNION ALL(SELECT  '','','','',NAME,'' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TARGET_SUBSET') UNION ALL(SELECT  '','','','','',NAME FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='L_TYPE')";
		final Map sqlIdName = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_XREF_NAME);

		try
		{
			jdbcTemplate.query(SELECT_XREF_NAME, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectXrefIdName in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectXrefIdName in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectXrefIdName");
		sqlIdName.put("sqlidname", totalList);
		return  sqlIdName;
	}

	public Map selectXrefNameSqlText(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_XREF_NAME_SQL = "SELECT SQL_TEXT,SELECT_LINK,FMT,TYPE,TARGET_PAGE_ID,TARGET_SUBSET,L_TYPE FROM " + getSchemaName() + ".IBRS_XREF_SQL WHERE XREF_SQL_ID = "+dbAdminInfo.getStartRange();

		final Map nameSqltext = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_XREF_NAME_SQL);

		try
		{
			jdbcTemplate.query(SELECT_XREF_NAME_SQL, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectXrefNameSqlText in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectXrefNameSqlText in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectXrefNameSqlText");
		nameSqltext.put("namesqltext", totalList);
		return  nameSqltext;
	}

	public Map insertTargetParms(DbAdminInfo dbAdminInfo) throws NCASException {
		String INSERT_TARGET_PARMS_SQL = "INSERT INTO  " + getSchemaName() + ".IBRS_TARGET_PARMS(TARGET_PARMS_ID, TARGET_PARMS) VALUES(?,?)";
		boolean status = false;
		Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String targetParms = dbAdminInfo.getFunction();

		_LOGGER.info("Insert SQL: " + INSERT_TARGET_PARMS_SQL);

		try
		{
				if(insertTargetParmsSqlUpdate == null){


				insertTargetParmsSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_TARGET_PARMS_SQL);
				insertTargetParmsSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				insertTargetParmsSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS", Types.VARCHAR));
				insertTargetParmsSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{name,targetParms};

		    	insertTargetParmsSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertTargetParmsSql in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertTargetParmsSql in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertTargetParmsSql");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateTargetParms(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String name = dbAdminInfo.getName();
		String targetParms = dbAdminInfo.getFunction();

		String UPDATE_TARGET_PARMS_SQL = "UPDATE " + getSchemaName() + ".IBRS_TARGET_PARMS SET TARGET_PARMS = ? WHERE TARGET_PARMS_ID=?";

		_LOGGER.info("Update SQL: " + UPDATE_TARGET_PARMS_SQL);

		try
		{
				if(updateTargetParmsSqlUpdate == null){


				updateTargetParmsSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_TARGET_PARMS_SQL);
				updateTargetParmsSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS", Types.VARCHAR));
				updateTargetParmsSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				updateTargetParmsSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{targetParms, name};

		    	updateTargetParmsSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateTargetParms in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateTargetParms in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateTargetParms");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	//TODO....This delete has to be cascaded to other tables.
	public Map deleteTargetParms(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String targetParmName = dbAdminInfo.getName();
		String DELETE_TARGET_PARMS = "DELETE FROM " + getSchemaName() + ".IBRS_TARGET_PARMS WHERE TARGET_PARMS_ID=?";

		_LOGGER.info("Delete SQL: " + DELETE_TARGET_PARMS);

		try
		{
				if(deleteTargetParmsSqlUpdate == null){
				deleteTargetParmsSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_TARGET_PARMS);
				deleteTargetParmsSqlUpdate.declareParameter(new SqlParameter("TARGET_PARMS_ID", Types.CHAR));
				deleteTargetParmsSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{targetParmName};

		    	deleteTargetParmsSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteTargetParams in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteTargetParams in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteTargetParams");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map selectTargetParms(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_TARGET_PARMS = "SELECT TARGET_PARMS FROM " + getSchemaName() + ".IBRS_TARGET_PARMS WHERE TARGET_PARMS_ID = '"+dbAdminInfo.getName()+"'";

		final Map targetParms = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_TARGET_PARMS);

		try
		{
			jdbcTemplate.query(SELECT_TARGET_PARMS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectTargetParms in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectTargetParms in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectTargetParms");
		targetParms.put("targetparms", totalList);
		return  targetParms;
	}
	public Map getTargetParamDropDowns() throws NCASException {
		String DROP_TARGET_PARMS = "SELECT TARGET_PARMS_ID FROM " + getSchemaName() + ".IBRS_TARGET_PARMS";

		final Map targetParms = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + DROP_TARGET_PARMS);

		try
		{
			jdbcTemplate.query(DROP_TARGET_PARMS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getTargetParmDropDowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getTargetParmDropDowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getTargetParmDropDowns");
		targetParms.put("targetparms", totalList);
		return  targetParms;
	}
	public Map insertLegend(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String INSERT_LEGEND_SQL = "INSERT INTO " + getSchemaName() + ".IBRS_LEGENDS(PAGE_ID,SECTION_NUM,LINE_NUM,FMT,LEGEND_TEXT) VALUES(?,?,?,?,?)";
		Map responseMap = new HashMap();

		_LOGGER.info(" SQL: " + INSERT_LEGEND_SQL);


		try
		{

				if(insertLegendSqlUpdate == null)
				{

					insertLegendSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_LEGEND_SQL);
					insertLegendSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					insertLegendSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
					insertLegendSqlUpdate.declareParameter(new SqlParameter("LINE_NUM", Types.INTEGER));
					insertLegendSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
					insertLegendSqlUpdate.declareParameter(new SqlParameter("LEGEND_TEXT", Types.VARCHAR));
					insertLegendSqlUpdate.compile();
				}

			    List adminLegendList = dbAdminInfo.getAdminLegendList();
			    _LOGGER.info("size  adminLegendList"+adminLegendList.size());
			    for(int i = 0; i<adminLegendList.size();i++) {
					Legend legend = (Legend)adminLegendList.get(i);
		    		insertLegendSqlUpdate.update(new Object[]{new Integer(legend.getPageId()),new Integer(legend.getSectionNum()),new Integer(legend.getLineNum()),legend.getFmt(),legend.getLegendText()});
			    }
				if(insertLegendSqlUpdate != null)
			    insertLegendSqlUpdate.flush();

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertLegend in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertLegend in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertLegend");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map updateLegend(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String UPDATE_LEGEND_SQL = "UPDATE " + getSchemaName() + ".IBRS_LEGENDS SET FMT=?, LEGEND_TEXT=? WHERE PAGE_ID=? AND SECTION_NUM=? AND LINE_NUM=?";
		Map responseMap = new HashMap();

		_LOGGER.info("UPDATE ADMIN LEGEND SQL: " + UPDATE_LEGEND_SQL);


		try
		{

				if(updateLegendSqlUpdate == null)
				{

					updateLegendSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_LEGEND_SQL);
					updateLegendSqlUpdate.declareParameter(new SqlParameter("FMT", Types.CHAR));
					updateLegendSqlUpdate.declareParameter(new SqlParameter("LEGEND_TEXT", Types.VARCHAR));
					updateLegendSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateLegendSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
					updateLegendSqlUpdate.declareParameter(new SqlParameter("LINE_NUM", Types.INTEGER));
					updateLegendSqlUpdate.compile();
				}

			    List adminLegendList = dbAdminInfo.getAdminLegendList();


		    	Object[] parameterValues = null;

		    	if(adminLegendList != null && adminLegendList.size()>0){
					Legend adminLegend  = (Legend)adminLegendList.get(0);
		    	parameterValues = new Object[]{adminLegend.getFmt(),adminLegend.getLegendText(),new Integer(adminLegend.getPageId()),new Integer(adminLegend.getSectionNum()),new Integer(adminLegend.getLineNum())};

			    updateLegendSqlUpdate.update(parameterValues);

				status = true;
				}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateLegend in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateLegend in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateLegend");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	//TODO....This delete has to be cascaded to other tables.
	public Map deleteLegend(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String addAll= dbAdminInfo.getAddAll();
		boolean deleteSingle = false;

		String DELETE_LEGENDS_PAGE = "DELETE FROM " + getSchemaName() + ".IBRS_LEGENDS WHERE PAGE_ID = ? AND SECTION_NUM = ?";


		_LOGGER.info("Delete SQL: " + DELETE_LEGENDS_PAGE);

		try
		{
			if(addAll.equalsIgnoreCase("ALL")){
				if(deleteLegendPageSqlUpdate == null){
				deleteLegendPageSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_LEGENDS_PAGE);
				deleteLegendPageSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteLegendPageSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
				deleteLegendPageSqlUpdate.compile();
				}

				Object[] parameterValues = null;
				parameterValues = new Object[]{new Integer(dbAdminInfo.getPageId()),new Integer(dbAdminInfo.getStartRange())};
				deleteLegendPageSqlUpdate.update(parameterValues);

			}else{
				deleteLegendSectionLineNum(dbAdminInfo.getPageId(), dbAdminInfo.getStartRange(), dbAdminInfo.getEndRange());
			}

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLegend in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLegend in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteLegend");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public void deleteLegendSectionLineNum(int pageId, int  sectionNum, int lineNum) throws NCASException {
		boolean status = false;
		String DELETE_LEGEND_PAGE_SECTION = "DELETE FROM " + getSchemaName() + ".IBRS_LEGENDS WHERE PAGE_ID = ? AND SECTION_NUM = ? AND LINE_NUM = ?" ;

		_LOGGER.info("Delete SQL: " + DELETE_LEGEND_PAGE_SECTION);

		try
		{
				if(deleteLegendPageSectionSqlUpdate == null){
				_LOGGER.info("Yes it is a single delete of linenum ->"+lineNum);
				deleteLegendPageSectionSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_LEGEND_PAGE_SECTION);
				deleteLegendPageSectionSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteLegendPageSectionSqlUpdate.declareParameter(new SqlParameter("SECTION_NUM", Types.INTEGER));
				deleteLegendPageSectionSqlUpdate.declareParameter(new SqlParameter("LINE_NUM", Types.INTEGER));
				deleteLegendPageSectionSqlUpdate.compile();
			}

				Object[] parameterValues = new Object[]{new Integer(pageId),new Integer(sectionNum),new Integer(lineNum)};
				deleteLegendPageSectionSqlUpdate.update(parameterValues);
			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLegendSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLegendSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteLegendSection");
	}

	public Map selectLegendLineNum(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_LEGEND_DTLS = "SELECT LINE_NUM FROM " + getSchemaName() + ".IBRS_LEGENDS WHERE PAGE_ID ="+dbAdminInfo.getPageId()+" AND SECTION_NUM="+dbAdminInfo.getStartRange();

		final Map lineNums = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_LEGEND_DTLS);

		try
		{
			jdbcTemplate.query(SELECT_LEGEND_DTLS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLegendLineNum in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLegendLineNum in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLegendLineNum");
		lineNums.put("lgNums", totalList);
		return  lineNums;
	}


	public Map selectLegendDetails(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_LEGEND_DTLS = "SELECT FMT, LEGEND_TEXT FROM " + getSchemaName() + ".IBRS_LEGENDS WHERE PAGE_ID ="+dbAdminInfo.getPageId()+" AND SECTION_NUM="+dbAdminInfo.getStartRange()+ " AND LINE_NUM="+dbAdminInfo.getEndRange();

		final Map legendDetails = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_LEGEND_DTLS);

		try
		{
			jdbcTemplate.query(SELECT_LEGEND_DTLS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLegendDetails in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLegendDetails in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLegendDetails");
		legendDetails.put("legenddetails", totalList);
		return  legendDetails;
	}

	public Map selectLegendSectionNum(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_LEGEND_SECTION = "SELECT DISTINCT SECTION_NUM FROM " + getSchemaName() + ".IBRS_PAGES WHERE PAGE_ID ="+dbAdminInfo.getPageId();

		final Map sectionnums = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_LEGEND_SECTION);

		try
		{
			jdbcTemplate.query(SELECT_LEGEND_SECTION, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectLegendSectionNum in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectLegendSectionNum in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectLegendSectionNum");
		sectionnums.put("lgNums", totalList);
		return  sectionnums;
	}

	public Map insertScrollDefs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String INSERT_SCROLLS_SQL = "INSERT INTO " + getSchemaName() + ".IBRS_SCROLL_DEFS(PAGE_ID,CURSOR_NBR,COLUMN_NBR,COL_NAME,COL_HEADING,DATATYPE_HDG,DATATYPE_DTL,DATATYPE_TOT,DATATYPE_GRT,FMT_HDG,FMT_DTL,FMT_TOT,FMT_GRT,SORTABLE,FILTERABLE, COL_FILTER,L_TYPE,D_VALUE,VISIBLE,RESTRICT_COLUMN) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Map responseMap = new HashMap();
		String excelOrNot = dbAdminInfo.getDefaultFlag();

		_LOGGER.info(" SQL: " + INSERT_SCROLLS_SQL);


		try
		{

				if(insertScrollSqlUpdate == null)
				{

					insertScrollSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),INSERT_SCROLLS_SQL);
					insertScrollSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("CURSOR_NBR",  Types.INTEGER));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("COLUMN_NBR",  Types.INTEGER));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("COL_NAME",  Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("COL_HEADING",  Types.VARCHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_HDG", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_DTL", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_TOT", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_GRT", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("FMT_HDG", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("FMT_DTL", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("FMT_TOT", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("FMT_GRT", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("SORTABLE", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("FILTERABLE", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("D_VALUE", Types.VARCHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("COL_FILTER", Types.VARCHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("VISIBLE", Types.CHAR));
					insertScrollSqlUpdate.declareParameter(new SqlParameter("RESTRICT_COLUMN", Types.CHAR));
					insertScrollSqlUpdate.compile();
				}

			    List adminScrollList = dbAdminInfo.getAdminScrollList();
			    _LOGGER.info("size  adminScrollList"+adminScrollList.size());
			    for(int i = 0; i<adminScrollList.size();i++) {
					Scroll scroll = (Scroll)adminScrollList.get(i);
					if(excelOrNot==null || !excelOrNot.equals("excel"))
					{
						List curColNbrs = getScrollCurrentColNbrs(Integer.parseInt(scroll.getPageId()),scroll.getCursorNum());
						int selectedColNbr = scroll.getColumnNum();
						if(curColNbrs.contains(new Integer(selectedColNbr)))
						{
							_LOGGER.info("The selected cursor's column number is already taken. Adjusting the present column numbers");
							adjustScrollCursorColNbrs(Integer.parseInt(scroll.getPageId()), scroll.getCursorNum(),selectedColNbr,curColNbrs,0);
						}
					}
		    		insertScrollSqlUpdate.update(new Object[]{new Integer(scroll.getPageId()),new Integer(scroll.getCursorNum()),new Integer(scroll.getColumnNum()),scroll.getColumnName(),scroll.getColHeading(),scroll.getDataTypeHdg(),scroll.getDataTypeDtl(), scroll.getDataTypeTot(), scroll.getDataTypeGrt(), scroll.getFmtTypeHdg(), scroll.getFmtTypeDtl(),scroll.getFmtTypeTot(),scroll.getFmtTypeGrt(),scroll.getSortable(), scroll.getFilterable(), scroll.getColFilter(),scroll.getLinkType(),scroll.getDValue(),scroll.getVisible(),scroll.getRestrictCol()});
			    }
				if(insertScrollSqlUpdate != null)
			    insertScrollSqlUpdate.flush();

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertScrollDefs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertScrollDefs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertScrollDefs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public void adjustScrollCursorColNbrs(int pageId,int cursorNbr, int selectedColNbr, List curColNbrs,int oldVal) throws NCASException{
		_LOGGER.info("Entering adjustScrollCursors");
			Map oldLatestColNbrs = new TreeMap(Collections.reverseOrder());
			Map curColNamesNbrs = getScrollCurrentColNbrsNames(pageId, cursorNbr);

			_LOGGER.info("selectedColNbr -> "+selectedColNbr);
			_LOGGER.info("old value ->"+oldVal);
			try{
				for(int i = 0; i<curColNbrs.size();i++)
			   {
				int curColNbrVal = ((Integer)curColNbrs.get(i)).intValue();
				_LOGGER.info("curColNbrVal ->"+curColNbrVal);
				int latestColNbrVal = 0;
				if(oldVal==0)
				{
					_LOGGER.debug("This is an INSERT");
					latestColNbrVal = curColNbrVal +1;
					_LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+latestColNbrVal);
					oldLatestColNbrs.put(curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(latestColNbrVal));

				}
				else if(oldVal>selectedColNbr)
				{
					//This means the link is moving up.
					if(curColNbrVal>=selectedColNbr && curColNbrVal<oldVal){
					latestColNbrVal = curColNbrVal +1;
					_LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+latestColNbrVal);
					oldLatestColNbrs.put(curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(latestColNbrVal));
					}else if(curColNbrVal>=selectedColNbr && curColNbrVal==oldVal){
						_LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+selectedColNbr);
						oldLatestColNbrs.put(curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(selectedColNbr));
					}
					else{
					 _LOGGER.info("Old value -> "+curColNbrVal+" - New value ->"+curColNbrVal);
 					 oldLatestColNbrs.put((String)curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(curColNbrVal));
					}
				}
				else if(oldVal<selectedColNbr)
				{
					//This means the link is moving down.
					if(curColNbrVal<=selectedColNbr && curColNbrVal>oldVal){
					latestColNbrVal = curColNbrVal - 1;
					_LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+latestColNbrVal);
					oldLatestColNbrs.put(curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(latestColNbrVal));
					}
					else if(curColNbrVal<=selectedColNbr && curColNbrVal==oldVal){
						_LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+selectedColNbr);
						oldLatestColNbrs.put(curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(selectedColNbr));
					}
					else{
					 _LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+curColNbrVal);
 					 oldLatestColNbrs.put((String)curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(curColNbrVal));
					}
				}
				else{
					 _LOGGER.debug("Old value -> "+curColNbrVal+" - New value ->"+curColNbrVal);
 					 oldLatestColNbrs.put((String)curColNamesNbrs.get(new Integer(curColNbrVal)),  new Integer(curColNbrVal));
				}

			   }
			    _LOGGER.info("Update Scroll Cursor Column Numbers getting called");
		         updateScrollCursorColNbrs(pageId, cursorNbr,oldLatestColNbrs);

				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.debug("adjustScrollCursorColNbrs in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("adjustScrollCursorColNbrs in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
				}
		_LOGGER.info("Exiting adjustScrollCursorColNbrs");
	}

	public Map updateScrollCursorColNbrs(int pageId,int cursorNbr, Map oldLatestColNbrs) throws NCASException {
		String UPDATE_SCROLL_CUR_SQL = "UPDATE " + getSchemaName() + ".IBRS_SCROLL_DEFS SET COLUMN_NBR=? WHERE PAGE_ID =? AND CURSOR_NBR=? AND COL_NAME=?";
		boolean status = false;
		Map responseMap = new HashMap();

		_LOGGER.info("Update SQL: " + UPDATE_SCROLL_CUR_SQL);

		try
		{
				if(updateScrollCursorLinkSqlUpdate == null){


				updateScrollCursorLinkSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_SCROLL_CUR_SQL);
				updateScrollCursorLinkSqlUpdate.declareParameter(new SqlParameter("COLUMN_NBR", Types.INTEGER));
				updateScrollCursorLinkSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				updateScrollCursorLinkSqlUpdate.declareParameter(new SqlParameter("CURSOR_NBR", Types.INTEGER));
				updateScrollCursorLinkSqlUpdate.declareParameter(new SqlParameter("COL_NAME", Types.CHAR));

				updateScrollCursorLinkSqlUpdate.compile();
			}

			    Iterator it = oldLatestColNbrs.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		        _LOGGER.debug("########NEW COL NUM:"+(Integer)pairs.getValue()+"::WHERE COL NAME::"+(String)pairs.getKey());
		    	updateScrollCursorLinkSqlUpdate.update(new Object[]{(Integer)pairs.getValue(), new Integer(pageId), new Integer(cursorNbr),(String)pairs.getKey()});

			    }
				if(updateScrollCursorLinkSqlUpdate != null)
			    updateScrollCursorLinkSqlUpdate.flush();
				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateScrollCursorColNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateScrollCursorColNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateScrollCursorColNbrs");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}





	public Map updateScrollDefs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;

		String UPDATE_SCROLL_SQL = "UPDATE " + getSchemaName() + ".IBRS_SCROLL_DEFS SET COL_HEADING=?,DATATYPE_HDG=?,DATATYPE_DTL=?, DATATYPE_TOT=?, DATATYPE_GRT=?,FMT_HDG=?, FMT_DTL=?, FMT_TOT=?,FMT_GRT=?,SORTABLE=?, FILTERABLE=?, COL_FILTER=?,L_TYPE=?,D_VALUE=?,VISIBLE=?,RESTRICT_COLUMN=? WHERE PAGE_ID=? AND CURSOR_NBR=? AND COL_NAME=?";
		Map responseMap = new HashMap();
		_LOGGER.info("UPDATE SCROLL DEFS SQL: " + UPDATE_SCROLL_SQL);


		try
		{

				if(updateScrollSqlUpdate == null)
				{

					updateScrollSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_SCROLL_SQL);
					updateScrollSqlUpdate.declareParameter(new SqlParameter("COL_HEADING",  Types.VARCHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_HDG", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_DTL", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_TOT", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("DATATYPE_GRT", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("FMT_HDG", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("FMT_DTL", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("FMT_TOT", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("FMT_GRT", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("SORTABLE", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("FILTERABLE", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("COL_FILTER", Types.VARCHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("L_TYPE", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("D_VALUE", Types.VARCHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("VISIBLE", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("RESTRICT_COLUMN", Types.CHAR));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("CURSOR_NBR",  Types.INTEGER));
					updateScrollSqlUpdate.declareParameter(new SqlParameter("COL_NAME",  Types.CHAR));
					updateScrollSqlUpdate.compile();
				}

			    List adminScrollList = dbAdminInfo.getAdminScrollList();


		    	Object[] parameterValues = null;

		    	if(adminScrollList != null && adminScrollList.size()>0){
				Scroll scroll  = (Scroll)adminScrollList.get(0);
				List curColNbrs = getScrollCurrentColNbrs(Integer.parseInt(scroll.getPageId()),scroll.getCursorNum());
				Map curColNamesNbrs = getScrollCurrentColumnNamesNbrs(Integer.parseInt(scroll.getPageId()),scroll.getCursorNum());

				Integer oldVal = (Integer)curColNamesNbrs.get(scroll.getColumnName());

				int oldValue = 0;
				if(oldVal!=null)
				{
					oldValue = oldVal.intValue();
				}
				_LOGGER.info("OLD VALUE IS ::::::"+oldValue);
				_LOGGER.info("PICKED VALUE IS :::::"+scroll.getColumnNum());
				if(oldValue != scroll.getColumnNum())
				{
					if(curColNamesNbrs.containsValue(new Integer(scroll.getColumnNum())))
					{
						_LOGGER.info("This column number is already taken");
						adjustScrollCursorColNbrs(Integer.parseInt(scroll.getPageId()),scroll.getCursorNum(),scroll.getColumnNum(),curColNbrs,oldValue);
					}
					//insertScrollDefs(dbAdminInfo);
				}else{
		    	parameterValues = new Object[]{scroll.getColHeading(),scroll.getDataTypeHdg(),scroll.getDataTypeDtl(), scroll.getDataTypeTot(), scroll.getDataTypeGrt(), scroll.getFmtTypeHdg(), scroll.getFmtTypeDtl(),scroll.getFmtTypeTot(),scroll.getFmtTypeGrt(),scroll.getSortable(), scroll.getFilterable(),scroll.getColFilter(),scroll.getLinkType(),scroll.getDValue(),scroll.getVisible(),scroll.getRestrictCol(),new Integer(scroll.getPageId()),new Integer(scroll.getCursorNum()),scroll.getColumnName()};
			    updateScrollSqlUpdate.update(parameterValues);
				}
				 status = true;
				}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateScrollDefs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateScrollDefs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateScrollDefs");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	//TODO....This delete has to be cascaded to other tables.
	public Map deleteScrollDefs(DbAdminInfo  dbAdminInfo) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String addAll= dbAdminInfo.getAddAll();
		boolean deleteSingle = false;

		String DELETE_SCROLLS_PAGE = "DELETE FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID = ?";


		_LOGGER.info("Delete SQL: " + DELETE_SCROLLS_PAGE);

		try
		{
			int pageId = dbAdminInfo.getPageId();
			if(addAll.equalsIgnoreCase("ALL")){
				if(deleteScrollSqlUpdate == null){
				deleteScrollSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_SCROLLS_PAGE);
				deleteScrollSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteScrollSqlUpdate.compile();
				}



				Object[] parameterValues = null;
				parameterValues = new Object[]{new Integer(pageId)};
				deleteScrollSqlUpdate.update(parameterValues);

			}else{
				  int tableId = dbAdminInfo.getStartRange();

				  if(dbAdminInfo.getLinkNbr()==0)
				  {
					 _LOGGER.info("On the page:"+pageId+" and this table:"+tableId+" is being deleted");
					deleteScrollCursor(pageId, tableId);
				}else
				{
					int columnNbr = dbAdminInfo.getLinkNbr();
					_LOGGER.info("On the page:"+pageId+" and this table:"+tableId+" and this Column#:"+columnNbr+" is being deleted");
					deleteScrollCursorColumn(pageId,tableId,columnNbr);
				}
			}

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteScroll in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteScroll in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteScroll");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public void deleteScrollCursor(int pageId, int  cursorNum) throws NCASException {
		boolean status = false;
		String DELETE_SCROLL_PAGE_SECTION = "DELETE FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID = ? AND CURSOR_NBR = ?" ;

		_LOGGER.info("Delete SQL: " + DELETE_SCROLL_PAGE_SECTION);

		try
		{
				if(deleteScrollCursorSqlUpdate == null){
				deleteScrollCursorSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_SCROLL_PAGE_SECTION);
				deleteScrollCursorSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteScrollCursorSqlUpdate.declareParameter(new SqlParameter("CURSOR_NBR", Types.INTEGER));
				deleteScrollCursorSqlUpdate.compile();
				}

				Object[] parameterValues = new Object[]{new Integer(pageId),new Integer(cursorNum)};
				deleteScrollCursorSqlUpdate.update(parameterValues);
			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteScrollCursor in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteScrollCursor in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteScrollCursor");
	}

	public Map deleteScrollCursorColumn(int pageId, int cursorNum, int columnNum) throws NCASException {
		boolean status = false;
		final Map responseMap = new HashMap();
		String DELETE_SCROLL_CURSOR_COLUMN = "DELETE FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID = ? AND CURSOR_NBR = ? AND COLUMN_NBR=?" ;

		_LOGGER.info("Delete SQL: " + DELETE_SCROLL_CURSOR_COLUMN);

		try
		{
				if(deleteScrollCursorColSqlUpdate == null){
				deleteScrollCursorColSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_SCROLL_CURSOR_COLUMN);
				deleteScrollCursorColSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				deleteScrollCursorColSqlUpdate.declareParameter(new SqlParameter("CURSOR_NBR", Types.INTEGER));
				deleteScrollCursorColSqlUpdate.declareParameter(new SqlParameter("COLUMN_NBR", Types.INTEGER));
				deleteScrollCursorColSqlUpdate.compile();
				}

				Object[] parameterValues = new Object[]{new Integer(pageId),new Integer(cursorNum),new Integer(columnNum)};
				deleteScrollCursorColSqlUpdate.update(parameterValues);
			    status = true;

			    reorderScrollCursorCols(pageId,cursorNum,columnNum);

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteScrollCursorColumn in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteScrollCursorColumn in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteScrollCursorColumn");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public void reorderScrollCursorCols(int pageId, int cursorNum,int columnNum) throws NCASException {
		boolean status = false;
		String UPDATE_SCROLL_CURSOR_COLNUM = "UPDATE "+getSchemaName()+".IBRS_SCROLL_DEFS SET COLUMN_NBR=? WHERE PAGE_ID=? AND CURSOR_NBR=? AND COL_NAME=?";
		_LOGGER.info("Update SQL: " + UPDATE_SCROLL_CURSOR_COLNUM);
		try{
			Map curColNamesNbrs = getScrollCurrentColumnNamesNbrs(pageId, cursorNum);

		    Iterator it = curColNamesNbrs.entrySet().iterator();

		    Map latestColNameNbrs = new HashMap();
			while (it.hasNext())
			{
				Map.Entry pairs = (Map.Entry)it.next();
				String colName = (String)pairs.getKey();
				int curColNbr = ((Integer)pairs.getValue()).intValue();
				if(curColNbr>columnNum)
				{
					_LOGGER.info("The curColNbr for colName "+colName+" is "+curColNbr);
					curColNbr = curColNbr - 1;
					_LOGGER.info("The new colnbr for colName "+colName+" is "+curColNbr);
					latestColNameNbrs.put(colName,new Integer(curColNbr));
				}
			}

				if(updateCursorColNbrSqlUpdate == null)
				{

					updateCursorColNbrSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(),UPDATE_SCROLL_CURSOR_COLNUM);
					updateCursorColNbrSqlUpdate.declareParameter(new SqlParameter("COLUMN_NBR", Types.INTEGER));
					updateCursorColNbrSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateCursorColNbrSqlUpdate.declareParameter(new SqlParameter("CURSOR_NBR", Types.INTEGER));
					updateCursorColNbrSqlUpdate.declareParameter(new SqlParameter("COL_NAME", Types.VARCHAR));
					updateCursorColNbrSqlUpdate.compile();
				}

			    Iterator it2 = latestColNameNbrs.entrySet().iterator();

			    while (it2.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it2.next();
		    	updateCursorColNbrSqlUpdate.update(new Object[]{(Integer)pairs.getValue(),new Integer(pageId),new Integer(cursorNum),(String)pairs.getKey()});
			    }
				if(updateCursorColNbrSqlUpdate != null)
			    updateCursorColNbrSqlUpdate.flush();

				status = true;

		}catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("reorderScrollCursorCols in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("reorderScrollCursorCols in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting reorderScrollCursorCols");
	}

	public Map selectScrollColName(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_SCROLL_DTLS = "SELECT COL_NAME FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+dbAdminInfo.getPageId()+" AND CURSOR_NBR="+dbAdminInfo.getStartRange();

		final Map colNames = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_SCROLL_DTLS);

		try
		{
			jdbcTemplate.query(SELECT_SCROLL_DTLS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectScrollColName in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectScrollColName in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectScrollColName");
		colNames.put("colnames", totalList);
		return  colNames;
	}


	public Map selectScrollDetails(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_SCROLL_DTLS = "SELECT COLUMN_NBR,COL_HEADING,DATATYPE_HDG,DATATYPE_DTL,DATATYPE_TOT,DATATYPE_GRT,FMT_HDG,FMT_DTL,FMT_TOT,FMT_GRT,SORTABLE,FILTERABLE,COL_FILTER,L_TYPE,D_VALUE,VISIBLE,RESTRICT_COLUMN FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+dbAdminInfo.getPageId()+" AND CURSOR_NBR="+dbAdminInfo.getStartRange()+ " AND COL_NAME='"+dbAdminInfo.getName()+"'";

		final Map scrollDetails = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_SCROLL_DTLS);

		try
		{
			jdbcTemplate.query(SELECT_SCROLL_DTLS, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					list.add(rs.getString(8));
					list.add(rs.getString(9));
					list.add(rs.getString(10));
					list.add(rs.getString(11));
					list.add(rs.getString(12));
					list.add(rs.getString(13));
					list.add(rs.getString(14));
					list.add(rs.getString(15));
					list.add(rs.getString(16));
					list.add(rs.getString(17));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectScrollDetails in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectScrollDetails in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectScrollDetails");
		scrollDetails.put("scrolldetails", totalList);
		return  scrollDetails;
	}

	public Map selectScrollCursorNum(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_SCROLL_CURSOR = "SELECT DISTINCT CURSOR_NBR FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+dbAdminInfo.getPageId();

		final Map cursornums = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_SCROLL_CURSOR);

		try
		{
			jdbcTemplate.query(SELECT_SCROLL_CURSOR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(new Integer(rs.getInt(1)));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectScrollCursorNum in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectScrollCursorNum in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectScrollCursorNum");
		cursornums.put("cursornums", totalList);
		return  cursornums;
	}

	public Map selectScrollColNum(DbAdminInfo  dbAdminInfo) throws NCASException {
		String SELECT_SCROLL_CUR_COL = "SELECT COL_NAME||'--'||CHAR(COLUMN_NBR) FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+dbAdminInfo.getPageId()+ " AND CURSOR_NBR="+dbAdminInfo.getStartRange();

		final Map colnums = new HashMap();
		final List totalList = new ArrayList();

		_LOGGER.info("Select SQL: " + SELECT_SCROLL_CUR_COL);

		try
		{
			jdbcTemplate.query(SELECT_SCROLL_CUR_COL, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					totalList.add(list);
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("selectScrollColNum in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("selectScrollColNum in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting selectScrollColNum");
		colnums.put("colnums", totalList);
		return  colnums;
	}

	public Map getScrollResults(DbAdminInfo  dbAdminInfo) throws NCASException {
		Map responseMap = new HashMap();
		final List totalList = new ArrayList();
		String schemaName = getSchemaName();
		int startRange = dbAdminInfo.getStartRange();
		int endRange = dbAdminInfo.getEndRange();

		String SCROLL_DROP_DOWN = "(SELECT CHAR(PAGE_ID)||'--'||TBL_TITLE, '' , '','' FROM " + schemaName +".IBRS_PAGES WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange+" AND SECTION_NUM=0) UNION ALL (SELECT '', NAME, '','' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='FMT') UNION ALL (SELECT '', '', NAME,'' FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='TYPE') UNION ALL (SELECT  '','','',NAME FROM " + schemaName +".IBRS_REFERENCE WHERE REF_TYPE='L_TYPE')";
		_LOGGER.info("getScrollResults SQL: " + SCROLL_DROP_DOWN);
		try
		{
			jdbcTemplate.query(SCROLL_DROP_DOWN, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					List list = new ArrayList();
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					totalList.add(list);
				}
			});

			responseMap.put("scroll_drop_down",totalList);
			return responseMap;

		}catch(Exception vamEx)
		{
			_LOGGER.debug("getScrollResults in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getScrollResults in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
	}

	public List getScrollCurrentColNbrs(int pageId, int cursorNbr) throws NCASException {
		String SELECT_SCROLL_COLUMN_NBR = "SELECT COLUMN_NBR FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+pageId+" AND CURSOR_NBR="+cursorNbr;

		final List cursorColNbrs = new ArrayList();
		_LOGGER.info("Select SQL: " + SELECT_SCROLL_COLUMN_NBR);

		try
		{
			jdbcTemplate.query(SELECT_SCROLL_COLUMN_NBR, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					cursorColNbrs.add(new Integer(rs.getInt(1)));
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getScrollCurrentColNbrs in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getScrollCurrentColNbrs in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getScrollCurrentColNbrs");
		return  cursorColNbrs;
	}

	public Map getScrollCurrentColNbrsNames(int pageId, int cursorNbr) throws NCASException {
		String SELECT_SCROLL_COLUMN_NBR_NAME = "SELECT COL_NAME,COLUMN_NBR FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+pageId+" AND CURSOR_NBR="+cursorNbr;

		final Map cursorColNbrsNames = new HashMap();
		_LOGGER.info("Select SQL: " + SELECT_SCROLL_COLUMN_NBR_NAME);

		try
		{
			jdbcTemplate.query(SELECT_SCROLL_COLUMN_NBR_NAME, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					cursorColNbrsNames.put(new Integer(rs.getInt(2)),rs.getString(1).trim());
				}
			});
		} catch(Exception vamEx) {
			_LOGGER.debug("getScrollCurrentColNbrsNames in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getScrollCurrentColNbrsNames in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getScrollCurrentColNbrsNames");
		return  cursorColNbrsNames;
	}

		public Map getScrollCurrentColumnNamesNbrs(int pageId, int cursorNbr) throws NCASException {
			String SELECT_SCROLL_COLUMN_NAME_NBR = "SELECT COL_NAME,COLUMN_NBR FROM " + getSchemaName() + ".IBRS_SCROLL_DEFS WHERE PAGE_ID ="+pageId+" AND CURSOR_NBR="+cursorNbr;
			final Map cursorColNamesNbrs = new TreeMap(Collections.reverseOrder());

			_LOGGER.info("Select SQL: " + SELECT_SCROLL_COLUMN_NAME_NBR);

			try
			{
				jdbcTemplate.query(SELECT_SCROLL_COLUMN_NAME_NBR, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						cursorColNamesNbrs.put(rs.getString(1).trim(),new Integer(rs.getInt(2)));
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("getScrollCurrentColumnNamesNbrs in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("getScrollCurrentColumnNamesNbrs in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting getScrollCurrentColumnNamesNbrs");
			return  cursorColNamesNbrs;
	}


		public Map clearCache(DbAdminInfo dbAdminInfo) throws NCASException
		{
				boolean status = false;
				final Map responseMap = new HashMap();
				int pageId = dbAdminInfo.getPageId();
				String acctId = dbAdminInfo.getName();
				String userId = dbAdminInfo.getAddAll();
				StringBuffer whereClause = new StringBuffer();

				if(pageId != -1)
				{
					whereClause.append(" WHERE PAGE_ID = "+pageId);
				}
				if(acctId != null && !acctId.trim().equals(""))
				{
					if(whereClause.toString().length()>0)
					{
						whereClause.append(" AND PARMS_1 LIKE '%"+acctId+"%'");
					}else{
						whereClause.append(" WHERE PARMS_1 LIKE '%"+acctId+"%'");
					}
				}

				String UPDATE_PAGEID_IN_STAGING = "UPDATE " + getSchemaName() + ".STG_IBRS_CNTL SET PAGE_ID = PAGE_ID * -1 "+whereClause.toString();
				String UPDATE_CACHE_FOR_USER = "UPDATE BMGVZP.STG_IBRS_CNTL SET PAGE_ID=-1 WHERE PORTAL_USER_ID = '"+userId+"';";
				String DELETE_INV_HOME_CACHE = "DELETE FROM  " + getSchemaName() + ".STG_IBRS_CNTL WHERE PAGE_ID BETWEEN 50 AND 50;";
				_LOGGER.info("Cache SQL1: " + UPDATE_PAGEID_IN_STAGING);
				_LOGGER.info("Cache SQL2: " + UPDATE_CACHE_FOR_USER);
				_LOGGER.info("Cache SQL3: " + DELETE_INV_HOME_CACHE);

				_LOGGER.info("Whereclause: " +whereClause.toString()+"::");

				String DELETE_PAYMENTS_INFO = "DELETE FROM " + getSchemaName() + ".STG_IBRS_CNTL WHERE PAGE_ID = "+pageId;

				int deleteCount = 0;

				try {
					if(deleteCacheSqlUpdate == null) {
						if(whereClause.toString().trim().length()>0)
						{
							deleteCacheSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_PAGEID_IN_STAGING);
							deleteCacheSqlUpdate.compile();
							deleteCount+= deleteCacheSqlUpdate.update();
						}
						if(pageId == 50){
							deleteCacheSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_INV_HOME_CACHE);
							deleteCacheSqlUpdate.compile();
							deleteCount+= deleteCacheSqlUpdate.update();
						}
						if(pageId>399 && pageId< 500)
						{
							_LOGGER.info("Payment Info being deleted from staging");
							deleteCacheSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_PAYMENTS_INFO);
							deleteCacheSqlUpdate.compile();
							deleteCount+= deleteCacheSqlUpdate.update();
						}
						if(userId!= null && userId.length()>0)
						{
							_LOGGER.info("There is a userId. Updating the data for the User:"+userId);
							deleteCacheSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_CACHE_FOR_USER);
							deleteCacheSqlUpdate.compile();
							deleteCount+= deleteCacheSqlUpdate.update();
						}
					}

					if(deleteCount > 0) {
						_LOGGER.info("Delete Stage Cache Response logged successfully \n Number of Records deleted or updated - "+deleteCount);
						status = true;
					}

				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.debug("clearCache in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("clearCache in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
				}
				_LOGGER.info("Exiting clearCache");
				 responseMap.put("status",new Boolean(status));
				 return responseMap;
	}



	private String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		//_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}
	/**
	 * @author Z894579
	 * Method that creates PageNavigatorXml from the values retrieved from the database
	 * @return
	 * @throws Exception
	 */
	public Map generatePageNavigatorXml(DbAdminInfo  dbAdminInfo)throws NCASException
	{
		_LOGGER.info("Entering createPageNavigatorXml ");
		Map billViewMap = null;
		Map markupMap = null;
		Map buttonMap= null;
		Map responseMap = new HashMap();
		String pageNavXml = null;
		try
		{
			billViewMap = getAllPageType();
			/**DBAdminUtil right now only BillView Element is added
			 * @tbd markupMap =   getAllMarkup();
			 @tbd extLinkMap =  getAllExternalLinks(); **/
               /*Get the marupMap*/
			markupMap =   getAllMarkup();
			buttonMap =   selectAllButtons();
			_LOGGER.info("The billViewMap value is---->"+billViewMap.toString());
			_LOGGER.info("The markupMap value is----->" + markupMap.toString());
			pageNavXml = DBAdminUtil.generatePageNavigatorXml(billViewMap, markupMap, buttonMap);
		}
		catch(Exception xmlEx)
		{
			_LOGGER.error("Exception in creating PageNavigator XML "+ xmlEx);
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,xmlEx);
		}
		_LOGGER.info("Exiting createPageNavigatorXml");
		responseMap.put("xmlText",pageNavXml);
		return responseMap;
	}

	public Map dbadminExcel(String operation, Map inputMap){
		Map responseMap = new HashMap();
		if(operation.equals("VAM")){
			int startRange = (Integer) inputMap.get("startRange");
			int endRange = (Integer) inputMap.get("endRange");
			String[] filter = (String[]) inputMap.get("filter");
			try {
				responseMap = getExcelData(startRange, endRange, filter);
			} catch (NCASException e) {
				e.printStackTrace();
			}
		}else if(operation.equals("PL")){
			int index = (Integer) inputMap.get("filter_index");
			String filter = NcasConstants.PL_TABLE[index];
			try {
				responseMap = getPLTData(filter, index);
			} catch (NCASException e) {
				e.printStackTrace();
			}
		}else{
			List list = ((ArrayList) inputMap.get("pl_ref"));
			int count = (Integer) list.get(0);
			String filter = (String) list.get(1);
			int index = (Integer) list.get(2);
			String idType = (String) list.get(3);
			try {
				responseMap = insertPLTable(inputMap, filter, count, index, idType);
			} catch (NCASException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//_LOGGER.info("responseMap --------->"+responseMap);
		return responseMap;
	}


	public Map getExcelData(int startRange, int endRange, String[] filter) throws NCASException{
		//filter can be 'IBRS_PAGES', 'IBRS_BREAD_CRUMBS', 'IBRS_LEFT_NAVS_DEF', 'IBRS_LEFT_NAVS', 'IBRS_SCROLL_DEFS', 'IBRS_LEGENDS', 'IBRS_HEADER_XREF'
		/**
		 * TODO to check whether the filter also accommodates the 'WHERE' condition
		 */
		String[] tempFilter = {"IBRS_PAGES", "IBRS_BREAD_CRUMBS", "IBRS_LEFT_NAVS_DEF", "IBRS_LEFT_NAVS", "IBRS_HEADER_XREF", "IBRS_SCROLL_DEFS", "IBRS_LEGENDS"};
		final Map responseMap = new HashMap();
		_LOGGER.info("LENGTH FILTER IS: " + filter.length);
		if(filter!= null){
			if(filter.length == 0){
				filter = tempFilter;
			}
		}
		for(int i = 0 ; i < filter.length; i++){
			_LOGGER.info("FILTER IS: " + filter[i]);
			String SELECT_PAGES_RANGE= "SELECT * FROM " + getSchemaName() + "." + filter[i] + (filter[i].equals("IBRS_LEFT_NAVS_DEF") ? "" : (" WHERE PAGE_ID BETWEEN "+startRange+" AND "+endRange));
			_LOGGER.info("Select SQL: " + SELECT_PAGES_RANGE);
			final List responseList = new ArrayList();
			try
			{
				final String filterStr = filter[i];
				jdbcTemplate.query(SELECT_PAGES_RANGE, new RowCallbackHandler() {
					int idx = 0;
					public void processRow(ResultSet rs) throws SQLException {

						if(filterStr.equals("IBRS_PAGES")){
							AdminPage page = new AdminPage(rs.getString("PAGE_ID"), rs.getInt("SECTION_NUM"), rs.getString("TBL_TITLE"), rs.getString("TITLE_SCROLL"), rs.getString("TOTAL_SCROLL"), rs.getString("GR_TOTAL_SCROLL"), rs.getString("DISABLE_SCROLL"), rs.getString("USER_ID"), rs.getString("FILTER_STRING"), rs.getString("PARENT_PAGE_ID"), rs.getString("UPDATE_DATE"), rs.getInt("NBR_OF_HITS"), rs.getString("USER_REPORT_NAME"), rs.getString("RESTAGE_IND"));
							responseList.add(page);
						}else if(filterStr.equals("IBRS_BREAD_CRUMBS")){
							int pageId = rs.getInt("PAGE_ID");
							int linkNbr = rs.getInt("LINK_NBR");
							Map pageIdLnkNbr = new HashMap();
							pageIdLnkNbr.put(String.valueOf(idx), pageId+"--"+linkNbr);
							idx ++;
							BreadCrumb breadCrumb = new BreadCrumb(pageIdLnkNbr, rs.getString("NAME"), rs.getString("MISC_STRING"), rs.getString("TYPE"), rs.getString("FMT"), rs.getString("TARGET_PAGE_ID"), rs.getString("TARGET_PARMS_ID"), rs.getString("TARGET_SUBSET"), rs.getInt("XREF_SQL_ID"), rs.getString("L_TYPE"));
							responseList.add(breadCrumb);
						}else if(filterStr.equals("IBRS_LEFT_NAVS")){
							LeftNav leftNav = new LeftNav(rs.getInt("LEFT_NAV_NBR"), rs.getInt("PAGE_ID"), rs.getInt("LINK_NBR"));
							responseList.add(leftNav);
						}else if(filterStr.equals("IBRS_LEFT_NAVS_DEF")){
							LeftNav leftNav = new LeftNav(rs.getInt("LEFT_NAV_NBR"), rs.getString("NAME"), rs.getString("MISC_STRING"), rs.getString("TYPE"), rs.getString("FMT"), rs.getString("TARGET_PAGE_ID"), rs.getString("TARGET_PARMS_ID"), rs.getString("TARGET_SUBSET"), rs.getInt("XREF_SQL_ID"), rs.getString("L_TYPE"), rs.getString("DISPLAY_IND"));
							responseList.add(leftNav);
						}else if(filterStr.equals("IBRS_SCROLL_DEFS")){
							Scroll scroll = new Scroll(rs.getString("PAGE_ID"), rs.getInt("CURSOR_NBR"), rs.getInt("COLUMN_NBR"), rs.getString("COL_NAME"), rs.getString("COL_HEADING"), rs.getString("DATATYPE_HDG"), rs.getString("DATATYPE_DTL"), rs.getString("DATATYPE_TOT"), rs.getString("DATATYPE_GRT"), rs.getString("FMT_HDG"), rs.getString("FMT_DTL"), rs.getString("FMT_TOT"), rs.getString("FMT_GRT"), rs.getString("SORTABLE"), rs.getString("FILTERABLE"), rs.getString("COL_FILTER"),  rs.getString("L_TYPE"),  rs.getString("D_VALUE"), rs.getString("VISIBLE"), rs.getString("RESTRICT_COLUMN"));
							responseList.add(scroll);
						}else if(filterStr.equals("IBRS_LEGENDS")){
							Legend legend = new Legend(rs.getString("PAGE_ID"), rs.getInt("SECTION_NUM"), rs.getInt("LINE_NUM"), rs.getString("FMT"), rs.getString("LEGEND_TEXT"));
							responseList.add(legend);
						}else if(filterStr.equals("IBRS_HEADER_XREF")){
							//String pageId,int linkNbr, String name, String miscString, String type, String fmt, String targetPageId, String targetParmsId, String targetSubset, int xrefSqlId, String linkType, String dValue, String selectLink
							Header header = new Header(rs.getString("PAGE_ID"), rs.getInt("LINK_NBR"), rs.getString("NAME"), rs.getString("MISC_STRING"), rs.getString("TYPE"), rs.getString("FMT"), rs.getString("TARGET_PAGE_ID"), rs.getString("TARGET_PARMS_ID"), rs.getString("TARGET_SUBSET"), rs.getInt("XREF_SQL_ID"), rs.getString("L_TYPE"), rs.getString("D_VALUE"), rs.getString("SELECT_LINK"));
							responseList.add(header);
						}
					}
				});
			} catch(Exception vamEx) {
				_LOGGER.debug("getExcelData in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("getExcelData in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting getExcelData");
			responseMap.put(filter[i], responseList);
		}
		return responseMap;
	}

	private Object getValue(ResultSet res, String colName, int colDataType){
		Object obj = null;
		try {
			if(colDataType == 1 || colDataType == 12 || colDataType == -1){
				obj = res.getString(colName);
			}else if(colDataType == 3){
				obj = res.getDouble(colName);
			}else if(colDataType == 4){

				obj = res.getInt(colName);
			}else if(colDataType == 93){
				obj = res.getTimestamp(colName);
			}else{
				obj = res.getDate(colName);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj;
	}

	public Map getPLTData(String filter, int index) throws NCASException{
		Map responseMap = new HashMap();
		Map tableMap = new HashMap();
		String SELECT_ALL_DATA = null;
		try
		{
			SELECT_ALL_DATA= "SELECT * FROM " + getSchemaName() + "." + filter ;
			_LOGGER.info("Select SQL: " + SELECT_ALL_DATA );
			tableMap = selectPLTData(SELECT_ALL_DATA, index, filter);
			responseMap.put(filter, tableMap);
		} catch(Exception vamEx) {
			_LOGGER.debug("getExcelData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getExcelData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		return responseMap;
	}


	public Map selectPLTData(String sql, int index, String filter) throws NCASException {
		 SelectPLTData selectPLTables = new SelectPLTData(sql, index, filter);
		 return selectPLTables.getPLData();
	}

	class SelectPLTData extends JdbcDaoSupport {

	    private String sql;
	    private String filter = null;
	    private int index = 0;
	    private Map tableMap = new HashMap();

		public SelectPLTData(String sql, int index, String filter) {
	        this.sql = sql;
	        this.index = index;
	        this.filter = filter;
	    }

		public Map getPLData() {
			Map responseMap = new HashMap();
			PreparedStatementCreator psc = new PreparedStatementCreator(){
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException{
					PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
					return ps;
				}
			};
			responseMap = (HashMap)getTemplate().query(psc, new ResultSetExtractor() {
				int count = 0;
				public Object extractData(ResultSet rs) throws SQLException {
					while(rs.next()){
						List resList = new ArrayList();
						for(int k = 0; k < NcasConstants.PL_TABLE_COL_NAMES[index].length; k++){
							resList.add(getValue(rs, NcasConstants.PL_TABLE_COL_NAMES[index][k], NcasConstants.PL_TABLE_COL_TYPES[index][k]));
						}
						count ++;
						tableMap.put(filter+"_"+count, resList);
					}
					tableMap.put(filter+"_count", count);
					return tableMap;
				}
			});
			return responseMap;
		}

	}

	protected JdbcTemplate getTemplate(){
		if (this.jdbcTemplate == null || getDataSource() != this.jdbcTemplate.getDataSource())
			this.jdbcTemplate = new JdbcTemplate(getDataSource());
		return jdbcTemplate;
	}

	private Map insertPLTable(Map inputMap, String filter, int count, int index, String idType) throws NCASException{
		long startTime = System.currentTimeMillis();
		SqlUpdate insertPLTableSqlUpdate = null;
		boolean status = false;
		String UPDATE_PL_TABLE = getSQLPL(filter, index);
		Map responseMap = new HashMap();
		try{
			String[] colNames = NcasConstants.PL_TABLE_COL_NAMES[index];
			insertPLTableSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_PL_TABLE);
			int j = 0;
			for(String s: colNames){
				insertPLTableSqlUpdate.declareParameter(new SqlParameter(s, NcasConstants.PL_TABLE_COL_TYPES[index][j]));
				j ++;
			}
			insertPLTableSqlUpdate.compile();
			deletePLTable(inputMap, filter, count, index, idType);
	    	if(count > 0){
	    		for(int i = 0; i < count; i++){
	    			List list = (ArrayList)inputMap.get(filter+"_"+i);
	    			Object[] parameterValues = new Object[list.size()];
	    			int k = 0;
	    			for(Object obj: list){
	    				parameterValues[k] = getParamVal(obj, index, k);
	    				k ++;
	    			}
	    			insertPLTableSqlUpdate.update(parameterValues);
	    		}
				status = true;
			}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updatePLTable in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updatePLTable in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		responseMap.put("status",new Boolean(status));
//		_LOGGER.info("responseMap --> "+responseMap);
//		_LOGGER.info("Exiting updateAdminPage");
		long endTime = System.currentTimeMillis() - startTime;
		_LOGGER.info("The Time taken to insert in table: "+filter+" is "+endTime+"ms");
		return responseMap;
	}

	private final String[] PL_WH_SQL = {"WHERE PAGE_ID = ?",
			"WHERE BTN_KEY IN (SELECT A.BTN_KEY FROM $.PL_BTNPERMINCL A INNER JOIN $.PL_BTN B ON B.BTN_KEY = A.BTN_KEY WHERE A.BTN_KEY = ?)",
			"WHERE BTN_KEY IN (SELECT A.BTN_KEY FROM $.PL_BTNPORTALEXL A INNER JOIN $.PL_BTN B ON B.BTN_KEY = A.BTN_KEY WHERE A.BTN_KEY = ?)",
			"WHERE NAME = ?",
			"WHERE NAME = ?",
			"WHERE PAGE_ID = ?",
			"WHERE TEMPLATE_NAME = ?",
			"WHERE NAME = ?",
			"WHERE LINKGROUPKEY = ?",
			"WHERE USERLOGINID IN (SELECT A.USERLOGINID FROM $.PL_LINK_USERPERS A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.USERLOGINID = ?)",
			"WHERE OSID IN (SELECT A.OSID FROM $.PL_LINKOSIDEXL A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.OSID = ?)",
			"WHERE NAME IN (SELECT A.NAME FROM $.PL_LINKPERMINCL A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.NAME = ?)",
			"WHERE PORTAL IN (SELECT A.PORTAL FROM $.PL_LINKPORTALEXL A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.PORTAL = ?)",
			"WHERE PORTAL IN (SELECT A.PORTAL FROM $.PL_LINKPORTALOVR A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.PORTAL = ?)",
			"WHERE LINK_KEY IN (SELECT A.LINK_KEY FROM $.PL_LINKSVEXL A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.LINK_KEY = ?)",
			"WHERE PAGEID = ?",
			"WHERE PAGEUSERKEY IN (SELECT A.PAGEUSERKEY FROM $.PL_PAGE_USER A INNER JOIN $.PL_PAGE_DATA B ON B.PAGEKEY = A.PAGE_KEY WHERE A.PAGEUSERKEY = ?)",
			"WHERE DESC = ?",
			"WHERE SECTIONLINKKEY IN (SELECT A.SECTIONLINKKEY FROM $.PL_SECTION_LINK A INNER JOIN $.PL_LINK B ON B.LINK_KEY = A.LINK_KEY WHERE A.SECTIONLINKKEY = ?) AND SECTIONLINKKEY IN (SELECT A.SECTIONLINKKEY FROM $.PL_SECTION_LINK A INNER JOIN $.PL_SECTION_DATA B ON B.SECTIONKEY = A.SECTIONKEY WHERE A.SECTIONLINKKEY = ?)",
			"WHERE USERLOGINID IN (SELECT A.USERLOGINID FROM $.PL_SECTION_USRPER A INNER JOIN $.PL_SECTION_DATA B ON B.SECTIONKEY = A.SECTION_KEY WHERE A.USERLOGINID = ?)",
			"WHERE PAGESECTIONKEY IN (SELECT A.PAGESECTIONKEY FROM $.PL_PAGE_SECTION A INNER JOIN $.PL_PAGE_DATA B ON B.PAGEKEY = A.PAGE_KEY WHERE A.PAGESECTIONKEY = ?) AND PAGESECTIONKEY IN (SELECT A.PAGESECTIONKEY FROM $.PL_PAGE_SECTION A INNER JOIN $.PL_SECTION_DATA B ON B.SECTIONKEY = A.SECTION_KEY WHERE A.PAGESECTIONKEY = ?)",
			"WHERE TYPE = ? AND TYPE_CODE = ?",
			"WHERE ECPDID = ? AND SEQUENCE_NO = ?"};

	private Map deletePLTable(Map inputMap, String filter, int count, int index, String idType) throws NCASException {
		long startTime = System.currentTimeMillis();
		boolean status = false;
		Map responseMap = new HashMap();
		boolean deleteSingle = false;
		SqlUpdate deletePLTableSqlUpdate = null;
		String DELETE_PL_TABLE = "DELETE FROM " + getSchemaName() + "."+filter+" ";
		_LOGGER.info("Delete SQL: " + DELETE_PL_TABLE);
		try
		{

			if(idType.equalsIgnoreCase("OVERWRITE")){
				deletePLTableSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_PL_TABLE);
				deletePLTableSqlUpdate.compile();
				Object[] parameterValues = null;
				parameterValues = new Object[]{};
				deletePLTableSqlUpdate.update(parameterValues);
			}else{
//				StringBuffer strBuff = new StringBuffer(DELETE_PL_TABLE);
//				char[] ar = " A".toCharArray();
//				strBuff.insert(6, ar);
//				DELETE_PL_TABLE = strBuff.toString();
				DELETE_PL_TABLE = appendSQL(DELETE_PL_TABLE, PL_WH_SQL[index]);
				_LOGGER.info("Delete SQL: " + DELETE_PL_TABLE);
				deletePLTableSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_PL_TABLE);
				for(int i = 0; i < NcasConstants.PL_TYPE[index].length; i ++){
					deletePLTableSqlUpdate.declareParameter(new SqlParameter(NcasConstants.PL_TABLE_COL_NAMES[index][NcasConstants.PL_TYPE[index][i]], NcasConstants.PL_TABLE_COL_TYPES[index][NcasConstants.PL_TYPE[index][i]]));
				}
				deletePLTableSqlUpdate.compile();
				if(count > 0){
		    		for(int i = 0; i < count; i++){
		    			List whList = (ArrayList) inputMap.get(filter+"_WH_"+i);
		    			Object[] parameterValues = new Object[whList.size()];
		    			int j = 0;
		    			for(Object obj: whList){
		    				parameterValues[j] = getParamVal(obj, index, NcasConstants.PL_TYPE[index][j]);
		    				j ++;
		    			}
		    				deletePLTableSqlUpdate.update(parameterValues);
		    		}
					status = true;
				}
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAdminPage in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteAdminPage in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
//		_LOGGER.info("Exiting deleteAdminPage");
		 responseMap.put("status",new Boolean(status));
		 long endTime = System.currentTimeMillis() - startTime;
		 _LOGGER.info("Time Taken to delete table: "+filter+" is "+endTime+"ms");
		 return responseMap;
	}

	private String appendSQL(String sql, String wh){
		StringBuilder str = new StringBuilder();
		str.append(wh);
		String schema = getSchemaName();
		char[] chArr = wh.toCharArray();
		int count = 0;
		for(int j = 0; j < chArr.length; j++){
			if(chArr[j]=='$'){
				int index = ((schema.length() * count) + j - count);
				str.replace(index, index+1, schema);
				count ++;
			}
		}
		return sql.concat(str.toString());
	}

	private Object getParamVal(Object obj, int i, int j){
		int colDataType = NcasConstants.PL_TABLE_COL_TYPES[i][j];
		try {
			if (colDataType == 93) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
					java.util.Date d = sdf.parse(obj.toString());
					Timestamp t = new Timestamp(d.getTime());
					obj = t;
				} catch (java.text.ParseException e) {
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
					obj = lastUpdated;
					e.printStackTrace();
				}
			} else if (colDataType == 91) {
				String hssfStr = obj.toString();
				java.sql.Date date = new java.sql.Date(System.currentTimeMillis());
				obj = date.valueOf(hssfStr);
			} else if (colDataType == 3) {
				double dou = Double.parseDouble(obj.toString());
				obj = dou;
			} else if(colDataType == 12 || colDataType == 1 || colDataType == -1) {
				obj = obj.toString();
			}else if (colDataType == 4) {
				int hssfInt = 0;
				StringBuffer strBuff = new StringBuffer(obj.toString());
				hssfInt = Integer.parseInt(obj.toString());
				obj = hssfInt;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	private String getSQLPL(String filter, int index){
		StringBuilder colNB = new StringBuilder();
		StringBuilder paramB = new StringBuilder();
		StringBuilder strBuilder = new StringBuilder();
		String str = "INSERT INTO " + getSchemaName() + "."+filter+"(";
		strBuilder.append(str);
		String[] colNames = NcasConstants.PL_TABLE_COL_NAMES[index];
		int count = 0;
		for(String s: colNames){
			count ++;
			colNB.append(s);
			paramB.append("?");
			if(count != colNames.length){
				colNB.append(",");
				paramB.append(",");
			}else{
				colNB.append(") VALUES(");
				paramB.append(")");
			}
		}
		strBuilder.append(colNB.toString());
		strBuilder.append(paramB.toString());
		return strBuilder.toString();
	}
	

	public Map insertReportControl(RptCntl reportCntl) throws NCASException {
		final String METHOD_NAME = "insertReportControl => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String INSERT_RPT_CNTL_DETAILS = "INSERT INTO  " + getSchemaName() +".PL_RPT_CNTL_T(RPT_ID,STANDARD_RPT, CUSTOM_RPT, RPT_NAME, REPORT_SUB_GROUP, RPT_SECTION, RPT_CATEGORY, PAGE_ID, PAGE_SUBSET, INTER_PAGE_ID, RPT_CATEGORY_DESCRIPTION, REPORT_DESCRIPTION, EMAIL_TEMPLATE_NAME, ARCHIVE_SYSTEM_ID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		boolean status = false;
		Map responseMap = new HashMap();
		List totalList = new ArrayList();
		
		_LOGGER.info(METHOD_NAME+"Insert SQL: " + INSERT_RPT_CNTL_DETAILS);
		try
				{
			   
					insertRptCntlDet = new SqlUpdate(jdbcTemplate.getDataSource(), INSERT_RPT_CNTL_DETAILS);
					
					 KeyHolder keyHolder = new GeneratedKeyHolder();

					insertRptCntlDet.setReturnGeneratedKeys(true);
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_ID", Types.DECIMAL));
					insertRptCntlDet.declareParameter(new SqlParameter("STANDARD_RPT", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("CUSTOM_RPT", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_NAME", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("REPORT_SUB_GROUP", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_SECTION", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY", Types.VARCHAR));

					insertRptCntlDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					insertRptCntlDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("INTER_PAGE_ID", Types.INTEGER));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY_DESCRIPTION", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("REPORT_DESCRIPTION", Types.VARCHAR));

					insertRptCntlDet.declareParameter(new SqlParameter("EMAIL_TEMPLATE_NAME", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("ARCHIVE_SYSTEM_ID", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
					insertRptCntlDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
					insertRptCntlDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

         
					insertRptCntlDet.compile();
					
		  

						Object[] parameterValues = new Object[]{
                                getGeneratedKey(getReportId()),
							   	reportCntl.getStdReport(),		
								reportCntl.getCustomRpt(),
								reportCntl.getRptName(),					
								reportCntl.getRptSubGroup(),									
								reportCntl.getRptSection(),									
								reportCntl.getRptCategory(),
								new Integer(reportCntl.getPageId()),								
								reportCntl.getPageSubset(),								
								new Integer(reportCntl.getInterPageId()),									
								reportCntl.getRptCatDescription(),									
								reportCntl.getRptDescription(),									
								reportCntl.getEmailTemplateName(),									
								reportCntl.getArchiveSystemId(),								
								reportCntl.getCreatedTimestamp(),							
						    	reportCntl.getLastUpdTimestamp(),		
								reportCntl.getLastUpdatedBy() };
						      
						 
								insertRptCntlDet.update(parameterValues);
							
          
				

			status = true;
			responseMap.put("status",new Boolean(status));
			
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"insertUnicodeData Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}




public List getReportId() throws NCASException {
		final String METHOD_NAME = "getReportId => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		final List totalList = new ArrayList();
		String SELECT_MAX_RPTID = "SELECT distinct rpt_id FROM " + getSchemaName() +".PL_RPT_CNTL_T";
		_LOGGER.info(SELECT_MAX_RPTID+"Exiting");
		try
				{
		 jdbcTemplate.query(SELECT_MAX_RPTID, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					int rep_id = rs.getInt("rpt_id");
					totalList.add(rep_id);
				}
			});
				} catch(Exception vamEx) {
					_LOGGER.debug("SelectBillViewType in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("SelectBillViewType in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
				}
				return totalList;
	}

 private int getGeneratedKey(List currentKeyList) {
	int maxLinkNbrPlusOne = 0;
	int maxValueCalculated = 0;
	if (currentKeyList != null && currentKeyList.size() > 0) {
		maxValueCalculated = ((Integer) Collections.max(currentKeyList))
				.intValue();
	}
	maxLinkNbrPlusOne = maxValueCalculated + 1;
	return maxLinkNbrPlusOne;
	}

	  public List selectReportId() throws NCASException {
		return getReportId();
		}
	  

	  public Map selectAllReportDetails(double rptId) throws NCASException {
			final String METHOD_NAME = "selectAllReportDetails => ";
			_LOGGER.info(METHOD_NAME+"Entering");
			final Map responseMap = new HashMap();
			String SELECT_RPT_VALUES ="SELECT * FROM "+ getSchemaName() +".PL_RPT_CNTL_T WHERE  RPT_ID= " + rptId;
			_LOGGER.info(SELECT_RPT_VALUES+"Exiting");
			try
					{
			 jdbcTemplate.query(SELECT_RPT_VALUES, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						    responseMap.put("strrpt",rs.getString("STANDARD_RPT"));
							responseMap.put("customrpt",rs.getString("CUSTOM_RPT"));
							responseMap.put("rptNmae",rs.getString("RPT_NAME"));
							responseMap.put("reportSubGroup",rs.getString("REPORT_SUB_GROUP"));
							responseMap.put("rptSection",rs.getString("RPT_SECTION"));
							responseMap.put("rptCategory",rs.getString("RPT_CATEGORY"));
							responseMap.put("pageID",rs.getInt("PAGE_ID"));
							responseMap.put("pageSubset",rs.getString("PAGE_SUBSET"));
							responseMap.put("interpageID",rs.getInt("INTER_PAGE_ID"));
							responseMap.put("rtpCatDesc",rs.getString("RPT_CATEGORY_DESCRIPTION"));
							responseMap.put("rptDesc",rs.getString("REPORT_DESCRIPTION"));
							responseMap.put("emailTemplate",rs.getString("EMAIL_TEMPLATE_NAME"));
							responseMap.put("archiveSystem",rs.getString("ARCHIVE_SYSTEM_ID")); 
					}
				});
					} catch(Exception vamEx) {
						_LOGGER.debug("selectAllReportDetails in VAM Failed \n"+vamEx.getMessage());
						_LOGGER.error("selectAllReportDetails in VAM Failed \n"+vamEx.getMessage());
						throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
					}
					return responseMap;
		}
 
	  
	  public Map updateReportDetail(RptCntl reportCntl) throws NCASException {
			final String METHOD_NAME = "updateReportDetail => ";
			_LOGGER.info(METHOD_NAME+"Entering");
			String UPDATE_PL_RPT_CNTL_T = "UPDATE "+getSchemaName()+".PL_RPT_CNTL_T  SET STANDARD_RPT=?, CUSTOM_RPT=?, RPT_NAME=? , REPORT_SUB_GROUP=?,RPT_SECTION=?,RPT_CATEGORY=?,PAGE_ID=?,PAGE_SUBSET=?,INTER_PAGE_ID=?,RPT_CATEGORY_DESCRIPTION=?,REPORT_DESCRIPTION=?,EMAIL_TEMPLATE_NAME=?,ARCHIVE_SYSTEM_ID=? ,LAST_UPD_TIMESTAMP=?,LAST_UPDATED_BY=? WHERE RPT_ID=?";
			boolean status = false;
			Map responseMap = new HashMap();
			//List totalList = new ArrayList();
			
			_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_PL_RPT_CNTL_T);
			try
					{
				   
						updateRptCntlDet = new SqlUpdate(jdbcTemplate.getDataSource(), UPDATE_PL_RPT_CNTL_T);
						
						 KeyHolder keyHolder = new GeneratedKeyHolder();

						updateRptCntlDet.setReturnGeneratedKeys(true);
						
						updateRptCntlDet.declareParameter(new SqlParameter("STANDARD_RPT", Types.CHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("CUSTOM_RPT", Types.CHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_NAME", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("REPORT_SUB_GROUP", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_SECTION", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY", Types.VARCHAR));

						updateRptCntlDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
						updateRptCntlDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("INTER_PAGE_ID", Types.INTEGER));
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY_DESCRIPTION", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("REPORT_DESCRIPTION", Types.VARCHAR));

						updateRptCntlDet.declareParameter(new SqlParameter("EMAIL_TEMPLATE_NAME", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("ARCHIVE_SYSTEM_ID", Types.CHAR));

						updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
						updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_ID", Types.DECIMAL));
	         
						updateRptCntlDet.compile();
						
			  

							Object[] parameterValues = new Object[]{
	                             // getGeneratedKey(getReportId()),
									
								   	reportCntl.getStdReport(),		
									reportCntl.getCustomRpt(),
									reportCntl.getRptName(),					
									reportCntl.getRptSubGroup(),									
									reportCntl.getRptSection(),									
									reportCntl.getRptCategory(),
									new Integer(reportCntl.getPageId()),								
									reportCntl.getPageSubset(),								
									new Integer(reportCntl.getInterPageId()),									
									reportCntl.getRptCatDescription(),									
									reportCntl.getRptDescription(),									
									reportCntl.getEmailTemplateName(),									
									reportCntl.getArchiveSystemId(),								
							    	reportCntl.getLastUpdTimestamp(),		
									reportCntl.getLastUpdatedBy(),
									new Double(reportCntl.getRptId())
										};
							
							

							      
							 
							   int  rslt = updateRptCntlDet.update(parameterValues);
							  
				if(rslt != -1)
				status = true;
				responseMap.put("status",new Boolean(status));
				
			} catch(Exception vamEx) {
				vamEx.printStackTrace();
				_LOGGER.error(METHOD_NAME+"updateReportDetail Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return responseMap;
		}

 public Map deleteReportDetails(double rptId) throws NCASException {
			final String METHOD_NAME = "deleteReportDetails => ";
			_LOGGER.info(METHOD_NAME+"Entering");
			String DELETE_PL_RPT_ID = "DELETE FROM " + getSchemaName() + ".PL_RPT_CNTL_T WHERE RPT_ID=?";
			boolean status = false;
			Map responseMap = new HashMap();
			//List totalList = new ArrayList();
			
			_LOGGER.info(METHOD_NAME+"Update SQL: " + DELETE_PL_RPT_ID);
			try
					{
				   
						deleteRptCntlDet = new SqlUpdate(jdbcTemplate.getDataSource(), DELETE_PL_RPT_ID);
						
						 KeyHolder keyHolder = new GeneratedKeyHolder();

						deleteRptCntlDet.setReturnGeneratedKeys(true);		
						deleteRptCntlDet.declareParameter(new SqlParameter("RPT_ID", Types.DECIMAL));      
						deleteRptCntlDet.compile();
					
						Object[] parameterValues = new Object[]{ new Double(rptId)};
							      
							 
							        deleteRptCntlDet.update(parameterValues);

				status = true;
				responseMap.put("status",new Boolean(status));
				
			} catch(Exception vamEx) {
				vamEx.printStackTrace();
				_LOGGER.error(METHOD_NAME+"deleteReportDetails Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return responseMap;
		}

 private boolean checkDateOverLap(String currEffFrm, String currEffTo, String prevEffFrm, String prevEffTo){

		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			Date cedf = df.parse(currEffFrm);
			Date cedt = df.parse(currEffTo);
			Date pedf = df.parse(prevEffFrm);
			Date pedt = df.parse(prevEffTo);
			if((cedf.compareTo(pedf) >= 0 && cedf.compareTo(pedt) <= 0)){
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

 public Map insertSystemParms(Object input) throws NCASException {
		final String METHOD_NAME = "insertSystemParmss => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String INSERT_SYS_PARM = "INSERT INTO  " + getSchemaName() +".PL_SYS_PARM_T(PARM_NAME,PARM_VALUE, PARM_DESC, LAST_UPDATE_BY, LAST_UPDATED, EFFECTIVE_DATE_FROM, EFFECTIVE_DATE_TO) VALUES(?,?,?,?,?,?,?)";
		boolean status = false;
		Map responseMap = new HashMap();
		List totalList = new ArrayList();
		SystemParam systemParms=(SystemParam)input;
		List parmList = getParmNames();
		_LOGGER.info("parmList " + parmList);
		boolean overLap = false;
		if(parmList.contains(systemParms.getName())){
			Map parmMap = selectAllParms(systemParms.getName());
			
			String currEffFrm = systemParms.getEffectiveDatefrom();
			String currEffTo = systemParms.getEffectiveDateto();
			String prevEffFrm = (String)parmMap.get("effectiveDatefrom");
			String prevEffTo = (String)parmMap.get("effectiveDateto");
			overLap = checkDateOverLap(currEffFrm, currEffTo, prevEffFrm, prevEffTo);
		}
		_LOGGER.info(METHOD_NAME+"Insert SQL: " + INSERT_SYS_PARM);
		responseMap.put("dup", overLap);
		try	{
			if(!overLap){
			   
					insertSystemParms = new SqlUpdate(jdbcTemplate.getDataSource(), INSERT_SYS_PARM);
					
					 KeyHolder keyHolder = new GeneratedKeyHolder();

					 insertSystemParms.setReturnGeneratedKeys(true);
					 insertSystemParms.declareParameter(new SqlParameter("PARM_NAME", Types.VARCHAR));
					 insertSystemParms.declareParameter(new SqlParameter("PARM_VALUE", Types.VARCHAR));
					 insertSystemParms.declareParameter(new SqlParameter("PARM_DESC", Types.VARCHAR));
					 insertSystemParms.declareParameter(new SqlParameter("LAST_UPDATE_BY", Types.VARCHAR));
					 insertSystemParms.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
					 insertSystemParms.declareParameter(new SqlParameter("EFFECTIVE_DATE_FROM", Types.TIMESTAMP));
					 insertSystemParms.declareParameter(new SqlParameter("EFFECTIVE_DATE_TO", Types.TIMESTAMP));

					 insertSystemParms.compile();
						Object[] parameterValues = new Object[]{
								systemParms.getName(),		
								systemParms.getValue(),
								systemParms.getParamDesc(),					
								systemParms.getLastUpdatedBy(),									
								systemParms.getLastUpdated(),									
								systemParms.getEffectiveDatefrom(),									
								systemParms.getEffectiveDateto()
								};									
				
						   insertSystemParms.update(parameterValues);

			status = true;
			responseMap.put("status",new Boolean(status));
				}else{
					responseMap.put("status","Dates are overlapping with a previous entry of Param Value: "+systemParms.getName()+". Please change dates and try again.");
				}
			
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"insertSystemParmss Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
		}
  // this method will give the drop down paramNames.
    public List getParmNames() throws NCASException {
		final String METHOD_NAME = "getParmNames => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		final List totalList = new ArrayList();
		String SELECT_PARMNAME = "SELECT DISTINCT  PARM_NAME FROM " + getSchemaName() +".PL_SYS_PARM_T";
		_LOGGER.info(SELECT_PARMNAME+"Exiting");
		try
				{
		 jdbcTemplate.query(SELECT_PARMNAME, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					String parm_name = rs.getString("PARM_NAME");
					totalList.add(parm_name);
				}
			});
				} catch(Exception vamEx) {
					_LOGGER.debug("getParmNames in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("getParmNames in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
				}
				return totalList;
	}
    //this method will  the corresponding details about the selecting the paramNames .
    
    public Map selectAllParms(String paramName) throws NCASException {
		final String METHOD_NAME = "selectAllParms => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		final Map responseMap = new HashMap();
		String SELECT_PARM_VALUES ="SELECT * FROM "+ getSchemaName() +".PL_SYS_PARM_T WHERE  PARM_NAME= '"+paramName+"'";
		_LOGGER.info(SELECT_PARM_VALUES+"Exiting");
		try
				{
		 jdbcTemplate.query(SELECT_PARM_VALUES, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					    responseMap.put("value",rs.getString("PARM_VALUE"));
						responseMap.put("effectiveDatefrom",rs.getString("EFFECTIVE_DATE_FROM"));
						responseMap.put("effectiveDateto",rs.getString("EFFECTIVE_DATE_TO"));
						responseMap.put("paramDesc",rs.getString("PARM_DESC"));
						
				}
			});
				} catch(Exception vamEx) {
					_LOGGER.debug("selectAllParms in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("selectAllParms in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
				}
				return responseMap;
	}
 // this method will  update the System param. 
    public Map updateSystemParms(Object input) throws NCASException {
		final String METHOD_NAME = "updateSystemParms => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String UPDATE_SYSPARMS = "UPDATE "+getSchemaName()+".PL_SYS_PARM_T  SET  PARM_VALUE=?, PARM_DESC=?, LAST_UPDATE_BY=?,LAST_UPDATED=?,EFFECTIVE_DATE_FROM=?,EFFECTIVE_DATE_TO=? WHERE PARM_NAME=?";
		boolean status = false;
		Map responseMap = new HashMap();
		//List totalList = new ArrayList();
		SystemParam systemParms=(SystemParam)input;
		_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_SYSPARMS);
		try
				{
			     SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			     String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			     
					updateSysParmsDet = new SqlUpdate(jdbcTemplate.getDataSource(), UPDATE_SYSPARMS);
					
					 KeyHolder keyHolder = new GeneratedKeyHolder();

					 updateSysParmsDet.setReturnGeneratedKeys(true);
					
					 updateSysParmsDet.declareParameter(new SqlParameter("PARM_VALUE", Types.VARCHAR));
					 updateSysParmsDet.declareParameter(new SqlParameter("PARM_DESC", Types.VARCHAR));
					 updateSysParmsDet.declareParameter(new SqlParameter("LAST_UPDATE_BY", Types.VARCHAR));
					 updateSysParmsDet.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
					 updateSysParmsDet.declareParameter(new SqlParameter("EFFECTIVE_DATE_FROM", Types.TIMESTAMP));
					 updateSysParmsDet.declareParameter(new SqlParameter("EFFECTIVE_DATE_TO", Types.TIMESTAMP));
					 updateSysParmsDet.declareParameter(new SqlParameter("PARM_NAME", Types.VARCHAR));

					
					 updateSysParmsDet.compile();
					
		  

						Object[] parameterValues = new Object[]{
                             // getGeneratedKey(getReportId()),
								
								systemParms.getValue(),
								systemParms.getParamDesc(),					
								systemParms.getLastUpdatedBy(),									
								systemParms.getLastUpdated(),									
								systemParms.getEffectiveDatefrom(),									
								systemParms.getEffectiveDateto(),		
								systemParms.getName()		
						        };
						
		 
						    updateSysParmsDet.update(parameterValues);
						  
			status = true;
			responseMap.put("status",new Boolean(status));
			
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"updateSystemParms Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}
  
    public Map deleteSystemParms(String paramName) throws NCASException {
		final String METHOD_NAME = "deleteSystemParms => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String DELETE_SYSPARMS = "DELETE FROM " + getSchemaName() + ".PL_SYS_PARM_T WHERE PARM_NAME=?";
		boolean status = false;
		Map responseMap = new HashMap();
		//List totalList = new ArrayList();
		
		_LOGGER.info(METHOD_NAME+"Update SQL: " + DELETE_SYSPARMS);
		try
				{
			   
					deleteSystemParmsDet = new SqlUpdate(jdbcTemplate.getDataSource(), DELETE_SYSPARMS);
					
					 KeyHolder keyHolder = new GeneratedKeyHolder();

					 deleteSystemParmsDet.setReturnGeneratedKeys(true);		
					 deleteSystemParmsDet.declareParameter(new SqlParameter("PARM_NAME", Types.VARCHAR));      
					 deleteSystemParmsDet.compile();
				
					Object[] parameterValues = (new Object[]{paramName});
						      
						 
					deleteSystemParmsDet.update(parameterValues);

			status = true;
			responseMap.put("status",new Boolean(status));
			
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"deleteSystemParms Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,DBAdminDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
    }
    
    //split string into equal sized parts
    private String[] splitInParts(String s, int partLength) 
    {     
    	int len = s.length();
    	
    	//calculate number of parts
    	int nparts = (len + partLength - 1) / partLength; //relies on integer cropping to get number of parts
    	String parts[] = new String[nparts];     
  
    	//break string into parts
    	int offset= 0;     
    	for (int i = 0; i < nparts; i++)     
    	{         
    		parts[i] = s.substring(offset, Math.min(offset + partLength, len));  //add equal size parts to array, last part uses stop at end of string instead of being equal size to rest.
    		offset += partLength;         
       	}      
    	return parts; 
    } 	   
}