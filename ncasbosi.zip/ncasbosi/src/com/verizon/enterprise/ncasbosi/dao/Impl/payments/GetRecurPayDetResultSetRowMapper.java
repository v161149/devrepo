package com.verizon.enterprise.ncasbosi.dao.Impl.payments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.payments.PaymentProfile;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetRecurPayDetResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetRecurPayDetResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetRecurPayDetResultSetRowMapper::mapRow rowNum - " + rowNum);

		Map<Map<String, String>, PaymentProfile> retMap = new HashMap<Map<String, String>, PaymentProfile>();
		PaymentProfile payProfile = new PaymentProfile();

		String serviceId = rs.getString("SERVICE_ID");
		double subOid = rs.getDouble("SUBSCRIPTION_OID");
		double userOid = rs.getDouble("USER_OID");
		String name = rs.getString("NAME");
		String safeKey = rs.getString("SAFE_KEY");
		String address = rs.getString("ADDRESS");
		String city = rs.getString("CITY");
		String state = rs.getString("STATE");
		String zip = rs.getString("ZIP");
		String country = rs.getString("COUNTRY");
		String typeDesc = rs.getString("TYPE_DESCRIPTION");
		String maskedAcctNum = rs.getString("MASKED_ACCT_NUMBER");
		String expDateMM = rs.getString("EXP_DATE_MM");
		String expDateYY = rs.getString("EXP_DATE_YY");

		Map<String, String> retKeyMap = new HashMap<String, String>();

		retKeyMap.put("BAN", serviceId);
		retKeyMap.put("SubscriptionOid", Double.toString(subOid));
		retKeyMap.put("UserOid", Double.toString(userOid));

		payProfile.setName(name);
		payProfile.setSafeKey(safeKey);
		payProfile.setAddress(address);
		payProfile.setCity(city);
		payProfile.setState(state);
		payProfile.setZip(zip);
		payProfile.setCountry(country);
		payProfile.setTypeDescription(typeDesc);
		payProfile.setMaskedAcctNum(maskedAcctNum);
		payProfile.setExpDateMM(expDateMM);
		payProfile.setExpDateYY(expDateYY);

		retMap.put(retKeyMap, payProfile);

		return retMap;
	}
}

