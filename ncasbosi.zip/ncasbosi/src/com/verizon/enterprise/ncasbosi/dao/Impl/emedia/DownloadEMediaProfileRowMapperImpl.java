package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadEMediaProfileRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadEMediaProfileRowMapperImpl.class);

	//public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	public Object extractData(ResultSet rs) throws SQLException {
		//_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::mapRow rowNumber -> " + rowNum);
		_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List profilesList = new ArrayList();
		List profile = new ArrayList();
		
		try {
			/*
			profile.add(new Cell("Config Id"));
			profile.add(new Cell("Service Type"));
			profile.add(new Cell("Company Name"));
			profile.add(new Cell("Customer Type"));
			profile.add(new Cell("LOB Indicator"));
			profile.add(new Cell("EDI Delivery Option"));
			profile.add(new Cell("Comm Method"));
			profile.add(new Cell("Profile Complete"));
			profile.add(new Cell("Bill Period"));
			profile.add(new Cell("National Indicator"));
			profile.add(new Cell("Media Option"));
			profile.add(new Cell("Direct Data Delivery Option"));
			profile.add(new Cell("Hold Days"));
			profile.add(new Cell("Software Version"));
			profile.add(new Cell("Start Date"));
			profile.add(new Cell("End Date"));
			profile.add(new Cell("Created Date"));
			
			//Add header
			profilesList.add(profile);
			*/

			while(rs.next()) {
				profile = new ArrayList();
	
				String configId = rs.getString("CONFIG_ID");
				String serviceType = rs.getString("SERVICE_TYPE");
				String companyName = rs.getString("COMPANY_NAME");
				String distributionName = rs.getString("DISTRBUTION_NAME");
				String profileStatus = rs.getString("PROF_STATUS");
				String lobIndicator = rs.getString("LOB_IND");
				String ediDelivOpt = rs.getString("EDI_DELIV_OPT");
				String commMethod = rs.getString("COMM_METHOD");
				String profileComplete = rs.getString("PROFILE_COMPLETE");
				String mediaOpt = rs.getString("MEDIA_OPT");
				String ddDelivOpt = rs.getString("DD_DELIV_OPT");
				String softwareVersion = rs.getString("SOFTWARE_VER");
				String billPeriod = rs.getString("BP_DAY");
				String nationalInd = rs.getString("CONFIG_NATL_IND");
				String startDate= rs.getString("START_DATE");
				String endDate= rs.getString("END_DATE");
				String createdDate= rs.getString("DATE_CREATED");
	
	
				if(CommonUtil.isNotNull(configId)) {
					profile.add(new Cell(configId.trim()));
				}
				if(CommonUtil.isNotNull(serviceType)) {
					profile.add(new Cell(serviceType.trim()));
				}
			
				if(CommonUtil.isNotNull(companyName)) {
					profile.add(new Cell(companyName.trim()));
				}
				if(CommonUtil.isNotNull(distributionName)) {
					profile.add(new Cell(distributionName.trim()));
				}
				if(CommonUtil.isNotNull(profileStatus)) {
				profile.add(new Cell(profileStatus.trim()));
				}
				if(CommonUtil.isNotNull(lobIndicator)) {
				profile.add(new Cell(lobIndicator.trim()));
				}
				if(CommonUtil.isNotNull(ediDelivOpt)) {
				profile.add(new Cell(ediDelivOpt.trim()));
				}
				if(CommonUtil.isNotNull(commMethod)) {
				profile.add(new Cell(commMethod.trim()));
				}
				if(CommonUtil.isNotNull(profileComplete)) {
				profile.add(new Cell(profileComplete.trim()));//PROFILE_COMPLETE
				}
				if(CommonUtil.isNotNull(billPeriod)) {
				profile.add(new Cell(billPeriod.trim()));//BP_DAY
				}
				if(CommonUtil.isNotNull(nationalInd)) {
				profile.add(new Cell(nationalInd.trim()));//CONFIG_NATL_IND
				}
				if(CommonUtil.isNotNull(mediaOpt)) {
				profile.add(new Cell(mediaOpt.trim()));
				}
				if(CommonUtil.isNotNull(ddDelivOpt)) {
				profile.add(new Cell(ddDelivOpt.trim()));
				}
				profile.add(new Cell(new Integer(rs.getInt("HOLD_DAYS")).toString()));
				if(CommonUtil.isNotNull(softwareVersion)) {
					profile.add(new Cell(softwareVersion.trim()));
				}
	
				profile.add(new Cell(CommonUtil.getDisplayDateFromString(startDate)));
				profile.add(new Cell(CommonUtil.getDisplayDateFromString(endDate)));
				profile.add(new Cell(CommonUtil.getDisplayDateFromString(createdDate)));
				
				profilesList.add(profile);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			//throw new NCASException("Exception occured while parsing the resultset \n"+pe.toString(),GetProfileRowMapperImpl.class,pe);
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("SearchEMediaProfile's profile  " + profile);
		}
		return profilesList;
	}
}
