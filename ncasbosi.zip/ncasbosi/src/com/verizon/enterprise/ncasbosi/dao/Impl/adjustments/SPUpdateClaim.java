package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPUpdateClaim extends BaseStoredProcedure
{
	static private final Logger _LOGGER = Logger.getLogger(SPUpdateClaim.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CLM_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUB_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"NEXT_FOLLOWUP_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_REP_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPUpdateClaim(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_UPDATE_CLAIM, spInOutList);
	}

	public Map executeStoredProcedure(String claimNumber, String inputString)throws Exception
	{
		//create an input param list
		List paramValueList = new ArrayList();
		paramValueList.add(claimNumber);//ESG_CLAIM_NUMBER
		paramValueList.add(inputString);//INPUT_STRING

		//add all input parameters to Map and pass it back along with responseMap
		Map inputParamMap = new HashMap();
		inputParamMap.put("ESG_CLAIM_NUMBER", claimNumber);
		inputParamMap.put("INPUT_STRING", inputString);

		//add input parameters Map and API_NAME to responseMap and return it back
		Map responseMap = executeStoredProcedure(paramValueList);
		responseMap.put("API_NAME", NCASBOSIConstants.SP_UPDATE_CLAIM);
		responseMap.put("inputParamMap", inputParamMap);

		return responseMap;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);

		return responseMap;
	}
}