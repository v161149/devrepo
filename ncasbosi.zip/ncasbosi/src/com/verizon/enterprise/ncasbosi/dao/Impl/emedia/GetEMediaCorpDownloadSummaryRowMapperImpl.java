package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.ncas.display.Cell;

public class GetEMediaCorpDownloadSummaryRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(GetEMediaCorpDownloadSummaryRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		//_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::mapRow rowNumber -> " + rowNum);
		_LOGGER.info("Inside DownloadEMediaProfileRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List summaryList = new ArrayList();
		List summary = new ArrayList();

		try {
			
			summary.add(new Cell("Enterprise ID"));
			summary.add(new Cell("Corp ID"));
			summary.add(new Cell("Account Name"));
			summary.add(new Cell("Bill Period"));
			summary.add(new Cell("Verified"));
			summary.add(new Cell("LOB"));
			summary.add(new Cell("Bill Manager"));
			summary.add(new Cell("EDI"));
			summary.add(new Cell("Direct Data"));
			summary.add(new Cell("Source System"));
			summary.add(new Cell("National Statement"));
			summary.add(new Cell("LOB"));
			summary.add(new Cell("Paper Free Billing Status")); 

			//Add header
			summaryList.add(summary);
			

			while(rs.next()) {
				summary = new ArrayList();

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String accountName = rs.getString("ACCT_NAME");
				String billPeriod = rs.getString("BILL_PERIOD");
				String verified = rs.getString("VERIFIED_FLAG");
				String mediaType = rs.getString("BM_MEDIA_TYPE");
				String bmCustConfig = rs.getString("BM_CUST_CONFIG_ID");


				String channelCode = rs.getString("CHANNEL_DESC");
				String ediDeliveryOption = rs.getString("EDI_DELIV_OPT");
				String vz450DeliveryOption = rs.getString("VZ450_DELIV_OPT");
				String vz450CustConfig = rs.getString("VZ450_CUST_CFG_ID");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String ebid = rs.getString("EBID");
				String nationalAccount = rs.getString("NBBE_ACCT_NUM");
				String paperSuppressInd = rs.getString("PAPER_SUPPRESS_IND");

				if(CommonUtil.isNotNull(enterpriseId)) {
					summary.add(new Cell(enterpriseId.trim()));
				}
				if(CommonUtil.isNotNull(corpId)) {
					summary.add(new Cell(corpId.trim()));
				}

				if(CommonUtil.isNotNull(accountName)) {
				summary.add(new Cell(accountName.trim()));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
				summary.add(new Cell(billPeriod.trim()));
				}
				if(CommonUtil.isNotNull(verified)) {
				summary.add(new Cell(verified.trim()));
				}
				if(CommonUtil.isNotNull(channelCode)) {
					summary.add(new Cell(channelCode.trim()));
				}
				if(CommonUtil.isNotNull(bmCustConfig)) {
				summary.add(new Cell(bmCustConfig.trim()));
				}
				if(CommonUtil.isNotNull(ebid)) {
				summary.add(new Cell(ebid.trim()));
				}
				if(CommonUtil.isNotNull(vz450CustConfig)) {
				summary.add(new Cell(vz450CustConfig.trim()));
				}
				if(CommonUtil.isNotNull(systemAbbrv)) {
					summary.add(new Cell(systemAbbrv.trim()));
				}
				if(CommonUtil.isNotNull(nationalAccount)) {
					summary.add(new Cell(nationalAccount.trim()));
				}
				if(CommonUtil.isNotNull(paperSuppressInd)) {
					if(paperSuppressInd.equalsIgnoreCase("0") ||
							paperSuppressInd.equalsIgnoreCase("X") ) {
						summary.add(new Cell("Not Active"));
					} else if(paperSuppressInd.equalsIgnoreCase("1")) {
						summary.add(new Cell("Not Active Pending"));
					} else if(paperSuppressInd.equalsIgnoreCase("2") ||
							paperSuppressInd.equalsIgnoreCase("Z") ) {
						summary.add(new Cell("Active"));
					} else if(paperSuppressInd.equalsIgnoreCase("3")) {
						summary.add(new Cell("Active Pending"));
					}
				}


				summaryList.add(summary);
			}
		}catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("SearchEMediaProfile's summary  " + summary);
		}
		return summaryList;
	}

}
