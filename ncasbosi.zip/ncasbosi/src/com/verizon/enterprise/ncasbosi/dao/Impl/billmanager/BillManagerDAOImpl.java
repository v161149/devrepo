package com.verizon.enterprise.ncasbosi.dao.Impl.billmanager;

import java.util.Map;


import com.verizon.enterprise.common.ncas.exception.NCASException;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.common.ncas.billmanager.BillManager;
import com.verizon.enterprise.ncasbosi.dao.Impl.billmanager.SPGetEMedia;
import com.verizon.enterprise.ncasbosi.dao.Interface.billmanager.BillmanagerDataInterface;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.apache.log4j.Logger;

public class BillManagerDAOImpl extends NCASSpringJDBCBase implements 
    BillmanagerDataInterface, NCASBOSIConstants   {
	static private final Logger _LOGGER = Logger
	.getLogger(BillManagerDAOImpl.class);
	private JdbcTemplate vamJdbcTemplate;// jdbctemplate created for VAM
	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	// dataSource
	private String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

	
	public void setVAMDataSource(DataSource dataSource) {
		vamJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[VAMjdbcTemplate datasource set ]");
	}

	public DataSource getVAMDataSource() {
		return vamJdbcTemplate.getDataSource();
	}
	public Map getEMediaList(BillManager input) throws NCASException {
		try {
			_LOGGER.info("Enterrring getEMediaList");
			if (input == null) {
				_LOGGER.error("throwing exception BMCUSTIDSearchForm is Null ");
				_LOGGER.debug("throwing exception BMCUSTIDSearchForm is Null ");
				throw new Exception("BMCUSTIDSearchForm is Null");
			}
			_LOGGER.info("getEMediaList:" + input);
			String schemaName = getSchemaName();
			Map output;
			SPGetEMedia getEMedia = new SPGetEMedia(getDataSource(),schemaName);
			output = getEMedia.executeStoredProcedure(input);

			_LOGGER.info("Leaving getEMediaList");

			return output;
		} catch (Exception vamEx) {
			_LOGGER.debug("GET getEMediaList\n" + vamEx.getMessage());
			_LOGGER.error("GET getEMediaList\n" + vamEx.getMessage());
			throw new NCASException("BI0906", BillManagerDAOImpl.class, vamEx);
		}

	}// end getEMediaList
}
