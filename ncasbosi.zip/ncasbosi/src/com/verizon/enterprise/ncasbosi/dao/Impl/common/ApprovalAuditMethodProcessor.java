package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface;

public class ApprovalAuditMethodProcessor {
	private static ApprovalAuditInterface approvalAuditObject = DAOFactory.getInstance().getApprovalAudit();	
		
	public static Serializable processApprovalAudit(Object input,String function)throws NCASException{
		//_LOGGER.info("Entering processApprovalAudit");
		Serializable response = null;
		try{
			Method method = approvalAuditObject.getClass().getMethod(function, new Class[]{CommonUtil.getClassType(input)});
			response = (Serializable)method.invoke(approvalAuditObject,new Object[]{input});
		}catch(InvocationTargetException exception){
			Throwable throwable = exception.getTargetException().getCause();
			if (throwable instanceof NCASException){
				throw (NCASException)throwable;
			}else{
				throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,ApprovalAuditMethodProcessor.class,throwable);
			}			
		}catch(Exception exception){
			if(exception instanceof NCASException){
				throw (NCASException)exception;
			}else{
				throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,ApprovalAuditMethodProcessor.class,exception);
			}
		}		
		//_LOGGER.info("Exiting processApprovalAudit");
		return response;
	}
	
	
}

