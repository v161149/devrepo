package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.vbif.DiscountPlans;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.util.DateUtility;

public class GetDiscountPlansResultSetMapper implements RowMapper
{
    static private final Logger _LOGGER = Logger.getLogger(GetDiscountPlansResultSetMapper.class);

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        _LOGGER.debug("Inside GetDiscountPlansResultSetMapper::mapRow rowNum - " + rowNum);
        CommonUtil.printMetaDataInfo(rs.getMetaData());
        
        DiscountPlans record = new DiscountPlans();
		record.setContractId(rs.getString("CONTRACT_ID"));
		record.setDiscPlanId(rs.getString("DISC_PLAN_ID"));
		record.setSourceAcctId(rs.getString("SOURCE_ACCT_ID"));
		record.setSourceEnv(rs.getString("SOURCE_ENV"));
		record.setContractStDt(rs.getString("CONTRACT_ST_DT"));
		record.setNBBEIp(rs.getString("NBBE_IP"));
		record.setConfigDesc(rs.getString("CONFIG_DESC"));
		record.setSourceSysIndr(rs.getString("SOURCE_SYS_INDR"));
		record.setConfigId(rs.getString("CONFIG_ID"));
		record.setContractEndDt(rs.getString("CONTRACT_END_DT"));
		record.setDiscCode(rs.getString("DISC_CODE"));       
        return record;
    }
}
