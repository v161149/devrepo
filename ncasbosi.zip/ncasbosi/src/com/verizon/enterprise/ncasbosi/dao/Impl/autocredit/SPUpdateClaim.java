package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 *Author:Ram/v992473 
 */

public class SPUpdateClaim extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPUpdateClaim.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_REP_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_LOGINID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_USER_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"AREA_OF_ORIG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CENTER_RCPT_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTACT_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_CONTACT_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_TEL_NUM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_TEL_NUM_EXT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_COMM_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_CKT_DETAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_DESCRIPTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_OVERALL_CAT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUPPORTING_DOC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SERVICE_CENTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_CLAIM_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCOUNT_IS_ICB", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ICB_NUMBER", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROOT_CAUSE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUB_ROOT_CAUSE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROOT_CAUSE_DEPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROOT_CAUSE_OWNER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RESPONSIBLE_DIR", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RESPONSIBLE_VP", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CORRECTIVE_ACTIONS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CURRENT_BALANCE", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BALANCE_AGE_0_30", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BALANCE_AGE_31_60", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BALANCE_AGE_61_90", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BALANCE_AGE_OV_90", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_BALANCE", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DAYS_AGED", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"HOW_DISPOSED", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS_DESC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUB_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUBSTATUS_DESC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CUST_APPROVER_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_APPROVER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DENY_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BALANCE_AGE_121_150", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BALANCE_AGE_OV_150", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NASP_SOURCE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NASP_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	 }
	
	public SPUpdateClaim(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_UPDATE_AC_CLAIM, spInOutList);
	}
	
	public Map executeStoredProcedure(Object pClaimMap)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map inputMap = (Map)pClaimMap;
		_LOGGER.info("inputMap::"+inputMap);
		List inputList = new ArrayList();
		inputList.add(new BigDecimal((String)inputMap.get("ESG_CLAIM_NUMBER")));
		inputList.add((String)inputMap.get("USER_ACTION"));
		inputList.add((String)inputMap.get("CLM_REP_VZID"));
		inputList.add((String)inputMap.get("LAST_UPD_LOGINID"));
		inputList.add((String)inputMap.get("LAST_UPD_USER_VZID"));
		inputList.add((String)inputMap.get("LAST_UPD_NAME"));
		inputList.add((String)inputMap.get("LAST_UPD_FIRST"));
		inputList.add((String)inputMap.get("LAST_UPD_LAST"));
		inputList.add((String)inputMap.get("LAST_UPD_MID_IN"));
		inputList.add(setNull((String)inputMap.get("AREA_OF_ORIG")));
		inputList.add(setNull((String)inputMap.get("CENTER_RCPT_DATE")));
		inputList.add(setNull((String)inputMap.get("CONTACT_TYPE")));
		inputList.add(setNull((String)inputMap.get("CUST_CONTACT_NAME")));
		inputList.add(setNull((String)inputMap.get("CUST_TEL_NUM")));
		inputList.add(setNull((String)inputMap.get("CUST_TEL_NUM_EXT")));
		inputList.add(setNull((String)inputMap.get("CUST_EMAIL")));
		inputList.add(setNull((String)inputMap.get("CLM_COMM_DATE")));
		inputList.add(setNull((String)inputMap.get("CLM_CKT_DETAIL")));
		inputList.add(setNull((String)inputMap.get("CLM_DESCRIPTION")));
		inputList.add(setNull((String)inputMap.get("SRC_SYS_BI_ID")));
		inputList.add(setNull((String)inputMap.get("CLM_OVERALL_CAT")));
		inputList.add(setNull((String)inputMap.get("SUPPORTING_DOC")));
		inputList.add(setNull((String)inputMap.get("SERVICE_CENTER")));
		inputList.add(setNull((String)inputMap.get("CLM_CLAIM_TYPE")));
		inputList.add(setNull((String)inputMap.get("ACCOUNT_IS_ICB")));
		inputList.add(setNull((String)inputMap.get("ICB_NUMBER")));
		inputList.add(setNull((String)inputMap.get("ROOT_CAUSE")));
		inputList.add(setNull((String)inputMap.get("SUB_ROOT_CAUSE")));
		inputList.add(setNull((String)inputMap.get("ROOT_CAUSE_DEPT")));
		inputList.add(setNull((String)inputMap.get("ROOT_CAUSE_OWNER")));
		inputList.add(setNull((String)inputMap.get("RESPONSIBLE_DIR")));
		inputList.add(setNull((String)inputMap.get("RESPONSIBLE_VP")));
		inputList.add(setNull((String)inputMap.get("CORRECTIVE_ACTIONS")));
		inputList.add(null);//CURRENT_BALANCE
		inputList.add(null);//BALANCE_AGE_0_30
		inputList.add(null);//BALANCE_AGE_31_60
		inputList.add(null);//BALANCE_AGE_61_90
		inputList.add(null);//BALANCE_AGE_OV_90
		inputList.add(null);//TOTAL_BALANCE
		inputList.add(null);//DAYS_AGED
		inputList.add(setNull((String)inputMap.get("HOW_DISPOSED")));
		inputList.add(null);//CUST_APPROVER_VZID
		inputList.add(null);//CUST_APPROVER_NAME
		inputList.add(setNull((String)inputMap.get("DENY_TEXT")));
		inputList.add(null);//BALANCE_AGE_121_150
		inputList.add(null);//BALANCE_AGE_OV_150
		inputList.add((String)inputMap.get("NASP_SOURCE"));
		inputList.add((String)inputMap.get("NASP_ID"));
		
		//logging the duration of the SP call
		long time_before_executeSP = System.currentTimeMillis();
		_LOGGER.info("Executing the Stored Proecedure::" + getStoredProcedureName());
		Map resMap = executeSP(inputList, false);
		long time_after_executeSP = System.currentTimeMillis();
		_LOGGER.info(getStoredProcedureName() + " " +  inputMap.get("USER_ACTION") + " took " + (commonUtil.formatNumber(new BigDecimal((time_after_executeSP-time_before_executeSP)/1000.0),"###0.00")) + " seconds to execute");
		
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
	
	//setting Null if no Value 
	//especially for this api,null should be set if nothing applicable
	private String setNull(String input){
		return (input!=null && input.trim().length()>0)?input.trim():null;
	}
	
	//set Decimal after checking for empty string/null value
	private BigDecimal setAmount(String input){
		return (input!=null && input.trim().length()>0)?new BigDecimal(input.trim()):null;
	}
}
