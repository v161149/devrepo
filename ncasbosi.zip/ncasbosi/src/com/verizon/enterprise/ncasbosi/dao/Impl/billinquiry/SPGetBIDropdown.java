package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;


import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.dao.Impl.common.GetBIDropDownResultSetMapper;



public class SPGetBIDropdown  extends BaseStoredProcedure
{
	static private final Logger _LOGGER = Logger.getLogger(SPGetBIDropdown.class);
	private static List spInOutList;

	static
	{

		_LOGGER.info("Static Init");
		spInOutList = new ArrayList();
		spInOutList.add(new Object[]{"DROP_DOWN_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	    spInOutList.add(new Object[]{"BI_CATEGORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	    spInOutList.add(new Object[]{"DISTINCT_ONLY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

	    spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	    spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	    spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	    spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	    spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
	    spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});



	}

public SPGetBIDropdown(DataSource dataSource) {
    super(dataSource, NCASBOSIConstants.SP_GET_BI_DROPDOWNS, getInoutList());
  }

//use this when the DROP_DOWN_NAME is BI_REASON
public SPGetBIDropdown(DataSource dataSource,String biCategory) {
    super(dataSource, NCASBOSIConstants.SP_GET_BI_DROPDOWNS, getInoutList(biCategory));
  }

	//forms a new in/out List with unique mapper object bound to each SP call - this mapper must be used when DROP_DOWN_NAME = BI_REASON
		private static List getInoutList(String biCategory){
			List inOutList = new ArrayList();
			GetBIDropDownResultSetMapper rsMapper = new GetBIDropDownResultSetMapper();
			rsMapper.setBiCategory(biCategory);
			inOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, rsMapper});
			inOutList.addAll(spInOutList);
			return inOutList;
	}

  //forms a new in/out List with unique mapper object bound to each SP call
  	private static List getInoutList(){
  		List inOutList = new ArrayList();
  		inOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, new BIOVDropdowns()});
  		inOutList.addAll(spInOutList);
  		return inOutList;
	}

  public Map executeStoredProcedure(Object paramValues) throws Exception {
    _LOGGER.info("Entering executeStoredProcedure for "+getStoredProcedureName());
    List paramValueList =(List)paramValues;
    _LOGGER.info("Exiting executeStoredProcedure for "+getStoredProcedureName());
    String biCategorysearchres = (String) paramValueList.get(1);
	 //populate bicategory of SPGetBIDropdown before executing the stored procedure
	Object[] resultSetDeclarationArray = (Object[])this.getAllParamList().get(0);
	BIOVDropdowns getbiOVDropdowns = (BIOVDropdowns)resultSetDeclarationArray[3];
	getbiOVDropdowns.setBiCategory(biCategorysearchres);
	
	Map resMap = executeSP(paramValueList, false);
    _LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
    return resMap;
  }

}
