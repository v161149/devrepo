package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class BIDataMapper implements RowMapper
{

	static private final Logger _LOGGER = Logger.getLogger(BIDataMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		BillInquiry resBI = null;
		String entType = null;

		if(rs != null)
		{
			_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry.BIDataMapper");
			resBI = new BillInquiry();
			resBI.setSrcSysBIID(rs.getString("SRC_SYS_BI_ID"));
			_LOGGER.info("SRC_SYS_BI_ID= "+rs.getString("SRC_SYS_BI_ID"));

			resBI.setBICategory(rs.getString("BI_CATEGORY"));
			_LOGGER.info("BI_CATEGORY= "+rs.getString("BI_CATEGORY"));

			resBI.setSourcePortal(rs.getString("VBC_OR_VBCC"));
			_LOGGER.info("VBC_OR_VBCC= "+rs.getString("VBC_OR_VBCC"));

			resBI.setOSID(rs.getString("ORIGINATING_SYS_ID"));
			_LOGGER.info("ORIGINATING_SYS_ID= "+rs.getString("ORIGINATING_SYS_ID"));

			resBI.setOrigLogin(rs.getString("ORIGINATOR_LOGINID"));
			_LOGGER.info("ORIGINATOR_LOGINID= "+rs.getString("ORIGINATOR_LOGINID"));

			resBI.setBAN(rs.getString("BAN"));
			_LOGGER.info("BAN= "+rs.getString("BAN"));

			resBI.setSAN(rs.getString("MAN"));
			_LOGGER.info("MAN= "+rs.getString("MAN"));

			resBI.setAcctNum(rs.getString("ACCOUNT_NUM"));
			_LOGGER.info("ACCOUNT_NUM= "+rs.getString("ACCOUNT_NUM"));

			resBI.setAcctName(rs.getString("ACCOUNT_NAME"));
			_LOGGER.info("ACCOUNT_NAME= "+rs.getString("ACCOUNT_NAME"));

			resBI.setInvoiceNum(rs.getString("INVOICE_NUMBER"));
			_LOGGER.info("INVOICE_NUMBER= "+rs.getString("INVOICE_NUMBER"));

			resBI.setBillDate((Date)rs.getObject("BILL_DATE"));
			_LOGGER.info("BILL_DATE= "+rs.getObject("BILL_DATE"));

			resBI.setReasonCode(rs.getString("BI_REASON_CODE"));
			_LOGGER.info("BI_REASON_CODE= "+rs.getString("BI_REASON_CODE"));

			resBI.setReason(rs.getString("BI_REASON_DESC"));
			_LOGGER.info("BI_REASON_DESC= "+rs.getString("BI_REASON_DESC"));


			resBI.setSenderLastName(rs.getString("CONTACT_LAST_NAME"));
			_LOGGER.info("CONTACT_LAST_NAME= "+rs.getString("CONTACT_LAST_NAME"));

			resBI.setSenderFirstName(rs.getString("CONTACT_FIRST_NAME"));
			_LOGGER.info(" "+rs.getString("CONTACT_FIRST_NAME"));

			resBI.setSenderPhone(rs.getString("CONTACT_PHONE"));
			_LOGGER.info("CONTACT_FIRST_NAME= "+rs.getString("CONTACT_PHONE"));

			resBI.setSenderEmail(rs.getString("CONTACT_EMAIL"));
			_LOGGER.info("CONTACT_EMAIL= "+rs.getString("CONTACT_EMAIL"));

			resBI.setAddlEmail(rs.getString("CONTACT_ADDL_EMAIL"));
			_LOGGER.info("CONTACT_ADDL_EMAIL= "+rs.getString("CONTACT_ADDL_EMAIL"));

			//resBI.setInquiryMemo(rs.getString("BI_MEMO"));
			resBI.setDisputeAmount(String.valueOf(rs.getBigDecimal("CREDIT_DISP_AMT")));
            _LOGGER.info("CREDIT_DISP_AMT "+resBI.getDisputeAmount());

			resBI.setCreatedDate((Date)rs.getObject("CREATE_DATE"));
			_LOGGER.info("CREATE_DATE= "+rs.getObject("CREATE_DATE"));

			resBI.setCloseDate((Date)rs.getObject("CLOSED_DATE"));
			_LOGGER.info("CLOSED_DATE= "+rs.getObject("CLOSED_DATE"));
			//rs.getString("ADDL_BI_ID")); NO AVAIL FIELD IN BI
			//resBI.setProblemType(rs.getString("PROBLEM_TYPE"));
			//rs.getString("PROVIDER_NAME")); NO AVAIL FIELD IN BI

			resBI.setCustWO(rs.getString("CUST_WORK_ORDER"));
			_LOGGER.info("CUST_WORK_ORDER= "+rs.getString("CUST_WORK_ORDER"));

			resBI.setStatus(rs.getString("BI_STATUS_DESC"));
			_LOGGER.info("BI_STATUS_DESC= "+rs.getString("BI_STATUS_DESC"));

			entType = rs.getString("ENTITLEMENT_OID_TY");
			_LOGGER.info("ENTITLEMENT_OID_TY= "+rs.getString("ENTITLEMENT_OID_TY"));

			_LOGGER.info("ENTITLEMENT_OID= "+rs.getString("ENTITLEMENT_OID"));

			if(entType != null && entType.equalsIgnoreCase("SP"))
			{
				resBI.setSubscriptionOid(Long.parseLong(rs.getString("ENTITLEMENT_OID")));

			}
			else
			{
				resBI.setSubscriberOid(Long.parseLong(rs.getString("ENTITLEMENT_OID")));

			}

			resBI.setClaimTrackingNumber(rs.getString("SRC_SYS_CLM_ID"));
			_LOGGER.info("SRC_SYS_CLM_ID= "+rs.getString("SRC_SYS_CLM_ID"));

			resBI.setSourcePortal(rs.getString("VBC_OR_VBCC"));
			_LOGGER.info("VBC_OR_VBCC= "+rs.getString("VBC_OR_VBCC"));

			resBI.setStatusCode(rs.getInt("BI_STATUS"));
			_LOGGER.info("BI_STATUS= "+rs.getInt("BI_STATUS"));

			resBI.setCustSvcType(rs.getString("CUST_SVC_TYPE"));
			_LOGGER.info("CUST_SVC_TYPE=" + rs.getString("CUST_SVC_TYPE"));

			resBI.setCategoryCode(rs.getString("CATEGORY_CODE"));
			_LOGGER.info("CATEGORY_CODE=" + rs.getString("CATEGORY_CODE"));

			resBI.setCategoryValue(rs.getString("CATEGORY_DESC"));
			_LOGGER.info("CATEGORY_CODE=" + rs.getString("CATEGORY_DESC"));

			if (rs.getString("ATTACHMENT_FLAG")!=null&&rs.getString("ATTACHMENT_FLAG").equalsIgnoreCase("Y")) {
        	resBI.setAttachmentFlg(true);
      		} else {
        	resBI.setAttachmentFlg(false);
      		}
      		_LOGGER.info("ATTACHMENT_FLAG= "+rs.getString("ATTACHMENT_FLAG"));

      		resBI.setAddrAttention(rs.getString("ADDR_ATTENTION"));
			_LOGGER.info("ADDR_ATTENTION=" + rs.getString("ADDR_ATTENTION"));

			resBI.setAddrLine1(rs.getString("ADDR_LINE1"));
			_LOGGER.info("ADDR_LINE1=" + rs.getString("ADDR_LINE1"));

			if(CommonUtil.isNotNull((String) rs.getString("ADDR_LINE2")))
			{
				resBI.setAddrLine2(((String) rs.getString("ADDR_LINE2")).trim());
			}

			_LOGGER.info("ADDR_LINE2=" + rs.getString("ADDR_LINE2"));

			resBI.setAddrCity(rs.getString("ADDR_CITY"));
			_LOGGER.info("ADDR_CITY=" + rs.getString("ADDR_CITY"));

			resBI.setAddrState(rs.getString("ADDR_STATE"));
			_LOGGER.info("ADDR_STATE=" + rs.getString("ADDR_STATE"));

			resBI.setAddrZip(rs.getString("ADDR_ZIP"));
			_LOGGER.info("ADDR_ZIP=" + rs.getString("ADDR_ZIP"));

			resBI.setAttachmentInd(rs.getString("ATTACH_LETTER_IND"));
			_LOGGER.info("ATTACH_LETTER_IND=" + rs.getString("ATTACH_LETTER_IND"));

			resBI.setInvoiceCopyDate(CommonUtil.getStrFromDate((Date)rs.getObject("INV_CPY_DATE")));
			_LOGGER.info("INV_CPY_DATE=" + resBI.getInvoiceCopyDate());

			resBI.setNewAddrAttention(rs.getString("NEW_ADD_ATTENTION"));
			_LOGGER.info("NEW_ADD_ATTENTION=" + rs.getString("NEW_ADD_ATTENTION"));

			resBI.setNewAddrLine1(rs.getString("NEW_ADD_LINE1"));
			_LOGGER.info("NEW_ADD_LINE1=" + rs.getString("NEW_ADD_LINE1"));

			if(CommonUtil.isNotNull((String) rs.getString("NEW_ADD_LINE2")))
			{
				resBI.setNewAddrLine2(((String) rs.getString("NEW_ADD_LINE2")).trim());
			}

			_LOGGER.info("NEW_ADD_LINE2=" + rs.getString("NEW_ADD_LINE2"));

			resBI.setNewAddrCity(rs.getString("NEW_ADD_CITY"));
			_LOGGER.info("NEW_ADD_CITY=" + rs.getString("NEW_ADD_CITY"));

			resBI.setNewAddrState(rs.getString("NEW_ADD_STATE"));
			_LOGGER.info("NEW_ADD_STATE=" + rs.getString("NEW_ADD_STATE"));

			resBI.setNewAddrZip(rs.getString("NEW_ADD_ZIP"));
			_LOGGER.info("NEW_ADD_ZIP=" + rs.getString("NEW_ADD_ZIP"));

			if(CommonUtil.isNotNull((String) rs.getString("CONTRACT_ID")))
			{
				resBI.setContractId(((String)rs.getString("CONTRACT_ID")).trim());
			}

			_LOGGER.info("CONTRACT_ID=" + rs.getString("CONTRACT_ID"));

			if(CommonUtil.isNotNull((String) rs.getString("AMMENDMENT_ID")))
			{
				resBI.setAmendmentId(((String) rs.getString("AMMENDMENT_ID")).trim());
			}

			_LOGGER.info("AMMENDMENT_ID=" + rs.getString("AMMENDMENT_ID"));

			if(CommonUtil.isNotNull((String) rs.getString("ADDL_ACCT_NOS")))
			{
				resBI.setAdditionalAcctNumbers(((String) rs.getString("ADDL_ACCT_NOS")).trim());
			}

			_LOGGER.info("ADDL_ACCT_NOS=" + rs.getString("ADDL_ACCT_NOS"));

			resBI.setAdjustmentReason(rs.getString("ADJUST_REASON"));
			_LOGGER.info("ADJUST_REASON=" + rs.getString("ADJUST_REASON"));

			resBI.setExpectedAdjustment(String.valueOf(rs.getBigDecimal("EXPECTED_AMOUNT")));
			_LOGGER.info("EXPECTED_AMOUNT=" + resBI.getExpectedAdjustment());

			if(CommonUtil.isNotNull((String) rs.getString("TRANS_FROM_ACCT")))
			{
				resBI.setTransferFrom(((String) rs.getString("TRANS_FROM_ACCT")).trim());
			}

			_LOGGER.info("TRANS_FROM_ACCT=" + rs.getString("TRANS_FROM_ACCT"));

			if(CommonUtil.isNotNull((String) rs.getString("TRANS_TO_ACCT")))
			{
				resBI.setTransferTo(((String) rs.getString("TRANS_TO_ACCT")).trim());
			}

			_LOGGER.info("TRANS_TO_ACCT=" + rs.getString("TRANS_TO_ACCT"));

			resBI.setTransferAmount(String.valueOf(rs.getBigDecimal("TRANS_AMOUNT")));
			_LOGGER.info("TRANS_AMOUNT=" + resBI.getTransferAmount());

			resBI.setServiceRequested(rs.getString("REQUESTED_SVC"));
			_LOGGER.info("REQUESTED_SVC=" + rs.getString("REQUESTED_SVC"));

			resBI.setInstallationDate(CommonUtil.getDisplayVAMDateFromString((Date)rs.getObject("REQ_INSTL_DATE")));
			_LOGGER.info("REQ_INSTL_DATE=" + resBI.getInstallationDate());

			resBI.setBillingDate(CommonUtil.getDisplayVAMDateFromString((Date)rs.getObject("DT_BILLING_BEGAN")));
			_LOGGER.info("DT_BILLING_BEGAN=" + resBI.getBillingDate());

			resBI.setImpactedInvoicePageNum(rs.getString("INVOICE_PG_NO"));
			_LOGGER.info("INVOICE_PG_NO=" + rs.getString("INVOICE_PG_NO"));

			resBI.setProblemBeganDate(CommonUtil.getDisplayVAMDateFromString((Date)rs.getObject("PROB_BEGIN_DATE")));
			_LOGGER.info("PROB_BEGIN_DATE=" + resBI.getProblemBeganDate());

			resBI.setProblemEndDate(CommonUtil.getDisplayVAMDateFromString((Date)rs.getObject("PROB_END_DATE")));
			_LOGGER.info("PROB_END_DATE=" + resBI.getProblemEndDate());

			if(CommonUtil.isNotNull((String) rs.getString("PROMOTION_TYPE")))
			{
				resBI.setPromotionType(((String) rs.getString("PROMOTION_TYPE")).trim());
			}

			_LOGGER.info("PROMOTION_TYPE=" + rs.getString("PROMOTION_TYPE"));

			resBI.setAffectedServiceId(rs.getString("SLA_SRVC_ID"));
			_LOGGER.info("SLA_SRVC_ID=" + rs.getString("SLA_SRVC_ID"));

			resBI.setTroubleTicketNum(rs.getString("TT_NUMBER"));
			_LOGGER.info("TT_NUMBER=" + rs.getString("TT_NUMBER"));

			resBI.setTaxType(rs.getString("TAX_TYPE"));
			_LOGGER.info("TAX_TYPE=" + rs.getString("TAX_TYPE"));

			resBI.setDisconnectDate(CommonUtil.getDisplayVAMDateFromString((Date)rs.getObject("ORIG_DISC_DATE")));
			_LOGGER.info("ORIG_DISC_DATE=" + resBI.getDisconnectDate());

			resBI.setPaymentPostedAcct(rs.getString("POSTED_TO_ACCT"));
			_LOGGER.info("POSTED_TO_ACCT=" + rs.getString("POSTED_TO_ACCT"));

			resBI.setCorrectPaymentAcct(rs.getString("CORRECT_PYMNT_ACT"));
			_LOGGER.info("CORRECT_PYMNT_ACT=" + rs.getString("CORRECT_PYMNT_ACT"));

			resBI.setRefundAmount(String.valueOf(rs.getBigDecimal("REQ_REFUND_AMT")));
			_LOGGER.info("REQ_REFUND_AMT=" + resBI.getRefundAmount());


		}

	  return resBI;
	}

}