package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;import com.verizon.enterprise.common.util.AccountNumberUtil;import com.verizon.enterprise.common.util.DateUtility;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
public class GetVgwAfpBillListMapper implements RowMapper{
	private static final Logger _LOGGER = Logger.getLogger(GetVgwAfpBillListMapper.class);
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.debug("GetVgwAfpBillListMapper - Mapping Row# "+rowNum);		HiSelectDO hiDO = null;		String formatDb2 = "yyyy-MM-dd";		String formatDisplayed = "MM/dd/yyyy";
		if(rs!=null){			hiDO = new HiSelectDO();			//get outputs			hiDO.setMan(val(rs.getString("MAN")));			hiDO.setBan(val(rs.getString("BAN")));			hiDO.setOsid(val(rs.getString("OSID")));			hiDO.setBillDate(val(rs.getString("BILL_DATE")));  //date			hiDO.setSections(val(rs.getInt("SECTIONS") + "")); //sections			hiDO.setStartSection("0"); // start section			hiDO.setLocation(val(rs.getString("LOCATION"))); //location -> D=disk T=tape			hiDO.setAcctLevel(val(rs.getString("MASTER"))); //acctLevel -> M=master S=standalone			hiDO.setFileType(val(rs.getString("FORMAT"))); //fileType -> afp or pdf			hiDO.setAban(val(rs.getString("ABAN"))); //aban (invoice number)			hiDO.setDocType(val(rs.getString("DOCUMENT_TYPE")));  //labels displayed to user				//create fields mapped to the screen.			hiDO.setYearMonth(CommonUtil.formatDate(hiDO.getBillDate(), "yyyy-MM-dd", "yyyy MMM"));			if ("VW".equals(hiDO.getOsid()))			{				hiDO.setBillPayer(AccountNumberUtil.base36ToBase10(hiDO.getBan()));			}			else			{				hiDO.setBillPayer(hiDO.getBan());			}			hiDO.setInvNbr(hiDO.getAban());			hiDO.setInvDate(CommonUtil.formatDate(hiDO.getBillDate(), formatDb2, formatDisplayed));	
		}
		return hiDO;
	}
	
	private String val(String input)	{		if (input == null)			return "";				return input.trim();	}
}
