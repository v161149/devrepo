package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.GBREMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPManageGBRProfile extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPManageGBRProfile.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"BP_DAY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"START_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CONFIG_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ACCT_LVL_INDR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CURRENCY_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"EXCHANGE_RATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAYMENT_DUE_INT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"OTH_CONTACT_INFO_1", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"OTH_CONTACT_INFO_2", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PROFILE_COMPLETE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PROFILE_COMMENT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"SMP_CONTRACT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"NASP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"REVLOC_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
	}

	public SPManageGBRProfile(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_PROFILE, spInOutList);
	}

	/**
	 * @param userId
	 * @param debugLevel
	 * @param profile
	 * @return
	 * @throws Exception
	 */
	public Map executeStoredProcedure(String userId, String debugLevel,
			GBREMediaProfile profile, String action)throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(profile.getUserId());//USER_ID
		paramValueList.add(profile.getUserName());//USER_NAME
		paramValueList.add(debugLevel);//DEBUG_LEVEL
        DecimalFormat decimalFormatter = new DecimalFormat("##########");
		String configSubscriptionOid = decimalFormatter.format(profile.getConfigSubscriptionOid());
		_LOGGER.info("configSubscriptionOid - " + configSubscriptionOid);
		paramValueList.add(configSubscriptionOid);//CONFIG_SUBS_OID
		paramValueList.add(action);//ACTION

		Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = formatter.format(profile.getStartDate());
		_LOGGER.info("Formatted Expected Start Date = " + strDate);

		paramValueList.add(profile.getBillPeriod());//BP_DAY
		paramValueList.add(strDate);//START_DATE
		paramValueList.add(profile.getConfigName());//CONFIG_NAME
		paramValueList.add("A");//ACCT_LVL_INDR
		paramValueList.add(profile.getLanguageCode());//LANGUAGE_CODE
		paramValueList.add(profile.getCurrencyCode());//CURRENCY_CODE
		paramValueList.add(profile.getExchangeRate());//EXCHANGE_RATE
		paramValueList.add(String.valueOf(profile.getPaymentDueInterval()));//PAYMENT_DUE_INT
		paramValueList.add(profile.getOtherContactInfo1());//OTH_CONTACT_INFO_1
		paramValueList.add(profile.getOtherContactInfo2());//OTH_CONTACT_INFO_2
		paramValueList.add(profile.getProfComplete());//PROFILE_COMPLETE
		paramValueList.add(profile.getComments());//PROFILE_COMMENT
		if (profile.getSmpContractId().equalsIgnoreCase("N/A")) {
			paramValueList.add("");//SMP_CONTRACT_ID
		} else {
			paramValueList.add(profile.getSmpContractId());//SMP_CONTRACT_ID
		}
		paramValueList.add(profile.getNaspId()); //NASP
		paramValueList.add(profile.getRevLoc()); //REVLOC_ID

		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}

