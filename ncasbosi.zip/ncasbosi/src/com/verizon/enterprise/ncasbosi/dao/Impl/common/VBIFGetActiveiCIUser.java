package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.approval.Designation;

/** @author V744829 */
public class VBIFGetActiveiCIUser{

	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	private JdbcTemplate jdbcTemplate;			
	private static VBIFGetActiveiCIUser.SearchUsersRowMapper mapperObj;
		
	static{
		//single mapperObject is created that services mutliple calls 
		mapperObj = new VBIFGetActiveiCIUser.SearchUsersRowMapper();
	}
	
	public VBIFGetActiveiCIUser(JdbcTemplate jdbcTemplate){						
		this.jdbcTemplate = jdbcTemplate;				
	}
	
	public List<Designation> getActiveiCIUser(String sql, List<String> whereInputs){
		String METHOD_NAME="VBIFGetActiveiCIUser->getActiveiCIUser:";
		_LOGGER.info(METHOD_NAME+sql);
		int inputSize = whereInputs.size();
		Object[] params = new Object[inputSize];
		int[] types = new int[inputSize];
		for(int i=0;i<inputSize;i++){
			params[i] = whereInputs.get(i);
			types[i] = Types.VARCHAR;
		}		
		List<Designation> userList = this.jdbcTemplate.query(sql, params, types, mapperObj);
		return userList;
	}
	
	private static class SearchUsersRowMapper implements RowMapper{
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			Designation designationObj = null;
			if (rs != null) {
				designationObj = new Designation();
				designationObj.setFirstName(rs.getString("FIRST_NAME"));
				designationObj.setLastName(rs.getString("LAST_NAME"));
				designationObj.getUserDelegation().setDesignatorVZID(rs.getString("LOGIN_ID"));
			}
			return designationObj;
		}
	}
}