package com.verizon.enterprise.ncasbosi.dao.Impl.usagerepository;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.GetAdjustmentsMapper;
import com.verizon.enterprise.common.ncas.usagerepository.UrDO;

public class SPGetArchUsage extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetArchUsage.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
	     spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetUsageMapper()});
		 
		 spInOutList.add(new Object[]{"WTN",        getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STOP_DATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIG_TERM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"MSG_CNT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERR_MSG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	}

	public SPGetArchUsage(DataSource dataSource){
		super(dataSource, getURSchemaName() + "." + "GET_ARCH_USAGE", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map requestMap = (HashMap)input;
		UrDO urDO = (UrDO)requestMap.get("urDO");
		
		//set max rows to return to what the user requested
		this.getJdbcTemplate().setMaxRows(urDO.getMaxRows());
		
		List callList = new ArrayList();
		callList.add(urDO.getWtn());       // WTN
		callList.add(urDO.getStartDate()); // START_DATE
		callList.add(urDO.getStopDate());  // STOP_DATE
		callList.add(urDO.getOrigTerm());  // ORIG_TERM
		
		Map responseMap = executeSP(callList, false);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
	}
	
}
