package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.dataobjects.Structure;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.NcasConstants;



public class SPDeferredDownloadRequest extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPDeferredDownloadRequest.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINK_PARAMS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FILTER_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SUBSET", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"EMPLOYEE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PORTAL_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MISC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STRUCTURE_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"STRUCTURE_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"POSITION_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"POSITION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CHANNEL_CD_LIST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"ALIAS_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"MATCH_FOUND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"BILL_FOUND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"FTP_USERID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_PASSWORD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_HOST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_DIRECTORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FTP_FILENAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DATAFORMAT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});


	}




	public SPDeferredDownloadRequest(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_DEFERRED_DL, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel,Map inputMap)throws Exception
	{
		String METHOD_NAME = "executeStoredProcedure::";
		List paramValueList = new ArrayList();

		StringBuffer myParams = new StringBuffer();
		myParams.append("SP Params [");

		_LOGGER.info(METHOD_NAME + " Input Map " +  inputMap.toString());
		//get all the parameters from input map

		paramValueList.add(userId); //APP_USER_ID
		myParams.append(userId + "^");

		paramValueList.add(debugLevel); //DEBUG_LEVEL
		myParams.append(debugLevel + "^");

		String pageID = (String) inputMap.get("pageId");
		paramValueList.add(pageID); //PAGEID
		myParams.append(pageID + "^");
		_LOGGER.debug(METHOD_NAME + "pageID" + pageID );

		String linkParams = (String) inputMap.get("linkParams");
		paramValueList.add(linkParams); //LINK_PARAMS
		myParams.append(linkParams + "^");
		_LOGGER.debug(METHOD_NAME + "linkParams" + linkParams );

		String filterString = (String) inputMap.get("filterString");
		paramValueList.add(filterString); //FILTER_STRING
		myParams.append(filterString + "^");
		_LOGGER.debug(METHOD_NAME + "filterString" + filterString );

		String sortString = (String) inputMap.get("sortString");
		paramValueList.add(sortString); //SORT_STRING
		myParams.append(sortString + "^");
		_LOGGER.debug(METHOD_NAME + "sortString" + sortString );

		String pageSubSet = (String) inputMap.get("pageSubSet");
		paramValueList.add(pageSubSet); //PAGE_SUBSET
		myParams.append(pageSubSet + "^");
		_LOGGER.debug(METHOD_NAME + "pageSubSet" + pageSubSet );


		paramValueList.add(userId); //USER_ID
		myParams.append(userId + "^");
		_LOGGER.debug(METHOD_NAME + "userId" + userId );


		paramValueList.add(debugLevel); //DEBUG_LEVEL
		myParams.append(debugLevel + "^");
		_LOGGER.debug(METHOD_NAME + "debugLevel" + debugLevel );

		String employeeFlag  = (String) inputMap.get("employee_flag");
		paramValueList.add(employeeFlag); //EMPLOYEE_FLAG
		myParams.append(employeeFlag + "^");
		_LOGGER.debug(METHOD_NAME + "employeeFlag" + employeeFlag );


		String portalUserID  = (String) inputMap.get("portal_user_id");
		paramValueList.add(portalUserID); //PORTAL_USER_ID
		myParams.append(portalUserID + "^");
		_LOGGER.debug(METHOD_NAME + "portalUserID" + portalUserID );

		String misc = (String) inputMap.get("misc");
		String action = (String) inputMap.get("action");
		Structure struct = (Structure)inputMap.get("STRUCTURE");

		paramValueList.add(misc);  //MISC
		myParams.append(misc + "^");
		_LOGGER.debug(METHOD_NAME + "misc" + misc );

		paramValueList.add(action);//ACTION
		myParams.append(action + "^");
		_LOGGER.debug(METHOD_NAME + "action" + action );


		paramValueList.add(struct.getStructureType());    //STRUCTURE_TYPE inout
		myParams.append(struct.getStructureType() + "^");
		_LOGGER.debug(METHOD_NAME + "struct.getStructureType()" + struct.getStructureType() );


		paramValueList.add(struct.getStructureValue());   //STRUCTURE_OID inout
		myParams.append(struct.getStructureValue() + "^");
		_LOGGER.debug(METHOD_NAME + "struct.getStructureValue()" + struct.getStructureValue() );


		paramValueList.add(struct.getPositionType());    //POSITION_TYPE inout
		myParams.append(struct.getPositionType() + "^");
		_LOGGER.debug(METHOD_NAME + "struct.getPositionType()" + struct.getPositionType() );

		paramValueList.add(struct.getPositionValue());   //POSITION_OID inout
		myParams.append(struct.getPositionValue() + "^");
		_LOGGER.debug(METHOD_NAME + "struct.getPositionValue()" + struct.getPositionValue() );

		String channelCodes = (String) inputMap.get("CHANNEL_CODES");
		paramValueList.add(channelCodes);  //CHANNEL_CD_LIST in
		myParams.append(channelCodes + "^");
		_LOGGER.debug(METHOD_NAME + "channelCodes" + channelCodes);

		paramValueList.add("Y");  //ALIAS_FLAG in
		myParams.append("Y" + "^");

		String lang = (String)inputMap.get("LANG");
		if(lang==null||(lang!=null&&lang.trim().equals("")))
			lang=NcasConstants.LANG_CODE_US_ENGLISH_VAM;
		paramValueList.add(lang);
		myParams.append(lang + "^");
		_LOGGER.debug(METHOD_NAME + "lang" + lang );

		String ftpUserid = (String) inputMap.get("ftp_userid");
		paramValueList.add(ftpUserid); //FTP_USERID
		myParams.append(ftpUserid + "^");
		_LOGGER.debug(METHOD_NAME + "ftpUserid" + ftpUserid );

		String ftpPassword = (String) inputMap.get("ftp_password");
		paramValueList.add(ftpPassword); //FTP_PASSWORD
		myParams.append(ftpPassword + "^");
		_LOGGER.debug(METHOD_NAME + "ftpPassword" + ftpPassword );

		String ftpHostname = (String) inputMap.get("ftp_hostname");
		paramValueList.add(ftpHostname); //FTP_HOST_NAME
		myParams.append(ftpHostname + "^");
		_LOGGER.debug(METHOD_NAME + "ftpHostname" + ftpHostname );

		String ftpDirectory = (String) inputMap.get("ftp_directory");
		paramValueList.add(ftpDirectory); //FTP_DIRECTORY
		myParams.append(ftpDirectory + "^");
		_LOGGER.debug(METHOD_NAME + "ftpDirectory" + ftpDirectory );

		String ftpFilename = (String) inputMap.get("ftp_filename");
		paramValueList.add(ftpFilename); //FTP_FILENAME
		myParams.append(ftpFilename + "^");
		_LOGGER.debug(METHOD_NAME + "ftpFilename" + ftpFilename );

		String dataformat = (String) inputMap.get("dataformat");
		paramValueList.add(dataformat); //DATAFORMAT
		myParams.append(dataformat + "^");
		_LOGGER.debug(METHOD_NAME + "dataformat" + dataformat );


		_LOGGER.debug(METHOD_NAME + myParams.toString());
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);

		return procMap ;
	}
	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
