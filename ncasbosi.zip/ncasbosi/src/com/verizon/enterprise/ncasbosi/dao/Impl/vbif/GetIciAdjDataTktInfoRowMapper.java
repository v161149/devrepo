package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.vbif.AdjTktInfo;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetIciAdjDataTktInfoRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetIciAdjDataTktInfoRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetIciAdjDataTktInfoRowMapper::mapRow rowNum - " + rowNum);
		AdjTktInfo adjTktInfo = new AdjTktInfo();

		String adjCategory = rs.getString("ADJ_CATEGORY");     
		Date adjFromDt = rs.getDate("ADJUST_FROM_DT"); 
		Date adjToDt = rs.getDate("ADJUST_THRU_DT");   
		String serviceTypeCd = rs.getString("SERVICE_TYPE_CD");
		String serviceTypeDesc = rs.getString("SVC_TYPE_DESC");
		String rootCauseCd = rs.getString("RT_CAUSE_CD");          
		String rootCauseDesc = rs.getString("ROOT_CAUSE");      
		String subRootCauseCd = rs.getString("SUB_RT_CAUSE_CD");   
		String subRootCauseDesc = rs.getString("SUB_ROOT_CAUSE");
		String rootCauseDeptCd = rs.getString("RT_CAUSE_DEPT_CD");  
		String rootCauseDeptDesc = rs.getString("RT_CAUSE_DEPT_DESC");
		String rootCauseOwner = rs.getString("ROOT_CAUSE_OWNER"); 
		String respDir = rs.getString("RESPONSIBLE_DIR");  
		String respVp = rs.getString("RESPONSIBLE_VP");    
		String issueCauseSum = rs.getString("ISSUE_CAUSE_SUM"); 
		String rtCauseCorr = rs.getString("RT_CAUSE_CORRECTION"); 
		String estAmtCr = commonUtil.formatNumber(rs.getBigDecimal("EST_AMT_CR"), "#,###,###,##0.00;-#,###,##0.00");
		String estAmtDr = commonUtil.formatNumber(rs.getBigDecimal("EST_AMT_DR"),"#,###,##0.00;-#,###,##0.00");   
		String estAmtTot = commonUtil.formatNumber(rs.getBigDecimal("EST_AMT_TOT"),"#,###,##0.00;-#,###,##0.00"); 
		String underContract = rs.getString("UNDER_CONTRACT");
		String contractNum = rs.getString("CONTRACT_NBR");
		String aprvAmount = commonUtil.formatNumber(rs.getBigDecimal("APPROVAL_AMOUNT"),"#,###,##0.00;-#,###,##0.00");
		String aprvName = rs.getString("APPROVER_NAME");
		String aprvAction = rs.getString("APPROVAL_ACTION");
		
		if (CommonUtil.isNotNull(adjCategory)) {
			adjTktInfo.setAdjCategory(adjCategory.trim());
		}
		try { 
			if (adjFromDt != null) {
				adjTktInfo.setAdjFromDt(CommonUtil.getFormattedDateString(adjFromDt, "dd/MMM/yyyy"));
			}
			if (adjToDt != null) {
				adjTktInfo.setAdjToDt(CommonUtil.getFormattedDateString(adjToDt, "dd/MMM/yyyy"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
 		if (CommonUtil.isNotNull(serviceTypeCd)) {
			adjTktInfo.setServiceTypeCd(serviceTypeCd.trim());
		}
		if (CommonUtil.isNotNull(serviceTypeDesc)) {
			adjTktInfo.setServiceTypeDesc(serviceTypeDesc.trim());
		}
		if (CommonUtil.isNotNull(rootCauseCd)) {
			adjTktInfo.setRootCauseCd(rootCauseCd.trim());
		}
		if (CommonUtil.isNotNull(rootCauseDesc)) {
			adjTktInfo.setRootCauseDesc(rootCauseDesc.trim());
		}
		if (CommonUtil.isNotNull(subRootCauseCd)) {
			adjTktInfo.setSubRootCauseCd(subRootCauseCd.trim());
		}
		if (CommonUtil.isNotNull(subRootCauseDesc)) {
			adjTktInfo.setSubRootCauseDesc(subRootCauseDesc.trim());
		}
		if (CommonUtil.isNotNull(rootCauseDeptCd)) {
			adjTktInfo.setRootCauseDeptCd(rootCauseDeptCd.trim());
		}
		if (CommonUtil.isNotNull(rootCauseDeptDesc)) {
			adjTktInfo.setRootCauseDeptDesc(rootCauseDeptDesc.trim());
		}		
		if (CommonUtil.isNotNull(rootCauseOwner)) {
			adjTktInfo.setRootCauseOwner(rootCauseOwner.trim());
		}		
		if (CommonUtil.isNotNull(respDir)) {
			adjTktInfo.setRespDir(respDir.trim());
		}		
		if (CommonUtil.isNotNull(respVp)) {
			adjTktInfo.setRespVp(respVp.trim());
		}		
		if (CommonUtil.isNotNull(issueCauseSum)) {
			adjTktInfo.setIssueCauseSum(issueCauseSum.trim());
		}		
		if (CommonUtil.isNotNull(rtCauseCorr)) {
			adjTktInfo.setRtCauseCorr(rtCauseCorr.trim());
		}		
		if (CommonUtil.isNotNull(estAmtCr)) {
			adjTktInfo.setEstAmtCr(estAmtCr.trim());
		}		
		if (CommonUtil.isNotNull(estAmtDr)) {
			adjTktInfo.setEstAmtDr(estAmtDr.trim());
		}		
		if (CommonUtil.isNotNull(estAmtTot)) {
			adjTktInfo.setEstAmtTot(estAmtTot.trim());
		}		
		if (CommonUtil.isNotNull(underContract)) {
			adjTktInfo.setUnderContract(underContract.trim());
		}	
		if (CommonUtil.isNotNull(contractNum)) {
			adjTktInfo.setContractNum(contractNum.trim());
		}		
		if (CommonUtil.isNotNull(aprvAmount)) {
			adjTktInfo.setAprvAmount(aprvAmount.trim());
		}		
		if (CommonUtil.isNotNull(aprvName)) {
			adjTktInfo.setAprvName(aprvName.trim());
		}		
		if (CommonUtil.isNotNull(aprvAction)) {
			adjTktInfo.setAprvAction(aprvAction.trim());
		}
		return adjTktInfo;
	}
}
