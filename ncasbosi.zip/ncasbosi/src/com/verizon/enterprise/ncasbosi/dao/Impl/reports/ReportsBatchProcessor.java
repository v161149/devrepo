package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.reports.ReportsBatchInterface;

/*
 * This class decides which operation to be performed
 */
public class ReportsBatchProcessor implements NCASBOSIConstants {
	private static ReportsBatchInterface interfaceObj;
	private static final Logger _LOGGER = Logger.getLogger(ReportsBatchProcessor.class);
	
	private static synchronized ReportsBatchInterface getProcessorObject(){
		if(interfaceObj==null){
			_LOGGER.info("Getting the singleton Reports Batch Object");
			interfaceObj = DAOFactory.getInstance().getReportsBatchImpl();
			_LOGGER.info("Successfully retrieved the reference to the Reports Batch Object");
		}
		return interfaceObj;
	}
	
	public static Map processRptBatchRequest(Object input,String function)throws Exception
	{
		_LOGGER.info("Entering processRptBatchRequest");
		Map responseMap = null;
		try{
			Method method = getProcessorObject().getClass().getMethod(function, new Class[]{Object.class});
			responseMap = (Map)method.invoke(getProcessorObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException(BILLING_EXCEPTION_850,ReportsBatchProcessor.class,exception.getTargetException());
		}
		
		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processRptBatchRequest");
		return responseMap;
	}
}
