package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.billinquiry.IBICategory;

public class SPGetIBICATDropdowns  extends BaseStoredProcedure {
  static private final Logger _LOGGER = Logger.getLogger(SPGetIBICATDropdowns.class);
  private static List spInOutList;

  static {
    _LOGGER.info("Static Init");
    spInOutList = new ArrayList();
    spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, new IBICATDropdowns()});
    spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
    spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
  }

  public SPGetIBICATDropdowns(DataSource dataSource) {
    super(dataSource, NCASBOSIConstants.SP_GET_IBI_CATEGORY, spInOutList);
  }

  public Map executeStoredProcedure(Object paramValues) throws Exception {
    _LOGGER.info("Entering executeStoredProcedure for "+getStoredProcedureName());
    List paramValueList =(List)paramValues;
    _LOGGER.info("Exiting executeStoredProcedure for "+getStoredProcedureName());
    Map resMap = executeSP(paramValueList, false);
    _LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
    return resMap;
  }

  public static final class IBICATDropdowns implements RowMapper {

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      IBICategory iBICategoryObj = new IBICategory();
      if(rs != null) {
        iBICategoryObj.setRegioncode(rs.getString("REGION_CD"));
        _LOGGER.info("REGION_CD = "+iBICategoryObj.getRegioncode());
        iBICategoryObj.setCategorycode(rs.getString("CATEGORY_CD"));
        _LOGGER.info("CATEGORY_CD = "+iBICategoryObj.getCategorycode());
        iBICategoryObj.setCategorydesc(rs.getString("CATEGORY_DESC"));
        _LOGGER.info("CATEGORY_DESC = "+iBICategoryObj.getCategorydesc());
        iBICategoryObj.setSubcatcode(rs.getString("SUB_CAT_CD"));
        _LOGGER.info("SUB_CAT_CD = "+iBICategoryObj.getSubcatcode());
        iBICategoryObj.setSubcatdesc(rs.getString("SUB_CAT_DESC"));
        _LOGGER.info("SUB_CAT_DESC = "+iBICategoryObj.getSubcatdesc());
      }
      return iBICategoryObj;
    }
  }
}
