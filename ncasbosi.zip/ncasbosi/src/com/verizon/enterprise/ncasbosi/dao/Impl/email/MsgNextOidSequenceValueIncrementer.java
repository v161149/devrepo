package com.verizon.enterprise.ncasbosi.dao.Impl.email;

import javax.sql.DataSource;

import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;

public class MsgNextOidSequenceValueIncrementer extends
		OracleSequenceMaxValueIncrementer {	
	
	/**
	 * Default Constructor
	 */
	public MsgNextOidSequenceValueIncrementer() {
		super();
	}

	/**
	 * @param ds
	 * @param incrementerName
	 */
	public MsgNextOidSequenceValueIncrementer(DataSource ds, String incrementerName) {
		super(ds, incrementerName);
	}

	protected String getSequenceQuery() {
		return "select get_table_id('" + getIncrementerName() + "') from dual";
	}

}
