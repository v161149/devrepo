package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.GBREMediaProfile;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetGBRProfileRowMapperImpl implements RowMapper
{
	static private final Logger logger = Logger.getLogger(GetGBRProfileRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "GetGBRProfileRowMapperImpl::mapRow()";

		logger.debug(METHOD_NAME + " ENTER");
		logger.info(METHOD_NAME + " rowNumber=" + rowNum);

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		GBREMediaProfile profile = new GBREMediaProfile();

		try
		{
			String configSubscriptionOid = rs.getString("CONFIG_SUBS_OID");
			String configId = rs.getString("CONFIG_ID");
			String serviceType = rs.getString("SERVICE_TYPE");
			String startDate = rs.getString("START_DATE");
			String endDate = rs.getString("END_DATE");
			String bpDay = rs.getString("BP_DAY");
			String dateCreated = rs.getString("DATE_CREATED");
			String companyName = rs.getString("COMPANY_NAME");
			String configName = rs.getString("CONFIG_NAME");
			String userName = rs.getString("EXT_UPDT_USR_NAME");// - Char(80)
			String userId = rs.getString("EXT_UPDT_USR_ID");// - Char(30)
			String profileComplete = rs.getString("PROFILE_COMPLETE");//Char(1)
			String profileStatus = rs.getString("PROF_STATUS");//Char(1)
			String profileStatusComment = rs.getString("PROF_STATUS_COMM");//Char(50)
			String comment = rs.getString("PROFILE_COMMENT");// VARCHAR(500)
			String subscriberOid = rs.getString("SUBSCRIBER_OID");
			String subscriberName = rs.getString("SUBSCRIBER_NAME");
			String bicCode = rs.getString("BIC");
			String guduns = rs.getString("GUDUNS");
			String lastBillDate = rs.getString("LAST_BILL_DATE");
			String accountLevelIndicator = rs.getString("ACCT_LVL_INDR");
			String languageCode = rs.getString("LANGUAGE_CODE");
			String currencyCode = rs.getString("CURRENCY_CODE");
			String otherContactInfo1 = rs.getString("OTH_CONTACT_INFO_1");
			String otherContactInfo2 = rs.getString("OTH_CONTACT_INFO_2");
			String exchangeRate = rs.getString("EXCHANGE_RATE");
			String paymentDueInterval = rs.getString("PAYMENT_DUE_INT");
			String smpContractId = rs.getString("SMP_CONTRACT_ID");
			String smpContractOid = (String) rs.getBigDecimal("SB_CONTRACT_OID").toString();
			String defaultRemitOid = rs.getString("DFLT_REMIT_OID");
			String naspId = rs.getString("NASP");
			String naspName = rs.getString("NASP_NAME");
			String revLoc = rs.getString("REVLOC_ID");
            String fixedRateInd = rs.getString("FIXED_RATE"); 

			//Pretty print the DB Values - GBR - as per Paul request.
			List valuesList = new ArrayList();
			valuesList.add("CONFIG_SUBS_OID=" + configSubscriptionOid);
			valuesList.add("CONFIG_ID=" + configId);
			valuesList.add("SERVICE_TYPE=" + serviceType);
			valuesList.add("START_DATE=" + startDate);
			valuesList.add("END_DATE=" + endDate);
			valuesList.add("BP_DAY=" + bpDay);
			valuesList.add("DATE_CREATED=" + dateCreated);
			valuesList.add("COMPANY_NAME=" + companyName);
			valuesList.add("CONFIG_NAME=" + configName);
			valuesList.add("EXT_UPDT_USR_NAME=" + userName);
			valuesList.add("EXT_UPDT_USR_ID=" + userId);
			valuesList.add("UPDATE_TIMESTAMP=" + rs.getString("UPDATE_TIMESTAMP"));
			valuesList.add("PROFILE_COMPLETE=" + profileComplete);
			valuesList.add("PROF_STATUS=" + profileStatus);
			valuesList.add("PROF_STATUS_COMM=" + profileStatusComment);
			valuesList.add("PROFILE_COMMENT=" + comment);
			valuesList.add("SUBSCRIBER_OID=" + subscriberOid);
			valuesList.add("SUBSCRIBER_NAME=" + subscriberName);
			valuesList.add("BIC=" + bicCode);
			valuesList.add("GUDUNS=" + guduns);
			valuesList.add("LAST_BILL_DATE=" + lastBillDate);
			valuesList.add("ACCT_LVL_INDR=" + accountLevelIndicator);
			valuesList.add("LANGUAGE_CODE=" + languageCode);
			valuesList.add("CURRENCY_CODE=" + currencyCode);
			valuesList.add("OTH_CONTACT_INFO_1="+otherContactInfo1);
			valuesList.add("OTH_CONTACT_INFO_2="+otherContactInfo2);
			valuesList.add("EXCHANGE_RATE="+exchangeRate);
			valuesList.add("PAYMENT_DUE_INT="+paymentDueInterval);
			valuesList.add("SMP_CONTRACT_ID="+smpContractId);
			valuesList.add("SB_CONTRACT_OID=" + smpContractOid);
			valuesList.add("DFLT_REMIT_OID=" + defaultRemitOid);
			valuesList.add("NASP=" + naspId);
			valuesList.add("NASP_NAME=" + naspName);
			valuesList.add("REVLOC=" + revLoc);
			valuesList.add("FIXED_RATE=" + fixedRateInd); 
			CommonUtil.prettyPrintValues(valuesList);

			profile.setConfigSubscriptionOid(Double.parseDouble(configSubscriptionOid));

			if (CommonUtil.isNotNull(configId)) {
				profile.setConfigID(configId.trim());
			}
			if (CommonUtil.isNotNull(serviceType)) {
				profile.setServiceType(serviceType.trim());
			}

			profile.setStartDate(CommonUtil.getDateFromString(startDate));
			profile.setEndDate(CommonUtil.getDateFromString(endDate));

			if (CommonUtil.isNotNull(bpDay)) {
				profile.setBillPeriod(bpDay.trim());
			}

			profile.setDtCreated(CommonUtil.getDateFromString(dateCreated));

			if (CommonUtil.isNotNull(companyName)) {
				profile.setCustCpnyName(companyName.trim());
			}
			if (CommonUtil.isNotNull(configName)) {
				profile.setConfigName(configName.trim());
			}
			if (CommonUtil.isNotNull(userName)) {
				profile.setUserName(userName.trim());
			}
			if (CommonUtil.isNotNull(userId)) {
				profile.setUserId(userId.trim());
			}

			profile.setModDtTime(rs.getTimestamp("UPDATE_TIMESTAMP"));

			if (CommonUtil.isNotNull(profileComplete)) {
				profile.setProfComplete(profileComplete.trim());
			}
			if (CommonUtil.isNotNull(profileStatus)) {
				profile.setProfileStatus(profileStatus.trim());
			}
			if (CommonUtil.isNotNull(profileStatusComment)) {
				profile.setProfStatusComnts(profileStatusComment.trim());
			}
			if (CommonUtil.isNotNull(comment)) {
				profile.setComments(comment.trim());
			}
			if (CommonUtil.isNotNull(subscriberOid)) {
				profile.setSubscriberOid(subscriberOid.trim());
			}
			if (CommonUtil.isNotNull(subscriberName)) {
				profile.setSubscriberName(subscriberName.trim());
			}
			if (CommonUtil.isNotNull(bicCode)) {
				profile.setBusinessIdentifierCode(bicCode.trim());
			}
			if (CommonUtil.isNotNull(guduns)) {
				profile.setGuduns(guduns.trim());
			}
			if (CommonUtil.isNotNull(lastBillDate)) {
				profile.setLastConfigBillDate(lastBillDate.trim());
			}
			if (CommonUtil.isNotNull(accountLevelIndicator)) {
				profile.setAccountLevelIndicator(accountLevelIndicator.trim());
			}
			if (CommonUtil.isNotNull(languageCode)) {
				profile.setLanguageCode(languageCode.trim());
			}
			if (CommonUtil.isNotNull(currencyCode)) {
				profile.setCurrencyCode(currencyCode.trim());
			}
			if (CommonUtil.isNotNull(otherContactInfo1)) {
				profile.setOtherContactInfo1(otherContactInfo1.trim());
			}
			if (CommonUtil.isNotNull(otherContactInfo2)) {
				profile.setOtherContactInfo2(otherContactInfo2.trim());
			}
			if (CommonUtil.isNotNull(exchangeRate)) {
				profile.setExchangeRate(exchangeRate.trim());
			}
			if (CommonUtil.isNotNull(paymentDueInterval)) {
				profile.setPaymentDueInterval(Integer.parseInt(paymentDueInterval.trim()));
			}
			if (CommonUtil.isNotNull(smpContractId)) {
				if (smpContractId.trim().length()== 0) {
					profile.setSmpContractId("N/A");
				} else {
					profile.setSmpContractId(smpContractId.trim());
				}				
			} else {
				profile.setSmpContractId("N/A");
			}
			
			if (CommonUtil.isNotNull(smpContractOid)) {
				profile.setSmpContractOid(smpContractOid.trim());
			}
			if (CommonUtil.isNotNull(defaultRemitOid)) {
				profile.setDefaultRemitOid(defaultRemitOid.trim());
			}
			if (CommonUtil.isNotNull(naspId)) {
				profile.setNaspId(naspId.trim());
			}
			if (CommonUtil.isNotNull(naspName)) {
				profile.setNaspName(naspName.trim());
			}
			if (CommonUtil.isNotNull(revLoc)) {
				profile.setRevLoc(revLoc.trim());
			}
			if (CommonUtil.isNotNull(fixedRateInd)) {
				profile.setFixedRateInd(fixedRateInd.trim());
			}
		}
		catch (NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.info(METHOD_NAME + " Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
		}

		logger.debug(METHOD_NAME + " profile=" + profile);
		logger.debug(METHOD_NAME + " EXIT");

		return profile;
	}
}
