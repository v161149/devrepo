package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetVgwSubAccountBillListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetVgwSubAccountBillListMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetAdjustmentsMapper - Mapping Row# "+rowNum);
		HiSelectDO hiDO = null;
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";

		if(rs!=null){
			hiDO = new HiSelectDO();
			
			hiDO.setBan(rs.getString("BAN"));			hiDO.setBillPayer(hiDO.getBan());						hiDO.setBillDate(rs.getString(2));			hiDO.setInvDate(CommonUtil.formatDate(hiDO.getBillDate(), formatDb2, formatDisplayed));						hiDO.setAban(rs.getString("ABAN"));			hiDO.setInvNbr(hiDO.getAban());						hiDO.setSections(rs.getString("SECTIONS"));						hiDO.setStartSection("0");						hiDO.setDocType("Invoice");						hiDO.setAcctLevel(hiDO.SUB);
		}
		return hiDO;
	}
	
	//Trimmer to remove spaces that VAC sends
	private String trimSpace(String input){
		return input!=null?input.trim():input;
	}
}
