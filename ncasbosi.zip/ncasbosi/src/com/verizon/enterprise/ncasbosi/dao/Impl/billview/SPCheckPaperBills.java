package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import javax.sql.DataSource;

import com.verizon.enterprise.dataobjects.Structure;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPCheckPaperBills extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPBillView.class);
	private static List spInOutList;

	public SPCheckPaperBills(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_CHECK_PAPER_BILLS, spInOutList);
	}

	static	{
		 spInOutList = new ArrayList();

		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"STRUCTURE_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STRUCTURE_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
         spInOutList.add(new Object[]{"HAS_PAPER_BILLS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
         spInOutList.add(new Object[]{"HAS_OMR_REPORTS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	protected Map<String, Object> executeStoredProcedure(String userId, String debugLevel, Map inputMap) throws Exception {
		_LOGGER.info("Inside SPCheckPaperBills.executeStoredProcedure() with input params: inputMap - " + inputMap);
		Map<String, Object> responseMap = new HashMap<String, Object>();
		List paramValueList = new ArrayList();
		
		paramValueList.add(userId);     //APP_USER_ID
		paramValueList.add(debugLevel); //DEBUG_LEVEL

		Structure struct = (Structure)inputMap.get("STRUCTURE");
		paramValueList.add(struct.getStructureValue());   //STRUCTURE_OID
		paramValueList.add(struct.getStructureType());    //STRUCTURE_TYPE

		return executeStoredProcedure(paramValueList);
	}
	
	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}}
