package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.reports.RptRecur;

public class GetRptRecurCntlSetRowMapper extends GetRptRecurDetResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetRptRecurDetResultSetRowMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetRptRecurCntlSetRowMapper::mapRow rowNum - " + rowNum);

		RptRecur rptRecurItem = (RptRecur)super.mapRow(rs, rowNum);
		rptRecurItem.setPageId(rs.getInt("PAGE_ID"));
		
		return rptRecurItem;
	}
}
