package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;


import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.handler.HandlerRegistry;

import org.apache.axis.AxisFault;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaAFTConstants;
import com.verizon.enterprise.common.eMedia.EMediaKeyProfile;
import com.verizon.enterprise.common.eMedia.EMediaManageContact;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecreateRequest;
import com.verizon.enterprise.common.eMedia.EMediaSrvcProviderInfo;
import com.verizon.enterprise.common.eMedia.EMediaBMAddress;
import com.verizon.enterprise.common.eMedia.GBREMediaProfile;
import com.verizon.enterprise.common.eMedia.SecabsCandidateApiInput;
import com.verizon.enterprise.common.ncas.gbr.GbrOrgPair;
import com.verizon.enterprise.common.ncas.gbr.GetGbrComponentDO;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.kernel.config.Config;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.SPErrorInfo;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaProfileInterface;
import com.verizon.enterprise.ncasbosi.dao.Impl.emedia.SPGenerateConfigID;
import com.verizon.enterprise.ncasbosi.dao.Impl.emedia.SPGetEMediaProfile;
import com.verizon.enterprise.ncasbosi.webservice.BillingHandlerInfo;
import com.verizon.enterprise.ncasbosi.webservice.BillingSOAPHandler;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.AddressValidationAPI;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.AddressValidationAPIServiceLocator;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.AddressValidationAPISoapBindingStub;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.Country;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.OutputOption;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.PostalAddress;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.RequestHeader;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.UnparsedAddress;
import com.verizon.enterprise.common.ncasbosi.webservice.onestop.ValidationResponse;
import com.verizon.enterprise.dataobjects.Structure;
import com.verizon.enterprise.common.ncasbosi.webservice.nasplookup.*;
import com.verizon.enterprise.common.ncasbosi.webservice.revloccdlookup.*;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.webservice.VBE.BillingVbeHandlerInfo;
import com.verizon.enterprise.ncasbosi.webservice.VBE.BillingVbeSOAPHandler;

import com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.SPValidateNASPID;
import com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.SPValidateRevLoc;

public class EMediaProfileDAOImpl  extends NCASSpringJDBCBase implements EMediaProfileInterface , NCASBOSIConstants {

	private static final String USER_ID_CONFIG_PATH = "verizon.ebosi.bill.vam.userid";
	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
	private static final String USER_ID_CONFIG_READ_ERROR = "Errors in reading config : "
														+ USER_ID_CONFIG_PATH;

	static private final Logger _LOGGER = Logger.getLogger(EMediaProfileDAOImpl.class);

	public EMediaKeyProfile generateConfigID(EMediaProfile profile) throws NCASException {
		String schemaName = getSchemaName();
		SPGenerateConfigID generateConfigID = new SPGenerateConfigID(getVAMDataSource(),schemaName);
		EMediaKeyProfile responseKeyProfile = null;

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "generateConfigID";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = generateConfigID.executeStoredProcedure(userID,debugLevel,profile);
			_LOGGER.info("Generate Config ID responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "generateConfigID";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GENERATE_CONFIG_ID;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}
			String configSubscriptionOid = (String)((BigDecimal)responseMap.get(CONFIG_SUBS_OID)).toString();
			_LOGGER.info("Newly generated config ID is.. " + configSubscriptionOid);

			responseKeyProfile = new EMediaKeyProfile();
			responseKeyProfile.setConfigSubscriptionOid(Double.parseDouble(configSubscriptionOid));

		} catch(NCASException ncasException ) {
			_LOGGER.debug("GenerateConfigID in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GenerateConfigID in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GenerateConfigID in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GenerateConfigID in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}

		return responseKeyProfile;
	}

	public EMediaKeyProfile generateGbrConfigID(GBREMediaProfile profile) throws NCASException {
		String schemaName = getSchemaName();
		SPGenerateGbrConfigID generateGbrConfigID = new SPGenerateGbrConfigID(getVAMDataSource(),schemaName);
		EMediaKeyProfile responseKeyProfile = null;

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "generateGbrConfigID";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = generateGbrConfigID.executeStoredProcedure(userID,debugLevel,profile);
			_LOGGER.info("Generate GBR Config ID responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();

			responseKeyProfile = new EMediaKeyProfile();
			responseKeyProfile.setSpResponseMap(responseMap);  //return entire map so can use values to call ecp to entilt user to see the gbr they just created if vec.

			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
			/*	SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "generateGbrConfigID";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GENERATE_GBR_CONFIG_ID;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode); */

				responseKeyProfile.setRetCode(returnCode);
				responseKeyProfile.setReasonCode((String) responseMap.get("REASON_CODE"));
				responseKeyProfile.setErrorText((String) responseMap.get("ERROR_TEXT"));


			}else{
			String configSubscriptionOid = (String)((BigDecimal)responseMap.get(CONFIG_SUBS_OID)).toString();
			_LOGGER.info("Newly generated config ID is.. " + configSubscriptionOid);
			responseKeyProfile.setConfigSubscriptionOid(Double.parseDouble(configSubscriptionOid));
			}
		} catch(NCASException ncasException ) {
			_LOGGER.debug("generateGbrConfigID in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("generateGbrConfigID in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("generateGbrConfigID in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("generateGbrConfigID in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}

		return responseKeyProfile;
	}


	public List getEMediaContact(EMediaKeyProfile keyProfile, String contactType) throws NCASException {

		List contactList = new ArrayList();
		String schemaName = getSchemaName();
		SPGetEMediaContact getEMediaContactStoredProc = new SPGetEMediaContact(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaContact";
				errMsg[1] = keyProfile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getEMediaContactStoredProc.executeStoredProcedure(userID,debugLevel,contactType,keyProfile);
			_LOGGER.info("Get EMedia Contact responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaContact";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_CONTACT;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			contactList = (List) responseMap.get("eMediaContact");
			_LOGGER.info("Get EMedia Contact contactList -> " + contactList);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("Get EMedia Contact in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("Get EMedia Contact in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("Get EMedia Contact in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("Get EMedia Contact in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return contactList;
	}

	public List getEMediaProfile(EMediaProfile profile) throws NCASException {
		List profilesList = new ArrayList();
		String schemaName = getSchemaName();
		SPGetEMediaProfile getEMediaProfileStoredProc = new SPGetEMediaProfile(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaProfile";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getEMediaProfileStoredProc.executeStoredProcedure(userID,debugLevel,String.valueOf(profile.getProfileKey().getConfigSubscriptionOid()));
			_LOGGER.info("Get EMedia Profile responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaProfile";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_PROFILE;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			profilesList = (List) responseMap.get("profiles");
			_LOGGER.info("Get EMedia Profile profilesList -> " + profilesList);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("Get EMedia Profile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("Get EMedia Profile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("Get EMedia Profile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("Get EMedia Profile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return profilesList;
	}

	public String manageEMediaProfile(EMediaProfile profile, String action) throws NCASException {
		String status = "SUCCESS";
		String schemaName = getSchemaName();
		SPManageEMediaProfile manageEMediaProfileStoredProc = new SPManageEMediaProfile(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				status = "FAILED";
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageEMediaProfile";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = manageEMediaProfileStoredProc.executeStoredProcedure(userID,debugLevel,profile,action);
			_LOGGER.info("Manage EMedia Profile responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "manageEMediaProfile";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_EM_PROFILE;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			EMediaProfile emediaProfile = new EMediaProfile();

			//keyProfile.setConfigSubscriptionOid(Double.parseDouble(responseMap.get("CONFIG_SUBS_OID").toString()));
			_LOGGER.info("Manage EMedia Profile emediaProfile -> " + emediaProfile);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("Manage EMedia Profile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("Manage EMedia Profile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			status = "Failed";
			_LOGGER.debug("Manage EMedia Profile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("Manage EMedia Profile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return status;
	}

	public String manageEMediaBMAddress(EMediaBMAddress emediaBMAddr, String action) throws NCASException {
		String status = "SUCCESS";
		String schemaName = getSchemaName();
		SPManageEMediaBMAddress manageEMediaBMAddressStoredProc = new SPManageEMediaBMAddress(getVAMDataSource(),schemaName);
		try
		{
			_LOGGER.info("ManageEMediaBMAddress input:\n" + emediaBMAddr);
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				status = "FAILED";
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageEMediaBMAddress";
				errMsg[1] = emediaBMAddr.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			Map responseMap = manageEMediaBMAddressStoredProc.executeStoredProcedure(userID,emediaBMAddr.getLastUpdatedUserId(),
					emediaBMAddr.getLastUpdatedUserName(), debugLevel,emediaBMAddr.getConfigSubsOid(), action, emediaBMAddr.getAddrSequence(),
					emediaBMAddr.getAddTypeInd(), emediaBMAddr.getAddress1(), emediaBMAddr.getAddress2(), emediaBMAddr.getAddress3(), emediaBMAddr.getCity(),
					emediaBMAddr.getState(), emediaBMAddr.getZip(), emediaBMAddr.getPostalCode(), emediaBMAddr.getCountry(), emediaBMAddr.getCdCopies());
			_LOGGER.info("ManageEMediaBMAddress responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				status = "FAILED";
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "manageEMediaBMAddress";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_EM_ADDRESS;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException ) {
			_LOGGER.debug("ManageEMediaBMAddress in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("ManageEMediaBMAddress in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("ManageEMediaBMAddress in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("ManageEMediaBMAddress in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return status;
	}

	public List getEMediaBMAddress(String configSubscriptionOid) throws NCASException {
		List profilesList = new ArrayList();
		String schemaName = getSchemaName();
		SPGetEMediaBMAddress getEMediaBMAddressStoredProc = new SPGetEMediaBMAddress(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaBMAddress";
				errMsg[1] = configSubscriptionOid;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getEMediaBMAddressStoredProc.executeStoredProcedure(userID,debugLevel,configSubscriptionOid);
			_LOGGER.info("GetEMediaBMAddress responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaBMAddress";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_ADDRESS;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			profilesList = (List) responseMap.get("addrList");
			_LOGGER.info("GetEMediaBMAddress addrList -> " + profilesList);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("GetEMediaBMAddress in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaBMAddress in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaBMAddress in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaBMAddress in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return profilesList;
	}

	public Map searchEMediaProfile(EMediaProfile profile, String whereClause, String sortOrder, Pagination pagination) throws NCASException {
		String schemaName = getSchemaName();
		SPSearchEMediaProfile searchEMediaProfileStoredProc = new SPSearchEMediaProfile(getVAMDataSource(),schemaName);
		Map responseMap = new HashMap();
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "searchEMediaProfile";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			responseMap = searchEMediaProfileStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder, profile, pagination);
			_LOGGER.info("SearchEMediaProfile responseMap -> " + responseMap);

			Map recordsMap = (Map) responseMap.get("recordsMap");
			int returnCode = ((Integer)recordsMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) recordsMap.get("REASON_CODE"));
				spInfo.setErrorText((String) recordsMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) recordsMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) recordsMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)recordsMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "searchEMediaProfile";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_SEARCH_EM_PROFILE;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException ) {
			_LOGGER.debug("SearchEMediaProfile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("SearchEMediaProfile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("SearchEMediaProfile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SearchEMediaProfile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return responseMap;
	}

	public String manageEMediaContact(EMediaManageContact contact) throws NCASException {
		//SPManageEMediaContact
		String status = "FAILED";
		String schemaName = getSchemaName();
		SPManageEMediaContact manageEMediaContactStoredProc = new SPManageEMediaContact(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageEMediaContact";
				errMsg[1] = contact.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = manageEMediaContactStoredProc.executeStoredProcedure(userID,debugLevel,contact);
			_LOGGER.info("ManageEMediaContact responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "manageEMediaContact";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_EM_CONTACT;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			status = "SUCCESS";

		} catch(NCASException ncasException ) {
			_LOGGER.debug("ManageEMediaContact in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("ManageEMediaContact in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("ManageEMediaContact in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("ManageEMediaContact in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return status;
	}

	public List getEMediaServiceProvider(int serviceProviderNumber) throws NCASException {
		List serviceProviderList = new ArrayList();
		String schemaName = getSchemaName();
		SPGetEMediaServiceProvider getEMediaServiceProviderStoredProc = new SPGetEMediaServiceProvider(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaServiceProvider";
				errMsg[1] = String.valueOf(serviceProviderNumber);
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getEMediaServiceProviderStoredProc.executeStoredProcedure(userID,debugLevel,serviceProviderNumber);
			_LOGGER.info("GetEMediaServiceProvider responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaServiceProvider";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_SVC_PROV;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			serviceProviderList = (List)responseMap.get("serviceProvider");

			_LOGGER.info("GetEMediaServiceProvider serviceProviderList -> " + serviceProviderList);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("GetEMediaServiceProvider in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaServiceProvider in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaServiceProvider in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaServiceProvider in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return serviceProviderList;
	}

	public Map getEMediaDropDown(String dropDownField) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetEMediaDropDown getEMediaDropDownStoredProc = new SPGetEMediaDropDown(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaDropDown";
				errMsg[1] = dropDownField;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getEMediaDropDownStoredProc.executeStoredProcedure(userID,debugLevel,dropDownField);
			_LOGGER.info("GetEMediaDropDown responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaDropDown";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_DROPDOWN;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			retMap = (HashMap)responseMap.get("dropDownData");

			_LOGGER.info("GetEMediaDropDown retMap -> " + retMap);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("GetEMediaDropDown in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaDropDown in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaDropDown in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaDropDown in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	public List getEMediaHistory(String configSubscriptionOid, String noteType) throws NCASException {
		List historyList = new ArrayList();
		String schemaName = getSchemaName();
		SPGetEMediaHistory getEMediaHistoryStoredProc = new SPGetEMediaHistory(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaHistory";
				errMsg[1] = String.valueOf(configSubscriptionOid) + ":" + noteType;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getEMediaHistoryStoredProc.executeStoredProcedure(userID,debugLevel,configSubscriptionOid,noteType);
			_LOGGER.info("GetEMediaHistory responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaHistory";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_HISTORY;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			historyList = (List)responseMap.get("history");

			_LOGGER.info("GetEMediaHistory historyList -> " + historyList);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("GetEMediaHistory in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaHistory in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaHistory in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaHistory in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return historyList;
	}

	public Map getEMediaAccounts(String configSubscriptionOid, String whereFilter,
									String sortOrder, Pagination pagination) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetEMediaAccounts getEMediaAccountsStoredProc = new SPGetEMediaAccounts(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaAccounts";
				errMsg[1] = configSubscriptionOid;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getEMediaAccountsStoredProc.executeStoredProcedure(userID,debugLevel,configSubscriptionOid,whereFilter,sortOrder,pagination);
			_LOGGER.info("GetEMediaAccounts responseMap -> " + retMap);

			int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaAccounts";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_ACCTS;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException) {
			_LOGGER.debug("GetEMediaAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	// Method: getGbrSummaryAccounts
	// Usage : to get a list of accounts based for a profile.
	// VAM API : GET_GBR_ACCTS
	public Map getGBREMediaAccounts(GetGbrComponentDO inputDO)
			throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetGBREMediaAccounts getGbrEMediaAccountsStoredProc = new SPGetGBREMediaAccounts(
				getVAMDataSource(), schemaName);
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaAccounts";
				errMsg[1] = inputDO.getConfigSubsOid();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getGbrEMediaAccountsStoredProc.executeStoredProcedure(userID,
					debugLevel, inputDO);
			_LOGGER.info("GetGBREMediaAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGBREMediaAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_GBR_ACCTS;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("GetGBREMediaAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("GetGBREMediaAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("GetGBREMediaAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("GetGBREMediaAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	// Method: getVbeSummaryAccounts
	// Usage : to get a list of accounts based for a profile.
	// VAM API : GET_VBE_ACCTS
	public Map getVBEEMediaAccounts(Map input)
			throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetVBEEMediaAccounts getVbeEMediaAccountsStoredProc = new SPGetVBEEMediaAccounts(
				getVAMDataSource(), schemaName);
		try {
				retMap = getVbeEMediaAccountsStoredProc.executeStoredProcedure((Object)input);
				_LOGGER.info("getVBEEMediaAccounts responseMap -> " + retMap);

			}

		 catch (Exception vamEx) {
			_LOGGER.debug("getVBEEMediaAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getVBEEMediaAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	public Map searchBMDDConfig(EMediaProfile profile, String sortOrder,
								Pagination pagination) throws  NCASException {
		String schemaName = getSchemaName();
		SPSearchBMDDConfig searchBMDDConfigStoredProc = new SPSearchBMDDConfig(getVAMDataSource(),schemaName);
		Map responseMap = new HashMap();
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "searchBMDDConfig";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			responseMap = searchBMDDConfigStoredProc.executeStoredProcedure(userID,debugLevel,profile,
											sortOrder, pagination);
			_LOGGER.info("SearchBMDDConfig responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "searchBMDDConfig";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_SEARCH_BM_DD_CFGS;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			//configList = (List)responseMap.get("config");
			//_LOGGER.info("SearchBMDDConfig configList -> " + configList);
		} catch(NCASException ncasException) {
			_LOGGER.debug("SearchBMDDConfig in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("SearchBMDDConfig in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("SearchBMDDConfig in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SearchBMDDConfig in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return responseMap;
	}

	public String manageEMediaAccounts(String userId, String userName, String action,
				String configSubscriptionOid, String ediDataGrp, ArrayList accountList) throws  NCASException {
		_LOGGER.debug("Entering EMediaProfileDAOImpl.manageEMediaAccounts with params :: userId - " + userId +
						", userName - " + userName + ", action - " + action + ", configSubOid - " + configSubscriptionOid +
						", ediDataGrp - " + ediDataGrp + ", accountList - " + accountList);
		String schemaName = getSchemaName();
		String status = "FAILED";
		SPManageEMediaAccounts manageEMediaAcctsStoredProc = new SPManageEMediaAccounts(getVAMDataSource(),schemaName);
		try
		{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (appUserID == null) {
			    	appUserID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageEMediaAccounts";
				errMsg[1] = String.valueOf(configSubscriptionOid) + " :: " + accountList;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String strAccountsList = convertArrayListToString(accountList);
			_LOGGER.info("strAccountsList -> " + strAccountsList);

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			_LOGGER.info("debugLevel -> " + debugLevel);

			Map responseMap = manageEMediaAcctsStoredProc.executeStoredProcedure(appUserID, userId, userName, debugLevel,
													action, configSubscriptionOid, ediDataGrp, strAccountsList);
			_LOGGER.info("manageEMediaAccounts responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "manageEMediaAccounts";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_EM_ACCTS;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			status = "SUCCESS";

		} catch(NCASException ncasException) {
			_LOGGER.debug("manageEMediaAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("manageEMediaAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("manageEMediaAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("manageEMediaAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		_LOGGER.info("manageEMediaAccounts status -> " + status);
		return status;
	}

	// Method: manageGbrAccounts
	// Usage : Add Remove GBE Accounts to/from profile.
	// VAM API : MANAGE_GBR
	public String manageGbrAccounts(Map input) throws  NCASException {

	//_LOGGER.debug("Entering EMediaProfileDAOImpl.manageGbrAccounts with params :: userId - " + userId +
	//				", userName - " + userName + ", action - " + action + ", configSubOid - " + configSubscriptionOid +
	//				", ediDataGrp - " + ediDataGrp + ", accountList - " + accountList);
	String schemaName = getSchemaName();
	String status = "FAILED";
	SPManageGbrAccounts manageGbrAcctsStoredProc = new SPManageGbrAccounts(getVAMDataSource(),schemaName);
	try
	{
		String appUserID = null;
		try {
			appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		    if (appUserID == null) {
		    	appUserID = "USSLBMG";
		    }
		} catch(Exception e) {
			_LOGGER.debug("APP USER ID is null..");
			String[] errMsg = new String[3];
			errMsg[0] = "manageGbrAccounts";
			errMsg[1] = String.valueOf(input.get("configSubscriptionOid"));
			errMsg[2] = USER_ID_CONFIG_READ_ERROR;
			throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}

		String strAccountsList = convertArrayListToString((ArrayList)input.get("accountList"));
		_LOGGER.info("strAccountsList -> " + strAccountsList);

		input.put("strAccountList", strAccountsList);

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		_LOGGER.info("debugLevel -> " + debugLevel);

		Map responseMap = manageGbrAcctsStoredProc.executeStoredProcedure(appUserID, debugLevel, input);
		_LOGGER.info("manageGbrAccounts responseMap -> " + responseMap);

		int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
		if( returnCode > 0 ) {
			 //Excuting SP doesn't return correct result
			SPErrorInfo spInfo = new SPErrorInfo();
			spInfo.setReturnCode(returnCode);//RETURN_CODE
			spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
			spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
			spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
			spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
			spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

		    String[] errMsg = new String[3];
		    errMsg[0] = "manageGbrAccounts";
		    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_ACCTS;
		    errMsg[2] = spInfo.toString();

		    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
		}

		status = "SUCCESS";

	} catch(NCASException ncasException) {
		_LOGGER.debug("manageGbrAccounts in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("manageGbrAccounts in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
	} catch(Exception vamEx) {
		_LOGGER.debug("manageGbrAccounts in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("manageGbrAccounts in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
	}
	_LOGGER.info("manageGbrAccounts status -> " + status);
	return status;
}


	public int putEMediaRecreateRequests(EMediaRecreateRequest request) throws  NCASException {
		_LOGGER.debug("Entering EMediaProfileDAOImpl.putEMediaRecreateRequests with params :: request - " + request);
		String schemaName = getSchemaName();
		int requestNumber = 0;
		SPPutEMediaRecreateRequest putEMediaRecreateRequestStoredProc = new SPPutEMediaRecreateRequest(getVAMDataSource(),schemaName);
		try
		{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (appUserID == null) {
			    	appUserID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "putEMediaRecreateRequests";
				errMsg[1] = request.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = putEMediaRecreateRequestStoredProc.executeStoredProcedure(appUserID,debugLevel,request);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "putEMediaRecreateRequests";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_PUT_EM_RECREATE_RQST;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			Integer numberInteger = (Integer)responseMap.get("REQUEST_NUMBER");
			requestNumber = numberInteger.intValue();
			_LOGGER.info("putEMediaRecreateRequests requestNumber -> " + requestNumber);

		} catch(NCASException ncasException) {
			_LOGGER.debug("putEMediaRecreateRequests in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("putEMediaRecreateRequests in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("putEMediaRecreateRequests in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("putEMediaRecreateRequests in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return requestNumber;
	}

	public Map getEMediaRecreateRequests(String whereFilter, String sortOrder,
											Pagination pagination) throws  NCASException {
		_LOGGER.debug("Entering EMediaProfileDAOImpl.getEMediaRecreateRequests with params :: whereFilter - " +
							whereFilter + ", sortOrder - " + sortOrder );
		String schemaName = getSchemaName();
		Map responseMap = new HashMap();
		SPGetEMediaRecreateRequest getEMediaRecreateRequestStoredProc = new SPGetEMediaRecreateRequest(getVAMDataSource(),schemaName);
		try
		{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (appUserID == null) {
			    	appUserID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaRecreateRequests";
				errMsg[1] = "whereFilter - " + whereFilter + " , sortOrder - " + sortOrder;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			responseMap = getEMediaRecreateRequestStoredProc.executeStoredProcedure(appUserID,debugLevel,whereFilter,sortOrder,pagination);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaRecreateRequests";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_RECREATE_RQST;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException) {
			_LOGGER.debug("getEMediaRecreateRequests in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("getEMediaRecreateRequests in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("getEMediaRecreateRequests in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getEMediaRecreateRequests in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return responseMap;
	}



	public Map getEMediaSummary( String customerNo, String customerType,
									String filterBy, String sortBy,
									String cursorId, Pagination pagination) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetEMediaSummary getEMediaSummaryStoredProc = new SPGetEMediaSummary(getVAMDataSource(),schemaName);

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaSummary";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getEMediaSummaryStoredProc.executeStoredProcedure(userID,debugLevel, customerNo,customerType, filterBy,sortBy, cursorId,pagination);
			_LOGGER.info("getEMediaSummary responseMap -> " + retMap);

			int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaSummary";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_SUMMARY;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException) {
			_LOGGER.debug("GetEMediaSummary in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaSummary in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaSummary in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaSummary in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	public Map getEMediaCorpSummary( String customerNo, String customerType,
									String filterBy, String sortOrder,
									String cursorId, Pagination pagination) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();

		SPGetEMediaCorpSummary getEMediaCorpSummaryStoredProc = new SPGetEMediaCorpSummary(getVAMDataSource(),schemaName);

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaCorpSummary";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getEMediaCorpSummaryStoredProc.executeStoredProcedure(userID,debugLevel, customerNo,customerType, filterBy,sortOrder, cursorId,pagination);
			_LOGGER.info("getEMediaCorpSummary responseMap -> " + retMap);

			int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getEMediaCorpSummary";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_CORP_SUMMARY;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException) {
			_LOGGER.debug("GetEMediaCorpSummary in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaCorpSummary in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaCorpSummary in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaCorpSummary in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	// Method: getGbrSummaryAccounts
	// Usage : to get a list of accounts based on customer name search criteria.
	// VAM API : SUMMARY_GBR_V10(Bill Payer tab)
	public Map getGbrSummaryAccounts(String customerNo, String customerType,
			String filterBy, String sortBy, String cursorId,
			Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetGbrSummaryAccounts getGbrSummaryAccountsStoredProc = new SPGetGbrSummaryAccounts(
				getVAMDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGbrSummaryAccounts";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getGbrSummaryAccountsStoredProc.executeStoredProcedure(userID,
					debugLevel, customerNo, customerType, filterBy, sortBy,
					cursorId, pagination,configSubsOid);
			_LOGGER.info("getGbrSummaryAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGbrSummaryAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_GBR_SUMMARY;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("getGbrSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getGbrSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getGbrSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getGbrSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	// Method: getVbeSummaryAccounts
	// Usage : to get a list of accounts based on customer name search criteria.
	// VAM API : SUMMARY_VBE_V11(Bill Payer tab)
	public Map getVbeSummaryAccounts(String customerNo, String customerType,
			String filterBy, String sortBy, String cursorId,
			Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetVbeSummaryAccounts getVbeSummaryAccountsStoredProc = new SPGetVbeSummaryAccounts(
				getVAMDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGbrSummaryAccounts";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getVbeSummaryAccountsStoredProc.executeStoredProcedure(userID,
					debugLevel, customerNo, customerType, filterBy, sortBy,
					cursorId, pagination,configSubsOid);
			_LOGGER.info("getVbeSummaryAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGbrSummaryAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_VBE_SUMMARY;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("getGbrSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getGbrSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getGbrSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getGbrSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	// Method: getGbrCorpSummaryAccounts
	// Usage : to get a list of accounts based on customer name search criteria.
	// VAM API : CORP_GBR_V10(Corp Tab)
	public Map getGbrCorpSummaryAccounts(String customerNo, String customerType,
			String filterBy, String sortOrder, String cursorId,
			Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();

		SPGetGbrCorpSummaryAccounts getGbrCorpSummaryAccountsStoredProc = new SPGetGbrCorpSummaryAccounts(
				getVAMDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGbrCorpSummaryAccounts";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getGbrCorpSummaryAccountsStoredProc.executeStoredProcedure(
					userID, debugLevel, customerNo, customerType, filterBy,
					sortOrder, cursorId, pagination, configSubsOid);
			_LOGGER.info("getGbrCorpSummaryAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGbrCorpSummaryAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_GBR_CORP_SUMMARY;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("getGbrCorpSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getGbrCorpSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getGbrCorpSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getGbrCorpSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	// Method: getVbeCorpSummaryAccounts
	// Usage : to get a list of accounts based on customer name search criteria.
	// VAM API : CORP_VBE_V11(Corp Tab)
	public Map getVbeCorpSummaryAccounts(String customerNo, String customerType,
			String filterBy, String sortOrder, String cursorId,
			Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();

		SPGetVbeCorpSummaryAccounts getVbeCorpSummaryAccountsStoredProc = new SPGetVbeCorpSummaryAccounts(
				getVAMDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getVbeCorpSummaryAccounts";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getVbeCorpSummaryAccountsStoredProc.executeStoredProcedure(
					userID, debugLevel, customerNo, customerType, filterBy,
					sortOrder, cursorId, pagination, configSubsOid);
			_LOGGER.info("getVbeCorpSummaryAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getVbeCorpSummaryAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_GBR_CORP_SUMMARY;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("getVbeCorpSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getVbeCorpSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getVbeCorpSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getVbeCorpSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	public Map getEmediaByAccountSearch(String serviceId, String wherePhrase, String sortOrder,
			String tokenString, Pagination pagination) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetEmediaByAccountSearch getEMediaAcctsBySearchStoredProc = new SPGetEmediaByAccountSearch(getVAMDataSource(),schemaName);

		try
		{
		String userID = null;
		try {
		userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (userID == null) {
		userID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "getEmediaByAccountSearch";
		errMsg[1] = serviceId;
		errMsg[2] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		retMap = getEMediaAcctsBySearchStoredProc.executeStoredProcedure(userID,debugLevel, serviceId, wherePhrase, sortOrder, tokenString, pagination);
		_LOGGER.info("getEmediaByAccountSearch responseMap -> " + retMap);

		int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
		if( returnCode > 0 ) {
		//Excuting SP doesn't return correct result
		SPErrorInfo spInfo = new SPErrorInfo();
		spInfo.setReturnCode(returnCode);//RETURN_CODE
		spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
		spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
		spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
		spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
		spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

		String[] errMsg = new String[3];
		errMsg[0] = "getEmediaByAccountSearch";
		errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_EM_ACCTS_BY_SEARCH;
		errMsg[2] = spInfo.toString();

		throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
		}

		} catch(NCASException ncasException) {
		_LOGGER.debug("GetEmediaByAccountSearch in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("GetEmediaByAccountSearch in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("GetEmediaByAccountSearch in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("GetEmediaByAccountSearch in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	// Method: getGbrAccountListBySubscription
	// Usage : to get a list of accounts based on account number search criteria.
	// VAM API : SERVICE_GBR_V10
	public Map getGbrAccountsBySubscription(String serviceId, String wherePhrase, String sortOrder,
			String tokenString, Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetGbrAccountsBySubscription getGbrAcctsBySubscriptionStoredProc = new SPGetGbrAccountsBySubscription(getVAMDataSource(),schemaName);

		try
		{
		String userID = null;
		try {
		userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (userID == null) {
		userID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "getGbrAccountsBySubscription";
		errMsg[1] = serviceId;
		errMsg[2] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		retMap = getGbrAcctsBySubscriptionStoredProc.executeStoredProcedure(userID,debugLevel, serviceId, wherePhrase, sortOrder, tokenString, pagination,configSubsOid);
		_LOGGER.info("getEmediaByAccountSearch responseMap -> " + retMap);

		int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
		if( returnCode > 0 ) {
		//Excuting SP doesn't return correct result
		SPErrorInfo spInfo = new SPErrorInfo();
		spInfo.setReturnCode(returnCode);//RETURN_CODE
		spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
		spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
		spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
		spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
		spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

		String[] errMsg = new String[3];
		errMsg[0] = "getGbrAccountsBySubscription";
		errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_GBR_ACCTS_BY_SUBSCRIPTION;
		errMsg[2] = spInfo.toString();

		throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
		}

		} catch(NCASException ncasException) {
		_LOGGER.debug("getGbrAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("getGbrAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("getGbrAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("getGbrAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	// Method: getVbeAccountListBySubscription
	// Usage : to get a list of accounts based on account number search criteria.
	// VAM API : SERVICE_VBE_V11
	public Map getVbeAccountsBySubscription(String serviceId, String wherePhrase, String sortOrder,
			String tokenString, Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetVbeAccountsBySubscription getVbeAcctsBySubscriptionStoredProc = new SPGetVbeAccountsBySubscription(getVAMDataSource(),schemaName);

		try
		{
		String userID = null;
		try {
		userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (userID == null) {
		userID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "getVbeAccountsBySubscription";
		errMsg[1] = serviceId;
		errMsg[2] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		retMap = getVbeAcctsBySubscriptionStoredProc.executeStoredProcedure(userID,debugLevel, serviceId, wherePhrase, sortOrder, tokenString, pagination,configSubsOid);
		_LOGGER.info("getVbeAccountsBySubscription responseMap -> " + retMap);

		int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
		if( returnCode > 0 ) {
		//Excuting SP doesn't return correct result
		SPErrorInfo spInfo = new SPErrorInfo();
		spInfo.setReturnCode(returnCode);//RETURN_CODE
		spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
		spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
		spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
		spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
		spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

		String[] errMsg = new String[3];
		errMsg[0] = "getVbeAccountsBySubscription";
		errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_VBE_ACCTS_BY_SUBSCRIPTION;
		errMsg[2] = spInfo.toString();

		throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
		}

		} catch(NCASException ncasException) {
		_LOGGER.debug("getVbeAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("getVbeAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("getVbeAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("getVbeAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	public Map getProfilesByOid( String customerNo, String customerType )
								throws NCASException {
		String mediaType = "   ";
		String cursorId = "";
		int startPosition = 1;
		int pageSize = 10000;

		String schemaName = getSchemaName();
		Map profilesMap = new HashMap();
		Map map = null;

		try
		{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (appUserID == null) {
			    	appUserID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getProfilesByOid";
				errMsg[1] = "customerNumber - " + customerNo + " , customerType - " + customerType;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			if(customerType!=null && customerType.equals("P")){
				SPGetProfilesBySubsOid getEMediaProfileStoredProc = new SPGetProfilesBySubsOid(getVAMDataSource(),schemaName);
				map = getEMediaProfileStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo);
				profilesMap = (Map) map.get("profiles");
			}
			else if(customerType!=null && customerType.equals("PFB")){
					SPGetPaperFreeAuthorization getPaperFreeAuthorization = new SPGetPaperFreeAuthorization(getVAMDataSource(),schemaName);
					map = getPaperFreeAuthorization.executeStoredProcedure(appUserID,debugLevel,customerNo);
					String paperAuthStatus = (String) map.get("PAPER_AUTH_STATUS");
					profilesMap.put("AUTH",paperAuthStatus);
			}else{
				SPGetProfilesByOid getProfilesByOidStoredProc = new SPGetProfilesByOid(getVAMDataSource(),schemaName);
				map = getProfilesByOidStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo,customerType,mediaType,cursorId,startPosition,pageSize);
				profilesMap = (Map) map.get("profiles");
			}


			int returnCode = ((Integer)map.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) map.get("REASON_CODE"));
				spInfo.setErrorText((String) map.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) map.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) map.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)map.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getProfilesByOid";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_ACCT_EMEDIA_LIST;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}
				_LOGGER.info("GetProfilesByOid profilesMap -> " + profilesMap);

		} catch(NCASException ncasException) {
			_LOGGER.debug("GetProfilesByOid in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetProfilesByOid in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetProfilesByOid in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetProfilesByOid in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return profilesMap;
	}

	public Content downloadsEMediaProfile ( Map params) throws NCASException {

	String schemaName = getSchemaName();
	SPDownloadEMediaProfile downloadEMediaProfileStoredProc = new SPDownloadEMediaProfile(getVAMDataSource(),schemaName);
	Content retObject = null;
	try
	{
		String userID = null;
		try {
			userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		    if (userID == null) {
		    	userID = "USSLBMG";
		    }
		} catch(Exception e) {
			_LOGGER.debug("USER ID is null..");
			String[] errMsg = new String[3];
			errMsg[0] = "downloadEMediaProfile";
			errMsg[1] = USER_ID_CONFIG_READ_ERROR;
			throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			if(whereClause==null) {
				whereClause = "1=1";
			} else if(whereClause.equals("")) {
				whereClause = "1=1";
			}
		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		retObject = downloadEMediaProfileStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder);


	} catch(NCASException ncasException ) {
		_LOGGER.debug("DownloadsEMediaProfile in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("DownloadsEMediaProfile in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
	} catch(Exception vamEx) {
		_LOGGER.debug("DownloadsEMediaProfile in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("DownloadsEMediaProfile in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
	}
	return retObject;
	}

	public Content downloadsEMediaRecreates ( Map params) throws NCASException {

		String schemaName = getSchemaName();
		SPDownloadEMediaRecreate downloadEMediaRecreateStoredProc = new SPDownloadEMediaRecreate(getVAMDataSource(),schemaName);
		Content retObject = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadEMediaProfile";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			if(params!=null){
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			retObject = downloadEMediaRecreateStoredProc.executeStoredProcedure(userID, "0", whereClause, sortOrder);


		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadsEMediaRecreates in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadsEMediaRecreates in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadsEMediaRecreates in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadsEMediaRecreates in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	public Content downloadAccountsSummary(Map params) throws NCASException {
		String schemaName = getSchemaName();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadAccountsSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}


		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String cursorId = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			cursorId = (String)params.get("CURSOR");
			if(whereClause==null) {
				whereClause = "";
			}
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		SPDownloadEMediaAccountsSummary downloadAccountsSummaryStoredProc = new SPDownloadEMediaAccountsSummary(getVAMDataSource(),schemaName);
		retObject = downloadAccountsSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo,whereClause,sortOrder,cursorId);

		} catch(NCASException ncasException) {
		_LOGGER.debug("GetEMediaDownloadAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("GetEMediaDownloadAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("GetEMediaDownloadAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("GetEMediaDownloadAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	// Method to get the Accounts by customer name in excel file for Bill Payer Tab
	public Content downloadGBRAccountsSummary(Map params) throws NCASException {
		String schemaName = getSchemaName();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadGBRAccountsSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}


		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String cursorId = "";
		String configSubsOid = "";
		String customerType= "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			customerType = (String)params.get("CUSTTYPE");
			if(whereClause==null) {
				whereClause = "";
			}
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		SPDownloadGBRAccountsSummary downloadGBRAccountsSummaryStoredProc = new SPDownloadGBRAccountsSummary(getVAMDataSource(),schemaName);
		retObject = downloadGBRAccountsSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause, sortOrder,
				cursorId, configSubsOid);

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadGBRAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadGBRAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadGBRAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadGBRAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	// Method to get the Accounts by customer name in excel file for Bill Payer Tab
	public Content downloadVBEAccountsSummary(Map params) throws NCASException {
		String schemaName = getSchemaName();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadVBEAccountsSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}


		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String cursorId = "";
		String configSubsOid = "";
		String customerType= "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			customerType = (String)params.get("CUSTTYPE");
			if(whereClause==null) {
				whereClause = "";
			}
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		SPDownloadVBEAccountsSummary downloadVBEAccountsSummaryStoredProc = new SPDownloadVBEAccountsSummary(getVAMDataSource(),schemaName);
		retObject = downloadVBEAccountsSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause, sortOrder,
				cursorId, configSubsOid);

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadVBEAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadVBEAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadVBEAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadVBEAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	//download in excel -> CORP_GBR_V10
	public Content downloadGBRCorpSummary ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadGBRCorpSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		String configSubsOid = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		if(customerType.equals("U")){
			SPDownloadGBRCorpSummary downloadGBRCorpSummaryStoredProc = new SPDownloadGBRCorpSummary(getVAMDataSource(),schemaName);
			retObject = downloadGBRCorpSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause,
					sortOrder, cursorId, configSubsOid);
		}else{
			SPDownloadGBRCorpSummary downloadGBRCorpSummaryStoredProc = new SPDownloadGBRCorpSummary(getVAMDataSource(),schemaName);
			retObject = downloadGBRCorpSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause,
					sortOrder, cursorId, configSubsOid);
		}

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadGBRCorpSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadGBRCorpSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadGBRCorpSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadGBRCorpSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

	//download in excel -> CORP_VBE_V11
	public Content downloadVBECorpSummary ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadVBECorpSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		String configSubsOid = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		if(customerType.equals("U")){
			SPDownloadVBECorpSummary downloadVBECorpSummaryStoredProc = new SPDownloadVBECorpSummary(getVAMDataSource(),schemaName);
			retObject = downloadVBECorpSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause,
					sortOrder, cursorId, configSubsOid);
		}else{
			SPDownloadVBECorpSummary downloadVBECorpSummaryStoredProc = new SPDownloadVBECorpSummary(getVAMDataSource(),schemaName);
			retObject = downloadVBECorpSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause,
					sortOrder, cursorId, configSubsOid);
		}

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadVBECorpSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadVBECorpSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadVBECorpSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadVBECorpSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

	//download in excel -> SERVICE_GBR_V10
	public Content downloadGBRAccountsBySubscription ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadGBRCorpSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		String configSubsOid = "";
		String serviceId = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			serviceId = (String) params.get("SERVICEID");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		SPDownloadGBRAccountsBySubscription downloadGBRAccountsBySubscription = new SPDownloadGBRAccountsBySubscription(getVAMDataSource(),schemaName);

			retObject = downloadGBRAccountsBySubscription.executeStoredProcedure(appUserID,debugLevel, serviceId, whereClause, sortOrder, cursorId,configSubsOid);

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadGBRCorpSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadGBRCorpSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadGBRCorpSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadGBRCorpSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

	//download in excel -> SERVICE_VBE_V11
	public Content downloadVBEAccountsBySubscription ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadVBEAccountsBySubscription";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		String configSubsOid = "";
		String serviceId = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			serviceId = (String) params.get("SERVICEID");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		SPDownloadVBEAccountsBySubscription downloadVBEAccountsBySubscription = new SPDownloadVBEAccountsBySubscription(getVAMDataSource(),schemaName);

			retObject = downloadVBEAccountsBySubscription.executeStoredProcedure(appUserID,debugLevel, serviceId, whereClause, sortOrder, cursorId,configSubsOid);

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadVBEAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadVBEAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadVBEAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadVBEAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}
	public Content downloadEMediaBMConfigWaivers ( Map params) throws NCASException {

		String schemaName = getSchemaName();
		SPDownloadEMediaBMConfigWaivers downloadEMediaBMConfigWaiversStoredProc = new SPDownloadEMediaBMConfigWaivers(getVAMDataSource(),schemaName);
		Content retObject = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadEMediaProfile";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String contractId = "";
			if(params!=null){
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				contractId = (String)params.get("CONTRACT_ID");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadEMediaBMConfigWaiversStoredProc.executeStoredProcedure(userID, debugLevel, contractId,whereClause, sortOrder);

			_LOGGER.info("Get BM Config Waivers responseMap -> " + retObject);


		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadsEMediaBMConfigWaivers in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadsEMediaBMConfigWaivers in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadsEMediaBMConfigWaivers in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadsEMediaBMConfigWaivers in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
		}

	public Content downloadEMediaBMWaivers ( Map params) throws NCASException {

		String schemaName = getSchemaName();
		SPDownloadEMediaBMWaivers downloadEMediaBMWaiversStoredProc = new SPDownloadEMediaBMWaivers(getVAMDataSource(),schemaName);
		Content retObject = null;
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadEMediaBMWaivers";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String contractId = "";
			if(params!=null){
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				contractId = (String)params.get("CONTRACT_ID");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadEMediaBMWaiversStoredProc.executeStoredProcedure(userID, debugLevel, contractId,whereClause, sortOrder);


			_LOGGER.info("Get BM Waivers responseMap -> " + retObject);


		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadsEMediaBMWaivers in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadsEMediaBMWaivers in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadsEMediaBMWaivers in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadsEMediaBMWaivers in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
		}


	public Map getEMediaSummaryDeferredDownload(Map params) throws NCASException {
		String METHOD_NAME = "getEMediaSummaryDeferredDownload :: ";
		String schemaName = getSchemaName();
		Map retMap = new HashMap();

		try
		{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (appUserID == null) {
					appUserID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEMediaSummaryDeferredDownload";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			if (params!=null) {
				String whereClause = (String)params.get("FILTER");;
				_LOGGER.debug(METHOD_NAME + "FILTER - " + whereClause );

				String sortOrder = (String)params.get("SORT");;
				_LOGGER.debug(METHOD_NAME + "SORT - " + sortOrder );

				String customerNo = (String)params.get("CUSTNUM");
				_LOGGER.debug(METHOD_NAME + "CUSTNUM - " + customerNo );

				String customerType = (String)params.get("CUSTTYPE");
				_LOGGER.debug(METHOD_NAME + "CUSTTYPE - " + customerType );

				String cursorId = (String)params.get("CURSOR");
				_LOGGER.debug(METHOD_NAME + "CURSOR - " + cursorId );

				String ftpUserId = (String) params.get("ftp_userid");
				_LOGGER.debug(METHOD_NAME + "FTP_USERID - " + ftpUserId );

				String ftpPassword = (String) params.get("ftp_password");
				_LOGGER.debug(METHOD_NAME + "FTP_PASSWORD - " + ftpPassword );

				String ftpHostName = (String) params.get("ftp_hostname");
				_LOGGER.debug(METHOD_NAME + "FTP_HOST_NAME - " + ftpHostName );

				String ftpDir = (String) params.get("ftp_directory");
				_LOGGER.debug(METHOD_NAME + "FTP_DIRECTORY - " + ftpDir );

				String ftpFileName = (String) params.get("ftp_filename");
				_LOGGER.debug(METHOD_NAME + "FTP_FILENAME - " + ftpFileName );

				String dataFormat = (String) params.get("dataFormat");
				_LOGGER.debug(METHOD_NAME + "DATAFORMAT - " + dataFormat );
				if (whereClause==null) {
					whereClause = "";
				}

				String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

				String downloadType = (String) params.get("DOWNLOAD_TYPE"); //Can be CORP_EMEDIA or SUMM_EMEDIA
				if (downloadType != null && downloadType.equalsIgnoreCase("CORP_EMEDIA")) {
					SPCorpSummaryDeferredDownload spCorpSummaryDeferredDownloadStoredProc =
												new SPCorpSummaryDeferredDownload(getVAMDataSource(), schemaName);
					retMap = spCorpSummaryDeferredDownloadStoredProc.executeStoredProcedure(appUserID, debugLevel, customerNo,
												customerType, whereClause, sortOrder, cursorId, ftpUserId, ftpPassword,
												ftpHostName, ftpDir, ftpFileName, dataFormat);
				} else {
					SPEMediaSummaryDeferredDownload spEMediaSummaryDeferredDownloadStoredProc =
												new SPEMediaSummaryDeferredDownload(getVAMDataSource(),schemaName);
					retMap = spEMediaSummaryDeferredDownloadStoredProc.executeStoredProcedure(appUserID, debugLevel, customerNo,
												customerType, whereClause, sortOrder, cursorId, ftpUserId, ftpPassword,
												ftpHostName, ftpDir, ftpFileName, dataFormat);
				}
			}
		} catch(NCASException ncasException) {
			_LOGGER.debug("GetEMediaSummaryDeferredDownload in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetEMediaSummaryDeferredDownload in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
			} catch(Exception vamEx) {
			_LOGGER.debug("GetEMediaSummaryDeferredDownload in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetEMediaSummaryDeferredDownload in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	public Content getEMediaDownloadSummary( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "getEMediaDownloadSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}


		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		if(customerType.equals("U")){
			SPGetEMediaDownloadSummaryExt getEMediaDownloadSummaryStoredProc = new SPGetEMediaDownloadSummaryExt(getVAMDataSource(),schemaName);
			retObject = getEMediaDownloadSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo,customerType,whereClause,sortOrder,cursorId);
		}else{
			SPGetEMediaDownloadSummary getEMediaDownloadSummaryStoredProc = new SPGetEMediaDownloadSummary(getVAMDataSource(),schemaName);
			retObject = getEMediaDownloadSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo,customerType,whereClause,sortOrder,cursorId);
		}




		} catch(NCASException ncasException) {
		_LOGGER.debug("GetEMediaDownloadSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("GetEMediaDownloadSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("GetEMediaDownloadSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("GetEMediaDownloadSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

public Content getEMediaCorpDownloadSummary ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "getEMediaCorpDownloadSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		if(customerType.equals("U")){
			SPGetEMediaCorpDownloadSummaryExt getEMediaCorpDwnldSummaryStoredProc = new SPGetEMediaCorpDownloadSummaryExt(getVAMDataSource(),schemaName);
			retObject = getEMediaCorpDwnldSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo,customerType,whereClause,sortOrder,cursorId);
		}else{
			SPGetEMediaCorpDownloadSummary getEMediaCorpDwnldSummaryStoredProc = new SPGetEMediaCorpDownloadSummary(getVAMDataSource(),schemaName);
			retObject = getEMediaCorpDwnldSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo,customerType,whereClause,sortOrder,cursorId);
		}

		} catch(NCASException ncasException) {
		_LOGGER.debug("GetEMediaDownloadSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("GetEMediaDownloadSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("GetEMediaDownloadSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("GetEMediaDownloadSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

public Content downloadsEmediaProfileAccounts ( Map params) throws NCASException {
	String schemaName = getSchemaName();
	Content retObject = null;
	SPDownloadsEmediaProfileAccounts downloadsEmediaProfileAccounts = new SPDownloadsEmediaProfileAccounts(getVAMDataSource(),schemaName);
	try
	{
	String appUserID = null;
	try {
	appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
	if (appUserID == null) {
	appUserID = "USSLBMG";
	}
	} catch(Exception e) {
	_LOGGER.debug("APP USER ID is null..");
	String[] errMsg = new String[3];
	errMsg[0] = "getEMediaCorpDownloadSummary";
	errMsg[1] = USER_ID_CONFIG_READ_ERROR;
	throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
	}
	String whereClause = "";
	String sortOrder = "";
	String oid = "";
	String profileType = "";
	if(params!=null){
		sortOrder = (String)params.get("SORT");
		whereClause = (String)params.get("FILTER");
		oid = (String)params.get("CUSTNUM");
		if(whereClause==null) {
			whereClause = "";
		}
		profileType = (String)params.get("PROFILE_TYPE");
	}

	downloadsEmediaProfileAccounts.setProfileType(profileType);

	String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
	retObject = downloadsEmediaProfileAccounts.executeStoredProcedure(appUserID,debugLevel,oid,whereClause,sortOrder);


	} catch(NCASException ncasException) {
	_LOGGER.debug("GetEMediaDownloadSummary in VAM Failed \n"+ncasException.getMessage());
	_LOGGER.error("GetEMediaDownloadSummary in VAM Failed \n"+ncasException.getMessage());
	throw ncasException;
	} catch(Exception vamEx) {
	_LOGGER.debug("GetEMediaDownloadSummary in VAM Failed \n"+vamEx.getMessage());
	_LOGGER.error("GetEMediaDownloadSummary in VAM Failed \n"+vamEx.getMessage());
	throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
	}
	return retObject;
}

   public String generateAFTRequestNumber(String userId, String configType, String configId, String custName,
                                        String action, String mode, String userName, String startDateStr,
                                        String comment, String fileName, String billMonth,
                                        String billYear, String rptRequestId) throws NCASException {
    _LOGGER.info("<<< Entering EMediaProfileDAOImpl's generateAFTRequestNumber() >>>");
    String requestNumber = null;
    String schemaName = getSchemaName();
    SPGenerateAFTRequestNumber generateAFTRequestNoStoredProc = new SPGenerateAFTRequestNumber(getVAMDataSource(),schemaName);

    try {
        String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
        Map responseMap = generateAFTRequestNoStoredProc.executeStoredProcedure(userId, debugLevel, configType,
                                            configId, custName, action, mode, userName, startDateStr, comment, fileName,
                                            billMonth, billYear, rptRequestId);
        _LOGGER.info("responseMap --> " + responseMap);
        requestNumber = (String) responseMap.get("REQUEST_NO");
    } catch(NCASException ncasException) {
        _LOGGER.debug("GenerateAFTRequestNumber in VAM Failed \n"+ncasException.getMessage());
        _LOGGER.error("GenerateAFTRequestNumber in VAM Failed \n"+ncasException.getMessage());
        throw ncasException;
    } catch(Exception vamEx) {
        _LOGGER.debug("GenerateAFTRequestNumber in VAM Failed \n"+vamEx.getMessage());
        _LOGGER.error("GenerateAFTRequestNumber in VAM Failed \n"+vamEx.getMessage());
        throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
    }

    _LOGGER.info("<<< Exiting EMediaProfileDAOImpl's generateAFTRequestNumber() >>>");
    return requestNumber;
   }

   public boolean insertAFTAccounts(String userId, String requestNumber, String ediDataGroup,
                                        List accountsList, int recordCount, boolean uploadComplete) throws NCASException {
    _LOGGER.info("<<< Entering EMediaProfileDAOImpl's insertAFTAccounts() >>>");
    boolean status = false;
    String schemaName = getSchemaName();
    SPUploadAFTInfo uploadAftStoredProc = new SPUploadAFTInfo(getVAMDataSource(),schemaName);

    try {
        String appUserID = null;

        //Logic to insert records into VAM
        _LOGGER.info("Request Number -> " + requestNumber);
        _LOGGER.info("AccountsList -> " + accountsList);
        String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
        String accounts = convertArrayListToString((ArrayList)accountsList);
        _LOGGER.info("Account Number(s) -> " + accounts);
        Map responseMap = uploadAftStoredProc.executeStoredProcedure(userId, debugLevel, requestNumber, ediDataGroup, accounts, recordCount, uploadComplete);
        _LOGGER.info("responseMap -> " + responseMap);
        //requestNumber = (String) responseMap.get("REQUEST_NO");
        status = true;
    } catch(NCASException ncasException) {
        ncasException.printStackTrace();
        _LOGGER.debug("InsertAFTAccounts in VAM Failed \n"+ncasException.getMessage());
        _LOGGER.error("InsertAFTAccounts in VAM Failed \n"+ncasException.getMessage());
        throw ncasException;
    } catch(Exception vamEx) {
        vamEx.printStackTrace();
        _LOGGER.debug("InsertAFTAccounts in VAM Failed \n"+vamEx.getMessage());
        _LOGGER.error("InsertAFTAccounts in VAM Failed \n"+vamEx.getMessage());
        throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
    }

    _LOGGER.info("<<< Exiting EMediaProfileDAOImpl's insertAFTAccounts() >>>");
    return status;
   }

	public Map getAFTRequests(String whereClause, String sortFilter, Pagination pagination, String requestType) throws NCASException {
		Map responseMap = null;
		_LOGGER.info("<<< Entering EMediaProfileDAOImpl's getAFTRequests() >>>");
		String schemaName = getSchemaName();
		SPGetAFTInfo aftInfoStoreProc = new SPGetAFTInfo(getVAMDataSource(),schemaName);
		try	{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (appUserID == null) {
					appUserID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getAFTRequests";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			responseMap = aftInfoStoreProc.executeStoredProcedure(appUserID, debugLevel, whereClause, sortFilter, pagination, requestType);

			_LOGGER.info("Response MAP -> " + responseMap);

		} catch(NCASException ncasException) {
			ncasException.printStackTrace();
			_LOGGER.debug("GetAFTRequests in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetAFTRequests in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("GetAFTRequests in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetAFTRequests in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}

		_LOGGER.info("<<< Exiting EMediaProfileDAOImpl's getAFTRequests() >>>");
		return responseMap;
	}

	public Map getAFTAccounts(String aftRequestId, String aftMode, String whereClause, String sortFilter, Pagination pagination) throws NCASException {
		Map responseMap = null;
		_LOGGER.info("<<< Entering EMediaProfileDAOImpl's getAFTAccounts() >>>");
		String schemaName = getSchemaName();
		SPGetAFTDetailInfo aftDetailInfoStoreProc = new SPGetAFTDetailInfo(getVAMDataSource(),schemaName);
		try	{
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (appUserID == null) {
					appUserID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getAFTAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = new HashMap();
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			responseMap = aftDetailInfoStoreProc.executeStoredProcedure(appUserID, debugLevel, aftRequestId, aftMode, whereClause, sortFilter, pagination);

			_LOGGER.info("Response MAP -> " + responseMap);
		} catch(NCASException ncasException) {
			_LOGGER.debug("GetAFTAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetAFTAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetAFTAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetAFTAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}

		_LOGGER.info("<<< Exiting EMediaProfileDAOImpl's getAFTAccounts() >>>");
		return responseMap;
	}

	public Content downloadAFTRequests(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadAFTRequest downloadAFTRequestStoredProc = new SPDownloadAFTRequest(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadAFTRequests";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
            String sortOrder = "";
            String requestType = "";
			if(params!=null) {
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
				requestType = (String)params.get("requestType");
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadAFTRequestStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder, requestType);

		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadAFTRequests in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadAFTRequests in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadAFTRequests in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadAFTRequests in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

    public Content downloadAFTReportViewRequests(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadAFTReportViewRequest downloadAFTReportViewRequestStoredProc = new SPDownloadAFTReportViewRequest(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadAFTReportViewRequests";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
            String sortOrder = "";
            String requestType = "";
			if(params!=null) {
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
				requestType = (String)params.get("requestType");
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadAFTReportViewRequestStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder, requestType);

		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadAFTReportViewRequests in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadAFTReportViewRequests in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadAFTReportViewRequests in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadAFTReportViewRequests in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
    }

	public Content downloadAFTRequestAccounts(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadAFTAccounts downloadAFTAccountsStoredProc = new SPDownloadAFTAccounts(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadAFTRequestAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String requestId = "";
			String mode = EMediaAFTConstants.AFT_UPDATE_REPORT_TYPE;
			if(params!=null) {
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				requestId = (String)params.get("AFT_REQUEST_ID");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadAFTAccountsStoredProc.executeStoredProcedure(userID, debugLevel, requestId, mode, whereClause, sortOrder);

		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadAFTRequestAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadAFTRequestAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadAFTRequestAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadAFTRequestAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

    public Content downloadAFTReportOnlyRequestsAccounts(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadAFTReportOnlyAccounts downloadAFTReportOnlyAcctsStoredProc = new SPDownloadAFTReportOnlyAccounts (getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadAFTReportOnlyRequestsAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String requestId = "";
			String mode = EMediaAFTConstants.AFT_REPORT_ONLY_TYPE;
			if(params!=null) {
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				requestId = (String)params.get("AFT_REQUEST_ID");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadAFTReportOnlyAcctsStoredProc.executeStoredProcedure(userID, debugLevel, requestId, mode, whereClause, sortOrder);

		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadAFTReportOnlyRequestsAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadAFTReportOnlyRequestsAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadAFTReportOnlyRequestsAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadAFTReportOnlyRequestsAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
    }

    public Content downloadAFTEDIReportViewRequestsAccounts(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadAFTEDIAccounts downloadAFTEDIAccountsStoredProc = new SPDownloadAFTEDIAccounts(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadAFTEDIReportViewRequestsAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String requestId = "";
			String mode = EMediaAFTConstants.AFT_EDI_REPORT_TYPE;
			if(params!=null) {
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				requestId = (String)params.get("AFT_REQUEST_ID");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadAFTEDIAccountsStoredProc.executeStoredProcedure(userID, debugLevel, requestId, mode, whereClause, sortOrder);

		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadAFTEDIReportViewRequestsAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadAFTEDIReportViewRequestsAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadAFTEDIReportViewRequestsAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadAFTEDIReportViewRequestsAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
    }

    public Content downloadAFTVECReportViewRequestsAccounts(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadAFTVECAccounts downloadAFTVECAccountsStoredProc = new SPDownloadAFTVECAccounts(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadAFTVECReportViewRequestsAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String requestId = "";
			String mode = EMediaAFTConstants.AFT_VEC_REPORT_TYPE;
			if(params!=null) {
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				requestId = (String)params.get("AFT_REQUEST_ID");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadAFTVECAccountsStoredProc.executeStoredProcedure(userID, debugLevel, requestId, mode, whereClause, sortOrder);

		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadAFTVECReportViewRequestsAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadAFTVECReportViewRequestsAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadAFTVECReportViewRequestsAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadAFTVECReportViewRequestsAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
    }

    public Map getBMConfigWaivers(String contractId, String whereClause,
			String sortOrder, Pagination pagination) throws NCASException {
		//Map acctListMap = null;
		Map responseMap=null;
		String schemaName = getSchemaName();
		SPGetEMediaBMConfigWaivers getBMConfigWaiversStoredProc = new SPGetEMediaBMConfigWaivers(
				getVAMDataSource(), schemaName);
		try {

			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getBMConfigWaivers";
				//errMsg[1] = String.valueOf(userOid);
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = getBMConfigWaiversStoredProc
					.executeStoredProcedure(userID, "0",  contractId,whereClause,
							 sortOrder,  pagination);
			_LOGGER.info("Get BM Waivers responseMap -> " + responseMap);

			//Map recordsMap = (Map) responseMap.get("recordsMap");

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getBMConfigWaivers";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_BM_CFG_WAIVERS;
				errMsg[2] = spInfo.toString();
				/*
				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
				*/
			}
			//acctListMap = (HashMap) responseMap.get("acctlists");
			//.logger.info("Get Acct List Map -> " + acctListMap);
		} catch (NCASException ncasException) {
			_LOGGER.debug("Get BM WAivers in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("Get BM WAivers  in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("Get BM WAivers in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("Get ABM WAivers in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("VAM BM WAivers  Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		return responseMap;
	}


	public Map getBMWaivers(String contractId, String whereClause,
			String sortOrder, Pagination pagination) throws NCASException {
		//Map acctListMap = null;
		Map responseMap=null;
		String schemaName = getSchemaName();
		SPGetEMediaBMWaivers getBMConfigWaiversStoredProc = new SPGetEMediaBMWaivers(
				getVAMDataSource(), schemaName);
		try {

			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getBMWaivers";
				//errMsg[1] = String.valueOf(userOid);
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = getBMConfigWaiversStoredProc
					.executeStoredProcedure(userID, "0", contractId,whereClause,
							 sortOrder,  pagination);
			_LOGGER.info("Get BM Waivers responseMap -> " + responseMap);

			//Map recordsMap = (Map) responseMap.get("recordsMap");

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getBMWaivers";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_BM_WAIVERS;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}
			//acctListMap = (HashMap) responseMap.get("acctlists");
			//.logger.info("Get Acct List Map -> " + acctListMap);
		} catch (NCASException ncasException) {
			_LOGGER.debug("Get BM WAivers in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("Get BM WAivers  in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("Get BM WAivers in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("Get ABM WAivers in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("VAM BM WAivers  Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		return responseMap;
	}

	public Map manageBMWaiver(String userId,String userName,String action,String contractId,String startDate,String endDate) throws NCASException {
		//Map acctListMap = null;
		Map responseMap=null;
		String schemaName = getSchemaName();
		SPManageBMWaiver manageBMWaiverStoredProc = new SPManageBMWaiver(
				getVAMDataSource(), schemaName);
		try {

			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageBMWaiver";
				//errMsg[1] = String.valueOf(userOid);
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = manageBMWaiverStoredProc
					.executeStoredProcedure(userID, "0",   userId, userName, action, contractId, startDate, endDate);
			_LOGGER.info("Manage BM Waivers responseMap -> " + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "manageBMWaiver";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_MANAGE_BM_WAIVER;
				errMsg[2] = spInfo.toString();
				/*
				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
				*/
			}
		} catch (NCASException ncasException) {
			_LOGGER.debug("Manage BM WAivers in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("Manage BM WAivers  in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("Manage BM WAivers in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("Maange ABM WAivers in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("Manage BM WAivers  Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		return responseMap;
	}


	public Map manageServiceProvider(String userId,String userName,String action, EMediaSrvcProviderInfo svcProvInfo) throws NCASException {
		//Map acctListMap = null;
		Map responseMap=null;
		String schemaName = getSchemaName();
		SPManageServiceProvider manageServiceProviderStoredProc = new SPManageServiceProvider(
				getVAMDataSource(), schemaName);
		try {

			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageServiceProvider";
				//errMsg[1] = String.valueOf(userOid);
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = manageServiceProviderStoredProc
					.executeStoredProcedure(userID, "0",   userId, userName, action, svcProvInfo);
			_LOGGER.info("Manage Service Provider responseMap -> " + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "manageServiceProvider";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_MANAGE_SVC_PROV;
				errMsg[2] = spInfo.toString();
                                /* bxu: It's not fatal error, we have to send reason code and return code back to UI.
				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
                                */
			}
		} catch (NCASException ncasException) {
			_LOGGER.debug("Manage Service Provider in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("Manage Service Provider  in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("Manage Service Provider in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("Manage Service Provider in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("Manage Service Provider  Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		return responseMap;
	}

	public Map getEmediaBMContract(String contractId, String custName,String whereClause,
			String sortOrder, Pagination pagination) throws NCASException {
		//Map acctListMap = null;
		Map responseMap=null;
		String schemaName = getSchemaName();
		SPGetEMediaBMContract getEmediaBMContractStoredProc = new SPGetEMediaBMContract(
				getVAMDataSource(), schemaName);
		try {

			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getEmediaBMContract";
				//errMsg[1] = String.valueOf(userOid);
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = getEmediaBMContractStoredProc
					.executeStoredProcedure(userID, "0",   contractId,  custName,whereClause,
							 sortOrder,  pagination);
			_LOGGER.info("getEmedia BM Contract responseMap -> " + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getEmediaBMContract";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_BM_CONTRACT;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}
		} catch (NCASException ncasException) {
			_LOGGER.debug("getEmedia BM Contract in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getEmedia BM Contract  in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getEmedia BM Contract in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getEmedia BM Contract in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("getEmedia BM Contract  Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		return responseMap;
	}

	public Map setPaperContractAmendFlag(String customerOid, String custType) throws NCASException {
		_LOGGER.info("<<< Entering EMediaProfileDAOImpl's setPaperContractAmendFlag() >>>");
		Map responseMap=null;
		String schemaName = getSchemaName();
		SPSetPaperContractAmend setPaperContractAmendStoredProc = new SPSetPaperContractAmend(
				getVAMDataSource(), schemaName);
		try {

			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "setPaperContractAmendFlag";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			responseMap = setPaperContractAmendStoredProc
					.executeStoredProcedure(userID, "0", customerOid, custType);
			_LOGGER.info("Set Paper Contract Amend responseMap -> " + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE"))
					.intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "setPaperContractAmendFlag";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_SET_PAPER_AMEND;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}
		} catch (NCASException ncasException) {
			_LOGGER.debug("set Paper Contract Amend in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("set Paper Contract Amend  in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("set Paper Contract Amendt in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("set Paper Contract Amend in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException("set Paper Contract Amend Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		_LOGGER.info("<<< Exiting EMediaProfileDAOImpl's setPaperContractAmendFlag() >>>");
		return responseMap;
	}

	public String managePaperFree(Map params) throws NCASException {
		String retValue = "false";
		String schemaName = getSchemaName();
		SPManagePaperFree managePaperFreeProc = new SPManagePaperFree(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "managePaperFree";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);


			String selections  = (String) params.get("ACCTLIST");
			String action  = (String) params.get("ACTION");
			String userOid  = (String) params.get("USEROID");
			Structure struct = (Structure)params.get("STRUCTURE");

			Map responseMap = managePaperFreeProc.executeStoredProcedure(userID,debugLevel,selections,action,userOid,struct);
			_LOGGER.info("Manage Paper Free response -> " + responseMap);

			retValue = "true";//((String)responseMap.get("STATUS"));
			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "managePaperFree";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_PAPER_FREE;
			    errMsg[2] = spInfo.toString();

			    retValue = "false";

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}


		}
		catch(NCASException ncasException ) {
			_LOGGER.error("Manage PaperFree in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vamEx ) {
			_LOGGER.error("Manage PaperFree in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException("Manage PaperFree in VAM Failed\n"
					+ vamEx.toString(), EMediaProfileDAOImpl.class, vamEx);
		}
		return retValue;
	}

	public Map searchGBRProfile(GBREMediaProfile profile, String whereClause, String sortOrder, Pagination pagination) throws NCASException {
		String schemaName = getSchemaName();
		SPSearchGBRProfile searchGBRProfileStoredProc = new SPSearchGBRProfile(getVAMDataSource(),schemaName);
		Map responseMap = new HashMap();
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "searchGBRProfile";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			responseMap = searchGBRProfileStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder, profile, pagination);
			_LOGGER.info("SearchEMediaProfile responseMap -> " + responseMap);

			Map recordsMap = (Map) responseMap.get("recordsMap");
			int returnCode = ((Integer)recordsMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) recordsMap.get("REASON_CODE"));
				spInfo.setErrorText((String) recordsMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) recordsMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) recordsMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)recordsMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "searchGBRProfile";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_SEARCH_GBR_PROFILE;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException ) {
			_LOGGER.debug("SearchGBRProfile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("SearchGBRProfile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("SearchGBRProfile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("SearchGBRProfile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return responseMap;
	}

	public Content downloadsGBRProfile(Map params) throws NCASException {
		String schemaName = getSchemaName();
		SPDownloadGBRProfile downloadGBRProfileStoredProc = new SPDownloadGBRProfile(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadsGBRProfile";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String profileType = "";
			String userOid = "";
			if(params!=null){
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				profileType = (String)params.get("PROFILE_TYPE");
				userOid = (String)params.get("CUSTNUM");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadGBRProfileStoredProc.executeStoredProcedure(userID, debugLevel, profileType, whereClause, sortOrder, userOid);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("DownloadsGBRProfile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("DownloadsGBRProfile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("DownloadsGBRProfile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("DownloadsGBRProfile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	// Method: downloadGBRAccounts
	// Usage : to get a list of accounts based for a profile in a excel format.
	// VAM API : GET_GBR_ACCTS
	public Content downloadGBRAccounts(Map params) throws NCASException {
		String schemaName = getSchemaName();

		SPDownloadGBRAccounts downloadGBRAccountsStoredProc = new SPDownloadGBRAccounts(getVAMDataSource(),schemaName);
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadsGBRAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String whereClause = "";
			String sortOrder = "";
			String tabInd = (String) params.get("TAB");

			String gbrAcct = (String) params.get("GBRACCT");

			if("CORP_ID".equals(tabInd))
			{
				tabInd = "CORP";
			}
			else if("BILL_PAYER".equals(tabInd))
			{
				tabInd = "ACCT";
			}
			else
				tabInd = "ALL";

			String configSubsOid = (String) params.get("CONFIGSUBSOID");
			if(params!=null){
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("")) {
					whereClause = "1=1";
				}
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			retObject = downloadGBRAccountsStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder,tabInd,configSubsOid,gbrAcct);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("downloadsGBRAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("downloadsGBRAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("downloadsGBRAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("downloadsGBRAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	// Method: downloadVBEAccounts
	// Usage : to get a list of accounts based for a profile in a excel format.
	// VAM API : GET_VBE_ACCTS
	public Content downloadVBEAccounts(Map params) throws NCASException {
		String schemaName = getSchemaName();
		String tabInd = (String) params.get("TAB");
		SPDownloadVBEAccounts downloadVBEAccountsStoredProc;
		if(tabInd !=null && tabInd.trim().equals("DOWNLOAD_REMIT"))
		{    String fullDownload="Y";
		     
		      _LOGGER.info("Inside DOWNLOAD_REMIT Condition");
			 downloadVBEAccountsStoredProc = new SPDownloadVBEAccounts(getVAMDataSource(),schemaName,fullDownload);	
		}
		else
		{
			 downloadVBEAccountsStoredProc = new SPDownloadVBEAccounts(getVAMDataSource(),schemaName);
		}
		
		Content retObject = null;
		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "downloadVBEAccounts";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			
			String sortOrder = "";
			String whereClause="";
			String gbrAcct = (String) params.get("GBRACCT");
			String configSubsOid = (String) params.get("CONFIGSUBSOID");

			if(params!=null){
				sortOrder = (String)params.get("SORT");
				whereClause = (String)params.get("FILTER");
				if(whereClause==null) {
					whereClause = "1=1";
				} else if(whereClause.equals("") ) {
					whereClause = "1=1";
				}
			}
			if(tabInd !=null && tabInd.trim().equals("DOWNLOAD_REMIT"))
			{
				whereClause="";
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			String remitOid = (String) params.get("REMITOID");
			String reportOid = (String) params.get("REPORTOID");
			retObject = downloadVBEAccountsStoredProc.executeStoredProcedure(userID, debugLevel, whereClause, sortOrder,tabInd,configSubsOid,gbrAcct,remitOid,reportOid);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("downloadVBEAccounts in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("downloadVBEAccounts in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("downloadVBEAccounts in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("downloadVBEAccounts in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	public List getGBRProfile(GBREMediaProfile profile) throws NCASException {
		List profilesList = new ArrayList();
		String schemaName = getSchemaName();
		SPGetGBRProfile getGBRProfileStoredProc = new SPGetGBRProfile(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGBRProfile";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = getGBRProfileStoredProc.executeStoredProcedure(userID,debugLevel,String.valueOf(profile.getConfigSubscriptionOid()));
			_LOGGER.info("GetGBRProfile responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getGBRProfile";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_GBR_PROFILE;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			profilesList = (List) responseMap.get("profiles");
			_LOGGER.info("GetGBRProfile profilesList -> " + profilesList);
		} catch(NCASException ncasException ) {
			_LOGGER.debug("GetGBRProfile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetGBRProfile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetGBRProfile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetGBRProfile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return profilesList;
	}

	public String manageGBRProfile(GBREMediaProfile profile, String action) throws NCASException {
		String status = "SUCCESS";
		String schemaName = getSchemaName();
		SPManageGBRProfile manageGBRProfileStoredProc = new SPManageGBRProfile(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				status = "FAILED";
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageGBRProfile";
				errMsg[1] = profile.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = manageGBRProfileStoredProc.executeStoredProcedure(userID,debugLevel,profile,action);
			_LOGGER.info("Manage EMedia Profile responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				status = "FAILED";
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "manageGBRProfile";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_PROFILE;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}
		} catch(NCASException ncasException ) {
			_LOGGER.debug("ManageGBRProfile in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("ManageGBRProfile in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			status = "Failed";
			_LOGGER.debug("ManageGBRProfile in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("ManageGBRProfile in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return status;
	}

	// Method: getGBROrgs
	// Usage : to get a list of ORGs belong to the GBR profile
	// VAM API : GET_GBR_ORGS
	public Map getGBROrgs(Map input) throws NCASException {
		List profilesList = new ArrayList();
		String schemaName = getSchemaName();
		Map responseMap = new HashMap();

		Map orgsMap = new HashMap();
		SPGetGBROrgs getGBROrgsStoredProc = new SPGetGBROrgs(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGBROrgs";
				errMsg[1] = input.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			String gbrAcctNum      = (String) input.get("gbrAcctNum");
			String orgLevel1Number = (String) input.get("orgLevel1Number");
			String sortOrder       = (String) input.get("sortBy");

			responseMap = getGBROrgsStoredProc.executeStoredProcedure(userID,debugLevel,input);
			_LOGGER.info("GetGBRProfile responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getGBROrg";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_GBR_ORG;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			orgsMap = (Map)responseMap.get("gbrOrgs");
			orgsMap.put("trackingNumber", "");
			orgsMap.put("gbrNumber", gbrAcctNum);

			_LOGGER.info("GetGBRProfile orgsMap -> " + orgsMap);

			//profilesList = (List) responseMap.get("profiles");
			//_LOGGER.info("GetGBROrg profilesList -> " + profilesList);


		} catch(NCASException ncasException ) {
			_LOGGER.debug("GetGBROrg in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("GetGBROrg in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			_LOGGER.debug("GetGBROrg in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("GetGBROrg in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return orgsMap;
	}

	/*public GbrOrgPair manageGbrOrg(Map input) throws NCASException {
		String status = "SUCCESS";
		String schemaName = getSchemaName();
		SPManageGBROrg manageGBROrgStoredProc = new SPManageGBROrg(getVAMDataSource(),schemaName);
		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				status = "FAILED";
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageGbrOrg";
				errMsg[1] = input.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = manageGBROrgStoredProc.executeStoredProcedure(userID,debugLevel,input,action);
			_LOGGER.info(" manageGbrOrg responseMap -> " + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				status = "FAILED";
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "manageGbrOrg";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_ORG;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}
		} catch(NCASException ncasException ) {
			_LOGGER.debug("manageGbrOrg in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("manageGbrOrg in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			status = "Failed";
			_LOGGER.debug("manageGbrOrg in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("manageGbrOrg in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return status;
	}
	*/

	// Method: deleteGbrOrgPair
	// Usage : to add or delete GBR ORGs belong to the GBR profile
	// VAM API : MANAGE_GBR_ORG
	public boolean deleteGbrOrgPair(Map input) throws NCASException {
		boolean status = true;
		String schemaName = getSchemaName();
		SPManageGBROrg manageGBROrgStoredProc = new SPManageGBROrg(getVAMDataSource(),schemaName);
		String action = "C";

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				//status = "FAILED";
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "manageGBROrg";
				errMsg[1] = input.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			GbrOrgPair gbrOrgPair = new GbrOrgPair();

			ArrayList gbrOrgsList = new ArrayList();
			gbrOrgsList = (ArrayList) input.get("orgPairs");

			for(int i=0;i<gbrOrgsList.size();i++)
			{
				gbrOrgPair = (GbrOrgPair) gbrOrgsList.get(i);
				input.put("orgLevel1Number", gbrOrgPair.getOrg1Oid());
				input.put("orgLevel1Name", gbrOrgPair.getOrg1());
				input.put("orgLevel2Number", gbrOrgPair.getOrg2Oid());
				input.put("orgLevel2Name", gbrOrgPair.getOrg2());


				Map responseMap = manageGBROrgStoredProc.executeStoredProcedure(userID,debugLevel,input,action);
				_LOGGER.info("Manage manageGBROrg responseMap -> " + responseMap);

				int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
				if( returnCode > 0 ) {
					//status = "FAILED";
					 //Excuting SP doesn't return correct result
					SPErrorInfo spInfo = new SPErrorInfo();
					spInfo.setReturnCode(returnCode);//RETURN_CODE
					spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
					spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
					spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
					spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
					spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

				    String[] errMsg = new String[3];
				    errMsg[0] = "manageGBROrg";
				    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_ORG;
				    errMsg[2] = spInfo.toString();

				    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
				}
			}
		} catch(NCASException ncasException ) {
			_LOGGER.debug("manageGBROrg in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("manageGBROrg in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			//status = "Failed";
			_LOGGER.debug("manageGBROrg in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("manageGBROrg in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return status;
	}

	// Method: deleteGbrOrgPair
	// Usage : to add or delete GBR ORGs belong to the GBR profile
	// VAM API : MANAGE_GBR_ORG
	public GbrOrgPair addGbrOrgPair(Map input) throws NCASException {
		boolean status = true;
		String schemaName = getSchemaName();
		SPManageGBROrg manageGBROrgStoredProc = new SPManageGBROrg(getVAMDataSource(),schemaName);
		String action = "A";

		_LOGGER.debug("inputMap" + input);

		//ArrayList gbrOrgsList = new ArrayList();
		//gbrOrgsList = (ArrayList) input.get("orgPairs");

		GbrOrgPair gbrOrgPair = new GbrOrgPair();

		gbrOrgPair = (GbrOrgPair) input.get("orgPair");
		_LOGGER.debug("gbrOrgPair" +gbrOrgPair.toString());

		input.put("orgLevel1Number", gbrOrgPair.getOrg1Oid());
		input.put("orgLevel1Name", gbrOrgPair.getOrg1());
		input.put("orgLevel2Number", gbrOrgPair.getOrg2Oid());
		input.put("orgLevel2Name", gbrOrgPair.getOrg2());

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
			    if (userID == null) {
			    	userID = "USSLBMG";
			    }
			} catch(Exception e) {
				//status = "FAILED";
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "addGbrOrgPair";
				errMsg[1] = input.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			Map responseMap = manageGBROrgStoredProc.executeStoredProcedure(userID,debugLevel,input,action);
			_LOGGER.info("manageGBROrg responseMap -> with Add" + responseMap);

			int returnCode = ((Integer)responseMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				//status = "FAILED";
				 //Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "addGbrOrgPair";
			    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_ORG;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}
			gbrOrgPair.setOrg1Oid((String)responseMap.get("ORG_LEVEL1_NO"));
			gbrOrgPair.setOrg1((String)responseMap.get("ORG_LEVEL1_NAME"));
			gbrOrgPair.setOrg2Oid((String)responseMap.get("ORG_LEVEL2_NO"));
			gbrOrgPair.setOrg2((String)responseMap.get("ORG_LEVEL2_NAME"));

		} catch(NCASException ncasException ) {
			_LOGGER.debug("addGbrOrgPair in VAM Failed \n"+ncasException.getMessage());
			_LOGGER.error("addGbrOrgPair in VAM Failed \n"+ncasException.getMessage());
			throw ncasException;
		} catch(Exception vamEx) {
			//status = "Failed";
			_LOGGER.debug("addGbrOrgPair in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("addGbrOrgPair in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return gbrOrgPair;
	}

	// Method: convertArrayListToString
	// Usage : to convert ArrayList to a String format VAM needed.

	private String convertArrayListToString(ArrayList list) {
		String strList = "";
		String separator = ",";
		if(list != null) {
			int size = list.size();
			int separatorLength = size-1;

			StringBuffer sb = new StringBuffer();
			for(int i=0; i<size; i++) {
				String value = (String)list.get(i);
				sb.append(value);

				if(i<separatorLength){
					sb.append(separator);
				}
			}
			strList = sb.toString();
		}
		return strList;
	}

	private String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}


	// Method: getGCPSummaryAccounts
	// Usage : to get a list of accounts based on customer name search criteria.
	// VAM API : SUMMARY_GCP_V10(Bill Payer tab)
	public Map getGCPSummaryAccounts(String customerNo, String customerType,
			String filterBy, String sortBy, String cursorId,
			Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetGCPSummaryAccounts getGCPSummaryAccountsStoredProc = new SPGetGCPSummaryAccounts(
				getVAMDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGCPSummaryAccounts";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getGCPSummaryAccountsStoredProc.executeStoredProcedure(userID,
					debugLevel, customerNo, customerType, filterBy, sortBy,
					cursorId, pagination,configSubsOid);
			_LOGGER.info("getGCPSummaryAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGCPSummaryAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_GCP_SUMMARY;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("getGCPSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getGCPSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getGCPSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getGCPSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	// Method: getGCPCorpSummaryAccounts
	// Usage : to get a list of accounts based on customer name search criteria.
	// VAM API : CORP_GCP_V10(Corp Tab)
	public Map getGCPCorpSummaryAccounts(String customerNo, String customerType,
			String filterBy, String sortOrder, String cursorId,
			Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();

		SPGetGCPCorpSummaryAccounts getGCPCorpSummaryAccountsStoredProc = new SPGetGCPCorpSummaryAccounts(
				getVAMDataSource(), schemaName);

		try {
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch (Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getGCPCorpSummaryAccounts";
				errMsg[1] = customerNo;
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,
						EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig
					.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getGCPCorpSummaryAccountsStoredProc.executeStoredProcedure(
					userID, debugLevel, customerNo, customerType, filterBy,
					sortOrder, cursorId, pagination, configSubsOid);
			_LOGGER.info("getGCPCorpSummaryAccounts responseMap -> " + retMap);

			int returnCode = ((Integer) retMap.get("RETURN_CODE")).intValue();
			if (returnCode > 0) {
				// Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);// RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE"))
						.intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGCPCorpSummaryAccounts";
				errMsg[1] = schemaName + "."
						+ NCASBOSIConstants.SP_GET_GCP_CORP_SUMMARY;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg,
						returnCode);
			}

		} catch (NCASException ncasException) {
			_LOGGER.debug("getGCPCorpSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			_LOGGER.error("getGCPCorpSummaryAccounts in VAM Failed \n"
					+ ncasException.getMessage());
			throw ncasException;
		} catch (Exception vamEx) {
			_LOGGER.debug("getGCPCorpSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			_LOGGER.error("getGCPCorpSummaryAccounts in VAM Failed \n"
					+ vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,
					EMediaProfileDAOImpl.class, vamEx);
		}
		return retMap;
	}

	// Method: getGCPAccountListBySubscription
	// Usage : to get a list of accounts based on account number search criteria.
	// VAM API : SERVICE_GCP_V10
	public Map getGCPAccountsBySubscription(String serviceId, String wherePhrase, String sortOrder,
			String tokenString, Pagination pagination,String configSubsOid) throws NCASException {
		Map retMap = null;
		String schemaName = getSchemaName();
		SPGetGCPAccountsBySubscription getGCPAcctsBySubscriptionStoredProc = new SPGetGCPAccountsBySubscription(getVAMDataSource(),schemaName);

		try
		{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			} catch(Exception e) {
			_LOGGER.debug("USER ID is null..");
			String[] errMsg = new String[3];
			errMsg[0] = "getGCPAccountsBySubscription";
			errMsg[1] = serviceId;
			errMsg[2] = USER_ID_CONFIG_READ_ERROR;
			throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			retMap = getGCPAcctsBySubscriptionStoredProc.executeStoredProcedure(userID,debugLevel, serviceId, wherePhrase, sortOrder, tokenString, pagination,configSubsOid);
			_LOGGER.info("getEmediaByAccountSearch responseMap -> " + retMap);

			int returnCode = ((Integer)retMap.get("RETURN_CODE")).intValue();
			if( returnCode > 0 ) {
				//Excuting SP doesn't return correct result
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) retMap.get("REASON_CODE"));
				spInfo.setErrorText((String) retMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) retMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) retMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String)retMap.get("SP_SQLSTATE"));

				String[] errMsg = new String[3];
				errMsg[0] = "getGCPAccountsBySubscription";
				errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_GET_GCP_ACCTS_BY_SUBSCRIPTION;
				errMsg[2] = spInfo.toString();

				throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

		} catch(NCASException ncasException) {
		_LOGGER.debug("getGCPAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("getGCPAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("getGCPAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("getGCPAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retMap;
	}

	// Method to get the Accounts by customer name in excel file for Bill Payer Tab
	//SUMMARY_GCP_V10
	public Content downloadGCPAccountsSummary(Map params) throws NCASException {
		String schemaName = getSchemaName();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadGCPAccountsSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}


		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String cursorId = "";
		String configSubsOid = "";
		String customerType= "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			customerType = (String)params.get("CUSTTYPE");
			if(whereClause==null) {
				whereClause = "";
			}
		}

		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		SPDownloadGCPAccountsSummary downloadGCPAccountsSummaryStoredProc = new SPDownloadGCPAccountsSummary(getVAMDataSource(),schemaName);
		retObject = downloadGCPAccountsSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause, sortOrder,
				cursorId, configSubsOid);

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadGCPAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadGCPAccountsSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadGCPAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadGCPAccountsSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
	}

	//download in excel -> CORP_GCP_V10
	public Content downloadGCPCorpSummary ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadGCPCorpSummary";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		String configSubsOid = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		SPDownloadGCPCorpSummary downloadGCPCorpSummaryStoredProc = new SPDownloadGCPCorpSummary(getVAMDataSource(),schemaName);
		retObject = downloadGCPCorpSummaryStoredProc.executeStoredProcedure(appUserID,debugLevel,customerNo, customerType, whereClause,
					sortOrder, cursorId, configSubsOid);


		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadGCPCorpSummary in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadGCPCorpSummary in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadGCPCorpSummary in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadGCPCorpSummary in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

	//download in excel -> SERVICE_GCP_V10
	public Content downloadGCPAccountsBySubscription ( Map params) throws NCASException {
		String schemaName = getSchemaName();
		List eMediaRecordList = new ArrayList();
		Content retObject = null;

		try
		{
		String appUserID = null;
		try {
		appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
		if (appUserID == null) {
		appUserID = "USSLBMG";
		}
		} catch(Exception e) {
		_LOGGER.debug("APP USER ID is null..");
		String[] errMsg = new String[3];
		errMsg[0] = "downloadGCPAccountsBySubscription";
		errMsg[1] = USER_ID_CONFIG_READ_ERROR;
		throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
		}
		String whereClause = "";
		String sortOrder = "";
		String customerNo = "";
		String customerType = "";
		String cursorId = "";
		String configSubsOid = "";
		String serviceId = "";
		if(params!=null){
			sortOrder = (String)params.get("SORT");
			whereClause = (String)params.get("FILTER");
			customerNo = (String)params.get("CUSTNUM");
			customerType = (String)params.get("CUSTTYPE");
			cursorId = (String)params.get("CURSOR");
			configSubsOid = (String) params.get("CONFIGSUBSOID");
			serviceId = (String) params.get("SERVICEID");
			if(whereClause==null) {
				whereClause = "";
			}

		}
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

		SPDownloadGCPAccountsBySubscription downloadGCPAccountsBySubscription = new SPDownloadGCPAccountsBySubscription(getVAMDataSource(),schemaName);
		retObject = downloadGCPAccountsBySubscription.executeStoredProcedure(appUserID,debugLevel, serviceId, whereClause, sortOrder, cursorId,configSubsOid);

		} catch(NCASException ncasException) {
		_LOGGER.debug("downloadGCPAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		_LOGGER.error("downloadGCPAccountsBySubscription in VAM Failed \n"+ncasException.getMessage());
		throw ncasException;
		} catch(Exception vamEx) {
		_LOGGER.debug("downloadGCPAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		_LOGGER.error("downloadGCPAccountsBySubscription in VAM Failed \n"+vamEx.getMessage());
		throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,vamEx);
		}
		return retObject;
}

	//eligible accounts count - SUMMARY_GCP_V10
	public Map<String,Integer> getGCPBillPayerSummaryEligibleAccountsCount(String customerNo, String customerType,String filterBy, String sortBy, String cursorId,Pagination pagination,String configSubsOid)throws NCASException{
		Map countMap = null;
		try {
			countMap = new SPCandidateEligibleAccountsCount(getVAMDataSource(), getSchemaName(),NCASBOSIConstants.SP_GET_GCP_SUMMARY).executeStoredProcedure(getUserId(), getDebugLevel(), customerNo, customerType, filterBy, sortBy, cursorId, pagination, configSubsOid);
		} catch (Exception ex) {
			_LOGGER.debug("getGCPBillPayerSummaryEligibleAccountsCount in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getGCPBillPayerSummaryEligibleAccountsCount in VAM Failed \n"+ex.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,ex);
		}
		return countMap;
	}
	//eligible accounts count - CORP_GCP_V10
	public Map<String,Integer> getGCPCorpSummaryEligibleAccountsCount(String customerNo, String customerType,String filterBy, String sortBy, String cursorId,Pagination pagination,String configSubsOid)throws NCASException{
		Map countMap = null;
		try {
			countMap = new SPCandidateEligibleAccountsCount(getVAMDataSource(), getSchemaName(),NCASBOSIConstants.SP_GET_GCP_CORP_SUMMARY).executeStoredProcedure(getUserId(),getDebugLevel(), customerNo, customerType, filterBy, sortBy, cursorId, pagination, configSubsOid);
		} catch (Exception ex) {
			_LOGGER.debug("getGCPCorpSummaryEligibleAccountsCount in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getGCPCorpSummaryEligibleAccountsCount in VAM Failed \n"+ex.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,ex);
		}
		return countMap;
	}

	//eligible accounts count - SERVICE_GCP_V10
	public Map<String,Integer> getGCPServiceEligibleAccountsCount(String serviceId, String wherePhrase, String sortOrder,String tokenString, Pagination pagination,String configSubsOid)throws NCASException{
		Map countMap = null;
		try {
			countMap = new SPCandidateEligibleAccountsCount(getVAMDataSource(), getSchemaName(),NCASBOSIConstants.SP_GET_GCP_ACCTS_BY_SUBSCRIPTION).executeStoredProcedure(getUserId(),getDebugLevel(),serviceId, wherePhrase, sortOrder, tokenString, pagination,configSubsOid);
		} catch (Exception ex) {
			_LOGGER.debug("getGCPServiceEligibleAccountsCount in VAM Failed \n"+ex.getMessage());
			_LOGGER.error("getGCPServiceEligibleAccountsCount in VAM Failed \n"+ex.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,ex);
		}
		return countMap;
	}

	private String getUserId()throws Exception{
			String userID = null;
			try {
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (userID == null) {
					userID = "USSLBMG";
				}
			}catch(Exception e) {
				_LOGGER.debug("USER ID is null..");
				String[] errMsg = new String[1];
				errMsg[0] = "getUserId";
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR,EMediaProfileDAOImpl.class, e, errMsg);
			}
			return userID;
	}

	private String getDebugLevel(){
		String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
		return debugLevel;
	}
	//SERVICE_SECABS_V10
	public Map<String,Object> getSecabsAcctsByService(Object secabsCandidateApiInput)throws NCASException{
		_LOGGER.info("Entering getSecabsAcctsByService");
		Map returnMap = null;
		try{
			returnMap = new SPGetSecabsAcctsByService(getVAMDataSource(),getSchemaName()).executeStoredProcedure((SecabsCandidateApiInput)secabsCandidateApiInput);
		}catch(Exception secabsException){
			 _LOGGER.error("getSecabsAcctsByService - failed::"+secabsException.getMessage());
			 secabsException.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,secabsException);
		}
		_LOGGER.info("Exiting getSecabsAcctsByService");
		return returnMap;
	}

	//SERVICE_SECABS_V10 - download
	public Map<String,Object> downloadSecabsAcctsByService(Object params)throws NCASException{
		_LOGGER.info("Entering downloadSecabsAcctsByService");
		Map<String,Object> returnMap = new HashMap<String,Object>();
		try{
			Content content = new SPDownloadSecabsAcctsByService(getVAMDataSource(),getSchemaName()).executeStoredProcedure((Map)params);
			returnMap.put("download_content", content);
		}catch(Exception secabsException){
			 _LOGGER.error("downloadSecabsAcctsByService - failed::"+secabsException.getMessage());
			 secabsException.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,secabsException);
		}
		_LOGGER.info("Exiting downloadSecabsAcctsByService");
		return returnMap;
	}


	//SUMMARY_SECABS_V10
	public Map<String,Object> getSecabsAcctsBySummary(Object secabsCandidateApiInput)throws NCASException{
		_LOGGER.info("Entering getSecabsAcctsBySummary");
		Map returnMap = null;
		try{
			returnMap = new SPGetSecabsSummary(getVAMDataSource(),getSchemaName()).executeStoredProc((SecabsCandidateApiInput)secabsCandidateApiInput);
		}catch(Exception secabsException){
			 _LOGGER.error("getSecabsAcctsBySummary - failed::"+secabsException.getMessage());
			 secabsException.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,secabsException);
		}
		_LOGGER.info("Exiting getSecabsAcctsBySummary");
		return returnMap;
	}
	//CORP_SECABS_V10
	public Map<String,Object> getSecabsAcctsByCorpSummary(Object secabsCandidateApiInput)throws NCASException{
		_LOGGER.info("Entering getSecabsAcctsByCorpSummary");
		Map returnMap = null;
		try{
			returnMap = new SPGetSecabsCorpSummary(getVAMDataSource(),getSchemaName()).executeStoredProc((SecabsCandidateApiInput)secabsCandidateApiInput);
		}catch(Exception secabsException){
			 _LOGGER.error("getSecabsAcctsByCorpSummary - failed::"+secabsException.getMessage());
			 secabsException.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,secabsException);
		}
		_LOGGER.info("Exiting getSecabsAcctsByCorpSummary");
		return returnMap;
	}

	//SUMMARY_SECABS_V10 for Download
	public Map<String,Object> downloadSecabsSummary(Object params)throws NCASException{
		_LOGGER.info("Entering downloadSecabsSecabsSummary");
		Map<String,Object> returnMap = new HashMap<String,Object>();
		try{
			Content content = new SPDownloadSecabsSummary(getVAMDataSource(),getSchemaName()).executeStoredProc((Map)params);
			returnMap.put("download_content", content);
		}catch(Exception secabsException){
			 _LOGGER.error("downloadSecabsSummary - failed::"+secabsException.getMessage());
			 secabsException.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,secabsException);
		}
		_LOGGER.info("Exiting downloadSecabsSummary");
		return returnMap;
	}

	//CORP_SECABS_V10 for Download
	public Map<String,Object> downloadSecabsCorpSummary(Object params)throws NCASException{
		_LOGGER.info("Entering downloadSecabsCorpSummary");
		Map<String,Object> returnMap = new HashMap<String,Object>();
		try{
			Content content = new SPDownloadSecabsCorpSummary(getVAMDataSource(),getSchemaName()).executeStoredProc((Map)params);
			returnMap.put("download_content", content);
		}catch(Exception secabsException){
			 _LOGGER.error("downloadSecabsCorpSummary - failed::"+secabsException.getMessage());
			 secabsException.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,secabsException);
		}
		_LOGGER.info("Exiting downloadSecabsCorpSummary");
		return returnMap;
	}


	//VAM API GET_SMP_CONTRACTS
	public Map getSMPContracts(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "EMediaProfileDAOImpl::getSMPContracts()";

		_LOGGER.debug(METHOD_NAME + " ENTER");

		String schemaName = getSchemaName();
		SPGetSMPContracts getSMPContractsStoredProc = new SPGetSMPContracts(getVAMDataSource(), schemaName);
		Map responseMap = null;

		try
		{
			String userID = null;

			try
			{
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");

			    if (userID == null)
			    {
			    	userID = "USSLBMG";
			    }
			}
			catch (Exception e)
			{
				_LOGGER.info(METHOD_NAME + " USER ID not found");

				String[] errMsg = new String[3];
				errMsg[0] = "getSMPContracts";
				errMsg[1] = inputMap.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;

				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			//call the stored procedure
			responseMap = getSMPContractsStoredProc.executeStoredProcedure(userID, debugLevel, inputMap);

			_LOGGER.info(METHOD_NAME + " responseMap=" + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE")).intValue();

			//if excuting SP doesn't return correct result
			if (returnCode > 0)
			{
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "getSMPContracts";
			    errMsg[1] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_GET_SMP_CONTRACTS;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg, returnCode);
			}
		}
		catch(NCASException ncasException)
		{
			_LOGGER.info(METHOD_NAME + " GetSMPContracts failed \n" + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + " GetSMPContracts failed \n" + ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vamEx)
		{
			_LOGGER.info(METHOD_NAME + " GetSMPContracts failed \n" + vamEx.getMessage());
			_LOGGER.error(METHOD_NAME + " GetSMPContracts failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, EMediaProfileDAOImpl.class, vamEx);
		}

		_LOGGER.debug(METHOD_NAME + " EXIT");

		return responseMap;
	}


	//VAM API ADD_DIR_ENTL
	public Map addDirectEntitlement(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "EMediaProfileDAOImpl::addDirectEntitlement()";

		_LOGGER.debug(METHOD_NAME + " ENTER");

		String schemaName = getSchemaName();
		SPAddDirectEntitlement addDirectEntitlementStoredProc = new SPAddDirectEntitlement(getVAMDataSource(), schemaName);
		Map responseMap = null;

		try
		{
			String userID = null;

			try
			{
				userID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");

			    if (userID == null)
			    {
			    	userID = "USSLBMG";
			    }
			}
			catch (Exception e)
			{
				_LOGGER.info(METHOD_NAME + " USER ID not found");

				String[] errMsg = new String[3];
				errMsg[0] = "addDirectEntitlement";
				errMsg[1] = inputMap.toString();
				errMsg[2] = USER_ID_CONFIG_READ_ERROR;

				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}

			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);

			//call the stored procedure
			responseMap = addDirectEntitlementStoredProc.executeStoredProcedure(userID, debugLevel, inputMap);

			_LOGGER.info(METHOD_NAME + " responseMap=" + responseMap);

			int returnCode = ((Integer) responseMap.get("RETURN_CODE")).intValue();

			//if excuting SP doesn't return correct result
			if (returnCode > 0)
			{
				SPErrorInfo spInfo = new SPErrorInfo();
				spInfo.setReturnCode(returnCode);//RETURN_CODE
				spInfo.setReasonCode((String) responseMap.get("REASON_CODE"));
				spInfo.setErrorText((String) responseMap.get("ERROR_TEXT"));
				spInfo.setSQLCode(((Integer) responseMap.get("SP_SQLCODE")).intValue());
				spInfo.setSQLToken((String) responseMap.get("SP_SQLTOKENS"));
				spInfo.setSQLState((String) responseMap.get("SP_SQLSTATE"));

			    String[] errMsg = new String[3];
			    errMsg[0] = "addDirectEntitlement";
			    errMsg[1] = "API_NAME=" + schemaName + "." + NCASBOSIConstants.SP_ADD_DIR_ENTL;
			    errMsg[2] = spInfo.toString();

			    throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg, returnCode);
			}
		}
		catch(NCASException ncasException)
		{
			_LOGGER.info(METHOD_NAME + " AddDirectEntitlement failed \n" + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + " AddDirectEntitlement failed \n" + ncasException.getMessage());
			throw ncasException;
		}
		catch(Exception vamEx)
		{
			_LOGGER.info(METHOD_NAME + " AddDirectEntitlement failed \n" + vamEx.getMessage());
			_LOGGER.error(METHOD_NAME + " AddDirectEntitlement failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, EMediaProfileDAOImpl.class, vamEx);
		}

		_LOGGER.debug(METHOD_NAME + " EXIT");

		return responseMap;
	}

	// create a remit point GENERATE_VBE_REMIT
	public Map generateVbeRemit(Map input) throws NCASException
	{
		String method = "generateVbeRemit";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPGenerateVbeRemit(getVAMDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
	}

	// save a remit point MANAGE_VBE_REMIT
	public Map manageVbeRemit(Map input) throws NCASException
	{
		String method = "manageVbeRemit";
     	Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPManageVbeRemit(getVAMDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

	    return responseMap;
	}


	// get a remit point GET_VBE_REMIT
	public Map getVbeRemit(Map input) throws NCASException
	{
		String method = "getVbeRemit";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPGetVbeRemit(getVAMDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
	}


	// search VBE remit point
	public Map searchVbeRemit(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "EMediaProfileDAOImpl.searchVbeRemit():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "ENTER");
		}

		Map responseMap = null;

		_LOGGER.info(METHOD_NAME + " inputMap=" + inputMap);

		try
		{
			_LOGGER.info(METHOD_NAME + "getVAMDataSource()=" + getVAMDataSource());
			_LOGGER.info(METHOD_NAME + "getSchemaName()=" + getSchemaName());

			String schemaName = getSchemaName();
			SPSearchVbeRemit searchVbeRemitStoredProc = null;

			//determine if download call or not
			boolean downloadVersion = (Boolean) inputMap.get("DOWNLOAD_VERSION");
		    //Determine if Full Download call or not
			String fullDownload=(String)inputMap.get("FULL_DOWNLOAD");

			if(downloadVersion)
			{
				if(fullDownload != null
						&& fullDownload.trim().equals("Y")){
					_LOGGER.info(METHOD_NAME +"Full Download Entering");
				searchVbeRemitStoredProc = new SPSearchVbeRemit(getVAMDataSource(), schemaName, downloadVersion,fullDownload);
					
				}
				else{
				searchVbeRemitStoredProc = new SPSearchVbeRemit(getVAMDataSource(), schemaName, downloadVersion);
				}
			}
			else
			{
				searchVbeRemitStoredProc = new SPSearchVbeRemit(getVAMDataSource(), schemaName);
			}

			responseMap = searchVbeRemitStoredProc.executeStoredProcedure(inputMap, "");
		}
		catch(NCASException ncasException)
		{
			_LOGGER.info(METHOD_NAME + "searchVbeRemit() failed. " + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "searchVbeRemit() failed. " + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception e)
		{
			_LOGGER.info(METHOD_NAME + "searchVbeRemit() failed. " + e.getMessage());
			_LOGGER.error(METHOD_NAME + "searchVbeRemit() failed. " + e.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, EMediaProfileDAOImpl.class, e);
		}

		_LOGGER.info(METHOD_NAME + "responseMap=" + responseMap);

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "EXIT");
		}

		return responseMap;
	}



	// create a report point GENERATE_RPT_PT
	public Map generateVbeReport(Map input) throws NCASException
	{
		String method = "generateVbeReport";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPGenerateVbeReport(getVAMDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
	}

	// save a report point MANAGE_VBE_REMIT
	public Map manageVbeReport(Map input) throws NCASException
	{
		String method = "manageVbeReport";
     	Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPManageVbeReport(getVAMDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

	    return responseMap;
	}


	// get a report point GET_VBE_Report
	public Map getVbeReport(Map input) throws NCASException
	{
		String method = "getVbeReport";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPGetVbeReport(getVAMDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
	}


	// search VBE report point
	public Map searchVbeReport(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "EMediaProfileDAOImpl.searchVbeReport():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "ENTER");
		}

		Map responseMap = null;

		_LOGGER.info(METHOD_NAME + " inputMap=" + inputMap);

		try
		{
			_LOGGER.info(METHOD_NAME + "getVAMDataSource()=" + getVAMDataSource());
			_LOGGER.info(METHOD_NAME + "getSchemaName()=" + getSchemaName());

			String schemaName = getSchemaName();
			SPSearchVbeReport searchVbeReportStoredProc = null;

			//determine if download call or not
			boolean downloadVersion = (Boolean) inputMap.get("DOWNLOAD_VERSION");

			if(downloadVersion)
			{
				searchVbeReportStoredProc = new SPSearchVbeReport(getVAMDataSource(), schemaName, downloadVersion);
			}
			else
			{
				searchVbeReportStoredProc = new SPSearchVbeReport(getVAMDataSource(), schemaName);
			}

			responseMap = searchVbeReportStoredProc.executeStoredProcedure(inputMap, "");
		}
		catch(NCASException ncasException)
		{
			_LOGGER.info(METHOD_NAME + "searchVbeReport() failed. " + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "searchVbeReport() failed. " + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception e)
		{
			_LOGGER.info(METHOD_NAME + "searchVbeReport() failed. " + e.getMessage());
			_LOGGER.error(METHOD_NAME + "searchVbeReport() failed. " + e.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, EMediaProfileDAOImpl.class, e);
		}

		_LOGGER.info(METHOD_NAME + "responseMap=" + responseMap);

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "EXIT");
		}

		return responseMap;
	}

	// get VBE hierarchy
	public Map getVbeHier(Map inputMap) throws NCASException
	{
		final String METHOD_NAME = "EMediaProfileDAOImpl.getVbeHier():: ";

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "ENTER");
		}

		Map responseMap = null;

		_LOGGER.info(METHOD_NAME + " inputMap=" + inputMap);

		try
		{
			_LOGGER.info(METHOD_NAME + "getVAMDataSource()=" + getVAMDataSource());
			_LOGGER.info(METHOD_NAME + "getSchemaName()=" + getSchemaName());

			String schemaName = getSchemaName();
			SPGetVbeHier getVbeHierStoredProc = null;

			//determine if download call or not
			boolean downloadVersion = (Boolean) inputMap.get("DOWNLOAD_VERSION");

			if(downloadVersion)
			{
				getVbeHierStoredProc = new SPGetVbeHier(getVAMDataSource(), schemaName, downloadVersion);
			}
			else
			{
				getVbeHierStoredProc = new SPGetVbeHier(getVAMDataSource(), schemaName);
			}

			responseMap = getVbeHierStoredProc.executeStoredProcedure(inputMap, "");
		}
		catch(NCASException ncasException)
		{
			_LOGGER.info(METHOD_NAME + "getVbeHier() failed. " + ncasException.getMessage());
			_LOGGER.error(METHOD_NAME + "getVbeHier() failed. " + ncasException.getMessage());

			throw ncasException;
		}
		catch(Exception e)
		{
			_LOGGER.info(METHOD_NAME + "getVbeHier() failed. " + e.getMessage());
			_LOGGER.error(METHOD_NAME + "getVbeHier() failed. " + e.getMessage());

			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860, EMediaProfileDAOImpl.class, e);
		}

		_LOGGER.info(METHOD_NAME + "responseMap=" + responseMap);

		if (_LOGGER.isDebugEnabled())
		{
			_LOGGER.debug(METHOD_NAME + "EXIT");
		}

		return responseMap;
	}

	
	/* Calling Onestop WS method ValidateAddress - v915678*/
	public Map invokeOnestopAddressValidationAPI(Map inputMap) throws NCASException {
		String METHOD_NAME="invokeOnestopAddressValidationAPI";
		_LOGGER.info(METHOD_NAME + " Entering");

		double elapsedTime = -1;
		Map<String, Object> respMap = new HashMap<String, Object>();
		Map inMap = (Map) inputMap;

		BillingHandlerInfo info = null;
		RequestHeader hdr = null;
		UnparsedAddress inputAddress = null;
		OutputOption outputOptions = null;
		ValidationResponse validationResp = null;

		hdr = (RequestHeader) inMap.get("REQUEST_HEADER");
		inputAddress = (UnparsedAddress) inMap.get("UNPARSED_ADDRESS");
		String addressType = (String) inMap.get("ADDRESS_TYPE");
		outputOptions = (OutputOption) inMap.get("OUTPUT_OPTION");

//		String endPoint = (String) inMap.get(NCASBOSIConstants.ONESTOP_WS_URL_IDENTIFIER);
//		Config.getProperty("ncasbosi.ncasbosi", NCASBOSIConstants.ONESTOP_WS_URL_IDENTIFIER);
		//String endPoint = "http://ndcmet51.vzbi.com:9083/AddressValidation/services/AddressValidationAPI";
		String endPoint = (String) Config.getProperty("ncasbosi.ncasbosi", NCASBOSIConstants.ONESTOP_WS_URL_IDENTIFIER);

		AddressValidationAPIServiceLocator locator = new AddressValidationAPIServiceLocator();
		locator.setAddressValidationAPIEndpointAddress(endPoint);

		QName portName = new QName("AddressValidationAPI");
		HandlerRegistry registryH = locator.getHandlerRegistry();
		List chain = registryH.getHandlerChain(portName);
		info = new BillingHandlerInfo(BillingSOAPHandler.class, null, null);
		chain.add(info);

		AddressValidationAPI bindStub=null;
		try {
			bindStub = new AddressValidationAPISoapBindingStub();
		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			_LOGGER.info("Inside Axis Fault ");
			throw new NCASException ("1", EMediaProfileDAOImpl.class, e);
		}
		try {
			bindStub = locator.getAddressValidationAPI();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			_LOGGER.info("Inside Service Exception ");
			throw new NCASException ("2", EMediaProfileDAOImpl.class, e);
		}
		long startTime = new Date().getTime();
		try {
			validationResp = bindStub.validateAddress(hdr, inputAddress, addressType, outputOptions);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			_LOGGER.info("Inside Remote Exception ");
			throw new NCASException ("3", EMediaProfileDAOImpl.class, e);
		}
		elapsedTime = ((double) (new Date().getTime() - startTime)) / 1000;

		String returnCode = Integer.toString(validationResp.getReturnCode());
		respMap.put("returnCode", returnCode);
		respMap.put("returnMsg", validationResp.getReturnMsg());
		respMap.put("validationLevel", Integer.toString(validationResp.getValidationLevel()));
		respMap.put("validationPassed", Boolean.toString(validationResp.isValidationPassed()));
		respMap.put("geoCodeLevel", Integer.toString(validationResp.getGeoCodeLevel()));
		if(returnCode.equals("0"))
			respMap.put("validatedAddress", (PostalAddress) validationResp.getValidatedAddress());
		else
			respMap.put("validatedAddress", null);
		if(returnCode.equals("2"))
			respMap.put("countryInfo", null);
		else
			respMap.put("countryInfo", (Country) validationResp.getCountryInfo());

		_LOGGER.info(METHOD_NAME + " Exiting");
		return respMap;
	}
	
	/* Calling mdm nasp validation*/
	public Map mdmLookupNaspId(Map inputMap) throws NCASException {
		String METHOD_NAME="mdmLookupNaspId()";
		_LOGGER.info(METHOD_NAME + " Entering");
		Map respMap = new HashMap();
		
		String naspId = (String)inputMap.get("NASPID");

		//todo add call to web service here
		double elapsedTime = -1;
		long startTime = new Date().getTime();
		BillingVbeHandlerInfo info = null;
		NASPIDLOOKUPREQUEST naspLookUpReqParam = null;
		NASPIDLOOKUPRESPONSE naspLookUpRspParam = null;		
		String endPoint = (String) Config.getProperty("ncasbosi.ncasbosi", NCASBOSIConstants.NASPLOOKUP_WS_URL_IDENTIFIER);
		Nasplookup_ServiceLocator locator = new Nasplookup_ServiceLocator();
		locator.setnasplookupSOAPEndpointAddress(endPoint);

		QName portName = new QName("nasplookupSOAP");
		HandlerRegistry registryH = locator.getHandlerRegistry();
		List chain = registryH.getHandlerChain(portName);
		info = new BillingVbeHandlerInfo(BillingVbeSOAPHandler.class, null, null);
		chain.add(info);		

		Nasplookup_PortType bindStub=null;
		try {
			bindStub = locator.getnasplookupSOAP();
			naspLookUpReqParam = new NASPIDLOOKUPREQUEST(naspId);
			naspLookUpRspParam = bindStub.lookupNaspId(naspLookUpReqParam);
		} catch (Exception e) {
			e.printStackTrace();
			logWebSvcException(naspId, "nasplookupSOAP", info.getSOAP_REQUEST_MESSAGE(), endPoint, info.getSOAP_RESPONSE_MESSAGE());
			throw new NCASException ("VBE-"+METHOD_NAME, EMediaProfileDAOImpl.class, e);
		}
		elapsedTime = ((double) (new Date().getTime() - startTime)) / 1000;
				
		respMap.put("NASPID", naspId);
		respMap.put("NASP_NAME", checkForNull(naspLookUpRspParam.getNASP_NAME()));
		respMap.put("CUSTOMER_SEGMENT", checkForNull(naspLookUpRspParam.getCUSTOMER_SEGMENT()));
		respMap.put("RETURN_CODE", naspLookUpRspParam.getRETURN_CODE());  // 1=valid, 2=not valid
		respMap.put("ERROR_DESC", checkForNull(naspLookUpRspParam.getERROR_DESC()));
		
		return respMap;
		
	}
	
	/* Calling vac nasp validation (this is 'in house' validation for nasp*/
	public Map vacValidateNaspId(Map input) throws NCASException {
		String method = "vacValidateNaspId";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPValidateNASPID(getDataSource()).executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
		
	}

	/* Calling VAM SP to revLoc validation  Added by v191876 */
	public Map vamLookupRevLoc(Map input) throws NCASException {
		String method = "vamValidateRevLoc";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			
			String appUserID = null;
			try {
				appUserID = BOSIConfig.getProperty(USER_ID_CONFIG_PATH, " ");
				if (appUserID == null) {
					appUserID = "USSLBMG";
				}
			} catch(Exception e) {
				_LOGGER.debug("APP USER ID is null..");
				String[] errMsg = new String[3];
				errMsg[0] = "getAFTRequests";
				errMsg[1] = USER_ID_CONFIG_READ_ERROR;
				throw new NCASException(NCASBOSIConstants.USER_CFG_ERROR, EMediaProfileDAOImpl.class, e, errMsg);
			}
			String debugLevel = NCASBOSIConfig.getProperty(NCASBOSIConstants.EMEDIA_DEUBG_LEVEL);
			
			responseMap = new SPValidateRevLoc(getDataSource()).executeStoredProcedure(appUserID, debugLevel, input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
		
	}

	/* Calling mdm revLoc validation*/
	public Map mdmLookupRevLoc(Map inputMap) throws NCASException {
		String METHOD_NAME="mdmLookupRevLoc()";
		_LOGGER.info(METHOD_NAME + " Entering");

		Map respMap = new HashMap();
		
		String revLoc = (String)inputMap.get("REVLOC_CD");

		//todo add call to web service here
		double elapsedTime = -1;
		long startTime = new Date().getTime();
		BillingVbeHandlerInfo info = null;
		REVLOCCDLOOKUPREQUEST revlocLookUpReqParam = null;
		REVLOCCDLOOKUPRESPONSE revlocLookUpRspParam = null;		
		String endPoint = (String) Config.getProperty("ncasbosi.ncasbosi", NCASBOSIConstants.REVLOCLOOKUP_WS_URL_IDENTIFIER);
		Revloccdlookup_ServiceLocator locator = new Revloccdlookup_ServiceLocator();
		locator.setrevloccdlookupSOAPEndpointAddress(endPoint);

		QName portName = new QName("revloccdlookupSOAP");
		HandlerRegistry registryH = locator.getHandlerRegistry();
		List chain = registryH.getHandlerChain(portName);
		info = new BillingVbeHandlerInfo(BillingVbeSOAPHandler.class, null, null);
		chain.add(info);		

		Revloccdlookup_PortType bindStub=null;
		try {
			bindStub = locator.getrevloccdlookupSOAP();
			revlocLookUpReqParam = new REVLOCCDLOOKUPREQUEST(revLoc);
			revlocLookUpRspParam = bindStub.lookupRevlocCd(revlocLookUpReqParam);
		} catch (Exception e) {
			e.printStackTrace();
			logWebSvcException(revLoc, "revloccdlookupSOAP", info.getSOAP_REQUEST_MESSAGE(), endPoint, info.getSOAP_RESPONSE_MESSAGE());
			throw new NCASException ("VBE-"+METHOD_NAME, EMediaProfileDAOImpl.class, e);
		}
		elapsedTime = ((double) (new Date().getTime() - startTime)) / 1000;
		
				
		respMap.put("REVLOC_CD", revLoc);
		respMap.put("REVLOC_DESC", checkForNull(revlocLookUpRspParam.getREVLOC_DESC()));
		respMap.put("RETURN_CODE", revlocLookUpRspParam.getRETURN_CODE());  // 1=valid, 2=not valid
		respMap.put("ERROR_DESC", checkForNull(revlocLookUpRspParam.getERROR_DESC()));

		return respMap;
	}
	
	// get contracted exchange rates
	public Map getGbrContractRates(Map input) throws NCASException
	{
		String method = "getGbrContractRates";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPGetContractRates(getVAMDataSource()).executeStoredProcedure((Object)input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
//		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
	}
	// manage contracted exchange rates
	public Map manageGbrContractRates(Map input) throws NCASException
	{
		String method = "manageGbrContractRates";
		Map responseMap = null;
		_LOGGER.info("Entering "+ method + " input: " + input);
		try{
			responseMap = new SPManageContractRates(getVAMDataSource()).executeStoredProcedure((Object)input);
		}catch(Exception e){
			 _LOGGER.error(method + " - failed::" + e.getMessage());
			 e.printStackTrace();
			 throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,EMediaProfileDAOImpl.class,e);
		}
		_LOGGER.info("Exiting "+ method + "input: " + input + " output: " + responseMap);

		return responseMap;
	}

	private String checkForNull(String pInputParam){
		if(pInputParam == null || pInputParam.trim().length()==0){
			return "";
		}else{
			return pInputParam.trim();
		}
	}		

	private void logWebSvcException(String transId, String action, String soapReqMsg, String endPoint, String soapResMsg) {
		try {
			DAOFactory.getInstance().getVbifImpl().logAuditTable(transId, action, soapReqMsg, endPoint, soapResMsg);
		} catch (Exception exp) {
			_LOGGER.error(action+ " WS Logging failed: " + exp.getMessage());
			_LOGGER.error("Soap Response (Exception/Resp): " + soapResMsg);
			_LOGGER.error("EndPoint :: " + endPoint);
			_LOGGER.error("Soap Request :: " + soapReqMsg);
		}		
	}
}