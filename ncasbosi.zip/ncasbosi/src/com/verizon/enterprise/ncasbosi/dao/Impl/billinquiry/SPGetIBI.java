package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiryNote;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;

public class SPGetIBI extends BaseStoredProcedure {
  private static final Logger _LOGGER = Logger.getLogger(SPGetIBI.class);
  private static List spInOutList;

  public SPGetIBI(DataSource dataSource) {
    super(dataSource, NCASBOSIConstants.SP_GET_INT_BIL_INQ, spInOutList);
  }

  static {
    _LOGGER.info("Static Init");
    spInOutList = new ArrayList();
    spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new IBIDataMapper()});
    spInOutList.add(new Object[]{"RESULT_SET_TWO", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, new CommentsMapper()});
    spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"ENTITLEMENT_REQ", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

    spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
    spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
  }

  public Map executeStoredProcedure(Object paramValues)throws Exception {
    _LOGGER.info("Entering Execute SP in " + getStoredProcedureName());
    List paramValueList = (List)paramValues;

    Map resMap = executeSP(paramValueList, false);
    _LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
    checkVACErrors(resMap);
    resMap = transformData(resMap);
    _LOGGER.info("Exiting Execute SP in " + getStoredProcedureName());
    return resMap;
  }

  private Map transformData(Map map)throws Exception {
    _LOGGER.info("Entering Transform Data ");
    List aList = null;
    BillInquiryNote biNote = null;
    BillInquiry bi = null;
    List biNoteList = null;
    List objList = null;

    if(map != null) {
      objList =	(List)map.get("RESULT_SET_ONE");
      if(objList == null || objList.size() == 0) {
        throw new Exception("ResultSet is either null or has NO Int. Bill Inquiriy");
      } else if(objList.size() > 1) {
        _LOGGER.error("Entering Transform Data ");
        throw new Exception("ResultSet has more than One Int. Bill Inquiriy");
      } else {
        bi = (BillInquiry)objList.get(0);
        if(bi != null) {
          aList = (ArrayList)map.get("RESULT_SET_TWO");
          biNoteList = new ArrayList();

          for(int i=0; i<aList.size(); i++) {
            biNote = (BillInquiryNote)aList.get(i);

            if(bi.getSourcePortal()!=null && bi.getSourcePortal().equalsIgnoreCase("VBCC")) {
              if(biNote != null && biNote.getNoteType().equalsIgnoreCase("CREATE") && (biNote.isPublicNote())) {
                populateActionAndMemo(bi,biNote);
              } else {
                biNoteList.add(biNote);
              }
            } else {
              if(biNote != null && biNote.getNoteType().equalsIgnoreCase("CREATE")) {
                populateActionAndMemo(bi,biNote);
              } else {
                biNoteList.add(biNote);
              }
            }
          }
          bi.setBillInquiryNote(biNoteList);
          map.remove("RESULT_SET_ONE");
          map.put("RESULT_SET_ONE", bi);
          map.remove("RESULT_SET_TWO");
        }
      }
    }
    _LOGGER.info("Exiting Transform Data Comments Mapping Done");
    return map;
  }

  private void populateActionAndMemo(BillInquiry bi,BillInquiryNote biNote) {
    bi.setAction(biNote.getNoteType());
    bi.setInquiryMemo(biNote.getNoteText());
  }

  //overriding the BaseStoredProcedure's checkVACErrors() method
  public void checkVACErrors(Map resMap)throws Exception {
    _LOGGER.info("Entering in method SPGetIBI.checkVACErrors(Map resMap)");
    Object retCodeObj = null;
    Integer retCode = null;
    if(resMap != null) {
      retCodeObj = resMap.get(NCASBOSIConstants.BI_VAC_RETURN_CODE_IDENTIFIER);
      if(retCodeObj != null) {
        retCode = (Integer)retCodeObj;
        if(retCode.intValue() >= NCASBOSIConstants.BI_VAC_ERROR_CODE) {
          String errorMsg = CommonUtil.mapToString(resMap);
          _LOGGER.error("Error encountered in the VAC Response "+errorMsg);
          _LOGGER.debug("Entering method checkVACErrors "+errorMsg);
          String reasonCode = (String)resMap.get(NCASBOSIConstants.BI_VAC_REASON_CODE_IDENTIFIER);
          if(reasonCode!=null && reasonCode.trim().equals(NCASBOSIConstants.BI_NOT_FOUND_ERROR_CODE)) { //bill inquiry not found
            throw new SQLException(NcasConstants.BI_NOT_FOUND);
          } else if(reasonCode!=null && reasonCode.trim().equals(NCASBOSIConstants.BI_USER_NOT_ENTITLED_ERROR_CODE)){ // user not entitled to view BI
            throw new SQLException(NcasConstants.USER_NOT_ENTITLED_BI);
          } else {
            throw new SQLException("VAC BAD Response "+errorMsg);
          }
        } else if (retCode.intValue() == NCASBOSIConstants.BI_VAC_WARNING_CODE) {
          String retWrn =  CommonUtil.mapToString(resMap);//(String)resMap.get(NCASBOSIConstants.BI_VAC_WARNING_TEXT_IDENTIFIER);
          _LOGGER.warn("VAC Warnings Issued "+retWrn);
          _LOGGER.info("VAC Warnings Issued "+retWrn);
          _LOGGER.debug("VAC Warnings Issued "+retWrn);
        } else {
          _LOGGER.info("VAC Response has no errors or warnings");
        }
      }
    } else {
      _LOGGER.info("Map passed to the method SPGetBI.checkVACErrors was null");
    }
    _LOGGER.info("Exiting method SPGetIBI.checkVACErrors");
  }
}
