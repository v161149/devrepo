package com.verizon.enterprise.ncasbosi.dao.Impl.Reprint;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.verizon.enterprise.common.ncas.Reprint.ReprintRequestObject;

import javax.sql.DataSource;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPGetReprint extends BaseStoredProcedure
{
	static private final Logger _LOGGER = Logger.getLogger(SPGetReprint.class);
	//private static List spInOutList;
	private String spName= null;
	
	public SPGetReprint(DataSource dataSource,String schemaName, String spName,List spInOutList)
	{
		super(dataSource, schemaName + "." +spName,spInOutList);
		this.spName = spName;
	}
	
	public Map executeStoredProcedure(Object inputMap)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		
		ReprintRequestObject reprintRequestInput = (ReprintRequestObject)inputMap;
		_LOGGER.info("create Reprint input::"+reprintRequestInput);
		String sblank = " "; 
		String program_mode = " ";
		String acctId = null;
		int billReprtOpt = 0;
		int addressIdentifier =0;
		
	
		List inputList = new ArrayList();
		
		
		
		String AccountId = reprintRequestInput.getAccountnumber();
		
		//acctId = padZeros(AccountId.trim(), 13);
		
		_LOGGER.info(" acctId with Left padded Zeros" + acctId);
		
//		AccountId= acctId.trim();// ACCOUNT_ID
		
		String BanId = reprintRequestInput.getBan();
		//acctId = BanId.trim();
		//acctId = padZeros(BanId.trim(), 13);
		
		_LOGGER.info(" BanId -->" + BanId);
		
//		 BanId= acctId.trim();// BAN
		
		billReprtOpt= reprintRequestInput.getBillReprtOpt();
		_LOGGER.info(" billReprtOpt -->" + billReprtOpt);
		if (billReprtOpt!=NCASBOSIConstants.NULL_INT)
		{
		 billReprtOpt= 0; 
		} 
		String carrierRouteCode=reprintRequestInput.getCarrierRouteCode();
		_LOGGER.info(" carrierRouteCode -->" + carrierRouteCode);
		if (carrierRouteCode == null)
		{
			carrierRouteCode=sblank;
		} 
		String areaName=reprintRequestInput.getAreaName();
		_LOGGER.info(" areaName -->" + areaName);
		if (areaName== null)

		{
			areaName=sblank;
		} 
		String stateCode=reprintRequestInput.getStateCode();
		_LOGGER.info(" stateCode -->" + stateCode);
		if (stateCode== null)

		{
			stateCode=sblank;
		} 
		String delAreaCode=reprintRequestInput.getDelAreaCode();
		_LOGGER.info(" delAreaCode -->" + delAreaCode);
		if (delAreaCode== null)

		{
			delAreaCode=sblank;
		} 
		String delRouteCode=reprintRequestInput.getDelRouteCode();
		_LOGGER.info(" delRuteCode -->" + delRouteCode);
		if (delRouteCode== null)

		{
			delRouteCode=sblank;
		} 
		String delPointCode=reprintRequestInput.getDelPointCode();
		_LOGGER.info(" delPointCode -->" + delPointCode);
		if (delPointCode== null)

		{
			delPointCode=sblank;
		} 
		String delCountryCode=reprintRequestInput.getDelCountryCode();
		_LOGGER.info(" delCountryCode -->" + delCountryCode);
		if (delCountryCode== null)

		{
			delCountryCode=sblank;
		} 
		Date currentDate = new Date(System.currentTimeMillis());
		SimpleDateFormat billDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String postalLabelEndDate = billDateFormat.format(currentDate);
		_LOGGER.info(" postalLabelEndDate -->" + postalLabelEndDate);
		
		 addressIdentifier=reprintRequestInput.getAddressIdentifier();
		 _LOGGER.info(" addressIdentifier -->" + addressIdentifier);
		if (addressIdentifier!=NCASBOSIConstants.NULL_INT)
		{
			addressIdentifier= 0;
		}
		String assignedAddressNum=reprintRequestInput.getAssignedAddressNum();
		 _LOGGER.info(" assignedAddressNum -->" + assignedAddressNum);
		if (assignedAddressNum== null)

		{
			assignedAddressNum=sblank;
		} 
		String assignedStreetTypeCode=reprintRequestInput.getAssignedStreetTypeCode();
		 _LOGGER.info(" assignedStreetTypeCode -->" + assignedStreetTypeCode);
		if (assignedStreetTypeCode== null)

		{
			assignedStreetTypeCode=sblank;
		} 
		String postalLabelAttnText=reprintRequestInput.getPostalLabelAttnText();
		 _LOGGER.info(" postalLabelAttnText -->" + postalLabelAttnText);
		if (postalLabelAttnText== null)

		{
			postalLabelAttnText=sblank;
		} 
		inputList.add("ESGDBH7");//APP_USER_ID
		inputList.add("1");//Internal
		if(spName.equals(NCASBOSIConstants.SP_EXA_NSB_REP_REQ)){
		inputList.add(AccountId);//ACCOUNT_ID
       // inputList.add(manServiceId);//MAN
    	}else{
		inputList.add(AccountId);
		inputList.add(BanId);
    	}
		inputList.add(reprintRequestInput.getBillDates());
		inputList.add(" ");//PROGRAM_MODE
		inputList.add(billReprtOpt);//BILL_REPRT_OPT
		inputList.add(reprintRequestInput.getPLIdentifier());//PSTLL_F
		inputList.add(carrierRouteCode);//PSTLL_CARR_RT_C
		inputList.add(areaName);//PSTLL_PAA_N
		inputList.add(stateCode);//PSTLL_STTE_C
		inputList.add(delAreaCode);//PSTLL_DAA_C
		inputList.add(delRouteCode);//PSTLL_DRTE_C
		inputList.add(delPointCode);//PSTLL_DPNT_C
		inputList.add(delCountryCode);//PSTLL_CTRY_N
		inputList.add(postalLabelEndDate);//PSTLL_ED
		inputList.add(addressIdentifier);//ADR_F
		inputList.add(assignedAddressNum);//ADR_B
		inputList.add(assignedStreetTypeCode);//ADR_ST_YC
		inputList.add(postalLabelAttnText);//PSTLL_ATTN_X
		inputList.add(" ");//PSTLL_LN_X_1 
		inputList.add(" ");//PSTLL_LN_YC_1
		inputList.add(" ");//PSTLL_LN_X_2
		inputList.add(" ");//PSTLL_LN_YC_2
		inputList.add(" ");//PSTLL_LN_X_3
		inputList.add(" ");//PSTLL_LN_YC_3
		inputList.add(" ");//PSTLL_LN_X_4
		inputList.add(" ");//PSTLL_LN_YC_4 
		inputList.add(" ");//PSTLL_LN_X_5
		inputList.add(" ");//PSTLL_LN_YC_5
		_LOGGER.info("inputList --> "+inputList);
		Map resMap = executeSP(inputList, false);
		_LOGGER.info("Printing the response Map::"+resMap);
		
		return resMap;
	}
		public static String padZeros(String inpData, int length)
	
		{
	
			StringBuffer sb = new StringBuffer();
	
			int j = (length - (inpData.length()));
	
			for (int i = 0; i < j; i++)
	
			{
	
				sb.append("0");
	
			}
	
			sb.append(inpData);
	
			return sb.toString();
	
		}
		private String getV (String input)
		{
			if (input != null && !"".equals(input))
			{
				return input;
			}
			else
			{
				return "";
			}
		}
		
}
