package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.common.CommonUtil; // contains formatting from double to String method

import com.verizon.enterprise.common.util.commonUtil; //contains Decimal Place formatting Method


public class SPGetCalculationDetails extends BaseStoredProcedure {
	
	private static final Logger _LOGGER = Logger.getLogger(SPGetCalculationDetails.class);
	private static List spInOutList;
	 
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
	     spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetCalculationDetailsMapper()});
		 
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_FIELD",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_POSITION",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NUM_ROWS",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CLM_STATUS",  getSqlDataType(Types.INTEGER),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS_DESC",  getSqlDataType(Types.VARCHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUB_STATUS",  getSqlDataType(Types.INTEGER),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUBSTATUS_DESC",  getSqlDataType(Types.VARCHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"TOTAL_ROWS",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"BATCH_ID",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_OVERALL_CAT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CALC_TYPE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CALC_TYPE_DESC",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CALC_SUB_TYPE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CALC_SUB_TYPE_DESC",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SEGMENT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"NET_CALC_DTL_AMT",  getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CREDIT_DEBIT",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"AUTO_TOT_LPC",  getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"AUTO_PORT_ADJ_CR",  getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"AUTO_PORT_ADJ_DR",  getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"AUTO_PORT_ADJ_INT",  getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	 }
	
	public SPGetCalculationDetails(DataSource dataSource){
		super(dataSource, getVACSchemaName() + "." + NCASBOSIConstants.SP_GET_CALC_DETAIL, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		String claimNumber = (String)inputMap.get("claimNumber");
		Pagination myPag = (Pagination)inputMap.get("pagination");
		String batchId = (String)inputMap.get("batchID");
		_LOGGER.info("claimNumber::"+claimNumber);
		_LOGGER.info("input pagination::"+myPag);
		_LOGGER.info("batch Id::"+batchId);
		
		if (myPag == null){
			throw new Exception("SPGetCalculationDetails: Pagination obj is null");
		}

		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add(claimNumber);  //ESG_CLAIM_NUMBER
		callList.add(myPag.getSortField()); //SORT_FIELD
		callList.add(myPag.getSortDirection()); //SORT_ORDER
		callList.add(new Integer(myPag.getLineOffset()));  // START_POSITION
		callList.add(new Integer(myPag.getPageSize()));    // NUM_ROWS
		callList.add((batchId!=null && batchId.trim().length()>0)?new BigDecimal(batchId.trim()):null);//BATCH_ID

		/* execute sp */
		Map resMap = executeSP(callList, false);
		String netAmt = null;
		try {
			netAmt = CommonUtil.formatDouble((Double)resMap.get("NET_CALC_DTL_AMT"));
		} catch (Exception e) {
			netAmt = null;
		}
		String formattedNetAmt = commonUtil.formatNumber(netAmt,"#,##0.00 ; -#,##0.00");
		_LOGGER.info("Formatted Net Amount"+formattedNetAmt);
		resMap.put("NET_CALC_DTL_AMT",formattedNetAmt);

		String autoTotalLpc = null;
		try {
			autoTotalLpc = CommonUtil.formatDouble((Double)resMap.get("AUTO_TOT_LPC"));
		} catch (Exception e) {
			autoTotalLpc = null;
		}
		String formattedAutoTotalLpc = commonUtil.formatNumber(autoTotalLpc,"#,##0.00 ; -#,##0.00");
		_LOGGER.info("Formatted AUTO_TOT_LPC "+formattedAutoTotalLpc);
		resMap.put("AUTO_TOT_LPC",formattedAutoTotalLpc);
		
		String autoPortAdjCr = null;
		try {
			autoPortAdjCr = CommonUtil.formatDouble((Double)resMap.get("AUTO_PORT_ADJ_CR"));
		} catch (Exception e) {
			autoPortAdjCr = null;
		}
		String formattedAutoPortAdjCr = commonUtil.formatNumber(autoPortAdjCr,"#,##0.00 ; -#,##0.00");
		_LOGGER.info("Formatted AUTO_PORT_ADJ_CR"+formattedAutoPortAdjCr);
		resMap.put("AUTO_PORT_ADJ_CR",formattedAutoPortAdjCr);
		
		String autoPortAdjDr = null;
		try {
			autoPortAdjDr = CommonUtil.formatDouble((Double)resMap.get("AUTO_PORT_ADJ_DR"));
		} catch (Exception e) {
			autoPortAdjDr = null;
		}
		String formattedAutoPortAdjDr = commonUtil.formatNumber(autoPortAdjDr,"#,##0.00 ; -#,##0.00");
		_LOGGER.info("Formatted AUTO_PORT_ADJ_DR"+formattedAutoPortAdjDr);
		resMap.put("AUTO_PORT_ADJ_DR",formattedAutoPortAdjDr);
		
		String autoPortAdjInt = null;
		try {
			autoPortAdjInt = CommonUtil.formatDouble((Double)resMap.get("AUTO_PORT_ADJ_INT"));
		} catch (Exception e) {
			autoPortAdjInt = null;
		}
		String formattedAutoPortAdjInt = commonUtil.formatNumber(autoPortAdjInt,"#,##0.00 ; -#,##0.00");
		_LOGGER.info("Formatted AUTO_PORT_ADJ_INT"+formattedAutoPortAdjInt);
		resMap.put("AUTO_PORT_ADJ_INT",formattedAutoPortAdjInt);	
		
		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
