package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import org.springframework.jdbc.core.SqlParameter;

import org.springframework.jdbc.core.RowCallbackHandler;

import org.springframework.jdbc.object.SqlUpdate;

import org.apache.log4j.Logger;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;

import java.util.List;

import java.util.Map;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

import com.verizon.enterprise.common.ncas.exception.NCASException;

import com.verizon.enterprise.common.ncasbosi.beans.EMediaEdit;

import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaEditInterface;

public class EMediaEditDAOImpl
    extends NCASSpringJDBCBase implements

    EMediaEditInterface, NCASBOSIConstants {

  private static final Logger _LOGGER = Logger.getLogger(EMediaEditDAOImpl.class);
  private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
  private SqlUpdate insertEMediaEditSqlUpdate = null;

  private SqlUpdate updateEMediaEditSqlUpdate = null;

  private SqlUpdate deleteEMediaEditSqlUpdate = null;

  /* INSERT, UPDATE, DELETE, SELECT for EMEDIA_EDIT Table  -  START */

  /**
   * @param eMediaEdit EMediaEdit
   * @return boolean
   * @throws Exception
   */    public Map doEMediaEdit(String operation,EMediaEdit eMediaEdit) throws NCASException {	  Map returnMap;	  if(operation.equalsIgnoreCase("I"))		  returnMap = insertEMediaEdit(eMediaEdit);	  else if(operation.equalsIgnoreCase("U"))		  returnMap = updateEMediaEdit(eMediaEdit);	  else if(operation.equalsIgnoreCase("D"))		  returnMap = deleteEMediaEdit(eMediaEdit);	  else if(operation.equalsIgnoreCase("S"))		  returnMap = selectEMediaEdit(eMediaEdit);	  else returnMap = selectALL_EMediaEdit();	  	  	  	  return returnMap;  }    
  public Map insertEMediaEdit(EMediaEdit eMediaEdit) throws NCASException {
    boolean status = false;
    String srcSys = eMediaEdit.getSrcSys();
    String dataOptions = CommonUtil.getCSVStringFromList(eMediaEdit.getDataOptions());
    String bpOverride = eMediaEdit.getBpOverride();
    String convSrc = eMediaEdit.getConvSrc();
    String billMgr = eMediaEdit.getBillMgr();
    String edi = eMediaEdit.getEdi();
    String directData = eMediaEdit.getDirectData();
    String pfb = eMediaEdit.getPfb();
    Map responseMap = new HashMap();
 //   String INSERT_EMEDIA_EDIT_LINK = "INSERT INTO " + getSchemaName() + ".EMEDIA_EDIT(SRC_SYSTEM,DATA_OPTIONS,BP_OVERRIDE,CONV_SRC,BILLMGR,EDI,DIRECTDATA,PFB) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";    String INSERT_EMEDIA_EDIT_LINK = "INSERT INTO " + getSchemaName() + ".EMEDIA_EDIT(SRC_SYSTEM,ISA05,ISA06,GS02,DATA_OPTIONS,BP_OVERRIDE,CONV_SRC,BILLMGR,EDI,DIRECTDATA,PFB,PFB_CONTRACT) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_EMEDIA_EDIT_LINK);
    try {
      if (insertEMediaEditSqlUpdate == null) {
        insertEMediaEditSqlUpdate = new SqlUpdate(jdbcTemplate.
                                                  getDataSource(),
                                                  INSERT_EMEDIA_EDIT_LINK);
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("SRC_SYSTEM", Types.VARCHAR));        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("ISA05", Types.CHAR));        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("ISA06", Types.CHAR));        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("GS02", Types.CHAR));        
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("DATA_OPTIONS", Types.VARCHAR));
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("BP_OVERRIDE", Types.CHAR));
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("CONV_SRC", Types.CHAR));
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("BILLMGR", Types.CHAR));
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("EDI", Types.CHAR));
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("DIRECTDATA", Types.CHAR));
        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("PFB", Types.CHAR));        insertEMediaEditSqlUpdate.declareParameter(new SqlParameter("PFB_CONTRACT", Types.CHAR));
        insertEMediaEditSqlUpdate.compile();
      }
      Object[] parameterValues = new Object[] {
          srcSys, "","","",dataOptions, bpOverride, convSrc, billMgr, edi, directData, pfb,""};
      int insCount = insertEMediaEditSqlUpdate.update(parameterValues);
      if (insCount > 0) {
        _LOGGER.info(
            "Insert EMedia Edit Response logged successfully \n Number of Records inserted - " +
            insCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertEMediaEditSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("insertEMediaEditSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.
                              DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertEMediaEdit" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   * @param sysSrc String
   * @return boolean
   * @throws Exception
   */
  public Map deleteEMediaEdit(EMediaEdit eMediaEdit) throws NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String srcSys = eMediaEdit.getSrcSys();
    String DELETE_EMEDIA_EDIT = "DELETE FROM " + getSchemaName() +
        ".EMEDIA_EDIT WHERE SRC_SYSTEM = ?";
    _LOGGER.info("Delete SQL: " + DELETE_EMEDIA_EDIT);
    try {
      if (deleteEMediaEditSqlUpdate == null) {
        deleteEMediaEditSqlUpdate = new SqlUpdate(jdbcTemplate.
                                                  getDataSource(),
                                                  DELETE_EMEDIA_EDIT);
        deleteEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "SRC_SYSTEM", Types.VARCHAR));
        deleteEMediaEditSqlUpdate.compile();
      }
      Object[] parameterValues = new Object[] {
          srcSys};
      int deleteCount = deleteEMediaEditSqlUpdate.update(
          parameterValues);
      if (deleteCount > 0) {
        _LOGGER.info(
            "Delete EMedia Edit logged successfully \n Number of Records deleted - " +
            deleteCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("deleteEMediaEditSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("deleteEMediaEditSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.
                              DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting deleteEMediaEdit");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   * @param eMediaEdit EMediaEdit
   * @return boolean
   * @throws Exception
   */
  public Map updateEMediaEdit(EMediaEdit eMediaEdit) throws NCASException {
    boolean status = false;
    String srcSys = eMediaEdit.getSrcSys();
    String dataOptions = CommonUtil.getCSVStringFromList(eMediaEdit.getDataOptions());
    String bpOverride = eMediaEdit.getBpOverride();
    String convSrc = eMediaEdit.getConvSrc();
    String billMgr = eMediaEdit.getBillMgr();
    String edi = eMediaEdit.getEdi();
    String directData = eMediaEdit.getDirectData();
    String pfb = eMediaEdit.getPfb();
    Map responseMap = new HashMap();
    String UPDATE_EMEDIA_EDIT_LINK = "UPDATE " + getSchemaName() + ".EMEDIA_EDIT SET DATA_OPTIONS = ?,BP_OVERRIDE = ?,CONV_SRC = ?,BILLMGR = ?,EDI = ?,DIRECTDATA = ?,PFB = ? WHERE SRC_SYSTEM = ?";
    _LOGGER.info("Update SQL: " + UPDATE_EMEDIA_EDIT_LINK);
    try {
      if (updateEMediaEditSqlUpdate == null) {
        updateEMediaEditSqlUpdate = new SqlUpdate(jdbcTemplate.
                                                  getDataSource(),
                                                  UPDATE_EMEDIA_EDIT_LINK);
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "DATA_OPTIONS", Types.VARCHAR));
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "BP_OVERRIDE", Types.CHAR));
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "CONV_SRC", Types.CHAR));
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "BILLMGR", Types.CHAR));
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "EDI", Types.CHAR));
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter(
            "DIRECTDATA", Types.CHAR));
        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter("PFB", Types.CHAR));        updateEMediaEditSqlUpdate.declareParameter(new SqlParameter("SRC_SYSTEM", Types.VARCHAR));
        updateEMediaEditSqlUpdate.compile();
      }
      Object[] parameterValues = new Object[] {dataOptions, bpOverride, convSrc,billMgr, edi, directData, pfb,srcSys};
      int updateCount = updateEMediaEditSqlUpdate.update(parameterValues);
      if (updateCount > 0) {
        _LOGGER.info(
            "Update EMediaEdit Response logged successfully \n Number of Records updated - " +
            updateCount);
        status = true;
      }
      else {
        Boolean satusObj = (Boolean) insertEMediaEdit(
            eMediaEdit).get("status");
        status = satusObj.booleanValue();
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("updateEMediaEditSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("updateEMediaEditSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.
                              DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting updateEMediaEdit" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param eMediaEdit EMediaEdit
   * @return List
   * @throws NCASException
   */
  public Map selectEMediaEdit(EMediaEdit eMediaEdit) throws NCASException {
    final Map responseMap = new HashMap(); 
    String srcSys = eMediaEdit.getSrcSys();
    String SELECT_EMEDIA_EDIT = "SELECT * FROM " + getSchemaName() +
        ".EMEDIA_EDIT WHERE SRC_SYSTEM = '" + srcSys + "'";
    _LOGGER.info("Select SQL: " + SELECT_EMEDIA_EDIT);
    try {
      jdbcTemplate.query(SELECT_EMEDIA_EDIT, new RowCallbackHandler() {
        public void processRow(ResultSet rs) throws SQLException {
          String key = rs.getString("SRC_SYSTEM");          List dataOptions = CommonUtil.getListFromCSVString(rs.getString("DATA_OPTIONS"));          String bpOverride = rs.getString("BP_OVERRIDE");          String convSrc = rs.getString("CONV_SRC");          String billMgr = rs.getString("BILLMGR");          String edi = rs.getString("EDI");          String directData = rs.getString("DIRECTDATA");          String pfb = rs.getString("PFB");          responseMap.put(key, new EMediaEdit(key, dataOptions, bpOverride, convSrc, billMgr, edi, directData, pfb));
        }
      });
    }
    catch (Exception vamEx) {
      _LOGGER.debug("selectALL_EMediaEdit in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("selectALL_EMediaEdit in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.
                              DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.debug("responseMap" + responseMap);
    return responseMap;
  }

  /**
   *
   * @return List
   * @throws NCASException
   */
  public Map selectALL_EMediaEdit() throws NCASException {
	final Map responseMap = new HashMap(); 
    String SELECT_EMEDIA_EDIT = "SELECT * FROM " + getSchemaName() +
        ".EMEDIA_EDIT";
    _LOGGER.info("Select SQL: " + SELECT_EMEDIA_EDIT);
    try {
      jdbcTemplate.query(SELECT_EMEDIA_EDIT, new RowCallbackHandler() {
        public void processRow(ResultSet rs) throws SQLException {
            String key = rs.getString("SRC_SYSTEM");            List dataOptions = CommonUtil.getListFromCSVString(rs.getString("DATA_OPTIONS"));            String bpOverride = rs.getString("BP_OVERRIDE");            String convSrc = rs.getString("CONV_SRC");            String billMgr = rs.getString("BILLMGR");            String edi = rs.getString("EDI");            String directData = rs.getString("DIRECTDATA");            String pfb = rs.getString("PFB");            responseMap.put(key, new EMediaEdit(key, dataOptions, bpOverride, convSrc, billMgr, edi, directData, pfb));
        }
      });
    }
    catch (Exception vamEx) {
      _LOGGER.debug("selectALL_EMediaEdit in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("selectALL_EMediaEdit in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.
                              DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.debug("responseMap" + responseMap);
    return responseMap;
  }

  /* INSERT, UPDATE, DELETE, SELECT for EMEDIA_EDIT Table  -  END */

  /**
   * @return String
   */
  private String getSchemaName() {
    String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
    //String schemaName = "BMGVZS";
    _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
    return schemaName;
  }
}
