package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetRepClaimList extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPGetRepClaimList.class);
	
	private static List spInOutList;
	
	private static GetRepClaimListRowMapperImpl rowMapper = null;
	
	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new GetRepClaimListRowMapperImpl();
		 spInOutList.add(new Object[]{"claims",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"USER_VZ_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetRepClaimList(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_REP_CLAIM_LIST, spInOutList);	
	}

	public Map executeStoredProcedure(String vzid)throws Exception	{
		List paramValueList = new ArrayList();
		paramValueList.add(vzid);//USER_VZ_ID
		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
