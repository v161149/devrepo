package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.autocredit.CreateClaimInput;

/*
 * Author:Ram/v992473
 */

public class SPCreateClaim extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPCreateClaim.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"TICKET_INFO", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new CreateClaimResultSetMapper()});
		 spInOutList.add(new Object[]{"ORIGINATOR_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIBER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIPTION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BACKEND_SYSTEM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATING_SYS_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ENTITY_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_MAIN_BAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLM_MAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUB_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_STATUS_DESC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_SUBSTATUS_DESC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_ENTRY_DATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"CLM_OVERALL_CAT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CALC_SUB_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 //added 06/09 PVB - SR number from OV to VAC on Create
		 spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLAIM_TYPE_CD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CLAIM_TYPE_DESC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPCreateClaim(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_CREATE_VZB_CLAIM, spInOutList);
	}

	public Map executeStoredProcedure(Object pCreateClaimInput)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		CreateClaimInput createClaimInput = (CreateClaimInput)pCreateClaimInput;
		_LOGGER.info("create claim input::"+createClaimInput);
		List inputList = new ArrayList();
		inputList.add(createClaimInput.getOriginatorLoginId());//ORIGINATOR_LOGINID
		inputList.add(createClaimInput.getOriginatorString());//ORIGINATOR_STRING
		inputList.add(createClaimInput.getCustomerName());//CUST_NAME
		inputList.add(createClaimInput.getSubscriberOid());//SUBSCRIBER_OID
		inputList.add(createClaimInput.getSubscriptionOid());//SUBSCRIPTION_OID
		inputList.add(createClaimInput.getBackendSystem());//BACKEND_SYSTEM
		inputList.add(createClaimInput.getOriginatingSystemId());//ORIGINATING_SYS_ID
		inputList.add(createClaimInput.getEntityCode());//ENTITY_CODE
		inputList.add(createClaimInput.getClaimMainBan());//CLM_MAIN_BAN
		inputList.add(createClaimInput.getClaimMan());//CLM_MAN
		inputList.add(createClaimInput.getOverallCategory());//CLM_OVERALL_CAT
		inputList.add(createClaimInput.getCreditType());//CALC_TYPE
		inputList.add(createClaimInput.getSubType());//CALC_SUB_TYPE
		inputList.add(createClaimInput.getServiceRequestNumber());//Service Request #
		inputList.add(createClaimInput.getClaimType());//CLAIM_TYPE_CD
		inputList.add(createClaimInput.getClaimTypeDesc());//CLAIM_TYPE_DESC
		Map resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		_LOGGER.info("Printing the response Map::"+resMap);
		
		return resMap;
	}
}
