package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.GBREMediaProfile;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class SearchGBRProfileRowMapperImpl implements RowMapper
{
	static private final Logger logger = Logger.getLogger(SearchGBRProfileRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "SearchGBRProfileRowMapperImpl::mapRow()";

		logger.debug(METHOD_NAME + " ENTER");
		logger.info(METHOD_NAME + " rowNumber=" + rowNum);

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		GBREMediaProfile profile = null;

		try
		{
			profile = new GBREMediaProfile();

			String configSubscriptionOid = (String) rs.getBigDecimal("CONFIG_SUBS_OID").toString();
			String configId = rs.getString("CONFIG_ID");
			String configName = rs.getString("CONFIG_NAME");
			String serviceType = rs.getString("SERVICE_TYPE");
			String profStatus = rs.getString("PROF_STATUS");
			String companyName = rs.getString("COMPANY_NAME");
			String startDate = rs.getString("START_DATE");
			String endDate = rs.getString("END_DATE");
			String createdDate = rs.getString("DATE_CREATED");
			String profileComplete = rs.getString("PROFILE_COMPLETE");
			String billPeriod = rs.getString("BP_DAY");
			String accountLevelIndicator = rs.getString("ACCT_LVL_INDR");
			String languageCode = rs.getString("LANGUAGE_CODE");
			String currencyCode = rs.getString("CURRENCY_CODE");
			String otherContactInfo1 = rs.getString("OTH_CONTACT_INFO_1");
			String otherContactInfo2 = rs.getString("OTH_CONTACT_INFO_2");
			String exchangeRate = rs.getString("EXCHANGE_RATE");
			String paymentDueInterval = rs.getString("PAYMENT_DUE_INT");
			String creatorUserId = rs.getString("CREATE_USR_ID");
			String creatorUserName = rs.getString("CREATE_USR_NAME");
			String smpContractId = rs.getString("SMP_CONTRACT_ID");
			String smpContractOid = (String) rs.getBigDecimal("SB_CONTRACT_OID").toString();

			//Pretty print the DB Values - GBR - as per Paul request.
			List valuesList = new ArrayList();
			valuesList.add("CONFIG_SUBS_OID=" + configSubscriptionOid);
			valuesList.add("CONFIG_ID=" + configId);
			valuesList.add("CONFIG_NAME=" + configName);
			valuesList.add("SERVICE_TYPE=" + serviceType);
			valuesList.add("PROF_STATUS=" + profStatus);
			valuesList.add("COMPANY_NAME=" + companyName);
			valuesList.add("START_DATE=" + startDate);
			valuesList.add("END_DATE=" + endDate);
			valuesList.add("DATE_CREATED=" + createdDate);
			valuesList.add("PROFILE_COMPLETE=" + profileComplete);
			valuesList.add("BP_DAY=" + billPeriod);
			valuesList.add("ACCT_LVL_INDR=" + accountLevelIndicator);
			valuesList.add("LANGUAGE_CODE=" + languageCode);
			valuesList.add("CURRENCY_CODE=" + currencyCode);
			valuesList.add("OTH_CONTACT_INFO_1=" + otherContactInfo1);
			valuesList.add("OTH_CONTACT_INFO_2=" + otherContactInfo2);
			valuesList.add("EXCHANGE_RATE=" + exchangeRate);
			valuesList.add("PAYMENT_DUE_INT=" + paymentDueInterval);
			valuesList.add("CREATOR_ID=" + creatorUserId);
			valuesList.add("CREATOR_NAME=" + creatorUserName);
			valuesList.add("SMP_CONTRACT_ID=" + smpContractId);
			valuesList.add("SB_CONTRACT_OID=" + smpContractOid);

			CommonUtil.prettyPrintValues(valuesList);

			profile.setConfigSubscriptionOid(Double.parseDouble(configSubscriptionOid));
			if (CommonUtil.isNotNull(configId)) {
				profile.setConfigID(configId.trim());
			}
			if (CommonUtil.isNotNull(configName)) {
				profile.setConfigName(configName.trim());
			}
			if (CommonUtil.isNotNull(serviceType)) {
				profile.setServiceType(serviceType.trim());
			}
			if (CommonUtil.isNotNull(profStatus)) {
				profile.setProfileStatus(profStatus.trim());
			}
			if (CommonUtil.isNotNull(companyName)) {
				profile.setCustCpnyName(companyName.trim());
			}

			profile.setStartDate(CommonUtil.getDateFromString(startDate));
			profile.setEndDate(CommonUtil.getDateFromString(endDate));
			profile.setDtCreated(CommonUtil.getDateFromString(createdDate));

			if (CommonUtil.isNotNull(profileComplete)) {
				profile.setProfComplete(profileComplete.trim());// PROFILE_COMPLETE
			}
			if (CommonUtil.isNotNull(billPeriod)) {
				profile.setBillPeriod(billPeriod.trim());// BP_DAY
			}
			if (CommonUtil.isNotNull(accountLevelIndicator)) {
				profile.setAccountLevelIndicator(accountLevelIndicator.trim());
			}
			if (CommonUtil.isNotNull(languageCode)) {
				profile.setLanguageCode(languageCode.trim());
			}
			if (CommonUtil.isNotNull(currencyCode)) {
				profile.setCurrencyCode(currencyCode.trim());
			}
			if (CommonUtil.isNotNull(otherContactInfo1)) {
				profile.setOtherContactInfo1(otherContactInfo1.trim());
			}
			if (CommonUtil.isNotNull(otherContactInfo2)) {
				profile.setOtherContactInfo2(otherContactInfo2.trim());
			}
			if (CommonUtil.isNotNull(exchangeRate)) {
				profile.setExchangeRate(exchangeRate.trim());
			}
			if (CommonUtil.isNotNull(paymentDueInterval)) {
				profile.setPaymentDueInterval(Integer.parseInt(paymentDueInterval.trim()));
			}
			if (CommonUtil.isNotNull(creatorUserId)) {
				profile.setCreatorUserId(creatorUserId.trim());
			}
			if (CommonUtil.isNotNull(creatorUserName)) {
				profile.setCreatorUserName(creatorUserName.trim());
			}
			if (CommonUtil.isNotNull(smpContractId)) {
				profile.setSmpContractId(smpContractId.trim());
			}
			if (CommonUtil.isNotNull(smpContractOid)) {
				profile.setSmpContractOid(smpContractOid.trim());
			}
		}
		catch (NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.info(METHOD_NAME + " Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.info(METHOD_NAME + " Exception occured while parsing the resultset \n"
					+ e.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n"
					+ e.getMessage());
		}

		logger.debug(METHOD_NAME + " profile=" + profile);
		logger.debug(METHOD_NAME + " EXIT");

		return profile;
	}
}
