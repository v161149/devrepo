package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.GetAdjustmentsMapper;
import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;

public class SPGetClientViewPaperInvList extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetClientViewPaperInvList.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();

	     spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetClientViewPaperInvListMapper()});

		 spInOutList.add(new Object[]{"USERID",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQUESTED_TS",  getSqlDataType(Types.TIMESTAMP),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"OSID",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ABAN",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_DATE",getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	}

	public SPGetClientViewPaperInvList(DataSource dataSource){
		super(dataSource, getVGWSchemaName() + "." + "VGWD704", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map requestMap = (HashMap)input;
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");

		String debugLevel = "0";
//		if (_LOGGER.isDebugEnabled()) debugLevel = "1";

		Calendar cal = new GregorianCalendar();  // get current date time
		Timestamp ts = new Timestamp(cal.getTimeInMillis()); //save current date time as time stamp


		List callList = new ArrayList();
		callList.add(hiDO.getUserId()); //USERID
		callList.add(debugLevel);    // DEBUG_LEVEL
		callList.add(ts);            //REQUESTED_TS
		callList.add(hiDO.getMan()); //MAN
		callList.add(hiDO.getBan()); //BAN
		callList.add(hiDO.getOsid()); //OSID
		callList.add(padWithZeros(hiDO.getAban())); //ABAN
		callList.add(hiDO.getBillDate()); //BILL_DATE

		Map responseMap = executeSP(callList, false);

		// if archive replys bill not found then do not throw exception
		// REASON_CODE=D704#006 RETURN_CODE=8 ERROR_TEXT=BILL NOT FOUND
		String reasonCode = (String)responseMap.get("REASON_CODE");
		if (reasonCode == null) reasonCode = "";
		if (!reasonCode.equals("D704#006"))
		{
			_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
			checkErrors(responseMap, VGW);
		}

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
	}

	private String padWithZeros(String in)
	{
		if (in == null) return null;

		in = in.trim();

		if (in.length() >= 12) return in;

		while (in.length() < 12)
		{
			in = "0" + in;
		}
		return in;
	}

}
