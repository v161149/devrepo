package com.verizon.enterprise.ncasbosi.dao.Impl.Reprint;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;


import com.verizon.enterprise.ncasbosi.dao.Interface.Reprint.ReprintRequestInterface;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.common.ncas.Reprint.ReprintRequestObject;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import org.springframework.jdbc.core.JdbcTemplate;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import javax.sql.DataSource;
import java.util.Map;
import java.sql.Types;



public class ReprintRequestDAOImpl extends NCASSpringJDBCBase implements 
ReprintRequestInterface ,NCASBOSIConstants {
	static private final Logger _LOGGER = Logger
	.getLogger(ReprintRequestDAOImpl.class);
	private JdbcTemplate expJdbcTemplate;// jdbctemplate created for VAM
	private static final String SCHEMA_NAME = "verizon.ebosi.bill.reprint.schema";
	private static final String SCHEMA_NAME_VSSI = "verizon.ebosi.bill.vgw.schema";
	 private String spName = null;
	 private static ReprintRequestDAOImpl reprint = new ReprintRequestDAOImpl();
	// dataSource
	private String getSchemaName(int osid) {
		String schemaName = null;
		if(osid==11){
			schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		}
		else
			schemaName = BOSIConfig.getProperty(SCHEMA_NAME_VSSI, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}
	public void setDataSource(DataSource dataSource) {
		expJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[expjdbcTemplate datasource set ]");
	}

	public DataSource getDataSource() {
		return expJdbcTemplate.getDataSource();
	}
	public static ReprintRequestDAOImpl getInstance(){
		return reprint;
	}
	
	public  String getSPName(){
		return spName;
	}
	public void setSPName( String spName){
		this.spName = spName;
	}
	
	public Map submitReprintRequest(ReprintRequestObject reprintObject) throws NCASException {
		try {
			if (reprintObject == null) {
				throw new Exception("BMCUSTIDSearchForm is Null");
			}
			_LOGGER.info("submitReprintRequest for NSB accounts:" + reprintObject);
			String schemaName = getSchemaName(reprintObject.getOsid());
			Map output;
			String spName =NCASBOSIConstants.SP_EXA_NSB_REP_REQ;
			setSPName(spName);
			//SPGetReprint getReprint = new SPGeltReprint(getDataSource(),schemaName,spName);
			SPGetReprint getReprint = new SPGetReprint(getDataSource(),schemaName, spName, getspInOutList(spName));
			output = getReprint.executeStoredProcedure(reprintObject);
			_LOGGER.info("output for NSB accounts:" + output);
			return output;
		} catch (Exception vamEx) {
			_LOGGER.error("GET submitReprintRequest NSB \n" + vamEx.getMessage());
			throw new NCASException("BI0906", ReprintRequestDAOImpl.class, vamEx);
		}

	}// 
	
	public Map submitReprintRequestVSSI(ReprintRequestObject reprintObject) throws NCASException {
		try {
			if (reprintObject == null) {
				_LOGGER.error("throwing exception BMCUSTIDSearchForm is Null ");
				_LOGGER.debug("throwing exception BMCUSTIDSearchForm is Null ");
				throw new Exception("BMCUSTIDSearchForm is Null");
			}
			_LOGGER.info("submitReprintRequest for VSSI accounts:" + reprintObject);
			String schemaName = getSchemaName(reprintObject.getOsid());
			Map output;
			String spName =NCASBOSIConstants.SP_EXA_VSSI_REP_REQ;
			SPGetReprint getReprint = new SPGetReprint(getDataSource(),schemaName,spName, getspInOutList(spName) );
			output = getReprint.executeStoredProcedure(reprintObject);
			_LOGGER.info("output for VSSI accounts:" + output);
			return output;
		} catch (Exception vamEx) {
			_LOGGER.error("GET submitReprintRequest VSSI \n" + vamEx.getMessage());
			throw new NCASException("BI0906", ReprintRequestDAOImpl.class, vamEx);
		}

	}// 

	private List getspInOutList(String spName){
		_LOGGER.info("Static Init");
		 List spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 _LOGGER.info(" spName----------" + spName);
		  if(spName.equals(NCASBOSIConstants.SP_EXA_NSB_REP_REQ)) {
			 spInOutList.add(new Object[]{"ACCOUNT_ID", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 }else{
			 spInOutList.add(new Object[]{"MAN", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"BAN", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 }
		
		 spInOutList.add(new Object[]{"BILL_DATE", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROGRAME_MODE", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_REPRINT_C", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_F", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_CARR_RT_C", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_PAA_N", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_STTE_C", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_DAA_C", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_DRTE_C", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_DPNT_C", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_CTRY_N", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_ED", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADR_F", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADR_B", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADR_ST_YC", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_ATTN_X", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_X_1", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_YC_1", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_X_2", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_YC_2", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_X_3", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_YC_3", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_X_4", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_YC_4", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_X_5", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PSTLL_LN_YC_5", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RETURN_CODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 _LOGGER.info("spInOutList -----------> "+spInOutList);
		 return spInOutList;
	}


}





