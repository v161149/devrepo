package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.claim.Claim;
import com.verizon.enterprise.common.ncas.claim.ClaimSearch;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPSearchClaims extends BaseStoredProcedure
{
   static private final Logger _LOGGER = Logger.getLogger(SPSearchClaims.class);
   private static List spInOutList;
   private static final String VBCC_PORTAL = "VBCC";
   private static final String ALL = "ALL";
   private static final String CALENDAR_FORMAT1 = "MM/dd/yyyy";
   private static final String CALENDAR_FORMAT2 = "yyyy-MM-dd";
   private static final String TOTAL_ROWS = "TOTAL_ROWS";
   private static final String CLAIMS = "claims";

   static
   {
	_LOGGER.info("Static Init");
    spInOutList = new ArrayList();

    spInOutList.add(new Object[]{"claims", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new ClaimDataMapper()});
	spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"VPS_VZB_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"TRACKING_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"ACCOUNT_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CLM_STATUS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"ENTRY_DATE_FROM", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"ENTRY_DATE_THRU", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"CUST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"SORT_FIELD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"SORT_DIR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"START_POS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"NUM_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	
	
	spInOutList.add(new Object[]{"RETURN_CODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"REASON_CODE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"ERROR_TEXT", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLCODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLTOKENS", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
	spInOutList.add(new Object[]{"SP_SQLSTATE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

   }

	public SPSearchClaims(DataSource dataSource)
	{

	    super(dataSource, NCASBOSIConstants.SP_SEARCH_CLAIMS, spInOutList);

	}
	public Map executeStoredProcedure(Object parmMap)throws Exception
	{
		_LOGGER.info("Enterring executeStoredProcedure");
		Map myMap = (Map)parmMap;
		ClaimSearch mySearch = null;
		Pagination myPag = null;
		List paramValueList = new ArrayList();
		Map SPMap = null;
		Map resMap = null;

		// Check/Process  Input Map
		if ((myMap != null) && (parmMap instanceof Map)){
			mySearch = NCASDataUtil.getClaimSearch(myMap);
			myPag = NCASDataUtil.getPagination(myMap);
		}else{
			throw new Exception("Search claims bad input:" + parmMap);
		}
		if (mySearch == null){
			throw new Exception("Search claims claimsearch is null");
		}
		if (myPag == null){
			throw new Exception("Search claims pagination is null");
		}

		_LOGGER.info("logging the Domain Object-ClaimSearch::"+mySearch);
		_LOGGER.info("logging the Domain Object-Pagination::"+myPag);
		// Process Input
		paramValueList.add(mySearch.getSourcePortal());
		paramValueList.add(new Double(mySearch.getUserOid()));
		paramValueList.add(checkForVBC_VBCC_ALL(mySearch)); 	// vps vzb
		paramValueList.add(checkForNull(mySearch.getTrackingId()));
		paramValueList.add(appendWildCard(13,checkForNull(mySearch.getBan())));	 	// account number
		paramValueList.add(checkForClaimStatus(mySearch.getClaimStatus()));
		paramValueList.add(checkForDate(mySearch.getFromEntryDate()));
		paramValueList.add(checkForDate(mySearch.getToEntryDate()));
		paramValueList.add(appendWildCard(100,checkForNull(mySearch.getCustomerName())));
		paramValueList.add(checkForNull(myPag.getSortField()));		 	// SORT_FIELD
		paramValueList.add(checkForNull(myPag.getSortDirection()));		 	// SORT_DIR
		paramValueList.add(new Integer(myPag.getLineOffset()));		 	// START_POS
		paramValueList.add(new Integer(myPag.getPageSize()));	 	// NUM_ROWS
		
		SPMap = executeSP(paramValueList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(SPMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		Integer rowcountrStr = (Integer)SPMap.get(TOTAL_ROWS);
		_LOGGER.info("Total rows returned after VAR..SEARCH_CLAIMS:: "+ rowcountrStr.intValue());
		myPag.updateTotalPages(rowcountrStr.intValue());
		myPag.setDefaultSize(myPag.getItemsPerPage());
		ArrayList claims = (ArrayList)SPMap.get(CLAIMS);
		if(claims!=null){
			myPag.setResultSize(Integer.toString(claims.size()));
		}else{
			myPag.setResultSize("0");
		}
		_LOGGER.info("ResultSet Size:: "+ myPag.getResultSize());
		resMap = NCASDataUtil.setClaims(claims,resMap);
		resMap = NCASDataUtil.setPagination(myPag,resMap);
		return resMap;
	}
	
	private String checkForNull(String pInputParam){
			if(pInputParam == null || pInputParam.trim().length()==0){
				return null;
			}else{
				return pInputParam;
			}
	}

	private String appendWildCard(int length, String pInputParam){
		//assumes UI has already assured us the 3 char minimum
		// do not add % if field is at max length - VAC will throw a -302
		if(pInputParam == null || pInputParam.trim().length()==0)
				return null;
		else if (pInputParam.trim().length() < length)
				return pInputParam + "%";
		      else 	return pInputParam;

	}
		private String checkForVBC_VBCC_ALL(ClaimSearch pClaimSearch){
		if(pClaimSearch == null || pClaimSearch.getSourcePortal().equalsIgnoreCase(VBCC_PORTAL) || ALL.equalsIgnoreCase(pClaimSearch.getCorporateEntity()) || pClaimSearch.getCorporateEntity()==null || pClaimSearch.getCorporateEntity().trim().length()==0){
			return null;
		}else{
			return pClaimSearch.getCorporateEntity();
		}
	}
	private String checkForDate(String pDate)throws Exception{
		if(pDate!=null && pDate.trim().length()>0){
			return new java.text.SimpleDateFormat(CALENDAR_FORMAT2).format(new java.text.SimpleDateFormat(CALENDAR_FORMAT1).parse(pDate));
		}else{
			return null;
		}

	}
	private String checkForClaimStatus(String pClaimStatus){
		if(pClaimStatus == null || pClaimStatus.equalsIgnoreCase(ALL) || pClaimStatus.trim().length()==0  ){
			return null;
		}else{
			return pClaimStatus;
		}
	}
}
