package com.verizon.enterprise.ncasbosi.dao.Impl.ticket;




import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;


import com.verizon.enterprise.billservices.afp2pdf.Afp2Pdf;
import com.verizon.enterprise.billservices.afp2pdf.Afp2PdfHome;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.exception.ConnectionException;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.exception.TicketException;
import com.verizon.enterprise.common.ncas.fileupload.FileUploadDO;
import com.verizon.enterprise.common.ncas.ticket.FormFlds;
import com.verizon.enterprise.common.ncas.ticket.GlobalFlds;
import com.verizon.enterprise.common.ncas.ticket.TicketAudit;
import com.verizon.enterprise.common.ncas.vbif.TicketUpdate;
import com.verizon.enterprise.common.ncasbosi.beans.Request;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.ticket.TicketUIInterface;
import com.verizon.kernel.ejb.EJBHomeFactory;


public class TicketsUIImpl extends TicketsDAOImpl implements NCASBOSIConstants,TicketUIInterface {

	private static final Logger _LOGGER = Logger.getLogger(TicketsUIImpl.class);

	//get Reports Cache
	public Map getReasonCache(Map params)throws NCASException
	{
		return getReasonCache();
	}

	public Map getReasonEmailCache(Map params)throws NCASException
	{
		String portal = (String)params.get("PORTAL");
		Map retMap = new HashMap();
		retMap.put("LIST", getReasonEmailCache(portal));
		return retMap;
	}


	public Map submitTicket(Map params) throws Exception
	{
		final String METHOD_NAME = "submitTicket::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map  retMap = null;
		String ticket = "";
		GlobalFlds globalFld = (GlobalFlds)params.get("GLOBAL_FIELDS");
		String userOid = (String)params.get("USEROID");
		String login_id = (String)params.get("PORTAL_LOGIN_ID");
		List<FormFlds> inqFields  = (List<FormFlds>)params.get("INQ_FIELDS");
		Map autoSelections = (Map)params.get("AUTO_SELECTS");
		String tempTrackingNumber = globalFld.getAttachTrackingNum();
		try
		{
			TicketUpdate inquiry = new TicketUpdate();
			globalFld.setInquiry(inquiry,inqFields,login_id,autoSelections);

			String portal = (String)params.get("PORTAL");
			if(portal.equalsIgnoreCase("VZW")||portal.equalsIgnoreCase("VBC")||portal.equalsIgnoreCase("VPS"))
				portal =  NcasConstants.VBIF_BI_SOURCE_VBC ;
			else portal = NcasConstants.VBIF_BI_SOURCE_VEC ;

			String qt = (String)params.get("QUICKTICKET");
			if(qt!=null&&!qt.isEmpty())
				portal = NcasConstants.VBIF_BI_SOURCE_QUICKTICKET ;


			Map inputMap = new HashMap();
			inputMap.put(NcasConstants.VBIF_TICKETUPDATE_OBJ, inquiry);
			inputMap.put(NcasConstants.VBIF_BI_SOURCE, portal);

			if(!globalFld.isRedirectedEmailInq()){
				retMap = DAOFactory.getInstance().getVbifImpl().processRedirectTicket(inputMap);
				ticket = (String)retMap.get(NcasConstants.VBIF_TICKET_ID);
			}else{
				ticket = "REDIREMAIL_"+login_id+System.currentTimeMillis();
				redirectEmailInquiry(portal,globalFld,login_id,ticket,inquiry.getNoteFreeForm());
			}
			globalFld.setTicketNum(ticket);


		} catch(org.springframework.jdbc.CannotGetJdbcConnectionException ex){
            _LOGGER.info(METHOD_NAME+" Failed \n"+ex.getMessage());
            _LOGGER.info(METHOD_NAME+" Failed \n", ex);
			throw new ConnectionException(NCASBOSIConstants.ERROR_VAC,TicketsUIImpl.class,ex);
		}catch(Exception ex) {
            _LOGGER.info(METHOD_NAME+" Failed \n"+ex.getMessage());
            _LOGGER.info(METHOD_NAME+" Failed \n", ex);
			throw new TicketException(NCASBOSIConstants.ERROR_VAC,TicketsUIImpl.class,ex);
		}
		params.put("TICKET",ticket);
		params.put("TRACKING",tempTrackingNumber);
		updateAttachments(params);
		insertPLTicket(globalFld,inqFields,	userOid, login_id);
		insertPLTicketDetails(globalFld,inqFields,	userOid, login_id);


		retMap.put("TICKET_ID",ticket);
		retMap.put("SUBMIT_DATE",CommonUtil.getCurrentDate("MMMMM dd, yyyy"));
		retMap.put("ISSUE",globalFld.getReason().getDesc());
		retMap.put("ACCT_NBR",globalFld.getAccountInfo().getBan_dan());
		retMap.put("INV_DATE",globalFld.getInvoiceDate());


		_LOGGER.info(METHOD_NAME+"Exiting with ticket - " + ticket);
		return retMap;
	}


	public void updateAttachments(Map params) throws NCASException
	{
		final String METHOD_NAME = "updateAttachments::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map  retMap = null;
		String ticket = (String)params.get("TICKET");
		String trackingNumber = (String)params.get("TRACKING");
		String login_id = (String)params.get("PORTAL_LOGIN_ID");
		if(trackingNumber!=null && !trackingNumber.isEmpty() && ticket!=null && !ticket.isEmpty()){
				try{
						Afp2PdfHome afp2pdfHome = (Afp2PdfHome) EJBHomeFactory.getFactory().lookUpHome("Afp2Pdf");
						Afp2Pdf billServices = afp2pdfHome.create();

						FileUploadDO fudo = new FileUploadDO();
						fudo.setTrackingId(trackingNumber);
						fudo.setNewTrackingId(ticket);
						fudo.setFileSystem(FileUploadDO.BILL_INQUIRY);
						fudo.setUserId(login_id);
						billServices.updateTrackId(fudo);
				}catch(Exception ex) {
		            _LOGGER.info(METHOD_NAME+" Failed - ATTACHMENT FAILURE \n"+ex.getMessage());
		            _LOGGER.info(METHOD_NAME+" Failed - ATTACHMENT FAILURE \n", ex);
				}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");

	}


	public void insertTicketAudit(Map params) throws NCASException
	{
		try{
			TicketAudit tktAudit = (TicketAudit)params.get("AUDIT");
			insertTicketAuditDetail(tktAudit);
		}catch(Exception ex) {
			_LOGGER.error("insertTicketAudit failed ::"+ex.getMessage());
		}

	}

	public Map getDynamicFields(Map params) throws NCASException
	{
		String tkt = (String)params.get("TICKET_ID");
		Map retMap = new HashMap();
		retMap.put("LIST", getDynamicFields(tkt));
		return  retMap;
	}

	public Map getTicketLite(Map params)throws NCASException
	{
		Map retMap = DAOFactory.getInstance().getVbifImpl().getTicket(params);
		return  retMap;
	}

	public Map getUserSearchList(Map params)throws NCASException
	{
		Map retMap = DAOFactory.getInstance().getBillView().getUserSearchList(params);
		return  retMap;
	}

	public Map getEmails(Map params)throws NCASException
	{

		String ticket = (String)params.get("TRACKID");
		String isPublic = (String)params.get("PUBLIC");
		Map retMap = getEmails(ticket, isPublic);
		return  retMap;
	}


	public Map buildInquirySearch(Map params)throws NCASException
	{
		return  buildInquirySearch("");
	}

	private void redirectEmailInquiry(String portal,GlobalFlds globalFld, String login_id,String ticket,String noteText)throws Exception {
		Request obj = new Request();
		obj.setParam1(ticket);//Ticket Number
		obj.setParam2("VBIF_CANADIAN");
		obj.setParam3(globalFld.getRedirectedEmailToAddress());//To Address
		obj.setParam4(globalFld.getAccountInfo().getBan_dan());//Account
		obj.setParam5(globalFld.getContactName()+ "  "+ globalFld.getContactEmail()+" "+globalFld.getContactPhone());//Contact Name, Email & pHONE
	    obj.setParam6(globalFld.getReason().getDesc());//Reason Desc

		obj.setLogin(login_id);
		obj.setLastUpdatedBy(login_id);
		obj.setPortal(portal);
		obj.setStatus("S");
		obj.setType(NcasConstants.BATCH_VBIF_EMAIL_PROCESSOR);
		obj.setErrormsg("");
		obj.setEmailText(noteText);
		DAOFactory.getInstance().getBatchRequestProcessor().doBatchReq(NcasConstants.BATCH_INSERT_REQ, 0, obj, "");
	}


}




