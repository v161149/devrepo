package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.Types;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;


import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.claim.Claim;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class SPGetClaim extends BaseStoredProcedure 
{
   private static final Logger _LOGGER = Logger.getLogger(SPGetClaim.class);
   private static List spInOutList;
 
   static
   {
	_LOGGER.info("Static block Initialisation of SPGetClaim");
    spInOutList = new ArrayList();
	spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetClaimMapper()});
	spInOutList.add(new Object[]{"SRC_SYS_CLM_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"ORIGINATOR_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	spInOutList.add(new Object[]{"ENTITLEMENT_REQ", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		
	spInOutList.add(new Object[]{"RETURN_CODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"REASON_CODE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"ERROR_TEXT", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLCODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLTOKENS", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	spInOutList.add(new Object[]{"SP_SQLSTATE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});	
   }
   
	public SPGetClaim(DataSource dataSource)
	{
	    super(dataSource, NCASBOSIConstants.SP_GET_VBCC_CLAIM, spInOutList);	  	
	}
	public Map executeStoredProcedure(Object input)throws Exception
	{
		_LOGGER.info("Entering executeStoredProcedure");
		Claim claim = (Claim)input;
		List paramValueList = new ArrayList();	
		paramValueList.add(claim.getTrackingNumber());// SRC_SYS_CLM_ID		
		paramValueList.add(claim.getSourcePortal());// VBC_OR_VBCC
		paramValueList.add(claim.getOrigLoginId());// ORIGINATOR_LOGINID
		paramValueList.add(new Double(claim.getUserOid()));// USER_OID				// PVB 07/2008 Turning on VAC based entitlement checking for any "get" 		// if coming from VBCC. 		if (claim.getSourcePortal().equals("VBCC"))			paramValueList.add("Y");		else			paramValueList.add("N");					/***** call the SP *************/
		Map resMap = executeSP(paramValueList, false);		
		//Map resMap = tempClaim();
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return  NCASDataUtil.setClaim((Claim)((ArrayList)resMap.get("RESULT_SET_ONE")).get(0),resMap);
		//return resMap;
	}
	private Map tempClaim()
	// just for testing when VAC was not ready
	// or other non vac creatable scenarios
	{
		Claim myClaim = null;
		Map myMap = new java.util.HashMap();
		myClaim = new Claim();
		myClaim.setTrackingNumber("12300020");
		myClaim.setBan("BAN 90233");
		myClaim.setClaimAmount(129.02f);
		myClaim.setEntryDate(new java.util.Date());
		myClaim.setStatus("Approved - Sent to Billing");	
		myClaim.setClosedDate(new java.util.Date());
		myClaim.setAcctName("MERILL CITGROUP");
		myClaim.setBillInquiryId("BILL1804080007140");
		myClaim.setClaimBans("129021323211, 12323231312, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432, 23492343432");
		myMap.put("RETURN_CODE",Integer.valueOf("0"));
		myMap = NCASDataUtil.setClaim(myClaim, myMap);
		return myMap;
	}
	
	//overriding the BaseStoredProcedure's checkVACErrors() method
	public void checkVACErrors(Map resMap)throws Exception
	{
		_LOGGER.info("Entering in method SPGetClaim.checkVACErrors(Map resMap)");
		Object retCodeObj = null;
		Integer retCode = null;		
		if(resMap != null)
		{
		   retCodeObj = resMap.get(NCASBOSIConstants.BI_VAC_RETURN_CODE_IDENTIFIER);
		   if(retCodeObj != null)
		   {
     		  retCode = (Integer)retCodeObj;
			  if(retCode.intValue() >= NCASBOSIConstants.BI_VAC_ERROR_CODE){
				  	String errorMsg = CommonUtil.mapToString(resMap);
					_LOGGER.error("Error encountered in the VAC Response "+errorMsg);
					_LOGGER.debug("Entering method checkVACErrors "+errorMsg); 
					String reasonCode = (String)resMap.get(NCASBOSIConstants.BI_VAC_REASON_CODE_IDENTIFIER);
					if(reasonCode!=null && reasonCode.trim().equals(NCASBOSIConstants.CLAIM_NOT_FOUND_ERROR_CODE)){ //claim not found
						throw new SQLException(NcasConstants.CLAIM_NOT_FOUND);
					}else if(reasonCode!=null && reasonCode.trim().equals(NCASBOSIConstants.CLAIM_USER_NOT_ENTITLED_ERROR_CODE)){ // user not entitled to view claim
						throw new SQLException(NcasConstants.USER_NOT_ENTITLED_CLAIM);
					}else{
						throw new SQLException("VAC BAD Response "+errorMsg);
					}
			  }else if(retCode.intValue() == NCASBOSIConstants.BI_VAC_WARNING_CODE){
				  String retWrn =  CommonUtil.mapToString(resMap);//(String)resMap.get(NCASBOSIConstants.BI_VAC_WARNING_TEXT_IDENTIFIER);
				  _LOGGER.warn("VAC Warnings Issued "+retWrn);
				  _LOGGER.info("VAC Warnings Issued "+retWrn);
				  _LOGGER.debug("VAC Warnings Issued "+retWrn);
			  }else{
				  _LOGGER.info("VAC Response has no errors or warnings");
			  }
		   }
		}else{
			_LOGGER.info("Map passed to the method SPGetClaim.checkVACErrors was null");
		}
		_LOGGER.info("Exiting method SPGetClaim.checkVACErrors");
		
	}
}
