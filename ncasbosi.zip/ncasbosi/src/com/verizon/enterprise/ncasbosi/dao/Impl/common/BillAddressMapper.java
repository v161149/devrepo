package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.common.BillAddress;

public class BillAddressMapper implements RowMapper
{

	static private final Logger _LOGGER = Logger.getLogger(BillAddressMapper.class);


	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		BillAddress resBilladd = null;

		_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry.BillInquiry");
		if(rs != null)
		{
			resBilladd = new BillAddress();

			resBilladd.setAban(rs.getString("ABAN"));
			_LOGGER.info("ABAN = "+rs.getString("ABAN"));
			
			resBilladd.setNameaddr1(rs.getString("NAME_ADDR_1"));
			_LOGGER.info("NAME_ADDR_1 = "+rs.getString("NAME_ADDR_1"));

			resBilladd.setNameaddr2(rs.getString("NAME_ADDR_2"));
			_LOGGER.info("NAME_ADDR_2 = "+rs.getString("NAME_ADDR_2"));

			resBilladd.setNameaddr3(rs.getString("NAME_ADDR_3"));
			_LOGGER.info("NAME_ADDR_3 = "+rs.getString("NAME_ADDR_3"));

			resBilladd.setNameaddr4(rs.getString("NAME_ADDR_4"));
			_LOGGER.info("NAME_ADDR_4 = "+rs.getString("NAME_ADDR_4"));

			resBilladd.setNameaddr5(rs.getString("NAME_ADDR_5"));
			_LOGGER.info("NAME_ADDR_5 = "+rs.getString("NAME_ADDR_5"));

			resBilladd.setStatecode(rs.getString("STATE_CODE"));
			_LOGGER.info("STATE_CODE = "+rs.getString("STATE_CODE"));
			
			resBilladd.setZipcdbasic(rs.getString("ZIP_CD_BASIC"));
			_LOGGER.info("ZIP_CD_BASIC = "+rs.getString("ZIP_CD_BASIC"));
			
			resBilladd.setZipcdplus4(rs.getString("ZIP_CD_PLUS_4"));
			_LOGGER.info("ZIP_CD_PLUS_4 = "+rs.getString("ZIP_CD_PLUS_4"));
			
			resBilladd.setPaymaddr1(rs.getString("PAYM_ADDR_1"));
			_LOGGER.info("PAYM_ADDR_1 = "+rs.getString("PAYM_ADDR_1"));

			resBilladd.setPaymaddr2(rs.getString("PAYM_ADDR_2"));
			_LOGGER.info("PAYM_ADDR_2 = "+rs.getString("PAYM_ADDR_2"));

			resBilladd.setPaymaddr3(rs.getString("PAYM_ADDR_3"));
			_LOGGER.info("PAYM_ADDR_3 = "+rs.getString("PAYM_ADDR_3"));

			resBilladd.setPaymaddr4(rs.getString("PAYM_ADDR_4"));
			_LOGGER.info("PAYM_ADDR_4 = "+rs.getString("PAYM_ADDR_4"));

			resBilladd.setPaymaddr5(rs.getString("PAYM_ADDR_5"));
			_LOGGER.info("PAYM_ADDR_5 = "+rs.getString("PAYM_ADDR_5"));

			resBilladd.setPaymstate(rs.getString("PAYM_STATE"));
			_LOGGER.info("PAYM_STATE = "+rs.getString("PAYM_STATE"));

			resBilladd.setPaymzip(rs.getString("PAYM_ZIP"));
			_LOGGER.info("PAYM_ZIP = "+rs.getString("PAYM_ZIP"));

			resBilladd.setPaymzipplus4(rs.getString("PAYM_ZIP_PLUS4"));
			_LOGGER.info("PAYM_ZIP_PLUS4 = "+rs.getString("PAYM_ZIP_PLUS4"));

			
		}

	  return resBilladd;
	}
}