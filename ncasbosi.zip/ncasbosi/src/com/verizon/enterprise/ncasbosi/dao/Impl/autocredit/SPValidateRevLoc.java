package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


/**
 * @author v191876
 * This class represents the SP_VALIDATE_RevLoc api 
 * It is used for two purposes
 * 1.To validate a REVLOC when user tries to do so
 * 2.To validate a REVLOC on creating Remits also.
 */

public class SPValidateRevLoc extends BaseStoredProcedure {
	
	private final static Logger _LOGGER = Logger.getLogger(SPValidateRevLoc.class);
	private static List<Object[]> spInOutList;
	
	static{		 
		 spInOutList = new ArrayList<Object[]>();
		 
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"REVLOC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 		 
	 }
	
	public SPValidateRevLoc(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_VALIDATE_RevLoc, spInOutList);
	}
	
	public Map<String,Object> executeStoredProcedure(String appUserId, String debugLevel, Object pInput)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map<String,Object> inputMap = (HashMap<String,Object>)pInput;
		_LOGGER.info("inputMap::"+inputMap);
		if(inputMap==null){
			throw new Exception("Input Object cannot be null");
		}
		
		String revLoc = (String)inputMap.get("REVLOC_CD");
		String userAction = (String)inputMap.get("_action");
				
		List<Object> inputList = new ArrayList<Object>();
		inputList.add(appUserId);
		inputList.add(debugLevel);
		inputList.add(revLoc);//revLoc
		Map<String,Object> resMap = executeStoredProcedure(inputList);
		_LOGGER.info("Now calling checkVAMErrors to identify any errors or issued warnings");
		checkErrors(resMap, VAM);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
		
	}
	
	protected Map executeStoredProcedure(Object paramValues) throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
	
}
