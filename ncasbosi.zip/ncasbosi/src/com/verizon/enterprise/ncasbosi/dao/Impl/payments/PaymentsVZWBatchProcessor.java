package com.verizon.enterprise.ncasbosi.dao.Impl.payments;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.payments.*;
import com.verizon.enterprise.common.ncas.exception.InvalidPaymentException;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.exception.PaymentException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.*;
import com.verizon.enterprise.wisegate.ejb.WisegateCache;


public class PaymentsVZWBatchProcessor extends PaymentsBatchImpl implements NCASBOSIConstants,PaymentsBatchInterface {

	private static final Logger _LOGGER = Logger.getLogger(PaymentsVZWBatchProcessor.class);


	public void doVZWRecurPaymentBatch() throws NCASException
	{
		final String METHOD_NAME = "doVZWRecurPaymentBatch => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		Map<String,String> eligibilityParams = null;
		String myFormatString = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		RecurPayment item = null;
		PaymentResponse payResponse = null;


		Collection<RecurPayment> recurList=null;

		try
		{
			 recurList = selectRecurPayments(NcasConstants.VZB_VZW_FLAG_VZW);
			_LOGGER.info(METHOD_NAME + " The size of incomplete Reqs::"+recurList.size());
			Iterator<RecurPayment> itr = recurList.iterator();

			while (itr.hasNext()) {
			try{
				item = itr.next();
				int profileID = item.getProfileID();
				int recurPayId = item.getPaymentID();
				String loginId = item.getLoginId();
				String serviceId = item.getServiceID();
				eligibilityParams = new HashMap<String,String>();
				eligibilityParams.put("userOid",Double.toString(item.getUserOID()));
				eligibilityParams.put("subscriptionOid",Double.toString(item.getSubscriptionOid()));
				eligibilityParams.put("loginId",item.getLoginId());

				String profileStatus = getProfileStatus(profileID);
				_LOGGER.info(METHOD_NAME+"The profile status for the profile number::"+profileID+"::is:"+profileStatus);

				if(profileStatus.equalsIgnoreCase(NcasConstants.PROFILE_STATUS_ACTIVE))
				{
					_LOGGER.info(METHOD_NAME+"The profile :"+profileID+": is ACTIVE");
					_LOGGER.info(METHOD_NAME+"NextPaymentDate: "+item.getNextPaymentDate());
					_LOGGER.info(METHOD_NAME+"FirstPaymentDate: "+item.getFirstPaymentDate());
					if(CommonUtil.compareDate(item.getNextPaymentDate(),item.getFirstPaymentDate(),myFormatString)==0)
					{
						_LOGGER.info(METHOD_NAME+"NextPaymentDate and FirstPaymentDate are the same.");
						updateRecurDetailsStatus(recurPayId,NcasConstants.PAY_DETAILS_LOCKED_STATUS,NcasConstants.BATCH_VZW_RECUR);
						payResponse = webImpl.managePayment(item, selectPaymentProfileDetails(profileID).get("paymentProfile"), NcasConstants.PAYMENT_TYPE_RECURRING);
						updateEPaymentsResponseForRecur(payResponse,recurPayId,CommonUtil.getNextPaymentDateFromNextDate(item.getNextPaymentDate(),item.getSettleDay()),NcasConstants.RECUR_PAY_SCHEDULED_STATUS,NcasConstants.BATCH_VZW_RECUR);
						insertPaymentEmail(item, item.getNickName(),REC_PMNT_CHANGES_TEMPLATE_VZW,item.getLoginId(),METHOD_NAME,NcasConstants.EMAIL_PROCESSED,NcasConstants.BATCH_VZW_RECUR);

					}
					else if(CommonUtil.compareDate(item.getNextPaymentDate(),simpleDateFormat2.format(cal.getTime()),myFormatString)<=0)
					{
						_LOGGER.info(METHOD_NAME+"NextPaymentDate and FirstPaymentDate are not the same and nextpaymentdate is less than or equal to today");
						if(isUserEligible(eligibilityParams))
						{
							_LOGGER.info(METHOD_NAME+"Yes the user :"+loginId+":: is eligible to pay for the service id :"+serviceId);
							//If the user is eligible update next payment date to +1 month.
							updateRecurPaymentStatus(recurPayId,item.getPaymentStatus(),"",CommonUtil.getNextPaymentDateFromNextDate(item.getNextPaymentDate(),item.getSettleDay()),item.getUpdateType(),NcasConstants.BATCH_VZW_RECUR);
							_LOGGER.info(METHOD_NAME+"Updated the next payment date for recur payment id:"+recurPayId);
						}
						else
						{
							_LOGGER.info(METHOD_NAME+"No, the user :"+loginId+":: is not eligible to pay for the service id :"+serviceId);
							updateRecurPaymentStatus(recurPayId,NcasConstants.RECUR_PAY_CANCEL_STATUS,"User unable to access Account","",NcasConstants.RECUR_WIRELESS_UPD_CANCEL,NcasConstants.BATCH_VZW_RECUR);
						}
					}
				}
				else
				{
					_LOGGER.info(METHOD_NAME+"The profile :"+profileID+": is INACTIVE");
					updateRecurPaymentStatus(recurPayId,NcasConstants.RECUR_PAY_CANCEL_STATUS,"Inactive Payment Account","",NcasConstants.RECUR_WIRELESS_UPD_CANCEL,NcasConstants.BATCH_VZW_RECUR);
				}
				}catch(InvalidPaymentException iex){
					PaymentResponse payResp = iex.getPaymentResponse("Failed to process the payment..");
					updateFailureRecurResponse(payResp,item,NcasConstants.PAY_DETAILS_FAILED_STATUS,NcasConstants.BATCH_VZW_RECUR);
					_LOGGER.info(METHOD_NAME+"Updated ePayments response for recurPayId:"+item.getPaymentID());
					insertPaymentEmail(item, item.getNickName(),REC_PMNT_SETUP_FAILURE_TEMPLATE_VZW,item.getLoginId(),METHOD_NAME,NcasConstants.EMAIL_FAILED,iex.getPaymentResponse().getEpResponseText(),iex.getPaymentResponse().getEpResponseCode(),Integer.toString(item.getPortalTrackID()),NcasConstants.BATCH_VZW_RECUR);

				}catch(PaymentException pex){
					item.setErrorDesc(pex.getMessage());
					updateRecurPaymentStatus(item.getPaymentID(),item.getPaymentStatus(),pex.getMessage(),item.getNextPaymentDate(),item.getUpdateType(),NcasConstants.BATCH_VZW_RECUR);
					insertPaymentEmail(item, item.getNickName(),PORTAL_BILLING_NOTIF_TEMPLATE,item.getLoginId(),METHOD_NAME,"","EXCEPTION Processing ::"+METHOD_NAME+"::"+pex.getMessage(),item.getEpResponseCode(),Integer.toString(item.getPortalTrackID()),NcasConstants.BATCH_VZW_RECUR);
					_LOGGER.info(METHOD_NAME+"Updated pl_pay_Recur saying ->Failed informing ePayments about recurPaymentId:"+item.getPaymentID());
				}catch(Exception ex){
					ex.printStackTrace();
					_LOGGER.error(METHOD_NAME + " in NCASBOSI Failed - Inner Loop\n" +ex.getMessage());
					if(item == null)
						item = new RecurPayment();
					insertPaymentEmail(item,item.getNickName(), PORTAL_BILLING_NOTIF_TEMPLATE,item.getLoginId(),METHOD_NAME,"","EXCEPTION Processing ::"+METHOD_NAME+"::"+ex.getMessage(),item.getEpResponseCode(),Integer.toString(item.getPortalTrackID()),NcasConstants.BATCH_VZW_RECUR);
				}
		  }
		}catch(Exception e){
			_LOGGER.error(METHOD_NAME + " in NCASBOSI Failed \n" +e.getMessage());
			if(item == null)
				item = new RecurPayment();
			insertPaymentEmail(item, item.getNickName(),PORTAL_BILLING_NOTIF_TEMPLATE,item.getLoginId(),METHOD_NAME,"","EXCEPTION Processing ::"+METHOD_NAME+"::"+e.getMessage(),item.getEpResponseCode(),Integer.toString(item.getPortalTrackID()),NcasConstants.BATCH_VZW_RECUR);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
}

	public Double getWirelessRealTimeBalance(String accountNumber) throws NCASException
	{
		final String METHOD_NAME = "getWirelessRealTimeBalance => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		_LOGGER.info(METHOD_NAME+"Account Number:"+accountNumber);
		Double retValue = 0.0;
		try{
			retValue = webImpl.getWirelessRealTimeBalance(accountNumber);
			_LOGGER.info(METHOD_NAME+"Ret value:"+retValue);
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+" Failed \n"+vamEx.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,PaymentsDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return retValue;
	}

	 public boolean isUserEligible(Map<String,String> eligibilityParams)throws NCASException{
			final String METHOD_NAME = "isUserEligible => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			_LOGGER.info(METHOD_NAME+" Eligibility Params:"+eligibilityParams);
		 boolean eligible = false;
		try{
			List acronyms = WisegateCache.getUserAcronyms(eligibilityParams.get("loginId"));
			_LOGGER.info(METHOD_NAME+"Acronyms:"+acronyms);
			eligible = NCASDataUtil.canPayVZW(acronyms);
			_LOGGER.info(METHOD_NAME+"eligible:"+eligible);
			if(!eligible)
			{
				return eligible;
			}
			Map responseMap = isUserEligible(eligibilityParams.get("userOid"),eligibilityParams.get("subscriptionOid"));

			if(((Integer)responseMap.get("RETURN_CODE")).intValue()==0){
				_LOGGER.info(METHOD_NAME+"Return code value is 0");
				String isUserElig = (String)responseMap.get("ELIGABLE_FLAG");
				if(eligible && isUserElig.equalsIgnoreCase("Y"))
				{
					eligible = true;
				}
				else{
					eligible = false;
				}
			}else{
				_LOGGER.info(METHOD_NAME+"Unable to confirm user eligibility");
				throw new Exception("Unable to confirm user eligibility:"+(String)responseMap.get("MSG_STRING"));
			}
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+" Failed \n"+vamEx.getMessage());
			throw new NCASException(PAYMENT_EXCEPTION_950,PaymentsDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		 return eligible;
	 }
}




