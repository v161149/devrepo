package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetProfilesByOid extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetProfilesByOid.class);
	
	private static List spInOutList;

	private static GetProfilesByOidRowMapperImpl rowMapper;
	
	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new GetProfilesByOidRowMapperImpl();
		 
		 spInOutList.add(new Object[]{"profiles",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CUST_NO", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUSTOMER_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MEDIA_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPGetProfilesByOid(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_ACCT_EMEDIA_LIST, spInOutList);	
	}
	
	public Map executeStoredProcedure(  String userId, String debugLevel, 
										String customerNo, String customerType, 
										String mediaType, String cursorId, 
										int startPosition, int pageSize) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		if(customerType == null) {
			customerType = "";
		}
		if(mediaType == null) {
			mediaType = "";
		}
		if(cursorId == null) {
			cursorId = "";
		}
		
		paramValueList.add(customerNo);//CUST_NO
		paramValueList.add(customerType);//CUSTOMER_TYPE
		paramValueList.add(mediaType);//MEDIA_TYPE
		paramValueList.add(cursorId);//TOKEN_ST
		paramValueList.add(String.valueOf(startPosition));//PAGE_OFFSET
		paramValueList.add(String.valueOf(pageSize));//PAGE_SIZE
		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
