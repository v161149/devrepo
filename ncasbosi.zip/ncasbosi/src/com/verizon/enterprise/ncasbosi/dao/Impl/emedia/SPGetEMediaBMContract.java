package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;


public class SPGetEMediaBMContract extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetEMediaBMContract.class);
	
	private static List spInOutList;
	
	private static GetEMediaBMContractRowMapperImpl rowMapper;
	
	static
	{
		 rowMapper = new GetEMediaBMContractRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"bmContracts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CONTRACT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUSTOMER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
	}
	
	public SPGetEMediaBMContract(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_BM_CONTRACT, spInOutList);	
	}

	public Map executeStoredProcedure(String userId,String debugLevel,String contractId,String custName,String whereFilter,
			String sortOrder, Pagination pagination)throws Exception
	{
		
		_LOGGER.debug("entering  executeStoredProcedure api");
		
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		
		StringBuffer myParams = new StringBuffer();

		myParams.append("SP Params [");


		paramValueList.add(userId);//APP_USER_ID
		myParams.append(userId + "^");
		

		paramValueList.add(debugLevel);//DEBUG_LEVEL
		myParams.append(debugLevel + "^");
		
		
		paramValueList.add(contractId);
		myParams.append(contractId + "^");
		
		paramValueList.add(custName);
		myParams.append(custName + "^");
		
		if(whereFilter == null || whereFilter.equals("")) {
			paramValueList.add("");//WHERE_FILTER
		} else {
			paramValueList.add(whereFilter);//WHERE_FILTER
		}
		myParams.append(whereFilter + "^");
		
		
		if(sortOrder == null || sortOrder.equals("")) {
			paramValueList.add("");//SORT_ORDER
		} else {
			paramValueList.add(sortOrder);//SORT_ORDER
		}
		myParams.append(sortOrder + "^");

		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}

		paramValueList.add(lineOffSet);//LINE_OFFSET
		myParams.append(lineOffSet + "^");
		
		paramValueList.add(pageSize);//PAGE_SIZE
		myParams.append(pageSize + "^");
		
		_LOGGER.debug(myParams.toString());
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		//return executeStoredProcedure(paramValueList);
		
		_LOGGER.debug("after executing api");
		
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		_LOGGER.debug("rowcountrStr" + rowcountrStr);

		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		
		//Map acctMap = (HashMap)procMap.get("bmConfigWaivers");
		List  contractsList = (List)procMap.get("bmContracts");
		_LOGGER.debug("after getting list");
		if(contractsList!=null)
			pagination.setResultSize(Integer.toString(contractsList.size()));
		else 
			pagination.setResultSize("0");
		_LOGGER.debug("after setting list size to pagnation");
		
		procMap.put("pagination", pagination);
		_LOGGER.debug("after setting pagination  to procMap");

		return procMap ;
				
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
