package com.verizon.enterprise.ncasbosi.dao.Impl.billmanager;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.Impl.portallinks.PortalLinkDAOImpl;

import com.verizon.enterprise.ncasbosi.dao.Interface.billmanager.MediaDownloadInterface;
import com.verizon.enterprise.common.ncasbosi.beans.MediaCount;
import com.verizon.enterprise.common.ncasbosi.beans.MediaDownload;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.common.ncas.exception.NCASException;

import java.math.BigInteger;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Arrays;

import javax.sql.DataSource;

public class MediaDownloadDAOImpl extends JdbcDaoSupport implements
        MediaDownloadInterface, NCASBOSIConstants
{
    private static final Logger _LOGGER = Logger
            .getLogger(MediaDownloadDAOImpl.class);

    private BatchSqlUpdate insertMediaDownloadSqlUpdate = null;
    private BatchSqlUpdate insertMediaEmailSqlUpdate = null;
    private BatchSqlUpdate deleteMediaDownloadSqlUpdate = null;    

    

    private String getSchemaName()
    {
        String schemaName = NCASBOSIConstants.VAM_SCHEMA;
       
        return schemaName;
    }

    
    public Map processMediaDownloadList(String operation, Object obj) throws NCASException
    {
        String METHOD_NAME = "processMediaDownloadList()  ";
        _LOGGER.info(METHOD_NAME + "  Enter  operation = " + operation);

        // temp api to redirect to processMediaDownloadRequest() 
        //    until it gets to wisegate db
        Map responseMap = null;
        responseMap = processMediaDownloadRequest(operation, obj);
 
        _LOGGER.info(METHOD_NAME + "  Exit  operation = " + operation);

        return responseMap;
    }
    
    
    public Map processMediaDownloadRequest(String operation, Object paramObj)
            throws NCASException
    {
        String METHOD_NAME = "processMediaDownloadRequest()  ";
        _LOGGER.info(METHOD_NAME + "  Enter  operation = " + operation);
        
        Map responseMap = null;
        
        if (operation.equalsIgnoreCase("getBMMediaDownloadList"))
        {
            List myParams = (List) paramObj;
            String customerId = (String) myParams.get(0);
            String fromDate = (String) myParams.get(1);
            String toDate = (String) myParams.get(2);
            String appId="BM";
            responseMap = selectAllMediaDownload(customerId, fromDate, toDate,appId);
        }
        else if (operation.equalsIgnoreCase("getBMFileNamesUsingFileDate"))
        {   String appId="BM";
            String fileDate = paramObj.toString();
            responseMap = getMDFileNamesUsingFileDate(fileDate,appId);
        }
        else if (operation.equalsIgnoreCase("getBMCountsGroupedByFileDate"))
        {   String appId="BM";
            responseMap = getMDCountsGroupedByFileDate(appId);        
        }
        else if (operation.equalsIgnoreCase("insertBMFileNames"))
        {
        	String appId="BM";
            responseMap = insertMDFileNames((List) paramObj,appId);        
        }
        else if (operation.equalsIgnoreCase("deleteBMFileNames"))
        {   String appId="BM";
            responseMap = deleteMDFileNames((List) paramObj,appId);        
        }
        else if (operation.equalsIgnoreCase("getBMMinFileDate"))
        {   String appId="BM";
            responseMap = getMDMinFileDate(appId);        
        }
        else if (operation.equalsIgnoreCase("createBMEmailRecords"))
        {   String appId="BM";
            List myParams = (List) paramObj;
            List emailAddressList = (List) myParams.get(0);
            MediaDownload md = (MediaDownload) myParams.get(1);
            Long emailTransId = (Long) myParams.get(2);
     
            responseMap = createMDEmailRecords(emailAddressList, md, emailTransId,appId);        
        }
        //This Method is for Direct Data Download
        else if (operation.equalsIgnoreCase("createDDEmailRecords"))
        {   String appId="DD";
            List myParams = (List) paramObj;
            List emailAddressList = (List) myParams.get(0);
            MediaDownload md = (MediaDownload) myParams.get(1);
            Long emailTransId = (Long) myParams.get(2);
     
            responseMap = createMDEmailRecords(emailAddressList, md, emailTransId,appId);        
        }
        //This Method is for Direct Data Download
        else  if (operation.equalsIgnoreCase("getDDMediaDownloadList"))
        {
            List myParams = (List) paramObj;
            String customerId = (String) myParams.get(0);
            String fromDate = (String) myParams.get(1);
            String toDate = (String) myParams.get(2);
            String appId="DD";
            responseMap = selectAllMediaDownload(customerId, fromDate, toDate,appId);
        }
        else if(operation.equalsIgnoreCase("getDDFileNamesUsingFileDate")){
        	String appId="DD";
            String fileDate = paramObj.toString();
            responseMap = getMDFileNamesUsingFileDate(fileDate,appId);
        }
        else if (operation.equalsIgnoreCase("getDDCountsGroupedByFileDate"))
        {   String appId="DD";
            responseMap = getMDCountsGroupedByFileDate(appId);        
        }
        else if (operation.equalsIgnoreCase("insertDDFileNames"))
        {
        	String appId="DD";
            responseMap = insertMDFileNames((List) paramObj,appId);        
        }
        else if (operation.equalsIgnoreCase("deleteDDFileNames"))
        {   String appId="DD";
            responseMap = deleteMDFileNames((List) paramObj,appId);        
        }
        else if (operation.equalsIgnoreCase("getDDMinFileDate"))
        {   String appId="DD";
            responseMap = getMDMinFileDate(appId);        
        }
        else if(operation.equalsIgnoreCase("getLBMediaDownloadList"))
        {   String appId="LB";
           List myParams = (List) paramObj;
           String accountNumber = (String) myParams.get(0);
           String fromDate = (String) myParams.get(1);
           String toDate = (String) myParams.get(2);
        
        responseMap = selectAllMediaDownload(accountNumber, fromDate, toDate,appId);
        }
        else if(operation.equalsIgnoreCase("getLBFileNamesUsingFileDate")){
        	String appId="LB";
            String fileDate = paramObj.toString();
            responseMap = getMDFileNamesUsingFileDate(fileDate,appId);
        }
        else if (operation.equalsIgnoreCase("getLBCountsGroupedByFileDate"))
        {   String appId="LB";
            responseMap = getMDCountsGroupedByFileDate(appId);        
        }
        else if (operation.equalsIgnoreCase("insertLBFileNames"))
        {
        	String appId="LB";
            responseMap = insertMDFileNames((List) paramObj,appId);        
        }
        else if (operation.equalsIgnoreCase("createLBEmailRecords"))
        {   String appId="LB";
            List myParams = (List) paramObj;
            List emailAddressList = (List) myParams.get(0);
            MediaDownload md = (MediaDownload) myParams.get(1);
            Long emailTransId = (Long) myParams.get(2);
     
            responseMap = createMDEmailRecords(emailAddressList, md, emailTransId,appId);        
        }
        else if (operation.equalsIgnoreCase("getLBMinFileDate"))
        {   String appId="LB";
            responseMap = getMDMinFileDate(appId);        
        }
		else if(operation.equalsIgnoreCase("deleteLBFileNames")){
            String appId="LB";
			responseMap=deleteMDFileNames((List) paramObj,appId);
		}
        else
        {
            String myMsg[] = new String[2];
            myMsg[0] = "BillManager Media Download Error - Invalid Operation Code : " + operation;
            myMsg[1] = "Error in Class : " + MediaDownloadDAOImpl.class.getName();
            throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_850, myMsg);           
        }
        
        _LOGGER.info(METHOD_NAME + "  Exit  operation = " + operation);
        return responseMap;
    }    

    
    public Map getMDFileNamesUsingFileDate(String fileDate,String appId) throws NCASException
    {
        String METHOD_NAME = "getMDFileNamesUsingFileDate  ";
        _LOGGER.info(METHOD_NAME + "  Enter  fileDate = " + fileDate);
        _LOGGER.info(METHOD_NAME + "  Enter  appId = " + appId); 
         String mySql = getMDFileNamesUsingFileDateSQL(fileDate,appId);
        _LOGGER.info(METHOD_NAME + "  mySql = " + mySql);      
        
        SearchMDUsingFileDate mySearch = new SearchMDUsingFileDate(getDataSource(), mySql);
        List myDBFileList = mySearch.execute(new Object[] {});
                
        HashMap responseMap = new HashMap();         
        responseMap.put("status", new Boolean(true));
        responseMap.put("myDBFileList", myDBFileList);
        
        _LOGGER.info(METHOD_NAME + "  Exit   myDBFileList size = " + myDBFileList.size());
        return responseMap;
    }


    public Map getMDCountsGroupedByFileDate(String appId) throws NCASException
    {
        String METHOD_NAME = "getMDCountsGroupedByFileDate  ";
        _LOGGER.info(METHOD_NAME + "  Enter ");

        String mySql = getMDCountsGroupedByFileDateSQL(appId);
        _LOGGER.info(METHOD_NAME + "  mySql = " + mySql);      
        
        SelectMDCountGroupedByFileDate mySearch = new SelectMDCountGroupedByFileDate(getDataSource(), mySql);
        List mediaCountList = mySearch.execute(new Object[] {});
                 
        HashMap responseMap = new HashMap();         
        responseMap.put("status", new Boolean(true));
        responseMap.put("mediaCountList", mediaCountList);
        
        _LOGGER.info(METHOD_NAME + "  Exit  ");
        return responseMap;
    }


    public Map insertMDFileNames(List fileList,String appId) throws NCASException
    {
        String METHOD_NAME = "insertMDFileNames() ";
        _LOGGER.info(METHOD_NAME + "  Enter ");

        boolean status = false;
        int insCount = 0;
        
        String INSERT_PL_MEDIA_DOWNLOAD = "INSERT INTO "
                + getSchemaName()
                + ".PL_MEDIA_DOWNLOAD(APP_ID,CUSTOMER_ID,FILE_TYPE,FILE_DATE,CREATED_DATE,FILE_NAME,LAST_UPDATED_BY,LAST_UPDATED) VALUES(?,?,?,?,?,?,?,?)";
        _LOGGER.info(METHOD_NAME + "Insert SQL: " + INSERT_PL_MEDIA_DOWNLOAD);
        
        try
        {
            if (insertMediaDownloadSqlUpdate == null)
            {
                insertMediaDownloadSqlUpdate = new BatchSqlUpdate(
                        getDataSource(), INSERT_PL_MEDIA_DOWNLOAD);
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "APP_ID", Types.CHAR));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "CUSTOMER_ID", Types.VARCHAR));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "FILE_TYPE", Types.VARCHAR));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "FILE_DATE", Types.CHAR));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "CREATED_DATE", Types.DATE));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "FILE_NAME", Types.VARCHAR));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "LAST_UPDATED_BY", Types.VARCHAR));
                insertMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "LAST_UPDATED", Types.TIMESTAMP));
            }
            
            SimpleDateFormat simpleDateFormat = 
                new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
            String lastUpdated = 
                simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

            String createdDate = new Date(System.currentTimeMillis()).toString();
            String lastUpdateBy=null;
            if(appId.equals("BM")){
              lastUpdateBy = "BMAPMJOB"; // nobody else should be calling this api
            }
            else if(appId.equals("DD")){
            	lastUpdateBy = "DDAPMJOB";
            }
            else if(appId.equals("LB")){
            	lastUpdateBy = "LBAPMJOB";	
            }
            int size = fileList.size();
            _LOGGER.info(METHOD_NAME + " fileList size = " + size);
            for (int i = 0; i < size; i++)
            {
                MediaDownload bm = (MediaDownload) fileList.get(i);
                _LOGGER.info(METHOD_NAME + " inserting fileName = " + bm.getFileName());

                Object[] parameterValues = new Object[] { appId, 
                        bm.getCustomerId(),
                        bm.getFileType(), 
                        bm.getFileDate(),
                        createdDate,
                        bm.getFileName(),
                        lastUpdateBy, 
                        lastUpdated };
                insertMediaDownloadSqlUpdate.update(parameterValues);
                insCount++;
                if (insertMediaDownloadSqlUpdate != null)
                    insertMediaDownloadSqlUpdate.flush();
            }
     
            if (insCount > 0)
            {
                _LOGGER
                        .info("Insert PL media  Response logged successfully \n Number of Records inserted - "
                                + insCount);
                status = true;
            }
            
        }
        catch (Exception vamEx)
        {
            vamEx.printStackTrace();
            _LOGGER.debug("insertMediaDownload in VAM Failed \n"
                    + vamEx.getMessage());
            _LOGGER.error("insertMediaDownload in VAM Failed \n"
                    + vamEx.getMessage());
            throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                    MediaDownloadDAOImpl.class, vamEx);
        }
        
        Map responseMap = new HashMap();
        responseMap.put("status", new Boolean(status));
        responseMap.put("count", new Integer(insCount));
        
        return responseMap;
    }
    
    
    public Map deleteMDFileNames(List myMDList,String appId) throws NCASException
    {
        String METHOD_NAME = "deleteMDFileNames() ";
        _LOGGER.info(METHOD_NAME + "  Enter ");

        boolean status = false;
        int deleteCount = 0;
  
        String DELETE_PL_MEDIA_DOWNLOAD = 
            "DELETE FROM " + getSchemaName()
            + ".PL_MEDIA_DOWNLOAD WHERE FILE_NAME = ?"
            + " AND APP_ID= ?";

        try
        {
            if (deleteMediaDownloadSqlUpdate == null)
            {
                deleteMediaDownloadSqlUpdate = new BatchSqlUpdate(
                        getDataSource(), DELETE_PL_MEDIA_DOWNLOAD);
                deleteMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "FILE_NAME", Types.VARCHAR));
                deleteMediaDownloadSqlUpdate.declareParameter(new SqlParameter(
                        "APP_ID", Types.VARCHAR));
                deleteMediaDownloadSqlUpdate.compile();
            }
 
            for (int i = 0; i < myMDList.size(); i++)
            {
                MediaDownload md = (MediaDownload) myMDList.get(i);
                String fileName = md.getFileName();
                
                _LOGGER.info("  deleting  fileName = " + fileName);
                Object[] parameterValues = new Object[] { fileName, appId };
                _LOGGER.info("  parameterValues length = " + parameterValues.length);

                deleteMediaDownloadSqlUpdate.update(parameterValues);
                deleteCount++;
                if (deleteMediaDownloadSqlUpdate != null)
                    deleteMediaDownloadSqlUpdate.flush();
            }
            
            if (deleteCount > 0)
            {
                 status = true;
            }
        }
        catch (Exception vamEx)
        {
            _LOGGER.error(METHOD_NAME + "VAM Delete Failed", vamEx);

            throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                    MediaDownloadDAOImpl.class, vamEx);
        }

        Map responseMap = new HashMap();
        responseMap.put("status", new Boolean(status));
        responseMap.put("deleteCount", new Integer(deleteCount));
        
        _LOGGER.info(METHOD_NAME + "  Exit   deleteCount = " + deleteCount);
        return responseMap;
    }
    
     
    private String getMDFileNamesUsingFileDateSQL(String fromDate,String appId)
    {
        String mySql = null;

        mySql = "SELECT FILE_NAME FROM "
            + getSchemaName()
            + ".PL_MEDIA_DOWNLOAD WHERE FILE_DATE = '"
            + fromDate
            +"' AND APP_ID= '"+appId+ "'";
        
        return mySql;
    }
    
    
    private String getMDCountsGroupedByFileDateSQL(String appId)
    {
        String mySql = null;

        mySql = "SELECT FILE_DATE, COUNT(*)as MY_COUNT FROM "
            +getSchemaName()
            + ".PL_MEDIA_DOWNLOAD WHERE APP_ID='"
            +appId + "'"
            + "  GROUP BY FILE_DATE";
        
        return mySql;
    }
    
 
    public Map createMDEmailRecords(List emailAddressList, 
                                    MediaDownload md, 
                                    Long emailTransId,String appId) throws NCASException
    {
        String METHOD_NAME = "createMDEmailRecords() "+"for"+appId;
        _LOGGER.info(METHOD_NAME + "  Enter ");

        boolean status = false;

        Map responseMap = new HashMap();
        
        // get DWNLD_ID from Media Download Table for this file
        String mySql = getMDMediaDownloadIDSQL(md,appId);
        _LOGGER.info(METHOD_NAME + "  mySql = " + mySql);      

        SearchMediaDownloadUsingMD mySearch = new SearchMediaDownloadUsingMD(getDataSource(), mySql);
        List myDBFileList = mySearch.execute(new Object[] {});
        if (myDBFileList.size() == 1)
        {
            Long downloadId = (Long) myDBFileList.get(0);
            md.setDownloadId(downloadId); 
        }
        else
        {
            md.setDownloadId(0); // use default of 0
            _LOGGER.error(METHOD_NAME + "Number of Records returned should be 1 - size = "
                    + myDBFileList.size());
            _LOGGER.error(METHOD_NAME + "  for File Name  = " + md.getFileName());            
        }
        
        String INSERT_PL_MEDIA_EMAIL = "INSERT INTO " +
                        getSchemaName() + ".PL_MEDIA_EMAIL " +
                		"(DWNLD_ID, EMAIL_TRANS_ID, EMAIL_ADDRESS, CREATED_DATE," +
                		" PORTAL_LOGIN_ID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP) " +
                		"VALUES(?, ?, ?, ?, ?, ?, ?)";
        _LOGGER.info(METHOD_NAME + "Insert SQL: " + INSERT_PL_MEDIA_EMAIL);
        
        try
        {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
                    "yyyy-MM-dd-HH.mm.ss.SSS");
            String lastUpdated = simpleDateFormat.format(new Timestamp(System
                    .currentTimeMillis()));
            if (insertMediaEmailSqlUpdate == null)
            {
                insertMediaEmailSqlUpdate = new BatchSqlUpdate(getDataSource(),
                        INSERT_PL_MEDIA_EMAIL);
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "DWNLD_ID", Types.INTEGER));
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "EMAIL_TRANS_ID", Types.INTEGER));
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "EMAIL_ADDRESS", Types.VARCHAR));
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "CREATED_DATE", Types.DATE));
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "PORTAL_LOGIN_ID", Types.VARCHAR));
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "CREATED_TIMESTAMP", Types.VARCHAR));
                insertMediaEmailSqlUpdate.declareParameter(new SqlParameter(
                        "LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
            }

            int insCount = 0;
            int emailSize = emailAddressList.size();
            _LOGGER.info(METHOD_NAME + "  emailSize =  " + emailSize);

            String lastUpdateBy = null; // nobody else should be calling this api
            if(appId.equals("BM"))
            {
                lastUpdateBy = "BMAPMJOB"; 
            }
            else if(appId.equals("DD"))
            {
                lastUpdateBy = "DDAPMJOB";
            }
            else if(appId.equals("LB"))
            {
                lastUpdateBy = "LBAPMJOB";
            }
            
            for (int i = 0; i < emailSize; i++)
            {
                String emailAddress = (String) emailAddressList.get(i);
                
                Date createdDateStr = new Date(System.currentTimeMillis());
                String createdDatetostring = createdDateStr.toString();
                _LOGGER.info("createdDatetostring" + createdDatetostring);
                _LOGGER.info("lastUpdated:::" + lastUpdated);
                Object[] parameterValues = 
                    new Object[] { new Long(md.getDownloadId()),
                                   emailTransId, 
                                   emailAddress,
                                   createdDatetostring, 
                                   lastUpdateBy, 
                                   lastUpdated,
                                   lastUpdated};
                int myCount = insertMediaEmailSqlUpdate.update(parameterValues);
                if (insertMediaEmailSqlUpdate != null)
                    insertMediaEmailSqlUpdate.flush();
                insCount += myCount;
            }
            if (insCount > 0)
            {
                _LOGGER
                        .info("Insert PL media  Response logged successfully \n Number of Records inserted - "
                                + insCount);
                status = true;
            }
        }
        catch (Exception vamEx)
        {
            vamEx.printStackTrace();
            _LOGGER.debug("insertMediaDownload in VAM Failed \n"
                    + vamEx.getMessage());
            _LOGGER.error("insertMediaDownload in VAM Failed \n"
                    + vamEx.getMessage());
            throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                    MediaDownloadDAOImpl.class, vamEx);
        }
        
        _LOGGER.info(METHOD_NAME + "  Exit   status = " + status);

        responseMap.put("status", new Boolean(status));
        return responseMap;
    }
   

    public List getMDMediaDownloadID(MediaDownload md,String appId) throws NCASException
    {
        String METHOD_NAME = "getMDMediaDownloadID)  ";
        _LOGGER.info(METHOD_NAME + "  Enter  ");
        _LOGGER.info("Application Id:::"+appId); 
        String mySql = getMDMediaDownloadIDSQL(md,appId);
        _LOGGER.info(METHOD_NAME + "  mySql = " + mySql);      
        
        SearchMediaDownloadUsingMD mySearch = new SearchMediaDownloadUsingMD(getDataSource(), mySql);
        List myMDFileList = mySearch.execute(new Object[] {});
                        
        _LOGGER.info(METHOD_NAME + "  Exit   myMDFileList size = " + myMDFileList.size());
        return myMDFileList;
    }

    
    private String getMDMediaDownloadIDSQL(MediaDownload md,String appId)
    {
        String mySql = null;

        mySql = "SELECT DWNLD_ID FROM "
            + getSchemaName()
            + ".PL_MEDIA_DOWNLOAD WHERE CUSTOMER_ID = '"
            + md.getCustomerId()
            + "'"
            + " AND FILE_NAME = '"
            + md.getFileName()
            + "'"
            + " AND APP_ID='"+appId+"'";
        return mySql;
    }
 
 
    public Map selectAllMediaDownload(String customerId, String fromDate,
            String toDate,String appId) throws NCASException
    {
        String myQuery = returnQuery(customerId, fromDate, toDate,appId);
        _LOGGER.info("selectAllMediaDownload()  SELECT SQL is After:::" + myQuery);
        Map allMediaMap = new HashMap();
       
        SelectAllMediaDownload selectAllMediaDownload = new SelectAllMediaDownload(getDataSource(), myQuery);
        List myMDList = selectAllMediaDownload.execute(new Object[] {});
        _LOGGER.info("customerId :::" + customerId);
        _LOGGER.info("fromDate :::" + fromDate);
        _LOGGER.info("toDate :::" + toDate);
        _LOGGER.info("appId:::"+appId);
        _LOGGER.info("Exiting selectBillingMetricsDetails");

        allMediaMap.put("mediadownload", myMDList);
        return allMediaMap;
    }

    
    private String returnQuery(String customerId, String fromDate, String toDate,String appId)
    {
        String temp = null;
        if (fromDate != null)
            temp = "SELECT DWNLD_ID, CUSTOMER_ID, FILE_TYPE, FILE_DATE, CREATED_DATE, FILE_NAME ,APP_ID FROM "
                    + getSchemaName()
                    + ".PL_MEDIA_DOWNLOAD WHERE CUSTOMER_ID = '"
                    + customerId
                    + "' AND FILE_DATE >= '"
                    + fromDate
                    + "' AND FILE_DATE <= '" + toDate +"' AND APP_ID= '"+appId+ "'"+" ORDER BY FILE_DATE DESC";
        else
            temp = "SELECT DWNLD_ID, CUSTOMER_ID, FILE_TYPE, FILE_DATE, CREATED_DATE, FILE_NAME ,APP_ID FROM "
                    + getSchemaName()
                    + ".PL_MEDIA_DOWNLOAD WHERE CUSTOMER_ID = '"
                    + customerId
                    +"' AND APP_ID= '"+appId
                    + "'"+" ORDER BY FILE_DATE DESC";
        return temp.toString();
    }
 

    public Map getMDMinFileDate(String appId) throws NCASException
    {
        String METHOD_NAME = "getMDMinFileDate()  ";
        _LOGGER.info(METHOD_NAME + "  Enter  ");

        boolean status = false;
        Map responseMap = new HashMap();

        String mySql = "SELECT MIN(FILE_DATE) AS MIN_DATE " 
            + "  FROM "
            + getSchemaName() 
            + ".PL_MEDIA_DOWNLOAD WHERE APP_ID='"
            +appId+ "'";
        
        _LOGGER.info(METHOD_NAME + "  mySql = " + mySql);      
        
        SearchMDMinFileDate mySearch = new SearchMDMinFileDate(getDataSource(), mySql);
        List myList = mySearch.execute(new Object[] {});
        
        String minFileDate = (String) myList.get(0);
                 
        responseMap.put("minFileDate", minFileDate);
        responseMap.put("status", new Boolean(status));
        _LOGGER.info(METHOD_NAME + "  Exit   myList size = " + myList.size());
        return responseMap;
    }

}


abstract class AbstractSelect extends MappingSqlQuery
{
    public AbstractSelect(DataSource dataSource, String sql)
    {
        super(dataSource, sql);
    }
}


class SearchMDUsingFileDate extends AbstractSelect
{
    public SearchMDUsingFileDate(DataSource dataSource, String mySql)
    {
        super(dataSource, mySql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        String METHOD_NAME = "mapRow() ";
                    
        String fileName = rs.getString("FILE_NAME");
                                           
        return fileName;
    }       
}


class SelectAllMediaDownload extends AbstractSelect
{
    public SelectAllMediaDownload(DataSource dataSource, String myQuery)
    {
        super(dataSource, myQuery);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        long downloadId = rs.getLong("DWNLD_ID");
        String customerId = rs.getString("CUSTOMER_ID");
        String fileType = rs.getString("FILE_TYPE");
        String fileDate = rs.getString("FILE_DATE");
        String createdDate = rs.getString("CREATED_DATE");
        String fileName = rs.getString("FILE_NAME");
 
        MediaDownload md = new MediaDownload();
        md.setDownloadId(downloadId);
        md.setCustomerId(customerId);
        md.setFileType(fileType);
        md.setFileDate(fileDate);
        md.setCreatedDate(createdDate);
        md.setFileName(fileName);
        
        return md;
    }
}


class SearchMediaDownloadUsingMD extends AbstractSelect
{
    public SearchMediaDownloadUsingMD(DataSource dataSource, String mySql)
    {
        super(dataSource, mySql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        String METHOD_NAME = "mapRow() ";
                    
        Long downloadId = rs.getLong("DWNLD_ID");
                                           
        return downloadId;
    }       
}


class SelectMDCountGroupedByFileDate extends AbstractSelect
{
    public SelectMDCountGroupedByFileDate(DataSource dataSource, String mySql)
    {
        super(dataSource, mySql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        String fileDate = rs.getString("FILE_DATE"); 
        long count = rs.getLong("MY_COUNT");     
        
        MediaCount mc = new MediaCount();
        mc.setFileDate(fileDate);
        mc.setCount(count);
        
        return mc;
    }
}


class SearchMDMinFileDate extends AbstractSelect
{
    public SearchMDMinFileDate(DataSource dataSource, String mySql)
    {
        super(dataSource, mySql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        String fileDate = rs.getString("MIN_DATE"); 
        
        return fileDate;
    }
}

