package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.object.SqlUpdate;
import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.*;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncasbosi.beans.EMediaMsg;

public class EMediaMsgDAOImpl
    extends NCASSpringJDBCBase implements
    EMediaMsgInterface, NCASBOSIConstants {
  private static final Logger _LOGGER = Logger.getLogger(EMediaMsgDAOImpl.class);
  private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";
  private SqlUpdate insertEMediaMsgSqlUpdate = null;
  private SqlUpdate updateEMediaMsgSqlUpdate = null;
  private SqlUpdate deleteEMediaMsgSqlUpdate = null;
  /* INSERT, UPDATE, DELETE, SELECT for EMEDIA_MSG Table  -  START */
  /**
   *
   * @param eMediaMsg EMediaMsg
   * @return Map
   * @throws NCASException
   */    public Map doEMediaMsg(String operation, EMediaMsg eMediaMsg) throws NCASException {	  Map returnMap;	  if(operation.equalsIgnoreCase("I"))		  returnMap = insertEMediaMsg(eMediaMsg);	  else if(operation.equalsIgnoreCase("U"))		  returnMap = updateEMediaMsg(eMediaMsg);	  else if(operation.equalsIgnoreCase("D"))		  returnMap = deleteEMediaMsg(eMediaMsg);	  else if(operation.equalsIgnoreCase("S"))		  returnMap = selectEMediaMsg(eMediaMsg);	  else returnMap = selectALL_EMediaMsg();	  	  	  	  return returnMap;  }  
  public Map insertEMediaMsg(EMediaMsg eMediaMsg) throws NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String msgId = eMediaMsg.getMsgId();
    String msgDescription = eMediaMsg.getMsgDescription();
    String INSERT_EMEDIA_MSG_LINK = "INSERT INTO " + getSchemaName() +
        ".EMEDIA_MSG(MSG_ID,MSG_DESCRIPTION) VALUES(?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_EMEDIA_MSG_LINK);
    try {
      if (insertEMediaMsgSqlUpdate == null) {
        insertEMediaMsgSqlUpdate = new SqlUpdate(jdbcTemplate.
                                                 getDataSource(),
                                                 INSERT_EMEDIA_MSG_LINK);
        insertEMediaMsgSqlUpdate.declareParameter(new SqlParameter(
            "MSG_ID", Types.VARCHAR));
        insertEMediaMsgSqlUpdate.declareParameter(new SqlParameter(
            "MSG_DESCRIPTION", Types.VARCHAR));
        insertEMediaMsgSqlUpdate.compile();
      }
      Object[] parameterValues = new Object[] {
          msgId, msgDescription};
      _LOGGER.info("****************parameterValues" + parameterValues);
      int insCount = insertEMediaMsgSqlUpdate.update(parameterValues);
      if (insCount > 0) {
        _LOGGER.info(
            "Insert EMediaMsg Response logged successfully \n Number of Records inserted - " +
            insCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertEMediaMsgSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("insertEMediaMsgSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertEMediaMsg");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param eMediaMsg EMediaMsg
   * @return Map
   * @throws NCASException
   */
  public Map deleteEMediaMsg(EMediaMsg eMediaMsg) throws NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String msgId = eMediaMsg.getMsgId();
    String DELETE_EMEDIA_MSG = "DELETE FROM " + getSchemaName() +
        ".EMEDIA_MSG WHERE MSG_ID = ?";
    _LOGGER.info("Delete SQL: " + DELETE_EMEDIA_MSG);
    try {
      if (deleteEMediaMsgSqlUpdate == null) {
        deleteEMediaMsgSqlUpdate = new SqlUpdate(jdbcTemplate.
                                                 getDataSource(),
                                                 DELETE_EMEDIA_MSG);
        deleteEMediaMsgSqlUpdate.declareParameter(new SqlParameter(
            "MSG_ID", Types.VARCHAR));
        deleteEMediaMsgSqlUpdate.compile();
      }
      Object[] parameterValues = new Object[] {
          msgId};
      int deleteCount = deleteEMediaMsgSqlUpdate.update(
          parameterValues);
      if (deleteCount > 0) {
        _LOGGER.info(
            "Delete EMedia Msg Response logged successfully \n Number of Records deleted - " +
            deleteCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("deleteEMediaMsgSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("deleteEMediaMsgSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting deleteEMediaMsg");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param eMediaMsg EMediaMsg
   * @return Map
   * @throws NCASException
   */

  public Map updateEMediaMsg(EMediaMsg eMediaMsg) throws NCASException {
    boolean status = false;
    Map responseMap = new HashMap();
    String msgId = eMediaMsg.getMsgId();
    String msgDescription = eMediaMsg.getMsgDescription();
    String UPDATE_EMEDIA_MSG_LINK = "UPDATE " + getSchemaName() +
        ".EMEDIA_MSG SET MSG_ID = ?,MSG_DESCRIPTION = ?";
    _LOGGER.info("Update SQL: " + UPDATE_EMEDIA_MSG_LINK);
    try {
      if (updateEMediaMsgSqlUpdate == null) {
        updateEMediaMsgSqlUpdate = new SqlUpdate(jdbcTemplate.
                                                 getDataSource(),
                                                 UPDATE_EMEDIA_MSG_LINK);
        updateEMediaMsgSqlUpdate.declareParameter(new SqlParameter(
            "MSG_ID",
            Types.VARCHAR));
        updateEMediaMsgSqlUpdate.declareParameter(new SqlParameter(
            "MSG_DESCRIPTION", Types.VARCHAR));
        updateEMediaMsgSqlUpdate.compile();
      }
      Object[] parameterValues = new Object[] {
          msgId, msgDescription};
      int updateCount = updateEMediaMsgSqlUpdate.update(
          parameterValues);
      if (updateCount > 0) {
        _LOGGER.info(
            "Update EMedia Msg Response logged successfully \n Number of Records updated - " +
            updateCount);
        status = true;
      }
      else {
        Boolean satusObj = (Boolean) insertEMediaMsg(
            eMediaMsg).get("status");
        status = satusObj.booleanValue();
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("updateEMediaMsgSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("updateEMediaMsgSqlUpdate in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaEditDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting updateEMediaMsg");
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

  /**
   *
   * @param eMediaMsg EMediaMsg
   * @return Map
   * @throws NCASException
   */
  public Map selectEMediaMsg(EMediaMsg eMediaMsg) throws
      NCASException {
    final Map returnMap = new HashMap(); //List that hold all records of data.
    String msgId = eMediaMsg.getMsgId();
    String SELECT_EMEDIA_MSG = "SELECT MSG_ID, MSG_DESCRIPTION FROM " +
        getSchemaName() +
        ".EMEDIA_MSG WHERE MSG_ID ='" + msgId + "'";
    _LOGGER.info("Select SQL: " + SELECT_EMEDIA_MSG);
    try {
      jdbcTemplate.query(SELECT_EMEDIA_MSG, new RowCallbackHandler() {
        public void processRow(ResultSet rs) throws SQLException {

          String key = rs.getString("MSG_ID");
          returnMap.put(key, rs.getString("MSG_DESCRIPTION"));

        }
      });
    }
    catch (Exception vamEx) {
      _LOGGER.debug("selectEMediaMsg in VAM Failed \n" + vamEx.getMessage());
      _LOGGER.error("selectEMediaMsg in VAM Failed \n" + vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaMsgDAOImpl.class, vamEx);
    }
    _LOGGER.debug("returnMap" + returnMap);
    return returnMap;
  }
  /**
   * 
   * @return List
   * @throws NCASException
   */
  public Map selectALL_EMediaMsg() throws
      NCASException {
    final  Map returnMap = new HashMap();
    String SELECT_EMEDIA_MSG = "SELECT MSG_ID, MSG_DESCRIPTION FROM " +
        getSchemaName() + ".EMEDIA_MSG";
    _LOGGER.info("Select SQL: " + SELECT_EMEDIA_MSG);
    try {
      jdbcTemplate.query(SELECT_EMEDIA_MSG, new RowCallbackHandler() {
        public void processRow(ResultSet rs) throws SQLException {
          String key = rs.getString("MSG_ID");
          returnMap.put(key, rs.getString("MSG_DESCRIPTION"));
        }
      });
    }
    catch (Exception vamEx) {
      _LOGGER.debug("selectALL_EMediaMsg in VAM Failed \n" +
                    vamEx.getMessage());
      _LOGGER.error("selectALL_EMediaMsg in VAM Failed \n" +
                    vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
                              EMediaMsgDAOImpl.class, vamEx);
    }
    _LOGGER.debug("returnMap" + returnMap);
    return returnMap;
  }
  /* INSERT, UPDATE, DELETE, SELECT for EMEDIA_MSG Table  -  END */

  private String getSchemaName() {
    String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
    //String schemaName = "BMGVZS";
    _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
    return schemaName;
  }
}
