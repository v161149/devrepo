package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.ServiceInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAllServiceIdInfoResultSetRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetAllServiceIdInfoResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetAllServiceIdInfoResultSetRowMapper::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		ServiceInfo serviceInfo = new ServiceInfo();
		
		String serviceId = rs.getString("SERVICE_ID");
		String displayText = rs.getString("SVC_DISPLAY_TEXT");
		String serviceIdType = rs.getString("SERVICE_ID_TYPE");		
		String serviceIdStatus = String.valueOf(rs.getInt("SVCID_STATUS"));
		String serviceIdStatusDesc = rs.getString("SVCID_STATUS_DESC");
		String lodNeeded = rs.getString("LOD_NEEDED");
		String orderNeeded = rs.getString("ORDER_NEEDED");
		String routeBoNeeded = rs.getString("ROUTE_BO_NEEDED");
		String claimNeeded = rs.getString("CLAIM_NEEDED");
		
		if (serviceId != null) {
			serviceInfo.setServiceId(serviceId.trim());
		}
		if (CommonUtil.isNotNull(displayText)) {
			serviceInfo.setDisplayText(displayText.trim());
		}
		if (CommonUtil.isNotNull(serviceIdType)) {
			serviceInfo.setServiceIdType(serviceIdType.trim());
		}		
		if (serviceIdStatus != null) {
			serviceInfo.setServiceIdStatus(serviceIdStatus.trim());
		}
		if (serviceIdStatusDesc != null) {
			serviceInfo.setServiceIdStatusText(serviceIdStatusDesc.trim());
		}
		if (lodNeeded != null) {
			serviceInfo.setLodNeeded(lodNeeded.trim());
		}
		if (orderNeeded != null) {
			serviceInfo.setOrderNeeded(orderNeeded.trim());
		}
		if (routeBoNeeded != null) {
			serviceInfo.setRouteBONeeded(routeBoNeeded.trim());
		}
		if (claimNeeded != null) {
			serviceInfo.setClaimNeeded(claimNeeded.trim());
		}
		return serviceInfo;
	}
}
