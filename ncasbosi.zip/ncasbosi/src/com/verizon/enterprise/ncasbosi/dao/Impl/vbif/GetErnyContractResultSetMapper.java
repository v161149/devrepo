package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.vbif.ErnyContract;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.util.DateUtility;

public class GetErnyContractResultSetMapper implements RowMapper
{
    static private final Logger _LOGGER = Logger.getLogger(GetErnyContractResultSetMapper.class);

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        _LOGGER.debug("Inside GetErnyContractResultSetMapper::mapRow rowNum - " + rowNum);
        CommonUtil.printMetaDataInfo(rs.getMetaData());
        
        ErnyContract record = new ErnyContract();
        record.setSourceAcctId(rs.getString("SOURCE_ACCT_ID"));
	    record.setVamsSystemId(rs.getString("VAMS_SYSTEM_ID"));
	    record.setContractId(rs.getString("CONTRACT_ID"));
	    record.setContractStDt(rs.getDate("CONTRACT_ST_DT").toString());
	    record.setApplicationNo(rs.getString("APPLICATION_NO"));       
        return record;
    }
}
