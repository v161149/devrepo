package com.verizon.enterprise.ncasbosi.dao.Impl.permissions;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.object.SqlUpdate;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Iterator;
import java.util.Map;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncasbosi.beans.AdminPermission;

import com.verizon.enterprise.ncasbosi.dao.Impl.emedia.EMediaEditDAOImpl;
import com.verizon.enterprise.ncasbosi.dao.Interface.permissions.AdminPermissionInterface;

public class AdminPermissionDAOImpl extends NCASSpringJDBCBase implements AdminPermissionInterface, NCASBOSIConstants {

private static final Logger _LOGGER = Logger.getLogger(AdminPermissionDAOImpl.class);

private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";

private SqlUpdate insertAdminPermissionSqlUpdate = null;

private SqlUpdate updateAdminPermissionSqlUpdate = null;

private SqlUpdate deleteAdminPermissionSqlUpdate = null;

private String htmlString ="";

private int rowCoumt = 1;

private boolean recordsReturn = false;


/* INSERT, UPDATE, DELETE, SELECT for PL_ADMIN_USER Table  -  START */


public Map doAdminPermission(String operation,AdminPermission adminPermission) throws NCASException {
  Map returnMap;
  if(operation.equalsIgnoreCase("I"))
	  returnMap = insertAdminPermission(adminPermission);
  else if(operation.equalsIgnoreCase("U"))
	  returnMap = updateAdminPermission(adminPermission);
  else if(operation.equalsIgnoreCase("D"))
	  returnMap = deleteAdminPermission(adminPermission);
  else if(operation.equalsIgnoreCase("S"))
	  returnMap = selectAdminPermission(adminPermission);
  else if(operation.equalsIgnoreCase("H"))
	  returnMap = selectINV_AdminPermission(adminPermission);
  else returnMap = selectALL_AdminPermission();
  	  	  
  return returnMap;
}

public Map selectAllAdminPermission() throws NCASException {
	 final Map responseMap = new HashMap(); 
	 String SELECT_ALL_ADMIN_PERMISSIONS = "SELECT USER_ID, PERMISSION FROM " + getSchemaName() +".PL_ADMIN_USER";
	 _LOGGER.info("Select SQL: " + SELECT_ALL_ADMIN_PERMISSIONS);
	    try {
	      jdbcTemplate.query(SELECT_ALL_ADMIN_PERMISSIONS, new RowCallbackHandler() {
	        public void processRow(ResultSet rs) throws SQLException {
	          String key = rs.getString("USER_ID");
	          String permissions = rs.getString("PERMISSION");
	          String totString = key+"-"+permissions;
	          responseMap.put(rs.getRow(), totString);
	        }
	      });
	    }
	    catch (Exception vamEx) {
	      _LOGGER.debug("selectALL_AdminPermission in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("selectALL_AdminPermission in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,AdminPermissionDAOImpl.class, vamEx);
	    }
	    _LOGGER.debug("responseMap" + responseMap);
	    return responseMap;
}

public Map insertAdminPermission(AdminPermission adminPermission) throws NCASException {
	boolean status = false;
   String user = adminPermission.getUserId();
   String lastUpdatedBy = adminPermission.getUpdatedBy();
   String permissions = adminPermission.getPermission();
   
   //added by mir mohammed
   if(permissions.equals("S") || permissions.equals("A")){
	    Map allPerms = selectAllAdminPermission();
	    int length = allPerms.entrySet().size();
	    for(int i = 1; i < length+1; i++){
	    	String totString = (String)allPerms.get(i);
	    	String[] temp = totString.split("-");
	    	String uid = temp[0];
	    	String pm = temp[1];
	    	if(uid.trim().equalsIgnoreCase(user.trim())){
	    		if(pm.trim().equals("R") || (permissions.equals("S") && pm.trim().equals("A")) || (permissions.equals("A") && pm.trim().equals("S"))){
		    		deleteAdminPermission(adminPermission);
		    		break;
		    	}
	    	}
	    }
   }
   //added by mir mohammed
   
   //String module = CommonUtil.getCSVStringFromList(adminPermission.getModules());
   List list = adminPermission.getModules();
   
   Map responseMap = new HashMap();
   String INSERT_ADMIN_PERMISSIONS = "INSERT INTO " + getSchemaName() + ".PL_ADMIN_USER(USER_ID,PERMISSION,MODULE,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
   _LOGGER.info("Insert SQL: " + INSERT_ADMIN_PERMISSIONS);

   try {
   	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
		if(list== null || (list!=null && list.isEmpty()))
			list.add("Emedia");
		Iterator it = list.iterator();
		while (it.hasNext()) {
			String  module = (String)it.next();
	
	    	if (insertAdminPermissionSqlUpdate == null) {
	    	  insertAdminPermissionSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),INSERT_ADMIN_PERMISSIONS);
	    	  insertAdminPermissionSqlUpdate.declareParameter(new SqlParameter("USER_ID", Types.CHAR));
	    	  insertAdminPermissionSqlUpdate.declareParameter(new SqlParameter("PERMISSION", Types.CHAR));
	    	  insertAdminPermissionSqlUpdate.declareParameter(new SqlParameter("MODULE", Types.CHAR));
	    	  insertAdminPermissionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
	    	  insertAdminPermissionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
	       }
	
	      Object[] parameterValues = new Object[] {user, permissions, module, lastUpdated, lastUpdatedBy};
	      int insCount = insertAdminPermissionSqlUpdate.update(parameterValues);
	      
	      if (insCount > 0) {
	        _LOGGER.info( "Insert ADMIN PERMISSIONS  Response logged successfully \n Number of Records inserted - " + insCount);
	        status = true;
	      }
		}
   }
   catch (Exception vamEx) {
     vamEx.printStackTrace();
     _LOGGER.debug("insertAdminPermissionSqlUpdate in VAM Failed \n" +vamEx.getMessage());
     _LOGGER.error("insertAdminPermissionSqlUpdate in VAM Failed \n" +vamEx.getMessage());
     throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, AdminPermissionDAOImpl.class, vamEx);
   }
   _LOGGER.info("Exiting insertAdminPermission" + responseMap.toString());
   responseMap.put("status", new Boolean(status));
   return responseMap;
 }

public Map updateAdminPermission(AdminPermission adminPermission) throws NCASException {
	Map responseMap = new HashMap();
	responseMap = deleteAdminPermission(adminPermission);
	responseMap = insertAdminPermission(adminPermission);
	/*
	 * boolean status = false;
    String user = adminPermission.getUserId();
    String lastUpdatedBy = adminPermission.getUpdatedBy();
    String permissions = adminPermission.getPermission();
    //String module = CommonUtil.getCSVStringFromList(adminPermission.getModules());
    List list = adminPermission.getModules();
    
    Map responseMap = new HashMap();
    String UPDATE_ADMIN_PERMISSIONS = "UPDATE " + getSchemaName() +".PL_ADMIN_USER SET USER_ID = ?,PERMISSION = ?,MODULE = ?,LAST_UPDATED = ?,LAST_UPDATED_BY = ?";
    _LOGGER.info("Update SQL: " + UPDATE_ADMIN_PERMISSIONS);

    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
		
		Iterator it = list.iterator();
		while (it.hasNext()) {
			String  module = (String)it.next();
			
	    	if (updateAdminPermissionSqlUpdate == null) {
	    		updateAdminPermissionSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),UPDATE_ADMIN_PERMISSIONS);
	    		updateAdminPermissionSqlUpdate.declareParameter(new SqlParameter("USER_ID", Types.CHAR));
	    		updateAdminPermissionSqlUpdate.declareParameter(new SqlParameter("PERMISSION", Types.CHAR));
	    		updateAdminPermissionSqlUpdate.declareParameter(new SqlParameter("MODULE", Types.CHAR));
	    		updateAdminPermissionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
	    		updateAdminPermissionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
	      }
	
	      Object[] parameterValues = new Object[] {user, permissions, module, lastUpdated, lastUpdatedBy};
	      int insCount = updateAdminPermissionSqlUpdate.update(parameterValues);
	      
		      if (insCount > 0) {
		        _LOGGER.info( "Update ADMIN PERMISSIONS  Response logged successfully \n Number of Records inserted - " + insCount);
		        status = true;
		      } else {
		          Boolean satusObj = (Boolean) insertAdminPermission(adminPermission).get("status");
		          status = satusObj.booleanValue();
		      }
		}
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("updateAdminPermissionSqlUpdate in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("updateAdminPermissionSqlUpdate in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, AdminPermissionDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting updateAdminPermission" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
    */
	return responseMap;
}
public Map deleteAdminPermission(AdminPermission adminPermission) throws NCASException {
	 boolean status = false;
	 Map responseMap = new HashMap();
	 String user = adminPermission.getUserId();
	 String DELETE_ADMIN_PERMISSIONS = "DELETE FROM " + getSchemaName() +".PL_ADMIN_USER WHERE USER_ID = ?";

	 _LOGGER.info("Delete SQL: " + DELETE_ADMIN_PERMISSIONS);
	    try {
	      if (deleteAdminPermissionSqlUpdate == null) {
	    	  deleteAdminPermissionSqlUpdate = new SqlUpdate(jdbcTemplate.getDataSource(),DELETE_ADMIN_PERMISSIONS);
	    	  deleteAdminPermissionSqlUpdate.declareParameter(new SqlParameter("USER_ID", Types.VARCHAR));
	    	  deleteAdminPermissionSqlUpdate.compile();
	      }
	      Object[] parameterValues = new Object[] {user};
	      int deleteCount = deleteAdminPermissionSqlUpdate.update(parameterValues);
	      if (deleteCount > 0) {
	        _LOGGER.info("Delete ADMIN PERMISSIONS logged successfully \n Number of Records deleted - " + deleteCount);
	        status = true;
	      }
	    }
	    catch (Exception vamEx) {
	      vamEx.printStackTrace();
	      _LOGGER.debug("deleteAdminPermissionSqlUpdate in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("deleteAdminPermissionSqlUpdate in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, AdminPermissionDAOImpl.class, vamEx);

	    }
	    _LOGGER.info("Exiting deleteAdminPermission");
	    responseMap.put("status", new Boolean(status));
	    return responseMap;
}
public Map selectAdminPermission(AdminPermission adminPermission) throws NCASException {
	 final Map responseMap = new HashMap();
	 final Map resMap = new HashMap();
	 String user = adminPermission.getUserId();
	 final List modules = new ArrayList();
	 String SELECT_ADMIN_PERMISSIONS = "SELECT USER_ID, PERMISSION, MODULE, LAST_UPDATED_BY FROM " + getSchemaName() +".PL_ADMIN_USER WHERE USER_ID = '" + user + "'";
	 _LOGGER.info("Select SQL: " + SELECT_ADMIN_PERMISSIONS);
	    try {

	      jdbcTemplate.query(SELECT_ADMIN_PERMISSIONS, new RowCallbackHandler() {

	    	  public void processRow(ResultSet rs) throws SQLException {
	        	String key = rs.getString("USER_ID");
	        	String permissions = rs.getString("PERMISSION");
	            modules.add((String)rs.getString("MODULE"));
	            String lastUpdatedBy =  rs.getString("LAST_UPDATED_BY");
	            responseMap.put(key, new AdminPermission(key, permissions, modules, lastUpdatedBy));	           
	        }
	      });
	    }
	    catch (Exception vamEx) {
	      _LOGGER.debug("selectAdminPermission in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("selectAdminPermission in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,AdminPermissionDAOImpl.class, vamEx);
	    }
	    _LOGGER.debug("responseMap" + responseMap);
	    if(responseMap.isEmpty()) {
	    	responseMap.put("STATUS", "FALSE");
	    }else {
	    	responseMap.put("STATUS", "TRUE");
	    }	 		 	    
	    return responseMap;
}
public Map selectALL_AdminPermission() throws NCASException {
	 final Map responseMap = new HashMap(); 
	 String SELECT_ALL_ADMIN_PERMISSIONS = "SELECT DISTINCT USER_ID, PERMISSION, LAST_UPDATED_BY FROM " + getSchemaName() +".PL_ADMIN_USER";
	 _LOGGER.info("Select SQL: " + SELECT_ALL_ADMIN_PERMISSIONS);
	    try {
	      jdbcTemplate.query(SELECT_ALL_ADMIN_PERMISSIONS, new RowCallbackHandler() {
	        public void processRow(ResultSet rs) throws SQLException {
	          String key = rs.getString("USER_ID");
	          String permissions = rs.getString("PERMISSION");
	          String lastUpdatedBy =  rs.getString("LAST_UPDATED_BY");
	          responseMap.put(key, new AdminPermission(key, permissions, new ArrayList(), lastUpdatedBy));
	        }
	      });
	      responseMap.put("MODULELIST", selectALL_AdminModules());
	    }
	    catch (Exception vamEx) {
	      _LOGGER.debug("selectALL_AdminPermission in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("selectALL_AdminPermission in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,AdminPermissionDAOImpl.class, vamEx);
	    }
	    _LOGGER.debug("responseMap" + responseMap);
	    return responseMap;
}
public List selectALL_AdminModules() throws NCASException { 
	 final List modules = new ArrayList();
	 String SELECT_ALL_ADMIN_MODULE = "SELECT DISTINCT MODULE FROM " + getSchemaName() +".PL_ADMIN_USER";
	 _LOGGER.info("Select SQL: " + SELECT_ALL_ADMIN_MODULE);
	    try {
	      jdbcTemplate.query(SELECT_ALL_ADMIN_MODULE, new RowCallbackHandler() {
	        public void processRow(ResultSet rs) throws SQLException {
	          modules.add(rs.getString("MODULE"));
	        }
	      });
	    }
	    catch (Exception vamEx) {
	      _LOGGER.debug("selectALL_AdminModules in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("selectALL_AdminModules in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,AdminPermissionDAOImpl.class, vamEx);
	    }
	    _LOGGER.debug("modules" + modules);
	    return modules;
}
public Map selectINV_AdminPermission(AdminPermission adminPermission) throws NCASException {
	 final Map responseMap = new HashMap(); 
	 Map returnMap = new HashMap(); 
	 String user = adminPermission.getUserId();
	 List  list = adminPermission.getModules();
	 Iterator it = list.iterator();
	 String module = "";
	 if (it.hasNext()) {
	    module = (String)it.next();	 
	 }
	 if(module.equals(""))
		 returnMap = selectAdminPermission(adminPermission);
	 else {
		 String SELECT_INV_PERMISSIONS = "SELECT USER_ID, PERMISSION FROM " + getSchemaName() +".PL_ADMIN_USER WHERE USER_ID = '" + user + "' AND MODULE = '"+ module +"'";
		 _LOGGER.info("Select SQL: " + SELECT_INV_PERMISSIONS);
		    try {
	
		      jdbcTemplate.query(SELECT_INV_PERMISSIONS, new RowCallbackHandler() {
		        public void processRow(ResultSet rs) throws SQLException {
		        	String key = rs.getString("USER_ID");
		        	String permissions = rs.getString("PERMISSION");
		            responseMap.put(key, permissions);
		        }
		      });
		    }
		    catch (Exception vamEx) {
		      _LOGGER.debug("selectAdminPermission in VAM Failed \n" +vamEx.getMessage());
		      _LOGGER.error("selectAdminPermission in VAM Failed \n" +vamEx.getMessage());
		      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,AdminPermissionDAOImpl.class, vamEx);
		    }
		    _LOGGER.debug("responseMap" + responseMap);
		    if(responseMap.isEmpty()) {
		    	returnMap.put("STATUS", "FALSE");
		    }else {
		    	returnMap.put("STATUS", "TRUE");
		    }	 		    
	 	}

	    return returnMap;
}



public Map getAdminEntitlement(Map inputMap) throws RemoteException,NCASException {
	
	_LOGGER.info("In side of GetAdminEntitlement");
	final Map responseMap = new HashMap(); 
	String portalType = (String)inputMap.get("portalType"); 
	String login = (String)inputMap.get("loginID");
	String ban = (String)inputMap.get("ban");
	String man =  (String)inputMap.get("man");

	
	String queryvec ="SELECT STR.* FROM "+getSchemaName()+".STRUCTURES_T STR WHERE STR.REPORT_ID_TS IN (SELECT MAX(TB1.REPORT_ID_TS) FROM "+getSchemaName()+".STRUCTURES_T TB1 WHERE TB1.ELEMENT_LVL = 0 AND TB1.ELEMENT_TYPE = 'US' AND TB1.ELEMENT_OID IN ( SELECT DISTINCT TB1.USER_OID FROM "+getSchemaName()+".USER_PROFILE TB1 LEFT OUTER JOIN "+getSchemaName()+".GROUP_USER_MAP TB2 ON TB1.USER_OID = TB2.USER_OID WHERE TB1.LOGIN_ID = '"+login.toUpperCase()+"' ))";
	String queryvbc ="SELECT STR.* FROM "+getSchemaName()+".STRUCTURES_T STR WHERE STR.REPORT_ID_TS IN (SELECT MAX(TB1.REPORT_ID_TS) FROM "+getSchemaName()+".STRUCTURES_T TB1 WHERE TB1.ELEMENT_LVL = 0 AND TB1.ELEMENT_TYPE = 'SS' AND TB1.ELEMENT_OID IN ( SELECT DISTINCT TB1.USER_OID FROM "+getSchemaName()+".USER_PROFILE TB1 LEFT OUTER JOIN "+getSchemaName()+".GROUP_USER_MAP TB2 ON TB1.USER_OID = TB2.USER_OID WHERE TB1.LOGIN_ID = '"+login.toUpperCase()+"' ))";
	String banquery=  " AND (STR.BAN like '";
	String manquery=  " STR.MAN like '";
	String finalQuery ="";
	rowCoumt = 1;
	htmlString ="<table cellspacing='0' cellpadding='0'  border='1' class='dataTbl' width='1100'>" +
			"<tr><th>ROW-NUM</th><th>ELEMENT_NAME</th><th>ELEMENT_TYPE</th><th>ELEMENT_OID</th><th>ELEMENT_LVL</th>" +
			"<th>LVL_0_TYPE</th><th>LVL_0_OID</th><th>LVL_1_TYPE</th><th>LVL_1_OID</th>" +
			"<th>LVL_2_TYPE</th><th>LVL_2_OID</th><th>LVL_3_TYPE</th><th>LVL_3_OID</th>" +
			"<th>LVL_4_TYPE</th><th>LVL_4_OID</th><th>LVL_5_TYPE</th><th>LVL_5_OID</th>" +
			"<th>LVL_6_TYPE</th><th>LVL_6_OID</th><th>MAN</th><th>BAN</th>" +
			"<th>OSID</th><th>WTN</th><th>CIRCUIT_ID</th><th>VALID_IND</th>" +
			"<th>USER_OID</th><th>ENTITLEMENT_LVL</th><th>VERIFIED</th><th>ACCT_ALIAS</th>" +
			"<th>LVL_0_NAME</th><th>LVL_1_NAME</th><th>LVL_2_NAME</th><th>LVL_3_NAME</th>" +
			"<th>LVL_4_NAME</th><th>LVL_5_NAME</th><th>LVL_6_NAME</th></tr>";
	
	_LOGGER.info("inputMap -->"+inputMap);
	
	if(portalType.equals("VEC"))
		finalQuery = queryvec;
	else finalQuery = queryvbc;
	
	if(!ban.isEmpty() && !man.isEmpty())
		finalQuery += banquery + ban.trim().toUpperCase()+"%' AND " + manquery  +man.trim().toUpperCase()+"%')";
	else if(!ban.isEmpty())
		finalQuery += banquery + ban.trim().toUpperCase()+"%' OR " + manquery  +ban.trim().toUpperCase()+"%')";
	else if(!man.isEmpty())
		finalQuery += banquery + man.trim().toUpperCase()+"%' OR " + manquery  +man.trim().toUpperCase()+"%')";
	
	boolean executeSearch = true;
	if(ban.isEmpty()&& man.isEmpty())
		executeSearch = false;
	finalQuery = finalQuery+" WITH UR";
	_LOGGER.info("Select SQL: " + finalQuery);
	if(executeSearch){
	    try {
	    	jdbcTemplate.query(finalQuery, new RowCallbackHandler() {
	        public void processRow(ResultSet rs) throws SQLException {
	        	String elementName = rs.getString("ELEMENT_NAME");
				String elementType = rs.getString("ELEMENT_TYPE");
				String elementOID =(rs.getBigDecimal("ELEMENT_OID")).toString();
				int elementLVL = rs.getInt("ELEMENT_LVL");
				String level0Type  = rs.getString("LVL_0_TYPE");
				String level0OID = (rs.getBigDecimal("LVL_0_OID")).toString();
				
				String level1Type  = rs.getString("LVL_1_TYPE");
				String level1OID = (rs.getBigDecimal("LVL_1_OID")).toString();
				String level2Type  = rs.getString("LVL_2_TYPE");
				String level2OID = (rs.getBigDecimal("LVL_2_OID")).toString();
				String level3Type  = rs.getString("LVL_3_TYPE");
				String level3OID = (rs.getBigDecimal("LVL_3_OID")).toString();
				String level4Type  = rs.getString("LVL_4_TYPE");
				String level4OID = (rs.getBigDecimal("LVL_4_OID")).toString();
				String level5Type  = rs.getString("LVL_5_TYPE");
				String level5OID = (rs.getBigDecimal("LVL_5_OID")).toString();
				String level6Type  = rs.getString("LVL_6_TYPE");
				String level6OID = (rs.getBigDecimal("LVL_6_OID")).toString();
				
				
				String man = rs.getString("MAN");
				String ban = rs.getString("BAN");
				String osid = rs.getString("OSID");
				String wtn = rs.getString("WTN");
				String circuteID = rs.getString("CIRCUIT_ID");
				String validIND = rs.getString("VALID_IND");
				String userOID = (rs.getBigDecimal("USER_OID")).toString();
				long entitlementLevel = rs.getLong("ENTITLEMENT_LVL");
				String verified = rs.getString("VERIFIED");
				
				String accAlias = rs.getString("ACCT_ALIAS");
				String level0Name = rs.getString("LVL_0_NAME");
				String level1Name = rs.getString("LVL_1_NAME");
				String level2Name = rs.getString("LVL_2_NAME");
				String level3Name = rs.getString("LVL_3_NAME");
				String level4Name = rs.getString("LVL_4_NAME");
				String level5Name = rs.getString("LVL_5_NAME");
				String level6Name = rs.getString("LVL_6_NAME");
				
				if(rowCoumt != 11)
				{
					htmlString += "<tr><td>"+rowCoumt++ +"</td><td>"+elementName+"</td><td>"+elementType+"</td><td>"+elementOID+
					"</td><td>"+elementLVL+"</td><td>"+level0Type+"</td><td>"+level0OID+"</td><td>"+level1Type+
					"</td><td>"+level1OID+"</td><td>"+level2Type+"</td><td>"+level2OID+"</td><td>"+level3Type+
					"</td><td>"+level3OID+"</td><td>"+level4Type+"</td><td>"+level4OID+"</td><td>"+level5Type+
					"</td><td>"+level5OID+"</td><td>"+level6Type+"</td><td>"+level6OID+"</td><td>"+man+
					"</td><td>"+ban+"</td><td>"+osid+"</td><td>"+wtn+"</td><td>"+"</td><td>"+circuteID+
					"</td><td>"+validIND+"</td><td>"+userOID+"</td><td>"+entitlementLevel+"</td><td>"+verified+
					"</td><td>"+accAlias+"</td><td>"+level0Name+"</td><td>"+level1Name+"</td><td>"+level2Name+
					"</td><td>"+level3Name+"</td><td>"+level4Name+"</td><td>"+level5Name+"</td><td>"+level6Name+"</td></tr>";
				}
				else
					rs.close();
				recordsReturn = true;
	         }
	      });
	      htmlString += "</table>";
	      if(rowCoumt >= 11)
	    	  htmlString = "<center><h3>Showing First 10 Rows From DB...</h3><br><br></center>" + htmlString;
	      _LOGGER.info("Final HtmlString -->"+htmlString);
	      if(recordsReturn)
	      {
	    	  recordsReturn = false;
	    	  responseMap.put("ResultHtml", htmlString);
	      }
	      else
	    	  responseMap.put("ResultHtml", "<h3>No Records Found</h3>"); 
	    }
	    catch (Exception vamEx) {
	    	_LOGGER.info("getAdminEntitlement in VAM Failed \n" +vamEx.getMessage());
	    	htmlString += "</table>";
		      if(rowCoumt >= 11)
		    	  htmlString = "<center><h3>Showing First 10 Rows From DB...</h3><br><br></center>" + htmlString; 
	    	if(recordsReturn)
		      {
		    	  recordsReturn = false;
		    	  responseMap.put("ResultHtml", htmlString);
		      }
	    }
	}
	else responseMap.put("ResultHtml", "<h3>Either BAN or MAN are required</h3>"); 
	    _LOGGER.debug("responseMap" + responseMap);
	    return responseMap;
}


private String getSchemaName() {
    String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
    _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
    return schemaName;
  }



}




    
