package com.verizon.enterprise.ncasbosi.dao.Impl.autoRem;

import org.apache.log4j.Logger;
import java.util.Map;
import java.util.HashMap;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

public class VisionHelper
{
	private final Logger _LOGGER = Logger.getLogger(VisionHelper.class);
	private String endPoint = null;
	private String userId = null;
	private String password = null;
	
	VisionHelper()
	{
		/*endPoint = NCASBOSIConfig.getProperty(NCASBOSIConstants.EPAY_VISION_REAL_BALANCE_URL);
		userId = NCASBOSIConfig.getProperty(NCASBOSIConstants.WIRELESS_REL_USERID);
		password = NCASBOSIConfig.getProperty(NCASBOSIConstants.WIRELESS_REL_PASSWORD);*/
		endPoint = SystemParamConfig.getProperty("VISION_ENDPOINT").trim();
		userId = SystemParamConfig.getProperty("VISION_USER_ID").trim();
		password = SystemParamConfig.getProperty("VISION_PASSWORD").trim();
		
		_LOGGER.info("VisionHelper():: userId=" + userId + ", password=" + password + ", url=" + endPoint);
	}
	
	public String invokeURL(String inputXml) throws Exception
	{
		final String METHOD_NAME = "invokeURL::";
		_LOGGER.info(METHOD_NAME + ", InputXml=" + inputXml);
		StringBuffer sbResponseXML = new StringBuffer();
		try
		{
			
			URL url = new URL(endPoint);
			URLConnection urlCon = url.openConnection();
			urlCon.setDoOutput(true);
			
			OutputStreamWriter osw = new OutputStreamWriter(urlCon.getOutputStream());
			osw.write("xmlreqdoc=" + inputXml);
			osw.close();
			
			BufferedReader br = new BufferedReader(new InputStreamReader(urlCon.getInputStream()));
			String s = "";
			
			while ((s=br.readLine()) != null)
			{
				sbResponseXML.append(s);
			}
			_LOGGER.info(METHOD_NAME + ", Response=" + sbResponseXML);
			br.close();
		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME + " Failed \n" + ex.getMessage());
			throw ex;
		}
		return sbResponseXML.toString();
	}
	
	public String getServiceReqXmlForAutoRem(Map<String, String> inpMap)
	{
		String servReqXml = "<service>" + getServiceHeader(inpMap) + getServiceBody(inpMap) + "</service>";
		return servReqXml;					
	}
	
	protected String getServiceHeader(Map<String, String> inpMap)
	{
		String servHeader = "<serviceHeader><billingSys>" + inpMap.get("BILLING_SYS") + "</billingSys><clientId>" + inpMap.get("CLIENT_ID") + "</clientId><userId>" + userId + "</userId><password>" + password + "</password><serviceName>" + inpMap.get("SERVICE_NAME") + "</serviceName></serviceHeader>";
		return servHeader;
	}
	
	protected String getServiceBody(Map<String, String> inpMap)
	{
		String serviceBody = "<serviceBody>" + getServiceReqForAutoRemarksUpdate(inpMap) + "</serviceBody>";
		return serviceBody;
	}
	
	protected String getServiceReqForAutoRemarksUpdate(Map<String, String> inpMap)
	{
		String servReq = "<serviceRequest><accountNo>" + inpMap.get("SERVICE_ID") + "</accountNo><billAccountType>C</billAccountType><remarkType>" + inpMap.get("REMARK_TYPE") + "</remarkType><remarkText>" + inpMap.get("REMARK_TEXT") + "</remarkText><remarkLevel>A</remarkLevel><contactMethod>" + inpMap.get("CONTACT_METHOD") + "</contactMethod></serviceRequest>";
		return servReq;
	}
	
	public static String getTransactionForAccessType(String accessType)
	{
		if (accessType.trim().equals("PAY_ONETIME_VW"))
		{
			return NCASBOSIConstants.PAY_ONETIME_VW;
		}
		else if (accessType.trim().equals("PAY_RECUR_VW"))
		{
			return NCASBOSIConstants.PAY_RECUR_VW;
		}
		else if (accessType.trim().equals("PAY_RECUR_UPD_VW"))
		{
			return NCASBOSIConstants.PAY_RECUR_UPD_VW;
		}
		else if (accessType.trim().equals("PFB_PAPERLESS_VW"))
		{
			return NCASBOSIConstants.PFB_PAPERLESS_VW;
		}
		else
		{
			return NCASBOSIConstants.PFB_PAPER_VW;
		}
	}
}
