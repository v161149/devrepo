package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.vbe.VbeHierDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;

//download button on top of report hier screen
// second result set from call to GET_VBE_HIER
// convert result set to input to jasper
public class GetVbeHierDownloadRowMapper2 implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetVbeHierDownloadRowMapper2.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetVbeHierDownloadRowMapper2::extractData() ";

		logger.info(METHOD_NAME + "ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> rowList = new ArrayList<List<Cell>>();
		List<Cell> cellList = new ArrayList<Cell>();

		try
		{
			while(rs.next())
			{
				cellList = new ArrayList<Cell>();

				cellList.add(new Cell(val(rs.getString("PARENT_DESC"))));  //col_1
				cellList.add(new Cell(val(rs.getString("PARENT_TYPE"))));  //col_2
				cellList.add(new Cell(val(rs.getString("PARENT_OID")))); //col_3
				cellList.add(new Cell(val(rs.getString("PARENT_ID")))); //col_4
				cellList.add(new Cell(val(rs.getString("PARENT_NAME")))); //col_5
				cellList.add(new Cell(val(rs.getString("CHILD_DESC")))); //col_6
				cellList.add(new Cell(val(rs.getString("CHILD_TYPE")))); //col_7
				cellList.add(new Cell(val(rs.getString("CHILD_OID")))); //col_8
				cellList.add(new Cell(val(rs.getString("CHILD_ID")))); //col_9
				cellList.add(new Cell(val(rs.getString("CHILD_NAME")))); //col_10
				
				rowList.add(cellList);

				logger.debug(METHOD_NAME + "cellList=" + cellList);
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();

			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();

			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
		}

		logger.debug(METHOD_NAME + "rowList.size()=" + rowList.size());

		return rowList;
	}
	
	private String val (String in)
	{
		if (in == null) in = "";
		in = in.trim();
		return commonUtil.excelTextValueOf(in);

	}
}
