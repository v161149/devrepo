package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import java.math.BigDecimal;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

  public class SPCreateIBI extends BaseStoredProcedure {
    static private final Logger _LOGGER = Logger.getLogger(SPCreateIBI.class);
    private static List spInOutList;

    static {
      _LOGGER.info("Static init ");

      spInOutList = new ArrayList();
      spInOutList.add(new Object[]{"BI_CATEGORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"ORIGINATING_SYS_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"REGION_CD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"ORIGINATOR_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"ACCOUNT_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BILL_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"MAN_BILL_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CATEGORY_CD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"SUB_CAT_CD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CONTACT_LAST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CONTACT_FIRST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CONTACT_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CONTACT_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CREATE_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"ENTITLEMENT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"SUBSCRIBER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"SUBSCRIPTION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"ATTACHMENT_FLAG", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_ADDRESS_1", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_ADDRESS_2", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_ADDRESS_3", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_ADDRESS_4", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_COUNTY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_DISTRICT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_PROVINCE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_CITY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_STATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_POSTAL_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_COUNTRY_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_ATTENTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_DEPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_PREMISES_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_STREET", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_CITY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_ZIP", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_DIST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_ADD_COUNTRY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"ADD_EFFECTIVE_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_CONT_ATTENTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_CONT_DEPT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_CONT_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_CONT_FAX", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_CONT_MOBILE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_CONT_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CONT_EFFECTIVE_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"TAX_REF_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"VAT_EFFECTIVE_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BIL_FMT_TIME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BIL_FMT_ITEMIZED", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BIL_FMT_LOCATION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BIL_FMT_MONTH", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BIL_FMT_LOCATION_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PREFERENCES", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"DIRECT_DEBIT_REQ", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"OLD_PON", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"NEW_PON", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PON_EFFECTIVE_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_SEPARATE_INV", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_SEPARATE_CALL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_SAME_INV_CALL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_INV_NO", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_INV_YEAR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_INV_MONTH", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_CALL_YEAR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYI_CALL_MONTH", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYA_BAL_REQR", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYA_STMT_START_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYA_STMT_END_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"UNBIL_TRUNK_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PERIOD_FROM", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PERIOD_TO", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"INVVOICE_LIST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CREDIT_REQ_START_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CREDIT_REQ_END_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"SERVICE_ID_LIST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"CREDIT_REASON", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"DISPUTE_AMOUNT", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"TT_REF_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"JUSTIFICATION_NOTE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYC_NOTE_REF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYC_SERVICE_REQ_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYC_NOTE_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYC_START_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYC_END_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"COPYC_AMOUNT", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PAYMENT_AMT", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PAYMENT_DT", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"PAYMENT_METHOD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"REFERENCE_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"BANK_ACCT_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"RELATED_INV_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
      spInOutList.add(new Object[]{"DISPUTE_INV_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

      spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
      spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
      spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
      spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
      spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
      spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
      spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    }

    public SPCreateIBI(DataSource dataSource) {
      super(dataSource, NCASBOSIConstants.SP_CREATE_INT_BIL_INQ, spInOutList);
    }

    public Map executeStoredProcedure(Object paramValues)throws Exception {
      _LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

      BillInquiry bi = (BillInquiry)paramValues;
      _LOGGER.info("billInquiry Object::"+bi);

      String origLogin = "";
      String acctName= "";
      String attachmentFlg = "";
      String invoicenum= "";
      String region ="";
      List paramValueList = new ArrayList();

      paramValueList.add(bi.getBICategory());
      paramValueList.add(bi.getSourcePortal());
      paramValueList.add(bi.getOSID());
      paramValueList.add(bi.getRegion());
      origLogin = bi.getOrigLogin();

      if(origLogin != null && origLogin.length()>20) {
        _LOGGER.info("Before Truncation \nOrigLogin: "+origLogin+"\nOrigLogin Length: "+origLogin.length());
        origLogin = origLogin.substring(0,20);
        _LOGGER.info("After Truncation \norigLogin: "+origLogin+"\norigLogin Length: "+origLogin.length());
      }
      paramValueList.add(origLogin);
      paramValueList.add(bi.getBAN());
      paramValueList.add(bi.getSAN());
      _LOGGER.info("Checking Account Name for VAC Compliance");
      acctName = bi.getAcctName();
      if(acctName != null && acctName.length()>40) {
        _LOGGER.info("Before Truncation \nAccount Name: "+acctName+"\nAccount Name Length: "+acctName.length());
        _LOGGER.info("Now trauncating Account Name to make it VAC Compliant");

        acctName = new String(acctName.substring(0, 40));
        _LOGGER.info("After Truncation \nAccount Name: "+acctName+"\nAccount Name Length: "+acctName.length());
      }
      paramValueList.add(acctName);
      paramValueList.add(bi.getBillDate());
      paramValueList.add(CommonUtil.getDateFromString(bi.getManbilldate()));
      paramValueList.add(bi.getCategoryCode());
      paramValueList.add(bi.getSubcategoryCode());
      paramValueList.add(bi.getSenderLastName());
      paramValueList.add(bi.getSenderFirstName());
      paramValueList.add(bi.getSenderPhone());
      paramValueList.add(bi.getSenderEmail());
      paramValueList.add(bi.getCreatedDate());
      paramValueList.add(new Double(bi.getSubscriptionOid()));
      paramValueList.add(new Double(bi.getSubscriberOid()));
      paramValueList.add(new Double(bi.getSubscriptionOid()));
      if (bi.isAttachmentFlg()) {
        attachmentFlg="Y";
      } else {
        attachmentFlg="N";
      }
      paramValueList.add(attachmentFlg);
      paramValueList.add(bi.getAttention());
      paramValueList.add(bi.getDepartment());
      paramValueList.add(bi.getPremisesName());
      paramValueList.add(bi.getStreetName());
      paramValueList.add(null);                //ignore OLD_COUNTY
      paramValueList.add(null);                //ignore OLD_DISTRICT
      paramValueList.add(null);                //ignore OLD_PROVINCE
      paramValueList.add(bi.getCity());
      paramValueList.add(null);                //ignore OLD_STATE
      paramValueList.add(bi.getZipcode());
      paramValueList.add(null);                //ignore OLD_COUNTRY_NAME
      paramValueList.add(bi.getNewAttention());
      paramValueList.add(bi.getNewDepartment());
      paramValueList.add(bi.getNewPremisesName());
      paramValueList.add(bi.getNewStreetName());
      paramValueList.add(bi.getNewCity());
      paramValueList.add(bi.getNewZipcode());
      paramValueList.add(bi.getNewDistrict());
      paramValueList.add(bi.getNewCountryString());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getEffectiveDate())));
      paramValueList.add(bi.getDetailAttention());
      paramValueList.add(bi.getDetailDepartment());
      paramValueList.add(bi.getNewTelephone());
      paramValueList.add(bi.getNewFax());
      paramValueList.add(bi.getNewMobile());
      paramValueList.add(bi.getNewemail());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getDetailEffectiveDate())));
      paramValueList.add(bi.getTaxRefNumber());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getStatusEffectiveDate())));
      paramValueList.add(bi.getTimeofDay());
      paramValueList.add(bi.getItemizedBilling());
      paramValueList.add(bi.getLocationSummary());
      paramValueList.add(bi.getMonthSummary());
      paramValueList.add(bi.getLocationNames());
      paramValueList.add(null);                       //ignore PREFERENCES
      paramValueList.add(bi.getDebitDescription());
      paramValueList.add(bi.getOldPurchaseOrder());
      paramValueList.add(bi.getNewPurchaseOrder());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getPurchaseEffectiveDate())));
      paramValueList.add(bi.getSeparateInvoice());
      paramValueList.add(bi.getSeparateCallData());
      paramValueList.add(bi.getSameInvoice());
      invoicenum = bi.getSameInvoice();
	  /*how to populate the 3 fields below depends on which radio box [same or separate] user selects*/
	  if (invoicenum != null && invoicenum.equalsIgnoreCase("Y")) {
		//Copy same Invoice call
		paramValueList.add(bi.getSameInvoiceDescription());
		paramValueList.add(bi.getSameCalldataYear());
		paramValueList.add(bi.getSameCalldataMonth());
	  } else {
		paramValueList.add(bi.getSepInvoiceDescription());
		paramValueList.add(bi.getSepInvoiceYearString());
		paramValueList.add(bi.getSepInvoiceMonth());
	  }
      paramValueList.add(bi.getSepCalldataYear());
      paramValueList.add(bi.getSepCalldataMonth());
      paramValueList.add(bi.getBalanceReqString());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getAccountStartDate())));
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getAccountEndDate())));
      paramValueList.add(bi.getTelortrunk());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getPeriodFrom())));
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getPeriodTo())));
      paramValueList.add(bi.getInvoiceList());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getStartDate())));
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getEndDate())));
      paramValueList.add(bi.getServiceIdList());
      paramValueList.add(bi.getReasonForCreditString());
      paramValueList.add(new BigDecimal(checkForInteger(bi.getDispAmount())));
      paramValueList.add(bi.getTicketRefNumber());
      paramValueList.add(bi.getJustification ());
      paramValueList.add(bi.getCreditNoteReference());
      paramValueList.add(bi.getServiceReqNumber());
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getCreditNoteDate())));
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getCreditStartDate())));
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getCreditEndDate())));
      paramValueList.add(new BigDecimal(checkForInteger(bi.getCreditedAmount())));
      paramValueList.add(new BigDecimal(checkForInteger(bi.getPaymentAmount())));
      paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getPaymentDate())));
      paramValueList.add(bi.getPaymentMethod());
      paramValueList.add(bi.getReferenceID());
      paramValueList.add(bi.getBankAccountNumber());
      paramValueList.add(bi.getRelatedInvoiceNumber());
      paramValueList.add(bi.getDisputeInvoiceDescription());


      _LOGGER.info("paramValueList "+paramValueList);
      Map resMap = executeSP(paramValueList, false);

      _LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
      checkVACErrors(resMap);
      _LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
      return resMap;
    }

    	private String checkForInteger(String pInputParam){
				if(pInputParam == null || pInputParam.trim().length()==0){
					return "0";
				}else{
					return pInputParam;
				}
		}

    	private String checkForNull(String pInputParam){
				if(pInputParam == null || pInputParam.trim().length()==0){
					return "";
				}else{
					return CommonUtil.formatDate(pInputParam,"MM/dd/yyyy","yyyy-MM-dd");
				}
		}

}

