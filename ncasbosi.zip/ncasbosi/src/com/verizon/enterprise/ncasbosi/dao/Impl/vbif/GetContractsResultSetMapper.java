package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.Contract;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetContractsResultSetMapper implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetContractsResultSetMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetContractsResultSetMapper::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		Contract contract = new Contract();
		
		String vacContractId = CommonUtil.convertStringFromDouble(rs.getDouble("VAC_CONTRACT_ID"));
		String contractId = rs.getString("CONTRACT_ID");
		String pow = CommonUtil.convertStringFromDouble(rs.getDouble("POW"));
		String cvcdDbNumber = CommonUtil.convertStringFromDouble(rs.getDouble("CVCD_DB_NBR"));
		String amendmentNumber = rs.getString("AMENDMENT_NBR");
		String centerFinOwned = rs.getString("CENTER_FIN_OWNED");
		String cvDocNumber = CommonUtil.convertStringFromDouble(rs.getDouble("CV_DOC_NBR"));
		String term = rs.getString("TERM");
		String commitment = rs.getString("COMMITMENT");
		Date custSignDate = rs.getDate("CUSTOMER_SIGN_DT");
		String custSignDateStr = CommonUtil.getDisplayDateFromString(custSignDate,"MM/dd/yyyy");
		Date vzbSignDate = rs.getDate("VZB_SIGN_DT");
		String vzbSignDateStr = CommonUtil.getDisplayDateFromString(vzbSignDate,"MM/dd/yyyy");
		String edLangNumber = rs.getString("ED_LANGUAGE");
		String contRatePgm = rs.getString("CONTRACT_RATE_PGM");
		String conSource = rs.getString("CONTRACT_SOURCE");
		String pricingType = rs.getString("PRICING_TYPE");
		String electiveClInd = rs.getString("ELECTIVE_CL_IND");
		String docType = rs.getString("DOC_TYPE");
		String selectInd = rs.getString("SELECTED_IND");
		
		if (CommonUtil.isNotNull(vacContractId)) {
			contract.setVacContractId(vacContractId.trim());
		}
		if (CommonUtil.isNotNull(contractId)) {
			contract.setContractId(contractId.trim());
		}
		if (CommonUtil.isNotNull(pow)) {
			contract.setPow(pow.trim());
		}
		if (CommonUtil.isNotNull(cvcdDbNumber)) {
			contract.setCvcdDbNumber(cvcdDbNumber.trim());
		}
		if (CommonUtil.isNotNull(amendmentNumber)) {
			contract.setAmendmentNumber(amendmentNumber.trim());
		}
		if (CommonUtil.isNotNull(centerFinOwned)) {
			contract.setCenterFinOwned(centerFinOwned.trim());
		}
		if (CommonUtil.isNotNull(cvDocNumber)) {
			contract.setCvDocNumber(cvDocNumber.trim());
		}
		if (CommonUtil.isNotNull(term)) {
			contract.setTerm(term.trim());
		}
		if (CommonUtil.isNotNull(commitment)) {
			contract.setCommitment(commitment.trim());
		}
		if (CommonUtil.isNotNull(custSignDateStr)) {
			contract.setCustSignDate(custSignDateStr.trim());
		}
		if (CommonUtil.isNotNull(vzbSignDateStr)) {
			contract.setVzbSignDate(vzbSignDateStr.trim());
		}
		if (CommonUtil.isNotNull(edLangNumber)) {
			contract.setEdLangNumber(edLangNumber.trim());
		}
		if (CommonUtil.isNotNull(contRatePgm)) {
			contract.setContRatePgm(contRatePgm.trim());
		}
		if (CommonUtil.isNotNull(conSource)) {
			contract.setConSource(conSource.trim());
		}
		if (CommonUtil.isNotNull(pricingType)) {
			contract.setPricingType(pricingType.trim());
		}
		if (CommonUtil.isNotNull(electiveClInd)) {
			contract.setElectiveClInd(electiveClInd.trim());
		}
		if (CommonUtil.isNotNull(docType)) {
			contract.setDocType(docType.trim());
		}
		if (CommonUtil.isNotNull(selectInd)) {
			contract.setselectInd(selectInd.trim());
		}

		return contract;
	}
}
