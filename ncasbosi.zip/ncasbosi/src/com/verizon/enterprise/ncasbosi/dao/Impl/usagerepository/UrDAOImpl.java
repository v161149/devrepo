package com.verizon.enterprise.ncasbosi.dao.Impl.usagerepository;

/* api's for the usage repository screens
 * Some api's call sp's other use direct sql
 */

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.usagerepository.UrInterface;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.usagerepository.UrDO;
import com.verizon.enterprise.common.ncas.usagerepository.UrUsageDO;
import org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper;
import org.springframework.dao.EmptyResultDataAccessException;
import com.verizon.enterprise.common.util.DateUtility;

public class UrDAOImpl extends NCASSpringJDBCBase implements UrInterface{
	
	private static final Logger _LOGGER = Logger.getLogger(UrDAOImpl.class);
	
	public final String authLevelCaseStmt = " CASE AUTH_LEVEL WHEN 'A' THEN 'Admin' WHEN 'B' THEN 'Orig / Term' WHEN 'C' THEN 'Orig only' WHEN 'N' THEN 'No Access'  ELSE ' ' END AS authLevelTxt ";

		
	/* there are different sp's to call to get usage, one for current data, one for archived data, and one for international data */
	/* sp to get current usage, current usage stored on disk in vsam files */
	public Map getUsage (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		UrDO urDO = (UrDO)requestMap.get("urDO");
		
		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in urDO = " + urDO);
			}
		
			responseMap = new SPGetUsage(getURDataSource()).executeStoredProcedure(requestMap);

			responseMap = checkMaxSize(responseMap, urDO.getMaxRows());
			responseMap = filterByTime(responseMap, urDO);

		}catch(Exception e){
			_LOGGER.error("getUsage - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}

		return responseMap;
	}
	
	/* sp to get archived usage, after a couple months usage is archived to OAM tape, this api gets that data */
	public Map getArchUsage (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		UrDO urDO = (UrDO)requestMap.get("urDO");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in urDO = " + urDO);
			}
			
			responseMap = new SPGetArchUsage(getURDataSource()).executeStoredProcedure(requestMap);

			responseMap = checkMaxSize(responseMap, urDO.getMaxRows());
			responseMap = filterByTime(responseMap, urDO);

		}catch(Exception e){
			_LOGGER.error("getArchUsage - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}

		return responseMap;
	}

	/* sp to get international usage, international has 16 digit tn instead of 10 digit, all history stored on vsam files 
	 * so no corresponding sp to get archived international usage
	 */
	public Map getIntrnUsage (Object input) throws NCASException
	{
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		UrDO urDO = (UrDO)requestMap.get("urDO");

		try
		{

			if (_LOGGER.isEnabledFor(Level.DEBUG))
			{
				_LOGGER.info("in urDO = " + urDO);
			}
			
			responseMap = new SPGetIntrnUsage(getURDataSource()).executeStoredProcedure(requestMap);

			responseMap = checkMaxSize(responseMap, urDO.getMaxRows());
			responseMap = filterByTime(responseMap, urDO);

		}catch(Exception e){
			_LOGGER.error("getIntrnUsage - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}

		return responseMap;
	}
	
	/* get the authorization level assoiated with the user,  Portal passes the user logged in
	 * to this api, then the userid is checked vs a usage repistory table to find their auth level
	 * A=admin, B=term, C=orig, N=none
	*/
	public Map getAuthLevel (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::getAuthLevel()");
		Map inMap = (HashMap) input;
		Map requestMap = new HashMap();
		Map responseMap = new HashMap();
		
		UrDO urDO = (UrDO) inMap.get("urDO");
		String userId = urDO.getUserId().toLowerCase();
		requestMap.put("userId", userId);
		_LOGGER.info("userId=" + userId);

		try {
		    String sqlStmt = "SELECT AUTH_LEVEL FROM XCEP.T0153A1_WEB_GROUPS WHERE LOWER(USER_ID)=:userId AND SYSTEM_ABBREV='UR'";
		    responseMap = urSimpleJdbcTemplate.queryForMap(sqlStmt, requestMap);	    
		}catch (EmptyResultDataAccessException notfound){
			_LOGGER.error("getAuthLevel - user " + userId +  " not found defaulting to no access");
			responseMap.put("AUTH_LEVEL", "N");  //default user to no access if user is not found.
			responseMap.put("ERR_MSG", "user " + userId + " not found defaulting to no access");
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::getAuthLevel() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		_LOGGER.info("Exiting UrDAOImpl::getAuthLevel()");
		return responseMap;		
	}
	
	/* log event that user looked at usage for tn between dates */
	public Map logIt (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::logIt()");
		Map inMap = (HashMap) input;
		Map requestMap = new HashMap();
		Map responseMap = new HashMap();
		
		Calendar cal = new GregorianCalendar();  // get current date time
		
		Date todaysDate = cal.getTime();
		String date = DateUtility.getFormattedDateString(todaysDate, "yyyyMMdd");  //year month day all mashed together
		String time = DateUtility.getFormattedDateString(todaysDate, "HH:mm:ss");  //military time 
		
		UrDO urDO = (UrDO) inMap.get("urDO");
		String userId = urDO.getUserId();
		if (userId != null) userId = userId.toLowerCase(); 
		requestMap.put("userId", userId);
		requestMap.put("origTerm", urDO.getOrigTerm());
		requestMap.put("wtn", urDO.getWtn());
		requestMap.put("startDate", urDO.getStartDate());
		requestMap.put("stopDate", urDO.getStopDate());
		requestMap.put("todayDate", date);
		requestMap.put("todayTime", time);
		
		_LOGGER.info("requestMap=" + requestMap);

		try {
		    String sqlStmt = "  INSERT INTO XCEP.T0151A1_UR_LOG VALUES ( :userId, :origTerm, :wtn, :startDate, :stopDate, :todayDate, :todayTime)";
		    int rowsUpdated = urSimpleJdbcTemplate.update(sqlStmt, requestMap);	
		    responseMap.put("ROWS_UPDATED", rowsUpdated + "");
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::logIt() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		_LOGGER.info("Exiting UrDAOImpl::logIt()");
		return responseMap;		
	}
	
	/* get list of users to show in dropdown list */
	public Map getUserList (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::getUserList()");
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		List<UrUsageDO> userList = null;

		try {
		    ArrayList inParameters = new ArrayList();
		    String sqlStmt = "SELECT DISTINCT LOWER(USER_ID) AS userId, AUTH_LEVEL as authLevel, LAST_NAME AS lastName, FIRST_NAME AS firstName, WORK_GROUP as workGroup, UPDATE_TIMESTAMP as updateTimestamp, " + authLevelCaseStmt +  " FROM XCEP.T0153A1_WEB_GROUPS WHERE SYSTEM_ABBREV = 'UR' ORDER BY LAST_NAME, FIRST_NAME WITH UR";
		    userList = urSimpleJdbcTemplate.query(sqlStmt,ParameterizedBeanPropertyRowMapper.newInstance(UrUsageDO.class), inParameters.toArray());
		    responseMap.put("RESULT_SET_ONE", userList);
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::getUserList() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		_LOGGER.info("Exiting UrDAOImpl::getUserList()");
		return responseMap;		
	}
	
	public Map getUserInfoByUserId (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::getUserInfoByUserId()");
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		UrUsageDO userInfo = null;
		String userId = null;
		try {
			UrDO urDO = (UrDO)requestMap.get("urDO");
			_LOGGER.info("input urDO = " + urDO);
		    ArrayList inParameters = new ArrayList();
		    userId = urDO.getUserId().toLowerCase();
		    String sqlStmt = "SELECT USER_ID AS userId, AUTH_LEVEL AS authLevel, LAST_NAME AS lastName,FIRST_NAME AS firstName, WORK_GROUP AS workGroup, UPDATE_TIMESTAMP AS updateTimestamp, " + authLevelCaseStmt +  " FROM XCEP.T0153A1_WEB_GROUPS WHERE USER_ID = '"+userId+"' AND SYSTEM_ABBREV  = 'UR' WITH UR";
		    userInfo = urSimpleJdbcTemplate.queryForObject(sqlStmt,ParameterizedBeanPropertyRowMapper.newInstance(UrUsageDO.class), inParameters.toArray());
		    responseMap.put("RESULT_SET_ONE", userInfo);
		}catch (EmptyResultDataAccessException notfound){
			_LOGGER.error("getUserInfoByUserId - user " + userId +  " not found");
			responseMap.put("ERR_MSG", "user " + userId + " not found");		    
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::getUserInfoByUserId() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		_LOGGER.info("Exiting UrDAOImpl::getUserInfoByUserId()");
		return responseMap;		
	}
	
	public Map getUserAuditReport (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::getUserAuditReport()");
		Map requestMap = (HashMap) input;
		Map responseMap = new HashMap();
		List<UrUsageDO> report = null;
		
		try {
			UrDO urDO = (UrDO)requestMap.get("urDO");
			_LOGGER.info("input urDO = " + urDO);
		    ArrayList inParameters = new ArrayList();
		    String sqlStmt = null;
		    if (urDO.getReportType()!=null&&urDO.getReportType().trim().equalsIgnoreCase("usageAuditRpt1")) {
		        sqlStmt = "SELECT L.PROCESS_DATE AS processDate,L.PROCESS_TIME AS processTime,L.WTN AS wtn,L.REQ_TYPE AS reqType,L.FROM_DATE AS fromDate,L.TO_DATE AS toDate FROM XCEP.T0151A1_UR_LOG L WHERE LOWER(L.USER_ID) = LOWER('"+urDO.getUserId()+"') AND L.PROCESS_DATE >= '"+urDO.getStartDate()+"' AND L.PROCESS_DATE <= '"+urDO.getStopDate()+"'"+urDO.getSortBy()+" WITH UR";
		    } else if (urDO.getReportType()!=null&&urDO.getReportType().trim().equalsIgnoreCase("usageAuditRpt2")) {
		    	sqlStmt = "SELECT L.USER_ID AS userId,L.PROCESS_DATE AS processDate,L.PROCESS_TIME AS processTime,L.REQ_TYPE AS reqType,L.FROM_DATE AS fromDate,L.TO_DATE AS toDate,U.LAST_NAME AS lastName,U.FIRST_NAME AS firstName FROM XCEP.T0151A1_UR_LOG L,XCEP.T0153A1_WEB_GROUPS U WHERE LOWER(L.USER_ID) = U.USER_ID AND L.WTN = '"+urDO.getWtn()+"' AND L.PROCESS_DATE >= '"+urDO.getStartDate()+"' AND L.PROCESS_DATE <= '"+urDO.getStopDate()+"' AND U.SYSTEM_ABBREV = 'UR'"+urDO.getSortBy()+" WITH UR";
		    } else if (urDO.getReportType()!=null&&urDO.getReportType().trim().equalsIgnoreCase("usageAuditRpt3")) {
		    	sqlStmt = "SELECT L.USER_ID AS userId,L.REQ_TYPE AS reqType,L.WTN AS wtn,L.FROM_DATE AS fromDate,L.TO_DATE AS toDate,L.PROCESS_DATE AS processDate,L.PROCESS_TIME AS processTime,U.LAST_NAME AS lastName,U.FIRST_NAME AS firstName FROM XCEP.T0151A1_UR_LOG L,XCEP.T0153A1_WEB_GROUPS U where LOWER(L.USER_ID) = U.USER_ID AND L.PROCESS_DATE >= '"+urDO.getStartDate()+"' AND L.PROCESS_DATE <= '"+urDO.getStopDate()+"' AND U.SYSTEM_ABBREV = 'UR'"+urDO.getSortBy()+" WITH UR";
		    }
		    report = urSimpleJdbcTemplate.query(sqlStmt,ParameterizedBeanPropertyRowMapper.newInstance(UrUsageDO.class), inParameters.toArray());
		    responseMap.put("RESULT_SET_ONE", report);
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::getUserAuditReport() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		_LOGGER.info("Exiting UrDAOImpl::getUserAuditReport()");
		return responseMap;		
	}
	
	
	/* add user */
	public Map addUser (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::addUser()");
		Map inMap = (HashMap) input;
		Map requestMap = new HashMap();
		Map responseMap = new HashMap();
		
		Calendar cal = new GregorianCalendar();  // get current date time
		
		UrDO urDO = (UrDO) inMap.get("urDO");
		String userId = urDO.getUserId();
		if (userId != null) userId = userId.toLowerCase(); 
	
		String authLevel = urDO.getAuthLevel();
		if (authLevel != null) authLevel = authLevel.toUpperCase(); 
		
		requestMap.put("UR", "UR");
		requestMap.put("userId", userId);
		requestMap.put("authLevel", authLevel);
		requestMap.put("lastName", urDO.getLastName());
		requestMap.put("firstName", urDO.getFirstName());
		requestMap.put("workGroup", urDO.getWorkGroup());

		_LOGGER.info("requestMap=" + requestMap);
		
		//check for duplicate user, if found return with out attempting to add
		if (isDuplicateUser(userId))
		{
			String errMsg = "<center> <p> User ID <b>" +userId+ "</b> already exists for: <br> " + urDO.getFirstName() + " " + urDO.getLastName() + " <br> </center>";
			responseMap.put("ERR_MSG", errMsg);
			return responseMap;
		}
		int rowsUpdated=0;
		try {
		    String sqlStmt = "  INSERT INTO XCEP.T0153A1_WEB_GROUPS VALUES (:UR, :userId, :authLevel, :lastName, :firstName, :workGroup, current_timestamp)";
		    rowsUpdated = urSimpleJdbcTemplate.update(sqlStmt, requestMap);	
		    responseMap.put("ROWS_UPDATED", rowsUpdated + "");
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::addUser() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
	
		
		String errMsg = "";
		if (rowsUpdated == 0)
		{
			errMsg= " <center> Add did not work </center>";
		}
		else
		{
			errMsg= "<center> <p> Add was successful for <b>" + userId + "</b> <br> </center>";
		}
		
		responseMap.put("ERR_MSG", errMsg);
		
		_LOGGER.info("Exiting UrDAOImpl::addUser()");
		return responseMap;		
	}	
	
	/* dup check -  make sure user does not already exist when adding a new user */
	private boolean isDuplicateUser (String userId) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::isDuplicateUser()");
		try {
			UrUsageDO userInfo = null;
		    ArrayList inParameters = new ArrayList();
		    String sqlStmt = "SELECT USER_ID AS userId FROM XCEP.T0153A1_WEB_GROUPS WHERE USER_ID = '"+userId+"' AND SYSTEM_ABBREV  = 'UR' WITH UR";
		    userInfo = urSimpleJdbcTemplate.queryForObject(sqlStmt,ParameterizedBeanPropertyRowMapper.newInstance(UrUsageDO.class), inParameters.toArray());
		}catch (EmptyResultDataAccessException notfound){
			_LOGGER.info("duplicate user found for userid " + userId);
			return false;    
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::isDuplicateUser() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		_LOGGER.info("Exiting UrDAOImpl::isDuplicateUser()");
		return true;		
	}	
	
	
	/* disable user */
	public Map disableUser (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::disableUser()");
		Map inMap = (HashMap) input;
		Map requestMap = new HashMap();
		Map responseMap = new HashMap();
		
		UrDO urDO = (UrDO) inMap.get("urDO");
		String userId = urDO.getUserId();
		if (userId != null) userId = userId.toLowerCase(); 
	
		requestMap.put("UR", "UR");
		requestMap.put("userId", userId);

		_LOGGER.info("requestMap=" + requestMap);
		
		int rowsUpdated = 0;
		try {
		    String sqlStmt = "  UPDATE XCEP.T0153A1_WEB_GROUPS SET AUTH_LEVEL='N',UPDATE_TIMESTAMP=current_timestamp WHERE USER_ID=:userId AND SYSTEM_ABBREV='UR'";
		    rowsUpdated = urSimpleJdbcTemplate.update(sqlStmt, requestMap);	
		    responseMap.put("ROWS_UPDATED", rowsUpdated + "");
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::disableUser() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		
		String errMsg = "";
		if (rowsUpdated == 0)
		{
			errMsg= " <center> <P> User " + userId + " was not found  </center>";
		}
		else
		{
			errMsg= " <center> <p> Access to UR has been removed for <b>" +userId+ "</b> <br> </center>";
		}
		
		responseMap.put("ERR_MSG", errMsg);
        
		_LOGGER.info("Exiting UrDAOImpl::disableUser()");
		return responseMap;		
	}	
	
	/* delete user */
	public Map deleteUser (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::deleteUser()");
		Map inMap = (HashMap) input;
		Map requestMap = new HashMap();
		Map responseMap = new HashMap();
		
		UrDO urDO = (UrDO) inMap.get("urDO");
		String userId = urDO.getUserId();
		if (userId != null) userId = userId.toLowerCase(); 
	
		requestMap.put("UR", "UR");
		requestMap.put("userId", userId);

		_LOGGER.info("requestMap=" + requestMap);
		int rowsUpdated = 0;
		try {
		    String sqlStmt = "  DELETE FROM XCEP.T0153A1_WEB_GROUPS WHERE USER_ID=:userId AND SYSTEM_ABBREV='UR'";
		    rowsUpdated = urSimpleJdbcTemplate.update(sqlStmt, requestMap);	
		    responseMap.put("ROWS_UPDATED", rowsUpdated + "");
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::deleteUser() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		
		String errMsg = "";
		if (rowsUpdated == 0)
		{
			errMsg= " <center> <P> User " + userId + " was not found  </center>";
		}
		else
		{
			errMsg= "<center> <p> User <b> " + userId + "</b> has been deleted from the UR user table <br> </center>";
		}
		
		responseMap.put("ERR_MSG", errMsg);
		
		_LOGGER.info("Exiting UrDAOImpl::deleteUser()");
		return responseMap;		
	}		
	
	/* update user */
	public Map updateUser (Object input) throws NCASException {
		_LOGGER.info("Entering UrDAOImpl::updateUser()");
		Map inMap = (HashMap) input;
		Map requestMap = new HashMap();
		Map responseMap = new HashMap();
		
		UrDO urDO = (UrDO) inMap.get("urDO");
		String userId = urDO.getUserId();
		if (userId != null) userId = userId.toLowerCase(); 
		
		String authLevel = urDO.getAuthLevel();
		if (authLevel != null) authLevel = authLevel.toUpperCase(); 
	
		requestMap.put("UR", "UR");
		requestMap.put("userId", userId);
		requestMap.put("authLevel", authLevel);
		requestMap.put("lastName", urDO.getLastName());
		requestMap.put("firstName", urDO.getFirstName());
		requestMap.put("workGroup", urDO.getWorkGroup());

		_LOGGER.info("requestMap=" + requestMap);
		int rowsUpdated=0;
		try {
		    String sqlStmt = "  UPDATE XCEP.T0153A1_WEB_GROUPS ";
		    sqlStmt = sqlStmt + "  SET LAST_NAME=:lastName, ";
		    sqlStmt = sqlStmt + "      FIRST_NAME=:firstName, ";
		    sqlStmt = sqlStmt + "      AUTH_LEVEL=:authLevel, ";
		    sqlStmt = sqlStmt + "      WORK_GROUP=:workGroup, ";
		    sqlStmt = sqlStmt + "      UPDATE_TIMESTAMP=current_timestamp ";
		    sqlStmt = sqlStmt + "  WHERE USER_ID=:userId AND SYSTEM_ABBREV='UR'";
		    rowsUpdated = urSimpleJdbcTemplate.update(sqlStmt, requestMap);	
		    responseMap.put("ROWS_UPDATED", rowsUpdated + "");
		}catch(Exception e){
			_LOGGER.error("UrDAOImpl::updateUser() - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("UR1001",UrDAOImpl.class,e);
		}
		
		String errMsg = "";
		if (rowsUpdated == 0)
		{
			errMsg= " <center> <P> User " + userId + " was not found  </center>";
		}
		else
		{
			errMsg= "<center> <p> Update was successful for " +userId+ " <br> </center>";
		}
		
		responseMap.put("ERR_MSG", errMsg);
		
		_LOGGER.info("Exiting UrDAOImpl::updateUser()");
		return responseMap;		
	}			
	
	
	
	/* this is called by all 3 sp's to get usage, if we reached the limit set by the user
	 * need to put an message to them so they know there is more usage out there 
	 */
	private Map checkMaxSize(Map responseMap, int maxRows)
	{
		List resultList = (ArrayList) responseMap.get("RESULT_SET_ONE");
		if (resultList != null)
		{
			if (resultList.size() >= maxRows)
			{
				responseMap.put("MAX_REACHED", "Y");
			}
		}
		return responseMap;
	}
	
	/*
	 * the web page supports date and time filtering, the sp's only support date filtering
	 * this function adds the filter by time functionality.
	 */
	private Map filterByTime(Map responseMap, UrDO urDO)
	{
		boolean writeInToOut = true;
		List resultListIn = (ArrayList) responseMap.get("RESULT_SET_ONE");
		List resultListOut = new ArrayList();
		
		if (resultListIn == null) return responseMap;
		
		for (int i = 0; i < resultListIn.size(); i++)
		{
			writeInToOut = true;
			UrUsageDO usage = (UrUsageDO)resultListIn.get(i);
			String usageDate = removeFormattingFromNumber(usage.getDate());
			
			//if usage before start date/time do not write to output
			if (urDO.getStartDate().equals(usageDate))
			{
				// if usage time less than the start time
				if (usage.getTime().compareTo(urDO.getStartTime()) < 0)
				{
					writeInToOut = false;
				}
			}
			
			
			//if usage after stop date/time do not write to output
			if (urDO.getStopDate().equals(usageDate))
			{
				// if usage time greater than stop tome
				if (usage.getTime().compareTo(urDO.getStopTime()) > 0)
				{
					writeInToOut = false;
				}
			}
		
			if (writeInToOut)
			{
				resultListOut.add(usage);
			}
		}
		
		responseMap.put("RESULT_SET_ONE", resultListOut);
		
		return responseMap;
	}
	
	/* takes a string and returns only the numbers */
 	public static String removeFormattingFromNumber (String in)
 	{
 		StringBuffer out = new StringBuffer();
 
 		//walk thru the string looking for numbers
 		//if found a number add to output.
 		for (int i = 0; i < in.length(); i++)
 		{
 			String x = in.substring(i, i+1);

 			if (Character.isDigit(in.charAt(i)))
 			{
 				out.append(x);
 			}
 		}
 		return out.toString();
 	}

}
