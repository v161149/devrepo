package com.verizon.enterprise.ncasbosi.dao.Impl.perf;

import org.apache.log4j.Logger;
import  com.verizon.enterprise.ncasbosi.common.BatchProcessorHelper;
import com.verizon.enterprise.ncasbosi.dao.Impl.payments.PaymentsDAOImpl;
import com.verizon.enterprise.common.ncas.NcasConstants;

public class LogPerfBatchImpl
{
	private static final Logger __Logger = Logger.getLogger(LogPerfBatchImpl.class);
	
	public static synchronized void runPerfAnalyzer() throws Exception
	{
		final String METHOD_NAME = "LogPerfBatchImpl::runPerfAnalyzer()";
		__Logger.info("ENTER " + METHOD_NAME);
		boolean canProcess = false;
		PaymentsDAOImpl payDaoImplObj = new PaymentsDAOImpl();
		BatchProcessorHelper helper = new BatchProcessorHelper(NcasConstants.BATCH_PERF_ONETIME);
		LogPerfHelper logFile = LogPerfHelper.getInstance();
		try
		{
			canProcess = helper.lock();
			if(canProcess)
			{
				logFile.logAnalysis("VBCCIBR");
				logFile.logAnalysis("VBCIBR");
				//helper.unlockBatchControl();
			}
			else
			{
				__Logger.info(METHOD_NAME+"Batch ::"+METHOD_NAME+" already running. So not invoking.");
				payDaoImplObj.insertInternalEmail("PORTAL_BILLING_NOTIF_TEMPLATE","Batch ::"+METHOD_NAME+" already running. So not invoking.",METHOD_NAME);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			__Logger.error(METHOD_NAME + " Exception Outer ::"+ex.getMessage());
			payDaoImplObj.insertInternalEmail("PORTAL_BILLING_NOTIF_TEMPLATE",ex.getMessage(),METHOD_NAME);
		}
		finally
		{
			if (canProcess == true)
			{
				helper.unlockBatchControl();
			}
		}
		__Logger.info("EXIT " + METHOD_NAME);
	}
}
