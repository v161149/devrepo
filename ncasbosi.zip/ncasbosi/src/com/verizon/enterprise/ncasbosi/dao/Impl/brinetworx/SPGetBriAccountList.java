package com.verizon.enterprise.ncasbosi.dao.Impl.brinetworx;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.brinetworx.BriAccount;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetBriAccountList extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetBriAccountList.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
	     spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetBriAccountListMapper()});
		 
		 spInOutList.add(new Object[]{"CALLER_ID",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"EMAILADDR",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PORTAL",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"STATUS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"MESSAGE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	}

	public SPGetBriAccountList(DataSource dataSource){
		super(dataSource, getBRISchemaName() + "." + "pe6gEntitledAccts", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map requestMap = (HashMap)input;
		BriAccount briAccout = (BriAccount)requestMap.get("briAccount");
		
		String portal = "";
		if (briAccout.getPortal().equalsIgnoreCase("NX")) {
			portal = "004";
		} else if (briAccout.getPortal().equalsIgnoreCase("NE")) {
			portal = "005";
		}
		
		String callerId = "INV";
		
		List callList = new ArrayList();
		callList.add(callerId); 
		callList.add(briAccout.getEmail());    
		callList.add(portal);            
		
		Map responseMap = executeSP(callList, false);
		
		_LOGGER.info("Now calling checkBRIStatus to identify any errors or issued warnings");
		checkBRIStatus(responseMap);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
	}
	
	/**
	 * Method that checks if BRI has returned a response with any warnings or errors
	 * @param resMap
	 */
	 protected void checkBRIStatus(Map resMap)throws Exception
	{
		_LOGGER.info("Entering in method checkBRIStatus(Map resMap)");
		Object statusObj = null;
		String status = null;		
		if(resMap != null)
		{
		   statusObj = resMap.get("STATUS");
		   if(statusObj != null)
		   {
			  status = (String)statusObj;

			  if(status.equalsIgnoreCase("00") || 
					  status.equalsIgnoreCase("20") ||
					  status.equalsIgnoreCase("21"))					  
			  {
				  
				String responseMap = CommonUtil.mapToString(resMap);
				_LOGGER.info("ResponseMap::"+responseMap);
				_LOGGER.info("BRI Response has no errors or warnings");		
		
			  }
			  else 
			  {
				  String errorMsg = CommonUtil.mapToString(resMap);
				  _LOGGER.error("Error encountered in the BRI Response "+errorMsg);				
				  throw new SQLException("BRI BAD Response "+errorMsg);				  
				  
			  }
		   }
		}
		else
		{
			_LOGGER.info("Map passed to the method checkBRIStatus was null");
		}
		_LOGGER.info("Exiting method checkBRIStatus");
		
	}
}
