package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;


public class GetSMPContractsRowMapperImpl implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetSMPContractsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetSMPContractsRowMapperImpl::getEMediaSummaryDeferredDownload()";

		logger.debug(METHOD_NAME + " ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		String smpContractId = "";
		EMediaDropDown eMediaDropDown = null;
		List smpContractIdList = new ArrayList();;

		try
		{
			while (rs.next())
			{
				eMediaDropDown = new EMediaDropDown();
				smpContractId = rs.getString("SMP_CONTRACT_ID");

				if(CommonUtil.isNotNull(smpContractId))
				{
					eMediaDropDown.setDropDownCode(smpContractId.trim());
				}

				if(CommonUtil.isNotNull(smpContractId))
				{
					eMediaDropDown.setDropDownDisplay(smpContractId.trim());
				}

				smpContractIdList.add(eMediaDropDown);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();

			logger.info(METHOD_NAME + " Exception occured while parsing resultset \n" + ex.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing resultset \n" + ex.getMessage());
		}

		logger.debug(METHOD_NAME + " EXIT");

		return smpContractIdList;
	}
}
