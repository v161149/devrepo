package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;


public class SPGetGBROrgs extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetGBROrgs.class);
	
	private static List spInOutList;
	
	private static GetGBROrgsRowMapperImpl rowMapper;
	
	static
	{
		 rowMapper = new GetGBROrgsRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"gbrOrgs",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORG_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORG_LEVEL1_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 
	}
	
	public SPGetGBROrgs(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_GBR_ORG, spInOutList);	
	}

	public Map executeStoredProcedure(String userId,String debugLevel,Map input)throws Exception
	{
		
		_LOGGER.debug("entering  executeStoredProcedure api");
		
		String gbrAcctNum      = (String) input.get("gbrAcctNum");
		String orgLevel1Number = (String) input.get("orgLevel1Number");
		String sortOrder       = (String) input.get("sortBy");
		String orgOid = "";
		
		List paramValueList = new ArrayList();
		List orgPairs = new ArrayList();
		List org1s = new ArrayList();
		Map resultMap = new HashMap();
		
		StringBuffer myParams = new StringBuffer();
		myParams.append("SP Params [");

		paramValueList.add(userId);//APP_USER_ID
		myParams.append(userId + "^");

		paramValueList.add(debugLevel);//DEBUG_LEVEL
		myParams.append(debugLevel + "^");
		
		paramValueList.add(input.get("configSubsOid")); //CONFIG_SUBS_OID
		myParams.append(input.get("configSubsOid") + "^");
		
		_LOGGER.debug("orgLevel1Number = " + orgLevel1Number);
		
		if(orgLevel1Number == null || "".equalsIgnoreCase(orgLevel1Number))
		   orgOid = "A";
		else
			orgOid = "2";
		
		if(orgOid == null) orgOid = "";
		paramValueList.add(orgOid); //ORG_OID
		myParams.append(orgOid + "^");
		
		if(orgLevel1Number == null) orgLevel1Number = "";
		paramValueList.add(orgLevel1Number); //ORG_LEVEL1_NO
		myParams.append(orgLevel1Number + "^");
		
		if(sortOrder == null) sortOrder = "";
		paramValueList.add(sortOrder); //SORT_ORDER
		myParams.append(sortOrder + "]");
		
		_LOGGER.debug(myParams.toString());
		
		Map procMap = (HashMap) executeStoredProcedure(paramValueList);
		//return executeStoredProcedure(paramValueList);
		
		_LOGGER.debug("after executing api");
		
		Map  gbrMap = (Map)procMap.get("gbrOrgs");
		_LOGGER.debug("after getting gbrMap");
		
		orgPairs = (ArrayList) gbrMap.get("orgPairs");
		org1s = (ArrayList) gbrMap.get("org1s");
		
		
		_LOGGER.debug("after getting orgPairs size = " + orgPairs.size());
		_LOGGER.debug("after getting orgPairs size = " + org1s.size());	
		
		return procMap;
	
				
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
