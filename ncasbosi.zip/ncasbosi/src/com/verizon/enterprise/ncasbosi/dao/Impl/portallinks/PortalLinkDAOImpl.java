package com.verizon.enterprise.ncasbosi.dao.Impl.portallinks;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Arrays;

import com.sun.tools.jdi.LinkedHashMap;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.custom.*;
import com.verizon.enterprise.common.ncas.display.Label;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncasbosi.beans.*;
import com.verizon.enterprise.ncasbosi.dao.Interface.portallinks.PortalLinkInterface;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;


public class PortalLinkDAOImpl extends JdbcDaoSupport implements PortalLinkInterface, NCASBOSIConstants {

private static final Logger _LOGGER = Logger.getLogger(PortalLinkDAOImpl.class);

private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";


private SqlUpdate insertLinkSqlUpdate = null;
private SqlUpdate updateLinkSqlUpdate = null;
private SqlUpdate deleteLinkSqlUpdate = null;
private BatchSqlUpdate insertPermLinkSqlUpdate = null;
private SqlUpdate deletePermLinkSqlUpdate = null;
private BatchSqlUpdate insertExclLinkSqlUpdate = null;
private SqlUpdate deleteExclLinkSqlUpdate = null;
private BatchSqlUpdate insertOrLinkSqlUpdate = null;
private BatchSqlUpdate updateOrLinkSqlUpdate = null;
private SqlUpdate deleteOrLinkSqlUpdate = null;
private SqlUpdate insertSectionLinkSqlUpdate = null;
private BatchSqlUpdate updateSectionLinkSqlUpdate = null;
private SqlUpdate deleteSectionLinkSqlUpdate = null;
private SqlUpdate deleteAllLinksFromSectionSqlUpdate = null;
private BatchSqlUpdate updateLinkOrderSqlUpdate = null;
private SqlUpdate insertLinkGroupSqlUpdate = null;
private SqlUpdate deleteLinkGroupSqlUpdate = null;
private SqlUpdate insertSectionDataSqlUpdate = null;
private SqlUpdate updateSectionDataSqlUpdate = null;
private SqlUpdate deleteSectionDataSqlUpdate = null;
private SqlUpdate insertPageDataSqlUpdate = null;
private SqlUpdate updatePageDataSqlUpdate = null;
private SqlUpdate deletePageDataSqlUpdate = null;
private SqlUpdate insertPageSectionSqlUpdate = null;
private BatchSqlUpdate updatePageSectionSqlUpdate = null;
private SqlUpdate deleteAllSectionsFromPageSqlUpdate = null;
private SqlUpdate deletePageSectionSqlUpdate = null;
private BatchSqlUpdate updateSectionOrderSqlUpdate = null;
private SqlUpdate deleteSectionRefSqlUpdate = null;
private SqlUpdate deleteSectionReferenceSqlUpdate = null;
private SqlUpdate deletePageRefSqlUpdate = null;
private SqlUpdate deleteLinkReferenceSqlUpdate = null;
private SqlUpdate updateLinkGroupSqlUpdate = null;

private SqlUpdate insertButtonSqlUpdate = null;
private SqlUpdate updateButtonSqlUpdate = null;
private SqlUpdate deleteButtonSqlUpdate = null;
private BatchSqlUpdate insertPermButtonSqlUpdate = null;
private SqlUpdate deletePermButtonSqlUpdate = null;
private BatchSqlUpdate insertExclButtonSqlUpdate = null;
private SqlUpdate deleteExclButtonSqlUpdate = null;
private BatchSqlUpdate updateBtnOrderSqlUpdate = null;

private SelectByPage selectByPage;
private SelectHeaderText selectHeaderText;
private SelectAllPortalLinks selectAllPortalLinks;
private SelectAllPortalNames selectAllPortalNames;
private SelectLinkKey selectLinkKey;
private SelectAllButtons selectAllButtons;
private SelectLinkOrders selectLinkOrders;
private SelectDashBoard selectDashBoardLinks;
private SelectLinkNamesKeys selectLinkNamesKeys;
private SelectLinkNamesDescKeys selectLinkNamesDescKeys;
private SelectLinkPermissions selectLinkPermissions;
private SelectLinkExclusions selectLinkExclusions;
private SelectLinkOverrides selectLinkOverrides;
private SelectLinkGroups selectLinkGroups;
private SelectAllPortalSections selectAllPortalSections;
private SelectSectionDetails selectSectionDetails;
private SelectAllPortalPages selectAllPortalPages;
private SelectPageDetails selectPageDetails;
private SelectSectionsForPage selectSectionsForPage;
private SelectLinksForSection selectLinksForSection;
private SelectSectionOrders selectSectionOrders;
private SelectLinkInfo selectLinkInfo;
private SelectAllLinkPermissions selectAllLinkPermissions;
private SelectAllLinkExclusions selectAllLinkExclusions;
private SelectAllOverrideLinks selectAllOverrideLinks;
private SelectAllSectionLinkKeys selectAllSectionLinkKeys;
private SelectAllPageSectionKeys selectAllPageSectionKeys;
private SelectLinkGroupKeys selectLinkGroupKeys;
private SelectAllLinkOrders selectAllLinkOrders;
private SelectAllSectionOrders selectAllSectionOrders;
private SelectLinkGroupInfo selectLinkGroupInfo;
private SelectSectionLinkInfo selectSectionLinkInfo;
private SelectPageSectionInfo selectPageSectionInfo;
private SelectLinksAndLinkGroupKeys selectLinksAndLinkGroupKeys;
private SelectAllBillingMetrics selectAllBillingMetrics;
private SelectBillingMetricsDetails selectBillingMetricsDetails;

private SelectButtonNamesKeys selectButtonNamesKeys;
private SelectPageAttr selectPageAttr;
private SelectBtnPageId selectBtnPageId;
private SelectAllButtonPermissions selectAllButtonPermissions;
private SelectAllButtonExclusions selectAllButtonExclusions;
private SelectButtonInfo selectButtonInfo;
private SelectButtonExclusions selectButtonExclusions;
private SelectButtonPermissions selectButtonPermissions;
private SelectAllBtnOrders selectAllBtnOrders;
private SelectBtnOrders selectBtnOrders;
private SelectBtnsForPage selectBtnsForPage;
private SelectAllBtnKeys selectAllBtnKeys;
private SelectBtnOrderForBtn selectBtnOrderForBtn;
private SelectMiscForBtn selectMiscForBtn;

int MAX_PERMS = 500;
String SELECT_SECTIONS = "";

String SELECT_SECTIONS1 = "select s.HEADERTEXT, s.INTL_HEADER,s.INTL_INTRO, s.INTROTEXT, s.SECTIONKEY, ps.sectionorder, gl.GROUPTYPE, gl.LINKGROUPKEY, sl.linkorder, ll.NAME, ll.TYPE, ll.EXT_FUNC, ll.INTL_NAME,ll.INTL_TOOLTIP,ll.TOOLTIP, ll.TRACK_NAME from "+getSchemaName()+".pl_page_data p inner join "+getSchemaName()+".pl_page_Section ps on p.pagekey = ps.page_key inner join "+getSchemaName()+".pl_section_data s on ps.section_key = s.sectionkey inner join "+getSchemaName()+".pl_section_link sl on s.sectionkey = sl.sectionkey inner join "+getSchemaName()+".pl_group_link gl on sl.LINKGROUPKEY = gl.LINKGROUPKEY inner join (select l1.* from "+getSchemaName()+".pl_link l1 , "+getSchemaName()+".pl_linkpermincl perm where l1.link_key = perm.link_key and perm.name in (";
String SELECT_SECTIONS2 = ") union select * from "+getSchemaName()+".pl_link l2 where l2.link_key not in (select link_key from "+getSchemaName()+".pl_linkpermincl perm2)) ll on sl.link_key = ll.link_key where p.pageid = ? and s.sectiontype in ('X','L') and s.user_type in ( '',? ) and not exists (select * from "+getSchemaName()+".pl_linkportalexl exl where exl.link_key = ll.link_key and portal = ? ) order by ps.sectionorder, sl.linkorder with ur";

String SELECT_ALL_LINKS = "SELECT A.LINK_KEY,A.NAME,A.DESC,A.TOOLTIP,A.EXT_FUNC,A.TYPE,A.INTL_NAME,A.INTL_TOOLTIP,A.ADMIN,B.NAME AS PERMNAME, C.PORTAL, A.USER_TYPE, D.PORTAL AS PORTAL_OVR, D.OR_LINK_KEY,A.TRACK_NAME FROM "+getSchemaName()+".PL_LINK A LEFT OUTER JOIN "+getSchemaName()+".PL_LINKPERMINCL B ON (A.LINK_KEY=B.LINK_KEY) LEFT OUTER JOIN "+getSchemaName()+".PL_LINKPORTALEXL C ON (A.LINK_KEY=C.LINK_KEY) LEFT OUTER JOIN "+getSchemaName()+".PL_LINKPORTALOVR D ON (A.LINK_KEY=D.LINK_KEY)";

String SELECT_ALL_BUTTONS = "select * from ( select b1.*  from  "+getSchemaName()+".pl_BTN b1 ,  "+getSchemaName()+".PL_BTNpermincl perm  where b1.btn_key = perm.btn_key and perm.name in (";
String SELECT_ALL_BUTTONS2 = " union select * from "+getSchemaName()+".pl_btn b2 where b2.btn_key not in (select btn_key from "+getSchemaName()+".pl_btnpermincl perm2) ) b3 where not exists (select * from "+getSchemaName()+".pl_btnportalexl exl where exl.btn_key = b3.btn_key and portal = ?  ) ORDER BY BTN_ORDER";
String SELECT_ALL_PORTAL_NAMES = "SELECT PORTAL_INDICATOR,DESCRIPTION FROM ESGAPP.PORTAL";
String SELECT_LINK_KEY = "SELECT LINK_KEY FROM "+getSchemaName()+".PL_LINK WHERE TYPE=?";
String SELECT_LINK_NAMES = "SELECT DISTINCT NAME, LINK_KEY FROM "+getSchemaName()+".PL_LINK";
String SELECT_LINK_NAMES_DESC = "SELECT DISTINCT NAME, LINK_KEY, DESC FROM "+getSchemaName()+".PL_LINK";
String SELECT_LINK_ORDERS = "SELECT LINK_KEY,LINKORDER FROM " + getSchemaName() + ".PL_SECTION_LINK WHERE SECTIONKEY =?";
String SELECT_LINK_INFO = "SELECT NAME,TYPE,DESC,TOOLTIP,EXT_FUNC,INTL_NAME,INTL_TOOLTIP,USER_TYPE,ADMIN,TRACK_NAME FROM " + getSchemaName() + ".PL_LINK WHERE LINK_KEY =?";
String SELECT_LINK_PERMS = "SELECT NAME FROM "+ getSchemaName()+".PL_LINKPERMINCL WHERE LINK_KEY=?";
String SELECT_LINK_EXCLS = "SELECT PORTAL FROM "+ getSchemaName()+".PL_LINKPORTALEXL WHERE LINK_KEY=?";
String SELECT_LINK_OVERRIDES = "SELECT OR_LINK_KEY,PORTAL FROM "+ getSchemaName()+".PL_LINKPORTALOVR WHERE LINK_KEY=?";
String SELECT_LINK_GROUPS = "SELECT LINKGROUPKEY,DESC FROM "+getSchemaName()+".PL_GROUP_LINK";
String SELECT_ALL_SECTIONS = "SELECT DESC,SECTIONKEY FROM "+getSchemaName()+".PL_SECTION_DATA";
String SELECT_SECTION_DETAILS = "SELECT DESC,SECTIONTYPE,HEADERTEXT,INTROTEXT,USER_TYPE,INTL_HEADER,INTL_INTRO FROM "+getSchemaName()+".PL_SECTION_DATA WHERE SECTIONKEY=?";
String SELECT_ALL_PAGES = "SELECT DESC,PAGEKEY FROM "+getSchemaName()+".PL_PAGE_DATA";
String SELECT_PAGE_DETAILS = "SELECT PAGEID,DESC,PAGETYPE,HEADERTEXT,INTROTEXT,INTL_HEADER,INTL_INTRO FROM "+getSchemaName()+".PL_PAGE_DATA WHERE PAGEKEY=?";
String SELECT_SECTIONS_FOR_PAGE = "SELECT B.DESC,B.SECTIONKEY FROM "+getSchemaName()+".PL_PAGE_SECTION A, "+getSchemaName()+".PL_SECTION_DATA B WHERE A.PAGE_KEY=? AND A.SECTION_KEY=B.SECTIONKEY";
String SELECT_LINKS_FOR_SECTION = "SELECT B.NAME,B.LINK_KEY FROM "+getSchemaName()+".PL_SECTION_LINK A, "+getSchemaName()+".PL_LINK B WHERE A.SECTIONKEY=? AND A.LINK_KEY=B.LINK_KEY";
String SELECT_SECTION_ORDERS = "SELECT SECTION_KEY,SECTIONORDER FROM " + getSchemaName() + ".PL_PAGE_SECTION WHERE PAGE_KEY =?";
String SELECT_EXCL_LINKS = "SELECT DISTINCT PORTALEX_KEY FROM "+getSchemaName()+".PL_LINKPORTALEXL";
String SELECT_LINK_PERMISSIONS = "SELECT DISTINCT PERMLINK_KEY FROM "+getSchemaName()+".PL_LINKPERMINCL";
String SELECT_OVER_LINKS = "SELECT DISTINCT PORTALOV_KEY FROM "+getSchemaName()+".PL_LINKPORTALOVR";
String SELECT_SECTIONLINK_KEYS = "SELECT SECTIONLINKKEY FROM "+getSchemaName()+".PL_SECTION_LINK";
String SELECT_PAGESECTION_KEYS = "SELECT PAGESECTIONKEY FROM "+getSchemaName()+".PL_PAGE_SECTION";
String SELECT_LINK_GROUP_KEYS = "SELECT LINKGROUPKEY FROM "+getSchemaName()+".PL_GROUP_LINK";
String SELECT_LINKS_AND_GROUP_KEYS = "SELECT LINK_KEY, LINKGROUPKEY FROM "+getSchemaName()+".PL_SECTION_LINK WHERE SECTIONKEY = ?";
String SELECT_ALL_LINK_ORDERS = "SELECT DISTINCT LINKORDER FROM "+getSchemaName()+".PL_SECTION_LINK";
String SELECT_ALL_SECTION_ORDERS = "SELECT DISTINCT SECTIONORDER FROM "+getSchemaName()+".PL_PAGE_SECTION";
String SELECT_LINK_GROUP_INFO = "SELECT GROUPTYPE, DESC FROM "+getSchemaName()+".PL_GROUP_LINK WHERE LINKGROUPKEY=?";
String SELECT_LINK_INFO_FOR_SECTION_LINK = "SELECT LINKORDER,LINKGROUPKEY FROM "+getSchemaName()+".PL_SECTION_LINK  WHERE SECTIONKEY =? AND LINK_KEY= ?";
String SELECT_SECTION_INFO_FOR_PAGE_SECTION = "SELECT SECTIONORDER FROM "+getSchemaName()+".PL_PAGE_SECTION  WHERE PAGE_KEY = ? AND SECTION_KEY =?";

String SELECT_DASHBOARD1 = "select s.headertext,l.name, l.desc, l.tooltip, l.ext_func, l.type from  "+getSchemaName()+".pl_section_data s,  "+getSchemaName()+".pl_section_link sl,  "+getSchemaName()+".pl_group_link gl,  "+getSchemaName()+".pl_link l  where s.sectiontype=? and s.sectionkey = sl.sectionkey and sl.LINKGROUPKEY = gl.LINKGROUPKEY and sl.link_key = l.link_key  and not exists  (select *  from "+getSchemaName()+".pl_linkportalexl exl  where exl.link_key = l.link_key and portal = ?)  and exists  (select perm.link_key  from "+getSchemaName()+".pl_linkpermincl perm  where perm.link_key = l.link_key and perm.name in(";
String SELECT_DASHBOARD2 = ") union select l1.link_key from "+getSchemaName()+".pl_link l1  where l1.link_key = l.link_key  and l1.link_key not in (select link_key from "+getSchemaName()+".pl_linkpermincl perm) ) order by sl.linkorder";
String SELECT_DASHBOARD = "";
String SELECT_SECT = "";
String SELECT_SECT1 = "select s.HEADERTEXT, s.INTL_HEADER, ps.sectionorder from "+getSchemaName()+".pl_page_data p inner join "+getSchemaName()+".pl_page_Section ps "+
        "on p.pagekey = ps.page_key inner join "+getSchemaName()+".pl_section_data s on ps.section_key = s.sectionkey "+
        "inner join "+getSchemaName()+".pl_section_link sl on s.sectionkey = sl.sectionkey inner join "+getSchemaName()+".pl_group_link gl "+
        "on sl.LINKGROUPKEY = gl.LINKGROUPKEY inner join (select l1.* from "+getSchemaName()+".pl_link l1 , "+getSchemaName()+".pl_linkpermincl perm "+
        "where l1.link_key = perm.link_key and perm.name in (";
String SELECT_SECT2 = ") union select * from "+getSchemaName()+".pl_link l2 "+
        "where l2.link_key not in (select link_key from "+getSchemaName()+".pl_linkpermincl perm2)) ll on sl.link_key = ll.link_key "+
        "where p.pageid = ? and s.sectiontype in ('T','D') and s.user_type in ( '', ? ) and not exists (select * from "+getSchemaName()+".pl_linkportalexl exl "+
        "where exl.link_key = ll.link_key and portal = ?) group by  s.HEADERTEXT, s.INTL_HEADER, ps.sectionorder order by ps.sectionorder with ur";

String SELECT_ALL_BILLING_METRICS = "SELECT * FROM metrics5.tx_name WHERE GROUP_OID='1' ORDER BY TIMESTAMP DESC";
String SELECT_BILLING_METRICS_DETAILS = "SELECT i.NAME,j.tx_name_oid,k.USER_OID,j.START_TIME,j.END_TIME, k.LOG_OID FROM metrics5.tx_name i, metrics5.TRANSACTION j, metrics5.LOG k WHERE j.transaction_oid=k.transaction_oid AND i.tx_name_oid=j.tx_name_oid AND i.NAME = ? AND k.time_oid >= *** AND k.time_oid <= $$$ AND k.portal_oid @@@ ORDER BY k.log_oid DESC";

String SELECT_BTN_NAMES = "SELECT DISTINCT NAME, BTN_KEY FROM "+getSchemaName()+".PL_BTN";
String SELECT_BVIEW_PAGE_ATTR = "SELECT DISTINCT PAGE_ATTR FROM "+getSchemaName()+".PL_BVIEW_TYPE WHERE PAGE_ID = ?";
String SELECT_BVIEW_PAGE_ID = "SELECT DISTINCT PAGE_ID FROM "+getSchemaName()+".PL_BVIEW_TYPE ORDER BY PAGE_ID";
String SELECT_BTN_PERMISSIONS = "SELECT DISTINCT PERMBTN_KEY FROM "+getSchemaName()+".PL_BTNPERMINCL";
String SELECT_EXCL_BTN = "SELECT DISTINCT PORTALEX_KEY FROM "+getSchemaName()+".PL_BTNPORTALEXL";
String SELECT_BTN_INFO = "SELECT BTN_KEY, NAME FROM " + getSchemaName() + ".PL_BTN WHERE PAGE_ID =? AND PAGE_ATTR = ? AND CONTENT_ID = ?";
String SELECT_BTN_EXCLS = "SELECT PORTAL FROM "+ getSchemaName()+".PL_BTNPORTALEXL WHERE BTN_KEY=?";
String SELECT_BTN_PERMS = "SELECT NAME FROM "+ getSchemaName()+".PL_BTNPERMINCL WHERE BTN_KEY=?";
String SELECT_ALL_BTN_ORDERS = "SELECT DISTINCT BTN_ORDER FROM "+getSchemaName()+".PL_BTN ORDER BY BTN_ORDER";
String SELECT_BTNS_FOR_PAGE = "SELECT DISTINCT BTN_KEY, NAME, BTN_ORDER FROM "+getSchemaName()+".PL_BTN WHERE PAGE_ID = ? AND PAGE_ATTR = ? AND CONTENT_ID = ? ORDER BY BTN_ORDER";
String SELECT_BTN_ORDERS = "SELECT BTN_KEY,BTN_ORDER FROM " + getSchemaName() + ".PL_BTN WHERE PAGE_ID =? AND PAGE_ATTR = ? AND CONTENT_ID = ?";
String SELECT_ALL_BTN_KEYS = "SELECT DISTINCT BTN_KEY FROM "+ getSchemaName() + ".PL_BTN";
String SELECT_BTN_ORDER_FOR_BTN = "SELECT DISTINCT BTN_ORDER FROM "+ getSchemaName() + ".PL_BTN WHERE PAGE_ID = ? AND PAGE_ATTR = ? AND CONTENT_ID = ? AND BTN_KEY = ?";
String SELECT_MISC_FOR_BTN = "SELECT MISC FROM "+ getSchemaName() + ".PL_BTN WHERE PAGE_ID = ? AND PAGE_ATTR = ? AND CONTENT_ID = ? AND BTN_KEY = ?";

String GLOBAL_APP_NAME = "";
private JdbcTemplate dbTemplate;

protected JdbcTemplate getDBTemplate()
{
	if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
		this.dbTemplate = new JdbcTemplate(getDataSource());
	return dbTemplate;
}


protected void initDao() throws Exception{
	super.initDao();
	String SEC_SQL = "";
	for(int i=0;i<MAX_PERMS;i++){
		if(SEC_SQL.equals(""))
			SEC_SQL = SELECT_SECTIONS1 + "?";
		else SEC_SQL += ",?";
	}

	SEC_SQL += SELECT_SECTIONS2;
	SELECT_SECTIONS = SEC_SQL;

		SEC_SQL = "";
		for(int i=0;i<MAX_PERMS;i++){
			if(SEC_SQL.equals(""))
				SEC_SQL = SELECT_DASHBOARD1 + "?";
			else SEC_SQL += ",?";
		}

		SEC_SQL += SELECT_DASHBOARD2;
		SELECT_DASHBOARD = SEC_SQL;

		SEC_SQL = "";
		for(int i=0;i<MAX_PERMS;i++){
			if(SEC_SQL.equals(""))
				SEC_SQL = SELECT_SECT1 + "?";
			else SEC_SQL += ",?";
		}

		SEC_SQL += SELECT_SECT2;
		SELECT_SECT = SEC_SQL;

		SEC_SQL = "?";
		for(int i=0;i<MAX_PERMS-1;i++){
		   SEC_SQL += ",?";
		}
		SEC_SQL += ")";
		SELECT_ALL_BUTTONS += SEC_SQL;
		SELECT_ALL_BUTTONS += SELECT_ALL_BUTTONS2;

		selectAllButtons = new SelectAllButtons(SELECT_ALL_BUTTONS) ;
		selectByPage = new SelectByPage(SELECT_SECTIONS) ;

		selectHeaderText = new SelectHeaderText(SELECT_SECT);
		selectAllPortalLinks = new SelectAllPortalLinks(SELECT_ALL_LINKS) ;
		selectDashBoardLinks = new SelectDashBoard(SELECT_DASHBOARD) ;
		selectAllPortalNames = new SelectAllPortalNames(SELECT_ALL_PORTAL_NAMES) ;
		selectLinkGroups = new SelectLinkGroups(SELECT_LINK_GROUPS) ;
	    selectLinkGroupKeys = new SelectLinkGroupKeys(SELECT_LINK_GROUP_KEYS) ;
	    selectLinksAndLinkGroupKeys = new SelectLinksAndLinkGroupKeys(SELECT_LINKS_AND_GROUP_KEYS) ;
		selectLinkGroupInfo = new SelectLinkGroupInfo(SELECT_LINK_GROUP_INFO) ;
		 selectLinkKey = new SelectLinkKey(SELECT_LINK_KEY) ;
		 selectSectionLinkInfo = new SelectSectionLinkInfo(SELECT_LINK_INFO_FOR_SECTION_LINK);
		 selectPageSectionInfo = new SelectPageSectionInfo(SELECT_SECTION_INFO_FOR_PAGE_SECTION);
		 selectSectionsForPage = new SelectSectionsForPage(SELECT_SECTIONS_FOR_PAGE);
		 selectLinksForSection = new SelectLinksForSection(SELECT_LINKS_FOR_SECTION);
		 selectLinkNamesKeys = new SelectLinkNamesKeys(SELECT_LINK_NAMES) ;
		 selectLinkNamesDescKeys = new SelectLinkNamesDescKeys(SELECT_LINK_NAMES_DESC) ;
		 selectAllLinkPermissions = new SelectAllLinkPermissions(SELECT_LINK_PERMISSIONS) ;
		 selectAllLinkOrders = new SelectAllLinkOrders(SELECT_ALL_LINK_ORDERS) ;
		 selectAllSectionOrders = new SelectAllSectionOrders(SELECT_ALL_SECTION_ORDERS) ;
		 selectAllLinkExclusions = new SelectAllLinkExclusions(SELECT_EXCL_LINKS) ;
		 selectAllOverrideLinks = new SelectAllOverrideLinks(SELECT_OVER_LINKS) ;
		 selectAllSectionLinkKeys = new SelectAllSectionLinkKeys(SELECT_SECTIONLINK_KEYS) ;
		 selectAllPageSectionKeys = new SelectAllPageSectionKeys(SELECT_PAGESECTION_KEYS) ;
		 selectLinkExclusions = new SelectLinkExclusions(SELECT_LINK_EXCLS) ;
		 selectLinkPermissions = new SelectLinkPermissions(SELECT_LINK_PERMS) ;
		 selectLinkOverrides = new SelectLinkOverrides(SELECT_LINK_OVERRIDES) ;
		 selectLinkInfo = new SelectLinkInfo(SELECT_LINK_INFO) ;
		 selectSectionDetails = new SelectSectionDetails(SELECT_SECTION_DETAILS) ;
		 selectPageDetails = new SelectPageDetails(SELECT_PAGE_DETAILS) ;
		 selectSectionOrders = new SelectSectionOrders(SELECT_SECTION_ORDERS) ;
		 selectAllPortalPages = new SelectAllPortalPages(SELECT_ALL_PAGES) ;
	 	 selectAllPortalSections = new SelectAllPortalSections(SELECT_ALL_SECTIONS) ;
		 selectLinkOrders = new SelectLinkOrders(SELECT_LINK_ORDERS) ;
		 selectAllBillingMetrics = new SelectAllBillingMetrics(SELECT_ALL_BILLING_METRICS);
		 selectBillingMetricsDetails = new SelectBillingMetricsDetails(SELECT_BILLING_METRICS_DETAILS);
 		 selectButtonNamesKeys = new SelectButtonNamesKeys(SELECT_BTN_NAMES) ;
 		 selectPageAttr = new SelectPageAttr(SELECT_BVIEW_PAGE_ATTR) ;
 		 selectBtnPageId = new SelectBtnPageId(SELECT_BVIEW_PAGE_ID) ;
 		 selectAllBtnOrders = new SelectAllBtnOrders(SELECT_ALL_BTN_ORDERS) ;
 		 selectBtnsForPage = new SelectBtnsForPage(SELECT_BTNS_FOR_PAGE);
 		 selectBtnOrders = new SelectBtnOrders(SELECT_BTN_ORDERS) ;
 		 selectAllBtnKeys = new SelectAllBtnKeys(SELECT_ALL_BTN_KEYS) ;
 		selectAllButtonPermissions = new SelectAllButtonPermissions(SELECT_BTN_PERMISSIONS) ;
 		selectAllButtonExclusions = new SelectAllButtonExclusions(SELECT_EXCL_BTN) ;
 		selectButtonInfo = new SelectButtonInfo(SELECT_BTN_INFO) ;
 		selectBtnOrderForBtn = new SelectBtnOrderForBtn(SELECT_BTN_ORDER_FOR_BTN);
 		selectMiscForBtn = new SelectMiscForBtn(SELECT_MISC_FOR_BTN);
 		selectButtonExclusions = new SelectButtonExclusions(SELECT_BTN_EXCLS) ;
 		selectButtonPermissions = new SelectButtonPermissions(SELECT_BTN_PERMS) ;
}

class SelectHeaderText extends JdbcDaoSupport {
    private String sql;

	public SelectHeaderText(String sql) {
        this.sql = sql;
    }

	public List getHeader(Object[] params,String langCode) {
		 _LOGGER.info("getHeader :: " + params);
		 final String LANG = langCode;
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List sectionList = new ArrayList();
		   		 	  String intlHeader = "";
		   		 	  String header = "";
		   		 	  Map<String,String> langMap = DAOFactory.getInstance().getInternationalImpl().getPreferredLang(LANG, "HOME");
			   		  String value = "";
			          while (rs.next()) {
			  			header = rs.getString("HEADERTEXT");
			  			intlHeader = rs.getString("INTL_HEADER");
			  			if(intlHeader!=null && !intlHeader.isEmpty()){
				  			value = (String)langMap.get(intlHeader.trim());
				  			if(value!=null&&!value.isEmpty())
				  				header = value;
			    	    }
						_LOGGER.debug("#############################The Header text is ::"+header+"::#################");
						sectionList.add(header);
			          }
				      return sectionList;
		        }});
	    }
}

class SelectByPage extends JdbcDaoSupport {
    private String sql;

	public SelectByPage(String sql) {
        this.sql = sql;
    }

	public CPage getCustomPage(Object[] params,String langCode) {
		 _LOGGER.info("getCustomPage :: " + params);
		 final String LANG = langCode;
	        return  (CPage)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

			   		  CPage pg = new CPage();
			   		  Map<String,String> langMap = DAOFactory.getInstance().getInternationalImpl().getPreferredLang(LANG, "HOME");
			   		  String value = "";
			   		  LinkedHashMap sectionCache = new LinkedHashMap();

			   		  String intlHeader = "";
			   		  String header =  "";
			   		  String intlIntro = "";
			   		  String intro = "";
			   		  String sectionKey = "";
			          while (rs.next()) {
			    		CSection section = null;
			  			header = rs.getString("HEADERTEXT");
			  			intlHeader = rs.getString("INTL_HEADER");
			  			intlIntro  = rs.getString("INTL_INTRO");
			  			intro = rs.getString("INTROTEXT");
			  			sectionKey = rs.getString("SECTIONKEY");

			    	    if(intlHeader!=null && !intlHeader.isEmpty()){
				  			value = (String)langMap.get(intlHeader.trim());
				  			if(value!=null&&!value.isEmpty())
				  				header = value;
			    	    }

			    	    if(intlIntro!=null && !intlIntro.isEmpty()){
				  			value = (String)langMap.get(intlIntro.trim());
				  			if(value!=null&&!value.isEmpty())
				  				intro = value;
			    	    }

			  			int index = sectionCache.indexOf(header);
			  			if (index < 0) {
			  				section = new CSection();
			  				pg.getSection().add(section);
			  				sectionCache.put(header, section);
			  				if (CommonUtil.isNotNull(intro)) {
			  				  section.setIntro(intro);
			  				}
			  				if (CommonUtil.isNotNull(header)) {
				  				  section.setHeader(header);
			  				}
			  				if (CommonUtil.isNotNull(sectionKey)) {
				  				  section.setSectionKey(sectionKey);
			  				}
			  			} else {
			  				section = (CSection) (pg.getSection().get(index));
			  			}
			  			//we don't always want to create a link, so
			  			//if we see a null TYPE (this means no Link rows at all)
			  			//don't create link for section
			  			CLink link = null;
			  			String type = rs.getString("TYPE");
			        if (CommonUtil.isNotNull(type) && !type.equalsIgnoreCase("permplacehldr")) {

			  			  link = new CLink();
			  			  String name = rs.getString("NAME");
			    	      String intlName = rs.getString("INTL_NAME");
			    	      String intlTooltip = rs.getString("INTL_TOOLTIP");
			    	      String toolTip = rs.getString("TOOLTIP");

			    	      if(intlName!=null && !intlName.isEmpty()){
			    	    	  value = (String)langMap.get(intlName.trim());
				  		 	if(value!=null&&!value.isEmpty())
				  		 		name = value;
			    	      }
				  		  if (CommonUtil.isNotNull(name))
			  			    link.setName(name);

			              if (CommonUtil.isNotNull(type))
			  			    link.setType(type);

			              if(intlTooltip!=null && !intlTooltip.isEmpty()){
			            	  value = (String)langMap.get(intlTooltip.trim());
				  		      if(value!=null&&!value.isEmpty())
				  			    toolTip = value;
			              }
			          if (CommonUtil.isNotNull(toolTip))
			  		  	  link.setTooltip(toolTip);

			  		  String trackName = rs.getString("TRACK_NAME");
			          if (CommonUtil.isNotNull(trackName))
			  		  	  link.setTrackName(trackName);

			  		  String groupType = rs.getString("GROUPTYPE");
			          if (CommonUtil.isNotNull(groupType) && !groupType.equalsIgnoreCase("X"))
			  		  	  link.setGroupType(groupType);

			          String linkGroupKey = Integer.toString(rs.getInt("LINKGROUPKEY"));
			  			  link.setLinkGroupKey(linkGroupKey);

			  			  String extFunc = rs.getString("EXT_FUNC");
			  			  String tmpStr = "";
			          if (CommonUtil.isNotNull(extFunc)) {
			          	if (type.equalsIgnoreCase("MENU")) {
			          		tmpStr = extFunc;
			          	} else {
			          		if(GLOBAL_APP_NAME.equals(NcasConstants.PAYMENT_HOME)|| GLOBAL_APP_NAME.equals(NcasConstants.VUA_HOME) )
			          			tmpStr = GLOBAL_APP_NAME + ".Handler('" + extFunc + "','"+ trackName + "','')";
			          		else tmpStr = GLOBAL_APP_NAME + ".LnkHndlr('" + extFunc + "','"+ trackName + "','')";
			          	}
			  		  	  link.setExtFunc(tmpStr);
			          }
			        }
			  			section.getLinks().add(link);

			          }
				      return pg;
		        }});
	    }

}



public Map selectAllPortalLinks() throws NCASException {
	 _LOGGER.info("Select SQL: " + SELECT_ALL_LINKS);
	 return selectAllPortalLinks.getAllPortalLinks(new Object[]{});
}


class SelectAllPortalLinks extends JdbcDaoSupport {
   private String sql;

	public SelectAllPortalLinks(String sql) {
       this.sql = sql;
   }

	public Map getAllPortalLinks(Object[] params) {
		 _LOGGER.info("getAllPortalLinks :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map 	 linkMap = new HashMap();
			          while (rs.next()) {
			    		  List permList = new ArrayList();
			    		  List portalList = new ArrayList();
			    	      int key = rs.getInt("LINK_KEY");
			    	      String name = rs.getString("NAME");
			    	      String desc = rs.getString("DESC");
			    	      String tooltip = rs.getString("TOOLTIP");
			    	      String extFunc = rs.getString("EXT_FUNC");
			    	      String type = rs.getString("TYPE");
			    	      String intlName = rs.getString("INTL_NAME");
			    	      String intlTooltip = rs.getString("INTL_TOOLTIP");
			    	      String admin = rs.getString("ADMIN");
			    	      String userType = rs.getString("USER_TYPE");
			    	      String tracking = rs.getString("TRACK_NAME");

			    		  CLink clink = new CLink(key, name, desc, tooltip,extFunc,type,intlName, intlTooltip,admin, userType,"",tracking, "");

			    	      String permLinkName = rs.getString("PERMNAME");
			    	      _LOGGER.debug("permlink->"+permLinkName);

			    	      if(permLinkName != null && !permLinkName.equals(""))
			    	      {
			    			 _LOGGER.debug("There is a permlink");
			    			 CPermission cperm = new CPermission(key,permLinkName);
			    			 permList.add(cperm);
			    		  }

			    	      String portalInd = rs.getString("PORTAL");
			    	      String portalIndForOvr = rs.getString("PORTAL_OVR");
			    	      int orLink = rs.getInt("OR_LINK_KEY");

			    	      if(portalInd != null && ! portalInd.equals(""))
			    	      {
			    			  _LOGGER.debug("There is an exclusion for this link->'"+type+"' for this portal->'"+portalInd+"'");
			    			  CPortal cportal = new CPortal(key,portalInd,0,false);
			    			  portalList.add(cportal);
			    		  }

			    		  if(portalIndForOvr != null && ! portalIndForOvr.equals(""))
			    	      {
			    			  _LOGGER.debug("There is an override for this link->'"+type+"' for this portal->'"+portalIndForOvr+"'");
			    			  CPortal cportal = new CPortal(key,portalIndForOvr,orLink,true);
			    			  portalList.add(cportal);
			    		  }
			    		  if(type!=null && type.trim().length()>0)
			    		  {
			    		   if(linkMap != null && linkMap.size()>0)
			    		   {
			    			   CLink existingClink = (CLink)linkMap.get(type);
			    			   if(existingClink != null)
			    			   {
			    				List existingPortalList = existingClink.getPortal();
			    				if(existingPortalList != null)
			    				{
			    					for(int i=0;i<portalList.size();i++)
			    					{
			    						existingPortalList.add(portalList.get(i));
			    					}
			    				}
			    				List existingPermList = existingClink.getPermission();
			    				if(existingPermList != null)
			    				{
			    					for(int i=0;i<permList.size();i++)
			    					{
			    						existingPermList.add(permList.get(i));
			    					}
			    				}
			    			    existingClink.setPortal(existingPortalList);
			    			    existingClink.setPermission(existingPermList);
			    			    linkMap.remove(type);
			    			    linkMap.put(type,existingClink);
			    		   	   }else
			    		   	   {
			    		   		clink.setPortal(portalList);
			    		   		clink.setPermission(permList);
			    	       		linkMap.put(type, clink);
			    		   		}
			    			}
			    		   else{
			    		   clink.setPortal(portalList);
			    		   clink.setPermission(permList);
			    	       linkMap.put(type, clink);
			    	     }
			       		}
			          }
				      return linkMap;
		        }});
	    }

}

public List selectAllPortalNames() throws NCASException {
	 _LOGGER.info("Select SQL: " + SELECT_ALL_PORTAL_NAMES);
	 return selectAllPortalNames.getAllPortalNames(new Object[]{});
}

class SelectAllPortalNames extends JdbcDaoSupport {
    private String sql;

	public SelectAllPortalNames(String sql) {
        this.sql = sql;
    }

	public List getAllPortalNames(Object[] params) {
		 _LOGGER.info("getAllPortalNames :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List portNameList = new ArrayList();
			          while (rs.next()) {
			    	      String name = rs.getString("PORTAL_INDICATOR");
			    	      portNameList.add(name);
			          }
				      return portNameList;
		        }});
	    }

}

public Map selectLinkGroups() throws NCASException {
	 _LOGGER.info("Select SQL: " + SELECT_LINK_GROUPS);
	 return selectLinkGroups.getLinkGroups(new Object[]{});
}

class SelectLinkGroups extends JdbcDaoSupport {
    private String sql;

	public SelectLinkGroups(String sql) {
        this.sql = sql;
    }

	public Map getLinkGroups(Object[] params) {
		 _LOGGER.info("getLinkGroups :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map linkGrpMap = new HashMap();
		   		 	  List linkGroupList = new ArrayList();
			          while (rs.next()) {
			    	      int key = rs.getInt("LINKGROUPKEY");
			    	      String desc = rs.getString("DESC");
			    	      String finalVal = Integer.toString(key);
			    	      if(desc != null && desc.length()>0)
			    			  finalVal = finalVal+"--"+desc;

			    	      linkGroupList.add(finalVal);
			          }
			          linkGrpMap.put("linkGroupDetails",linkGroupList);
			          return linkGrpMap;
		        }});
	    }

}

public List selectLinkGroupKeys() throws NCASException {

	 return selectLinkGroupKeys.getAllLinkGroupKeys(new Object[]{});
}


class SelectLinkGroupKeys extends JdbcDaoSupport {
    private String sql;

	public SelectLinkGroupKeys(String sql) {
        this.sql = sql;
    }

	public List getAllLinkGroupKeys(Object[] params) {
		 _LOGGER.info("getAllLinkGroupKeys :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List linkGroupKeyList = new ArrayList();
			          while (rs.next()) {
			    	      int key = rs.getInt("LINKGROUPKEY");
			    	      linkGroupKeyList.add(new Integer(key));
			          }
				      return linkGroupKeyList;
		        }});
	    }

}

public Map selectLinksAndLinkGroupKeys(int sectionKey) throws NCASException {
	 return selectLinksAndLinkGroupKeys.getAllLinksAndLinkGroupKeys(new Object[]{new Integer(sectionKey)});
}


class SelectLinksAndLinkGroupKeys extends JdbcDaoSupport {
    private String sql;

	public SelectLinksAndLinkGroupKeys(String sql) {
        this.sql = sql;
    }

	public Map getAllLinksAndLinkGroupKeys(Object[] params) {
		 _LOGGER.info("getAllLinksAndLinkGroupKeys :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map linkGroupKeyMap = new HashMap();
			          while (rs.next()) {
			    	      int key = rs.getInt("LINKGROUPKEY");
			    	      int linkKey = rs.getInt("LINK_KEY");
			    	      linkGroupKeyMap.put(new Integer(linkKey),new Integer(key));
			          }
				      return linkGroupKeyMap;
		        }});
	    }

}



public Map selectLinkGroupInfo(int linkGroupKey) throws NCASException {
	 return selectLinkGroupInfo.getLinkGroupInfo(new Object[]{new Integer(linkGroupKey)});
}
class SelectLinkGroupInfo extends JdbcDaoSupport {
    private String sql;

	public SelectLinkGroupInfo(String sql) {
        this.sql = sql;
    }

	public Map getLinkGroupInfo(Object[] params) {
		 _LOGGER.info("getLinkGroupInfo :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map linkGroupMap = new HashMap();
			          while (rs.next()) {
			    	      String type = rs.getString("GROUPTYPE");
			    	      String desc = rs.getString("DESC");
			    	      linkGroupMap.put(type,desc);
			          }
				      return linkGroupMap;
		        }});
	    }

}

public Integer selectLinkKey(String type) throws NCASException {
	 return selectLinkKey.getLinkKey(new Object[]{type});
}


class SelectLinkKey extends JdbcDaoSupport {
    private String sql;

	public SelectLinkKey(String sql) {
        this.sql = sql;
    }

	public Integer getLinkKey(Object[] params) {
		 _LOGGER.info("getLinkKey :: " + params);
	        return  (Integer)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Integer latestLinkKey = null;
			          while (rs.next()) {
			    	      latestLinkKey = new Integer(rs.getInt("LINK_KEY"));
			          }
				      return latestLinkKey;
		        }});
	    }

}
public Map selectSectionLinkInfo(int sectionKey, int linkKey) throws NCASException {
	 return selectSectionLinkInfo.getSectionLinkInfo(new Object[]{new Integer(sectionKey), new Integer(linkKey)});
}


class SelectSectionLinkInfo extends JdbcDaoSupport {
    private String sql;

	public SelectSectionLinkInfo(String sql) {
        this.sql = sql;
    }

	public Map getSectionLinkInfo(Object[] params) {
		 _LOGGER.info("getSectionLinkInfo :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map sectionLinkInfoMap = new HashMap();
			          while (rs.next()) {
			    	      int linkOrder = rs.getInt("LINKORDER");
			    	      int linkGroupKey = rs.getInt("LINKGROUPKEY");
			    	      sectionLinkInfoMap.put(new Integer(linkOrder),new Integer(linkGroupKey));
			          }
				      return sectionLinkInfoMap;
		        }});
	    }

}
public Map selectPageSectionInfo(int pageKey, int sectionKey) throws NCASException {
	 return selectPageSectionInfo.getPageSectionInfo(new Object[]{new Integer(pageKey), new Integer(sectionKey)});
}


class SelectPageSectionInfo extends JdbcDaoSupport {
    private String sql;

	public SelectPageSectionInfo(String sql) {
        this.sql = sql;
    }

	public Map getPageSectionInfo(Object[] params) {
		 _LOGGER.info("getPageSectionInfo :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map pageSectionInfoMap = new HashMap();
			          while (rs.next()) {
			    	      int sectionOrder = rs.getInt("SECTIONORDER");
			    	      pageSectionInfoMap.put("order",new Integer(sectionOrder));
			          }
				      return pageSectionInfoMap;
		        }});
	    }

}

public Map selectSectionsForPage(int pageKey) throws NCASException {
	 return 	 selectSectionsForPage.getSectionsForPage(new Object[]{new Integer(pageKey)});
}


class SelectSectionsForPage extends JdbcDaoSupport {
    private String sql;

	public SelectSectionsForPage(String sql) {
        this.sql = sql;
    }

	public Map getSectionsForPage(Object[] params) {
		 _LOGGER.info("getSectionsForPage :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map sectionsForPage = new HashMap();
			          while (rs.next()) {
			    	      String desc = rs.getString("DESC");
			    	      int sectionKey = rs.getInt("SECTIONKEY");
			    	      sectionsForPage.put(new Integer(sectionKey),desc);
			          }
				      return sectionsForPage;
		        }});
	    }

}
public Map selectLinksForSection(int sectionKey) throws NCASException {
	 return selectLinksForSection.getLinksForSection(new Object[]{new Integer(sectionKey)});
}


class SelectLinksForSection extends JdbcDaoSupport {
    private String sql;

	public SelectLinksForSection(String sql) {
        this.sql = sql;
    }

	public Map getLinksForSection(Object[] params) {
		 _LOGGER.info("getLinksForSection :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map linksForSections = new HashMap();
			          while (rs.next()) {
			    	      String desc = rs.getString("NAME");
			    	      int linkKey = rs.getInt("LINK_KEY");
			    	      linksForSections.put(new Integer(linkKey),desc);
			          }
				      return linksForSections;
		        }});
	    }

}

public Map selectLinkNamesKeys() throws NCASException {

	 _LOGGER.info("Exiting selectLinkNamesKeys");
	 return selectLinkNamesKeys.getLinkNamesKeys(new Object[]{});
}


class SelectLinkNamesKeys extends JdbcDaoSupport {
    private String sql;

	public SelectLinkNamesKeys(String sql) {
        this.sql = sql;
    }

	public Map getLinkNamesKeys(Object[] params) {
		 _LOGGER.info("getLinkNamesKeys :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map linkKeyNameMap = new HashMap();
			          while (rs.next()) {
			    	      String linkName = rs.getString("NAME");
			    	      int linkKey = rs.getInt("LINK_KEY");
			    	      linkKeyNameMap.put(new Integer(linkKey),linkName);
			    	  }
				      return linkKeyNameMap;
		        }});
	    }

}

public Map selectLinkNamesDescKeys() throws NCASException {

	 _LOGGER.info("Exiting selectLinkNamesKeys");
	 return selectLinkNamesDescKeys.getLinkNamesDescKeys(new Object[]{});
}

class SelectLinkNamesDescKeys extends JdbcDaoSupport {
    private String sql;

	public SelectLinkNamesDescKeys(String sql) {
        this.sql = sql;
    }

	public Map getLinkNamesDescKeys(Object[] params) {
		 _LOGGER.info("getLinkNamesKeys :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map linkKeyNameMap = new HashMap();
		   		 	  Map linkKeyDescMap = new HashMap();
		   		 	  Map resp = new HashMap();
			          while (rs.next()) {
			    	      String linkName = rs.getString("NAME");
			    	      String desc = rs.getString("DESC");
			    	      int linkKey = rs.getInt("LINK_KEY");
			    	      linkKeyNameMap.put(new Integer(linkKey),linkName);
			    	      linkKeyDescMap.put(new Integer(linkKey),desc);
			    	  }
			          resp.put("linkKeyName", linkKeyNameMap);
			          resp.put("linkKeyDesc", linkKeyDescMap);
				      return resp;
		        }});
	    }

}
public List selectAllLinkPermissions() throws NCASException {
	 return selectAllLinkPermissions.getAllLinkPermissions(new Object[]{});
}


class SelectAllLinkPermissions extends JdbcDaoSupport {
    private String sql;

	public SelectAllLinkPermissions(String sql) {
        this.sql = sql;
    }

	public List getAllLinkPermissions(Object[] params) {
		 _LOGGER.info("getAllLinkPermissions :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List permKeyList = new ArrayList();
			          while (rs.next()) {
			    	      int linkKey = rs.getInt("PERMLINK_KEY");
			    	      permKeyList.add(new Integer(linkKey));
			          }
				      return permKeyList;
		        }});
	    }

}


public List selectAllLinkOrders() throws NCASException {
	 return selectAllLinkOrders.getAllLinkOrders(new Object[]{});
}

class SelectAllLinkOrders extends JdbcDaoSupport {
    private String sql;

	public SelectAllLinkOrders(String sql) {
        this.sql = sql;
    }

	public List getAllLinkOrders(Object[] params) {
		 _LOGGER.info("getAllLinkOrders :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List linkOrderList = new ArrayList();
			          while (rs.next()) {
			    	      int linkOrder = rs.getInt("LINKORDER");
			    	      linkOrderList.add(new Integer(linkOrder));
			    	  }
				      return linkOrderList;
		        }});
	    }

}
public List selectAllSectionOrders() throws NCASException {
	 return selectAllSectionOrders.getAllSectionOrders(new Object[]{});
}


class SelectAllSectionOrders extends JdbcDaoSupport {
    private String sql;

	public SelectAllSectionOrders(String sql) {
        this.sql = sql;
    }

	public List getAllSectionOrders(Object[] params) {
		 _LOGGER.info("getAllSectionOrders :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List sectionOrderList = new ArrayList();
			          while (rs.next()) {
			    	      int sectionOrder = rs.getInt("SECTIONORDER");
			    	      sectionOrderList.add(new Integer(sectionOrder));
			          }
				      return sectionOrderList;
		        }});
	    }

}

public List selectAllLinkExclusions() throws NCASException {
	 return selectAllLinkExclusions.getAllLinkExclusions(new Object[]{});
}


class SelectAllLinkExclusions extends JdbcDaoSupport {
    private String sql;

	public SelectAllLinkExclusions(String sql) {
        this.sql = sql;
    }

	public List getAllLinkExclusions(Object[] params) {
		 _LOGGER.info("getAllLinkExclusions :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List exclKeyList = new ArrayList();
			          while (rs.next()) {
			    	      int linkKey = rs.getInt("PORTALEX_KEY");
			    	      exclKeyList.add(new Integer(linkKey));
			          }
				      return exclKeyList;
		        }});
	    }

}
public List selectAllOverrideLinks() throws NCASException {
	 return selectAllOverrideLinks.getAllOverrideLinks(new Object[]{});
}


class SelectAllOverrideLinks extends JdbcDaoSupport {
    private String sql;

	public SelectAllOverrideLinks(String sql) {
        this.sql = sql;
    }

	public List getAllOverrideLinks(Object[] params) {
		 _LOGGER.info("getAllOverrideLinks :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

	   		 	  List overKeyList = new ArrayList();
		          while (rs.next()) {
		    	      int linkKey = rs.getInt("PORTALOV_KEY");
		    	      overKeyList.add(new Integer(linkKey));
		          }
			      return overKeyList;
	        }});
    }

}

public List selectAllSectionLinkKeys() throws NCASException {
	 return selectAllSectionLinkKeys.getAllSectionLinkKeys(new Object[]{});
}



class SelectAllSectionLinkKeys extends JdbcDaoSupport {
    private String sql;

	public SelectAllSectionLinkKeys(String sql) {
        this.sql = sql;
    }

	public List getAllSectionLinkKeys(Object[] params) {
		 _LOGGER.info("getAllSectionLinkKeys :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List sectionLinkList = new ArrayList();
			          while (rs.next()) {
			    	      int linkKey = rs.getInt("SECTIONLINKKEY");
			    	      sectionLinkList.add(new Integer(linkKey));
			          }
				      return sectionLinkList;
		        }});
	    }

}
public List selectAllPageSectionKeys() throws NCASException {
	 return selectAllPageSectionKeys.getAllPageSectionKeys(new Object[]{});
}


class SelectAllPageSectionKeys extends JdbcDaoSupport {
    private String sql;

	public SelectAllPageSectionKeys(String sql) {
        this.sql = sql;
    }

	public List getAllPageSectionKeys(Object[] params) {
		 _LOGGER.info("getAllPageSectionKeys :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List pageSectionList = new ArrayList();
			          while (rs.next()) {
			    	      int pageSecKey = rs.getInt("PAGESECTIONKEY");
			    	      pageSectionList.add(new Integer(pageSecKey));
			          }
				      return pageSectionList;
		        }});
	    }

}
public List selectLinkExclusions(int linkKey) throws NCASException {
	 return selectLinkExclusions.getLinkExclusions(new Object[]{new Integer(linkKey)});
}

class SelectLinkExclusions extends JdbcDaoSupport {
    private String sql;

	public SelectLinkExclusions(String sql) {
        this.sql = sql;
    }

	public List getLinkExclusions(Object[] params) {
		 _LOGGER.info("getLinkExclusions :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List linkExclList = new ArrayList();
			          while (rs.next()) {
			    	      String portalName = rs.getString("PORTAL");
			    	      linkExclList.add(portalName);
			          }
				      return linkExclList;
		        }});
	    }

}
public List selectLinkPermissions(int linkKey) throws NCASException {
	 return  selectLinkPermissions.gettLinkPermissions(new Object[]{new Integer(linkKey)});
}

class SelectLinkPermissions extends JdbcDaoSupport {
    private String sql;

	public SelectLinkPermissions(String sql) {
        this.sql = sql;
    }

	public List gettLinkPermissions(Object[] params) {
		 _LOGGER.info("gettLinkPermissions :: " + params);
	        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  List linkPermList = new ArrayList();
			          while (rs.next()) {
			    	      String permName = rs.getString("NAME");
			    	      linkPermList.add(permName);
			          }
				      return linkPermList;
		        }});
	    }

}
public Map selectLinkOverrides(int linkKey) throws NCASException {
	 return  selectLinkOverrides.getLinkOverrides(new Object[]{new Integer(linkKey)});
}


class SelectLinkOverrides extends JdbcDaoSupport {
    private String sql;

	public SelectLinkOverrides(String sql) {
        this.sql = sql;
    }

	public Map getLinkOverrides(Object[] params) {
		 _LOGGER.info("getLinkOverrides :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map overrideMap = new HashMap();
			          while (rs.next()) {
			    	      int orLinkKey = rs.getInt("OR_LINK_KEY");
			    	      String portal = rs.getString("PORTAL");
			    	      overrideMap.put(portal,new Integer(orLinkKey));
			          }
				      return overrideMap;
		        }});
	    }

}


public Map getLinkDetails(int linkKey) throws NCASException{
	_LOGGER.info("The linkkey is :"+linkKey);
	Map portalLkMap = null;
	PortalLink portalLink = null;
	Map responseMap = new HashMap();
	try{
		portalLkMap = selectLinkInfo(linkKey);
		portalLink = (PortalLink)portalLkMap.get("portalLinkInfo");
		Map portalNamesAndOverKeys = selectLinkOverrides(linkKey);

			List overNamesKeys = new ArrayList();
			Iterator it = portalNamesAndOverKeys.entrySet().iterator();
			String finalVal = "";
			Map currentKeysNames = selectLinkNamesKeys();
			while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry)it.next();
			String portalName = (String)pairs.getKey();
			int lnKey = ((Integer)pairs.getValue()).intValue();

			String nameAvailable = (String)currentKeysNames.get((Integer)pairs.getValue());
			if(nameAvailable!=null && nameAvailable.trim().length()>0)
			{
				if(portalName!=null && portalName.trim().length()>0)
			 {
				finalVal = portalName+"->"+nameAvailable;
				_LOGGER.debug("The final Value is ->"+finalVal);
				overNamesKeys.add(finalVal);
			 }
			}
			else{
				if(portalName!=null && portalName.trim().length()>0)
				{
				 finalVal = portalName+"->"+Integer.toString(lnKey);
				 _LOGGER.debug("The final Value is ->"+finalVal);
				 overNamesKeys.add(finalVal);
			 	}
		 	}

		}
		Map overMap = new HashMap();
		overMap.put("overMap",overNamesKeys);
		portalLink.setOrLinkMap(overMap);
		portalLink.setPermLinkNames(selectLinkPermissions(linkKey));
		portalLink.setPortalIndsForExcl(selectLinkExclusions(linkKey));
		} catch(Exception vamEx) {
			_LOGGER.debug("getLinkDetails in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getLinkDetails in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting getLinkDetails");
	responseMap.put("linkDetails",portalLink);
	return responseMap;
}



public Map selectLinkInfo(int linkKey) throws NCASException {
	 return selectLinkInfo.getLinkInfo(new Object[]{new Integer(linkKey)});
}


class SelectLinkInfo extends JdbcDaoSupport {
    private String sql;

	public SelectLinkInfo(String sql) {
        this.sql = sql;
    }

	public Map getLinkInfo(Object[] params) {
		 _LOGGER.info("getLinkInfo :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map portalLinkMap = new HashMap();
			          while (rs.next()) {
						  String name = rs.getString("NAME");
						  String type = rs.getString("TYPE");
						  String desc = rs.getString("DESC");
						  String tooltip = rs.getString("TOOLTIP");
						  String extFunc = rs.getString("EXT_FUNC");
						  String intlName = rs.getString("INTL_NAME");
						  String intlTooltip = rs.getString("INTL_TOOLTIP");
						  String userType	= rs.getString("USER_TYPE");
						  String admin = rs.getString("ADMIN");
						  String trackName = rs.getString("TRACK_NAME");
						  PortalLink portalLinkInfo = new PortalLink(0,name,desc,tooltip,extFunc,type,intlName,intlTooltip,admin,trackName,null,null,userType,null,"");
						  portalLinkMap.put("portalLinkInfo",portalLinkInfo);
			          }
				      return portalLinkMap;
		        }});
	    }

}



public Map selectSectionDetails(int sectionKey) throws NCASException {
	 return selectSectionDetails.getSectionDetails(new Object[]{new Integer(sectionKey)});
}

class SelectSectionDetails extends JdbcDaoSupport {
	   private String sql;

		public SelectSectionDetails(String sql) {
	       this.sql = sql;
	   }

		public Map getSectionDetails(Object[] params) {
			 _LOGGER.info("getSectionDetails :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map sectionInfo = new LinkedHashMap();
				          while (rs.next()) {
				    	      String desc = rs.getString("DESC");
				    	      String type = rs.getString("SECTIONTYPE");
				    	      String headerText = rs.getString("HEADERTEXT");
				    	      String introText = rs.getString("INTROTEXT");
				    	      String userType = rs.getString("USER_TYPE");
				    	      String intlHeader = rs.getString("INTL_HEADER");
				    	      String intlIntro	= rs.getString("INTL_INTRO");
				    	      Section section = new Section(0,desc,type,headerText,introText,userType,intlHeader,intlIntro,"");
				    	      sectionInfo.put("sectionDetails",section);				          }
					      return sectionInfo;
			        }});
		    }

}
public Map selectPageDetails(int pageKey) throws NCASException {
	 return selectPageDetails.getPageDetails(new Object[]{new Integer(pageKey)});
}


class SelectPageDetails extends JdbcDaoSupport {
	   private String sql;

		public SelectPageDetails(String sql) {
	       this.sql = sql;
	   }

		public Map getPageDetails(Object[] params) {
			 _LOGGER.info("getPageDetails :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map pageInfo = new LinkedHashMap();
				          while (rs.next()) {
				    	      int pageId = rs.getInt("PAGEID");
				    	      String desc = rs.getString("DESC");
				    	      String pageType = rs.getString("PAGETYPE");
				    	      String headerText = rs.getString("HEADERTEXT");
				    	      String introText = rs.getString("INTROTEXT");
				    	      String intlHeader = rs.getString("INTL_HEADER");
				    	      String intlIntro	= rs.getString("INTL_INTRO");
				    	      Page page = new Page(0,pageId,pageType,desc,headerText,introText,intlHeader,intlIntro,"");
				    		  pageInfo.put("pageDetails",page);
				          }
					      return pageInfo;
			        }});
		    }

}

public Map selectDashBoard(String portalType,List permissions) throws NCASException {
	return selectDashBoard("D", portalType,permissions);
}
public Map selectDashBoard(String dashBoardType,String portalType,List permissions) throws NCASException {
	 _LOGGER.info("Select SQL: " + SELECT_DASHBOARD);
		Object[] params = new Object[MAX_PERMS+2];
		params[0] = new String(dashBoardType);
		params[1] = new String(portalType);
		Iterator it = permissions.iterator();
		for(int i=2;i<MAX_PERMS+2;i++){
			if(it.hasNext())
				params[i] = new String(String.valueOf(it.next()));
			else params[i] = "";
		}
	return	selectDashBoardLinks.getAllGraphs(params);
}

class SelectDashBoard extends JdbcDaoSupport {
	   private String sql;

		public SelectDashBoard(String sql) {
	       this.sql = sql;
	   }

		public Map getAllGraphs(Object[] params) {
			 _LOGGER.info("getAllGraphs :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map graphsMap = new LinkedHashMap();
				          while (rs.next()) {
				    	      String header = rs.getString("HEADERTEXT");
				    	      String name = rs.getString("NAME");
				    	      String graphtype = rs.getString("DESC");
				    	      String tooltip = rs.getString("TOOLTIP");
				    	      String pageid = rs.getString("EXT_FUNC");
				    	      String type = rs.getString("TYPE");
				    	      graphsMap.put(pageid, new CGraph(header, name, graphtype, tooltip, pageid,type));
				          }
					      return graphsMap;
			        }});
		    }

}


public Map selectLinkOrders(int sectionKey) throws NCASException {
	 return selectLinkOrders.getLinkOrders(new Object[]{new Integer(sectionKey)});
}


class SelectLinkOrders extends JdbcDaoSupport {
	   private String sql;

		public SelectLinkOrders(String sql) {
	       this.sql = sql;
	   }

		public Map getLinkOrders(Object[] params) {
			 _LOGGER.info("getLinkOrders :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map linkOrders = new LinkedHashMap();
				          while (rs.next()) {
				    	      int linkKey = rs.getInt("LINK_KEY");
				    	      int linkOrder = rs.getInt("LINKORDER");
				    	      linkOrders.put(new Integer(linkKey),new Integer(linkOrder));
				          }
					      return linkOrders;
			        }});
		    }

}
public Map selectSectionOrders(int pageKey) throws NCASException {
	 return selectSectionOrders.getSectionOrders(new Object[]{new Integer(pageKey)});
}


class SelectSectionOrders extends JdbcDaoSupport {
	   private String sql;

		public SelectSectionOrders(String sql) {
	       this.sql = sql;
	   }

		public Map getSectionOrders(Object[] params) {
			 _LOGGER.info("getSectionOrders :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map sectionOrders = new LinkedHashMap();
				          while (rs.next()) {
				    	      int sectionKey = rs.getInt("SECTION_KEY");
				    	      int sectionOrder = rs.getInt("SECTIONORDER");
				    	      sectionOrders.put(new Integer(sectionKey),new Integer(sectionOrder));
				          }
					      return sectionOrders;
			        }});
		    }

}

public Map selectAllPortalPages() throws NCASException {
	 return selectAllPortalPages.getAllPortalPages(new Object[]{});
}


class SelectAllPortalPages extends JdbcDaoSupport {
	   private String sql;

		public SelectAllPortalPages(String sql) {
	       this.sql = sql;
	   }

		public Map getAllPortalPages(Object[] params) {
			 _LOGGER.info("getAllPortalPages :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map portPages = new LinkedHashMap();
				          while (rs.next()) {
				    	      String desc = rs.getString("DESC");
				    	      int pageKey = rs.getInt("PAGEKEY");
				    	      portPages.put(new Integer(pageKey),desc);
				          }
					      return portPages;
			        }});
		    }

}
public Map selectAllPortalSections() throws NCASException {
	 return selectAllPortalSections.getAllPortalSections(new Object[]{});
}


class SelectAllPortalSections extends JdbcDaoSupport {
	   private String sql;

		public SelectAllPortalSections(String sql) {
	       this.sql = sql;
	   }

		public Map getAllPortalSections(Object[] params) {
			 _LOGGER.info("getAllPortalSections :: " + params);
		        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  Map portSections = new LinkedHashMap();
				          while (rs.next()) {
				    	      String desc = rs.getString("DESC");
				    	      int sectionKey = rs.getInt("SECTIONKEY");
				    	      portSections.put(new Integer(sectionKey),desc);
				          }
					      return portSections;
			        }});
		    }

}


//insert in to PL_LINK table

public Map insertPortalLink(PortalLink portalLink) throws NCASException {

	boolean status = false;

    Map responseMap = new HashMap();
    String INSERT_PL_LINK = "INSERT INTO " + getSchemaName() + ".PL_LINK(LINK_KEY,NAME,DESC,TOOLTIP,EXT_FUNC,TYPE,INTL_NAME,INTL_TOOLTIP,USER_TYPE,ADMIN,TRACK_NAME,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_PL_LINK);

    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

    	if (insertLinkSqlUpdate == null) {
    	  insertLinkSqlUpdate = new SqlUpdate(getDataSource(),INSERT_PL_LINK);
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("TOOLTIP", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("EXT_FUNC", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("INTL_NAME", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("INTL_TOOLTIP", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("USER_TYPE", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("ADMIN", Types.CHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("TRACK_NAME", Types.VARCHAR));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
    	  insertLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
      }

      List currentKeyList = Arrays.asList(selectLinkNamesKeys().keySet().toArray());
	  int newKey = getGeneratedKey(currentKeyList);

	  _LOGGER.debug("The new generated key for the PL_LINK table is :"+newKey);


      Object[] parameterValues = new Object[] {new Integer(newKey),portalLink.getName(),portalLink.getDesc(),portalLink.getTooltip(),
      											portalLink.getExtFunc(), portalLink.getType(),portalLink.getIntlName(),
      											portalLink.getIntlTooltip(),portalLink.getUserType(),portalLink.getAdmin(),portalLink.getTrackName(),lastUpdated,
      											portalLink.getLastUpdatedBy()};
      int insCount = insertLinkSqlUpdate.update(parameterValues);

      if (insCount > 0) {
        _LOGGER.info( "Insert PL LINK  Response logged successfully \n Number of Records inserted - " + insCount);

		//int linkKeyInt = selectLinkKey(portalLink.getType()).intValue();
		portalLink.setLinkKey(newKey);

		List permLinkNames = portalLink.getPermLinkNames();
        if(permLinkNames!= null && permLinkNames.size()>0)
        {
			// This link requires the user to have one of the permissions in the list.
			status = false;
			insertPermLink(portalLink);
			status = true;
		}


		List portalList = portalLink.getPortalIndsForExcl();
        if(portalList!= null && portalList.size()>0)
        {
			// This link has to be excluded from the selected portals.
			status = false;
			insertExclLink(portalLink);
			status = true;
		}
		Map orLinkMap = portalLink.getOrLinkMap();
        if(orLinkMap!= null && orLinkMap.size()>0)
        {
			status = false;
			_LOGGER.info("The link has a cross reference insert in to PL_LINKPORTALOVR table");
			insertOverLink(portalLink);
			status = true;
		}
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertPortalLink in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("insertPortalLink in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertPortalLink" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

public Map updatePortalLink(PortalLink portalLink) throws NCASException {
	boolean status = false;
    Map responseMap = new HashMap();
    String UPDATE_PL_LINK = "UPDATE " + getSchemaName() +".PL_LINK SET NAME = ?,DESC = ?,TOOLTIP = ?,EXT_FUNC = ?,TYPE = ?,INTL_NAME = ?,INTL_TOOLTIP = ?,USER_TYPE = ?, ADMIN = ?, TRACK_NAME = ?, LAST_UPDATED = ?,LAST_UPDATED_BY =? WHERE LINK_KEY = ?";
    _LOGGER.info("Update SQL: " + UPDATE_PL_LINK);

    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

    	if (updateLinkSqlUpdate == null) {
    		updateLinkSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_PL_LINK);
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("TOOLTIP", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("EXT_FUNC", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("INTL_NAME", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("INTL_TOOLTIP", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("USER_TYPE", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("ADMIN", Types.CHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("TRACK_NAME", Types.VARCHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
			  updateLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));

      }

      Object[] parameterValues = new Object[] {portalLink.getName(),portalLink.getDesc(),portalLink.getTooltip(),
      											portalLink.getExtFunc(), portalLink.getType(),portalLink.getIntlName(),
      											portalLink.getIntlTooltip(),portalLink.getUserType(),portalLink.getAdmin(),portalLink.getTrackName(),
      											lastUpdated,portalLink.getLastUpdatedBy(), new Integer(portalLink.getLinkKey())};
      int insCount = updateLinkSqlUpdate.update(parameterValues);

	      if (insCount > 0) {
	        _LOGGER.info( "Update Portal Links  Response logged successfully \n Number of Records inserted - " + insCount);
	        status = true;
	      }
			List portalList = portalLink.getPortalIndsForExcl();
			if(portalList!= null && portalList.size()>0)
			{
				status = false;
				_LOGGER.info("First, delete all the exclusions for this link.");
				deleteExclLink(portalLink.getLinkKey());
				_LOGGER.info("Now insert all the latest exclusions for this link.");
				insertExclLink(portalLink);
				status = true;
			}
			else if(portalList!= null && portalList.size() == 0)
			{
				//This link has no exclusions.
			status = false;
			deleteExclLink(portalLink.getLinkKey());
			status = true;
			}
			List permList = portalLink.getPermLinkNames();
			if(permList!= null && permList.size()>0)
			{
				status = false;
				_LOGGER.info("First, delete all the permissions for this link.");
				deletePermLink(portalLink.getLinkKey());
				_LOGGER.info("Now insert all the latest permissions for this link.");
				insertPermLink(portalLink);
				status = true;
			}else if(permList!= null && permList.size() == 0)
			{
				//This link has no permission constraints
				status = false;
				_LOGGER.info("First, delete all the permission constraints for this link.");
				deletePermLink(portalLink.getLinkKey());
				status = true;
			}

			Map orLinkMap = portalLink.getOrLinkMap();
			if(orLinkMap!= null && orLinkMap.size()>0)
			{
				status = false;
				_LOGGER.info("Update the latest override link info for this link.");
				deleteOverLink(portalLink.getLinkKey());
				insertOverLink(portalLink);
				status = true;
			}else if(orLinkMap!= null && orLinkMap.size() == 0)
			{
				//This link has no overrides in any portals.
				status = false;
				_LOGGER.info("Delete all the override for this link.");
				deleteOverLink(portalLink.getLinkKey());
				status = true;
			}
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("updatePortalLink in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("updatePortalLink in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting updatePortalLink" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
}
public Map deletePortalLink(int linkKey) throws NCASException {
	 boolean status = false;
	 Map responseMap = new HashMap();
	 String DELETE_EXT_LINK = "DELETE FROM " + getSchemaName() +".PL_LINK WHERE LINK_KEY = ?";

	 _LOGGER.info("Delete SQL: " + DELETE_EXT_LINK);
	 _LOGGER.info("The link key that is getting deleted:"+linkKey);
	    try {
			_LOGGER.info("Delete the foreign key references first");

			Map firstMap = deletePermLink(linkKey);
			Map secondMap   = deleteExclLink(linkKey);
			Map thirdMap = deleteOverLink(linkKey);
			Map fourthMap = deleteLinkFromSectionLink(linkKey);
			boolean firstBool = ((Boolean)firstMap.get("status")).booleanValue();
			boolean secondBool = ((Boolean)secondMap.get("status")).booleanValue();
			boolean thirdBool = ((Boolean)thirdMap.get("status")).booleanValue();
			boolean fourthBool = ((Boolean)fourthMap.get("status")).booleanValue();

			if(firstBool && secondBool && thirdBool && fourthBool)
			{
				_LOGGER.debug("The references of the LINK have been deleted successfully");
			  if (deleteLinkSqlUpdate == null) {
				  deleteLinkSqlUpdate = new SqlUpdate(getDataSource(),DELETE_EXT_LINK);
				  deleteLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
				  deleteLinkSqlUpdate.compile();
			  }
			  Object[] parameterValues = new Object[] {new Integer(linkKey)};
			  int deleteCount = deleteLinkSqlUpdate.update(parameterValues);
			  if (deleteCount > 0) {
				_LOGGER.info("Delete PORTAL LINKS logged successfully \n Number of Records deleted - " + deleteCount);
				status = true;
			  }
	  		}else{
				_LOGGER.debug("The references of the LINK couldn't be deleted. Throwing exception to trigger a rollback");
				throw new Exception("References couldn't be deleted");
			}
	    }
	    catch (Exception vamEx) {
	      vamEx.printStackTrace();
	      _LOGGER.debug("deletePortalLink in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("deletePortalLink in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

	    }
	    _LOGGER.info("Exiting deletePortalLink");
	    responseMap.put("status", new Boolean(status));
	    return responseMap;
}







//insert in to PL_LINKPERMINCL table

public Map insertPermLink(PortalLink portalLink) throws NCASException {

	boolean status = false;

    Map responseMap = new HashMap();
    String INSERT_PERM_LINK = "INSERT INTO " + getSchemaName() + ".PL_LINKPERMINCL(PERMLINK_KEY,NAME,LINK_KEY,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_PERM_LINK);

    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

    	if (insertPermLinkSqlUpdate == null) {
    	  insertPermLinkSqlUpdate = new BatchSqlUpdate(getDataSource(),INSERT_PERM_LINK);
    	  insertPermLinkSqlUpdate.declareParameter(new SqlParameter("PERMLINK_KEY", Types.INTEGER));
    	  insertPermLinkSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
    	  insertPermLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
    	  insertPermLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
    	  insertPermLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
      }
	  int linkKey = portalLink.getLinkKey();
	  String lastUpdatedBy = portalLink.getLastUpdatedBy();
      List permList = portalLink.getPermLinkNames();
	  int insCount = 0;
	  int genPermKey = 0;
	  _LOGGER.debug("The permlist size is:"+permList.size());
			    for(int i =0;i<permList.size();i++) {
					if(i==0)
					{
						genPermKey = getGeneratedKey(selectAllLinkPermissions());
					}else{
						genPermKey++;
					}
				  _LOGGER.debug("The new generated key for the PL_LINKPERMINCL table is :"+genPermKey);
			      _LOGGER.debug("The permission name that is getting entered for the linkKey:"+linkKey+" is:"+(String)permList.get(i));

		    	insCount += insertPermLinkSqlUpdate.update(new Object[]{new Integer(genPermKey),(String)permList.get(i),new Integer(linkKey),lastUpdated,lastUpdatedBy});
			    }
				if(insertPermLinkSqlUpdate!=null)
				insertPermLinkSqlUpdate.flush();
      if (insCount > 0) {
        _LOGGER.info( "Insert Link Permissions Response logged successfully \n Number of Records inserted - " + insCount);
        status = true;
      }

    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertPermLink in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("insertPermLink in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertPermLink" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

public Map deletePermLink(int linkKey) throws NCASException {
	 boolean status = false;
	 Map responseMap = new HashMap();
	 String DELETE_PERM_LINK = "DELETE FROM " + getSchemaName() +".PL_LINKPERMINCL WHERE LINK_KEY = ?";

	 _LOGGER.info("Delete SQL: " + DELETE_PERM_LINK);
	    try {
	      if (deletePermLinkSqlUpdate == null) {
	    	  deletePermLinkSqlUpdate = new SqlUpdate(getDataSource(),DELETE_PERM_LINK);
	    	  deletePermLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
	    	  deletePermLinkSqlUpdate.compile();
	      }
	      Object[] parameterValues = new Object[] {new Integer(linkKey)};
	      int deleteCount = deletePermLinkSqlUpdate.update(parameterValues);
	        _LOGGER.info("Delete PERM LINKS logged successfully \n Number of Records deleted - " + deleteCount);

	      status = true;
	    }
	    catch (Exception vamEx) {
	      vamEx.printStackTrace();
	      _LOGGER.debug("deletePermLink in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("deletePermLink in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

	    }
	    _LOGGER.info("Exiting deletePermLink");
	    responseMap.put("status", new Boolean(status));
	    return responseMap;
}

//insert in to PL_LINKPORTALEXL table

public Map insertExclLink(PortalLink portalLink) throws NCASException {

	boolean status = false;

    Map responseMap = new HashMap();
    String INSERT_EXCL_LINK = "INSERT INTO " + getSchemaName() + ".PL_LINKPORTALEXL(PORTALEX_KEY,LINK_KEY,PORTAL, LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_EXCL_LINK);

    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

    	if (insertExclLinkSqlUpdate == null) {
    	  insertExclLinkSqlUpdate = new BatchSqlUpdate(getDataSource(),INSERT_EXCL_LINK);
    	  insertExclLinkSqlUpdate.declareParameter(new SqlParameter("PORTALEX_KEY", Types.INTEGER));
    	  insertExclLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
    	  insertExclLinkSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
    	  insertExclLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
    	  insertExclLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
      }

	  int linkKey = portalLink.getLinkKey();
	  String lastUpdatedBy = portalLink.getLastUpdatedBy();
      List portalList = portalLink.getPortalIndsForExcl();

      _LOGGER.debug("The size of the Exclusion list is :"+portalList.size());
	  int insCount = 0;
	  int exclKey = 0;
			    for(int i =0;i<portalList.size();i++) {
					if(exclKey==0)
					{
			      		exclKey = getGeneratedKey(selectAllLinkExclusions());
					}else{
						exclKey++;
					}
				 _LOGGER.debug("The new generated key for the PL_LINKPORTALEXL table is :"+exclKey);
			      _LOGGER.debug("The portal name that is getting excluded for the linkKey:"+linkKey+" is:"+(String)portalList.get(i));
		    	insCount += insertExclLinkSqlUpdate.update(new Object[]{new Integer(exclKey),new Integer(linkKey),(String)portalList.get(i),lastUpdated,lastUpdatedBy});
			    }

			    if(insertExclLinkSqlUpdate!=null)
			     insertExclLinkSqlUpdate.flush();

      if (insCount > 0) {
        _LOGGER.info( "Insert EXCL LINK  Response logged successfully \n Number of Records inserted - " + insCount);
        status = true;
      }

    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertExclLink in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("insertExclLink in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertExclLink" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }


public Map deleteExclLink(int linkKey) throws NCASException {
	 boolean status = false;
	 Map responseMap = new HashMap();
	 String DELETE_EXCL_LINK = "DELETE FROM " + getSchemaName() +".PL_LINKPORTALEXL WHERE LINK_KEY = ?";

	 _LOGGER.info("Delete SQL: " + DELETE_EXCL_LINK);
	    try {
	      if (deleteExclLinkSqlUpdate == null) {
	    	  deleteExclLinkSqlUpdate = new SqlUpdate(getDataSource(),DELETE_EXCL_LINK);
	    	  deleteExclLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
	    	  //deleteExclLinkSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
	    	  deleteExclLinkSqlUpdate.compile();
	      }
	      Object[] parameterValues = new Object[] {new Integer(linkKey)};
	      int deleteCount = deleteExclLinkSqlUpdate.update(parameterValues);
	        _LOGGER.info("Delete EXCL LINKS logged successfully \n Number of Records deleted - " + deleteCount);

	      status = true;
	    }
	    catch (Exception vamEx) {
	      vamEx.printStackTrace();
	      _LOGGER.debug("deleteExclLink in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("deleteExclLink in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

	    }
	    _LOGGER.info("Exiting deleteExclLink");
	    responseMap.put("status", new Boolean(status));
	    return responseMap;
}

public Map insertOverLink(PortalLink portalLink) throws NCASException {

	boolean status = false;

    Map responseMap = new HashMap();
    String INSERT_OR_LINK = "INSERT INTO " + getSchemaName() + ".PL_LINKPORTALOVR(PORTALOV_KEY,LINK_KEY,PORTAL, OR_LINK_KEY, LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";
    _LOGGER.info("Insert SQL: " + INSERT_OR_LINK);

    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

    	if (insertOrLinkSqlUpdate == null) {
    	  insertOrLinkSqlUpdate = new BatchSqlUpdate(getDataSource(),INSERT_OR_LINK);
    	  insertOrLinkSqlUpdate.declareParameter(new SqlParameter("PORTALOV_KEY", Types.INTEGER));
    	  insertOrLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
    	  insertOrLinkSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
    	  insertOrLinkSqlUpdate.declareParameter(new SqlParameter("OR_LINK_KEY", Types.INTEGER));
    	  insertOrLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
    	  insertOrLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
      }



	  int linkKey = portalLink.getLinkKey();
	  String lastUpdatedBy = portalLink.getLastUpdatedBy();
      Map orLinkMap = portalLink.getOrLinkMap();
	  int insCount = 0;
	  int newKey = 0;

      _LOGGER.debug("The size of the Override map is :"+orLinkMap.size());
	  Iterator it = orLinkMap.entrySet().iterator();

		while (it.hasNext()) {
			if(insCount==0)
			{
				newKey = getGeneratedKey(selectAllOverrideLinks());
			}else{
				newKey++;
			}
		Map.Entry pairs = (Map.Entry)it.next();
      _LOGGER.debug("The new generated key for the PL_LINKPORTALOVR table is:"+newKey);
	  _LOGGER.debug("The overriden linkKey for the linkKey:"+linkKey+" is:"+((Integer)pairs.getValue()).intValue()+":and the portal is:"+(String)pairs.getKey());

		insCount += insertOrLinkSqlUpdate.update(new Object[]{new Integer(newKey),new Integer(linkKey), (String)pairs.getKey(),(Integer)pairs.getValue(),lastUpdated,lastUpdatedBy});

		}
		if(insertOrLinkSqlUpdate!=null)
		insertOrLinkSqlUpdate.flush();


      if (insCount > 0) {
        _LOGGER.info( "Insert OVERRIDE LINK  Response logged successfully \n Number of Records inserted - " + insCount);
        status = true;
      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("insertOverLink in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("insertOverLink in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting insertOverLink" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
  }

public Map updateOverLink(PortalLink portalLink) throws NCASException {
	boolean status = false;
    Map responseMap = new HashMap();
    String UPDATE_OR_LINK = "UPDATE " + getSchemaName() +".PL_LINKPORTALOVR SET OR_LINK_KEY =?, LAST_UPDATED = ?, LAST_UPDATED_BY = ? WHERE LINK_KEY = ? AND PORTAL = ? ";
    _LOGGER.info("Update SQL: " + UPDATE_OR_LINK);
	Map orLinkMap = portalLink.getOrLinkMap();
	int linkKey = portalLink.getLinkKey();
	int upCount = 0;
	String lastUpdatedBy = portalLink.getLastUpdatedBy();
    try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

    	if (updateOrLinkSqlUpdate == null) {
    		updateOrLinkSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_OR_LINK);
			  updateOrLinkSqlUpdate.declareParameter(new SqlParameter("OR_LINK_KEY", Types.INTEGER));
			  updateOrLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
			  updateOrLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
			  updateOrLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
			  updateOrLinkSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));

      }

		Iterator it = orLinkMap.entrySet().iterator();

		while (it.hasNext()) {
		Map.Entry pairs = (Map.Entry)it.next();
		 upCount += updateOrLinkSqlUpdate.update(new Object[]{(Integer)pairs.getValue(), lastUpdated,lastUpdatedBy,new Integer(linkKey),(String)pairs.getKey()});
		}
				if(updateOrLinkSqlUpdate != null)
			    updateOrLinkSqlUpdate.flush();

	      if (upCount > 0) {
	        _LOGGER.info( "Update Override Links  Response logged successfully \n Number of Records inserted - " + upCount);
	        status = true;
	      }
    }
    catch (Exception vamEx) {
      vamEx.printStackTrace();
      _LOGGER.debug("updateOverLink in VAM Failed \n" +vamEx.getMessage());
      _LOGGER.error("updateOverLink in VAM Failed \n" +vamEx.getMessage());
      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
    }
    _LOGGER.info("Exiting updateOverLink" + responseMap.toString());
    responseMap.put("status", new Boolean(status));
    return responseMap;
}
public Map deleteOverLink(int linkKey) throws NCASException {
	 boolean status = false;
	 Map responseMap = new HashMap();
	 String DELETE_OVER_LINK = "DELETE FROM " + getSchemaName() +".PL_LINKPORTALOVR WHERE LINK_KEY = ?";

	 _LOGGER.info("Delete SQL: " + DELETE_OVER_LINK);
	    try {
	      if (deleteOrLinkSqlUpdate == null) {
	    	  deleteOrLinkSqlUpdate = new SqlUpdate(getDataSource(),DELETE_OVER_LINK);
	    	  deleteOrLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
	    	  deleteOrLinkSqlUpdate.compile();
	      }
	      Object[] parameterValues = new Object[] {new Integer(linkKey)};
	      int deleteCount = deleteOrLinkSqlUpdate.update(parameterValues);
	        _LOGGER.info("Delete OVER LINKS logged successfully \n Number of Records deleted - " + deleteCount);
   	        status = true;
	    }
	    catch (Exception vamEx) {
	      vamEx.printStackTrace();
	      _LOGGER.debug("deleteOverLink in VAM Failed \n" +vamEx.getMessage());
	      _LOGGER.error("deleteOverLink in VAM Failed \n" +vamEx.getMessage());
	      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

	    }
	    _LOGGER.info("Exiting deleteOverLink");
	    responseMap.put("status", new Boolean(status));
	    return responseMap;
}

public Map getPortalLinkDropdowns() throws NCASException {
	Map responseMap = new HashMap();
	try{
		List portalNames = DAOFactory.getInstance().getPortalLinkForECP().selectAllPortalNames();
		Map result = selectLinkNamesDescKeys();
		Map currentLinksKeys = (HashMap)result.get("linkKeyName");
				List overKeyNames = new ArrayList();
				Iterator it = currentLinksKeys.entrySet().iterator();
				String finalVal = "";
				while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry)it.next();

				int linkKey = ((Integer)pairs.getKey()).intValue();
				String linkName = (String)pairs.getValue();
				 finalVal = Integer.toString(linkKey);
				if(linkName!=null && linkName.trim().length()>0)
				{
					finalVal = linkKey+"--"+linkName;
				}
				_LOGGER.debug("The final Value is ->"+finalVal);
				overKeyNames.add(finalVal);
			}

				Map linkDescMap = (HashMap) result.get("linkKeyDesc");
				List linkDescList = new ArrayList();
				Iterator itd = linkDescMap.entrySet().iterator();
				String finalValDesc = "";
				while (itd.hasNext()) {
				Map.Entry pairs = (Map.Entry)itd.next();

				int linkKey = ((Integer)pairs.getKey()).intValue();
				String descName = (String)pairs.getValue();
				finalValDesc = Integer.toString(linkKey);
				if(descName!=null && descName.trim().length()>0)
				{
					finalValDesc = linkKey+"--"+descName;
				}
				_LOGGER.debug("The final Value is ->"+finalValDesc);
				linkDescList.add(finalValDesc);
			}

			responseMap.put("portalNames",portalNames);
			responseMap.put("currentLinks",overKeyNames);
			responseMap.put("linkDesc",linkDescList);



			_LOGGER.info("Exiting getPortalLinkDropdowns");
		} catch(Exception vamEx) {
			_LOGGER.debug("getPortalLinkDropdowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getPortalLinkDropdowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("responseMap"+ responseMap);
		return responseMap;
	}

public Map getSectionLinkDropdowns() throws NCASException {
	Map responseMap = new HashMap();
	try{
			Map sectionKeyDesc = selectAllPortalSections();
			List allSections = new ArrayList();
			String finalVal1 = "";

				Iterator it1 = sectionKeyDesc.entrySet().iterator();
				while (it1.hasNext()) {
				Map.Entry pairs1 = (Map.Entry)it1.next();

				int sectionKey = ((Integer)pairs1.getKey()).intValue();
				String secDesc = (String)pairs1.getValue();
				 finalVal1 = Integer.toString(sectionKey);
				if(secDesc!=null && secDesc.trim().length()>0)
				{
					finalVal1 = sectionKey+"--"+secDesc;
				}
				allSections.add(finalVal1);
			}

		Map currentLinksKeys = selectLinkNamesKeys();

				List overKeyNames = new ArrayList();
				Iterator it2 = currentLinksKeys.entrySet().iterator();
				String finalVal2 = "";
				while (it2.hasNext()) {
				Map.Entry pairs2 = (Map.Entry)it2.next();

				int linkKey = ((Integer)pairs2.getKey()).intValue();
				String linkName = (String)pairs2.getValue();
				 finalVal2 = Integer.toString(linkKey);
				if(linkName!=null && linkName.trim().length()>0)
				{
					finalVal2 = linkKey+"--"+linkName;
				}
				overKeyNames.add(finalVal2);
			}

			responseMap.put("allSections",allSections);
			responseMap.put("allLinks",overKeyNames);
			responseMap.put("allLinkGroupKeys", selectLinkGroups());
			responseMap.put("allOrders", selectAllLinkOrders());



			_LOGGER.info("Exiting getSectionLinkDropdowns");
		} catch(Exception vamEx) {
			_LOGGER.debug("getSectionLinkDropdowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getSectionLinkDropdowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("responseMap"+ responseMap);
		return responseMap;
	}

public Map getPageSectionDropdowns() throws NCASException {
	Map responseMap = new HashMap();
	try{
			Map pageKeyDesc = selectAllPortalPages();
			List allPages = new ArrayList();
			String finalVal1 = "";

				Iterator it1 = pageKeyDesc.entrySet().iterator();
				while (it1.hasNext()) {
				Map.Entry pairs1 = (Map.Entry)it1.next();

				int pageKey = ((Integer)pairs1.getKey()).intValue();
				String pageDesc = (String)pairs1.getValue();
				 finalVal1 = Integer.toString(pageKey);
				if(pageDesc!=null && pageDesc.trim().length()>0)
				{
					finalVal1 = pageKey+"--"+pageDesc;
				}
				allPages.add(finalVal1);
			}

				Map currentSectionsKeys = selectAllPortalSections();

				List sectionNames = new ArrayList();
				Iterator it2 = currentSectionsKeys.entrySet().iterator();
				String finalVal2 = "";
				while (it2.hasNext()) {
				Map.Entry pairs2 = (Map.Entry)it2.next();

				int sectionKey = ((Integer)pairs2.getKey()).intValue();
				String sectionDesc = (String)pairs2.getValue();
				 finalVal2 = Integer.toString(sectionKey);
				if(sectionDesc!=null && sectionDesc.trim().length()>0)
				{
					finalVal2 = sectionKey+"--"+sectionDesc;
				}
				sectionNames.add(finalVal2);
			}

			responseMap.put("allPages",allPages);
			responseMap.put("allSections",sectionNames);
			responseMap.put("allOrders", selectAllSectionOrders());



			_LOGGER.info("Exiting getPageSectionDropdowns");
		} catch(Exception vamEx) {
			_LOGGER.debug("getPageSectionDropdowns in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("getPageSectionDropdowns in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("responseMap"+ responseMap);
		return responseMap;
	}

public Map insertSectionLink(SectionLink  sectionLink) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int sectionKey = sectionLink.getSectionKey();
		Map linkOrder = sectionLink.getLinkOrders();
		Map linkGroups = sectionLink.getLinkGroups();
		String lastUpdatedBy = sectionLink.getLastUpdatedBy();
		Map curLinks = selectLinksForSection(sectionKey);

		String INSERT_SECTION_LINK = "INSERT INTO " + getSchemaName() + ".PL_SECTION_LINK(SECTIONLINKKEY,SECTIONKEY,LINK_KEY,LINKORDER,LINKGROUPKEY, LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_SECTION_LINK);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(insertSectionLinkSqlUpdate == null){


				insertSectionLinkSqlUpdate = new SqlUpdate(getDataSource(),INSERT_SECTION_LINK);
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("SECTIONLINKKEY", Types.INTEGER));
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINKORDER", Types.INTEGER));
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINKGROUPKEY", Types.INTEGER));
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertSectionLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertSectionLinkSqlUpdate.compile();
			}



				Iterator it = linkOrder.entrySet().iterator();

				while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry)it.next();

				int linkOrderParam = ((Integer)pairs.getValue()).intValue();
				Integer linkParamInt = (Integer)pairs.getKey();
				int linkParam = linkParamInt.intValue();

				if(curLinks.containsKey(linkParamInt))
				{
					//The link already exists. The user has to use update.
						 Exception ex = new Exception("This link already exists in this section.");
						_LOGGER.error("insertSectionLink in VAM Failed \n"+ex.getMessage());
						throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,ex);
				}

				_LOGGER.info("Adjust Link Orders getting called");

				int latestLinkOrderParam = adjustLinkOrders(sectionLink,linkParam, linkOrderParam );

				if(latestLinkOrderParam==0)
				{
					latestLinkOrderParam = linkOrderParam;
				}

			  	int newKey = getGeneratedKey(selectAllSectionLinkKeys());

			  	_LOGGER.debug("The new generated key for the PL_SECTIONLINK table is :"+newKey);
				insertSectionLinkSqlUpdate.update(new Object[]{new Integer(newKey),new Integer(sectionKey),new Integer(linkParam), new Integer(latestLinkOrderParam), (Integer)linkGroups.get(new Integer(linkParam)),lastUpdated,lastUpdatedBy});
				}



				status = true;



		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertSectionLink in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertSectionLink in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertSectionLink");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateSectionLink(SectionLink  sectionLink) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int sectionKey = sectionLink.getSectionKey();
		Map dbLinkOrders = selectLinkOrders(sectionKey);

		String UPDATE_SECTION_LINK_SQL = "UPDATE " + getSchemaName() + ".PL_SECTION_LINK SET LINKORDER = ?, LINKGROUPKEY = ?, LAST_UPDATED = ?, LAST_UPDATED_BY=? WHERE SECTIONKEY=? AND LINK_KEY=?";

		_LOGGER.info("Update SQL: " + UPDATE_SECTION_LINK_SQL);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(updateSectionLinkSqlUpdate == null){


				updateSectionLinkSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_SECTION_LINK_SQL);
				updateSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINKORDER", Types.INTEGER));
				updateSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINKGROUPKEY", Types.INTEGER));
				updateSectionLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updateSectionLinkSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updateSectionLinkSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				updateSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));

				updateSectionLinkSqlUpdate.compile();
			}
				Map linkOrders = sectionLink.getLinkOrders();
				Map linkGroups = sectionLink.getLinkGroups();

			    Iterator it = linkOrders.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
				boolean linkOrderTaken = dbLinkOrders.containsValue((Integer)(pairs.getValue()));
				if(!linkOrderTaken)
				{
		    		updateSectionLinkSqlUpdate.update(new Object[]{(Integer)pairs.getValue(), (Integer)linkGroups.get(pairs.getKey()), lastUpdated, sectionLink.getLastUpdatedBy(), new Integer(sectionKey),(Integer)pairs.getKey()});
				}
		    	else
		    	{
					adjustLinkOrders(sectionLink,((Integer)pairs.getKey()).intValue(),((Integer)pairs.getValue()).intValue());
				}
			   }
			   if(updateSectionLinkSqlUpdate != null)
			   updateSectionLinkSqlUpdate.flush();

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateSectionLink in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateSectionLink in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateSectionLink");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public int adjustLinkOrders(SectionLink sectionLink, int linkKey, int selectedLinkOrder) throws NCASException{
		int sectionKey = sectionLink.getSectionKey();
		Map linkOrders = selectLinkOrders(sectionLink.getSectionKey());
		boolean linkOrderTaken = linkOrders.containsValue(new Integer(selectedLinkOrder));
		boolean linkExists = linkOrders.containsKey(new Integer(linkKey));
		int maxLinkOrderPlusOne = 0;
		int maxValueCalculated = 0;
		Map linkLinkGroups = sectionLink.getLinkGroups();
		int lnkGrp = ((Integer)linkLinkGroups.get(new Integer(linkKey))).intValue();

		if(selectedLinkOrder==-1)
		{
			if(linkOrders.values()!=null && linkOrders.values().size()>0)
			{
				maxValueCalculated = ((Integer)Collections.max(linkOrders.values())).intValue();
			}
			maxLinkOrderPlusOne = maxValueCalculated+1;
			_LOGGER.info("Max Integer Plus one is: " + maxLinkOrderPlusOne);
			return maxLinkOrderPlusOne;
		}

		if(!linkOrderTaken)
		{
			//The link order is not taken. So the link that is being introduced is going to be the last link if there
			//are already links existing or it will be the first, if none exists.
			return selectedLinkOrder;
		}
		else{
			//The link order is taken. All the current links that are equal or greater to the user choice of the
			//link order should be increased by one if this link is moving down.All the current links which have their
			//current link order inbetween or equal to the chosen link order, should be increased by one and the others
			//remain the same.
		    Iterator it = linkOrders.entrySet().iterator();

		    Map latestLinkOrders = new HashMap();
			if(linkExists)
			{
				 int updatingLinkOrder = ((Integer)linkOrders.get(new Integer(linkKey))).intValue();
				 _LOGGER.info("The updatingLinkOrder is:"+updatingLinkOrder);
				_LOGGER.info("The link already exists. So this must be an update and not an insert");
					while (it.hasNext())
					{

						Map.Entry pairs = (Map.Entry)it.next();

						int curLinkKey = ((Integer)(pairs.getKey())).intValue();
						int curLinkOrder = ((Integer)pairs.getValue()).intValue();
						_LOGGER.info("Current link ->"+curLinkKey+"Current link order-> "+curLinkOrder);
						if(linkKey==curLinkKey)
						{
							_LOGGER.info("This is the link that is being modified->"+curLinkKey+" The new link order is " +selectedLinkOrder);
							latestLinkOrders.put(new Integer(curLinkKey), new Integer(selectedLinkOrder));
						}
						else if(updatingLinkOrder>selectedLinkOrder)
						{
							//This means the link is moving up in the order.
							//All the links which have the linkorder equal or greater than selected linkorder
							//and less than the old linkorder are to be increased by 1.

								if(curLinkOrder == selectedLinkOrder || curLinkOrder>selectedLinkOrder && curLinkOrder<updatingLinkOrder)
								{
									int latestLinkOrder = curLinkOrder+1;
									_LOGGER.info("The Latest link order for the link "+ curLinkKey+" is "+latestLinkOrder);
									latestLinkOrders.put(new Integer(curLinkKey), new Integer(latestLinkOrder));
								}
								else{
									_LOGGER.info("The LATEST link order for the link "+ curLinkKey+" is "+curLinkOrder);
									latestLinkOrders.put(new Integer(curLinkKey), new Integer(curLinkOrder));
								}
						}
						else if(updatingLinkOrder<selectedLinkOrder)
						{
							//This means the link is moving down in the order.
							//All the links which have the linkorder equal or greater than selected linkorder
							//and less than the old linkorder are to be increased by 1.

								if(curLinkOrder == selectedLinkOrder || curLinkOrder<selectedLinkOrder && curLinkOrder>updatingLinkOrder)
								{
									int latestLinkOrder = curLinkOrder-1;
									_LOGGER.info("The Latest link order for the link "+ curLinkKey+" is "+latestLinkOrder);
									latestLinkOrders.put(new Integer(curLinkKey), new Integer(latestLinkOrder));
								}
								else{
									_LOGGER.info("The LATEST link order for the link "+ curLinkKey+" is "+curLinkOrder);
									latestLinkOrders.put(new Integer(curLinkKey), new Integer(curLinkOrder));
								}
						}
						else{
									_LOGGER.info("The LATEST link order for the link "+ curLinkKey+" is "+curLinkOrder);
									latestLinkOrders.put(new Integer(curLinkKey), new Integer(curLinkOrder));
						}
				    }
				    updateLinkOrder(latestLinkOrders, sectionKey, lnkGrp,linkKey,sectionLink.getLastUpdatedBy());

			}
			else
			{
				_LOGGER.info("The link doesn't exist. So this must be an insert and not an update");
					while (it.hasNext())
					{
						Map.Entry pairs = (Map.Entry)it.next();
						if(((Integer)pairs.getValue()).intValue()>=selectedLinkOrder)
						{

							int latestLinkOrder = ((Integer)(pairs.getValue())).intValue()+1;
							int curLinkKey = ((Integer)(pairs.getKey())).intValue();

							_LOGGER.info("The latest link order for the link "+ curLinkKey+" is "+latestLinkOrder);

							latestLinkOrders.put(new Integer(curLinkKey), new Integer(latestLinkOrder));

						}else
						{
							latestLinkOrders.put((Integer)pairs.getKey(), (Integer)pairs.getValue());
						}
				    }
				  updateLinkOrder(latestLinkOrders, sectionKey, lnkGrp,linkKey,sectionLink.getLastUpdatedBy());
	  	  	}

		}
		  return maxLinkOrderPlusOne;
	}


public boolean updateLinkOrder(Map linkOrder, int sectionKey, int lnkGrp, int linkKey, String lastUpdatedBy) throws NCASException{
		boolean status = false;

		String UPDATE_LINK_ORDER_SQL = "INSERT INTO " + getSchemaName() + ".PL_SECTION_LINK(SECTIONLINKKEY,SECTIONKEY,LINKORDER,LINK_KEY,LINKGROUPKEY, LAST_UPDATED,LAST_UPDATED_BY ) VALUES(?,?,?,?,?,?,?)";

		_LOGGER.info(" SQL: " + UPDATE_LINK_ORDER_SQL);


		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			Map linkGrpMap = selectLinksAndLinkGroupKeys(sectionKey);
			if(deleteAllLinksFromSection(sectionKey))
			{

				if(updateLinkOrderSqlUpdate == null)
				{

					updateLinkOrderSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_LINK_ORDER_SQL);
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("SECTIONLINKKEY", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LINKORDER", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LINKGROUPKEY", Types.INTEGER));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
					updateLinkOrderSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
					updateLinkOrderSqlUpdate.compile();
				}


			    Iterator it = linkOrder.entrySet().iterator();
			    int testIncrement = 0;
				int newKey = 0;

				linkGrpMap.remove(new Integer(linkKey));
				linkGrpMap.put(new Integer(linkKey),new Integer(lnkGrp));



			    while (it.hasNext()) {
				if(testIncrement ==0)
				{
					newKey = getGeneratedKey(selectAllSectionLinkKeys());
				}
				else{

					newKey++;
				}
				Map.Entry pairs = (Map.Entry)it.next();

		    	testIncrement+= updateLinkOrderSqlUpdate.update(new Object[]{new Integer(newKey),new Integer(sectionKey), (Integer)pairs.getValue(),
		    									(Integer)pairs.getKey(),(Integer)linkGrpMap.get((Integer)pairs.getKey()),
		    									lastUpdated, lastUpdatedBy});
			    }

			    if(updateLinkOrderSqlUpdate!=null)
			    updateLinkOrderSqlUpdate.flush();

				status = true;
			}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateLinkOrder in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateLinkOrder in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateLinkOrder");
		return status;
	}


public boolean deleteAllLinksFromSection(int sectionKey) throws NCASException {
		boolean status = false;
		String DELETE_ALL_LINKS = "DELETE FROM " + getSchemaName() + ".PL_SECTION_LINK WHERE SECTIONKEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_ALL_LINKS);

		try {
			if(deleteAllLinksFromSectionSqlUpdate == null) {
				deleteAllLinksFromSectionSqlUpdate = new SqlUpdate(getDataSource(),DELETE_ALL_LINKS);
				deleteAllLinksFromSectionSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				deleteAllLinksFromSectionSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(sectionKey)};

			int deleteCount = deleteAllLinksFromSectionSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete Links from Section logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAllLinksFromSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteAllLinksFromSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteAllLinksFromSection");
		return status;
	}


	public Map deleteSectionLink(int sectionKey, int linkKey, String allOrSingle) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_LINKS_FROM_SECTION = "DELETE FROM " + getSchemaName() + ".PL_SECTION_LINK WHERE SECTIONKEY = ? AND LINK_KEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_LINKS_FROM_SECTION);

		try {
			if(allOrSingle.equalsIgnoreCase("ALL"))
			{
				boolean otherstatus = deleteAllLinksFromSection(sectionKey);
				responseMap.put("status",new Boolean(status));
				return responseMap;
			}
			else{

			if(deleteSectionLinkSqlUpdate == null) {
				deleteSectionLinkSqlUpdate = new SqlUpdate(getDataSource(),DELETE_LINKS_FROM_SECTION);
				deleteSectionLinkSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				deleteSectionLinkSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
				deleteSectionLinkSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(sectionKey), new Integer(linkKey)};

			int deleteCount = deleteSectionLinkSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete Link from section logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;
	  		}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteSectionLink in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteSectionLink in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteSectionLink");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public Map deleteLinkFromSectionLink(int linkKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_LINK_REF_FROM_SECTIONLINK = "DELETE FROM " + getSchemaName() + ".PL_SECTION_LINK WHERE LINK_KEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_LINK_REF_FROM_SECTIONLINK);

		try {
			if(deleteLinkReferenceSqlUpdate == null) {
				deleteLinkReferenceSqlUpdate = new SqlUpdate(getDataSource(),DELETE_LINK_REF_FROM_SECTIONLINK);
				deleteLinkReferenceSqlUpdate.declareParameter(new SqlParameter("LINK_KEY", Types.INTEGER));
				deleteLinkReferenceSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(linkKey)};

			int deleteCount = deleteLinkReferenceSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete LINK from sectionlink logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLinkFromSectionLink in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLinkFromSectionLink in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteLinkFromSectionLink");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map deleteSectionFromSectionLink(int sectionKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_SECTION_REF_FROM_SECTIONLINK = "DELETE FROM " + getSchemaName() + ".PL_SECTION_LINK WHERE SECTIONKEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_SECTION_REF_FROM_SECTIONLINK);

		try {
			if(deleteSectionReferenceSqlUpdate == null) {
				deleteSectionReferenceSqlUpdate = new SqlUpdate(getDataSource(),DELETE_SECTION_REF_FROM_SECTIONLINK);
				deleteSectionReferenceSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				deleteSectionReferenceSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(sectionKey)};

			int deleteCount = deleteSectionReferenceSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete SECTION from sectionlink logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteSectionFromSectionLink in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteSectionFromSectionLink in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteSectionFromSectionLink");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map insertLinkGroup(LinkGroup  linkGroup) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String INSERT_LINK_GROUP = "INSERT INTO " + getSchemaName() + ".PL_GROUP_LINK(LINKGROUPKEY,GROUPTYPE,DESC,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
		_LOGGER.info("Insert SQL: " + INSERT_LINK_GROUP);
		try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			if(insertLinkGroupSqlUpdate == null) {
				insertLinkGroupSqlUpdate = new SqlUpdate(getDataSource(),INSERT_LINK_GROUP);
				insertLinkGroupSqlUpdate.declareParameter(new SqlParameter("LINKGROUPKEY", Types.INTEGER));
				insertLinkGroupSqlUpdate.declareParameter(new SqlParameter("GROUPTYPE", Types.CHAR));
				insertLinkGroupSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
				insertLinkGroupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertLinkGroupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));

				insertLinkGroupSqlUpdate.compile();
			}
			int newKey = getGeneratedKey(selectLinkGroupKeys());

			_LOGGER.debug("The new generated key for the table PL_GROUP_LINK is:"+newKey);

			Object[] parameterValues = new Object[]{new Integer(newKey),linkGroup.getGroupType(), linkGroup.getDesc(),lastUpdated, linkGroup.getLastUpdatedBy()};

			int insCount = insertLinkGroupSqlUpdate.update(parameterValues);

			_LOGGER.info("Insert Linkgroup in section logged successfully \n Number of Records insert - "+insCount);

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertLinkGroup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertLinkGroup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertLinkGroup");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map updateLinkGroup(LinkGroup linkGroup) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String UPDATE_LINK_GROUP = "UPDATE " + getSchemaName() + ".PL_GROUP_LINK SET GROUPTYPE=?,DESC=?,LAST_UPDATED=?,LAST_UPDATED_BY=? WHERE LINKGROUPKEY=? ";
		_LOGGER.info("Insert SQL: " + UPDATE_LINK_GROUP);
		try {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			if(updateLinkGroupSqlUpdate == null) {
				updateLinkGroupSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_LINK_GROUP);
				updateLinkGroupSqlUpdate.declareParameter(new SqlParameter("GROUPTYPE", Types.CHAR));
				updateLinkGroupSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
				updateLinkGroupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updateLinkGroupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updateLinkGroupSqlUpdate.declareParameter(new SqlParameter("LINKGROUPKEY", Types.INTEGER));
				updateLinkGroupSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{linkGroup.getGroupType(), linkGroup.getDesc(),lastUpdated, linkGroup.getLastUpdatedBy(),new Integer(linkGroup.getLinkGroupKey()) };

			int updCount = updateLinkGroupSqlUpdate.update(parameterValues);

			_LOGGER.info("Update Linkgroup in section logged successfully \n Number of Records insert - "+updCount);

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateLinkGroup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateLinkGroup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateLinkGroup");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map deleteLinkGroup(int  linkGroupKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_LINK_GROUP = "DELETE FROM " + getSchemaName() + ".PL_GROUP_LINK WHERE LINKGROUPKEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_LINK_GROUP);
		try {

			if(deleteLinkGroupSqlUpdate == null) {
				deleteLinkGroupSqlUpdate = new SqlUpdate(getDataSource(),DELETE_LINK_GROUP);
				deleteLinkGroupSqlUpdate.declareParameter(new SqlParameter("GROUPTYPE", Types.CHAR));
				deleteLinkGroupSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(linkGroupKey)};

			int deleteCount = deleteLinkGroupSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete Linkgroup from section logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteLinkGroup in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteLinkGroup in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteLinkGroup");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map insertSectionData(Section section) throws NCASException {
		String INSERT_SECTION_DATA_SQL = "INSERT INTO  " + getSchemaName() + ".PL_SECTION_DATA(SECTIONKEY,DESC,SECTIONTYPE,HEADERTEXT,INTROTEXT,USER_TYPE,INTL_HEADER,INTL_INTRO,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?)";
		boolean status = false;
		Map responseMap = new HashMap();

		_LOGGER.info("Insert SQL: " + INSERT_SECTION_DATA_SQL);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(insertSectionDataSqlUpdate == null){
				insertSectionDataSqlUpdate = new SqlUpdate(getDataSource(),INSERT_SECTION_DATA_SQL);
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("SECTIONTYPE", Types.CHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("HEADERTEXT", Types.VARCHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("INTROTEXT", Types.VARCHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("USER_TYPE", Types.VARCHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("INTL_HEADER", Types.VARCHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("INTL_INTRO", Types.VARCHAR));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertSectionDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertSectionDataSqlUpdate.compile();
			}

				List currentKeyList = Arrays.asList(selectAllPortalSections().keySet().toArray());

				int newKey = getGeneratedKey(currentKeyList);

				Object[] parameterValues = new Object[]{new Integer(newKey),section.getDesc(),section.getSectionType(),section.getHeaderText(),
														section.getIntroText(),section.getUserType(),section.getIntlHeader(),
														section.getIntlIntro(),lastUpdated,section.getLastUpdatedBy()};

		    	insertSectionDataSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertSectionData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertSectionData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertSectionData");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updateSectionData(Section section) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String UPDATE_SECTION_DATA = "UPDATE " + getSchemaName() + ".PL_SECTION_DATA SET DESC = ?, SECTIONTYPE = ?,HEADERTEXT = ?,INTROTEXT = ?,USER_TYPE = ?, INTL_HEADER = ?, INTL_INTRO= ?, LAST_UPDATED =?, LAST_UPDATED_BY = ? WHERE SECTIONKEY=?";

		_LOGGER.info("Update SQL: " + UPDATE_SECTION_DATA);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(updateSectionDataSqlUpdate == null){


				updateSectionDataSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_SECTION_DATA);
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("SECTIONTYPE", Types.CHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("HEADERTEXT", Types.VARCHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("INTROTEXT", Types.VARCHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("USER_TYPE", Types.VARCHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("INTL_HEADER", Types.VARCHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("INTL_INTRO", Types.VARCHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updateSectionDataSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));

				updateSectionDataSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{section.getDesc(),section.getSectionType(),section.getHeaderText(),
														section.getIntroText(),section.getUserType(),section.getIntlHeader(),
														section.getIntlIntro(),lastUpdated,section.getLastUpdatedBy(),
														new Integer(section.getSectionKey())};

		    	updateSectionDataSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateSectionData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateSectionData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateSectionData");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map deleteSectionData(int  sectionKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_SECTION_DATA = "DELETE FROM " + getSchemaName() + ".PL_SECTION_DATA WHERE SECTIONKEY=?";

		_LOGGER.info("Delete SQL: " + DELETE_SECTION_DATA);


		try
		{
				_LOGGER.info("Deleting the REFERENCES from the PAGESECTION and SECTIONLINK tables");
				Map firstRef = deleteSectionFromPageSection(sectionKey);
				Map secRef	 = deleteSectionFromSectionLink(sectionKey);
				boolean firstBool = ((Boolean)firstRef.get("status")).booleanValue();
				boolean secondBool = ((Boolean)secRef.get("status")).booleanValue();
				if(firstBool && secondBool){
					_LOGGER.debug("All the references for this section have been deleted");
				if(deleteSectionDataSqlUpdate == null){
				deleteSectionDataSqlUpdate = new SqlUpdate(getDataSource(),DELETE_SECTION_DATA);
				deleteSectionDataSqlUpdate.declareParameter(new SqlParameter("SECTIONKEY", Types.INTEGER));
				deleteSectionDataSqlUpdate.compile();
				}
				Object[] parameterValues = new Object[]{new Integer(sectionKey)};

		    	deleteSectionDataSqlUpdate.update(parameterValues);

			    status = true;
				}else{
						_LOGGER.debug("All the REFERENCES for this SECTION couldn't be deleted");
				}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteSectionData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteSectionData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteSectionData");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

	public Map insertPageData(com.verizon.enterprise.common.ncasbosi.beans.Page page) throws NCASException {
		String INSERT_PAGE_DATA_SQL = "INSERT INTO  " + getSchemaName() + ".PL_PAGE_DATA(PAGEKEY,DESC,PAGEID,PAGETYPE,HEADERTEXT,INTROTEXT,INTL_HEADER,INTL_INTRO,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?)";
		boolean status = false;
		Map responseMap = new HashMap();

		_LOGGER.info("Insert SQL: " + INSERT_PAGE_DATA_SQL);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(insertPageDataSqlUpdate == null){
				insertPageDataSqlUpdate = new SqlUpdate(getDataSource(),INSERT_PAGE_DATA_SQL);
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("PAGEKEY", Types.INTEGER));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("PAGEID", Types.INTEGER));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("PAGETYPE", Types.CHAR));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("HEADERTEXT", Types.VARCHAR));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("INTROTEXT", Types.VARCHAR));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("INTL_HEADER", Types.VARCHAR));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("INTL_INTRO", Types.VARCHAR));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertPageDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertPageDataSqlUpdate.compile();
			}

				List currentKeyList = Arrays.asList(selectAllPortalPages().keySet().toArray());
				int newKey = getGeneratedKey(currentKeyList);

				Object[] parameterValues = new Object[]{new Integer(newKey),page.getDesc(), new Integer(page.getPageId()),page.getPageType(),page.getHeaderText(),
														page.getIntroText(),page.getIntlHeader(),
														page.getIntlIntro(),lastUpdated,page.getLastUpdatedBy()};

		    	insertPageDataSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertPageData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertPageData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertSectionData");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map updatePageData(com.verizon.enterprise.common.ncasbosi.beans.Page page) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String UPDATE_PAGE_DATA = "UPDATE " + getSchemaName() + ".PL_PAGE_DATA SET DESC = ?, PAGEID = ?, PAGETYPE = ?,HEADERTEXT = ?,INTROTEXT = ?,INTL_HEADER = ?, INTL_INTRO= ?, LAST_UPDATED = ?, LAST_UPDATED_BY = ? WHERE PAGEKEY=?";

		_LOGGER.info("Update SQL: " + UPDATE_PAGE_DATA);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(updatePageDataSqlUpdate == null){


				updatePageDataSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_PAGE_DATA);
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("DESC", Types.VARCHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("PAGEID", Types.INTEGER));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("PAGETYPE", Types.VARCHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("HEADERTEXT", Types.VARCHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("INTROTEXT", Types.VARCHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("INTL_HEADER", Types.VARCHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("INTL_INTRO", Types.VARCHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updatePageDataSqlUpdate.declareParameter(new SqlParameter("PAGEKEY", Types.INTEGER));

				updatePageDataSqlUpdate.compile();
			}
				Object[] parameterValues = new Object[]{page.getDesc(),new Integer(page.getPageId()),page.getPageType(),page.getHeaderText(),
														page.getIntroText(),page.getIntlHeader(),
														page.getIntlIntro(),lastUpdated,page.getLastUpdatedBy(),
														new Integer(page.getPageKey())};

		    	updatePageDataSqlUpdate.update(parameterValues);

			    status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updatePageData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updatePageData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updatePageData");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


	public Map deletePageData(int pageKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_PAGE_DATA = "DELETE FROM " + getSchemaName() + ".PL_PAGE_DATA WHERE PAGEKEY=?";

		_LOGGER.info("Delete SQL: " + DELETE_PAGE_DATA);

		try
		{
			    Map refMap = deletePageFromPageSection(pageKey);
			    boolean refBool = ((Boolean)refMap.get("status")).booleanValue();
			    if(refBool)
			    {
					_LOGGER.info("All the REFERENCES for PAGE have been deleted");
					if(deletePageDataSqlUpdate == null){
					deletePageDataSqlUpdate = new SqlUpdate(getDataSource(),DELETE_PAGE_DATA);
					deletePageDataSqlUpdate.declareParameter(new SqlParameter("PAGEKEY", Types.INTEGER));
					deletePageDataSqlUpdate.compile();
					}

					Object[] parameterValues = new Object[]{new Integer(pageKey)};

					deletePageDataSqlUpdate.update(parameterValues);

					status = true;
				}else{

					_LOGGER.info("All the REFERENCES for PAGE couldn't be deleted");
				}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deletePageData in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deletePageData in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deletePageData");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public Map insertPageSection(PageSection  pageSection) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int pageKey	= pageSection.getPageKey();
		Map sectionOrder = pageSection.getSectionOrders();
		String lastUpdatedBy = pageSection.getLastUpdatedBy();
		Map curSections = selectSectionsForPage(pageKey);
		String INSERT_PAGE_SECTION = "INSERT INTO " + getSchemaName() + ".PL_PAGE_SECTION(PAGESECTIONKEY,SECTION_KEY,PAGE_KEY,SECTIONORDER,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";

		_LOGGER.info("Insert SQL: " + INSERT_PAGE_SECTION);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(insertPageSectionSqlUpdate == null){


				insertPageSectionSqlUpdate = new SqlUpdate(getDataSource(),INSERT_PAGE_SECTION);
				insertPageSectionSqlUpdate.declareParameter(new SqlParameter("PAGESECTIONKEY", Types.INTEGER));
				insertPageSectionSqlUpdate.declareParameter(new SqlParameter("SECTION_KEY", Types.INTEGER));
				insertPageSectionSqlUpdate.declareParameter(new SqlParameter("PAGE_KEY", Types.INTEGER));
				insertPageSectionSqlUpdate.declareParameter(new SqlParameter("SECTIONORDER", Types.INTEGER));
				insertPageSectionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				insertPageSectionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				insertPageSectionSqlUpdate.compile();
			}


				Iterator it = sectionOrder.entrySet().iterator();

				while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry)it.next();

				int sectionOrderParam = ((Integer)pairs.getValue()).intValue();
				Integer sectionParamInt = (Integer)pairs.getKey();
				int sectionParam = sectionParamInt.intValue();

				if(curSections.containsKey(sectionParamInt))
				{
					//The section already exists. The user has to use update.
						 Exception ex = new Exception("This section already exists on this page.");
						_LOGGER.error("insertPageSection in VAM Failed \n"+ex.getMessage());
						throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,ex);
				}


				_LOGGER.info("Adjust Section Orders getting called");

				int latestSectionOrderParam = adjustSectionOrders(pageSection,sectionParam,sectionOrderParam );

				if(latestSectionOrderParam==0)
				{
					latestSectionOrderParam = sectionOrderParam;
				}

				int newKey = getGeneratedKey(selectAllPageSectionKeys());

				_LOGGER.debug("The new generated Key for the table PL_PAGE_SECTION is:"+newKey);

				insertPageSectionSqlUpdate.update(new Object[]{new Integer(newKey),new Integer(sectionParam),new Integer(pageKey),
																new Integer(latestSectionOrderParam), lastUpdated,lastUpdatedBy});
				}


				status = true;



		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertPageSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertPageSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting insertPageSection");
		responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public int adjustSectionOrders(PageSection pageSection, int sectionKey, int sectionOrder) throws NCASException{
		int pageKey = pageSection.getPageKey();
		Map sectionOrders = selectSectionOrders(pageSection.getPageKey());
		boolean sectionOrderTaken = sectionOrders.containsValue(new Integer(sectionOrder));
		boolean sectionExists = sectionOrders.containsKey(new Integer(sectionKey));
		int maxSectionOrderPlusOne = 0;
		int maxValueCalculated = 0;

		if(sectionOrder==-1)
		{
			if(sectionOrders.values()!=null && sectionOrders.values().size()>0)
			{
				maxValueCalculated = ((Integer)Collections.max(sectionOrders.values())).intValue();
			}
			maxSectionOrderPlusOne = maxValueCalculated+1;
			_LOGGER.info("Max Integer Plus one is: " + maxSectionOrderPlusOne);
			return maxSectionOrderPlusOne;
		}

		if(!sectionOrderTaken)
		{
			//The section order is not taken. So the section that is being introduced is going to be the last section if there
			//are already sections existing or it will be the first, if none exists.
			return sectionOrder;
		}
		else{
			//The section order is taken. All the current sections that are equal or greater to the user choice of the
			//section order should be increased by one.
		    Iterator it = sectionOrders.entrySet().iterator();

		    Map latestSectionOrders = new HashMap();
						if(sectionExists)
						{
							 int updatingSectionOrder = ((Integer)sectionOrders.get(new Integer(sectionKey))).intValue();
							 _LOGGER.info("The updatingSectionOrder is:"+updatingSectionOrder);
							_LOGGER.info("The section already exists. So this must be an update and not an insert");
								while (it.hasNext())
								{

									Map.Entry pairs = (Map.Entry)it.next();

									int curSectionKey = ((Integer)(pairs.getKey())).intValue();
									int curSectionOrder = ((Integer)pairs.getValue()).intValue();
									_LOGGER.info("Current section ->"+curSectionKey+"Current section order-> "+curSectionOrder);
									if(sectionKey==curSectionKey)
									{
										_LOGGER.info("This is the section that is being modified->"+curSectionKey+" The new section order is " +sectionOrder);
										latestSectionOrders.put(new Integer(curSectionKey), new Integer(sectionOrder));
									}
									else if(updatingSectionOrder>sectionOrder)
									{
										//This means the section is moving up in the order.
										//All the section which have the order equal or greater than selected order
										//and less than the old order are to be increased by 1.

											if(curSectionOrder == sectionOrder || curSectionOrder>sectionOrder && curSectionOrder<updatingSectionOrder)
											{
												int latestSectionOrder = curSectionOrder+1;
												_LOGGER.info("The Latest section order for the section "+ curSectionKey+" is "+latestSectionOrder);
												latestSectionOrders.put(new Integer(curSectionKey), new Integer(latestSectionOrder));
											}
											else{
												_LOGGER.info("The LATEST section order for the section "+ curSectionKey+" is "+curSectionOrder);
												latestSectionOrders.put(new Integer(curSectionKey), new Integer(curSectionOrder));
											}
									}
									else if(updatingSectionOrder<sectionOrder)
									{
										//This means the section is moving down in the order.
										//All the section which have the sectionorder equal or greater than selected sectionorder
										//and less than the old sectionorder are to be increased by 1.

											if(curSectionOrder == sectionOrder || curSectionOrder<sectionOrder && curSectionOrder>updatingSectionOrder)
											{
												int latestSectionOrder = curSectionOrder-1;
												_LOGGER.info("The Latest section order for the section "+ curSectionKey+" is "+latestSectionOrder);
												latestSectionOrders.put(new Integer(curSectionKey), new Integer(latestSectionOrder));
											}
											else{
												_LOGGER.info("The LATEST section order for the section "+ curSectionKey+" is "+curSectionOrder);
												latestSectionOrders.put(new Integer(curSectionKey), new Integer(curSectionOrder));
											}
									}
									else{
												_LOGGER.info("The LATEST section order for the section "+ curSectionKey+" is "+curSectionOrder);
												latestSectionOrders.put(new Integer(curSectionKey), new Integer(curSectionOrder));
									}
				    }
				    updateSectionOrder(latestSectionOrders, sectionKey,pageSection.getLastUpdatedBy());
			}
			else
			{
				_LOGGER.info("The section doesn't exist. So this must be an insert and not an update");
					while (it.hasNext())
					{
						Map.Entry pairs = (Map.Entry)it.next();
						if(((Integer)pairs.getValue()).intValue()>=sectionOrder)
						{

							int latestSectionOrder = ((Integer)(pairs.getValue())).intValue()+1;
							int curSectionKey = ((Integer)(pairs.getKey())).intValue();

							_LOGGER.info("The latest section order for the section "+ curSectionKey+" is "+latestSectionOrder);

							latestSectionOrders.put(new Integer(curSectionKey), new Integer(latestSectionOrder));

						}else
						{
							latestSectionOrders.put((Integer)pairs.getKey(), (Integer)pairs.getValue());
						}
				    }
				  updateSectionOrder(latestSectionOrders, sectionKey,pageSection.getLastUpdatedBy());
	  	  	}

		}
		  return maxSectionOrderPlusOne;
	}

public boolean updateSectionOrder(Map sectionOrder, int pageKey, String lastUpdatedBy) throws NCASException{
		boolean status = false;

		String UPDATE_SECTION_ORDER_SQL = "INSERT INTO " + getSchemaName() + ".PL_PAGE_SECTION(PAGESECTIONKEY,PAGE_KEY,SECTIONORDER,SECTION_KEY,LAST_UPDATED,LAST_UPDATED_BY ) VALUES(?,?,?,?,?,?)";

		_LOGGER.info(" SQL: " + UPDATE_SECTION_ORDER_SQL);


		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			if(deleteAllSectionsFromPage(pageKey))
			{

				if(updateSectionOrderSqlUpdate == null)
				{

					updateSectionOrderSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_SECTION_ORDER_SQL);
					updateSectionOrderSqlUpdate.declareParameter(new SqlParameter("PAGESECTIONKEY", Types.INTEGER));
					updateSectionOrderSqlUpdate.declareParameter(new SqlParameter("PAGE_KEY", Types.INTEGER));
					updateSectionOrderSqlUpdate.declareParameter(new SqlParameter("SECTIONORDER", Types.INTEGER));
					updateSectionOrderSqlUpdate.declareParameter(new SqlParameter("SECTION_KEY", Types.INTEGER));
					updateSectionOrderSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
					updateSectionOrderSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
					updateSectionOrderSqlUpdate.compile();
				}

			    Iterator it = sectionOrder.entrySet().iterator();
				int testIncrement = 0;
				int newKey = 0;
			    while (it.hasNext()) {
				if(testIncrement == 0)
				{
					newKey = getGeneratedKey(selectAllPageSectionKeys());
				}
				else{
					newKey++;
				}
		        Map.Entry pairs = (Map.Entry)it.next();
		    	testIncrement+= updateSectionOrderSqlUpdate.update(new Object[]{new Integer(newKey),new Integer(pageKey), (Integer)pairs.getValue(),
		    									(Integer)pairs.getKey(),lastUpdated, lastUpdatedBy});
			    }

				if(updateSectionOrderSqlUpdate!=null)
				updateSectionOrderSqlUpdate.flush();

				status = true;
			}

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updateSectionOrder in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updateSectionOrder in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updateSectionOrder");
		return status;
	}

	public Map updatePageSection(PageSection  pageSection) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		int pageKey = pageSection.getPageKey();
		Map dbSectionOrders = selectSectionOrders(pageKey);
		String UPDATE_PAGE_SECTION_SQL = "UPDATE " + getSchemaName() + ".PL_PAGE_SECTION SET SECTIONORDER = ? , LAST_UPDATED = ?, LAST_UPDATED_BY = ? WHERE PAGE_KEY=? AND SECTION_KEY=?";

		_LOGGER.info("Update SQL: " + UPDATE_PAGE_SECTION_SQL);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				if(updatePageSectionSqlUpdate == null){


				updatePageSectionSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_PAGE_SECTION_SQL);

				updatePageSectionSqlUpdate.declareParameter(new SqlParameter("SECTIONORDER", Types.INTEGER));
				updatePageSectionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
				updatePageSectionSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
				updatePageSectionSqlUpdate.declareParameter(new SqlParameter("PAGE_KEY", Types.INTEGER));
				updatePageSectionSqlUpdate.declareParameter(new SqlParameter("SECTION_KEY", Types.INTEGER));

				updatePageSectionSqlUpdate.compile();
			}
				Map sectionOrders = pageSection.getSectionOrders();

			    Iterator it = sectionOrders.entrySet().iterator();

			    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();

				boolean sectionOrderTaken = dbSectionOrders.containsValue((Integer)(pairs.getValue()));
				if(!sectionOrderTaken)
				{
		    		updatePageSectionSqlUpdate.update(new Object[]{(Integer)pairs.getValue(),lastUpdated,
		    														pageSection.getLastUpdatedBy(), new Integer(pageKey),
		    														(Integer)pairs.getKey()});
				}
		    	else
		    	{
					adjustSectionOrders(pageSection,((Integer)pairs.getKey()).intValue(),((Integer)pairs.getValue()).intValue());
				}
			   }
			   if(updatePageSectionSqlUpdate != null)
			   updatePageSectionSqlUpdate.flush();

				status = true;

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("updatePageSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("updatePageSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting updatePageSection");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public boolean deleteAllSectionsFromPage(int pageKey) throws NCASException {
		boolean status = false;
		String DELETE_ALL_SECTIONS = "DELETE FROM " + getSchemaName() + ".PL_PAGE_SECTION WHERE PAGE_KEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_ALL_SECTIONS);

		try {
			if(deleteAllSectionsFromPageSqlUpdate == null) {
				deleteAllSectionsFromPageSqlUpdate = new SqlUpdate(getDataSource(),DELETE_ALL_SECTIONS);
				deleteAllSectionsFromPageSqlUpdate.declareParameter(new SqlParameter("PAGE_KEY", Types.INTEGER));
				deleteAllSectionsFromPageSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(pageKey)};

			int deleteCount = deleteAllSectionsFromPageSqlUpdate.update(parameterValues);

			if(deleteCount > 0) {
				_LOGGER.info("Delete Sections from Page logged successfully \n Number of Records deleted - "+deleteCount);
				status = true;
			}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteAllSectionsFromPage in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteAllSectionsFromPage in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteAllSectionsFromPage");
		return status;
	}


	public Map deletePageSection(int pageKey, int sectionKey, String allOrSingle) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_SECTIONS_FROM_PAGE = "DELETE FROM " + getSchemaName() + ".PL_PAGE_SECTION WHERE PAGE_KEY = ? AND SECTION_KEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_SECTIONS_FROM_PAGE);

		try {
			if(allOrSingle.equalsIgnoreCase("ALL"))
			{
				boolean otherstatus = deleteAllSectionsFromPage(pageKey);
				responseMap.put("status",new Boolean(status));
				return responseMap;
			}
			else{

			if(deletePageSectionSqlUpdate == null) {
				deletePageSectionSqlUpdate = new SqlUpdate(getDataSource(),DELETE_SECTIONS_FROM_PAGE);
				deletePageSectionSqlUpdate.declareParameter(new SqlParameter("PAGE_KEY", Types.INTEGER));
				deletePageSectionSqlUpdate.declareParameter(new SqlParameter("SECTION_KEY", Types.INTEGER));
				deletePageSectionSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(pageKey), new Integer(sectionKey)};

			int deleteCount = deletePageSectionSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete Section from page logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;
	  		}
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deletePageSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deletePageSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deletePageSection");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public Map deleteSectionFromPageSection(int sectionKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_SECTION_REFERENCE = "DELETE FROM " + getSchemaName() + ".PL_PAGE_SECTION WHERE SECTION_KEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_SECTION_REFERENCE);

		try {
			if(deleteSectionRefSqlUpdate == null) {
				deleteSectionRefSqlUpdate = new SqlUpdate(getDataSource(),DELETE_SECTION_REFERENCE);
				deleteSectionRefSqlUpdate.declareParameter(new SqlParameter("SECTION_KEY", Types.INTEGER));
				deleteSectionRefSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(sectionKey)};

			int deleteCount = deleteSectionRefSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete Section from pagesection logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteSectionFromPageSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteSectionFromPageSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteSectionFromPageSection");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}

public Map deletePageFromPageSection(int pageKey) throws NCASException {
		boolean status = false;
		Map responseMap = new HashMap();
		String DELETE_PAGE_REFERENCE = "DELETE FROM " + getSchemaName() + ".PL_PAGE_SECTION WHERE PAGE_KEY = ?";
		_LOGGER.info("Delete SQL: " + DELETE_PAGE_REFERENCE);

		try {
			if(deletePageRefSqlUpdate == null) {
				deletePageRefSqlUpdate = new SqlUpdate(getDataSource(),DELETE_PAGE_REFERENCE);
				deletePageRefSqlUpdate.declareParameter(new SqlParameter("PAGE_KEY", Types.INTEGER));
				deletePageRefSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{new Integer(pageKey)};

			int deleteCount = deletePageRefSqlUpdate.update(parameterValues);

			_LOGGER.info("Delete Page from pagesection logged successfully \n Number of Records deleted - "+deleteCount);

				status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deletePageFromPageSection in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deletePageFromPageSection in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deletePageFromPageSection");
		 responseMap.put("status",new Boolean(status));
		 return responseMap;
	}


public Map selectAllButtons(String portalType,List permissions) throws NCASException {
	 _LOGGER.info("Select SQL: " + SELECT_ALL_BUTTONS);

		Object[] params = new Object[MAX_PERMS+1];
		Iterator it = permissions.iterator();


		for(int i = 0;i<MAX_PERMS;i++){
			if(it.hasNext()) {
				params[i] = new String(String.valueOf(it.next()));
			} else {
				params[i] = "";
			}
		}
		params[MAX_PERMS] = new String(portalType);

	 return selectAllButtons.getAllButtons(params);
}





class SelectAllButtons extends JdbcDaoSupport {
    private String sql;

	public SelectAllButtons(String sql) {
        this.sql = sql;
    }

	public Map getAllButtons(Object[] params) {
		 _LOGGER.info("getAllButtons :: " + params);
	        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
		        public Object extractData(ResultSet rs) throws SQLException {
		   		 _LOGGER.info("In extractData :: " );

		   		 	  Map buttonMap = new HashMap();
			          while (rs.next()) {
				  		  int key = rs.getInt("BTN_KEY");
					      String name = rs.getString("NAME");
					      String pageID = rs.getString("PAGE_ID");
					      String pageAttr = rs.getString("PAGE_ATTR");
					      String contentID = rs.getString("CONTENT_ID");

					      String btnKey = NCASDataUtil.getButtonKey(pageID,pageAttr,contentID);
					      List btnNameList = (List)buttonMap.get(btnKey);
					      if(btnNameList==null)
					    	  btnNameList = new ArrayList();
					      btnNameList.add(new Label(name,name));
					      buttonMap.put(btnKey,btnNameList);
			          }
				      return buttonMap;
		        }});
	    }

}


	private String getSchemaName() {
	    String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
	    //_LOGGER.debug("SCHEMA NAME ##  -> " + schemaName);
	    return schemaName;
	 }

  private int getGeneratedKey(List currentKeyList)
  {
			int maxLinkNbrPlusOne = 0;
			int maxValueCalculated = 0;
			if(currentKeyList!=null && currentKeyList.size()>0)
			{
				maxValueCalculated = ((Integer)Collections.max(currentKeyList)).intValue();
			}
			maxLinkNbrPlusOne = maxValueCalculated+1;
			return maxLinkNbrPlusOne;
  }

	public List selectAllBillingMetrics() throws NCASException{
		return selectAllBillingMetrics.getAllBillingMetrics(new Object[]{});
	}


  class SelectAllBillingMetrics extends JdbcDaoSupport {
	    private String sql;

		public SelectAllBillingMetrics(String sql) {
	        this.sql = sql;
	    }

		public List getAllBillingMetrics(Object[] params) {
			 _LOGGER.info("getAllBillingMetrics :: " + params);
		        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
			        public Object extractData(ResultSet rs) throws SQLException {
			   		 _LOGGER.info("In extractData :: " );

			   		 	  List billMetList = new ArrayList();
				          while (rs.next()) {
						      String name = rs.getString("NAME");
						      billMetList.add(name);
				          }
					      return billMetList;
			        }});
		    }
	}
	public Map selectBillingMetricsDetails(String trans_name, String portalType, String from_date, String to_date) throws NCASException{
		return selectBillingMetricsDetails.getBillingMetricsDetails(new Object[]{trans_name}, portalType, from_date, to_date);
	}


	  class SelectBillingMetricsDetails extends JdbcDaoSupport {
		    private String sql;

			public SelectBillingMetricsDetails(String sql) {
		        this.sql = sql;
		    }

			public Map getBillingMetricsDetails(Object[] params, String portalType, String from_date, String to_date) {
				 _LOGGER.info("getBillingMetricsDetails :: " + params);
			        return  (Map)getDBTemplate().query(returnQuery(portalType, from_date, to_date), params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  Map billMetMap = new HashMap();
					          while (rs.next()) {
								  List billMetDetailsList = new ArrayList();
							      String name = rs.getString("NAME");
							      String tx_name_oid = rs.getString("TX_NAME_OID");
							      String user_oid = rs.getString("USER_OID");
							      String start_time = rs.getString("START_TIME");
							      String end_time = rs.getString("END_TIME");
							      int log_oid = rs.getInt("LOG_OID");
							      billMetDetailsList.add(name);
							      billMetDetailsList.add(tx_name_oid);
							      billMetDetailsList.add(user_oid);
							      billMetDetailsList.add(start_time);
							      billMetDetailsList.add(end_time);
							      billMetMap.put(new Integer(log_oid), billMetDetailsList);
					          }
						      return billMetMap;
				        }});
			    }

		}



		private String returnQuery(String portalType, String from_date, String to_date){
			String tempBuff = "SELECT i.NAME,j.tx_name_oid,k.USER_OID,j.START_TIME,j.END_TIME, k.LOG_OID FROM metrics5.tx_name i, metrics5.TRANSACTION j, metrics5.LOG k WHERE j.transaction_oid=k.transaction_oid AND i.tx_name_oid=j.tx_name_oid AND i.NAME = ? AND k.time_oid >= *** AND k.time_oid <= $$$ AND k.portal_oid @@@ ORDER BY k.log_oid DESC";
			StringBuffer temp = new StringBuffer(tempBuff);
			int pIndex = temp.indexOf("@");
			_LOGGER.info("PINDEX :::"+pIndex);
			temp.replace(pIndex, pIndex+3, portalType);
			int fdIndex = temp.indexOf("*");
			_LOGGER.info("FDINDEX :::"+fdIndex);
			temp.replace(fdIndex, fdIndex+3, from_date);
			int tdIndex = temp.indexOf("$");
			_LOGGER.info("TDINDEX :::"+tdIndex);
			temp.replace(tdIndex, tdIndex+3, to_date);
			return temp.toString();
		}

		/**
		 * Buttons methods in billview/admin/params
		 */

		public Map getButtonDropdowns() throws NCASException {
			Map responseMap = new HashMap();
			try{
				List portalNames = DAOFactory.getInstance().getPortalLinkForECP().selectAllPortalNames();
				Map currentButtonKeys = selectButtonNamesKeys();
				//List pageAttr = selectPageAttr();
				List pageId = selectBtnPageId();
				List overKeyNames = new ArrayList();
				//List orders = selectAllBtnOrders();
				Iterator it = currentButtonKeys.entrySet().iterator();
				String finalVal = "";
				while (it.hasNext()) {
					Map.Entry pairs = (Map.Entry)it.next();
					int btnKey = ((Integer)pairs.getKey()).intValue();
					String btnName = (String)pairs.getValue();
					 finalVal = Integer.toString(btnKey);
					if(btnName!=null && btnName.trim().length()>0)
					{
						finalVal = btnKey+"--"+btnName;
					}
					//_LOGGER.debug("The final Value is ->"+finalVal);
					overKeyNames.add(finalVal);
				}
				responseMap.put("portalNames",portalNames);
				responseMap.put("currentButtons",overKeyNames);
				//responseMap.put("pageAttr", pageAttr);
				responseMap.put("pageId", pageId);
				//responseMap.put("btnOrder", orders);
				_LOGGER.info("Exiting getButtonDropdowns");
				} catch(Exception vamEx) {
					_LOGGER.debug("getButtonDropdowns in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("getButtonDropdowns in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
				}
				_LOGGER.info("responseMap"+ responseMap);
				return responseMap;
			}
		public Map selectButtonNamesKeys() throws NCASException {
			 return selectButtonNamesKeys.getButtonNamesKeys(new Object[]{});
		}


		class SelectButtonNamesKeys extends JdbcDaoSupport {
		    private String sql;

			public SelectButtonNamesKeys(String sql) {
		        this.sql = sql;
		    }

			public Map getButtonNamesKeys(Object[] params) {
				 _LOGGER.info("getButtonNamesKeys :: " + params);
			        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  Map btnKeyNameMap = new HashMap();
					          while (rs.next()) {
							      String btnName = rs.getString("NAME");
							      int btnKey = rs.getInt("BTN_KEY");
							      btnKeyNameMap.put(new Integer(btnKey),btnName);
					          }
						      return btnKeyNameMap;
				        }});
			    }

		}

		public List selectPageAttr(int pageId) throws NCASException {
			 return selectPageAttr.getPageAttr(new Object[]{new Integer(pageId)});
		}


		class SelectPageAttr extends JdbcDaoSupport {
		    private String sql;

			public SelectPageAttr(String sql) {
		        this.sql = sql;
		    }

			public List getPageAttr(Object[] params) {
				 _LOGGER.info("getPageAttr :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List pageAttrList = new ArrayList();
					          while (rs.next()) {
							      String pageAttr = rs.getString("PAGE_ATTR");
							      pageAttrList.add(pageAttr);
					          }
						      return pageAttrList;
				        }});
			    }

		}

		public List selectBtnPageId() throws NCASException {
			 return selectBtnPageId.getBtnPageId(new Object[]{});
		}



		class SelectBtnPageId extends JdbcDaoSupport {
		    private String sql;

			public SelectBtnPageId(String sql) {
		        this.sql = sql;
		    }

			public List getBtnPageId(Object[] params) {
				 _LOGGER.info("getBtnPageId :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List pageIdList = new ArrayList();
					          while (rs.next()) {
							      String pageId = rs.getString("PAGE_ID");
							      pageIdList.add(pageId);
					          }
						      return pageIdList;
				        }});
			    }

		}


		public List selectAllBtnOrders() throws NCASException {
			 return selectAllBtnOrders.getAllBtnOrders(new Object[]{});
		}



		class SelectAllBtnOrders extends JdbcDaoSupport {
		    private String sql;

			public SelectAllBtnOrders(String sql) {
		        this.sql = sql;
		    }

			public List getAllBtnOrders(Object[] params) {
				 _LOGGER.info("getAllBtnOrders :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List btnOrderList = new ArrayList();
					          while (rs.next()) {
							      int btnOrder = rs.getInt("BTN_ORDER");
							      btnOrderList.add(new Integer(btnOrder));
					          }
						      return btnOrderList;
				        }});
			    }
		}


		public Map selectBtnsForPage(int pageId, String pageAttr, int contentId) throws NCASException {
			 return selectBtnsForPage.getBtnsForPage(new Object[]{new Integer(pageId), pageAttr, new Integer(contentId)});
		}



		class SelectBtnsForPage extends JdbcDaoSupport {
		    private String sql;

			public SelectBtnsForPage(String sql) {
		        this.sql = sql;
		    }

			public Map getBtnsForPage(Object[] params) {
				 _LOGGER.info("getBtnsForPage :: " + params);
			        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  Map btnsForPage = new HashMap();
					          while (rs.next()) {
							      String name = rs.getString("NAME");
							      int btnKey = rs.getInt("BTN_KEY");
							      btnsForPage.put(new Integer(btnKey),name);
					          }
						      return btnsForPage;
				        }});
			    }

		}

		public Map selectBtnOrders(int pageId, String pageAttr, int contentId) throws NCASException {
			 return selectBtnOrders.getBtnOrders(new Object[]{new Integer(pageId), pageAttr, new Integer(contentId)});
		}


		class SelectBtnOrders extends JdbcDaoSupport {
		    private String sql;

			public SelectBtnOrders(String sql) {
		        this.sql = sql;
		    }

			public Map getBtnOrders(Object[] params) {
				 _LOGGER.info("getBtnOrders :: " + params);
			        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  Map btnOrders = new HashMap();
					          while (rs.next()) {
							      int btnKey = rs.getInt("BTN_KEY");
							      int btnOrder = rs.getInt("BTN_ORDER");
							      btnOrders.put(new Integer(btnKey),new Integer(btnOrder));
					          }
						      return btnOrders;
				        }});
			    }

		}
		public List selectAllBtnKeys() throws NCASException {
			 return selectAllBtnKeys.getAllBtnKeys(new Object[]{});
		}


		class SelectAllBtnKeys extends JdbcDaoSupport {
		    private String sql;

			public SelectAllBtnKeys(String sql) {
		        this.sql = sql;
		    }

			public List getAllBtnKeys(Object[] params) {
				 _LOGGER.info("getAllBtnKeys :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List btnKeyList = new ArrayList();
					          while (rs.next()) {
							      int btnKey = rs.getInt("BTN_KEY");
							      btnKeyList.add(new Integer(btnKey));
					          }
						      return btnKeyList;
				        }});
			    }
		}
		public Map insertButton(Button button) throws NCASException {
			boolean status = false;
			//_LOGGER.info("Insert SQL: " + INSERT_PL_BTN);
			_LOGGER.info("INSIDE INSERT BUTTON");
		    Map responseMap = new HashMap();
		    Map btnOrders = button.getBtnOrders();
		    _LOGGER.info("btnOrders --> "+ btnOrders);
		    int pageId = Integer.parseInt(button.getPageId());
		    _LOGGER.info("pageId --> "+ pageId);
		    String pageAttr = button.getPageAttr();
		    _LOGGER.info("pageAttr --> "+ pageAttr);
		    int contentId = Integer.parseInt(button.getContentId());
		    _LOGGER.info("contentId --> "+ contentId);
		    List names = button.getNames();
		    _LOGGER.info("names List --> "+ names);
		    List misc = button.getMisc();
		    _LOGGER.info("misc List --> "+ misc);
		    Map curBtns = selectBtnsForPage(pageId, pageAttr, contentId);
		    _LOGGER.info("curBtns MAP--> "+ curBtns);

		    String INSERT_PL_BTN = "INSERT INTO " + getSchemaName() + ".PL_BTN(BTN_KEY,NAME,PAGE_ID,PAGE_ATTR,CONTENT_ID,BTN_ORDER,MISC,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?)";
		    _LOGGER.info("Insert SQL: " + INSERT_PL_BTN);
		    try {
		    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

		    	if (insertButtonSqlUpdate == null) {
		    	  insertButtonSqlUpdate = new SqlUpdate(getDataSource(),INSERT_PL_BTN);
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("PAGE_ATTR", Types.CHAR));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("CONTENT_ID", Types.INTEGER));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("BTN_ORDER", Types.INTEGER));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("MISC", Types.VARCHAR));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
		    	  insertButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
		      }
		      Iterator it = btnOrders.entrySet().iterator();
		      int i = 0;
		      while(it.hasNext()){
		    	    Map.Entry pairs = (Map.Entry)it.next();

					int btnOrderParam = ((Integer)pairs.getValue()).intValue();
					_LOGGER.info("btnOrderParam -------> "+btnOrderParam);
					_LOGGER.info("Adjust btn Orders getting called");
					int latestBtnOrderParam = adjustInsBtnOrders(button, pageId, btnOrderParam );
					_LOGGER.info("latestBtnOrderParam --> "+latestBtnOrderParam);
					if(latestBtnOrderParam==0){
						latestBtnOrderParam = btnOrderParam;
					}
					_LOGGER.info("latestBtnOrderParam --> "+latestBtnOrderParam);
		      List currentKeyList = Arrays.asList(selectButtonNamesKeys().keySet().toArray());
			  int newKey = getGeneratedKey(currentKeyList);
			  _LOGGER.debug("The new generated key for the PL_BTN table is :"+newKey);
				  _LOGGER.info("The NAME Inserted is --> "+names.get(i));
				  String nameStr = (String) names.get(i);
			      Object[] parameterValues = new Object[] {new Integer(newKey),nameStr, new Integer(pageId), pageAttr,
			      											new Integer(contentId), new Integer(latestBtnOrderParam), misc.get(i), lastUpdated,
		      											button.getLastUpdatedBy()};
		      int insCount = insertButtonSqlUpdate.update(parameterValues);
		      if (insCount > 0) {
		          _LOGGER.info( "Insert PL BUTTON  Response logged successfully \n Number of Records inserted - " + insCount);
		  		button.setBtnKey(newKey);
			  		List permBtnNames = (List)button.getPermBtnNames().get("permissions_"+i);
		        if(permBtnNames!= null && permBtnNames.size()>0)
		        {
						// This btn requires the user to have one of the permissions in the list.
					status = false;
					insertPermButton(button);
					status = true;
				}
					List portalList = (List)button.getPortalIndsForExcl().get("efp_"+i);
					_LOGGER.info( "Listing portalList  --> " + portalList);
		        if(portalList!= null && portalList.size()>0)
		        {
						// This btn has to be excluded from the selected portals.
					status = false;
					insertExclButton(button);
					status = true;
				}
		      }
			      i++;
		      }
		    }
		    catch (Exception vamEx) {
		      vamEx.printStackTrace();
		      _LOGGER.debug("insertButton in VAM Failed \n" +vamEx.getMessage());
		      _LOGGER.error("insertButton in VAM Failed \n" +vamEx.getMessage());
		      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
		    }
		    _LOGGER.info("Exiting insertButton" + responseMap.toString());
		    responseMap.put("status", new Boolean(status));
		    return responseMap;
		  }

		public int adjustInsBtnOrders(Button button, int pageId, int btnOrder) throws NCASException{
			Map btnOrderMap = selectBtnOrders(pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()));
			_LOGGER.info("adjustBtnOrders: The PAGE ID is: " + pageId);
			_LOGGER.info("adjustBtnOrders: The btnOrder is: " + btnOrder);
			boolean btnOrderTaken = btnOrderMap.containsValue(new Integer(btnOrder));
			_LOGGER.info("adjustBtnOrders: The BOOL of btnOrderTaken is: " + btnOrderTaken);
			int maxBtnOrderPlusOne = 0;
			int maxValueCalculated = 0;
			if(btnOrder==-1){
				if(btnOrderMap.values()!=null && btnOrderMap.values().size()>0){
					maxValueCalculated = ((Integer)Collections.max(btnOrderMap.values())).intValue();
				}
				maxBtnOrderPlusOne = maxValueCalculated+1;
				_LOGGER.info("Max Integer Plus one is: " + maxBtnOrderPlusOne);
				return maxBtnOrderPlusOne;
			}
			if(!btnOrderTaken){
				//The btn order is not taken. So the btn that is being introduced is going to be the last btn if there
				//are already btns existing or it will be the first, if none exists.
				return btnOrder;
			}else{
				//The btn order is taken. All the current btns that are equal or greater to the user choice of the
				//btn order should be increased by one if this btn is moving down.All the current btns which have their
				//current btn order inbetween or equal to the chosen btn order, should be increased by one and the others
				//remain the same.
			    Iterator it = btnOrderMap.entrySet().iterator();
			    _LOGGER.info("The SIZE of btnOrderMap is:"+btnOrderMap.size());
			    Map latestBtnOrders = new HashMap();
					_LOGGER.info("The btn doesn't exist. So this must be an insert and not an update");
						while (it.hasNext()){
							Map.Entry pairs = (Map.Entry)it.next();
							_LOGGER.info("((Integer)pairs.getValue()).intValue() ---------->  "+ ((Integer)pairs.getValue()).intValue());
							_LOGGER.info("btnOrder ---------->  "+ btnOrder);
							if(((Integer)pairs.getValue()).intValue()>= btnOrder){
								int latestBtnOrder = ((Integer)(pairs.getValue())).intValue()+1;
								int curBtnKey = ((Integer)(pairs.getKey())).intValue();
								_LOGGER.info("The latest btn order for the btn "+ curBtnKey+" is "+latestBtnOrder);
								latestBtnOrders.put(new Integer(curBtnKey), new Integer(latestBtnOrder));
							}else{
								latestBtnOrders.put((Integer)pairs.getKey(), (Integer)pairs.getValue());
							}
					    }
						_LOGGER.info("latestBtnOrders ---------->  "+ latestBtnOrders);
					  updateBtnOrder(latestBtnOrders, pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()), button.getLastUpdatedBy());
			}
			  return maxBtnOrderPlusOne;
		}

		public boolean updateBtnOrder(Map btnOrder, int pageId, String pageAttr, int contentId, String lastUpdatedBy) throws NCASException{
			boolean status = false;
			//String UPDATE_BTN_ORDER_SQL = "INSERT INTO " + getSchemaName() + ".PL_BTN(PAGE_ID,BTN_KEY,BTN_ORDER,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
			String UPDATE_BTN_ORDER_SQL = "UPDATE " + getSchemaName() +".PL_BTN SET BTN_ORDER = ?, LAST_UPDATED = ?,LAST_UPDATED_BY =? WHERE PAGE_ID = ? AND PAGE_ATTR = ? AND CONTENT_ID = ? AND BTN_KEY = ?";
			_LOGGER.info(" SQL: " + UPDATE_BTN_ORDER_SQL);
			try{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				if(updateBtnOrderSqlUpdate == null){
					updateBtnOrderSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_BTN_ORDER_SQL);
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("BTN_ORDER", Types.INTEGER));
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("PAGE_ATTR", Types.VARCHAR));
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("CONTENT_ID", Types.VARCHAR));
					updateBtnOrderSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
					updateBtnOrderSqlUpdate.compile();
				}
				Iterator it = btnOrder.entrySet().iterator();
				int testIncrement = 0;
				int newKey = 0;
				while (it.hasNext()) {
					if(testIncrement ==0){
						newKey = getGeneratedKey(selectAllBtnKeys());
					}else{
						newKey++;
					}
					Map.Entry pairs = (Map.Entry)it.next();
					testIncrement+= updateBtnOrderSqlUpdate.update(new Object[]{(Integer)pairs.getValue(), lastUpdated, lastUpdatedBy, new Integer(pageId), pageAttr, new Integer(contentId), (Integer)pairs.getKey()});
				}
				if(updateBtnOrderSqlUpdate!=null)
				updateBtnOrderSqlUpdate.flush();
				status = true;
			} catch(Exception vamEx) {
				vamEx.printStackTrace();
				_LOGGER.debug("updateInsBtnOrder in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("updateInsBtnOrder in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting updateInsBtnOrder");
			return status;
		}



		public List selectAllButtonPermissions() throws NCASException {
			 return selectAllButtonPermissions.getAllButtonPermissions(new Object[]{});
		}
		class SelectAllButtonPermissions extends JdbcDaoSupport {
		    private String sql;

			public SelectAllButtonPermissions(String sql) {
		        this.sql = sql;
		    }

			public List getAllButtonPermissions(Object[] params) {
				 _LOGGER.info("getAllButtonPermissions :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List permBtnKeyList = new ArrayList();
					          while (rs.next()) {
							      int btnKey = rs.getInt("PERMBTN_KEY");
							      permBtnKeyList.add(new Integer(btnKey));
					          }
						      return permBtnKeyList;
				        }});
			    }
		}
		public Map insertPermButton(Button button) throws NCASException {

			boolean status = false;

		    Map responseMap = new HashMap();
		    String INSERT_PERM_BTN = "INSERT INTO " + getSchemaName() + ".PL_BTNPERMINCL(PERMBTN_KEY,NAME,BTN_KEY,LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
		    _LOGGER.info("Insert SQL: " + INSERT_PERM_BTN);

		    try {
		    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

		    	if (insertPermButtonSqlUpdate == null) {
		    	  insertPermButtonSqlUpdate = new BatchSqlUpdate(getDataSource(),INSERT_PERM_BTN);
		    	  insertPermButtonSqlUpdate.declareParameter(new SqlParameter("PERMBTN_KEY", Types.INTEGER));
		    	  insertPermButtonSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
		    	  insertPermButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
		    	  insertPermButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
		    	  insertPermButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
		      }
			  int btnKey = button.getBtnKey();
			  String lastUpdatedBy = button.getLastUpdatedBy();
			  int count = button.getMisc().size();
			  Map permMap = button.getPermBtnNames();
			  for(int x = 0; x < count; x++){

			      List permList = (List) permMap.get("permissions_"+x);
			  int insCount = 0;
			  int genPermKey = 0;
			  _LOGGER.debug("The permlist size is:"+permList.size());
					    for(int i =0;i<permList.size();i++) {
							if(i==0)
							{
								genPermKey = getGeneratedKey(selectAllButtonPermissions());
							}else{
								genPermKey++;
							}
						  _LOGGER.debug("The new generated key for the PL_BTNPERMINCL table is :"+genPermKey);
					      _LOGGER.debug("The permission name that is getting entered for the btnKey:"+btnKey+" is:"+(String)permList.get(i));

				    	insCount += insertPermButtonSqlUpdate.update(new Object[]{new Integer(genPermKey),(String)permList.get(i),new Integer(btnKey),lastUpdated,lastUpdatedBy});
					    }
						if(insertPermButtonSqlUpdate!=null)
						insertPermButtonSqlUpdate.flush();
		      if (insCount > 0) {
		        _LOGGER.info( "Insert Button Permissions Response logged successfully \n Number of Records inserted - " + insCount);
		        status = true;
		      }
			  }

		    }
		    catch (Exception vamEx) {
		      vamEx.printStackTrace();
		      _LOGGER.debug("insertPermButton in VAM Failed \n" +vamEx.getMessage());
		      _LOGGER.error("insertPermButton in VAM Failed \n" +vamEx.getMessage());
		      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
		    }
		    _LOGGER.info("Exiting insertPermButton" + responseMap.toString());
		    responseMap.put("status", new Boolean(status));
		    return responseMap;
		  }

		public List selectAllButtonExclusions() throws NCASException {
			 return selectAllButtonExclusions.getAllButtonExclusions(new Object[]{});
		}
		class SelectAllButtonExclusions extends JdbcDaoSupport {
		    private String sql;

			public SelectAllButtonExclusions(String sql) {
		        this.sql = sql;
		    }

			public List getAllButtonExclusions(Object[] params) {
				 _LOGGER.info("getAllButtonExclusions :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List exclBtnKeyList = new ArrayList();
					          while (rs.next()) {
							      int btnKey = rs.getInt("PORTALEX_KEY");
							      exclBtnKeyList.add(new Integer(btnKey));
					          }
						      return exclBtnKeyList;
				        }});
			    }
		}
		public Map insertExclButton(Button button) throws NCASException {

			boolean status = false;

		    Map responseMap = new HashMap();
		    String INSERT_EXCL_BTN = "INSERT INTO " + getSchemaName() + ".PL_BTNPORTALEXL(PORTALEX_KEY,BTN_KEY,PORTAL, LAST_UPDATED,LAST_UPDATED_BY) VALUES(?,?,?,?,?)";
		    _LOGGER.info("Insert SQL: " + INSERT_EXCL_BTN);

		    try {
		    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

		    	if (insertExclButtonSqlUpdate == null) {
		    	  insertExclButtonSqlUpdate = new BatchSqlUpdate(getDataSource(),INSERT_EXCL_BTN);
		    	  insertExclButtonSqlUpdate.declareParameter(new SqlParameter("PORTALEX_KEY", Types.INTEGER));
		    	  insertExclButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
		    	  insertExclButtonSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
		    	  insertExclButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
		    	  insertExclButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
		      }

			  int btnKey = button.getBtnKey();
			  String lastUpdatedBy = button.getLastUpdatedBy();
			  int count = button.getMisc().size();
			  _LOGGER.info("count: " + count);
			  Map portalMap = button.getPortalIndsForExcl();
			  _LOGGER.info("portalMap: " + portalMap);
			  for(int x = 0; x < count; x++){
			      List portalList = (List) portalMap.get("efp_"+x);

		      _LOGGER.debug("The size of the Exclusion list is :"+portalList.size());
			  int insCount = 0;
			  int exclKey = 0;
					    for(int i =0;i<portalList.size();i++) {
							if(exclKey==0)
							{
					      		exclKey = getGeneratedKey(selectAllButtonExclusions());
							}else{
								exclKey++;
							}
						 _LOGGER.debug("The new generated key for the PL_BTNPORTALEXL table is :"+exclKey);
					      _LOGGER.debug("The portal name that is getting excluded for the btnKey:"+btnKey+" is:"+(String)portalList.get(i));
				    	insCount += insertExclButtonSqlUpdate.update(new Object[]{new Integer(exclKey),new Integer(btnKey),(String)portalList.get(i),lastUpdated,lastUpdatedBy});
					    }

					    if(insertExclButtonSqlUpdate!=null)
					     insertExclButtonSqlUpdate.flush();

		      if (insCount > 0) {
		        _LOGGER.info( "Insert EXCL BTN  Response logged successfully \n Number of Records inserted - " + insCount);
		        status = true;
		      }
		    }
		    }
		    catch (Exception vamEx) {
		      vamEx.printStackTrace();
		      _LOGGER.debug("insertExclButton in VAM Failed \n" +vamEx.getMessage());
		      _LOGGER.error("insertExclButton in VAM Failed \n" +vamEx.getMessage());
		      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
		    }
		    _LOGGER.info("Exiting insertExclButton" + responseMap.toString());
		    responseMap.put("status", new Boolean(status));
		    return responseMap;
		  }

		public Map updateButton(Button button) throws NCASException {
			boolean status = false;
		    Map responseMap = new HashMap();
		    int pageId = Integer.parseInt(button.getPageId());
		    Map curBtns = selectBtnsForPage(pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()));
		    String UPDATE_PL_BTN = "UPDATE " + getSchemaName() +".PL_BTN SET BTN_ORDER = ?,MISC = ?, LAST_UPDATED = ?,LAST_UPDATED_BY =? WHERE PAGE_ID = ? AND PAGE_ATTR = ? AND CONTENT_ID = ? AND BTN_KEY = ?";
		    _LOGGER.info("Update SQL: " + UPDATE_PL_BTN);

		    try {
		    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

		    	if (updateButtonSqlUpdate == null) {
		    		updateButtonSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_PL_BTN);
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("BTN_ORDER", Types.INTEGER));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("MISC", Types.VARCHAR));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED", Types.TIMESTAMP));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.CHAR));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("PAGE_ATTR", Types.VARCHAR));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("CONTENT_ID", Types.INTEGER));
					  updateButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));

}
		    	List miscList = button.getMisc();
		    	String miscStr = (String) miscList.get(0);
		    	 _LOGGER.info("miscStr : --> " + miscStr);
		    	Map orders = button.getBtnOrders();
		    	int btnOrder = 0;
	    		String orderStr = (String) orders.get("order");
	    		btnOrder = Integer.parseInt(orderStr);
	    		_LOGGER.info("btnOrder  : --> " + btnOrder);
	    		Map orderMap = selectBtnOrders(pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()));
	    		_LOGGER.info("orderMap : --> " + orderMap);
	    		boolean btnOrderTaken = orderMap.containsValue(new Integer(btnOrder));
	    		if(btnOrderTaken){
	    			//this condition is to determine whether the taken 'button order' has not changed its
	    			//position
		    		int tempBtnOrder = ((Integer)orderMap.get(new Integer(button.getBtnKey()))).intValue();
		    		_LOGGER.info("tempBtnOrder inside true : --> " + tempBtnOrder);
		    		btnOrderTaken = tempBtnOrder == btnOrder ? false : true;
		    		_LOGGER.info("btnOrderTaken inside true : --> " + btnOrderTaken);
	    		}
	    		_LOGGER.info("btnOrderTaken : --> " + btnOrderTaken);
	    		int insCount = 0;
	    		if(!btnOrderTaken){
	    			_LOGGER.info("btnOrderTaken : --> NOT TAKEN");
	    			Object[] parameterValues = new Object[] {new Integer(btnOrder), miscStr, lastUpdated,button.getLastUpdatedBy(), new Integer(Integer.parseInt(button.getPageId())), button.getPageAttr(), new Integer(Integer.parseInt(button.getContentId())), new Integer(button.getBtnKey())};
	    			insCount = updateButtonSqlUpdate.update(parameterValues);
	    		}else{
	    			_LOGGER.info("btnOrderTaken : --> TAKEN");
	    			adjustUpdtBtnOrders(button, pageId, btnOrder);
	    		}


			      if (insCount > 0) {
			        _LOGGER.info( "Update Portal Links  Response logged successfully \n Number of Records inserted - " + insCount);
			        status = true;
			      }

					List portalList = (List)button.getPortalIndsForExcl().get("efp_0");
					if(portalList!= null && portalList.size()>0)
					{
						status = false;
						_LOGGER.info("First, delete all the exclusions for this button.");
						deleteExclButton(button.getBtnKey());
						_LOGGER.info("Now insert all the latest exclusions for this button.");
						insertExclButton(button);
						status = true;
					}
					else if(portalList!= null && portalList.size() == 0)
					{
						//This button has no exclusions.
					status = false;
					deleteExclButton(button.getBtnKey());
					status = true;
					}
					List permList = (List)button.getPermBtnNames().get("permissions_0");
					if(permList!= null && permList.size()>0)
					{
						status = false;
						_LOGGER.info("First, delete all the permissions for this button.");
						deletePermButton(button.getBtnKey());
						_LOGGER.info("Now insert all the latest permissions for this button.");
						insertPermButton(button);
						status = true;
					}else if(permList!= null && permList.size() == 0)
					{
						//This button has no permission constraints
						status = false;
						_LOGGER.info("First, delete all the permission constraints for this button.");
						deletePermButton(button.getBtnKey());
						status = true;
					}

		    }
		    catch (Exception vamEx) {
		      vamEx.printStackTrace();
		      _LOGGER.debug("updateButton in VAM Failed \n" +vamEx.getMessage());
		      _LOGGER.error("updateButton in VAM Failed \n" +vamEx.getMessage());
		      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);
		    }
		    _LOGGER.info("Exiting updateButton" + responseMap.toString());
		    responseMap.put("status", new Boolean(status));
		    return responseMap;
		}

		public int adjustUpdtBtnOrders(Button button, int pageId, int btnOrder) throws NCASException{
			Map btnOrderMap = selectBtnOrders(pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()));
			_LOGGER.info("adjustUpdtBtnOrders: The PAGE ID is: " + pageId);
			_LOGGER.info("adjustUpdtBtnOrders: The btnOrder is: " + btnOrder);
			int btnKey = button.getBtnKey();
			boolean btnOrderTaken = btnOrderMap.containsValue(new Integer(btnOrder));
			_LOGGER.info("adjustUpdtBtnOrders: The BOOL of btnOrderTaken is: " + btnOrderTaken);
			boolean btnExists = btnOrderMap.containsKey(new Integer(btnKey));//button will be new, so always insert
			int sameorder = 0;

			if(btnOrder==-1){
				List orderList = selectBtnOrderForBtn(pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()), btnKey);
				sameorder = ((Integer)orderList.get(0)).intValue();
				return sameorder;
			}
			if(!btnOrderTaken){
				//The btn order is not taken. So the btn that is being introduced is going to be the last btn if there
				//are already btns existing or it will be the first, if none exists.
				return btnOrder;
			}
			else{
				//The btn order is taken. All the current btns that are equal or greater to the user choice of the
				//btn order should be increased by one if this btn is moving down.All the current btns which have their
				//current btn order inbetween or equal to the chosen btn order, should be increased by one and the others
				//remain the same.
			    Iterator it = btnOrderMap.entrySet().iterator();
			    _LOGGER.info("The SIZE of btnOrderMap is:"+btnOrderMap.size());
			    Map latestBtnOrders = new HashMap();
				if(btnExists){
					 int updatingBtnOrder = ((Integer)btnOrderMap.get(new Integer(btnKey))).intValue();
					 _LOGGER.info("The updatingBtnOrder is:"+updatingBtnOrder);
					_LOGGER.info("The btn already exists. So this must be an update and not an insert");
						while (it.hasNext()){
							Map.Entry pairs = (Map.Entry)it.next();
							int curBtnKey = ((Integer)(pairs.getKey())).intValue();
							int curBtnOrder = ((Integer)pairs.getValue()).intValue();
							_LOGGER.info("Current btn ->"+curBtnKey+"Current btn order-> "+curBtnOrder);
							if(btnKey==curBtnKey){
								_LOGGER.info("This is the btn that is being modified->"+curBtnKey+" The new btn order is " +btnOrder);
								latestBtnOrders.put(new Integer(curBtnKey), new Integer(btnOrder));
							}
							else if(updatingBtnOrder>btnOrder){
								//This means the btn is moving up in the order.
								//All the btns which have the btnorder equal or greater than selected btnorder
								//and less than the old btnorder are to be increased by 1.

									if(curBtnOrder == btnOrder || curBtnOrder>btnOrder && curBtnOrder<updatingBtnOrder){
										int latestBtnOrder = curBtnOrder+1;
										_LOGGER.info("The Latest btn order for the btn "+ curBtnKey+" is "+latestBtnOrder);
										latestBtnOrders.put(new Integer(curBtnKey), new Integer(latestBtnOrder));
									}
									else{
										_LOGGER.info("The LATEST btn order for the btn "+ curBtnKey+" is "+curBtnOrder);
										latestBtnOrders.put(new Integer(curBtnKey), new Integer(curBtnOrder));
									}
							}
							else if(updatingBtnOrder<btnOrder)
							{
								//This means the btn is moving down in the order.
								//All the btns which have the btnorder equal or greater than selected btnorder
								//and less than the old btnorder are to be increased by 1.

									if(curBtnOrder == btnOrder || curBtnOrder<btnOrder && curBtnOrder>updatingBtnOrder)
									{
										int latestBtnOrder = curBtnOrder-1;
										_LOGGER.info("The Latest btn order for the btn "+ curBtnKey+" is "+latestBtnOrder);
										latestBtnOrders.put(new Integer(curBtnKey), new Integer(latestBtnOrder));
									}
									else{
										_LOGGER.info("The LATEST btn order for the btn "+ curBtnKey+" is "+curBtnOrder);
										latestBtnOrders.put(new Integer(curBtnKey), new Integer(curBtnOrder));
									}
							}
							else{
										_LOGGER.info("The LATEST btn order for the btn "+ curBtnKey+" is "+curBtnOrder);
										latestBtnOrders.put(new Integer(curBtnKey), new Integer(curBtnOrder));
							}
					    }
					    updateBtnOrder(latestBtnOrders, pageId, button.getPageAttr(), Integer.parseInt(button.getContentId()), button.getLastUpdatedBy());

				}


			}
			  return sameorder;
		}

		public Map deleteExclButton(int btnKey) throws NCASException {
			 boolean status = false;
			 Map responseMap = new HashMap();
			 String DELETE_EXCL_BTN = "DELETE FROM " + getSchemaName() +".PL_BTNPORTALEXL WHERE BTN_KEY = ?";

			 _LOGGER.info("Delete SQL: " + DELETE_EXCL_BTN);
			    try {
			      if (deleteExclButtonSqlUpdate == null) {
			    	  deleteExclButtonSqlUpdate = new SqlUpdate(getDataSource(),DELETE_EXCL_BTN);
			    	  deleteExclButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
			    	  //deleteExclButtonSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
			    	  deleteExclButtonSqlUpdate.compile();
			      }
			      Object[] parameterValues = new Object[] {new Integer(btnKey)};
			      int deleteCount = deleteExclButtonSqlUpdate.update(parameterValues);
			        _LOGGER.info("Delete EXCL BTNS logged successfully \n Number of Records deleted - " + deleteCount);

			      status = true;
			    }
			    catch (Exception vamEx) {
			      vamEx.printStackTrace();
			      _LOGGER.debug("deleteExclButton in VAM Failed \n" +vamEx.getMessage());
			      _LOGGER.error("deleteExclButton in VAM Failed \n" +vamEx.getMessage());
			      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

			    }
			    _LOGGER.info("Exiting deleteExclButton");
			    responseMap.put("status", new Boolean(status));
			    return responseMap;
		}

		public Map deletePermButton(int btnKey) throws NCASException {
			 boolean status = false;
			 Map responseMap = new HashMap();
			 String DELETE_PERM_BTN = "DELETE FROM " + getSchemaName() +".PL_BTNPERMINCL WHERE BTN_KEY = ?";

			 _LOGGER.info("Delete SQL: " + DELETE_PERM_BTN);
			    try {
			      if (deletePermButtonSqlUpdate == null) {
			    	  deletePermButtonSqlUpdate = new SqlUpdate(getDataSource(),DELETE_PERM_BTN);
			    	  deletePermButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
			    	  deletePermButtonSqlUpdate.compile();
			      }
			      Object[] parameterValues = new Object[] {new Integer(btnKey)};
			      int deleteCount = deletePermButtonSqlUpdate.update(parameterValues);
			        _LOGGER.info("Delete PERM BTNS logged successfully \n Number of Records deleted - " + deleteCount);

			      status = true;
			    }
			    catch (Exception vamEx) {
			      vamEx.printStackTrace();
			      _LOGGER.debug("deletePermButton in VAM Failed \n" +vamEx.getMessage());
			      _LOGGER.error("deletePermButton in VAM Failed \n" +vamEx.getMessage());
			      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

			    }
			    _LOGGER.info("Exiting deletePermButton");
			    responseMap.put("status", new Boolean(status));
			    return responseMap;
		}

		public Map deleteButton(int pageId, int btnKey) throws NCASException {
			 boolean status = false;
			 Map responseMap = new HashMap();
			 String DELETE_EXT_BTN = "DELETE FROM " + getSchemaName() +".PL_BTN WHERE PAGE_ID = ? AND BTN_KEY = ?";

			 _LOGGER.info("Delete SQL: " + DELETE_EXT_BTN);
			 _LOGGER.info("The btn key that is getting deleted:"+btnKey);
			    try {
					_LOGGER.info("Delete the foreign key references first");

					Map firstMap = deletePermButton(btnKey);
					Map secondMap   = deleteExclButton(btnKey);
					boolean firstBool = ((Boolean)firstMap.get("status")).booleanValue();
					boolean secondBool = ((Boolean)secondMap.get("status")).booleanValue();

					if(firstBool && secondBool)
					{
						_LOGGER.debug("The references of the BTN have been deleted successfully");
					  if (deleteButtonSqlUpdate == null) {
						  deleteButtonSqlUpdate = new SqlUpdate(getDataSource(),DELETE_EXT_BTN);
						  deleteButtonSqlUpdate.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
						  deleteButtonSqlUpdate.declareParameter(new SqlParameter("BTN_KEY", Types.INTEGER));
						  deleteButtonSqlUpdate.compile();
					  }
					  Object[] parameterValues = new Object[] {new Integer(pageId), new Integer(btnKey)};
					  int deleteCount = deleteButtonSqlUpdate.update(parameterValues);
					  if (deleteCount > 0) {
						_LOGGER.info("Delete PORTAL BTNS logged successfully \n Number of Records deleted - " + deleteCount);
						status = true;
					  }
			  		}else{
						_LOGGER.debug("The references of the BTN couldn't be deleted. Throwing exception to trigger a rollback");
						throw new Exception("References couldn't be deleted");
					}
			    }
			    catch (Exception vamEx) {
			      vamEx.printStackTrace();
			      _LOGGER.debug("deleteButton in VAM Failed \n" +vamEx.getMessage());
			      _LOGGER.error("deleteButton in VAM Failed \n" +vamEx.getMessage());
			      throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, vamEx);

			    }
			    _LOGGER.info("Exiting deleteButton");
			    responseMap.put("status", new Boolean(status));
			    return responseMap;
		}


		public Map getButtonDetails(int pageId, String pageAttr, int contentId) throws NCASException{
			_LOGGER.info("The pageId is :"+pageId);
			Map btnInfo = null;
			Map btnOrder = null;
			Map responseMap = new HashMap();
			try{
				btnInfo = selectButtonInfo(pageId, pageAttr, contentId);
				btnOrder = selectBtnOrders(pageId, pageAttr, contentId);
				} catch(Exception vamEx) {
					_LOGGER.debug("getButtonDetails in VAM Failed \n"+vamEx.getMessage());
					_LOGGER.error("getButtonDetails in VAM Failed \n"+vamEx.getMessage());
					throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
				}
				_LOGGER.info("Exiting getButtonDetails");
			responseMap.put("btnInfo",btnInfo);
			responseMap.put("btnOrder",btnOrder);
			return responseMap;
		}

		public Map getButtonDetailedInfo(int pageId, String pageAttr, int contentId, int btnKey) throws NCASException{
			_LOGGER.info("The btnKey is :"+btnKey);
			Map responseMap = new HashMap();
			int order = 0;
			String misc = null;
			List orderList = null;
			List permissions = null;
			List exclusions = null;
			List miscList = null;
			try{
				orderList = selectBtnOrderForBtn(pageId, pageAttr, contentId, btnKey);
				order = ((Integer)orderList.get(0)).intValue();
				//TODO add MISC to the detailed info
				miscList = selectMiscForBtn(pageId, pageAttr, contentId, btnKey);
				misc = (String)miscList.get(0);
				permissions = selectButtonPermissions(btnKey);
				exclusions = selectButtonExclusions(btnKey);
			} catch(Exception vamEx) {
				_LOGGER.debug("getButtonDetailedInfo in VAM Failed \n"+vamEx.getMessage());
				_LOGGER.error("getButtonDetails in VAM Failed \n"+vamEx.getMessage());
				throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,PortalLinkDAOImpl.class,vamEx);
			}
			_LOGGER.info("Exiting getButtonDetailedInfo");
			responseMap.put("order",new Integer(order));
			responseMap.put("misc", misc);
			responseMap.put("permissions",permissions);
			responseMap.put("exclusions",exclusions);
			return responseMap;
		}


		public Map selectButtonInfo(int pageId, String pageAttr, int contentId) throws NCASException {
			 return selectButtonInfo.getButtonInfo(new Object[]{new Integer(pageId), pageAttr, new Integer(contentId)});
		}

		class SelectButtonInfo extends JdbcDaoSupport {
		    private String sql;

			public SelectButtonInfo(String sql) {
		        this.sql = sql;
		    }

			public Map getButtonInfo(Object[] params) {
				 _LOGGER.info("getButtonInfo :: " + params);
			        return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  Map btnMap = new HashMap();
					          while (rs.next()) {
								  int btnKey = rs.getInt("BTN_KEY");
								  String name = rs.getString("NAME");
							      btnMap.put(new Integer(btnKey),name);
					          }
						      return btnMap;
				        }});
			    }
		}


		public List selectBtnOrderForBtn(int pageId, String pageAttr, int contentId, int btnKey) throws NCASException {
			 return selectBtnOrderForBtn.getBtnOrderForBtn(new Object[]{new Integer(pageId), pageAttr, new Integer(contentId), new Integer(btnKey)});
		}
		class SelectBtnOrderForBtn extends JdbcDaoSupport {
		    private String sql;

			public SelectBtnOrderForBtn(String sql) {
		        this.sql = sql;
		    }

			public List getBtnOrderForBtn(Object[] params) {
				 _LOGGER.info("getBtnOrderForBtn :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List btnOrderForBtn = new ArrayList();
					          while (rs.next()) {
								  int order = rs.getInt("BTN_ORDER");
								  btnOrderForBtn.add(order);
					          }
						      return btnOrderForBtn;
				        }});
			    }
		}
		public List selectMiscForBtn(int pageId, String pageAttr, int contentId, int btnKey) throws NCASException {
			 return selectMiscForBtn.getMiscForBtn(new Object[]{new Integer(pageId), pageAttr, new Integer(contentId), new Integer(btnKey)});
		}
		class SelectMiscForBtn extends JdbcDaoSupport {
		    private String sql;

			public SelectMiscForBtn(String sql) {
		        this.sql = sql;
		    }

			public List getMiscForBtn(Object[] params) {
				 _LOGGER.info("getMiscForBtn :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List miscForBtn = new ArrayList();
					          while (rs.next()) {
								  String misc = rs.getString("MISC");
								  miscForBtn.add(misc);
					          }
						      return miscForBtn;
				        }});
			    }
		}

		public List selectButtonExclusions(int btnKey) throws NCASException {
			 return selectButtonExclusions.getButtonExclusions(new Object[]{new Integer(btnKey)});
		}
		class SelectButtonExclusions extends JdbcDaoSupport {
		    private String sql;

			public SelectButtonExclusions(String sql) {
		        this.sql = sql;
		    }

			public List getButtonExclusions(Object[] params) {
				 _LOGGER.info("getButtonExclusions :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List btnExclList = new ArrayList();
					          while (rs.next()) {
							      String portalName = rs.getString("PORTAL");
							      btnExclList.add(portalName);
					          }
						      return btnExclList;
				        }});
			    }
		}


		public List selectButtonPermissions(int btnKey) throws NCASException {
			 return selectButtonPermissions.getButtonPermissions(new Object[]{new Integer(btnKey)});
		}
		class SelectButtonPermissions extends JdbcDaoSupport {
		    private String sql;

			public SelectButtonPermissions(String sql) {
		        this.sql = sql;
		    }

			public List getButtonPermissions(Object[] params) {
				 _LOGGER.info("getButtonPermissions :: " + params);
			        return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				   		 _LOGGER.info("In extractData :: " );

				   		 	  List btnPermList = new ArrayList();
					          while (rs.next()) {
							      String permName = rs.getString("NAME");
							      btnPermList.add(permName);
					          }
						      return btnPermList;
				        }});
			    }
		}
		public Map processButton(String operation,int pageId, String pageAttr, int contentId, int btnKey, Button button)  throws NCASException{
			Map responseMap = null;
			  try{
				  if(operation.equalsIgnoreCase("I"))
					  responseMap = insertButton(button);
				  else if(operation.equalsIgnoreCase("U"))
					  responseMap = updateButton(button);
				  else if(operation.equalsIgnoreCase("D"))
					  responseMap = deleteButton(pageId, btnKey);
				  else if(operation.equalsIgnoreCase("BO"))
					  responseMap = selectBtnOrders(pageId, pageAttr, contentId);
				  else if(operation.equalsIgnoreCase("BDD"))
					  responseMap = getButtonDropdowns();
				  else if(operation.equalsIgnoreCase("BD"))
					  responseMap = getButtonDetails(pageId, pageAttr, contentId);
				  else if(operation.equalsIgnoreCase("BDI"))
					  responseMap = getButtonDetailedInfo(pageId, pageAttr, contentId, btnKey);
				  else {
					  List pageAttrList = selectPageAttr(pageId);
					  responseMap = new HashMap();
					  responseMap.put("pageAttr", pageAttrList);
				  }
			  }catch(Exception e){
				e.printStackTrace();
			    _LOGGER.error("processButton in NCASBOSI Failed \n" +e.getMessage());
			    throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950, PortalLinkDAOImpl.class, e);
			}
			return responseMap;
		}

		public Map getPageDisplay(Map inputMap) throws NCASException {
			String METHOD_NAME = "getPageDisplay():: ";
			String tmpType = "";
			String topBotQ = "N";
			int i;
			Map retMap = new HashMap();

			// this is used for name spacing linkhandler
			String appName = (String) inputMap.get("appName");
			GLOBAL_APP_NAME = appName;

			// this is used to suppress the BOT query
			String topBot = (String) inputMap.get("topBot");
			if (topBot != null) {
				topBotQ = topBot;
			}
			//portal Indicator
			String portalInd = (String) inputMap.get("portalInd");
			String userType = (String) inputMap.get("userType");
			// Portal defined Page Number
			String portalPageId = (String) inputMap.get("portalPageId");
			String lang = (String) inputMap.get("lang");
			List permissions = (List) inputMap.get("perms");

			Object[] params = new Object[MAX_PERMS+3];
			//perms
			Iterator it = permissions.iterator();
			for( i = 0;i<MAX_PERMS;i++){
				if(it.hasNext()) {
					params[i] = new String(String.valueOf(it.next()));
			  } else {
			  	params[i] = "";
			  }
			}
			//set usertype
			if (userType.equalsIgnoreCase("VZW") || userType.equalsIgnoreCase("VZB") || userType.equalsIgnoreCase("ALL")) {
				if (userType.equalsIgnoreCase("VZB")) {
					tmpType = "ALL";
				} else {
					tmpType = userType;
				}
			}

			params[i] = new Integer(portalPageId); i++;
			params[i] = new String(tmpType); i++;
			params[i] = new String(portalInd);

			if (_LOGGER.isDebugEnabled()) {
				_LOGGER.debug(METHOD_NAME + "inputMap=" + inputMap.toString());
			    _LOGGER.debug(METHOD_NAME + "Select TOP SQL=" + SELECT_SECTIONS);
			}
			retMap.put("TOP", selectByPage.getCustomPage(params,lang));
			// run the BOT sql only if we call for it
			if (topBotQ.equalsIgnoreCase("Y")) {
			  if (_LOGGER.isDebugEnabled()) {
				_LOGGER.debug(METHOD_NAME + "Select BOT SQL=" + SELECT_SECT);
			  }
			  retMap.put("BOT", selectHeaderText.getHeader(params,lang));
			}
			return retMap;
		}

		public Map getCustomDisplay(Map inputMap) throws NCASException {
			String portalInd = (String) inputMap.get("portalInd");
			List permissions = (List) inputMap.get("perms");
			return selectDashBoard("P",portalInd,permissions);
		}
}
