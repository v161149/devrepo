package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.Interface.billinquiry.BillInquiryMigrationinterface;
import com.verizon.enterprise.common.ncasbosi.beans.DfrgAttachment;
import javax.sql.DataSource;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import org.springframework.jdbc.object.MappingSqlQuery;

import org.apache.log4j.Level;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import java.util.ArrayList;
import com.verizon.enterprise.common.ncas.fileupload.FileUploadDO;
import com.verizon.kernel.ejb.EJBHomeFactory; //EJB - send file to database imports

public class BillInquiryMigrationDAOImpl extends JdbcDaoSupport implements
        BillInquiryMigrationinterface, NCASBOSIConstants
{
    private static final org.apache.log4j.Logger _LOGGER = org.apache.log4j.Logger
            .getLogger(BillInquiryMigrationDAOImpl.class);

    private SelectFormDefinition selectFormDefinition;

    private SelectFieldMap selectFieldMap;

    private SelectContentFolderOid selectContentFolderOid;

    private SelectContentFolder selectContentFolder;

    private SelectContentBase selectContentBase;

    private SelectContent selectContent;

    private SelectContentItem selectContentItem;

    private SelectBillInquiry selectBillInquiry;

    private SelectCountContentFolder selectCountContentFolder;

    private SelectSubscriptionOsid selectSubscriptionOsid;

    String SELECT_FORM_DEF_DFRG = "SELECT FORM_DEF_OID FROM DFRG.FORM_DEF WHERE CATEGORY='BILLINQ'";

    String SELECT_CONTENT_FOLDER_VZCMS = "SELECT CONTENT_FOLDER_OID FROM VZCMS.CONTENT_FOLDER WHERE CONTENT_FOLDER_NAME ='dfrg' "
            + " AND PARENT_FOLDER_OID = '0'";

    abstract class AbstractSelect extends MappingSqlQuery
    {
        public AbstractSelect(DataSource dataSource, String sql)
        {
            super(dataSource, sql);
        }
    }

    class SelectFormDefinition extends AbstractSelect
    {
        public SelectFormDefinition(DataSource dataSource)
        {
            super(dataSource, SELECT_FORM_DEF_DFRG);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            _LOGGER.info("FormDefinition Query:::" + SELECT_FORM_DEF_DFRG);
            String formDefOid = rs.getString("FORM_DEF_OID");
            return formDefOid;
        }
    }

    class SelectFieldMap extends AbstractSelect
    {
        public SelectFieldMap(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String fildDefOid = rs.getString("FIELD_DEF_OID");
            return fildDefOid;
        }
    }

    class SelectContentFolderOid extends AbstractSelect
    {
        public SelectContentFolderOid(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String contentFolderOid = rs.getString("CONTENT_FOLDER_OID");
            return contentFolderOid;
        }
    }

    class SelectCountContentFolder extends AbstractSelect
    {
        public SelectCountContentFolder(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String countContentFolder = rs.getString("COUNT_CONTENTFOLDER");
            return countContentFolder;
        }
    }

    class SelectContentFolder extends AbstractSelect
    {
        public SelectContentFolder(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            List contentBaseList = new ArrayList();
            List billInquiryList = new ArrayList();
            String contentBaseQuery = null;
            String contentBaseOid = null;
            String contentName = null;
            String billInquiryQuery = null;
            String trackingId = null;
            String ban = null;
            String billDate = null;
            DfrgAttachment dfrgAttachment = new DfrgAttachment();
            String contentFolderOid = rs.getString("CONTENT_FOLDER_OID");
            String contentFolderName = rs.getString("CONTENT_FOLDER_NAME");
            String userId = rs.getString("USER_ID");
            billInquiryQuery = getBillInquiry(contentFolderName);
            selectBillInquiry = new SelectBillInquiry(getDataSource(),
                    billInquiryQuery);
            billInquiryList = selectBillInquiry.execute(new Object[] {});
            // Check the content_folder_name exists in bill_inquiry table.
            if (!billInquiryList.isEmpty() )
            {
                dfrgAttachment = (DfrgAttachment) billInquiryList.get(0);
                dfrgAttachment.setTrackingId(dfrgAttachment.getTrackingId());
                dfrgAttachment.setBan(dfrgAttachment.getBan());
                dfrgAttachment.setBillDate(dfrgAttachment.getBillDate());
                //dfrgAttachment.setContentFolderOid(contentFolderOid);
                dfrgAttachment.setContentFolderName(contentFolderName);
                dfrgAttachment.setUserId(userId);
                dfrgAttachment.setOsID(dfrgAttachment.getOsID());
                dfrgAttachment.setMan(dfrgAttachment.getMan());
                contentBaseQuery = getContentBase(contentFolderOid);
                /*
                 * It is used to get the Filename,Filecontent for the particular
                 * dfrg attachement It may returns more than one row.so we have
                 * to keep into List
                 */
                selectContentBase = new SelectContentBase(getDataSource(),
                        contentBaseQuery);
                contentBaseList = selectContentBase.execute(new Object[] {});
                dfrgAttachment.setContentBaseList(contentBaseList);
            }
            return dfrgAttachment;
        }
    }

    class SelectContentBase extends AbstractSelect
    {
        public SelectContentBase(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            List contentList = new ArrayList();
            List contentItemList = new ArrayList();
            String contentOid = null;
            String contentQuery = null;
            String contentItemOid = null;
            byte[] content = null;
            String contentItemQuery = null;
            String contentBaseOid = rs.getString("CONTENT_BASE_OID");
            String contentFolderOid = rs.getString("CONTENT_FOLDER_OID");
            String contentName = rs.getString("CONTENT_NAME");
            DfrgAttachment dfrgAttachment = new DfrgAttachment();
            //dfrgAttachment.setContentBaseOid(contentBaseOid);
            //dfrgAttachment.setContentFolderOid(contentFolderOid);
            contentQuery = getContent(contentBaseOid);
            selectContent = new SelectContent(getDataSource(), contentQuery);
            contentList = selectContent.execute(new Object[] {});
            contentOid = (String) contentList.get(0);
            contentItemQuery = getContentItem(contentOid);
            selectContentItem = new SelectContentItem(getDataSource(),
                    contentItemQuery);
            contentItemList = selectContentItem.execute(new Object[] {});
            if (!contentItemList.isEmpty())
            {
                dfrgAttachment = (DfrgAttachment) contentItemList.get(0);
                contentItemOid = dfrgAttachment.getContentItemOid();
                content = dfrgAttachment.getContent();
                dfrgAttachment.setContent(content);
                //dfrgAttachment.setContentItemOid(contentItemOid);
                dfrgAttachment.setContentName(contentName);
            }
            return dfrgAttachment;
        }
    }

    class SelectContent extends AbstractSelect
    {
        public SelectContent(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String contentOid = rs.getString("CONTENT_OID");
            return contentOid;
        }
    }

    class SelectContentItem extends AbstractSelect
    {
        public SelectContentItem(DataSource dataSource, String mySql)
        {
            super(dataSource, mySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String contentItemOid = rs.getString("CONTENT_ITEM_OID");
            byte[] content = rs.getBytes("CONTENT");
            DfrgAttachment dfrgAttachment = new DfrgAttachment();
            //dfrgAttachment.setContentItemOid(contentItemOid);
            dfrgAttachment.setContent(content);
            return dfrgAttachment;
        }
    }

    class SelectBillInquiry extends AbstractSelect
    {
        public SelectBillInquiry(DataSource dataSource, String billInquirySql)
        {
            super(dataSource, billInquirySql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String osIDQuery = null;
            List osIDList = new ArrayList();
            String osID = null;
            DfrgAttachment dfrgAttachment = new DfrgAttachment();
            String trackingId = rs.getString("TRACKING_ID");
            String ban = rs.getString("BAN");
            String billDate = rs.getString("BILL_DATE");
            String customerAccountnum = rs.getString("CUSTOMER_ACCT_NUM");
            String san=rs.getString("SAN");
            dfrgAttachment.setTrackingId(trackingId);
            dfrgAttachment.setBan(ban);
            dfrgAttachment.setBillDate(billDate);
            dfrgAttachment.setMan(customerAccountnum);
            _LOGGER.info("customerAccountnum"+customerAccountnum);
            if( customerAccountnum != null &&  !customerAccountnum.trim().equals("") ){
            	
            osIDQuery = getOsID(customerAccountnum);
            	
            	
            selectSubscriptionOsid = new SelectSubscriptionOsid(
                    getDataSource(), osIDQuery);
            osIDList = selectSubscriptionOsid.execute(new Object[] {});
            }
            else if(ban !=null && !ban.trim().equals("")){
            	osIDQuery = getOsID(ban);
        		selectSubscriptionOsid = new SelectSubscriptionOsid(
                        getDataSource(), osIDQuery);
                osIDList = selectSubscriptionOsid.execute(new Object[] {});
        	}
            else{
            	osIDQuery = getOsID(san);
        		selectSubscriptionOsid = new SelectSubscriptionOsid(
                        getDataSource(), osIDQuery);
                osIDList = selectSubscriptionOsid.execute(new Object[] {});
            }
            if(!osIDList.isEmpty()){
            osID = (String) osIDList.get(0);
            dfrgAttachment.setOsID(osID);
            }
            return dfrgAttachment;
        }
    }

    class SelectSubscriptionOsid extends AbstractSelect
    {
        public SelectSubscriptionOsid(DataSource dataSource,
                String subscriptionSql)
        {
            super(dataSource, subscriptionSql);
        }

        protected Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            String osID = rs.getString("OSID");
            return osID;
        }
    }

    public Map processBillInquiryMigration(Map params) throws NCASException
    {
        String METHOD_NAME = "processBillInquiryMigration()  ";
        _LOGGER.info("Entering into" + METHOD_NAME);
        List billInquiryFolderList = null;
        List billInquiryLists=null;
        int billInquiryCount;
        List countContentFolderList = null;
        String countCountFolderValue = null;
        int countContentFolderVal;
        Map responseMap = new HashMap();
        // TODO: LMTEST temp api to redirect to processBillInquiryMigration()
        // until it gets to wisegate db
        /*
         * Following code is used to get the FORM_DEF_OID which inturn uses to
         * get the FIELD_DEF_OID
         */
        selectFormDefinition = new SelectFormDefinition(getDataSource());
        List formdefinitionList = selectFormDefinition.execute(new Object[] {});
        String formDefOid = (String) formdefinitionList.get(0);
        _LOGGER.info("FORM_DEF_OID VALUE::::" + formDefOid);
        String formfieldmapSql = getFormFieldMapSQL(formDefOid);
        _LOGGER.info("FormFieldMap Query:::" + formfieldmapSql);
        selectFieldMap = new SelectFieldMap(getDataSource(), formfieldmapSql);
        List formfieldmapList = selectFieldMap.execute(new Object[] {});
        String fieldDefOid = (String) formfieldmapList.get(0);
        _LOGGER.info("FIELD_DEF_OID VALUE::::" + fieldDefOid);
        _LOGGER.info("ContentFolder Query:::" + SELECT_CONTENT_FOLDER_VZCMS);
        selectContentFolderOid = new SelectContentFolderOid(getDataSource(),
                SELECT_CONTENT_FOLDER_VZCMS);
        List rootFolderOidList = selectContentFolderOid
                .execute(new Object[] {});
        String rootFolderOid = (String) rootFolderOidList.get(0);
        _LOGGER.info("RootFolderOid :::" + rootFolderOid);
        // Following code is used to get the DFRG Folder Name.
        String contentFolderStageOneQuery = getContentFolderOid(rootFolderOid,
                "BILLINQ");
        _LOGGER.info("ContentFolderStageone Query:::"
                + contentFolderStageOneQuery);
        selectContentFolderOid = new SelectContentFolderOid(getDataSource(),
                contentFolderStageOneQuery);
        List contentFolderStageoneList = selectContentFolderOid
                .execute(new Object[] {});
        String contentFolderOneValue = (String) contentFolderStageoneList
                .get(0);
        _LOGGER.info("contentFolderOneValue :::" + contentFolderOneValue);
        String contentFolderStageTwoQuery = getContentFolderOid(
                contentFolderOneValue, formDefOid);
        _LOGGER.info("ContentFolderStagetwo Query:::"
                + contentFolderStageTwoQuery);
        selectContentFolderOid = new SelectContentFolderOid(getDataSource(),
                contentFolderStageTwoQuery);
        List contentFolderStagetwoList = selectContentFolderOid
                .execute(new Object[] {});
        String contentFolderTwoValue = (String) contentFolderStagetwoList
                .get(0);
        _LOGGER.info("contentFolderTwoValue :::" + contentFolderOneValue);
        String contentFolderStageThreeQuery = getContentFolderOid(
                contentFolderTwoValue, fieldDefOid);
        _LOGGER.info("contentFolderStageThreeQuery Query:::"
                + contentFolderStageThreeQuery);
        selectContentFolderOid = new SelectContentFolderOid(getDataSource(),
                contentFolderStageThreeQuery);
        List contentFolderStagethreeList = selectContentFolderOid
                .execute(new Object[] {});
        String contentFolderThreeValue = (String) contentFolderStagethreeList
                .get(0);
        _LOGGER.info("contentFolderThreeValue :::" + contentFolderThreeValue);
        // Finding Total Number of records in a content_folder Table
        String countContentFolderSql = getCountContentFolder(contentFolderThreeValue);
        _LOGGER.info("countContentFolderSql Query::" + countContentFolderSql);
        selectCountContentFolder = new SelectCountContentFolder(
                getDataSource(), countContentFolderSql);
        countContentFolderList = selectCountContentFolder
                .execute(new Object[] {});
        countCountFolderValue = (String) countContentFolderList.get(0);
        countContentFolderVal = Integer.valueOf(countCountFolderValue);
        _LOGGER.info("countContentFolderVal:::" + countContentFolderVal);
        // To paginate the query by rowsPerPage
        int start_row, end_row, page, rowsPerPage, totPages;
        String pageKey = null;
        rowsPerPage=10;      
         totPages = Double.valueOf(
                String.valueOf(Math.ceil(countContentFolderVal / 10.0)))
                .intValue();
         
      long dataLength = 0;
      //List list = new ArrayList();
      int type = Integer.parseInt((String) params.get("type"));// if type = 0, then getting the page number, if type = 1, the get actual data
      _LOGGER.info("Type value:::"+type);
      int counter = 0;
      int startIndex = 1;
      int billinquiryListSize,j,k,countContentBaseList;
      List contentBaseList=null;
      if(type == 1){
    	  startIndex = Integer.parseInt((String) params.get("page_start_index"));
    	  //totPages = Integer.parseInt((String) params.get("page_end_index")) + 1;
    	  totPages = Integer.parseInt((String) params.get("page_end_index")) ;
      }
      DfrgAttachment dfrgObject=new DfrgAttachment();
      int si = 1;
      Map resp = new HashMap();
        for (page = startIndex; page <= totPages; page++)
        {
            end_row = page * rowsPerPage;
            start_row = ((page - 1) * rowsPerPage) + 1;
            String contentFolderSql = getContentFolder(contentFolderThreeValue,
                    start_row, end_row);
            //_LOGGER.info("contentFolder Query::" + contentFolderSql);
            selectContentFolder = new SelectContentFolder(getDataSource(),
                    contentFolderSql);
            billInquiryFolderList = selectContentFolder
                    .execute(new Object[] {});
            //pageKey = String.valueOf(page);
           /* _LOGGER.info("Bill Inquiry List Size::"
                    + billInquiryFolderList.size());*/
          
            //responseMap.put(pageKey, billInquiryFolderList);
            if(type == 0){
            	
            	billinquiryListSize=billInquiryFolderList.size();
            	for(j=0;j<billinquiryListSize;j++){
            		dfrgObject=(DfrgAttachment)billInquiryFolderList.get(j);
            		dataLength+=dfrgObject.getLengths();
            		contentBaseList=dfrgObject.getContentBaseList();
            		if(contentBaseList!=null){
            		countContentBaseList=contentBaseList.size();
            	
            		for(k=0;k<countContentBaseList;k++){
            			dfrgObject=(DfrgAttachment) contentBaseList.get(k);
            			dataLength+=dfrgObject.getLengths();
            		}
            		}
            	 
            		
            	}
            	_LOGGER.info("Data Length::"+dataLength);
            	
	            if(dataLength > 10000080 ){
	               	//si = page;
	            	dataLength=0;
	            	page--;
	            	_LOGGER.info("dataLength:::"+dataLength);
	            	responseMap.put(counter, si+"-"+page);
	            	_LOGGER.info("responseMap value:::"+responseMap);
	            	_LOGGER.info("counter value::"+counter);
	            	counter++;
	            	si=page+1;
	            }else{
	            	responseMap.put(counter, si+"-"+page);
	            }
            }else{
            	responseMap.put(page, billInquiryFolderList);
            }
            _LOGGER.info(page+" put into map");
        }
        _LOGGER.info("returning finally ****");
        _LOGGER.info("Data Length value::"+dataLength);
        _LOGGER.info("Map Value:::"+responseMap);
        
        return responseMap;
    }

    public String getFormFieldMapSQL(String formDefOid)
    {
        String formFieldMapSql = null;
        formFieldMapSql = "SELECT FIELD_DEF_OID FROM DFRG.FORM_FIELD_MAP WHERE FORM_DEF_OID='"
                + formDefOid + "'";
        return formFieldMapSql;
    }

    public String getContentFolderOid(String contentFolderOid,
            String contentFolderName)
    {
        String contentFolderOidSql = null;
        contentFolderOidSql = "SELECT CONTENT_FOLDER_OID FROM VZCMS.CONTENT_FOLDER "
                + " WHERE PARENT_FOLDER_OID  ='"
                + contentFolderOid
                + "'"
                + " AND CONTENT_FOLDER_NAME  = '" + contentFolderName + "'";
        return contentFolderOidSql;
    }

    public String getContentFolder(String parentFolderOid, int start, int end)
    {
        String contentFolderSql = null;
        String userId = "V110459";
        /*
         * contentFolderSql = " SELECT CONTENT_FOLDER_OID,CONTENT_FOLDER_NAME
         * FROM VZCMS.CONTENT_FOLDER " + " WHERE PARENT_FOLDER_OID='" +
         * parentFolderOid + "'" +" AND CONTENT_FOLDER_NAME NOT LIKE 'TEMP%' " + "
         * AND ROWNUM <=100 ORDER BY TIMESTAMP DESC ";
         */
        
          contentFolderSql = " SELECT CONTENT_FOLDER_OID,CONTENT_FOLDER_NAME,USER_ID " 
              + " FROM (SELECT CONTENT_FOLDER_OID,CONTENT_FOLDER_NAME,USER_ID, " 
              + " COUNT(*) OVER ()  TOTAL_ROWS," 
              + " ROW_NUMBER() OVER (ORDER BY CONTENT_FOLDER_OID) ROW_COUNTER " 
              + " FROM VZCMS.CONTENT_FOLDER WHERE  PARENT_FOLDER_OID='" 
              + parentFolderOid + "'" 
              + " AND CONTENT_FOLDER_NAME NOT LIKE 'TEMP%' ORDER BY CONTENT_FOLDER_OID)" 
              + " WHERE ROW_COUNTER BETWEEN " + start + " AND " + end;
        
       /*
         * contentFolderSql = " SELECT
         * CONTENT_FOLDER_OID,CONTENT_FOLDER_NAME,USER_ID " + " FROM (SELECT
         * CONTENT_FOLDER_OID,CONTENT_FOLDER_NAME,USER_ID, " + " COUNT(*) OVER ()
         * TOTAL_ROWS," + " ROW_NUMBER() OVER (ORDER BY CONTENT_FOLDER_OID)
         * ROW_COUNTER " + " FROM VZCMS.CONTENT_FOLDER WHERE USER_ID='" + userId +
         * "'" + " AND CONTENT_FOLDER_NAME NOT LIKE 'TEMP%' ORDER BY
         * CONTENT_FOLDER_OID)";
         */
        return contentFolderSql;
    }

    public String getCountContentFolder(String parentFolderOid)
    {
        String countContentFolderSql = null;
        countContentFolderSql = " SELECT COUNT(*) as COUNT_CONTENTFOLDER FROM VZCMS.CONTENT_FOLDER "
                + " WHERE PARENT_FOLDER_OID='"
                + parentFolderOid
                + "'"
                + " AND CONTENT_FOLDER_NAME NOT LIKE 'TEMP%' ";
        return countContentFolderSql;
    }

    public String getContentBase(String contentFolderOid)
    {
        String contentBaseSql = null;
        contentBaseSql = " SELECT CONTENT_BASE_OID,USER_ID,CONTENT_FOLDER_OID,CONTENT_NAME FROM VZCMS.CONTENT_BASE "
                + " WHERE CONTENT_FOLDER_OID='" + contentFolderOid + "'";
        return contentBaseSql;
    }

    public String getContent(String contentBaseOid)
    {
        String contentSql = null;
        contentSql = "SELECT CONTENT_OID FROM VZCMS.CONTENT "
                + " WHERE CONTENT_BASE_OID='" + contentBaseOid + "'";
        return contentSql;
    }

    public String getContentItem(String contentOid)
    {
        String contentItemSql = null;
        contentItemSql = "SELECT CONTENT_ITEM_OID,CONTENT FROM VZCMS.CONTENT_ITEM "
                + " WHERE CONTENT_OID='" + contentOid + "'";
        return contentItemSql;
    }

    public String getBillInquiry(String billInquiryOid)
    {
        String billInquiryOidSql = null;
        billInquiryOidSql = " SELECT TRACKING_ID,BAN,BILL_DATE ,CUSTOMER_ACCT_NUM,SAN FROM ESG.BILL_INQUIRY"
                + " WHERE BILL_INQUIRY_OID='" + billInquiryOid + "'";
        return billInquiryOidSql;
    }

    public String getOsID(String customerAcctNum)
    {
        String osIDSql = null;
        osIDSql = " SELECT OSID FROM ESG.SUBSCRIPTION WHERE CUSTOMER_ACCT_NUM='"
                + customerAcctNum + "'";
        return osIDSql;
    }
}
