package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquirySearch;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiryForm;

public class SPGetDLVerBIs extends BaseStoredProcedure {

  private static final Logger _LOGGER = Logger.getLogger(SPGetDLVerBIs.class);
  private static List spInOutList;

  static {
    _LOGGER.info("Static Init");

    spInOutList = new ArrayList();
    //spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new BISearchDataMapper()});
    spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"BI_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CREATE_DATE_FROM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CREATE_DATE_THOU", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CLOSE_DATE_FROM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CLOSE_DATE_THOU", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"BILL_DATE_FROM", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"BILL_DATE_THOU", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CONTACT_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CONTACT_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CONTACT_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"CUST_WORK_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"BI_REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"INVOICE_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"DISP_AMOUNT_FROM", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"DISP_AMOUNT_TO", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"INQUIRY_MEMO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"SORT_FIELD", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"SORT_DIR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

    spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER), 	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),	 NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR), 	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER), 	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),    NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),	 NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
    spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),	 NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });

    spInOutList.add(new Object[]{"ACCOUNT_ID", getSqlDataType(Types.CHAR),       NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
    spInOutList.add(new Object[]{"FTP_USERID", getSqlDataType(Types.VARCHAR),	 NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"FTP_PASSWORD", getSqlDataType(Types.VARCHAR),	 NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"FTP_HOSTNAME", getSqlDataType(Types.VARCHAR),	 NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"FTP_DIRECTORY", getSqlDataType(Types.VARCHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"FTP_FILENAME", getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
    spInOutList.add(new Object[]{"DATAFORMAT", getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
  }

  public SPGetDLVerBIs(DataSource dataSource) {
    super(dataSource, NCASBOSIConstants.SP_SEARCH_BILL_INQ_DL, spInOutList);
  }

  public Map executeStoredProcedure(Object input)throws Exception {
    _LOGGER.info("Enterring executeStoredProcedure");

    BillInquiryForm billInquiryForm = (BillInquiryForm)input;
    BillInquirySearch myBIS = null;
    Pagination myPag = null;
    List paramValueList = new ArrayList();

    // Check/Process  Input Map
    if ((billInquiryForm != null) && (billInquiryForm instanceof BillInquiryForm)) {
      myBIS = billInquiryForm.getMyBIS();   // get data user entered into screen
      myPag = billInquiryForm.getMyPag();   // get pagination data so know which page to retrieve
    }else{
      throw new Exception("SPGetDLVerBIs: bad input expect BillInquiryForm got:" + billInquiryForm);
    }

    if (myBIS == null) {
      throw new Exception("SPGetDLVerBIs: Search bill inquiry data is null");
    }

    if (myPag == null){
      throw new Exception("SPGetDLVerBIs: Bill inquiry pagination is null");
    }

    //convert date user entered into date db2 can use.
    String formatIn = "MM/dd/yyyy";
    String formatOut = "yyyy-MM-dd";
    String createDateFrom = CommonUtil.formatDate(myBIS.getCreateDateFrom(), formatIn, formatOut);
    String createDateTo = CommonUtil.formatDate(myBIS.getCreateDateTo(), formatIn, formatOut);
    String closeDateFrom = CommonUtil.formatDate(myBIS.getCloseDateFrom(), formatIn, formatOut);
    String closeDateTo = CommonUtil.formatDate(myBIS.getCloseDateTo(), formatIn, formatOut);
    String billDateFrom = CommonUtil.formatDate(myBIS.getBillDateFrom(), formatIn, formatOut);
    String billDateTo = CommonUtil.formatDate(myBIS.getBillDateTo(), formatIn, formatOut);

    String ban = myBIS.getBAN();
    String san = myBIS.getSAN();
    String acctInfo[] = getBan_Man_accountId(ban, san);
    String sendername = myBIS.getSenderName();
    String senderemail = myBIS.getSenderEmail();
    String senderphone = myBIS.getSenderPhone();
    String trackingid = myBIS.getSrcSysBIId();
    String custwo = myBIS.getCustWO();
    String reasoncode = myBIS.getReasonCode();
    String invoicenum = myBIS.getInvoiceNum();
    String inquirymemo = myBIS.getInquiryMemo();

    paramValueList.add(billInquiryForm.getFtpUserid());                                // APP_USER_ID
    paramValueList.add("0");                            // DEBUG_LEVEL
    paramValueList.add(myBIS.getSourcePortal());                                       // VBC_OR_VBCC
    paramValueList.add(new Double(myBIS.getUserOid()));  // USER_OID
    paramValueList.add(new Integer(Integer.parseInt(myBIS.getStatus())));              // BI_STATUS
    paramValueList.add(getV(acctInfo[0]));		 			               // BAN
    paramValueList.add(getV(acctInfo[1]));				 	               // MAN
    paramValueList.add(getV(createDateFrom));                                          // CREATE_DATE_FROM
    paramValueList.add(getV(createDateTo));                                            // CREATE_DATE_THRU
    paramValueList.add(getV(closeDateFrom));                                           // CLOSE_DATE_FROM
    paramValueList.add(getV(closeDateTo));                                             // CLOSE_DATE_THRU
    paramValueList.add(getV(billDateFrom));                                            // BILL_DATE_FROM
    paramValueList.add(getV(billDateTo));                                              // BILL_DATE_THRU
    paramValueList.add(getV(sendername));                                              // CONTACT_NAME
    paramValueList.add(getV(senderemail));       			                // CONTACT_EMAIL
    paramValueList.add(getV(senderphone));	        		                // CONTACT_PHONE
    paramValueList.add(getV(trackingid));		        	                // SRC_SYS_BI_ID
    paramValueList.add(getV(custwo));				                        // CUST_WORK_ORDER
    paramValueList.add(getV(reasoncode));			                        // BI_REASON_CODE
    paramValueList.add(getV(invoicenum));			                        // INVOICE_NUMBER
    paramValueList.add(new Double(Double.parseDouble(myBIS.getDisputeAmountFrom())));   // DISP_AMOUNT_FROM
    paramValueList.add(new Double(Double.parseDouble(myBIS.getDisputeAmountTo())));     // DISP_AMOPUNT_TO
    paramValueList.add(getV(inquirymemo)); 			                         // INQUIRY_MEMO

    //pagination fields
    String sortField = myPag.getSortField();
    paramValueList.add(getV(sortField));		 	                         // SORT_FIELD
    String sortDir = myPag.getSortDirection();
    if(sortDir != null) {
      if(sortDir.equalsIgnoreCase("A") ||sortDir.equalsIgnoreCase("D")) {
        paramValueList.add(getV(sortDir));		 	                                 // SORT_DIR
      } else {
        paramValueList.add("");
      }
    } else {
      paramValueList.add("");
    }

    paramValueList.add(getV(acctInfo[2]));	 	                                          // ACCOUNT_ID
    paramValueList.add(billInquiryForm.getFtpUserid());                                  // FTP_USERID
    paramValueList.add(billInquiryForm.getFtpPassword());                                // FTP_PASSWORD
    paramValueList.add(billInquiryForm.getFtpHostname());                                // FTP_HOSTNAME
    paramValueList.add(billInquiryForm.getFtpDirectory());                               // FTP_DIRECTORY
    paramValueList.add(billInquiryForm.getFtpFilename());                                // FTP_FILENAME
    paramValueList.add(billInquiryForm.getDataformat());                                 // DATAFORMAT
    /***** call the SP *************/
    Map resMap = executeSP(paramValueList, false);
    //Map resMap = getBIS();
    _LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
    checkVACErrors(resMap);
    _LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
    return resMap;
  }

  //get value from variable, if empty string set to null.
  private String getV (String input) {
    if (input != null && !"".equals(input)) {
      return input;
    } else {
      return "";
    }
  }

  //reassign ban,man and account id values
  private String[] getBan_Man_accountId(String ban,String man){
    String xBan = getV(ban);
    String xMan = getV(man);
    if (xBan == null && xMan == null) {
      return new String[] {null, null, null};
    }
    else if (xBan != null && xMan == null) {
      return new String[] {null, null, xBan};
    }
    else if (xBan == null && xMan != null) {
      return new String[] {null, xMan, null};
    }
    else {
      return new String[] {xBan, xMan, null};
    }
  }
}
