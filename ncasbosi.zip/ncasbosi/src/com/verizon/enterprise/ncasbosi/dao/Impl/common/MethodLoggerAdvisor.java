package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.lang.reflect.Method;
import org.apache.log4j.Logger;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

/**
 * The object of this call can be used to rethrow exception,log params(both in & out) of any DAO impl
 * This is configured in spring-context.xml
 *
 */
public class MethodLoggerAdvisor implements ThrowsAdvice,AfterReturningAdvice,MethodBeforeAdvice{
	
	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	
	/**
	 * @param method
	 * @param args
	 * @param target
	 * @param ex
	 * @throws NCASException
	 * This method is called when an exception occurs in the DAOImpl's method
	 */
	public void afterThrowing(Method method, Object[] args, Object target, Exception ex)throws NCASException{
		String methodName = method.getName();
		String targetClass = target.getClass().getName();
		if(ex!=null){
			_LOGGER.info("Exception occured in method:"+methodName +" Exception:"+ex.getMessage());
			if(ex instanceof NCASException){
				//not doing anything as some Ticket methods in DAOImpl throw NCASException already - just propagating that back
			}else{
				ex.printStackTrace();
				throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,target.getClass(),new Exception(methodName+":::"+ex.getMessage()));
			}			
		}		
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.aop.AfterReturningAdvice#afterReturning(java.lang.Object, java.lang.reflect.Method, java.lang.Object[], java.lang.Object)
	 * This method is called after returning from the DaoImpl's method
	 */
	@Override
	public void afterReturning(Object returnValue, Method method, Object[] args,Object target) throws Throwable {		
		String methodName = method.getName();
		_LOGGER.info("Target="+target.getClass().getName()+" \n "+methodName+" returning with output:"+returnValue);
	}
	

	/* (non-Javadoc)
	 * @see org.springframework.aop.MethodBeforeAdvice#before(java.lang.reflect.Method, java.lang.Object[], java.lang.Object)
	 * This method is called before entering the DaoImpl's method
	 */
	@Override
	public void before(Method method, Object[] args, Object target)throws Throwable {
		String methodName = method.getName();
		StringBuilder builder = new StringBuilder();
		builder.append("Target="+target.getClass().getName()+"\n Entering "+methodName+" with input ::");		
		if(args!=null){
			for(int i=0;i<args.length;i++){
				Object obj = args[i];
				String argNo = "args-"+(i+1);
				builder.append(argNo+":"+obj+"\t");
			}
		}
		_LOGGER.info(builder.toString());
	}
}

