package com.verizon.enterprise.ncasbosi.dao;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.core.SqlInOutParameter;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;


public abstract class BaseStoredProcedure extends StoredProcedure implements NCASBOSIConstants
{

	static private final Logger _LOGGER = Logger.getLogger(BaseStoredProcedure.class);


	private String storedProcName = null;
	private Map valueMap;
	private Map resMap = null;

	private List allParamList = null;
	private ArrayList inputValueList = null;
	
	//vars to be used when calling the checkErrors function
	protected final String VAM = "VAM";
	protected final String VGW = "VGW";
	protected final String BARS = "BARS";



	 public BaseStoredProcedure(DataSource dataSource, String spName, List spInOutList)
	 {
		 super(dataSource, spName);
		 storedProcName = spName;
		 inputValueList = new ArrayList();
		 allParamList = spInOutList;

		 declareParameters();
		 compile();
		 _LOGGER.debug("Stored Procedure "+storedProcName+" compiled");
	 }

	/**
	 * Method to declares the SP parameters
	 * @param storeProcName
	 */

	private void  declareParameters()
	  {
		_LOGGER.debug("Entering SP Parameters declaration "+storedProcName);
		Integer dataType = null;
		String paramName= null;
		String paramType= null;
		Object paramObj = null;
		Object[] parmArr = null;
		Object rsType = null;

		for (int i= 0; i<allParamList.size(); i++ )
			//{while(paramTypeMap.keySet().iterator().hasNext())
			{
				parmArr = (Object[])allParamList.get(i);
				paramName= (String)parmArr[0];
				paramType= (String)parmArr[2];


				if(paramType != null && paramType.equalsIgnoreCase(NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET))
				{
					rsType= parmArr[3];
					if(rsType instanceof RowMapper)
					{
					  paramObj = new SqlReturnResultSet(paramName,(RowMapper) rsType);
					}
					else if(rsType instanceof ResultSetExtractor)
					{
						  paramObj = new SqlReturnResultSet(paramName,(ResultSetExtractor) rsType);
					}
					else if(rsType instanceof RowCallbackHandler)
					{
						  paramObj = new SqlReturnResultSet(paramName,(RowCallbackHandler) rsType);
					}
				}
				else if(paramType != null && paramType.equalsIgnoreCase(NCASBOSIConstants.SP_PARAMETER_TYPE_OUT))
				{
					dataType= (Integer)parmArr[1];
					paramObj = new SqlOutParameter(paramName, dataType.intValue());
				}
				else if(paramType != null && paramType.equalsIgnoreCase(NCASBOSIConstants.SP_PARAMETER_TYPE_IN))
				{
					dataType= (Integer)parmArr[1];
					paramObj = new SqlParameter(paramName, dataType.intValue());
				}
				else if(paramType != null && paramType.equalsIgnoreCase(NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT))
				{
					dataType= (Integer)parmArr[1];
					paramObj = new SqlInOutParameter(paramName, dataType.intValue());
				}
				else
				{
					paramObj = null;
				}

				declareParameter((SqlParameter)paramObj);
				_LOGGER.debug("Declarning parameter "+paramName+ "  as "+paramType);
			}
		_LOGGER.debug("Exiting SP Parameters declaration for "+storedProcName);
	  }

    /**
	 * If Output Parameter Objects included then set Out = true
	 * Condition: ParamList should be equivalent to all registered parameters
	 * @param out
	 * @return
	 */
    protected void applyValues(boolean out)
	 {
    	String paramName= null;
    	valueMap = new HashMap();
    	List inList = null;
    	Object[] parmArr = null;

    	_LOGGER.debug("Entering SP Parameters runtime values");
    	_LOGGER.info("Input Parameter Values for "+storedProcName);
    	if(!out)
    	{
    		 inList = NCASBOSIDAOUtil.getInputParamList((ArrayList)allParamList);
    		 for (int i=0; i<inList.size(); i++)
			{
    			 parmArr = (Object[])inList.get(i);
 				 paramName= (String)parmArr[0];

				valueMap.put(paramName, inputValueList.get(i));
				_LOGGER.info("Input Param Name: "+paramName+" Value= "+inputValueList.get(i));

		   }
    	}
    	else
    	{
    		inList = NCASBOSIDAOUtil.getAllParamList((ArrayList)allParamList);
    		for (int i=0; i<inList.size(); i++)

				{
		    		parmArr = (Object[])inList.get(i);
					paramName= (String)parmArr[0];
					valueMap.put(paramName, inputValueList.get(i));
					_LOGGER.info("Input Param Name: "+paramName+" Value= "+inputValueList.get(i));
			    }
    	}
	 }
    /**
	 *
	 * @param isOutVars
	 * False: If Output Variable return Data Types are included in the Input ParametersList
	 * @return
	 */
	public Map executeSP(List valueList, boolean isOutVar)throws Exception
	{
		_LOGGER.info("Entering ExecuteStoredProcedure  "+getStoredProcedureName());

		inputValueList = (ArrayList)valueList;
		applyValues(isOutVar);

		_LOGGER.info("Executing SP "+getStoredProcedureName()+ "  @"+NCASBOSIUtil.getCurrentDateAndTime());
		resMap = super.execute(valueMap);
		_LOGGER.info("SP Response Received for "+getStoredProcedureName()+ "  @"+NCASBOSIUtil.getCurrentDateAndTime());
		
		return resMap;
	}

	/**
	 * Method returns the StoredProcedure Name
	 * @return
	 */
	protected String getStoredProcedureName()
	{
		return storedProcName;
	}



	public static Integer getSqlDataType(int i)
	{
		return new Integer(i);
	}

	/**
	 * An abstract Method must be implemented by sub class to set the InputValues to be inserted into the SP at the execution time
	 * The implemented method must call BaseStoredProcedure class's public void executeSP(ArrayList aList, boolean isOutVars);
	 * Values must be added in the ArrayList in the same order they are declared	 *
	 * @param paramObj
	 */
	protected abstract Map executeStoredProcedure(Object paramValueObj)throws Exception;
 
	/**
	 * Method that checks if VAC has returned a response with any warnings or errors
	 * @param resMap
	 */
	 protected void checkVACErrors(Map resMap)throws Exception
	{
		_LOGGER.info("Entering in method checkVACErrors(Map resMap)");
		Object retCodeObj = null;
		Integer retCode = null;		
		if(resMap != null)
		{
		   retCodeObj = resMap.get(NCASBOSIConstants.BI_VAC_RETURN_CODE_IDENTIFIER);
		   if(retCodeObj != null)
		   {
			   retCode = (Integer)retCodeObj;

			  if(retCode.intValue() >= NCASBOSIConstants.BI_VAC_ERROR_CODE)
			  {
				//String retMsg = (String)resMap.get(NCASBOSIConstants.BI_VAC_ERROR_TEXT_IDENTIFIER);
				String errorMsg = CommonUtil.mapToString(resMap);
				_LOGGER.error("Error encountered in the VAC Response "+errorMsg);
				_LOGGER.debug("Entering static method checkVACErrors "+errorMsg);
				throw new SQLException("VAC BAD Response "+errorMsg);
			  }
			  else if(retCode.intValue() == NCASBOSIConstants.BI_VAC_WARNING_CODE)
			  {
				  String retWrn =  CommonUtil.mapToString(resMap);//(String)resMap.get(NCASBOSIConstants.BI_VAC_WARNING_TEXT_IDENTIFIER);
				  _LOGGER.warn("VAC Warnings Issued "+retWrn);
				  _LOGGER.info("VAC Warnings Issued "+retWrn);
				  _LOGGER.debug("VAC Warnings Issued "+retWrn);
			  }
			  else
			  {
//				  String responseMap = CommonUtil.mapToString(resMap);
//				  _LOGGER.info("ResponseMap::"+responseMap);
				  _LOGGER.info("VAC Response has no errors or warnings");
			  }
		   }
		}
		else
		{
			_LOGGER.info("Map passed to the method checkVACErrors was null");
		}
		_LOGGER.info("Exiting method checkVACErrors");
		
	}
	 
	 // generic function to check errors.  looks for the RETURN_CODE output from the sp.
	 // if the return code is >= 8 an exception is thrown, else continue on.
	 // backendIdentifier is just string to be printed out in error message to identify the source, ex VAM, VAC, VGW, BarsWest
	 protected void checkErrors(Map resMap, String backendIdentifier)throws Exception
		{
			_LOGGER.info("Entering in method checkErrors(Map resMap)");
			Object retCodeObj = null;
			Integer retCode = null;		
			if(resMap != null)
			{
			   retCodeObj = resMap.get("RETURN_CODE");
			   if(retCodeObj != null)
			   {
				   retCode = (Integer)retCodeObj;

				  if(retCode.intValue() >= 8)
				  {
					String errorMsg = CommonUtil.mapToString(resMap);
					_LOGGER.error("Error encountered in the " + backendIdentifier + " Response " + errorMsg);
					throw new SQLException("VAC BAD Response "+errorMsg);
				  }
				  else if(retCode.intValue() == 4)
				  {
					  String retWrn =  CommonUtil.mapToString(resMap);
					  _LOGGER.warn(backendIdentifier + " Warnings Issued "+retWrn);
				  }
				  else
				  {
//					  String responseMap = CommonUtil.mapToString(resMap);
//					  _LOGGER.info("ResponseMap::"+responseMap);
					  _LOGGER.info(backendIdentifier + " Response has no errors or warnings");
				  }
			   }
			}
			else
			{
				_LOGGER.info("Map passed to the method checkErrors was null");
			}
			_LOGGER.info("Exiting method checkErrors");
			
		}
	 
	 
	  static protected String getVAMSchemaName() 
	  {
		  String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");			
		  _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		  return schemaName;
	  }
	  
	  static protected String getVACSchemaName() 
	  {
//		  String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAC_SCHEMA_NAME, " ");			
//		  _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
//		  return schemaName;
		  return "VAR";
	  }
	  static protected String getVGWSchemaName() 
	  {
		  String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VGW_SCHEMA_NAME, " ");			
		  _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		  return schemaName;
	  }
	  static protected String getBarsWestSchemaName() 
	  {
		  String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.BARSWEST_SCHEMA_NAME, " ");			
		  _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		  return schemaName;
	  }
	  static protected String getBRISchemaName() 
	  {
		  String schemaName = NCASBOSIConfig.getProperty(NCASBOSIConstants.BRI_SCHEMA_NAME, " ");			
		  _LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		  return schemaName;
	  }
	  static protected String getURSchemaName() 
	  {
		  return "XCEP";
	  }


	public List getAllParamList() {
		return allParamList;
	}
}

