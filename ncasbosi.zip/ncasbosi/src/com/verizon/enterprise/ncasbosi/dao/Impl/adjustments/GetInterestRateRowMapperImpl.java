package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.adjustments.InterestRateDetails;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetInterestRateRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetInterestRateRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetInterestRateRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List<InterestRateDetails> interestRateList = new ArrayList();
		InterestRateDetails interestRateDetailsRecord = null;
		try{
			while(rs.next()) {
				interestRateDetailsRecord = new InterestRateDetails();
				String state = rs.getString("STATE");
				String year = rs.getString("YEAR");
				double intRate = rs.getDouble("YEARLY_INT_RATE");
				
				if(CommonUtil.isNotNull(state)) {
					interestRateDetailsRecord.setState(state.trim());
				}
				if(CommonUtil.isNotNull(year)) {
					interestRateDetailsRecord.setYear(year.trim());
				}
				interestRateDetailsRecord.setIntRate(commonUtil.formatNumber(new BigDecimal(intRate), "##0.00000;-##0.00000"));
								
				//finally add the interestRateDetailsRecord to the list
				interestRateList.add(interestRateDetailsRecord);
			}
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			throw nfe;
		}catch(Exception ex) {
			ex.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+ex.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+ex.getMessage());
		}
		return interestRateList;
	}
}
