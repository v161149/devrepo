package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDownloadGBRCorpSummary extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPDownloadGBRCorpSummary.class);

	private static List spInOutList;

	private static DownloadGBRCorpSummaryRowMapperImpl rowMapper;

	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new DownloadGBRCorpSummaryRowMapperImpl();

		 spInOutList.add(new Object[]{"records",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CUST_NO", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUSTOMER_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});		 
		 spInOutList.add(new Object[]{"WHERE_PHRASE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPDownloadGBRCorpSummary(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_GBR_CORP_SUMMARY, spInOutList);
	}

	public Content executeStoredProcedure(String userId, String debugLevel,
										String customerNo, String customerType,
										String whereFilter, String sortOrder,
										String cursorId,String configSubsOid) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		if(customerNo == null ) {
			customerNo = "";
		}
		if(customerType == null) {
			customerType = "";
		}
		if(whereFilter == null) {
			whereFilter = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(cursorId == null) {
			cursorId = "";
		}
		
		// clearing out token_st for each call, so doesn't execute same 
		cursorId = "";

		paramValueList.add(customerNo);//CUST_NO
		paramValueList.add(customerType);//CUSTOMER_TYPE
		paramValueList.add(configSubsOid);//CONFIG_SUBS_OID
		paramValueList.add(whereFilter);//WHERE_PHRASE
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(cursorId);//TOKEN_ST
		paramValueList.add("1");//PAGE_OFFSET
		paramValueList.add("10000");//PAGE_SIZE
		
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);	
		List actualList = (List)procMap.get("records");
		Content retObj = new Content();
		retObj.setRows(actualList);

		return retObj ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
