package com.verizon.enterprise.ncasbosi.dao.Impl.intl;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.verizon.enterprise.common.ncas.NCASIntlUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.intl.LangData;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.domain.SelectOption;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.intl.DynamText;
import com.verizon.enterprise.ncasbosi.dao.Interface.intl.InternationalInterface;
import com.verizon.enterprise.common.ncas.admin.SearchAppsData;
import com.verizon.enterprise.common.ncas.ticket.Reason;

import javax.sql.DataSource;
import java.util.Map;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import com.verizon.kernel.config.Config;



public class InternationalDAOImpl extends JdbcDaoSupport implements InternationalInterface, NCASBOSIConstants {

	private static final Logger _LOGGER = Logger.getLogger(InternationalDAOImpl.class);

	private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";

	private String INSERT_DYNAM_TEXT = "INSERT INTO  " + getSchemaName() + ".PL_DYNAM_TEXT_T(APP_NAME,TYPE,TEXT_ORDER,LANG_OID,LAST_UPDATE,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";
	private String UPDATE_PL_DYNAM_TEXT = "UPDATE "+getSchemaName()+".PL_DYNAM_TEXT_T SET TYPE=?, LAST_UPDATE=?, LAST_UPDATED_BY=? , LANG_OID=? WHERE ID=?";
	private String UPDATE_PL_DYNAM_DUP  = "UPDATE "+getSchemaName()+".PL_REQSTATUS SET ERROR_MSG = ?, TYPE = ? WHERE REQUEST_ID = ?";
	private String SELECT_REQUEST_ID = "SELECT DISTINCT REQUEST_ID FROM "+getSchemaName()+".PL_REQSTATUS";
	private String SELECT_ALL_DYNAM_TYPES = "SELECT ID,TYPE,APP_NAME FROM "+getSchemaName()+".PL_DYNAM_TEXT_T ORDER BY APP_NAME,TYPE";
	private String SELECT_ALL_APP_NAMES = "SELECT  DISTINCT(APP_NAME) FROM  "+getSchemaName()+".PL_DYNAM_TEXT_T";
	private String SEARCH_ALL_TYPE_NAMES ="SELECT DISTINCT(D.TYPE) FROM "+getSchemaName()+".PL_DYNAM_TEXT_T D,"+getSchemaName()+".PL_LANG_T L WHERE D.LANG_OID=L.LANG_OID AND L.NAME = ? AND D.APP_NAME = ?";
    private String SELECT_ALL_DUPLICATE_IDS = "SELECT REQUEST_ID FROM "+getSchemaName()+".PL_REQSTATUS WHERE TYPE = ?";
	private String SELECT_ALL_DUPLICATE_MSG = "SELECT ERROR_MSG FROM "+getSchemaName()+".PL_REQSTATUS WHERE REQUEST_ID = ?";
	private String SELECT_LANGUAGE ="SELECT LANGUAGE_NAME,LANGUAGE_CODE FROM LANGUAGE ORDER BY LANGUAGE_CODE";
	private String SELECT_LANGOID_FROM_LANG = "SELECT LANG_OID FROM "+getSchemaName()+".PL_LANG_T WHERE LANG='"+NcasConstants.LANG_CODE_US_ENGLISH_VAM+"' AND NAME=?";
	private String SELECT_DYNAM_DTLS = "SELECT TYPE,TEXT_ORDER,APP_NAME,LANG_OID FROM "+getSchemaName()+".PL_DYNAM_TEXT_T WHERE ID=?";
	private String SELECT_MAX_LANG_ID = "SELECT MAX(LANG_OID) AS LANG_OID FROM "+getSchemaName()+".PL_LANG_T";
//CACHE
	private String SELECT_DYNA_AND_LANG_FOR_CACHE = "SELECT  A.TYPE,B.NAME,COALESCE(B.VALUE,C.VALUE) AS VALUE FROM "+getSchemaName()+".PL_DYNAM_TEXT_T A , "+getSchemaName()+".PL_LANG_T B, "+getSchemaName()+".PL_LANG_T C WHERE B.LANG=? AND A.LANG_OID=B.LANG_OID AND B.NAME=C.NAME AND C.LANG='"+NcasConstants.LANG_CODE_US_ENGLISH_VAM+"'";
	private String SELECT_SIMPLE_TRANSLATE = "SELECT  VALUE FROM "+getSchemaName()+".PL_LANG_T WHERE LANG=? AND NAME=?";

//XLS EXPORT
	private String SELECT_PLLANG = "SELECT NAME,LANG,VALUE FROM "+getSchemaName()+".PL_LANG_T ORDER BY NAME,LANG";
	private String SELECT_DYNAM_TEXT = "SELECT TYPE,APP_NAME,TEXT_ORDER,NAME FROM "+getSchemaName()+".PL_DYNAM_TEXT_T A,"+getSchemaName()+".PL_LANG_T B WHERE A.LANG_OID=B.LANG_OID AND B.LANG='EN5' ORDER BY APP_NAME,TYPE,TEXT_ORDER";

	private String SELECT_PLLANG_MISS1 = "SELECT B.NAME,B.LANG,B.VALUE FROM "+getSchemaName()+".PL_LANG_T A, "+ getSchemaName()+".PL_LANG_T B where A.LANG_OID=B.LANG_OID AND A.LANG='EN5' AND  A.VALUE=B.VALUE ORDER BY B.NAME,B.LANG";
	private String SELECT_PLLANG_MISS2 = "SELECT B.NAME,B.LANG,B.VALUE FROM "+getSchemaName()+".PL_LANG_T A, "+ getSchemaName()+".PL_LANG_T B where A.LANG_OID=B.LANG_OID AND A.LANG='EN5' AND  A.VALUE!=B.VALUE ORDER BY B.NAME,B.LANG";

//ADMIN
	private String SELECT_NAME ="SELECT NAME FROM "+getSchemaName()+".PL_LANG_T WHERE LANG=?";
	private String SELECT_ALL_NAMES = "SELECT NAME FROM "+getSchemaName()+".PL_LANG_T ORDER BY NAME";
	private String SELECT_VALUE ="SELECT VALUE,LANG_OID FROM "+getSchemaName()+".PL_LANG_T WHERE LANG=? AND NAME=?";
	
	//SEARCH
	private String SELECT_REASONS_MSG = "SELECT REASON_ID, REASON_DESC FROM "+getSchemaName()+".PL_VBIF_REASON_T";
	private String SELECT_UPDATE_DELETE_REASONS_MSG = "SELECT DISTINCT REASON_ID, REASON_DESC FROM "+getSchemaName()+".PL_VBIF_REASON_T A, "+getSchemaName()+".PL_SEARCH_APPS_T B WHERE A.REASON_ID = B.APP_ID";
	 
	
	private String SELECT_SEARCH_APPS_DATA = "SELECT APP_ID, KEYWORD, RANK, PORTAL FROM "+getSchemaName()+".PL_SEARCH_APPS_T WHERE APP_ID = ? AND PORTAL = ?";
	private String INSERT_SEARCH_DATA = "INSERT INTO  " + getSchemaName() + ".PL_SEARCH_APPS_T(APP_ID, KEYWORD, RANK, PORTAL, PORTAL_LOGIN_ID, LAST_UPD_TIMESTAMP) VALUES(?,?,?,?,?,?)";
	private String UPDATE_SEARCH_DATA = "UPDATE "+getSchemaName()+".PL_SEARCH_APPS_T SET RANK=?, PORTAL = ?,PORTAL_LOGIN_ID=?, LAST_UPD_TIMESTAMP=? WHERE APP_ID=? AND KEYWORD=?";
	private String UPDATE_AUTO_SEARCH_DATA = "UPDATE "+getSchemaName()+".PL_SEARCH_APPS_T SET RANK=?,PORTAL_LOGIN_ID=?, LAST_UPD_TIMESTAMP=? WHERE SEARCH_ID=?";
	private String DELETE_APPID_SEARCH_DATA = "DELETE FROM  " + getSchemaName() + ".PL_SEARCH_APPS_T WHERE APP_ID = ? AND PORTAL = ?";
	private String DELETE_KEYWORD_SEARCH_DATA = "DELETE FROM  " + getSchemaName() + ".PL_SEARCH_APPS_T WHERE APP_ID = ? AND PORTAL = ? AND KEYWORD = ?";
	private String SELECT_KEYWORDS = "SELECT SEARCH_ID, KEYWORD, RANK FROM "+getSchemaName()+".PL_SEARCH_APPS_T WHERE PORTAL = ? AND KEYWORD LIKE ?";
	
	private SelectReasonsDetails selectReasonsDetails;
	private SelectSearchAppData selectSearchAppData;
	private SelectKeywordDetails selectKeywordDetails;
	
	private SqlUpdate insertSearchSqlUpdate;
	private SqlUpdate updateSearchSqlUpdate;
	private SqlUpdate updateAutoSearchSqlUpdate;
	private SqlUpdate deleteAppIdSqlUpdate;
	private SqlUpdate deleteAppIdKeySqlUpdate;
	


	private SelectAllValueDetails selectAllValueDetails;
	private SelectDynaAndLangForCache selectDynaAndLangForCache;
	private SelectAllLanguageDetails selectAllLanguageDetails;
	private SelectIDFromLangForName selectIDFromLangForName;
	private SelectDynamDetails selectDynamDetails;
	private GetDuplicates getDuplicates;
	private GetDuplicateMsg getDuplicateMsg;
	private SelectAllNames selectAllNames;
	private UpdateDynamText updateDynamText;
	private UpdateDynamDup updateDynamDup;
	private CreateTranslationsxls createTranslationsxls;
	private CreateDynamxls createDynamxls;
	
	private SimpleTranslate simpleTranslation;

	
	private MissTranslationsxls1 missTranslationsxls1;
	private MissTranslationsxls2 missTranslationsxls2;

	
	private static long timer = 0;
	@SuppressWarnings("unchecked")
	private Map<String,Map<String,List>> langMap = null;


//ADMIN
	private SelectAllNameDetails selectAllNameDetails;
	private int request_id = 0;
	private SelectRequestId selectRequestId = null;
	private List requestList = null;



	private SqlUpdate insertUnicodeSqlUpdate;
	private SqlUpdate updateUnicodeSqlUpdate;
	private SqlUpdate deleteTypeSqlUpdate;
	private SqlUpdate deleteUnicodeSqlUpdate;
	private SqlUpdate insertDynamSqlUpdate;
	private SqlUpdate insertDynamdupSqlUpdate;
	private BatchSqlUpdate updateLangSqlUpdate;
	private SqlUpdate updateLangToEnglishSqlUpdate;

    private static final List<String> excelLangList = new ArrayList<String>();
    static{
		excelLangList.add("fr");
		excelLangList.add("de");
		excelLangList.add("nl");
		excelLangList.add("en-GB");
		excelLangList.add("es");
		excelLangList.add("pt");
		excelLangList.add("ja");
		excelLangList.add("zh");
		excelLangList.add("xn");
		excelLangList.add("sv");
		excelLangList.add("it");
		excelLangList.add("ko");
	}

	@SuppressWarnings("unchecked")
	Map  dataMap = null;
	Map reverseLangCodeMap = null;
	private String getSchemaName() {
		String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
		return schemaName;
	}


	protected void initDao() throws Exception{
		super.initDao();
		//CACHE
		selectDynaAndLangForCache = new SelectDynaAndLangForCache(SELECT_DYNA_AND_LANG_FOR_CACHE);
		//XLS EXPORT
		createTranslationsxls = new CreateTranslationsxls(SELECT_PLLANG);
		missTranslationsxls1 = new MissTranslationsxls1(SELECT_PLLANG_MISS1);
		missTranslationsxls2 = new MissTranslationsxls2(SELECT_PLLANG_MISS2);

		createDynamxls = new CreateDynamxls(SELECT_DYNAM_TEXT);
		simpleTranslation = new SimpleTranslate(SELECT_SIMPLE_TRANSLATE);
		timer = System.currentTimeMillis();
	}

	abstract class AbstractSelect extends MappingSqlQuery{

		public AbstractSelect(DataSource dataSource,String sql){
			super(dataSource,sql);
		}

	}
	private JdbcTemplate dbTemplate;
	private JdbcTemplate ecpJdbcTemplate;
	private DataSource ecpDataSource;

	public DataSource getEcpDataSource() {
		return ecpDataSource;
	}
	public void setEcpDataSource(DataSource ecpDataSource) {
		this.ecpDataSource = ecpDataSource;
		this.ecpJdbcTemplate = super.createJdbcTemplate(this.ecpDataSource);
	}
	public JdbcTemplate getecpJdbcTemplate() {
		return this.ecpJdbcTemplate;
	}

	protected JdbcTemplate getDBTemplate()
	{
		if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}


	public void deleteLangCache(){
		if (langMap	!= null) {
			langMap.clear();
			langMap= null;
		}
	}

    private String getMatchingLangCode(Map<String, String> langMatchMap, String search) {
    	String defaultStr = NcasConstants.LANG_CODE_US_ENGLISH_VAM;
    	if(search==null || search.trim().equals(""))
    		return defaultStr;
            Iterator<Map.Entry<String, String>> it  = langMatchMap.entrySet().iterator();
            while(it.hasNext()) {
                Map.Entry<String, String> pairs = it.next();
                if(search.equalsIgnoreCase(pairs.getKey())) {
                    defaultStr = (String)pairs.getValue();
                    break;
                }
                else if(search.equalsIgnoreCase(pairs.getValue())) {
                    defaultStr = pairs.getValue();
                    break;
                }
            }
    	return defaultStr;
        }

	@SuppressWarnings("unchecked")
	public Map<String,List> getPreferredLangPhrases(String langCode,String appName) {
		final String METHOD_NAME = "getPreferredLangPhrases => ";
		_LOGGER.info(METHOD_NAME+"::langCode::"+langCode+"::appName::"+appName);
		Map<String,List>  retMap = new HashMap();
		if(langCode == null || langCode.trim().equals(""))
		{
			_LOGGER.info(METHOD_NAME+"::User's Preferred language is empty. Defaulting it to english");
			langCode = NCASBOSIConstants.LANG_CODE_ENGLISH;
		}
		if(appName==null || (appName!=null && appName.trim().equals("")))
		{
			_LOGGER.info(METHOD_NAME+"::App Name is null or empty");
			appName = "";
		}
		langCode = getMatchingLangCode(NCASIntlUtil.langMatchMap,langCode);

		_LOGGER.info("The langCode after the match is:"+langCode);

		resetCache(langCode,appName);
		retMap = getCachedData(langCode, appName);
		return retMap;
	}


	
	
	public List<SelectOption> translateSelectOptions(String langCode,String appName,List<SelectOption> entries) {
		final String METHOD_NAME = "translateSelectOptions => ";
		
		langCode = getMatchingLangCode(NCASIntlUtil.langMatchMap,langCode);
		List langList = selectDynaAndLangForCache.getLangMaps("EN5",appName);
		
		Map typeMap = (Map)langList.get(0);
		Map langMap = (Map)langList.get(1);
		List<SelectOption> translatedList = new ArrayList();

		if(typeMap!=null && langMap!=null && entries!=null ){
				Iterator originalItr = entries.iterator();
				while(originalItr.hasNext()){
					SelectOption optns = (SelectOption)originalItr.next();
					translatedList.add(new SelectOption((String) langMap.get((String) typeMap.get(optns.getLabel())),optns.getValue()));
				}
		}
		return translatedList;

	}
	


	
	@SuppressWarnings("unchecked")
	public  Map<String,String> getPreferredLang(String langCode,String appName) {
		Map<String,String>  retMap = new HashMap();
		Map<String,List>  cachedMap = getPreferredLangPhrases(langCode,appName) ;
		Map.Entry mapEntry;
		List lstEntry = null;
		String lstValue = "";
		for (Iterator it = cachedMap.entrySet().iterator(); it.hasNext();) {
			mapEntry = (Map.Entry) it.next();
			lstEntry = (List)mapEntry.getValue();
			if(lstEntry!=null&&lstEntry.size()>=1)
				lstValue = (String)lstEntry.get(0);
			retMap.put((String)mapEntry.getKey(),lstValue);
		}
		return retMap;
	}

	@SuppressWarnings("unchecked")
	private Map<String, List> getCachedData(String langCode,String appName) {
		String mapKey = langCode+"*"+appName;
		if(langMap == null || (langMap!=null && !langMap.containsKey(mapKey)))
			populateCache(langCode, appName);
		if(langMap == null)
			return new HashMap();
		else
		return langMap.get(mapKey);
	}

	public synchronized void resetCache(String langCode,String appName) {
		long minutes = ( System.currentTimeMillis() - timer ) / 60000;
		if(minutes >= 60) {
			if (langMap	!= null) {
				langMap.clear();
				langMap= null;
			}
			timer = System.currentTimeMillis();
		}
		if(langMap == null)
			populateCache(langCode,appName);
	}


	@SuppressWarnings("unchecked")
	public void populateCache(String lang, String appName){
		final String METHOD_NAME = "populateLangData => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try {
			Map<String,Map<String,List>> retMap = selectAllLangData(lang,appName);
			if(langMap == null)
				langMap =  new HashMap();
			Map.Entry mapEntry;
			for (Iterator it = retMap.entrySet().iterator(); it.hasNext();) {
				mapEntry = (Map.Entry) it.next();
				langMap.put((String)mapEntry.getKey(),(Map<String,List>) mapEntry.getValue());
			}
		} catch (Exception e) {
			_LOGGER.error(METHOD_NAME+" FAILED :: " +e.getMessage());
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}


	@SuppressWarnings("unchecked")
	public  Map<String,Map<String,List>> selectAllLangData(String lang, String appName) throws NCASException{
		final String METHOD_NAME = "selectAllLangData => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try{
			return selectDynaAndLangForCache.getDynaAndLangFromDB(lang,appName);
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+"selectAllLangData Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
	}
	
	
	class SimpleTranslate extends JdbcDaoSupport{
		private String sql;
		public SimpleTranslate(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public String getTranslation(String lang, String value) {
			final String METHOD_NAME = "getTranslation => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			final String langCode = lang;
			Object[] params = null;
			params = new Object[]{lang, value};
			_LOGGER.info(METHOD_NAME+"::SQL:"+sql);

			return  (String)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {
					String translatedValue = "";
					if (rs.next()) {
						try{
							String value = rs.getString("VALUE").trim();

							if(value==null || value.trim().length()==0)
								value = "";

							translatedValue = value;
						}catch(Exception ex){_LOGGER.error("Error :"+ex.getMessage());}
					}
					return translatedValue;
				}});
		}
		
	}
	
	class SelectDynaAndLangForCache extends JdbcDaoSupport{
		private String sql;
		public SelectDynaAndLangForCache(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map<String,Map<String,List>> getDynaAndLangFromDB(String lang, String app) {
			final String METHOD_NAME = "getDynaAndLangFromDB => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			final String langCode = lang;
			if(app==null)
				app = "";

			final String appName = app;
			Object[] params = null;
			sql = SELECT_DYNA_AND_LANG_FOR_CACHE;
			if(appName.trim().equals(""))
			{
				params = new Object[]{lang};
			}
			else{
				params = new Object[]{lang, appName};
				sql += " AND A.APP_NAME=? ";
			}
			sql += " ORDER BY A.TYPE, A.TEXT_ORDER";

			_LOGGER.info(METHOD_NAME+"::SQL:"+sql);

			return  (Map<String,Map<String,List>>)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {
					Map<String,List> dynaLangMap = new HashMap<String,List>();
					Map<String, Map<String,List>> finalMap = new HashMap<String, Map<String,List>>();
					List<String> valueList = null;
					String mapKey = "";
					while (rs.next()) {
						try{

							String type = rs.getString("TYPE").trim();
							String name = rs.getString("NAME").trim();
							String value = rs.getString("VALUE").trim();

							if(value==null || value.trim().length()==0)
								value = name;

							valueList = (List)dynaLangMap.get(type);
							if(valueList==null)
								valueList = new ArrayList<String>();
							valueList.add(value);
							dynaLangMap.put(type, valueList);

						}catch(Exception ex){_LOGGER.error("Error :"+ex.getMessage());}
					}
					mapKey = langCode+"*"+appName;
					finalMap.put(mapKey, dynaLangMap);
					return finalMap;
				}});
		}
		
		public List<Map<String,String>> getLangMaps(String lang, String app) {
			final String METHOD_NAME = "getLangMaps => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			final String langCode = lang;
			if(app==null)
				app = "";

			final String appName = app;
			Object[] params = null;
			sql = SELECT_DYNA_AND_LANG_FOR_CACHE;
			if(appName.trim().equals(""))
				params = new Object[]{lang};
			else{
				params = new Object[]{lang, appName};
				sql += " AND A.APP_NAME=? ";
			}
			sql += " ORDER BY A.TYPE, A.TEXT_ORDER";

			_LOGGER.info(METHOD_NAME+"::SQL:"+sql);

			return  (List<Map<String,String>>)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {
					List retList = new ArrayList();
					Map<String,String> langMapByValue = new HashMap<String,String>();
					Map<String,String> langMapByType  = new HashMap<String,String>();
					String mapKey = "";
					while (rs.next()) {
						try{

							String type = rs.getString("TYPE").trim();
							String name = rs.getString("NAME").trim();
							String value = rs.getString("VALUE").trim();

							if(value==null || value.trim().length()==0)
								value = name;


							langMapByValue.put(value,type);
							langMapByType.put(type,value);

						}catch(Exception ex){_LOGGER.error("Error :"+ex.getMessage());}
					}
					retList.add(langMapByValue);
					retList.add(langMapByType);
					return retList;
				}});
		}		
	}




	public Map<String,Object> insertUnicodeAllData(String name,String value,String lang, int langOid) throws NCASException {
		final String METHOD_NAME = "insertUnicodeAllData => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String INSERT_UNICODE_DATA = "INSERT INTO  " + getSchemaName() + ".PL_LANG_T(NAME, VALUE, LANG, LANG_OID) VALUES(?,?,?,?)";
		boolean status = false;
		Map<String,Object> responseMap = new HashMap<String,Object>();
		_LOGGER.info(METHOD_NAME+"Insert SQL: " + INSERT_UNICODE_DATA);
		try
		{
			_LOGGER.info(METHOD_NAME+"NAME::"+name+"::value::"+value+"::lang::"+lang);

			if(insertUnicodeSqlUpdate == null){
				insertUnicodeSqlUpdate = new SqlUpdate(getDataSource(),INSERT_UNICODE_DATA);
				insertUnicodeSqlUpdate.setReturnGeneratedKeys(true);
				insertUnicodeSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				insertUnicodeSqlUpdate.declareParameter(new SqlParameter("VALUE", Types.VARCHAR));
				insertUnicodeSqlUpdate.declareParameter(new SqlParameter("LANG", Types.CHAR));
				insertUnicodeSqlUpdate.declareParameter(new SqlParameter("LANG_OID", Types.INTEGER));
				insertUnicodeSqlUpdate.compile();
			}

			if(langOid == 0)
			{
				SelectMaxLangOIDFromLang selectMaxLangOIDFromLang = new SelectMaxLangOIDFromLang(SELECT_MAX_LANG_ID);
			    langOid = selectMaxLangOIDFromLang.getMaxLangOid(new Object[]{});
			}

			_LOGGER.info(METHOD_NAME+"langId::"+langOid);

			Object[] parameterValues = new Object[]{name,value,NCASIntlUtil.langMatchMap.get(lang),langOid};
			insertUnicodeSqlUpdate.update(parameterValues);

			status = true;
			responseMap.put("status",new Boolean(status));
			responseMap.put("langoid", langOid);
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"insertUnicodeData Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}


	@SuppressWarnings("unchecked")
	public Map updateUnicodeData(String userText,String value,String lang) throws NCASException {
		final String METHOD_NAME = "updateUnicodeData => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String UPDATE_UNICODE_DATA = "UPDATE " + getSchemaName() + ".PL_LANG_T SET  VALUE=? WHERE LANG = ? and NAME=?";
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();

		_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_UNICODE_DATA);

		try
		{
			_LOGGER.info("User text::"+userText);

			if(updateUnicodeSqlUpdate == null){
				updateUnicodeSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_UNICODE_DATA);
				updateUnicodeSqlUpdate.declareParameter(new SqlParameter("VALUE", Types.VARCHAR));
				updateUnicodeSqlUpdate.declareParameter(new SqlParameter("LANG", Types.CHAR));
				updateUnicodeSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				updateUnicodeSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{value,NCASIntlUtil.langMatchMap.get(lang),userText};
			updateUnicodeSqlUpdate.update(parameterValues);
			status = true;
			responseMap.put("status",new Boolean(status));
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"updateUnicodeData Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}


	@SuppressWarnings("unchecked")
	public Map deleteUnicodeData(String name,String value,String lang) throws NCASException {
		final String METHOD_NAME = "deleteUnicodeData => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String DELETE_UNICODE_DATA = "DELETE FROM " + getSchemaName() + ".PL_LANG_T where LANG = ? and NAME=? and VALUE=?";
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();

		_LOGGER.info(METHOD_NAME+"DELETE SQL: " + DELETE_UNICODE_DATA);

		try
		{
			_LOGGER.info(METHOD_NAME+":Name::"+name+":value:"+value+":lang:"+lang);

			if(deleteUnicodeSqlUpdate == null){
				deleteUnicodeSqlUpdate = new SqlUpdate(getDataSource(),DELETE_UNICODE_DATA);
				deleteUnicodeSqlUpdate.declareParameter(new SqlParameter("LANG", Types.CHAR));
				deleteUnicodeSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				deleteUnicodeSqlUpdate.declareParameter(new SqlParameter("VALUE", Types.VARCHAR));
				deleteUnicodeSqlUpdate.compile();
			}

			Object[] parameterValues = new Object[]{NCASIntlUtil.langMatchMap.get(lang),name,value};
			deleteUnicodeSqlUpdate.update(parameterValues);
			status = true;
			responseMap.put("status",new Boolean(status));
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"deleteUnicodeData Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}


	class SelectAllLanguageDetails extends AbstractSelect{

		public SelectAllLanguageDetails(DataSource dataSource){
			super(dataSource,SELECT_LANGUAGE);
		}
		@SuppressWarnings("unchecked")
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
			String languageName = rs.getString("LANGUAGE_NAME");
			String languagecode = rs.getString("LANGUAGE_CODE");
			dataMap.put(languageName,languagecode);
			reverseLangCodeMap.put(languagecode,languageName);
			return dataMap;
		}
	}

	@SuppressWarnings("unchecked")
	public Map  selectAllLanguageDetails() throws NCASException {
		_LOGGER.info("Select SQL: " + SELECT_LANGUAGE);
		dataMap = new HashMap();
		reverseLangCodeMap = new HashMap();
		selectAllLanguageDetails = new SelectAllLanguageDetails(getEcpDataSource()) ;
		selectAllLanguageDetails.execute(new Object[]{});
		return dataMap;
	}

	class SelectDynamDetails extends JdbcDaoSupport{
		private String sql;

		public SelectDynamDetails(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map getDynamDetails(Object[] params) {
			final String METHOD_NAME = "getDynamDetails => ";
			_LOGGER.info(METHOD_NAME+"Entering");
			return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {

					Map<String,String> valueMap =   new HashMap<String,String>();
					while(rs.next())
					{
						String type = rs.getString("TYPE");
						String order = Integer.toString(rs.getInt("TEXT_ORDER"));
						String appName = rs.getString("APP_NAME");
						String langOid = Integer.toString(rs.getInt("LANG_OID"));
						valueMap.put("type",type);
						valueMap.put("order",order);
						valueMap.put("appName",appName);
						valueMap.put("langOid", langOid);
					}
					return valueMap;
				}});
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String,String> selectDynamDetails(String id)  throws NCASException{
		final String METHOD_NAME = "selectDynamDetails => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_DYNAM_DTLS);
		try{
			selectDynamDetails = new SelectDynamDetails(SELECT_DYNAM_DTLS);
			return selectDynamDetails.getDynamDetails(new Object[]{new Integer(id)});
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+"selectDynamDetails Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
	}

	@SuppressWarnings("unchecked")
	public Map insertUnicodeDatafromExcel(Map inputMap) throws NCASException {
		final String METHOD_NAME = "insertUnicodeDatafromExcel => ";
		Map responseMap = new HashMap();
		List lang = ((ArrayList) inputMap.get("pl_ref"));
		try {
			responseMap = insertPLLangTable(inputMap, lang);
			_LOGGER.info(METHOD_NAME+"responseMap::"+responseMap);
		} catch (NCASException e) {
			_LOGGER.error(METHOD_NAME+"insertUnicodeDatafromExcel Failed \n"+e.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,e);
		}
		return responseMap;
	}



	@SuppressWarnings("unchecked")
	private Map insertPLLangTable(Map inputMap, List lang) throws NCASException{
		final String METHOD_NAME = "insertPLLangTable => ";
		_LOGGER.info(METHOD_NAME+"Entering::");
		SqlUpdate insertPLTableSqlUpdate = null;
		boolean status = false;
		String INSERT_LANG_DATA = "INSERT INTO  " + getSchemaName() + ".PL_LANG_T(NAME, VALUE, LANG, LANG_OID) VALUES(?,?,?,?)";
		Map responseMap = new HashMap();
		List errorNamesList = new ArrayList();
		try{
			insertPLTableSqlUpdate = new SqlUpdate(getJdbcTemplate().getDataSource(),INSERT_LANG_DATA);
			insertPLTableSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
			insertPLTableSqlUpdate.declareParameter(new SqlParameter("VALUE", Types.VARCHAR));
			insertPLTableSqlUpdate.declareParameter(new SqlParameter("LANG", Types.CHAR));
			insertPLTableSqlUpdate.declareParameter(new SqlParameter("LANG_OID", Types.INTEGER));
			insertPLTableSqlUpdate.compile();
			List rowList = (ArrayList)inputMap.get("PL_LANG");
			int rowListSize = rowList.size();
			Object[] parameterValues = new Object[4];
			List dupList = new ArrayList();
			Map dupMap = new HashMap();
			int lSize = lang.size();
			SelectMaxLangOIDFromLang selectMaxLangOIDFromLang = new SelectMaxLangOIDFromLang(SELECT_MAX_LANG_ID);
			Integer startLangOid = selectMaxLangOIDFromLang.getMaxLangOid(new Object[]{});
			for(int i = 0; i < rowListSize; i++){
					List l = (ArrayList) rowList.get(i);
					startLangOid+= i;
					for(int j = 1; j < lSize; j++){
						parameterValues[0] = getParamVal(l.get(0), 12);
						parameterValues[1] = getParamVal(l.get(j), 12);
						parameterValues[2] = NCASIntlUtil.langMatchMap.get(lang.get(j));
						parameterValues[3] = startLangOid;

						if(parameterValues[1]==null || parameterValues[1].toString().trim().equals(""))
						{
							parameterValues[1] = parameterValues[0];
						}

						if((parameterValues[0]!=null && !parameterValues[0].toString().trim().equals(""))
							&&(parameterValues[2]!=null && !parameterValues[2].toString().trim().equals("")))
						{
							try{
							insertPLTableSqlUpdate.update(parameterValues);
							}catch(Exception sqlExcep)
							{
								sqlExcep.printStackTrace();
								_LOGGER.debug("insertPLLangTable in VAM Failed \n"+sqlExcep.getMessage());

								LangData langData = new LangData((String)parameterValues[0],(String)parameterValues[1],(String)parameterValues[2]);
								dupList.add(langData);
								//In case of an error collect the TYPE
								errorNamesList.add(parameterValues[0]);
							}

						}
					}
			}
			dupMap.put("langMap", dupList);
			updateLangData(dupMap);
			_LOGGER.info(METHOD_NAME+"Below are the NAMEs that failed the insert. The translations will be overwritten for these duplicates:\n"+errorNamesList.toString());

			_LOGGER.info(METHOD_NAME+"Exiting::");
			status = true;
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("insertPLLangTable in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("insertPLLangTable in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		responseMap.put("status",new Boolean(status));
		responseMap.put("duplicates", errorNamesList);
		List requestID = (ArrayList) inputMap.get("reqID");
		if(requestID.size()>0){
			String reqID = requestID.get(0).toString();
			updateDynamDup(reqID,"LANG", errorNamesList);
		}
		return responseMap;
	}


	class SelectMaxLangOIDFromLang extends JdbcDaoSupport{
		private String sql;

		public SelectMaxLangOIDFromLang(String sql) {
			this.sql = sql;
		}

		public Integer getMaxLangOid(Object[] params) {
			final String METHOD_NAME = "getMaxLangOid => ";
			_LOGGER.info(METHOD_NAME+"Entering");
			return  (Integer)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {
					int id = 0;
					while (rs.next()) {
						 id = rs.getInt("LANG_OID");
					}
					return new Integer(id+1);
				}});
		}
	}


	public final String PL_TABLE_COL_NAMES[][] = {{"NAME", "VALUE", "LANG"}};

	@SuppressWarnings("static-access")
	private Object getParamVal(Object obj, int dataType){
		int colDataType = dataType;
		try {
			if (colDataType == 93) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
					java.util.Date d = sdf.parse(obj.toString());
					Timestamp t = new Timestamp(d.getTime());
					obj = t;
				} catch (java.text.ParseException e) {
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
					obj = lastUpdated;
					e.printStackTrace();
				}
			} else if (colDataType == 91) {
				String hssfStr = obj.toString();
				java.sql.Date date = new java.sql.Date(System.currentTimeMillis());
				obj = date.valueOf(hssfStr);
			} else if (colDataType == 3) {
				double dou = Double.parseDouble(obj.toString());
				obj = dou;
			} else if(colDataType == 12 || colDataType == 1 || colDataType == -1) {
				obj = obj.toString();
			}else if (colDataType == 4) {
				int hssfInt = 0;
				hssfInt = Integer.parseInt(obj.toString());
				obj = hssfInt;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	public Map<String,Boolean> insertDynamTypes(String type, String appName, int order,int langOid, String lastUpdatedBy)throws NCASException{
		final String METHOD_NAME = "insertDynamTypes => ";
		_LOGGER.info(METHOD_NAME+" Entering");

		_LOGGER.info("TYPE::"+type+"::appName::"+appName+"order::"+order+"::langOid::"+langOid);
		boolean status = false;
		SqlUpdate insertDynamTypes = null;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			insertDynamTypes = new SqlUpdate(getDataSource(),INSERT_DYNAM_TEXT);
			insertDynamTypes.declareParameter(new SqlParameter("APP_NAME", Types.CHAR));
			insertDynamTypes.declareParameter(new SqlParameter("TYPE", Types.VARCHAR));
			insertDynamTypes.declareParameter(new SqlParameter("TEXT_ORDER", Types.INTEGER));
			insertDynamTypes.declareParameter(new SqlParameter("LANG_OID", Types.INTEGER));
			insertDynamTypes.declareParameter(new SqlParameter("LAST_UPDATE", Types.TIMESTAMP));
			insertDynamTypes.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

			insertDynamTypes.compile();


			Object[] parameterValues = new Object[]{appName,type,new Integer(order),new Integer(langOid),lastUpdated,lastUpdatedBy};


			insertDynamTypes.update(parameterValues);
			status = true;
			deleteLangCache();
		} catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");

		responseMap.put("status",new Boolean(status));

		return responseMap;

	}


	class SelectAllDynamTypes extends JdbcDaoSupport{
		private String sql;
		public SelectAllDynamTypes(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map<String,String>  getAllDynamTypes(Object[] params) {
			final String METHOD_NAME = "getAllDynamTypes => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {

					HashMap<String,String>  dynamMap =   new HashMap<String,String> ();
					String type = "";
					int id = -1;
					while (rs.next()) {
						 id = rs.getInt("ID");
						 type = rs.getString("APP_NAME").trim()+"----"+rs.getString("TYPE").trim();
						dynamMap.put(Integer.toString(id),type);
					}
					return dynamMap;
				}});
		}
	}


	public Map<String,String> selectAllDynamTypes() throws NCASException {
		final String METHOD_NAME = "selectAllDynamTypes => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try
		{
			SelectAllDynamTypes selectTypes = new SelectAllDynamTypes(SELECT_ALL_DYNAM_TYPES);
			_LOGGER.info(METHOD_NAME+"Exiting");
			return selectTypes.getAllDynamTypes(new Object[]{});
		} catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
	}


	class SelectAllAppName extends JdbcDaoSupport{
		private String sql;
		public SelectAllAppName(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map<String,List>  getAllAppName(Object[] params) {
			final String METHOD_NAME = "getAllAppName => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {

					List<String> appNameList =   new ArrayList<String>();
					HashMap<String,List> appNameMap =   new HashMap<String,List> ();
					String appName = "";
					while (rs.next()) {
						appName = rs.getString("APP_NAME");
						appNameList.add(appName);
					}
					appNameMap.put("appNameList",appNameList);
					return appNameMap;
				}});
		}
	}


	public Map<String, List> selectAllAppName() throws NCASException {
		final String METHOD_NAME = "selectAllAppName => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try
		{
			SelectAllAppName selectAppName = new SelectAllAppName(SELECT_ALL_APP_NAMES);
			_LOGGER.info(METHOD_NAME+"Exiting");
			return selectAppName.getAllAppName(new Object[]{});
		} catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
	}

	class SearchAllType extends JdbcDaoSupport{
		private String sql;
		public SearchAllType(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map<String,List>  getAllType(Object[] params) {
			final String METHOD_NAME = "getAllType => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {

					HashMap<String,List>  allTypeMap =   new HashMap<String,List> ();
					String type = "";
					List retList = new ArrayList();
					while (rs.next()) {
						  type = rs.getString("TYPE");
						  retList.add(type);
					}
					allTypeMap.put("allTypeMap", retList);
					return allTypeMap;
				}});
		}
	}


	public Map<String,List> searchAllType(String searchText,String searchAppName) throws NCASException {
		final String METHOD_NAME = "searchAllType => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try
		{
			SearchAllType searchVal = new SearchAllType(SEARCH_ALL_TYPE_NAMES);
			_LOGGER.info(METHOD_NAME+"Exiting");
			return searchVal.getAllType(new Object[]{searchText,searchAppName });
		} catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
	}


	public Map<String,Boolean> deleteTypeFromDynamText(String id) throws NCASException {
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		String DELETE_TYPE_FROM_DYNAM_TEXT = "DELETE FROM " + getSchemaName() + ".PL_DYNAM_TEXT_T WHERE ID=?";

		_LOGGER.info("Delete SQL: " + DELETE_TYPE_FROM_DYNAM_TEXT);


		try
		{
			_LOGGER.info("Deleting the id:"+id+" from the PL_DYNAM_TEXT_T");
			if(deleteTypeSqlUpdate == null){
				deleteTypeSqlUpdate = new SqlUpdate(getDataSource(),DELETE_TYPE_FROM_DYNAM_TEXT);
				deleteTypeSqlUpdate.declareParameter(new SqlParameter("ID", Types.INTEGER));
				deleteTypeSqlUpdate.compile();
			}
			Object[] parameterValues = new Object[]{new Integer(id)};

			deleteTypeSqlUpdate.update(parameterValues);

			status = true;

			deleteLangCache();

		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.debug("deleteTypeFromDynamText in VAM Failed \n"+vamEx.getMessage());
			_LOGGER.error("deleteTypeFromDynamText in VAM Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info("Exiting deleteTypeFromDynamText");
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}




	class UpdateDynamText extends SqlUpdate{
		public UpdateDynamText(DataSource dataSource){
			super(dataSource,UPDATE_PL_DYNAM_TEXT);
			declareParameter(new SqlParameter(Types.VARCHAR));
			declareParameter(new SqlParameter(Types.TIMESTAMP));
			declareParameter(new SqlParameter(Types.VARCHAR));
			declareParameter(new SqlParameter(Types.INTEGER));
			declareParameter(new SqlParameter(Types.INTEGER));

		}
	}

	public Map<String,Boolean> updateDynamText(String type, String updatedBy, int langOid, int id) throws NCASException{
		final String METHOD_NAME = "updateDynamText => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		_LOGGER.info(METHOD_NAME+"update SQL: " + UPDATE_PL_DYNAM_TEXT);
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		try{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			updateDynamText = new UpdateDynamText(getDataSource());
			updateDynamText.update(new Object[]{type, lastUpdated,updatedBy,new Integer(langOid),new Integer(id)});
			status = true;
			deleteLangCache();
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+"updateDynamText Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		responseMap.put("status",new Boolean(status));
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map<String,Object> insertDynamExcelData(List<DynamText> dynamTextList, String updatedBy) throws NCASException{
		final String METHOD_NAME = "insertDynamExcelData => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		//insert in to pl_dynam_text_t

		String reqID = null;
		String _updatedBy = null;

		if(updatedBy.contains("~")){
			String _temp[] = updatedBy.split("~");
			_updatedBy = _temp[0].toString();
			reqID = _temp[1].toString();
			}else{
			_updatedBy = updatedBy;
			}



		String INSERT_DYNAM_TEXT_SQL = "INSERT INTO  " + getSchemaName() + ".PL_DYNAM_TEXT_T(TYPE, TEXT_ORDER, APP_NAME, LANG_OID, LAST_UPDATE,LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";
		boolean status = false;
		Map<String,Object> responseMap = new HashMap<String,Object>();
		_LOGGER.info(METHOD_NAME+":Insert SQL: " + INSERT_DYNAM_TEXT_SQL);
		List errorTypesList = new ArrayList();
		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				insertDynamSqlUpdate = new SqlUpdate(getDataSource(),INSERT_DYNAM_TEXT_SQL);
				insertDynamSqlUpdate.setReturnGeneratedKeys(true);
				insertDynamSqlUpdate.declareParameter(new SqlParameter("TYPE", Types.VARCHAR));
				insertDynamSqlUpdate.declareParameter(new SqlParameter("TEXT_ORDER", Types.INTEGER));
				insertDynamSqlUpdate.declareParameter(new SqlParameter("APP_NAME", Types.CHAR));
				insertDynamSqlUpdate.declareParameter(new SqlParameter("LANG_OID", Types.INTEGER));
				insertDynamSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATE", Types.TIMESTAMP));
				insertDynamSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				insertDynamSqlUpdate.compile();
				for(int i = 0; i<dynamTextList.size();i++) {
					DynamText dynamText = (DynamText)dynamTextList.get(i);
					Object[] parameterValues = new Object[]{dynamText.getType(),new Integer(dynamText.getOrder()),
																dynamText.getAppName(),selectIDFromLangForName(dynamText.getName()),
																lastUpdated,_updatedBy};

					try{
						insertDynamSqlUpdate.update(parameterValues);
					}catch(Exception sqlExcep)
					{
						_LOGGER.error(METHOD_NAME+"insertDynamExcelData Failed \n"+sqlExcep.getMessage());
						//In case of an error collect the TYPE
						errorTypesList.add(parameterValues[0]);
					}
				}
			status = true;
			_LOGGER.info(METHOD_NAME+"Below are the TYPES that failed. Please check for duplicates:\n"+errorTypesList.toString());
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+"insertDynamExcelData Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");

		responseMap.put("status",new Boolean(status));
		responseMap.put("duplicates", errorTypesList);
		if(reqID!=null){
		updateDynamDup(reqID,"DYNAM", errorTypesList);
		}

		return responseMap;
	}

	class SelectIDFromLangForName extends JdbcDaoSupport{
		private String sql;

		public SelectIDFromLangForName(String sql) {
			this.sql = sql;
		}

		public Integer getIdFromLang(Object[] params) {
			return  (Integer)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {

					int langId = -1;
					while (rs.next()) {
						 langId = rs.getInt("LANG_OID");
					}
					return new Integer(langId);
				}});
		}
	}


	public Integer selectIDFromLangForName(String name) throws NCASException {
		final String METHOD_NAME = "selectIDFromLangForName => ";
		int langOid = -1;
		try{
			selectIDFromLangForName = new SelectIDFromLangForName(SELECT_LANGOID_FROM_LANG);
			langOid = selectIDFromLangForName.getIdFromLang(new Object[]{name.trim()});
			if(langOid == -1)
			{
				//if langOid is -1, it suggests that the NAME doesn't exist in PL_LANG_T. So Add pl_lang_t data for all the langs.
				Map<String,Object> returnMap = insertUnicodeAllData(name,name,LANG_CODE_ENGLISH,0);
				langOid = ((Integer)returnMap.get("langoid")).intValue();

				for(int i = 0; i<excelLangList.size();i++)
				{
					insertUnicodeAllData(name,name,(String)excelLangList.get(i),langOid);
				}
			}
		}catch(Exception vamEx) {
			_LOGGER.error(METHOD_NAME+"selectIDFromLangForName Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		return new Integer(langOid);
	}


			public String selectUnicodeDataFromVAM(String language)
					throws NCASException {
				// TODO Auto-generated method stub
				return null;
			}


//XLS EXPORT
			class CreateTranslationsxls extends JdbcDaoSupport{
				private String sql;
				public CreateTranslationsxls(String sql) {
			       this.sql = sql;
			}
				@SuppressWarnings("unchecked")
					public Map<String,Map<String,String>>  getTranslations(Object[] params) {
						 return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						        public Object extractData(ResultSet rs) throws SQLException {
						        	Map<String,String> translationsMap = null;
						        	Map<String,Map<String,String>> finalMap = new HashMap<String,Map<String,String>>();
						        	String value = "";
						        	String lang = "";
						        	String name = "";
					         while (rs.next()) {
					        	 name = rs.getString("NAME");
					        	 value= rs.getString("VALUE");
					        	 lang= rs.getString("LANG");
					        	 if(name!=null){
					        		 name = name.trim();
					        	 if(finalMap.containsKey(name))
					        	 ((Map)finalMap.get(name)).put((String)reverseLangCodeMap.get((String)NCASIntlUtil.reverseLangMatchMap.get(lang.trim())),value.trim());
					        	 else
					        	 {	 translationsMap = new HashMap<String,String>();
					        		 translationsMap.put((String)reverseLangCodeMap.get((String)NCASIntlUtil.reverseLangMatchMap.get(lang.trim())),value.trim());
					        		 finalMap.put(name,translationsMap);
					        	 }					        	 
					        	 }
					         }
						return finalMap;
					  }});
					}
				}
			
			
			
			
			
			
			class MissTranslationsxls1 extends JdbcDaoSupport{
				private String sql;
				public MissTranslationsxls1(String sql) {
			       this.sql = sql;
			}
				@SuppressWarnings("unchecked")
					public Map<String,Map<String,String>>  getTranslations(Object[] params) {
						 return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						        public Object extractData(ResultSet rs) throws SQLException {
						        	Map<String,String> translationsMap = null;
						        	Map<String,Map<String,String>> finalMap = new HashMap<String,Map<String,String>>();
						        	String value = "";
						        	String lang = "";
						        	String name = "";
					         while (rs.next()) {
					        	 name = rs.getString("NAME");
					        	 value= rs.getString("VALUE");
					        	 lang= rs.getString("LANG");
					        	 if(name!=null){
					        		 name = name.trim();
					        	 if(finalMap.containsKey(name))
					        	 ((Map)finalMap.get(name)).put((String)reverseLangCodeMap.get((String)NCASIntlUtil.reverseLangMatchMap.get(lang.trim())),"");
					        	 else
					        	 {	 translationsMap = new HashMap<String,String>();
					        		 translationsMap.put((String)reverseLangCodeMap.get((String)NCASIntlUtil.reverseLangMatchMap.get(lang.trim())),"");
					        		 finalMap.put(name,translationsMap);
					        	 }
					        	 
					        	 }
					         }
						return finalMap;
					  }});
					}
				}
			
			class MissTranslationsxls2 extends JdbcDaoSupport{
				private String sql;
				public MissTranslationsxls2(String sql) {
			       this.sql = sql;
			}
				@SuppressWarnings("unchecked")
					public Map<String,Map<String,String>>  getTranslations(Object[] params, final Map finalMap) {
						 return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						        public Object extractData(ResultSet rs) throws SQLException {
						        	Map<String,String> translationsMap = null;
						        	String value = "";
						        	String lang = "";
						        	String name = "";
					         while (rs.next()) {
					        	 name = rs.getString("NAME");
					        	 value= rs.getString("VALUE");
					        	 lang= rs.getString("LANG");
					        	 if(name!=null){
					        		 name = name.trim();
					        	 if(finalMap.containsKey(name))
					        	 ((Map)finalMap.get(name)).put((String)reverseLangCodeMap.get((String)NCASIntlUtil.reverseLangMatchMap.get(lang.trim())),value.trim());
					        	 else
					        	 {	 translationsMap = new HashMap<String,String>();
					        		 translationsMap.put((String)reverseLangCodeMap.get((String)NCASIntlUtil.reverseLangMatchMap.get(lang.trim())),value.trim());
					        		 finalMap.put(name,translationsMap);
					        	 }
					        	 
					        	 }
					         }
						return finalMap;
					  }});
					}
				}
			
			
			public Map<String,Map<String,String>> getPLLangMissingDetails() throws NCASException {
				final String METHOD_NAME = "getPLLangMissingDetails() => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				selectAllLanguageDetails();
				_LOGGER.info(" PLLangMissingDetails Query : "+missTranslationsxls2.sql);				
				return missTranslationsxls2.getTranslations(new Object[]{},missTranslationsxls1.getTranslations(new Object[]{}));
		}		
			
			

				public Map<String,Map<String,String>> getPLLangDetails(String missingLangXLS) throws NCASException {
					final String METHOD_NAME = "getPLLangDetails() => ";
					_LOGGER.info(METHOD_NAME+" Entering");
					Map<String, Map<String,String>> languageTranslations = null;
					
					_LOGGER.info("missingLangXLS is "+missingLangXLS);
					if(missingLangXLS != null && missingLangXLS.equals("true")){
						_LOGGER.info("Calling  getPLLangMissingDetails()");
						languageTranslations = getPLLangMissingDetails();
					}else{
						selectAllLanguageDetails();
						languageTranslations = createTranslationsxls.getTranslations(new Object[]{});
					}					
					return languageTranslations;
			}

//ADMIN

			class SelectAllNameDetails extends JdbcDaoSupport{
				private String sql;

				public SelectAllNameDetails(String sql) {
					this.sql = sql;
				}

				@SuppressWarnings("unchecked")
				public Map getSelectAllNameDetails(Object[] params) {
					final String METHOD_NAME = "getSelectAllNameDetails => ";
					_LOGGER.info(METHOD_NAME+"Entering");
					return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						public Object extractData(ResultSet rs) throws SQLException {

							HashMap nameMap =   new HashMap();
							while (rs.next()) {
								String name = rs.getString("NAME");
								nameMap.put(name, name);
							}
							return nameMap;
						}});
				}
			}


			@SuppressWarnings("unchecked")
			public Map selectAllNameDetails(String lang) throws NCASException {
				final String METHOD_NAME = "selectAllNameDetails => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_NAME);
				try{
					selectAllNameDetails = new SelectAllNameDetails(SELECT_NAME);
					return selectAllNameDetails.getSelectAllNameDetails(new Object[]{NCASIntlUtil.langMatchMap.get(lang)});
				}catch(Exception vamEx) {
					_LOGGER.error(METHOD_NAME+"selectAllNameDetails Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
			}

			class SelectAllValueDetails extends JdbcDaoSupport{
				private String sql;

				public SelectAllValueDetails(String sql) {
					this.sql = sql;
				}

				@SuppressWarnings("unchecked")
				public Map getAllValueDetails(Object[] params) {
					final String METHOD_NAME = "getSelectAllValueDetails => ";
					_LOGGER.info(METHOD_NAME+"Entering");
					return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						public Object extractData(ResultSet rs) throws SQLException {

							HashMap valueMap =   new HashMap();
							while (rs.next()) {
								String value = rs.getString("VALUE");
								int langOid = rs.getInt("LANG_OID");
								valueMap.put("getvalue",value);
								valueMap.put("getlangoid",new Integer(langOid));
							}
							return valueMap;
						}});
				}
			}


			@SuppressWarnings("unchecked")
			public Map selectAllValueDetails(String lang,String name) throws NCASException {
				final String METHOD_NAME = "selectAllValueDetails => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_VALUE);
				try{
					selectAllValueDetails = new SelectAllValueDetails(SELECT_VALUE);
					return selectAllValueDetails.getAllValueDetails(new Object[]{NCASIntlUtil.langMatchMap.get(lang),name});
				}catch(Exception vamEx) {
					_LOGGER.error(METHOD_NAME+"selectAllValueDetails Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
			}


			class SelectAllNames extends JdbcDaoSupport{
				private String sql;

				public SelectAllNames(String sql) {
					this.sql = sql;
				}

			@SuppressWarnings("unchecked")
			public List<String> getAllNames(Object[] params) {
				final String METHOD_NAME = "getAllNames => ";
				_LOGGER.info(METHOD_NAME+"Entering");
				return  (List<String>)getDBTemplate().query(sql, params, new ResultSetExtractor() {
					public Object extractData(ResultSet rs) throws SQLException {

						List<String> nameList =   new ArrayList<String>();
						while (rs.next()) {
							String name = rs.getString("NAME");
							nameList.add(name);
						}
						return nameList;
					}});
			}
		}


		@SuppressWarnings("unchecked")
		public List<String> selectAllNames() throws NCASException {
			final String METHOD_NAME = "selectAllNames => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_ALL_NAMES);
			try{
				selectAllNames = new SelectAllNames(SELECT_ALL_NAMES);
				return selectAllNames.getAllNames(new Object[]{});
			}catch(Exception vamEx) {
				_LOGGER.error(METHOD_NAME+"selectAllNames Failed \n"+vamEx.getMessage());
				throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
			}
		}


		class CreateDynamxls extends JdbcDaoSupport{
			private String sql;
			public CreateDynamxls(String sql) {
		       this.sql = sql;
		}
			@SuppressWarnings("unchecked")
				public List<DynamText>  getTranslations(Object[] params) {
					 return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
					        public Object extractData(ResultSet rs) throws SQLException {
					        	List<DynamText> translationsList = new ArrayList<DynamText>();
					        	String type = "";
					        	String appName = "";
					        	int textOrder = 0;
					        	String name = "";
					        	DynamText dynaText = null;
				         while (rs.next()) {
				        	 type= rs.getString("TYPE");
				        	 appName= rs.getString("APP_NAME");
				        	 textOrder= rs.getInt("TEXT_ORDER");
				        	 name= rs.getString("NAME");
				        	 dynaText = new DynamText(type,appName,Integer.toString(textOrder),name);
				        	 translationsList.add(dynaText);
				        }
					return translationsList;
				  }});
				}
			}

			public Map<String,List<DynamText>> getDynaTextDetails() throws NCASException {
				final String METHOD_NAME = "getDynaTextDetails() => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				List<DynamText> dynamList = createDynamxls.getTranslations(new Object[]{});
				Map<String,List<DynamText>> dynamMap = new HashMap<String,List<DynamText>>();
				dynamMap.put("dynaText", dynamList);
				_LOGGER.info(METHOD_NAME+" Exiting");
				return dynamMap;
		}

			public String createRequestID(String updatedBy) throws NCASException{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				String createdTime = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				if (request_id == 0) {
					request_id = getGeneratedKey(selectRequestId());
				} else {
					request_id++;
				}
				InetAddress ia = null;
				String hostname = "Server";
				try{
					ia = InetAddress.getLocalHost();
					hostname = ia.getHostName();
				}catch(UnknownHostException uhe){
					uhe.printStackTrace();
				}
				String INSERT_LOG = "INSERT into " + getSchemaName() + ".PL_REQSTATUS(REQUEST_ID,TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,PARAM6,PARAM7,STATUS,ITERATION,ERROR_MSG,PORTAL,EMPLOYEE_FLAG,LOGINID,LAST_UPDATED_BY,LAST_UPDATED,CREATED_TIMESTAMP)" + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				insertDynamdupSqlUpdate = new SqlUpdate(getDataSource(),INSERT_LOG);
				insertDynamdupSqlUpdate.setReturnGeneratedKeys(true);
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("REQUEST_ID",Types.INTEGER));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("TYPE",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM1",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM2",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM3",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM4",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM5",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM6",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PARAM7",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("STATUS",Types.CHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("ITERATION",Types.INTEGER));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("ERROR_MSG",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("PORTAL",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("EMPLOYEE_FLAG",Types.CHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("LOGINID",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED_BY",Types.VARCHAR));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("LAST_UPDATED",Types.TIMESTAMP));
				insertDynamdupSqlUpdate.declareParameter(new SqlParameter("CREATED_TIMESTAMP",Types.TIMESTAMP));
				insertDynamdupSqlUpdate.compile();
				Object[] parameterValues = new Object[]{new Integer(request_id),"","",hostname,"","","","","","",1,"","","",updatedBy,updatedBy,lastUpdated,createdTime};
						try{
						insertDynamdupSqlUpdate.update(parameterValues);
						// _LOGGER.info("The request id that got inserted is "+request_id);
						}catch(Exception sqlExcep)
						{
						_LOGGER.error("createRequestID Failed \n"+sqlExcep.getMessage());
						}
				return Integer.toString(request_id);
			}

			private int getGeneratedKey(List currentKeyList) {
				int maxLinkNbrPlusOne = 0;
				int maxValueCalculated = 0;
				if (currentKeyList != null && currentKeyList.size() > 0) {
					maxValueCalculated = ((Integer) Collections.max(currentKeyList))
							.intValue();
				}
				maxLinkNbrPlusOne = maxValueCalculated + 1;
				return maxLinkNbrPlusOne;
			}

			class UpdateDynamDup extends SqlUpdate{
				public UpdateDynamDup(DataSource dataSource){
					super(dataSource,UPDATE_PL_DYNAM_DUP);
					declareParameter(new SqlParameter(Types.VARCHAR));
					declareParameter(new SqlParameter(Types.VARCHAR));
					declareParameter(new SqlParameter(Types.INTEGER));
				}
			}

			public void updateDynamDup(String reqID, String type, List errorTypesList) throws NCASException{
				final String METHOD_NAME = "UpdateDynamDup => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				_LOGGER.info(METHOD_NAME+"update SQL: " + UPDATE_PL_DYNAM_DUP);
				StringBuffer sb = new StringBuffer();
				StringBuffer _fileReturn = new StringBuffer();
				for(int i=0;i<errorTypesList.size();i++){
					if(i>0)
					sb.append(",");
					sb.append(errorTypesList.get(i));
				}
				try{
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
					updateDynamDup = new UpdateDynamDup(getDataSource());
					if(sb.length()> 950)
				     {
						_fileReturn = writeDuplicatestofile(sb, reqID);
						updateDynamDup.update(new Object[]{_fileReturn,type,new Integer(Integer.parseInt(reqID))});
				     }else{
				        updateDynamDup.update(new Object[]{sb,type,new Integer(Integer.parseInt(reqID))});
				     }
				}catch(Exception vamEx) {
					_LOGGER.error(METHOD_NAME+"UpdateDynamDup Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
			}

			class SelectRequestId extends AbstractSelect {
				public SelectRequestId(DataSource dataSource) {
					super(dataSource, SELECT_REQUEST_ID);
				}

				protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
					int request_id = rs.getInt("REQUEST_ID");
					requestList.add(new Integer(request_id));
					return requestList;
				}
			}


			public List selectRequestId() throws NCASException{

				requestList = new ArrayList();
				selectRequestId = new SelectRequestId(getDataSource());
				selectRequestId.execute(new Object[] {});
				_LOGGER.info("Exiting SelectRequestId");
				return requestList;
			}

			class GetDuplicates extends JdbcDaoSupport{
				private String sql;

				public GetDuplicates(String sql) {
					this.sql = sql;
				}

				@SuppressWarnings("unchecked")
				public List getDuplicateID(Object[] params) {
					final String METHOD_NAME = "getDuplicateID => ";
					_LOGGER.info(METHOD_NAME+"Entering");
					return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						public Object extractData(ResultSet rs) throws SQLException {

							List idList =   new ArrayList();
							while(rs.next())
							{
								String req_id = Integer.toString(rs.getInt("REQUEST_ID"));
								idList.add(req_id);
							}
							return idList;
						}});
				}
			}

			public List getDuplicates(String type) throws NCASException{
				final String METHOD_NAME = "getDuplicates => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_ALL_DUPLICATE_IDS);
				try{
					getDuplicates = new GetDuplicates(SELECT_ALL_DUPLICATE_IDS);
					return getDuplicates.getDuplicateID(new Object[]{type});
				}catch(Exception vamEx) {
					_LOGGER.error(METHOD_NAME+"getDuplicates Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
			}

			class GetDuplicateMsg extends JdbcDaoSupport{
				private String sql;

				public GetDuplicateMsg(String sql) {
					this.sql = sql;
				}

				@SuppressWarnings("unchecked")
				public List getDuplicateCode(Object[] params) {
					final String METHOD_NAME = "getDuplicateCode => ";
					_LOGGER.info(METHOD_NAME+"Entering");
					return  (List)getDBTemplate().query(sql, params, new ResultSetExtractor() {
						public Object extractData(ResultSet rs) throws SQLException {

							List idList =   new ArrayList();
							while(rs.next())
							{
								String msg = rs.getString("ERROR_MSG");
								idList.add(msg);
							}
							return idList;
						}});
				}
			}

			public List getDuplicateMsg(int reqID) throws NCASException{
				final String METHOD_NAME = "getDuplicateMsg => ";
				_LOGGER.info(METHOD_NAME+" Entering");
				_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_ALL_DUPLICATE_MSG);
				try{
					getDuplicateMsg = new GetDuplicateMsg(SELECT_ALL_DUPLICATE_MSG);
					return getDuplicateMsg.getDuplicateCode(new Object[]{new Integer(reqID)});
				}catch(Exception vamEx) {
					_LOGGER.error(METHOD_NAME+"getDuplicates Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
			}

			public StringBuffer writeDuplicatestofile(StringBuffer sb, String reqID)throws NCASException{
				StringBuffer _toreturn = new StringBuffer();
				String uploadDirectory = Config.getProperty("sapient.billing_cfg", "verizon.billing.Admintool.VAMUpload");
				File file = new File(uploadDirectory+"/"+reqID+".txt");
				FileWriter fw = null;
				BufferedWriter bw = null;
					  try {
						    fw = new FileWriter(file,true);
							bw = new BufferedWriter(fw);
						    bw.write(sb.toString());
						    _toreturn.append("Since Duplicates List size exceeds >950 char,its written to a file" +
						    		    "under the path"+uploadDirectory+"/"+reqID+".txt.");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							_toreturn.append("Sorry! File Writing Failed.");
						}finally{
							try {
								bw.close();
								fw.close();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						return _toreturn;
			    }
	@SuppressWarnings("unchecked")
	public Map updateLangData(Map langDataMap) throws NCASException {
		final String METHOD_NAME = "updateLangData => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String UPDATE_LANG_DATA = "UPDATE " + getSchemaName() + ".PL_LANG_T SET  VALUE=? WHERE LANG = ? and NAME=?";
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		LangData langData;
		_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_LANG_DATA);

		try
		{

			if(updateLangSqlUpdate == null){
				updateLangSqlUpdate = new BatchSqlUpdate(getDataSource(),UPDATE_LANG_DATA);
				updateLangSqlUpdate.declareParameter(new SqlParameter("VALUE", Types.VARCHAR));
				updateLangSqlUpdate.declareParameter(new SqlParameter("LANG", Types.CHAR));
				updateLangSqlUpdate.declareParameter(new SqlParameter("NAME", Types.VARCHAR));
				updateLangSqlUpdate.compile();
			}
			List langDataList = (List)langDataMap.get("langMap");
			for(int i = 0; i<langDataList.size(); i++)
			{
				langData = (LangData)langDataList.get(i);
				_LOGGER.debug("LangData::"+langData.toString());
				updateLangSqlUpdate.update(new Object[]{langData.getValue(),langData.getLang(),langData.getName()});
			}
			updateLangSqlUpdate.flush();
			status = true;
			responseMap.put("status",new Boolean(status));
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"updateLangData Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map updateLangDataToEnglish(String langs) throws NCASException {
		final String METHOD_NAME = "updateLangDataToEnglish => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String UPDATE_LANG_TO_ENG = "UPDATE " + getSchemaName() + ".PL_LANG_T SET  VALUE=NAME WHERE LANG IN('";
		boolean status = false;
		Map<String,Boolean> responseMap = new HashMap<String,Boolean>();
		_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_LANG_TO_ENG);

		try
		{
			StringBuffer sb = new StringBuffer();
			sb.append(UPDATE_LANG_TO_ENG);
			if(langs.indexOf(',')!=-1)
			{
				//multiple langs present.
				StringTokenizer st = new StringTokenizer(langs, ",");
				int numTokens = st.countTokens();
				int i = 0;
				while (st.hasMoreElements())
					{
					String token = st.nextToken();
					if(i!=numTokens -1 )
					{
						sb.append(token).append("','");
						i++;
					}
					else{
						sb.append(token).append("'");
					}
					}


			}else
			{
				sb.append(langs).append("'");
			}
			sb.append(");");
			_LOGGER.debug(METHOD_NAME+"The query now is:"+sb.toString());
			if(updateLangToEnglishSqlUpdate == null){
				updateLangToEnglishSqlUpdate = new SqlUpdate(getDataSource(),sb.toString());
				updateLangToEnglishSqlUpdate.compile();
			}
			updateLangToEnglishSqlUpdate.update();
			status = true;
			responseMap.put("status",new Boolean(status));
		} catch(Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER.error(METHOD_NAME+"updateLangDataToEnglish Failed \n"+vamEx.getMessage());
			throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}
	
	 public String getTranslation(String value, String lang) {
			return simpleTranslation.getTranslation(lang,value);
	  }
	 
	//For Search Data - Subbu
		public Map<String,Object> processSearchData(SearchAppsData searchAppsData, String updatedBy, String method) throws NCASException {
			final String METHOD_NAME = "processSearchData => ";
			_LOGGER.info(METHOD_NAME+"Entering");
			Map<String,Object> responseMap = null;
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
	       	String lastUpdTimestamp = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
	       
	       	int appId = searchAppsData.getAppId();
	       	String keyword = searchAppsData.getKeyword();
	       	int rank = searchAppsData.getRank();
	       	String portal = searchAppsData.getPortal();
	       	       	
	       	//Object[] parameterValues = new Object[]{appId,keyword,rank,portal,updatedBy,lastUpdTimestamp};
	       	//Object[] updateParameterValues = new Object[]{rank,portal,updatedBy,lastUpdTimestamp,appId,keyword};
	       	//Object[] deleteAppIdParameterValues = new Object[]{appId,portal};
	       	//Object[] deleteAppIdKeyParameterValues = new Object[]{appId,portal,keyword};
			
			if("insertSearchdata".equalsIgnoreCase(method)) {
				//TODO check the keyword and rank availability in the DB, if its there throw an exception.
				boolean status = false;
				responseMap = new HashMap<String,Object>();
				Object[] parameterValues = new Object[]{appId,keyword,rank,portal,updatedBy,lastUpdTimestamp};
				_LOGGER.info(METHOD_NAME+"Insert SQL: " + INSERT_SEARCH_DATA);
				try
				{
					_LOGGER.info(METHOD_NAME+"appId::"+appId+"::keyWord::"+keyword+"::portal::"+portal+"::rank::"+rank+"::updatedBy::"+updatedBy);
		
					if(insertSearchSqlUpdate == null){
						insertSearchSqlUpdate = new SqlUpdate(getDataSource(),INSERT_SEARCH_DATA);
						insertSearchSqlUpdate.setReturnGeneratedKeys(true);
						insertSearchSqlUpdate.declareParameter(new SqlParameter("APP_ID", Types.INTEGER));
						insertSearchSqlUpdate.declareParameter(new SqlParameter("KEYWORD", Types.VARCHAR));
						insertSearchSqlUpdate.declareParameter(new SqlParameter("RANK", Types.INTEGER));
						insertSearchSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
						insertSearchSqlUpdate.declareParameter(new SqlParameter("PORTAL_LOGIN_ID",Types.VARCHAR));
						insertSearchSqlUpdate.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP",Types.VARCHAR));
						insertSearchSqlUpdate.compile();
					}
					
					insertSearchSqlUpdate.update(parameterValues);
		
					status = true;
					responseMap.put("status",new Boolean(status));
				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.error(METHOD_NAME+"insertSearchData Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
			}else if("updateSearchdata".equalsIgnoreCase(method)){
				boolean status = false;
				responseMap = new HashMap<String,Object>();
				Object[] updateParameterValues = new Object[]{rank,portal,updatedBy,lastUpdTimestamp,appId,keyword};
				_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_SEARCH_DATA);
				try
				{
					_LOGGER.info(METHOD_NAME+"appId::"+appId+"::keyWord::"+keyword+"::portal::"+portal+"::rank::"+rank+"::updatedBy::"+updatedBy);
					
					if(updateSearchSqlUpdate == null){
						updateSearchSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_SEARCH_DATA);										
						updateSearchSqlUpdate.declareParameter(new SqlParameter("RANK", Types.INTEGER));
						updateSearchSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
						updateSearchSqlUpdate.declareParameter(new SqlParameter("PORTAL_LOGIN_ID",Types.VARCHAR));
						updateSearchSqlUpdate.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP",Types.VARCHAR));
						updateSearchSqlUpdate.declareParameter(new SqlParameter("APP_ID", Types.INTEGER));
						updateSearchSqlUpdate.declareParameter(new SqlParameter("KEYWORD", Types.VARCHAR));
						updateSearchSqlUpdate.compile();
					}
					
					int updCount = updateSearchSqlUpdate.update(updateParameterValues);
					if (updCount > 0) {
				        _LOGGER.info( "Update Rank  Response logged successfully \n Number of Records updated - " + updCount);
				        status = true;
				    }				 	
					
					responseMap.put("status",new Boolean(status));
				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.error(METHOD_NAME+"updateSearchData Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
				
			}else if("updateAutoSearchdata".equalsIgnoreCase(method)){
				boolean status = false;
				responseMap = new HashMap<String,Object>();
				
				Object[] updateAutoParameterValues = new Object[]{rank,updatedBy,lastUpdTimestamp,appId};
				_LOGGER.info(METHOD_NAME+"Update SQL: " + UPDATE_AUTO_SEARCH_DATA);
				try
				{
					_LOGGER.info(METHOD_NAME+"searchId::"+appId+"::keyWord::"+keyword+"::portal::"+portal+"::rank::"+rank+"::updatedBy::"+updatedBy);
					
					if(updateAutoSearchSqlUpdate == null){
						updateAutoSearchSqlUpdate = new SqlUpdate(getDataSource(),UPDATE_AUTO_SEARCH_DATA);										
						updateAutoSearchSqlUpdate.declareParameter(new SqlParameter("RANK", Types.INTEGER));						
						updateAutoSearchSqlUpdate.declareParameter(new SqlParameter("PORTAL_LOGIN_ID",Types.VARCHAR));
						updateAutoSearchSqlUpdate.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP",Types.VARCHAR));
						updateAutoSearchSqlUpdate.declareParameter(new SqlParameter("SEARCH_ID", Types.INTEGER));						
						updateAutoSearchSqlUpdate.compile();
					}
					
					int updCount = updateAutoSearchSqlUpdate.update(updateAutoParameterValues);
					if (updCount > 0) {
				        _LOGGER.info( "Update Rank  Response logged successfully \n Number of Records updated - " + updCount);
				        status = true;
				    }				 	
					
					responseMap.put("status",new Boolean(status));
				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.error(METHOD_NAME+"updateAutoSearchdata Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
				
			}else if("deleteSearchData".equalsIgnoreCase(method)){
				boolean status = false;
				responseMap = new HashMap<String,Object>();
				Object[] deleteAppIdParameterValues = new Object[]{appId,portal};			
		       	
				try
				{
					_LOGGER.info(METHOD_NAME+"appId::"+appId+"::keyWord::"+keyword+"::portal::"+portal+"::updatedBy::"+updatedBy);
					_LOGGER.info(METHOD_NAME+"DELETE SQL: " + DELETE_APPID_SEARCH_DATA);
					
					if(deleteAppIdSqlUpdate == null){
						deleteAppIdSqlUpdate = new SqlUpdate(getDataSource(),DELETE_APPID_SEARCH_DATA);
						deleteAppIdSqlUpdate.declareParameter(new SqlParameter("APP_ID", Types.INTEGER));						
						deleteAppIdSqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));						
						deleteAppIdSqlUpdate.compile();							
					}
					
					int delCount = deleteAppIdSqlUpdate.update(deleteAppIdParameterValues);
					
					if (delCount > 0) {
				        _LOGGER.info( "Delete AppId  Response logged successfully \n Number of Records updated - " + delCount);
				        status = true;
				    }				
					
				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.error(METHOD_NAME+"updateSearchData Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}				
				responseMap.put("status",new Boolean(status));
				
			}else if("deleteSearchKeydata".equalsIgnoreCase(method)){
				boolean status = false;
				responseMap = new HashMap<String,Object>();
				Object[] deleteAppIdParameterValues = new Object[]{appId,portal,keyword};			
		       	
				try
				{
					_LOGGER.info(METHOD_NAME+"appId::"+appId+"::keyWord::"+keyword+"::portal::"+portal+"::updatedBy::"+updatedBy);
						
					_LOGGER.info(METHOD_NAME+"DELETE SQL: " + DELETE_KEYWORD_SEARCH_DATA);
					if(deleteAppIdKeySqlUpdate == null){
						deleteAppIdKeySqlUpdate = new SqlUpdate(getDataSource(),DELETE_KEYWORD_SEARCH_DATA);
						deleteAppIdKeySqlUpdate.declareParameter(new SqlParameter("APP_ID", Types.INTEGER));						
						deleteAppIdKeySqlUpdate.declareParameter(new SqlParameter("PORTAL", Types.VARCHAR));
						deleteAppIdKeySqlUpdate.declareParameter(new SqlParameter("KEYWORD", Types.VARCHAR));
						deleteAppIdKeySqlUpdate.compile();
					}
					
					int delCount = deleteAppIdKeySqlUpdate.update(deleteAppIdParameterValues);
					
					
					if (delCount > 0) {
				        _LOGGER.info( "Delete AppId  Response logged successfully \n Number of Records updated - " + delCount);
				        status = true;
				    }					
				} catch(Exception vamEx) {
					vamEx.printStackTrace();
					_LOGGER.error(METHOD_NAME+"updateSearchData Failed \n"+vamEx.getMessage());
					throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
				}
								
				responseMap.put("status",new Boolean(status));
			}
			else if("selectSearchData".equalsIgnoreCase(method)){
				boolean status = false;
				responseMap = new HashMap<String,Object>();
				_LOGGER.info(METHOD_NAME+"SELECT SQL: " + SELECT_SEARCH_APPS_DATA);
				SearchAppsData resultSearchAppsData = selectSearchData(appId, portal);
				
				status = true;
				responseMap.put("status",new Boolean(status));
				responseMap.put("result", resultSearchAppsData);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return responseMap;
		}
		
		@SuppressWarnings("unchecked")
		public Map<String,List> selectReasonsDetails()  throws NCASException{
			final String METHOD_NAME = "selectReasonsDetails => ";
			_LOGGER.info(METHOD_NAME+" Entering");				
			Map<String,List> valueMap =   new HashMap<String,List>();
			try{
				_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_REASONS_MSG);
				selectReasonsDetails = new SelectReasonsDetails(SELECT_REASONS_MSG);			
				List<Reason> reasonList = selectReasonsDetails.getReasons();			
				
				_LOGGER.info(METHOD_NAME+"Select SQL for actual reasons: " + SELECT_UPDATE_DELETE_REASONS_MSG);
				selectReasonsDetails = new SelectReasonsDetails(SELECT_UPDATE_DELETE_REASONS_MSG);
				List<Reason> updateReasonList = selectReasonsDetails.getReasons();
				
				valueMap.put("LIST", reasonList);
				valueMap.put("UPDLIST", updateReasonList);
				
				return valueMap;
			}catch(Exception vamEx) {
				_LOGGER.error(METHOD_NAME+"selectReasonsDetails Failed \n"+vamEx.getMessage());
				throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
			}
		}
		
		class SelectReasonsDetails extends JdbcDaoSupport{
			private String sql;

			public SelectReasonsDetails(String sql) {
				this.sql = sql;
			}

			@SuppressWarnings("unchecked")
			public List getReasons() {
				final String METHOD_NAME = "getReasons => ";
				_LOGGER.info(METHOD_NAME+"Entering");
				return  (List)getDBTemplate().query(sql, new ResultSetExtractor() {
					public Object extractData(ResultSet rs) throws SQLException {

						//Map<String,List> valueMap =   new HashMap<String,List>();					
						List<Reason> reasonList = new ArrayList<Reason>();
						while(rs.next())
						{
							int reasonId = rs.getInt("REASON_ID");
							String reasonDesc = rs.getString("REASON_DESC");
							Reason reason = new Reason();
							reason.setReasonId(reasonId);
							reason.setDesc(reasonDesc);
							reasonList.add(reason);
						}
						//valueMap.put("LIST", reasonList);
						return reasonList;
					}});
			}
		}
		
		@SuppressWarnings("unchecked")
		public SearchAppsData selectSearchData(int appId, String portal) throws NCASException {
			final String METHOD_NAME = "selectSearchData => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_SEARCH_APPS_DATA);
			try{
				selectSearchAppData = new SelectSearchAppData(SELECT_SEARCH_APPS_DATA);
				return selectSearchAppData.getSearchData(new Object[]{new Integer(appId), portal});
			}catch(Exception vamEx) {
				_LOGGER.error(METHOD_NAME+"selectSearchData Failed \n"+vamEx.getMessage());
				throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
			}
		}
		
		class SelectSearchAppData extends JdbcDaoSupport{
			private String sql;

			public SelectSearchAppData(String sql) {
				this.sql = sql;
			}

			@SuppressWarnings("unchecked")
			public SearchAppsData getSearchData(Object[] params) {
				final String METHOD_NAME = "getSearchData => ";
				_LOGGER.info(METHOD_NAME+"Entering");
				return  (SearchAppsData)getDBTemplate().query(sql, params, new ResultSetExtractor() {
					public Object extractData(ResultSet rs) throws SQLException {
						
						SearchAppsData searchAppsData = new SearchAppsData();
						Map<String, Integer> keywordRankMap = new HashMap<String, Integer>();
						int appId=61;
						String portal="VBCIBR";
						//APP_ID, KEYWORD, RANK, PORTAL
						List<String> nameList =   new ArrayList<String>();
						while (rs.next()) {							
							appId = rs.getInt("APP_ID");
							portal = rs.getString("PORTAL");
							String keyword = rs.getString("KEYWORD");
							int rank = rs.getInt("RANK");
							keywordRankMap.put(keyword, new Integer(rank));
						}
						searchAppsData.setAppId(appId);
						searchAppsData.setPortal(portal);
						searchAppsData.setKeywordRanks(keywordRankMap);
						return searchAppsData;
					}});
			}
		}
		
		@SuppressWarnings("unchecked")
		public Map<String,List> selectKeywords(String key, String portal)  throws NCASException{
			final String METHOD_NAME = "selectKeywords => ";
			_LOGGER.info(METHOD_NAME+" Entering");				
			Map<String,List> valueMap =   null;
			StringBuffer strKey = new StringBuffer();
			strKey.append("%");
			strKey.append(key);
			strKey.append("%");
			_LOGGER.info(" Searching Key is "+strKey.toString());
			try{
				_LOGGER.info(METHOD_NAME+"Select SQL: " + SELECT_KEYWORDS);
				selectKeywordDetails = new SelectKeywordDetails(SELECT_KEYWORDS);			
				valueMap = selectKeywordDetails.getKeywords(new Object[]{portal,strKey.toString()});			
				return valueMap;
				
			}catch(Exception vamEx) {
				_LOGGER.error(METHOD_NAME+"selectKeywords Failed \n"+vamEx.getMessage());
				throw new NCASException(INTERNATIONAL_EXCEPTION_950,InternationalDAOImpl.class,vamEx);
			}
		}
		
		class SelectKeywordDetails extends JdbcDaoSupport{
			private String sql;

			public SelectKeywordDetails(String sql) {
				this.sql = sql;
			}

			@SuppressWarnings("unchecked")
			public Map<String,List> getKeywords(Object[] params) {
				final String METHOD_NAME = "getKeywords => ";
				_LOGGER.info(METHOD_NAME+"Entering");				
				return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
					public Object extractData(ResultSet rs) throws SQLException {

						Map<String,List> valueMap =   new HashMap<String,List>();					
						List<SearchAppsData> keywordList = new ArrayList<SearchAppsData>();
						
						while(rs.next())
						{
							int searchId = rs.getInt("SEARCH_ID");
							String keyword = rs.getString("KEYWORD");
							int rank = rs.getInt("RANK");
							SearchAppsData data = new SearchAppsData();
							data.setAppId(searchId);
							data.setKeyword(keyword);
							data.setRank(rank);
							keywordList.add(data);
						}						
						valueMap.put("KEYLIST", keywordList);
						return valueMap;
					}});
			}
		}
	
}




