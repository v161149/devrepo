package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.io.Serializable;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


/**
 * @author V238591
 *
 */
public class SPUserAccounts extends BaseStoredProcedure {
		static private final Logger _LOGGER = Logger.getLogger(SPUserAccounts.class);
		private static List<Object[]> spInOutList;
		private static GetAccountListRowMapperImpl acctsrowMapper;

		public SPUserAccounts(DataSource dataSource, String schemaName, String storedProcName)
		{
			super(dataSource, schemaName + "." + storedProcName, spInOutList);
		}

		static
		{
			 spInOutList = new ArrayList<Object[]>();
			 acctsrowMapper = new GetAccountListRowMapperImpl();

			 spInOutList.add(new Object[]{"acctList",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,acctsrowMapper});
			 spInOutList.add(new Object[]{"LOGIN_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"RTN_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		}

		public Map<String, Serializable> executeStoredProcedure(String userId, String debugLevel, Map params) throws Exception
		{
			String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
			List paramValueList = new ArrayList();

			String portalUserID  = (String) params.get("LOGINID");

			paramValueList.add(portalUserID);    
			paramValueList.add("1");

			Map procMap = executeStoredProcedure(paramValueList);
			int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
			String debugStr = (String)procMap.get("ERROR_TEXT");
			if (debugStr == null) {
			    debugStr = "";
			}
			if( returnCode > 0 ) {
                    _LOGGER.error("In executeStoredProcedure - debugStr = " + debugStr);
					String[] errMsg = new String[3];
				    errMsg[0] = "getBillView";
				    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_EXT_BILL_VIEW;
				    errMsg[2] = debugStr;
				    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}
			procMap.put("userId", portalUserID);

			return procMap;
		}



		public Map executeStoredProcedure(Object paramValues)throws Exception
		{
			List paramValueList = (List) paramValues;
			return executeSP(paramValueList, false);
		}


}


