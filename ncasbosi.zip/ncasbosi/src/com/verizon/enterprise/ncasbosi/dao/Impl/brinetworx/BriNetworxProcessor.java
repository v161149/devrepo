package com.verizon.enterprise.ncasbosi.dao.Impl.brinetworx;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.brinetworx.BriNetworxInterface;


/*
 * This class decides which operation to be performed
 */
public class BriNetworxProcessor {
	private static BriNetworxInterface interfaceObj;
	private static final Logger _LOGGER = Logger.getLogger(BriNetworxProcessor.class);
	
	private static synchronized BriNetworxInterface getBRIObject(){
		if(interfaceObj==null){
			_LOGGER.info("Getting the singleton BriNetworx Object");
			interfaceObj = DAOFactory.getInstance().getBriNetworxImplementationReference();
			_LOGGER.info("Successfully retrieved handle to the BriNetworx Object");
		}
		return interfaceObj;
	}
	
	public static Map processBriNetworx(Object input,String function)throws NCASException{
		_LOGGER.info("Entering processBriNetworx");
		Map responseMap = null;
		try{
			Method method = getBRIObject().getClass().getMethod(function, new Class[]{Object.class});
			responseMap = (Map)method.invoke(getBRIObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException("HI1002",BriNetworxProcessor.class,exception.getTargetException());
		}catch(Exception exception){
			throw new NCASException("HI1002",BriNetworxProcessor.class,exception);
		}
		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processBriNetworx");
		return responseMap;
	}	
}
