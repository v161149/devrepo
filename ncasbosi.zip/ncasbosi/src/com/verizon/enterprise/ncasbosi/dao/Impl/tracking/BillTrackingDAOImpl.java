package com.verizon.enterprise.ncasbosi.dao.Impl.tracking;



import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.dao.Interface.tracking.BillTrackingInterface;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.bills.BillTrackingVO;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;


public class BillTrackingDAOImpl  extends NCASSpringJDBCBase implements BillTrackingInterface , NCASBOSIConstants
{
	static private final Logger _LOGGER = Logger.getLogger(BillTrackingDAOImpl.class);
	

  public Map trackBillEntity (BillTrackingVO bt)throws NCASException
  {
		 _LOGGER.info("Entering trackBillEntity");
		 _LOGGER.info("bill tracking vo: "+bt);
		 
		 Map resMap = null;
		 
		 try
		 {
			 //Calling GetBI in VAC
			 SPBillTracking trackSP = new SPBillTracking(getDataSource());
			 resMap = trackSP.executeStoredProcedure(bt);
			 _LOGGER.info("trackBillEntity successful");
		 }	 
		catch(NCASException nex)
		{
			_LOGGER.error("rethrowing exception occured in the trackBillEntity "+nex);
			_LOGGER.debug("rethrowing exception occured in the trackBillEntity "+nex);
		}
		catch(Exception biEx)
		{
			_LOGGER.error("trackBillEntity rethrowing exception occured in while identifying category "+biEx);
			_LOGGER.debug("trackBillEntity rethrowing exception occured in while identifying category "+biEx);
		}

		_LOGGER.info("Exiting trackBillEntity -->  " + resMap);
	return 	resMap;

	}

} //end BillTrackingDAOImpl