package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * Author:Chris Carroll
 * This class represents the api VAR.UPDATE_VZB_ADJ
 */

public class SPUpdateAdjustments extends BaseStoredProcedure
{
	private static final Logger logger = Logger.getLogger(SPUpdateAdjustments.class);
	private static List spInOutList;

	static
	{
		final String METHOD_NAME = "SPUpdateAdjustments::static() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		spInOutList = new ArrayList();

		spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"VAC_ADJUST_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"USER_ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"SERVICE_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"LAST_UPD_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"LAST_UPD_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"LAST_UPD_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"LAST_UPD_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"LAST_UPD_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"LAST_UPD_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"VZB_REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"SUB_CAT_CD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"SVC_TYPE_CD", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		//output fields specifying the behaviour of the execution of SP
		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		spInOutList.add(new Object[]{"POSTING_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"BATCH_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"ADJ_CLASSIF_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"ADDL_REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"REV_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPUpdateAdjustments(DataSource dataSource)
	{
		super(dataSource, getVACSchemaName() + "." + NCASBOSIConstants.SP_UPDATE_VZB_ADJ, spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception
	{
		final String METHOD_NAME = "SPUpdateAdjustments::executeStoredProcedure(Object) ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		logger.info(METHOD_NAME + "ExecuteStoredProcedure in " + getStoredProcedureName());

		Map inputMap = (Map) input;

		//convert adjustment id to bigDecial, if came in as null set to null
		String adjId = (String) inputMap.get("VAC_ADJUST_ID");
		BigDecimal adjIdBd = null;

		if (adjId != null)
		{
			adjIdBd = new BigDecimal(adjId);
		}

		String batchId = (String) inputMap.get("BATCH_ID");

		if ("".equals(batchId))
		{
			batchId = null;
		}

		List inputList = new ArrayList();
		inputList.add((String) inputMap.get("ESG_CLAIM_NUMBER"));
		inputList.add(adjIdBd);
		inputList.add((String) inputMap.get("USER_ACTION"));
		inputList.add((String) inputMap.get("SERVICE_ID"));
		inputList.add((String) inputMap.get("LAST_UPD_VZID"));
		inputList.add((String) inputMap.get("LAST_UPD_NAME"));
		inputList.add((String) inputMap.get("LAST_UPD_FIRST"));
		inputList.add((String) inputMap.get("LAST_UPD_LAST"));
		inputList.add((String) inputMap.get("LAST_UPD_MID_IN"));
		inputList.add((String) inputMap.get("LAST_UPD_SUFF"));
		inputList.add((String) inputMap.get("VZB_REASON_CODE"));
		inputList.add((String) inputMap.get("SUB_CAT_CD"));
		inputList.add((String) inputMap.get("SVC_TYPE_CD"));
        inputList.add((String) inputMap.get("POSTING_LEVEL"));
        inputList.add(batchId);
        inputList.add((String) inputMap.get("ADJ_CLASSIF_CODE"));
        inputList.add((String) inputMap.get("ADDL_REASON_CODE"));
        inputList.add((String) inputMap.get("REV_CODE"));

		Map resMap = executeSP(inputList, false);

		logger.info(METHOD_NAME + "resMap=" + resMap);

		checkVACErrors(resMap);

		logger.info(METHOD_NAME + "EXIT");

		return resMap;
	}
}
