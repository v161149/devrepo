package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.ServiceId;

/*
 * Author:Ram/v992473
 */

public class GetServiceIdsMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetServiceIdsMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetServiceIdsMapper - Mapping Row# "+rowNum);
		ServiceId si = null;
		if(rs!=null){
			si = new ServiceId();
			si.setValue(rs.getString("LOCATION_ID"));
		}
		return si;
	}
}
