package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.autocredit.CalcDetail;
import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/**
 * @author v992473
 *
 */

public class SPUpdateCalcDetail extends BaseStoredProcedure{

	private static final Logger _LOGGER = Logger.getLogger(SPUpdateCalcDetail.class);
	private static List spInOutList;
	
	static{
		_LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
		 spInOutList.add(new Object[]{"CALC_DTL_ID",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BATCH_ID",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DELETE_IND",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NET_AVAIL_DISC_PER",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MTTR_DISC_PER",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DAYS_OF_CREDIT",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CORRECT_BILL_RATE",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CORRECT_DISC_PER",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CORRECT_PROMO_RATE",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 		 
		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPUpdateCalcDetail(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_UPDATE_CALC_DTL, spInOutList);
	}
	
	public Map executeStoredProcedure(Object paramValueObj) throws Exception {
		
		/* get input values */
		Map inputMap = (Map)paramValueObj;
		String batchId = null;
		String deleteInd = null;
		String calcDetailId = null;
		String netAvailDiscPer = null;
		String mttrDiscPer = null;
		String daysOfCredit = null;
		String correctBillRate = null;
		String correctDiscPer = null;
		String correctPromoRate = null;
		VamDO vamDO = null;
		CalcDetail calcDetail = null;
		
		String fromTicket = (String) inputMap.get("FROM_TICKET");
		// if coming from the ticket we won't be passing the objects , just the data we need
		if (fromTicket != null) {
			calcDetailId = (String) inputMap.get(NcasConstants.VBIF_CALCDETAIL_ID);
			batchId = (String) inputMap.get(NcasConstants.VBIF_BATCH_ID);
			deleteInd = (String) inputMap.get("DELETE_IND");
			correctBillRate = (String) inputMap.get("correctBillRate");
			correctDiscPer = (String) inputMap.get("correctDiscPer");
			correctPromoRate = (String) inputMap.get("correctPromoRate");
			netAvailDiscPer = (String) inputMap.get("netAvailDiscPer");
			mttrDiscPer = (String) inputMap.get("mttrDiscPer");
			daysOfCredit = (String) inputMap.get("daysOfCredit");
		} else {
			vamDO = (VamDO)inputMap.get("vamDO");
			calcDetail = (CalcDetail)inputMap.get("billElement");//calcDetail is a billElement
			if (vamDO == null){
				throw new Exception("SPUpdateCalcDetail: input vamDO object is null");
			}
			if (calcDetail == null){
				throw new Exception("SPUpdateCalcDetail: input calcDetail object is null");
			}
			/* getting the batchId and deleteInd from VamDO*/	
			batchId = vamDO.getBatchId();
			deleteInd = vamDO.getDeleteInd();

			/* getting the rest of input params from CalcDetail*/
			calcDetailId = calcDetail.getCalcDetailID();
			netAvailDiscPer = calcDetail.getNetwkAvailDiscount();
			mttrDiscPer = calcDetail.getMttrDiscount();
			daysOfCredit = calcDetail.getDaysOfCredit();
			correctBillRate = calcDetail.getCorBillRateCharge();
			correctDiscPer = calcDetail.getCorrectedDiscount();
			correctPromoRate = calcDetail.getCorrectedPromotion();		
		}
		_LOGGER.info("batchId::"+batchId);
		_LOGGER.info("deleteInd::"+deleteInd);
		_LOGGER.info("calcDetailId::"+calcDetailId);
		_LOGGER.info("netAvailDiscPer::"+netAvailDiscPer);
		_LOGGER.info("mttrDiscPer::"+mttrDiscPer);
		_LOGGER.info("daysOfCredit::"+daysOfCredit);
		_LOGGER.info("correctBillRate::"+correctBillRate);
		_LOGGER.info("correctDiscPer::"+correctDiscPer);
		_LOGGER.info("correctPromoRate::"+correctPromoRate);
		
		/* map input vars to sp parameters */
		List inputList = new ArrayList();
		inputList.add(calcDetailId!=null?new BigDecimal(calcDetailId):null);//CALC_DTL_ID    DECIMAL(13,0)
		inputList.add(batchId!=null?new BigDecimal(batchId):null);//BATCH_ID    DECIMAL(13,0)
		inputList.add(deleteInd);//DELETE_IND    CHAR(1)
		inputList.add((netAvailDiscPer!=null && netAvailDiscPer.trim().length()>0)?Integer.valueOf(netAvailDiscPer):null);//NET_AVAIL_DISC_PER    INTEGER
		inputList.add((mttrDiscPer!=null && mttrDiscPer.trim().length()>0)?Integer.valueOf(mttrDiscPer):null);//MTTR_DISC_PER    INTEGER
		inputList.add((daysOfCredit!=null && daysOfCredit.trim().length()>0)?new BigDecimal(daysOfCredit):null);//DAYS_OF_CREDIT    DECIMAL
		inputList.add((correctBillRate!=null && correctBillRate.trim().length()>0)?new BigDecimal(correctBillRate):null);//CORRECT_BILL_RATE    DECIMAL(10,4)
		inputList.add((correctDiscPer!=null && correctDiscPer.trim().length()>0)?Integer.valueOf(correctDiscPer):null);//CORRECT_DISC_PER    INTEGER
		inputList.add((correctPromoRate!=null && correctPromoRate.trim().length()>0)?new BigDecimal(correctPromoRate):null);//CORRECT_PROMO_RATE    DECIMAL(10,2)
		
		/* execute sp */
		Map resMap = executeSP(inputList, false);
		
		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
