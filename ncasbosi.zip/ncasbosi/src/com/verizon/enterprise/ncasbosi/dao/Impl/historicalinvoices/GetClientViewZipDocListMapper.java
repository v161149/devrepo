package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.fileupload.FileUploadDO;import com.verizon.enterprise.common.util.DateUtility;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetClientViewZipDocListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetClientViewPaperInvListMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.debug("GetClientViewPaperInvListMapper - Mapping Row# "+rowNum);		String formatDb2 = "yyyy-MM-dd";		String formatDisplayed = "MM/dd/yyyy";
		FileUploadDO fuDO = null;
		if(rs!=null){
			fuDO = new FileUploadDO();			fuDO.setFileNumber(rs.getString("DOCUMENT_NUMBER"));
			fuDO.setFileSystem(rs.getString("SYSTEM_ID"));			fuDO.setFileName(rs.getString("FILE_NAME"));			fuDO.setFileSize(rs.getInt("DOCUMENT_LENGTH"));			fuDO.setFileLocation(rs.getString("DOCUMENT_LOCATION"));		}
		return fuDO;
	}
}
