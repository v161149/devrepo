package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.common.StructureInfoAccount;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetStructureInfoRowMapperImpl implements ResultSetExtractor
{
    static private final Logger _LOGGER = Logger
            .getLogger(GetStructureInfoRowMapperImpl.class);

    public Object extractData(ResultSet rs) throws SQLException
    {
        _LOGGER.info("Inside GetStructureInfoRowMapperImpl -> ");
        CommonUtil.printMetaDataInfo(rs.getMetaData());
        List accountList = new ArrayList();
        StructureInfoAccount account = null;
        try
        {
            while (rs.next())
            {
                String man = rs.getString("MAN");
                String ban = rs.getString("BAN");
                String osid = rs.getString("OSID");
                String wtn = rs.getString("WTN");
                String manBillDate = rs.getString("MAN_BILL_DATE");
            
                account = new StructureInfoAccount();
                account.setMan(man);
                account.setBan(ban);
                account.setOsid(osid);
                account.setWtn(wtn);
                account.setManBillDate(manBillDate);
                
                accountList.add(account);
            }
        }
        catch (NumberFormatException nfe)
        {
            nfe.printStackTrace();
            _LOGGER.error("Exception occured while parsing the resultset \n"
                    + nfe.getMessage());
            throw nfe;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            _LOGGER.error("Exception occured while parsing the resultset \n"
                    + ex.getMessage());
        }
        return accountList;
    }
}
