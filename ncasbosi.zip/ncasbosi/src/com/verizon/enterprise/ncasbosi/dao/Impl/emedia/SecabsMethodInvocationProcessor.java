package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaProfileInterface;;

/**
 * @author v992473
 * This class decides which Spring DAO Impl method to be performed for the SECABS project
 *
 */

public class SecabsMethodInvocationProcessor {
	private static EMediaProfileInterface emediaProfileObject = DAOFactory.getInstance().getEMediaProfile();
	private static final Logger _LOGGER = Logger.getLogger(SecabsMethodInvocationProcessor.class);
	
	private static EMediaProfileInterface getEMediaProfileObject(){
		return emediaProfileObject;
	}
	
	public static Map processSecabsTask(Object input,String function)throws NCASException{
		_LOGGER.info("Entering processSecabsTask");
		Map responseMap = null;
		try{
			Method method = getEMediaProfileObject().getClass().getMethod(function, new Class[]{Object.class});
			responseMap = (Map)method.invoke(getEMediaProfileObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,SecabsMethodInvocationProcessor.class,exception.getTargetException());
		}catch(Exception exception){
			throw new NCASException(NCASBOSIConstants.BILLING_EXCEPTION_860,SecabsMethodInvocationProcessor.class,exception);
		}
		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processSecabsTask");
		return responseMap;
	}
}

