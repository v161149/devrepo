package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.io.*;
import java.net.*;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.reports.*;
import com.verizon.enterprise.common.ncas.display.Audit;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.exception.PaymentException;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.User;



public class ReportsDAOImpl extends JdbcDaoSupport implements NCASBOSIConstants
{
	private static final Logger _LOGGER = Logger.getLogger(ReportsDAOImpl.class);

	private JdbcTemplate dbTemplate;



	//VAM table PL_RPT_CNTL_T  starts...
	String INSERT_RPT_CNTL_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_RPT_CNTL_T(STANDARD_RPT,CUSTOM_RPT,RPT_NAME,REPORT_SUB_GROUP,RPT_SECTION,RPT_CATEGORY,PAGE_ID,PAGE_SUBSET,INTER_PAGE_ID,RPT_CATEGORY_DESCRIPTION,REPORT_DESCRIPTION,EMAIL_TEMPLATE_NAME,ARCHIVE_SYSTEM_ID,CREATED_TIMESTAMP,LAST_UPD_TIMESTAMP,LAST_UPDATED_BY,REPORT_TYPE,PARENT_PAGE_ID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String UPDATE_RPT_CNTL_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_CNTL_T SET STANDARD_RPT = ?,CUSTOM_RPT = ?,RPT_NAME = ?,REPORT_SUB_GROUP = ?,RPT_SECTION = ?,RPT_CATEGORY = ?,PAGE_ID = ?,PAGE_SUBSET = ?,INTER_PAGE_ID = ?,RPT_CATEGORY_DESCRIPTION = ?,REPORT_DESCRIPTION = ?,EMAIL_TEMPLATE_NAME = ?,ARCHIVE_SYSTEM_ID = ?,CREATED_TIMESTAMP = ?,LAST_UPD_TIMESTAMP = ?,LAST_UPDATED_BY = ? WHERE RPT_ID = ?";
	String SELECT_RPT_CACHE = "SELECT * FROM " + getSchemaName() +".PL_RPT_CNTL_T WHERE CUSTOM_RPT='N' AND STANDARD_RPT='Y' AND UPPER(RPT_SECTION)=? AND RPT_ID NOT IN (SELECT RPT_ID from " + getSchemaName() +".PL_RPT_EX_PORTAL_T WHERE PORTAL = ? )  UNION SELECT A.* FROM " + getSchemaName() +".PL_RPT_CNTL_T A, " + getSchemaName() +".PL_RPT_STANDUSER_T B WHERE A.CUSTOM_RPT='N' AND A.STANDARD_RPT='N' AND UPPER(A.RPT_SECTION)=? AND A.RPT_ID=B.RPT_ID AND B.USER_OID=? AND A.RPT_ID NOT IN (SELECT RPT_ID from " + getSchemaName() +".PL_RPT_EX_PORTAL_T WHERE PORTAL = ? ) ORDER BY CATEGORY_SORT_ORDER ASC,RPT_NAME ASC,REPORT_SUB_GROUP ASC";
	String SELECT_RPT_CNTL_DETAILS = "SELECT * FROM " + getSchemaName() +".PL_RPT_CNTL_T where RPT_ID = ?" ;
	String UPDATE_RPT_CNTL_CUSTOM = "UPDATE " + getSchemaName() + ".PL_RPT_CNTL_T SET RPT_NAME = ?,REPORT_DESCRIPTION = ?,LAST_UPD_TIMESTAMP = ?,LAST_UPDATED_BY = ? WHERE RPT_ID = ?";
	String SELECT_RPT_BATCH = "SELECT * FROM " + getSchemaName() +".PL_RPT_CNTL_T where RPT_SECTION=? AND RPT_CATEGORY=?";


	String SELECT_FAVORITE_RPTS = "SELECT A.*,B.LAST_DATE  FROM " + getSchemaName() +".PL_RPT_CNTL_T A INNER JOIN (SELECT RPT_ID, MAX(LAST_UPD_TIMESTAMP) AS LAST_DATE FROM " + getSchemaName() +".PL_RPT_AUDIT_T  WHERE USER_OID=?  GROUP BY RPT_ID) B ON A.RPT_ID=B.RPT_ID AND UPPER(A.RPT_SECTION)=? ORDER BY B.LAST_DATE desc FETCH FIRST 5 ROWS ONLY";
	String SELECT_CUSTOM_RPTS =   "SELECT A.*,D.LAST_DATE FROM " + getSchemaName() +".PL_RPT_CNTL_T A INNER JOIN (SELECT B.RPT_ID, MAX(B.LAST_UPD_TIMESTAMP) AS LAST_DATE FROM " + getSchemaName() +".PL_RPT_AUDIT_T  B, " + getSchemaName() +".PL_RPT_CUSTOM_USER_T C WHERE B.USER_OID=? AND B.USER_OID = C.USER_OID AND C.RPT_ID=B.RPT_ID GROUP BY	B.RPT_ID) D ON A.RPT_ID=D.RPT_ID AND A.CUSTOM_RPT='Y' AND UPPER(A.RPT_SECTION)=? ORDER BY D.LAST_DATE desc FETCH FIRST 5 ROWS ONLY";
	String SELECT_SHARED_RPTS =   "SELECT A.*,D.LAST_DATE FROM " + getSchemaName() +".PL_RPT_CNTL_T A INNER JOIN (SELECT B.RPT_ID, MAX(B.LAST_UPD_TIMESTAMP) AS LAST_DATE FROM " + getSchemaName() +".PL_RPT_AUDIT_T  B, " + getSchemaName() +".PL_RPT_CUSTOM_USER_T C WHERE B.USER_OID=? AND B.USER_OID != C.USER_OID AND C.SHARE_IND='Y' AND C.RPT_ID=B.RPT_ID GROUP BY	B.RPT_ID) D ON A.RPT_ID=D.RPT_ID AND A.CUSTOM_RPT='Y' AND UPPER(A.RPT_SECTION)=? ORDER BY D.LAST_DATE desc FETCH FIRST 5 ROWS ONLY";
	String SELECT_SCHEDULED_RPTS = "SELECT A.RPT_ID,A.RPT_NAME,A.REPORT_SUB_GROUP,A.INTER_PAGE_ID,A.PAGE_ID,A.PAGE_SUBSET,B.LAST_DATE   FROM " + getSchemaName() +".PL_RPT_CNTL_T A INNER JOIN (SELECT AA.RPT_ID, MAX(BB.LAST_UPD_TIMESTAMP) AS LAST_DATE FROM " + getSchemaName() +".PL_RPT_REQUEST_T AA,  " + getSchemaName() +".PL_RPT_EXEC_T BB WHERE AA.RPT_REQUEST_ID = BB.RPT_REQUEST_ID  AND AA.RPT_RECUR_ID!="+ NcasConstants.DEFFERED_DOWNLOAD_RPT_ID +" AND AA.USER_OID=?  GROUP BY AA.RPT_ID) B ON A.RPT_ID=B.RPT_ID AND  UPPER(A.RPT_SECTION)=?  ORDER BY B.LAST_DATE desc FETCH FIRST 5 ROWS ONLY";


	String SELECT_SCHEDULED_RPT_FORRECURID = "SELECT * FROM " + getSchemaName() +".PL_RPT_RECUR_T where RPT_RECUR_ID = ?" ;

	//VAM table PL_RPT_CNTL_T  ends...

	//VAM table PL_RPT_CUSTOM_USER_T  starts...
	String INSERT_CUSTOM_USER_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_RPT_CUSTOM_USER_T(RPT_ID, PORTAL_LOGIN_ID, SHARE_IND, ECPD_ID, USER_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?)";
	String UPDATE_CUSTOM_USER_SHARED_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_CUSTOM_USER_T SET SHARE_IND = ?, LAST_UPD_TIMESTAMP = ? ,LAST_UPDATED_BY = ?  WHERE RPT_ID = ?";


	//VAM table PL_RPT_CUSTOM_USER_T  ends...

	String DELETE_CUSTOM_USER_DETAILS = "DELETE FROM " + getSchemaName() + ".PL_RPT_CUSTOM_USER_T where RPT_ID = ?";
	String SELECT_CUSTOM_USER_DETAILS = "Select * FROM " + getSchemaName() + ".PL_RPT_CUSTOM_USER_T where RPT_ID = ? AND USER_OID = ?";

	String SELECT_ICI_CUSTOM_RPT = "Select B.RPT_ID,B.PAGE_ID FROM " + getSchemaName() + ".PL_RPT_CUSTOM_USER_T A, " + getSchemaName() + ".PL_RPT_CNTL_T B where B.RPT_SECTION='ICICUSTOM' AND A.RPT_ID = B.RPT_ID AND USER_OID = ?";


	String DELETE_RPT_CNTL_DETAIL = "DELETE FROM " + getSchemaName() + ".PL_RPT_CNTL_T where CUSTOM_RPT = 'Y' AND RPT_ID = ?";


	//VAM table PL_RPT_EMAIL_T  starts...
	String INSERT_EMAIL_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_RPT_EMAIL_T(RPT_REQUEST_ID, EMAIL_PROCESS_TSTAMP, EMAIL_TRACKING_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?)";
	String UPDATE_EMAIL_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_EMAIL_T SET RPT_REQUEST_ID = ?, EMAIL_PROCESS_TSTAMP = ?, EMAIL_TRACKING_OID = ?, CREATED_TIMESTAMP = ?, LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_EXEC_MAIL_ID = ?";
	String SELECT_EMAIL_DETAILS = "SELECT * FROM " + getSchemaName() + ".PL_RPT_EMAIL_T WHERE RPT_EXEC_MAIL_ID = ";
	//VAM table PL_RPT_EMAIL_T  ends...

	//For EMAIL BATCH
	String SELECT_ELIGIBLE_EMAIL_DETAILS = "SELECT  A.RPT_EXEC_MAIL_ID,A.RPT_REQUEST_ID,B.CREATED_TIMESTAMP,C.EMAIL_TEMPLATE_NAME,C.RPT_CATEGORY, C.RPT_SECTION,C.RPT_NAME,C.REPORT_SUB_GROUP, B.PORTAL_LOGIN_ID, B.EMAIL_ADDR,B.DOWNLOAD_DESCRIPTION,C.RPT_ID from " + getSchemaName() + ".PL_RPT_EMAIL_T A, " + getSchemaName() + ".PL_RPT_REQUEST_T B," + getSchemaName() + ".PL_RPT_CNTL_T C  WHERE A.EMAIL_TRACKING_OID = 0 AND A.RPT_REQUEST_ID=B.RPT_REQUEST_ID AND  B.RPT_ID = C.RPT_ID  FOR UPDATE;";
	String UPDATE_EMAIL_PROC_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_EMAIL_T SET EMAIL_TRACKING_OID = ?, EMAIL_PROCESS_TSTAMP = ?, LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_EXEC_MAIL_ID = ?;";

	// For vbe email from aft table
    String SELECT_VBE_AFT_EMAIL_DETAILS = "SELECT  A.REQUEST_NO, A.CUSTOMER_NAME, A.COMMENTS from " + getSchemaName() + ".AFT_REQ_T A  WHERE A.RPT_REQUEST_ID = ? WITH UR;";

	
	//VAM table PL_RPT_RECUR_T  starts...
	String INSERT_RPT_RECUR_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_RPT_RECUR_T(RPT_ID, PORTAL_LOGIN_ID, STRUCT_TYPE, STRUCT_OID, POSITION_TYPE, POSITION_OID, STATUS, RECUR_DAY, FREQUENCY, START_DATE, END_DATE, NEXT_SCHEDULE_DATE, EMAIL_ADDR, PAGE_SUBSET, RQST_LINK_PARAM, RQST_SORT_PARAM, RQST_FILTER_PARAM, USER_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String UPDATE_RPT_RECUR_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_RECUR_T SET PORTAL_LOGIN_ID = ?, STATUS = ?, RECUR_DAY = ?, START_DATE = ?, END_DATE = ?, NEXT_SCHEDULE_DATE = ?, EMAIL_ADDR = ?, USER_OID = ?, LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_RECUR_ID = ?";
	String SELECT_RPT_RECUR_DETAILS = "SELECT * FROM " + getSchemaName() + ".PL_RPT_RECUR_T WHERE RPT_RECUR_ID = ";
	String DELETE_RPT_RECUR_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_RECUR_T SET PORTAL_LOGIN_ID = ?, STATUS = ?, END_DATE = ?, NEXT_SCHEDULE_DATE = ?,  USER_OID = ?, LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_RECUR_ID = ?";

	//String BATCH_SELECT_RPT_RECUR_DETAILS = "SELECT * FROM " + getSchemaName() + ".PL_RPT_RECUR_T WHERE UCASE(STATUS)='"+NcasConstants.RECUR_REPORTS_SCHEDULED_STATUS.toUpperCase()+"' AND NEXT_SCHEDULE_DATE<=DATE(CURRENT_DATE)";
	String SELECT_ELGIBLE_RECUR_RPT_FOR_PROCESS = "SELECT A.*,B.PAGE_ID FROM " + getSchemaName() + ".PL_RPT_RECUR_T A, "+ getSchemaName() + ".PL_RPT_CNTL_T B WHERE UCASE(A.STATUS)='"+NcasConstants.RECUR_REPORTS_SCHEDULED_STATUS.toUpperCase()+"' AND DATE(CURRENT_DATE) >= A.START_DATE and DATE(CURRENT_DATE) <= A.END_DATE and DATE(CURRENT_DATE) >= A.NEXT_SCHEDULE_DATE AND A.RPT_ID = B.RPT_ID FOR UPDATE";
	String UPDATE_NEXT_SCH_DATE_RPT_RECUR = "UPDATE " + getSchemaName() + ".PL_RPT_RECUR_T SET END_DATE=?,NEXT_SCHEDULE_DATE = ?, LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_RECUR_ID=?";
	//VAM table PL_RPT_RECUR_T  ends...

	//VAM table PL_RPT_REQUEST_T  starts...
	String SELECT_RPT_REQUEST_DETAILS = "SELECT * FROM " + getSchemaName() + ".PL_RPT_REQUEST_T WHERE RPT_REQUEST_ID = ";
	String INSERT_RPT_REQUEST_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_RPT_REQUEST_T(RPT_ID, PORTAL_LOGIN_ID, RPT_TYPE, RPT_RECUR_ID, STRUCTURE_TYPE, STRUCTURE_OID, POSITION_TYPE, POSITION_OID, REQUEST_STATUS, ERROR_DESCRIPTION, RPT_PROCESS_TS,RPT_REQUEST_TS, EMAIL_ADDR, PAGE_ID, PAGE_SUBSET, DOWNLOAD_DESCRIPTION, RQST_LINK_PARAM, RQST_SORT_PARAM, RQST_FILTER_PARAM, USER_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String UPDATE_RPT_REQUEST_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_REQUEST_T SET RPT_ID = ?, PORTAL_LOGIN_ID = ?, RPT_TYPE = ?, RPT_RECUR_ID = ?, STRUCTURE_TYPE = ?, STRUCTURE_OID = ?, POSITION_TYPE = ?, POSITION_OID = ?, REQUEST_STATUS = ?, ERROR_DESCRIPTION = ?, RPT_REQUEST_TS = ?, RPT_PROCESS_TS = ?, EMAIL_ADDR = ?, PAGE_ID = ?, PAGE_SUBSET = ?, DOWNLOAD_DESCRIPTION = ?, RQST_LINK_PARAM = ?, RQST_SORT_PARAM = ?, RQST_FILTER_PARAM = ?, USER_OID = ?, LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_REQUEST_ID = ?";
    //1. Batch related SQLs
	String BATCH_SELECT_RPT_REQUEST_DETAILS = "SELECT * FROM " + getSchemaName() + ".PL_RPT_REQUEST_T WHERE UCASE(REQUEST_STATUS)='"+NcasConstants.REPORTS_DETAILS_SCHEDULED_STATUS.toUpperCase()+"' WITH UR";
	String BATCH_UPDATE_RPT_REQUEST_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_REQUEST_T SET REQUEST_STATUS = ? , LAST_UPD_TIMESTAMP = ?, LAST_UPDATED_BY = ? WHERE RPT_REQUEST_ID = ?";

	//VAM table PL_RPT_REQUEST_T ends...

	//VAM table PL_RPT_EXEC_T  starts...
	String INSERT_RPT_EXEC_DETAILS = "INSERT INTO " + getSchemaName() + ".PL_RPT_EXEC_T(RPT_REQUEST_ID, DISPLAY_PARAM, FILE_DESCRIPTION, FILE_STATUS, ERROR_DESCRIPTION, RUN_TIMESTAMP, ARCHIVE_DOC_NBR, DISPLAY_END_DATE, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	//String DELETE_RPT_EXEC_DETAILS = "DELETE FROM " + getSchemaName() + ".PL_RPT_EXEC_T WHERE RPT_EXEC_ID = ?";
	String END_DATE_RPT_EXEC_DETAILS = "UPDATE " + getSchemaName() + ".PL_RPT_EXEC_T SET DISPLAY_END_DATE = '1900-01-01' WHERE RPT_EXEC_ID = ?";
	//VAM table PL_RPT_EXEC_T  ends...

	//VAM table PL_RPT_EXEC_T  starts...
	String INSERT_RPT_AUDIT = "INSERT INTO " + getSchemaName() + ".PL_RPT_AUDIT_T(RPT_ID, ACTION_TYPE, PORTAL_LOGIN_ID, USER_OID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?)";
	//VAM table PL_RPT_EXEC_T  ends...

	//VAM table CUST_RPT_TYPES_T  and CUST_RPT_FIELDS_T starts...
	String SELECT_CUST_RPT_META_DETAILS = "SELECT A.*,B.FIELD_NAME,B.SOURCE_ABBR FROM " + getSchemaName() + ".CUST_RPT_TYPES_T A, " + getSchemaName() + ".CUST_RPT_FIELDS_T B WHERE A.FIELD_GROUP=B.FIELD_GROUP AND A.REPORT_SECTION=B.REPORT_SECTION ORDER BY A.REPORT_TYPE,A.VIEWBY_NAME,A.FIELD_GROUP,B.FIELD_NAME";
	//VAM table CUST_RPT_TYPES_T  and CUST_RPT_FIELDS_T  ends...
	String SELECT_SHARED_RPT_DUPS1 = "SELECT A.RPT_NAME  FROM " + getSchemaName() + ".PL_RPT_CNTL_T A , " + getSchemaName() + ".PL_RPT_CUSTOM_USER_T B WHERE  ";
	String SELECT_SHARED_RPT_DUPS2 = " AND A.RPT_ID=B.RPT_ID  AND A.CUSTOM_RPT='Y' AND A.RPT_NAME=?";


	//VAM table CUST_RPT_CHOICES_T
	String INSERT_CUST_RPT_CHOICES = "INSERT INTO " + getSchemaName() + ".CUST_RPT_CHOICES_T (RPT_ID, FIELD_NAME, SOURCE_ABBR,APPLIED_FUNCTION, OUTPUT_FMT, SORT_ORDINAL, GROUP_ORDINAL, DISPLAY_ORDINAL,FIELD_GROUP) VALUES(?,?,?,?,?,?,?,?,?)";
	String SELECT_CUST_RPT_CHOICES = "SELECT A.FIELD_NAME,A.SOURCE_ABBR,A.FIELD_GROUP  FROM " + getSchemaName() +".CUST_RPT_CHOICES_T A where RPT_ID = ?  ORDER BY DISPLAY_ORDINAL ASC" ;

	String SELECT_CUST_RPT_GLOBAL_FIELDS = "SELECT X.FIELD_NAME,X.SOURCE_ABBR,X.FIELD_GROUP   FROM " + getSchemaName() + ".CUST_RPT_FIELDS_T X   WHERE UPPER(X.REPORT_SECTION) = ? AND UPPER(X.FIELD_GROUP) = 'GLOBAL' ORDER BY X.FIELD_NAME";
	String DELETE_CUST_RPT_CHOICES = "DELETE FROM " + getSchemaName() + ".CUST_RPT_CHOICES_T where RPT_ID = ?";

	//PL_VIEW_AUDIT_T
	String INSERT_VIEW_AUDIT = "INSERT INTO " + getSchemaName() + ".PL_VIEW_AUDIT_T(ACCESS_TYPE,MAN,BAN,ABAN,BILL_DATE,OSID,USER_OID,PORTAL_LOGIN_ID,IMP_LOGIN_ID, CREATED_TIMESTAMP, LAST_UPD_TIMESTAMP, LAST_UPDATED_BY) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";


	protected void initDao() throws Exception{
		super.initDao();
	}


	public String getSchemaName()
	{
		String schemaName = NCASBOSIConstants.VAM_SCHEMA;
		return schemaName;
	}

	protected JdbcTemplate getDBTemplate()
	{
		if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}



	@SuppressWarnings("unchecked")
	public List getReportCache(String langCode,String userOid,String section,String portal) throws NCASException
	{
		final String METHOD_NAME = "getReportCache::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_RPT_CACHE);
		Map responseMap = new HashMap();
		List<RptCntl> rptCacheList = new ArrayList();
		try
		{
			GetRptCntlDetResultSetRowMapper rowMapper = new GetRptCntlDetResultSetRowMapper();
		//	rowMapper.setLangMap(DAOFactory.getInstance().getInternationalImpl().getPreferredLang(langCode, "REPORTS"));
			Object[] params = new Object[]{section.toUpperCase(),portal.toUpperCase(), section.toUpperCase(),userOid,portal.toUpperCase()};
			rptCacheList = getDBTemplate().query(SELECT_RPT_CACHE,params,rowMapper);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return rptCacheList;
	}

	@SuppressWarnings("unchecked")
	public List getReportBatch(String langCode,String userOid,String section, String category) throws NCASException
	{
		final String METHOD_NAME = "getReportBatch::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_RPT_BATCH);
		_LOGGER.info(METHOD_NAME + "section: " + section);
		_LOGGER.info(METHOD_NAME + "category: " + category);
		Map responseMap = new HashMap();
		List<RptCntl> rptBatchList = new ArrayList();
		try
		{
			GetRptCntlDetResultSetRowMapper rowMapper = new GetRptCntlDetResultSetRowMapper();
			Object[] params = new Object[]{new String(section.toUpperCase()), new String(category.toUpperCase())};
			rptBatchList = getDBTemplate().query(SELECT_RPT_BATCH,params,rowMapper);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return rptBatchList;
	}
	

	public RptCntl getReportDetails(String rptID) throws NCASException
	{
		final String METHOD_NAME = "getReportDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_RPT_CNTL_DETAILS);
		Map responseMap = new HashMap();
		RptCntl rptCntl = null;
		try
		{
			GetRptCntlDetResultSetRowMapper rowMapper = new GetRptCntlDetResultSetRowMapper();
			Object[] params = new Object[]{Integer.parseInt(rptID)};
			List<RptCntl> rptCacheList = getDBTemplate().query(SELECT_RPT_CNTL_DETAILS,params,rowMapper);
			if(rptCacheList!=null)
				rptCntl = (RptCntl)rptCacheList.get(0);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return rptCntl;
	}
	
	@SuppressWarnings("unchecked")
	public List getFavoriteReports(String langCode,String userOid,String section) throws NCASException
	{
		final String METHOD_NAME = "getFavoriteReports::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_FAVORITE_RPTS);
		Map responseMap = new HashMap();
		List<RptCntl> rptCacheList = new ArrayList();
		try
		{
			GetRptCntlDetResultSetRowMapper rowMapper = new GetRptCntlDetResultSetRowMapper();
			Object[] params = new Object[]{new String(userOid),new String(section.toUpperCase())};
			rptCacheList = getDBTemplate().query(SELECT_FAVORITE_RPTS,params,rowMapper);
			Collections.sort(rptCacheList);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new PaymentException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return rptCacheList;
	}

		@SuppressWarnings("unchecked")
		public List getCustomReports(String langCode,String userOid,String section) throws NCASException
		{
			final String METHOD_NAME = "getCustomReports::";
			_LOGGER.info(METHOD_NAME+"Entering");
			_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_CUSTOM_RPTS);
			Map responseMap = new HashMap();
			List<RptCntl> rptCacheList = new ArrayList();
			try
			{
				GetRptCntlDetResultSetRowMapper rowMapper = new GetRptCntlDetResultSetRowMapper();
				Object[] params = new Object[]{new String(userOid),new String(section.toUpperCase())};
				rptCacheList = getDBTemplate().query(SELECT_CUSTOM_RPTS,params,rowMapper);
				Collections.sort(rptCacheList);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return rptCacheList;
		}


		@SuppressWarnings("unchecked")
		public List getSharedReports(String langCode,String userOid,String section) throws NCASException
		{
			final String METHOD_NAME = "getSharedReports::";
			_LOGGER.info(METHOD_NAME+"Entering");
			_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_SHARED_RPTS);
			Map responseMap = new HashMap();
			List<RptCntl> rptCacheList = new ArrayList();
			try
			{
				GetRptCntlDetResultSetRowMapper rowMapper = new GetRptCntlDetResultSetRowMapper();
				Object[] params = new Object[]{new String(userOid),new String(section.toUpperCase())};
				rptCacheList = getDBTemplate().query(SELECT_SHARED_RPTS,params,rowMapper);
				Collections.sort(rptCacheList);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return rptCacheList;
		}


		@SuppressWarnings("unchecked")
		public List getScheduledReports(String langCode,String userOid,String section) throws NCASException
		{
			final String METHOD_NAME = "getScheduledReports::";
			_LOGGER.info(METHOD_NAME+"Entering");
			_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_SCHEDULED_RPTS);
			Map responseMap = new HashMap();
			List<RptCntl> rptCacheList = new ArrayList();
			try
			{
				GetScheduledRptRowMapper rowMapper = new GetScheduledRptRowMapper();
				Object[] params = new Object[]{new String(userOid),new String(section.toUpperCase())};
				rptCacheList = getDBTemplate().query(SELECT_SCHEDULED_RPTS,params,rowMapper);
				Collections.sort(rptCacheList);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return rptCacheList;
		}





		public List getScheduledReportForID(String recurID) throws NCASException
		{
			final String METHOD_NAME = "getScheduledReportForID::";
			_LOGGER.info(METHOD_NAME+"Entering");
			_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_SCHEDULED_RPT_FORRECURID);
			Map responseMap = new HashMap();
			List<RptCntl> rptCacheList = new ArrayList();
			try
			{
				GetRptRecurDetResultSetRowMapper rowMapper = new GetRptRecurDetResultSetRowMapper();
				Object[] params = new Object[]{new Double(recurID)};
				rptCacheList = getDBTemplate().query(SELECT_SCHEDULED_RPT_FORRECURID,params,rowMapper);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return rptCacheList;
		}

		@SuppressWarnings("unchecked")
		public int insertReportControlDetails(RptCntl reportCntl) throws NCASException
		{
			final String METHOD_NAME = "insertReportControlDetails::";
			_LOGGER.info(METHOD_NAME+"Entering");
			SqlUpdate insertRptCntlDet = null;
			Map responseMap = new HashMap();
			int rptId = 0;
			if (reportCntl != null)
			{
				_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_RPT_CNTL_DETAILS);

				try
				{
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

					insertRptCntlDet = new SqlUpdate(getDataSource(), INSERT_RPT_CNTL_DETAILS);
					KeyHolder keyHolder = new GeneratedKeyHolder();

					insertRptCntlDet.setReturnGeneratedKeys(true);
					insertRptCntlDet.declareParameter(new SqlParameter("STANDARD_RPT", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("CUSTOM_RPT", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_NAME", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("REPORT_SUB_GROUP", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_SECTION", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY", Types.VARCHAR));

					insertRptCntlDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					insertRptCntlDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("INTER_PAGE_ID", Types.INTEGER));
					insertRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY_DESCRIPTION", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("REPORT_DESCRIPTION", Types.VARCHAR));

					insertRptCntlDet.declareParameter(new SqlParameter("EMAIL_TEMPLATE_NAME", Types.VARCHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("ARCHIVE_SYSTEM_ID", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
					insertRptCntlDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
					insertRptCntlDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

					insertRptCntlDet.declareParameter(new SqlParameter("REPORT_TYPE", Types.CHAR));
					insertRptCntlDet.declareParameter(new SqlParameter("PARENT_PAGE_ID", Types.INTEGER));

					insertRptCntlDet.compile();

						Object[] parameterValues = new Object[]{
								reportCntl.getStdReport(),
								reportCntl.getCustomRpt(),
								reportCntl.getRptName(),
								reportCntl.getRptSubGroup(),
								reportCntl.getRptSection(),
								reportCntl.getRptCategory(),
								reportCntl.getPageId(),
								reportCntl.getPageSubset(),
								reportCntl.getInterPageId(),
								reportCntl.getRptCatDescription(),
								reportCntl.getRptDescription(),
								reportCntl.getEmailTemplateName(),
								reportCntl.getArchiveSystemId(),
								lastUpdated.trim(),
								lastUpdated.trim(),
								reportCntl.getLastUpdatedBy(),reportCntl.getReportType(),reportCntl.getParentPageId() };
						insertRptCntlDet.update(parameterValues, keyHolder);
						rptId = keyHolder.getKey().intValue();
						reportCntl.setRptId(rptId);
					_LOGGER.info(METHOD_NAME + " Success, Rows Inserted rptId ::" + rptId);
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					String[] errMsg = new String[2];
				    errMsg[0] = METHOD_NAME;
				    errMsg[1] = ex.getMessage();
					_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
					throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
				}
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return rptId;
		}


		@SuppressWarnings("unchecked")
		public Map updateReportControlDetails(List<RptCntl> reportCntlList) throws NCASException
		{
			final String METHOD_NAME = "updateReportControlDetails::";
			_LOGGER.info(METHOD_NAME+"Entering");
			BatchSqlUpdate updateRptCntlDet = null;
			Map responseMap = new HashMap();
			int totalRowsUpdated = 0;
			if ((reportCntlList != null) && (reportCntlList.size() > 0))
			{
				_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_RPT_CNTL_DETAILS);
				try
				{
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

					updateRptCntlDet = new BatchSqlUpdate(getDataSource(), UPDATE_RPT_CNTL_DETAILS);
					updateRptCntlDet.declareParameter(new SqlParameter("STANDARD_RPT", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("CUSTOM_RPT", Types.CHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("RPT_NAME", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("REPORT_SUB_GROUP", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("RPT_SECTION", Types.CHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
					updateRptCntlDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("INTER_PAGE_ID", Types.INTEGER));
					updateRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY_DESCRIPTION", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("REPORT_DESCRIPTION", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("EMAIL_TEMPLATE_NAME", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("ARCHIVE_SYSTEM_ID", Types.CHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
					updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
					updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
					updateRptCntlDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));

					updateRptCntlDet.compile();

					for(int i = 0;i<reportCntlList.size();i++)
					{
						RptCntl rptCntlItem = reportCntlList.get(i);
						Object[] parameterValues = new Object[]{
								rptCntlItem.getStdReport(),
								rptCntlItem.getCustomRpt(),
								rptCntlItem.getRptName(),
								rptCntlItem.getRptSubGroup(),
								rptCntlItem.getRptSection(),
								rptCntlItem.getRptCategory(),
								rptCntlItem.getPageId(),
								rptCntlItem.getPageSubset(),
								rptCntlItem.getInterPageId(),
								rptCntlItem.getRptCatDescription(),
								rptCntlItem.getRptDescription(),
								rptCntlItem.getEmailTemplateName(),
								rptCntlItem.getArchiveSystemId(),
								lastUpdated.trim(),
								lastUpdated.trim(),
								rptCntlItem.getLastUpdatedBy(),
								rptCntlItem.getRptId()};
						int rowsUpdated = updateRptCntlDet.update(parameterValues);
						totalRowsUpdated += rowsUpdated;
					}
					updateRptCntlDet.flush();
					responseMap.put("ROWS_UPDATED", totalRowsUpdated + "");
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					String[] errMsg = new String[2];
				    errMsg[0] = METHOD_NAME;
				    errMsg[1] = ex.getMessage();
					_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
					throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
				}
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return responseMap;
		}

		@SuppressWarnings("unchecked")
		public Map updateReportControlDetail(Map params) throws NCASException
		{
			final String METHOD_NAME = "updateReportControlDetail::";
			_LOGGER.info(METHOD_NAME+"Entering");
			BatchSqlUpdate updateRptCntlDet = null;
			Map responseMap = new HashMap();
			StringBuffer sqlBuf = new StringBuffer();
			sqlBuf.append("UPDATE ").append(getSchemaName()).append(".PL_RPT_CNTL_T SET ");

			int rptId = Integer.parseInt((String)params.get("RPT_ID"));
			String rptName = (String)params.get("RPT_NAME");
			String emailTemplateName = (String)params.get("EMAIL_TEMPLATE_NAME");
			String rptCategory = (String)params.get("RPT_CATEGORY");
			String rptCatDescription = (String)params.get("RPT_CATEGORY_DESCRIPTION");
			String rptDescription = (String)params.get("REPORT_DESCRIPTION");
			String lastUpdTimestamp = (String)params.get("LAST_UPD_TIMESTAMP");
			String lastUpdatedBy = (String)params.get("LAST_UPDATED_BY");
			ArrayList fieldList = new ArrayList();

			if (rptName!=null&&!rptName.trim().equalsIgnoreCase("")) {
				sqlBuf.append("RPT_NAME").append(" = ?,");
				fieldList.add("RPT_NAME");
			}
			if (emailTemplateName!=null&&!emailTemplateName.trim().equalsIgnoreCase("")) {
				sqlBuf.append("EMAIL_TEMPLATE_NAME").append(" = ?,");
				fieldList.add("EMAIL_TEMPLATE_NAME");
			}
			if (rptCategory!=null&&!rptCategory.trim().equalsIgnoreCase("")) {
				sqlBuf.append("RPT_CATEGORY").append(" = ?,");
				fieldList.add("RPT_CATEGORY");
			}
			if (rptCatDescription!=null&&!rptCatDescription.trim().equalsIgnoreCase("")) {
				sqlBuf.append("RPT_CATEGORY_DESCRIPTION").append(" = ?,");
				fieldList.add("RPT_CATEGORY_DESCRIPTION");
			}
			if (rptDescription!=null&&!rptDescription.trim().equalsIgnoreCase("")) {
				sqlBuf.append("REPORT_DESCRIPTION").append(" = ?,");
				fieldList.add("REPORT_DESCRIPTION");
			}
			if (lastUpdTimestamp!=null&&!lastUpdTimestamp.trim().equalsIgnoreCase("")) {
				sqlBuf.append("LAST_UPD_TIMESTAMP").append(" = ?,");
				fieldList.add("LAST_UPD_TIMESTAMP");
			}
			if (lastUpdatedBy!=null&&!lastUpdatedBy.trim().equalsIgnoreCase("")) {
				sqlBuf.append("LAST_UPDATED_BY").append(" = ? WHERE RPT_ID = ?");
				fieldList.add("LAST_UPDATED_BY");
			}

			if (fieldList.size() > 0)
			{
				_LOGGER.info(METHOD_NAME + "SQL: " + sqlBuf.toString());
				try
				{
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

					updateRptCntlDet = new BatchSqlUpdate(getDataSource(), sqlBuf.toString());
					if (fieldList.contains("RPT_NAME")) {
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_NAME", Types.VARCHAR));
					}
					if (fieldList.contains("EMAIL_TEMPLATE_NAME")) {
						updateRptCntlDet.declareParameter(new SqlParameter("EMAIL_TEMPLATE_NAME", Types.VARCHAR));
					}
					if (fieldList.contains("RPT_CATEGORY")) {
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY", Types.VARCHAR));
					}
					if (fieldList.contains("RPT_CATEGORY_DESCRIPTION")) {
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_CATEGORY_DESCRIPTION", Types.VARCHAR));
					}
					if (fieldList.contains("REPORT_DESCRIPTION")) {
						updateRptCntlDet.declareParameter(new SqlParameter("REPORT_DESCRIPTION", Types.VARCHAR));
					}
					if (fieldList.contains("LAST_UPD_TIMESTAMP")) {
						updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
					}
					if (fieldList.contains("LAST_UPDATED_BY")) {
						updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
						updateRptCntlDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
					}
					updateRptCntlDet.compile();

					Object[] parameterValues = new Object[fieldList.size()+1];
					for(int i = 0;i<fieldList.size();i++) {
						parameterValues[i] = fieldList.get(i);
					}
					parameterValues[fieldList.size()] = rptId;
					int rowsUpdated = updateRptCntlDet.update(parameterValues);
					updateRptCntlDet.flush();
					responseMap.put("ROWS_UPDATED", rowsUpdated + "");
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					String[] errMsg = new String[2];
				    errMsg[0] = METHOD_NAME;
				    errMsg[1] = ex.getMessage();
					_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
					throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
				}
			}
			_LOGGER.info(METHOD_NAME+"Exiting");
			return responseMap;
		}


	@SuppressWarnings("unchecked")
	public Map insertEmailDetails(List<RptEmail> reportEmailList) throws NCASException
	{
		final String METHOD_NAME = "insertEmailDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate insertEmailDet = null;
		Map responseMap = new HashMap();
		int totalRowsUpdated = 0;
		if ((reportEmailList != null) && (reportEmailList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_EMAIL_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				insertEmailDet = new BatchSqlUpdate(getDataSource(), INSERT_EMAIL_DETAILS);
				KeyHolder keyHolder = new GeneratedKeyHolder();

				insertEmailDet.setReturnGeneratedKeys(true);
				insertEmailDet.declareParameter(new SqlParameter("RPT_REQUEST_ID", Types.INTEGER));
				insertEmailDet.declareParameter(new SqlParameter("EMAIL_PROCESS_TSTAMP", Types.TIMESTAMP));
				insertEmailDet.declareParameter(new SqlParameter("EMAIL_TRACKING_OID", Types.DECIMAL));
				insertEmailDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertEmailDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertEmailDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

				insertEmailDet.compile();

				for(int i=0;i<reportEmailList.size();i++)
				{
					RptEmail rptEmailItem = reportEmailList.get(i);
					Object[] parameterValues = new Object[]{rptEmailItem.getRptRequestId(),
							                                rptEmailItem.getEmailProcessTstamp(),
							                                new Double(rptEmailItem.getEmailTrackingOid()),
							                                lastUpdated,
							                                lastUpdated,
							                                rptEmailItem.getLastUpdatedBy()};
					int rowsUpdated = insertEmailDet.update(parameterValues, keyHolder);
					totalRowsUpdated += rowsUpdated;
					rptEmailItem.setRptExecMailId(keyHolder.getKey().intValue());
				}
				insertEmailDet.flush();
				responseMap.put("ROWS_INSERTED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map updateEmailDetails(List<RptEmail> reportEmailList) throws NCASException
	{
		final String METHOD_NAME = "updateEmailDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate updateEmailDet = null;
		Map responseMap = new HashMap();
		int totalRowsUpdated = 0;
		if ((reportEmailList != null) && (reportEmailList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_EMAIL_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				updateEmailDet = new BatchSqlUpdate(getDataSource(), UPDATE_EMAIL_DETAILS);

				updateEmailDet.declareParameter(new SqlParameter("RPT_REQUEST_ID", Types.INTEGER));
				updateEmailDet.declareParameter(new SqlParameter("EMAIL_PROCESS_TSTAMP", Types.TIMESTAMP));
				updateEmailDet.declareParameter(new SqlParameter("EMAIL_TRACKING_OID", Types.DECIMAL));
				updateEmailDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				updateEmailDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateEmailDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				updateEmailDet.declareParameter(new SqlParameter("RPT_EXEC_MAIL_ID", Types.INTEGER));

				updateEmailDet.compile();

				for(int i=0;i<reportEmailList.size();i++)
				{
					RptEmail rptEmailItem = reportEmailList.get(i);
					Object[] parameterValues = new Object[]{rptEmailItem.getRptRequestId(),
							                                rptEmailItem.getEmailProcessTstamp(),
							                                new Double(rptEmailItem.getEmailTrackingOid()),
							                                lastUpdated.trim(),
							                                lastUpdated.trim(),
							                                rptEmailItem.getLastUpdatedBy(),
							                                rptEmailItem.getRptExecMailId()};
					int rowsUpdated = updateEmailDet.update(parameterValues);
					totalRowsUpdated += rowsUpdated;
				}
				updateEmailDet.flush();
				responseMap.put("ROWS_INSERTED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}


	@SuppressWarnings("unchecked")
	public int insertCustomUserDetails(RptCustUser reportCustUser) throws NCASException
	{
		final String METHOD_NAME = "insertCustomUserDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		SqlUpdate insertCustomUserDet = null;
		Map responseMap = new HashMap();
		int custUserOid = 0;
		int totalRowsUpdated = 0;
		if (reportCustUser != null)
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_CUSTOM_USER_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				insertCustomUserDet = new SqlUpdate(getDataSource(), INSERT_CUSTOM_USER_DETAILS);
				KeyHolder keyHolder = new GeneratedKeyHolder();

				insertCustomUserDet.setReturnGeneratedKeys(true);
				insertCustomUserDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
				insertCustomUserDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
				insertCustomUserDet.declareParameter(new SqlParameter("SHARE_IND", Types.CHAR));
				insertCustomUserDet.declareParameter(new SqlParameter("ECPD_ID", Types.DECIMAL));
				insertCustomUserDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
				insertCustomUserDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertCustomUserDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertCustomUserDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

				insertCustomUserDet.compile();

					Object[] parameterValues = new Object[]{reportCustUser.getRptId(),
							reportCustUser.getPortalLoginId(),
							reportCustUser.getShareInd(),
							new Double(reportCustUser.getECpdId()),
							new Double(reportCustUser.getUserOid()),
	                        lastUpdated.trim(),
				            lastUpdated.trim(),
						    reportCustUser.getLastUpdatedBy()};
					insertCustomUserDet.update(parameterValues, keyHolder);
					custUserOid = keyHolder.getKey().intValue();
					reportCustUser.setRptCustomUserId(custUserOid);
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + custUserOid);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return custUserOid;
	}

	@SuppressWarnings("unchecked")
	public void deleteCustomUser(List<RptCustUser> rptCustUserList) throws NCASException {
		final String METHOD_NAME = "deleteCustomUser::";
		_LOGGER.info(METHOD_NAME+"Entering");

		RptAudit reportAudit = null;
		Map responseMap = new HashMap();
		BatchSqlUpdate deleteCustomUserDet = null;
		BatchSqlUpdate deleteRptControlDet = null;

		List<RptAudit> auditList = new ArrayList();
		_LOGGER.info(METHOD_NAME+"DELETE CUSTOM USER SQL: " + DELETE_CUSTOM_USER_DETAILS);
		_LOGGER.info(METHOD_NAME+"DELETE RPT CNTL SQL: " + DELETE_RPT_CNTL_DETAIL);

		if ((rptCustUserList != null) && (rptCustUserList.size() > 0))
		{
				try
				{
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));


					deleteCustomUserDet = new BatchSqlUpdate(getDataSource(), DELETE_CUSTOM_USER_DETAILS);
					deleteCustomUserDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
					deleteCustomUserDet.compile();

					deleteRptControlDet = new BatchSqlUpdate(getDataSource(), DELETE_RPT_CNTL_DETAIL);
					deleteRptControlDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
					deleteRptControlDet.compile();

					for(int i=0;i<rptCustUserList.size();i++)
					{
						RptCustUser rptCustUserItem = rptCustUserList.get(i);

						deleteCustomRpt(rptCustUserItem.getRptId());

						Object[] parameterValues = new Object[]{rptCustUserItem.getRptId()};

						deleteCustomUserDet.update(parameterValues);

						Object[] parameterValues2 = new Object[]{rptCustUserItem.getRptId()};
						deleteRptControlDet.update(parameterValues2);



						reportAudit = new RptAudit(0,rptCustUserItem.getRptId(), NcasConstants.RPT_AUDIT_DELETED, rptCustUserItem.getPortalLoginId(), rptCustUserItem.getUserOid(),lastUpdated, lastUpdated, rptCustUserItem.getPortalLoginId()) ;
						auditList.add(reportAudit);
					}
					deleteCustomUserDet.flush();
					deleteRptControlDet.flush();
					for(int i=0;i<auditList.size();i++)
						insertReportAuditDetail(auditList.get(i));

					_LOGGER.info(METHOD_NAME + " Success, Rows Deleted" );
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					String[] errMsg = new String[2];
				    errMsg[0] = METHOD_NAME;
				    errMsg[1] = ex.getMessage();
					_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
					throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
				}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
	}

	@SuppressWarnings("unchecked")
	public Map updateCustomSharedReport(List<RptCustUser> rptUserList,String loginId) throws NCASException
	{
		final String METHOD_NAME = "updateCustomSharedReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate updateCustomUser = null;
		Map responseMap = new HashMap();
		int totalRowsUpdated = 0;
		if ((rptUserList != null) && (rptUserList.size() > 0))
		{
				_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_CUSTOM_USER_SHARED_DETAILS);
				try
				{
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
					String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

					updateCustomUser = new BatchSqlUpdate(getDataSource(), UPDATE_CUSTOM_USER_SHARED_DETAILS);
					updateCustomUser.declareParameter(new SqlParameter("SHARE_IND", Types.CHAR));
					updateCustomUser.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
					updateCustomUser.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
					updateCustomUser.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));

					updateCustomUser.compile();

					for(int i=0;i<rptUserList.size();i++)
					{
						RptCustUser rptUser = rptUserList.get(i);
						Object[] parameterValues = new Object[]{rptUser.getShareInd(),lastUpdated,loginId,rptUser.getRptCustomUserId()};
						int rowsUpdated = updateCustomUser.update(parameterValues);
						totalRowsUpdated += rowsUpdated;
					}
					updateCustomUser.flush();
					responseMap.put("ROWS_UPDATED", totalRowsUpdated + "");
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					String[] errMsg = new String[2];
				    errMsg[0] = METHOD_NAME;
				    errMsg[1] = ex.getMessage();
					_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
					throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
				}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}



	@SuppressWarnings("unchecked")
	public Map getReportRecurDetails(String rptRecurId) throws NCASException {
		final String METHOD_NAME = "getReportRecurDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_RPT_RECUR_DETAILS);

		try
		{
			List<RptRecur> rptRecurList = getDBTemplate().query(SELECT_RPT_RECUR_DETAILS + rptRecurId, new GetRptRecurDetResultSetRowMapper());
			responseMap.put("RESULT_SET_ONE", rptRecurList.get(0));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public List<RptRecur> getBatchReportRecurDetails() throws NCASException {
		final String METHOD_NAME = "getBatchReportRecurDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_ELGIBLE_RECUR_RPT_FOR_PROCESS);

		List<RptRecur> rptRecurList = new ArrayList<RptRecur>();
		try
		{
			rptRecurList = getDBTemplate().query(SELECT_ELGIBLE_RECUR_RPT_FOR_PROCESS, new GetRptRecurCntlSetRowMapper());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return rptRecurList;
	}

	@SuppressWarnings("unchecked")
	public int insertReportRecurDetails(RptRecur reportRecur) throws NCASException {
		final String METHOD_NAME = "insertReportRecurDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		SqlUpdate insertRptRecurDet = null;
		int recurId = 0;
		if (reportRecur != null)
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_RPT_RECUR_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				insertRptRecurDet = new SqlUpdate(getDataSource(), INSERT_RPT_RECUR_DETAILS);
				KeyHolder keyHolder = new GeneratedKeyHolder();

				insertRptRecurDet.setReturnGeneratedKeys(true);
				insertRptRecurDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
				insertRptRecurDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("STRUCT_TYPE", Types.CHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("STRUCT_OID", Types.DECIMAL));
				insertRptRecurDet.declareParameter(new SqlParameter("POSITION_TYPE", Types.CHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("POSITION_OID", Types.DECIMAL));
				insertRptRecurDet.declareParameter(new SqlParameter("STATUS", Types.VARCHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("RECUR_DAY", Types.INTEGER));
				insertRptRecurDet.declareParameter(new SqlParameter("FREQUENCY", Types.CHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("START_DATE", Types.DATE));
				insertRptRecurDet.declareParameter(new SqlParameter("END_DATE", Types.DATE));
				insertRptRecurDet.declareParameter(new SqlParameter("NEXT_SCHEDULE_DATE", Types.DATE));
				insertRptRecurDet.declareParameter(new SqlParameter("EMAIL_ADDR", Types.LONGVARCHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("RQST_LINK_PARAM", Types.LONGVARCHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("RQST_SORT_PARAM", Types.LONGVARCHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("RQST_FILTER_PARAM", Types.LONGVARCHAR));
				insertRptRecurDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
				insertRptRecurDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertRptRecurDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertRptRecurDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

				insertRptRecurDet.compile();

					Object[] parameterValues = new Object[]{reportRecur.getRptId(),
							reportRecur.getPortalLoginId(),
                            reportRecur.getStructType(),
                            new Double(reportRecur.getStructOid()),
                            reportRecur.getPositionType(),
                            new Double(reportRecur.getPositionOid()),
                            reportRecur.getStatus(),
                            reportRecur.getRecurDay(),
                            reportRecur.getFrequency(),
                            reportRecur.getStartDate(),
                            reportRecur.getEndDate(),
                            reportRecur.getNextScheduleDate(),
                            reportRecur.getEmailAddr(),
                            reportRecur.getPageSubset(),
                            reportRecur.getRqstLinkParam(),
                            reportRecur.getRqstSortParam(),
                            reportRecur.getRqstFilterParam(),
                            new Double(reportRecur.getUserOid()),
                            lastUpdated.trim(),
                            lastUpdated.trim(),
                            reportRecur.getPortalLoginId()};
					insertRptRecurDet.update(parameterValues, keyHolder);
					recurId = keyHolder.getKey().intValue();
					reportRecur.setRptRecurId(recurId);
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + recurId);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return recurId;
	}

	@SuppressWarnings("unchecked")
	public Map updateReportRecurDetails(RptRecur rptRecurItem) throws NCASException {
		final String METHOD_NAME = "updateReportRecurDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		SqlUpdate updateRptRecurDet = null;
		int totalRowsUpdated = 0;
		_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_RPT_RECUR_DETAILS);

			try
			{

				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				updateRptRecurDet = new SqlUpdate(getDataSource(), UPDATE_RPT_RECUR_DETAILS);

				updateRptRecurDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("STATUS", Types.VARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("RECUR_DAY", Types.INTEGER));
				updateRptRecurDet.declareParameter(new SqlParameter("START_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("END_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("NEXT_SCHEDULE_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("EMAIL_ADDR", Types.LONGVARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
				updateRptRecurDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateRptRecurDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("RPT_RECUR_ID", Types.INTEGER));

				updateRptRecurDet.compile();
				Date nextSchDate = Date.valueOf(CommonUtil.getNextSchDateForRpt("",rptRecurItem.getRecurDay()));

				Object[] parameterValues = new Object[]{
                                                            rptRecurItem.getPortalLoginId(),
                                                            rptRecurItem.getStatus(),
                                                            rptRecurItem.getRecurDay(),
                                                            rptRecurItem.getStartDate(),
                                                            rptRecurItem.getEndDate(),
                                                            nextSchDate,
                                                            rptRecurItem.getEmailAddr(),
                                                             rptRecurItem.getUserOid(),
							                                lastUpdated.trim(),
							                                rptRecurItem.getPortalLoginId(),
							                                rptRecurItem.getRptRecurId()};
				int rowsUpdated = updateRptRecurDet.update(parameterValues);
				totalRowsUpdated += rowsUpdated;
				responseMap.put("ROWS_UPDATED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Updated=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}

		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map updateNextSchDateForRptRecur(List<RptRecur> reportRecurList) throws NCASException
	{
		final String METHOD_NAME = "updateNextSchDateForRptRecur::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		BatchSqlUpdate updateRptRecurDet = null;
		int totalRowsUpdated = 0;
		int nextRptRecurId = -1;

		if ((reportRecurList != null) && (reportRecurList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_NEXT_SCH_DATE_RPT_RECUR);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				updateRptRecurDet = new BatchSqlUpdate(getDataSource(), UPDATE_NEXT_SCH_DATE_RPT_RECUR);
				updateRptRecurDet.declareParameter(new SqlParameter("END_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("NEXT_SCHEDULE_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateRptRecurDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("RPT_REQUEST_ID", Types.INTEGER));
				//updateRptRecurDet.declareParameter(new SqlParameter(3, Types.DECIMAL));
				updateRptRecurDet.compile();

				for(int i=0;i<reportRecurList.size();i++)
				{
					RptRecur rptRecurItem = reportRecurList.get(i);
					nextRptRecurId = rptRecurItem.getRptRecurId();
					String tempNextSchDate = "1900-01-01";
					String endDate = "1900-01-01";
					if(rptRecurItem.isRecur()){
						tempNextSchDate = CommonUtil.getNextSchDateForRpt("",rptRecurItem.getRecurDay());
						endDate = rptRecurItem.getEndDate();
					}



						Object[] parameterValues = new Object[]{endDate,tempNextSchDate,
																lastUpdated,
																NcasConstants.BATCH_RPT,
																rptRecurItem.getRptRecurId()};
						int rowsUpdated = updateRptRecurDet.update(parameterValues);
						totalRowsUpdated += rowsUpdated;

				}
				updateRptRecurDet.flush();
				responseMap.put("ROWS_UPDATED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Updated=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				String errorDetail = METHOD_NAME + " Failed when updating a row with RPT_RECUR_ID = "+nextRptRecurId+"\n"+ex.getMessage();
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = errorDetail;
				_LOGGER.error(errorDetail);
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map deleteReportRecurDetails(List<RptRecur> reportRecurList) throws NCASException {
		final String METHOD_NAME = "deleteReportRecurDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		BatchSqlUpdate updateRptRecurDet = null;
		_LOGGER.info(METHOD_NAME+"DELETE SQL: " + DELETE_RPT_RECUR_DETAILS);


		int totalRowsUpdated = 0;
		if ((reportRecurList != null) && (reportRecurList.size() > 0))
		{
			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
				updateRptRecurDet = new BatchSqlUpdate(getDataSource(), DELETE_RPT_RECUR_DETAILS);
				updateRptRecurDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("STATUS", Types.VARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("END_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("NEXT_SCHEDULE_DATE", Types.DATE));
				updateRptRecurDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
				updateRptRecurDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateRptRecurDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				updateRptRecurDet.declareParameter(new SqlParameter("RPT_RECUR_ID", Types.INTEGER));

				updateRptRecurDet.compile();
				java.sql.Date infiniteDate = java.sql.Date.valueOf("9999-12-31");
				for(int i=0;i<reportRecurList.size();i++)
				{
					RptRecur rptRecurItem = reportRecurList.get(i);
					Object[] parameterValues = new Object[]{
                                                            rptRecurItem.getPortalLoginId(),
                                                            NcasConstants.RECUR_REPORTS_CANCEL_STATUS,
                                                            java.sql.Date.valueOf(CommonUtil.getCurrentDate()),
                                                            infiniteDate,
                                                            rptRecurItem.getUserOid(),
							                                lastUpdated.trim(),
							                                rptRecurItem.getPortalLoginId(),
							                                rptRecurItem.getRptRecurId()};
					int rowsUpdated = updateRptRecurDet.update(parameterValues);
					totalRowsUpdated += rowsUpdated;
				}
				updateRptRecurDet.flush();
				responseMap.put("ROWS_UPDATED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Updated=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map getReportReqDetails(String rptRequestId) throws NCASException {
		final String METHOD_NAME = "getReportReqDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_RPT_REQUEST_DETAILS);

		try
		{
			List<RptRequest> rptRequestList = getDBTemplate().query(SELECT_RPT_REQUEST_DETAILS + rptRequestId, new GetRptRequestDetResultSetRowMapper());
			responseMap.put("RESULT_SET_ONE", rptRequestList.get(0));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public List getScheduledRptRequestDetails() throws NCASException {
		final String METHOD_NAME = "getBatchReportReqDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + BATCH_SELECT_RPT_REQUEST_DETAILS);
		List<RptRequest> rptRequestList = new ArrayList<RptRequest>();
		try
		{
			rptRequestList = getDBTemplate().query(BATCH_SELECT_RPT_REQUEST_DETAILS, new GetRptRequestDetResultSetRowMapper());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return rptRequestList;
	}

	@SuppressWarnings("unchecked")
	public Map updateRptRequestDetails(List<RptRequest> rptRequestList) throws NCASException
	{
		final String METHOD_NAME = "updateRptRequestDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate updateRequestDet = null;
		Map responseMap = new HashMap();
		int totalRowsUpdated = 0;
		if ((rptRequestList != null) && (rptRequestList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + BATCH_UPDATE_RPT_REQUEST_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				updateRequestDet = new BatchSqlUpdate(getDataSource(), BATCH_UPDATE_RPT_REQUEST_DETAILS);

				updateRequestDet.declareParameter(new SqlParameter("REQUEST_STATUS", Types.VARCHAR));
				updateRequestDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateRequestDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				updateRequestDet.declareParameter(new SqlParameter("RPT_REQUEST_ID", Types.INTEGER));

				updateRequestDet.compile();

				for(int i=0;i<rptRequestList.size();i++)
				{
					RptRequest rptRequestItem = rptRequestList.get(i);
					Object[] parameterValues = new Object[]{rptRequestItem.getRequestStatus(),
							                                lastUpdated,
							                                NcasConstants.BATCH_RPT_RECUR,
							                                rptRequestItem.getRptRequestId()};
					int rowsUpdated = updateRequestDet.update(parameterValues);
					totalRowsUpdated += rowsUpdated;
				}
				updateRequestDet.flush();
				responseMap.put("ROWS_UPDATED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Updated=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

public Map insertReportReqDetails(List<RptRequest> reportReqList) throws NCASException
	{
		final String METHOD_NAME = "insertReportReqDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate insertRptDet = null;
		Map responseMap = new HashMap();
		int totalRowsUpdated = 0;
		int nextRptRecurId = -1;

		if ((reportReqList != null) && (reportReqList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_RPT_REQUEST_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				insertRptDet = new BatchSqlUpdate(getDataSource(), INSERT_RPT_REQUEST_DETAILS);
				KeyHolder keyHolder = new GeneratedKeyHolder();

				insertRptDet.setReturnGeneratedKeys(true);
				insertRptDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
				insertRptDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
				insertRptDet.declareParameter(new SqlParameter("RPT_TYPE", Types.CHAR));
				insertRptDet.declareParameter(new SqlParameter("RPT_RECUR_ID", Types.INTEGER));
				insertRptDet.declareParameter(new SqlParameter("STRUCTURE_TYPE", Types.CHAR));
				insertRptDet.declareParameter(new SqlParameter("STRUCTURE_OID", Types.DECIMAL));
				insertRptDet.declareParameter(new SqlParameter("POSITION_TYPE", Types.CHAR));
				insertRptDet.declareParameter(new SqlParameter("POSITION_OID", Types.DECIMAL));
				insertRptDet.declareParameter(new SqlParameter("REQUEST_STATUS", Types.VARCHAR));
				insertRptDet.declareParameter(new SqlParameter("ERROR_DESCRIPTION", Types.LONGVARCHAR));
				insertRptDet.declareParameter(new SqlParameter("RPT_PROCESS_TS", Types.TIMESTAMP));
				insertRptDet.declareParameter(new SqlParameter("RPT_REQUEST_TS", Types.TIMESTAMP));
				insertRptDet.declareParameter(new SqlParameter("EMAIL_ADDR", Types.LONGVARCHAR));
				insertRptDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
				insertRptDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
				insertRptDet.declareParameter(new SqlParameter("DOWNLOAD_DESCRIPTION", Types.LONGVARCHAR));
				insertRptDet.declareParameter(new SqlParameter("RQST_LINK_PARAM", Types.LONGVARCHAR));
				insertRptDet.declareParameter(new SqlParameter("RQST_SORT_PARAM", Types.LONGVARCHAR));
				insertRptDet.declareParameter(new SqlParameter("RQST_FILTER_PARAM", Types.LONGVARCHAR));
				insertRptDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
				insertRptDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertRptDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertRptDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

				insertRptDet.compile();

				List reportReqListOut = new ArrayList();
				for(int i=0;i<reportReqList.size();i++)
				{
					RptRequest rptReqItem = reportReqList.get(i);
					nextRptRecurId = rptReqItem.getRptRecurId();
					if(rptReqItem.getRptType().equals(NcasConstants.REPORTS_TYPE_ONETIME))
						rptReqItem.setRptRequestTs(lastUpdated);
					Object[] parameterValues = new Object[]{rptReqItem.getRptId(),
															rptReqItem.getPortalLoginId(),
															rptReqItem.getRptType(),
															rptReqItem.getRptRecurId(),
															rptReqItem.getStructType(),
															new Double(rptReqItem.getStructOid()),
															rptReqItem.getPositionType(),
															new Double(rptReqItem.getPositionOid()),
															rptReqItem.getRequestStatus(),
															rptReqItem.getErrDescription(),
															"1900-01-01 00.00.00.000",rptReqItem.getRptRequestTs(),
															getUserEmail(rptReqItem.getPortalLoginId(),rptReqItem.getEmailAddr(),rptReqItem.getRptType()),
															rptReqItem.getPageId(),
															rptReqItem.getPageSubset(),
															rptReqItem.getDownloadDescription(),
															rptReqItem.getRqstLinkParam(),
															rptReqItem.getRqstSortParam(),
															rptReqItem.getRqstFilterParam(),
															new Double(rptReqItem.getUserOid()),
												            lastUpdated.trim(),
							                                lastUpdated.trim(),
							                                rptReqItem.getLastUpdatedBy()};

					int rowsUpdated = insertRptDet.update(parameterValues, keyHolder);
					totalRowsUpdated += rowsUpdated;
					rptReqItem.setRptRequestId(keyHolder.getKey().intValue());
					reportReqListOut.add(rptReqItem);
				}
				insertRptDet.flush();
				responseMap.put("ROWS_INSERTED", totalRowsUpdated + "");
				responseMap.put("reportReqListOut", reportReqListOut);
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				String errorDetail = METHOD_NAME + " Failed when inserting a row with RPT_RECUR_ID = "+nextRptRecurId+"\n"+ex.getMessage();
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = errorDetail;
				_LOGGER.error(errorDetail);
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return responseMap;
	}



public Map updateReportReqDetails(List<RptRequest> reportReqList) throws NCASException
{
	final String METHOD_NAME = "updateReportReqDetails::";
	_LOGGER.info(METHOD_NAME+"Entering");
	BatchSqlUpdate updateRptDet = null;
	Map responseMap = new HashMap();
	int totalRowsUpdated = 0;
	int rptRequestId = -1;

	if ((reportReqList != null) && (reportReqList.size() > 0))
	{
		_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_RPT_REQUEST_DETAILS);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			updateRptDet = new BatchSqlUpdate(getDataSource(), UPDATE_RPT_REQUEST_DETAILS);

			updateRptDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
			updateRptDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
			updateRptDet.declareParameter(new SqlParameter("RPT_TYPE", Types.CHAR));
			updateRptDet.declareParameter(new SqlParameter("RPT_RECUR_ID", Types.INTEGER));
			updateRptDet.declareParameter(new SqlParameter("STRUCTURE_TYPE", Types.CHAR));
			updateRptDet.declareParameter(new SqlParameter("STRUCTURE_OID", Types.DECIMAL));
			updateRptDet.declareParameter(new SqlParameter("POSITION_TYPE", Types.CHAR));
			updateRptDet.declareParameter(new SqlParameter("POSITION_OID", Types.DECIMAL));
			updateRptDet.declareParameter(new SqlParameter("REQUEST_STATUS", Types.VARCHAR));
			updateRptDet.declareParameter(new SqlParameter("ERROR_DESCRIPTION", Types.LONGVARCHAR));
			updateRptDet.declareParameter(new SqlParameter("RPT_REQUEST_TS", Types.TIMESTAMP));
			updateRptDet.declareParameter(new SqlParameter("RPT_PROCESS_TS", Types.TIMESTAMP));
			updateRptDet.declareParameter(new SqlParameter("EMAIL_ADDR", Types.LONGVARCHAR));
			updateRptDet.declareParameter(new SqlParameter("PAGE_ID", Types.INTEGER));
			updateRptDet.declareParameter(new SqlParameter("PAGE_SUBSET", Types.CHAR));
			updateRptDet.declareParameter(new SqlParameter("DOWNLOAD_DESCRIPTION", Types.LONGVARCHAR));
			updateRptDet.declareParameter(new SqlParameter("RQST_LINK_PARAM", Types.LONGVARCHAR));
			updateRptDet.declareParameter(new SqlParameter("RQST_SORT_PARAM", Types.LONGVARCHAR));
			updateRptDet.declareParameter(new SqlParameter("RQST_FILTER_PARAM", Types.LONGVARCHAR));
			updateRptDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
			updateRptDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
			updateRptDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
			updateRptDet.declareParameter(new SqlParameter("RPT_REQUEST_ID", Types.INTEGER));

			updateRptDet.compile();

			List reportReqListOut = new ArrayList();
			for(int i=0;i<reportReqList.size();i++)
			{
				RptRequest rptReqItem = reportReqList.get(i);
				_LOGGER.info("rptReqItem=" + rptReqItem);
				rptRequestId = rptReqItem.getRptRequestId();
				if(rptReqItem.getRptType().equals(NcasConstants.REPORTS_TYPE_ONETIME))
					rptReqItem.setRptRequestTs(lastUpdated);
				Object[] parameterValues = new Object[]{rptReqItem.getRptId(),
														rptReqItem.getPortalLoginId(),
														rptReqItem.getRptType(),
														rptReqItem.getRptRecurId(),
														rptReqItem.getStructType(),
														new Double(rptReqItem.getStructOid()),
														rptReqItem.getPositionType(),
														new Double(rptReqItem.getPositionOid()),
														rptReqItem.getRequestStatus(),
														rptReqItem.getErrDescription(),
														rptReqItem.getRptRequestTs(),"1900-01-01 00.00.00.000",
														getUserEmail(rptReqItem.getPortalLoginId(),rptReqItem.getEmailAddr(),rptReqItem.getRptType()),
														rptReqItem.getPageId(),
														rptReqItem.getPageSubset(),
														rptReqItem.getDownloadDescription(),
														rptReqItem.getRqstLinkParam(),
														rptReqItem.getRqstSortParam(),
														rptReqItem.getRqstFilterParam(),
														new Double(rptReqItem.getUserOid()),
											            lastUpdated.trim(),
						                                rptReqItem.getLastUpdatedBy(),
						                                rptReqItem.getRptRequestId()};

				int rowsUpdated = updateRptDet.update(parameterValues);
				totalRowsUpdated += rowsUpdated;
				reportReqListOut.add(rptReqItem);
			}
			updateRptDet.flush();
			responseMap.put("ROWS_UPDATEED", totalRowsUpdated + "");
			responseMap.put("reportReqListOut", reportReqListOut);
			_LOGGER.info(METHOD_NAME + " Success, Rows updateed=" + totalRowsUpdated);
		}
		catch(Exception ex)
		{
			String errorDetail = METHOD_NAME + " Failed when updateing a row with RPT_REQUEST_ID = "+rptRequestId+"\n"+ex.getMessage();
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = errorDetail;
			_LOGGER.error(errorDetail);
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
	}
	_LOGGER.info(METHOD_NAME+" Exiting");
	return responseMap;
}




	@SuppressWarnings("unchecked")
	public Map insertReportExecDetails(List<RptExec> reportExecList) throws NCASException
	{
		final String METHOD_NAME = "insertReportExecDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate insertExecDet = null;
		Map responseMap = new HashMap();
		int totalRowsUpdated = 0;
		if ((reportExecList != null) && (reportExecList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_RPT_EXEC_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				insertExecDet = new BatchSqlUpdate(getDataSource(), INSERT_RPT_EXEC_DETAILS);
				KeyHolder keyHolder = new GeneratedKeyHolder();

				insertExecDet.setReturnGeneratedKeys(true);
				insertExecDet.declareParameter(new SqlParameter("RPT_REQUEST_ID", Types.INTEGER));
				insertExecDet.declareParameter(new SqlParameter("DISPLAY_PARAM", Types.VARCHAR));
				insertExecDet.declareParameter(new SqlParameter("FILE_DESCRIPTION", Types.VARCHAR));
				insertExecDet.declareParameter(new SqlParameter("FILE_STATUS", Types.VARCHAR));
				insertExecDet.declareParameter(new SqlParameter("ERROR_DESCRIPTION", Types.LONGVARCHAR));
				insertExecDet.declareParameter(new SqlParameter("RUN_TIMESTAMP", Types.TIMESTAMP));
				insertExecDet.declareParameter(new SqlParameter("FILE_NAME", Types.VARCHAR));
				insertExecDet.declareParameter(new SqlParameter("SIZE", Types.INTEGER));
				insertExecDet.declareParameter(new SqlParameter("ARCHIVE_DOC_NBR", Types.DECIMAL));
				insertExecDet.declareParameter(new SqlParameter("DISPLAY_END_DATE", Types.DATE));
				insertExecDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertExecDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertExecDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

				insertExecDet.compile();

				for(int i=0;i<reportExecList.size();i++)
				{
					RptExec rptExecItem = reportExecList.get(i);
					Object[] parameterValues = new Object[]{rptExecItem.getRptRequestId(),
															rptExecItem.getDisplayParam(),
															rptExecItem.getFileDescription(),
															rptExecItem.getFileStatus(),
															rptExecItem.getErrorDescription(),
															rptExecItem.getRunTimestamp(),
															rptExecItem.getFileName(),
															rptExecItem.getSize(),
															new Double(rptExecItem.getArchiveDocNbr()),
															rptExecItem.getDispalyEndDay(),
															lastUpdated.trim(),
							                                lastUpdated.trim(),
							                                rptExecItem.getLastUpdatedBy()};

					int rowsUpdated = insertExecDet.update(parameterValues, keyHolder);
					totalRowsUpdated += rowsUpdated;
					rptExecItem.setRptRequestId(keyHolder.getKey().intValue());
				}
				insertExecDet.flush();
				responseMap.put("ROWS_INSERTED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return responseMap;
	}

	@SuppressWarnings("unchecked")
	public Map deleteReportExecDetails(List<Integer> reportExecIdList) throws NCASException
	{
		final String METHOD_NAME = "deleteReportExecDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map responseMap = new HashMap();
		BatchSqlUpdate deleteRptExecDet = null;

		int totalRowsUpdated = 0;
		if ((reportExecIdList != null) && (reportExecIdList.size() > 0))
		{
			_LOGGER.info(METHOD_NAME + "SQL: " + END_DATE_RPT_EXEC_DETAILS);

			try
			{
				deleteRptExecDet = new BatchSqlUpdate(getDataSource(), END_DATE_RPT_EXEC_DETAILS);
				deleteRptExecDet.declareParameter(new SqlParameter("RPT_EXEC_ID", Types.INTEGER));

				deleteRptExecDet.compile();

				for(int i=0;i<reportExecIdList.size();i++)
				{
					Object[] parameterValues = new Object[]{reportExecIdList.get(i)};
					int rowsUpdated = deleteRptExecDet.update(parameterValues);
					totalRowsUpdated += rowsUpdated;
				}
				deleteRptExecDet.flush();
				responseMap.put("ROWS_DELETED", totalRowsUpdated + "");
				_LOGGER.info(METHOD_NAME + " Success, Rows Deleted=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return responseMap;
	}

    @SuppressWarnings("unchecked")
    public List<RptEmail> getEligibleEmailItemList() throws NCASException
    {
        final String METHOD_NAME = "getEmailItemList::";
        _LOGGER.info(METHOD_NAME+"Entering");
        List<RptEmail> rptEmailList = new ArrayList();
        _LOGGER.info(METHOD_NAME + "SQL: " + SELECT_ELIGIBLE_EMAIL_DETAILS);

        try
        {
            GetRptEmailDetResultSetRowMapper rowMapper = new GetRptEmailDetResultSetRowMapper();
            Object[] params = new Object[]{};
            rptEmailList = getDBTemplate().query(SELECT_ELIGIBLE_EMAIL_DETAILS,params,rowMapper);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            String[] errMsg = new String[2];
            errMsg[0] = METHOD_NAME;
            errMsg[1] = ex.getMessage();
            _LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
            throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
        }
        _LOGGER.info(METHOD_NAME+"Exiting");
        return rptEmailList;
    }

    @SuppressWarnings("unchecked")
    public List<VbeAftInfo> getVbeAftList(RptEmail item) throws NCASException
    {
        final String METHOD_NAME = "getVbeAftList::";
        _LOGGER.info(METHOD_NAME+"Entering");
        List<VbeAftInfo> vbeAftList = null;
        _LOGGER.info(METHOD_NAME + "SQL: " + SELECT_VBE_AFT_EMAIL_DETAILS);

        try
        {
            GetVbeAftInfoResultSetRowMapper rowMapper = new GetVbeAftInfoResultSetRowMapper();
            Object[] params = new Object[]{new Integer(item.getRptRequestId())};
            vbeAftList = getDBTemplate().query(SELECT_VBE_AFT_EMAIL_DETAILS,params,rowMapper);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            String[] errMsg = new String[2];
            errMsg[0] = METHOD_NAME;
            errMsg[1] = ex.getMessage();
            _LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
            throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
        }
        _LOGGER.info(METHOD_NAME+"Exiting");
        return vbeAftList;
    }






	@SuppressWarnings("unchecked")
	public int insertReportAuditDetail(RptAudit reportAudit) throws NCASException
	{
		final String METHOD_NAME = "insertReportAuditDetail::";
		_LOGGER.info(METHOD_NAME+"Entering");
		SqlUpdate insertAuditDet = null;
		int rowsUpdated = 0;
		_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_RPT_AUDIT);

		try
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

			insertAuditDet = new SqlUpdate(getDataSource(), INSERT_RPT_AUDIT);
			KeyHolder keyHolder = new GeneratedKeyHolder();

			insertAuditDet.setReturnGeneratedKeys(true);
			insertAuditDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
			insertAuditDet.declareParameter(new SqlParameter("ACTION_TYPE", Types.CHAR));
			insertAuditDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
			insertAuditDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
			insertAuditDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
			insertAuditDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
			insertAuditDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));

			insertAuditDet.compile();

			Object[] parameterValues = new Object[]{reportAudit.getRptId(),
					                                reportAudit.getRptActionType(),
					                                reportAudit.getPortalLoginId(),
					                                new Double(reportAudit.getUserOid()),
													lastUpdated.trim(),
					                                lastUpdated.trim(),
					                                reportAudit.getLastUpdatedBy()};

			rowsUpdated = insertAuditDet.update(parameterValues, keyHolder);
			reportAudit.setRptAuditId(keyHolder.getKey().intValue());
			_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + rowsUpdated);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return rowsUpdated;
	}

	@SuppressWarnings("unchecked")
	public void updateEmailProcDetails(int execId, long trackOid) throws NCASException
	{
		final String METHOD_NAME = "updateEmailProcDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		SqlUpdate updateEmailDet = null;


			_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_EMAIL_PROC_DETAILS);

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				updateEmailDet = new SqlUpdate(getDataSource(), UPDATE_EMAIL_PROC_DETAILS);

				updateEmailDet.declareParameter(new SqlParameter("EMAIL_TRACKING_OID", Types.DECIMAL));
				updateEmailDet.declareParameter(new SqlParameter("EMAIL_PROCESS_TSTAMP", Types.TIMESTAMP));
				updateEmailDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateEmailDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				updateEmailDet.declareParameter(new SqlParameter("RPT_EXEC_MAIL_ID", Types.INTEGER));

				updateEmailDet.compile();
				Object[] parameterValues = new Object[]{new Double(trackOid),lastUpdated.trim(),lastUpdated.trim(),	"EMAILBATCH", new Integer(execId)};
				updateEmailDet.update(parameterValues);

			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}

		_LOGGER.info(METHOD_NAME+"Exiting");

	}

	private String getUserEmailFromEcp(String loginId,String emailToAddr){
		final String METHOD_NAME = "getUserEmailFromEcp::";
		_LOGGER.info(METHOD_NAME+"Entering");
		String emailAddr = "";
		try{
			User user = DAOFactory.getInstance().getPaymentsBeanForECP().getUserFromECP(loginId);
			emailAddr = user.getEmail();
		}
		catch(Exception ex){
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
		}

		return  emailAddr+"," + emailToAddr;
	}


	private String getUserEmail(String portalLoginId, String emailToAddr,	String rptType) {
		String emailAddr = emailToAddr;
		emailAddr = getUserEmailFromEcp(portalLoginId,emailToAddr);
		return emailAddr;
	}

	@SuppressWarnings("unchecked")
	public List<CustomRptMeta> geAllCustomAttributes() throws NCASException {
		final String METHOD_NAME = "geAllCustomAttributes::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_CUST_RPT_META_DETAILS);

		List<CustomRptMeta> customRptMetaList = new ArrayList<CustomRptMeta>();
		try
		{
			customRptMetaList = getDBTemplate().query(SELECT_CUST_RPT_META_DETAILS, new GetCustomRptMetaResultSetRowMapper());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return customRptMetaList;
	}

	@SuppressWarnings("unchecked")
	public String getCustomPageId() throws NCASException
	{
		final String METHOD_NAME = "getCustomPageId::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map result = null;
		String pageId = "";
		try
		{
			SPGetCustomPageId spObj = new SPGetCustomPageId(getDataSource(),
															getSchemaName());
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			result = spObj.executeStoredProcedure(debugLevel);
			pageId = (String)result.get("PAGE_ID");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return pageId;
	}

	@SuppressWarnings("unchecked")
	public Map getCustomFilterInfo(Map inpMap) throws NCASException
	{
		final String METHOD_NAME = "getCustomFilterInfo::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map result = null;

		try
		{
			SPGetCustomFilterInfo spObj = new SPGetCustomFilterInfo(getDataSource(),
																	getSchemaName());
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			result = spObj.executeStoredProcedure(debugLevel, Integer.parseInt((String)inpMap.get("RPT_ID")));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return result;
	}

	@SuppressWarnings("unchecked")
	public Map setCustomFilterInfo(Map inpMap) throws NCASException
	{
		final String METHOD_NAME = "setCustomFilterInfo::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map result = null;

		try
		{
			SPSetCustomFilterInfo spObj = new SPSetCustomFilterInfo(getDataSource(),
																	getSchemaName());
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			result = spObj.executeStoredProcedure(debugLevel, Integer.parseInt((String)inpMap.get("RPT_ID")),
												  (String)inpMap.get("RPT_FILTERS"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return result;
	}

	@SuppressWarnings("unchecked")
	public Map deleteCustomRpt(int rptId) throws NCASException
	{
		final String METHOD_NAME = "deleteCustomRpt::";
		_LOGGER.info(METHOD_NAME + "Entering");
		Map result = null;

		try
		{
			SPDeleteCustomRpt spObj = new SPDeleteCustomRpt(getDataSource(),
															getSchemaName());
			String debugLevel = CommonUtil.getDebugLevel(NCASBOSIConstants.BILL_VIEW_DEUBG_LEVEL);
			result = spObj.executeStoredProcedure(debugLevel, rptId);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME + " Exiting");
		return result;
	}

	public Boolean getShared(String sql,Object[] params) {
		final String METHOD_NAME = "getShared => ";
		_LOGGER.info(METHOD_NAME+" Entering");
        return  (Boolean)getDBTemplate().query(sql, params, new ResultSetExtractor() {
	        public Object extractData(ResultSet rs) throws SQLException {
	        	  boolean dups = false;
				  if (rs.next())dups = true;
				  return new Boolean(dups);
	  }});
	}


	public boolean isDuplicateReport(String userOid,String rptName,String section) throws NCASException {
		final String METHOD_NAME = "isDuplicateReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		boolean isDuplicate = false;
		String sqlDefault = "B.USER_OID=" + userOid;
		String sql = SELECT_SHARED_RPT_DUPS1;

		try{
			 if (section.equalsIgnoreCase("Wireless")){

						String ecpdString = "";
						_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_SHARED_RPT_DUPS1);
						List<Double> ecpdIdList = DAOFactory.getInstance().getPaymentsBeanForECP().selectAllECPDIdsForUser(new Double(userOid).doubleValue());
						for(int i=0;i<ecpdIdList.size();i++){
							if(!ecpdString.isEmpty())
								ecpdString += ",";
							ecpdString += ecpdIdList.get(i);
						}
						if(!ecpdString.isEmpty())
							sqlDefault = "B.ECPD_ID IN (" + ecpdString + " )";
			 }

			 sql += sqlDefault + SELECT_SHARED_RPT_DUPS2;
				Object[] params = new Object[]{new String(rptName)};
				if(getShared(sql,params))
					isDuplicate = true;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
		return isDuplicate;
	}



	@SuppressWarnings("unchecked")
	public void insertRptChoices(List<CustomRptField> fields,String rptId) throws NCASException
	{
		final String METHOD_NAME = "insertRptChoices::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate insertRptChoice = null;
		if ((fields != null) && (fields.size() > 0))
		{
			try
			{
				List current = getCustRptChoices(rptId,new ArrayList());
				if(current!=null&&current.size()>0){
					SqlUpdate deleteCustChoices = new SqlUpdate(getDataSource(), DELETE_CUST_RPT_CHOICES);
					deleteCustChoices.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
					deleteCustChoices.compile();
					Object[] parameterValues2 = new Object[]{Integer.parseInt(rptId)};
					deleteCustChoices.update(parameterValues2);
				}
				_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_CUST_RPT_CHOICES);
				insertRptChoice = new BatchSqlUpdate(getDataSource(), INSERT_CUST_RPT_CHOICES);
				insertRptChoice.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));
				insertRptChoice.declareParameter(new SqlParameter("FIELD_NAME", Types.VARCHAR));
				insertRptChoice.declareParameter(new SqlParameter("SOURCE_ABBR", Types.CHAR));
				insertRptChoice.declareParameter(new SqlParameter("APPLIED_FUNCTION", Types.CHAR));
				insertRptChoice.declareParameter(new SqlParameter("OUTPUT_FMT", Types.CHAR));
				insertRptChoice.declareParameter(new SqlParameter("SORT_ORDINAL", Types.INTEGER));
				insertRptChoice.declareParameter(new SqlParameter("GROUP_ORDINAL", Types.INTEGER));
				insertRptChoice.declareParameter(new SqlParameter("DISPLAY_ORDINAL", Types.INTEGER));
				insertRptChoice.declareParameter(new SqlParameter("FIELD_GROUP", Types.VARCHAR));

				insertRptChoice.compile();

				for(int i = 0;i<fields.size();i++)
				{
					CustomRptField rptField = fields.get(i);
					Object[] parameterValues = new Object[]{new Integer(rptId),rptField.getFieldName(),rptField.getSource(),"","",0,0,i+1,rptField.getFieldGrp()};
					insertRptChoice.update(parameterValues);
				}
				insertRptChoice.flush();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}

		}
		_LOGGER.info(METHOD_NAME+" Exiting");

	}



	public String getSharedReport(String rptId, String userOid)throws NCASException
	{
		// TODO Auto-generated method stub
		final String METHOD_NAME = "getSharedReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_CUSTOM_USER_DETAILS);
		Map responseMap = new HashMap();
		String isShared = "N";
		try
		{
			GetCustomRptUser rowMapper = new GetCustomRptUser();
			Object[] params = new Object[]{new Integer(rptId),new Double(userOid)};
			List custUserList = getDBTemplate().query(SELECT_CUSTOM_USER_DETAILS,params,rowMapper);
			if(custUserList!=null &&custUserList.size()>0)
				isShared = ((RptCustUser)custUserList.get(0)).getShareInd();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return isShared;
	}

	public List getCustomRptList(String userOid)throws NCASException
	{
		final String METHOD_NAME = "isCustomExists::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_ICI_CUSTOM_RPT);
		Map responseMap = new HashMap();
		List rptList = new ArrayList();
		try
		{
			Object[] params = new Object[]{new Double(userOid)};
			rptList = (List)getDBTemplate().query(SELECT_ICI_CUSTOM_RPT, params, new ResultSetExtractor() {
				        public Object extractData(ResultSet rs) throws SQLException {
				        	List<RptCntl> rptList = new ArrayList<RptCntl>();
				        	while (rs.next()) {
				        		RptCntl rpt = new RptCntl();
				        		rpt.setRptId(rs.getInt("RPT_ID"));
				        		rpt.setPageId(rs.getInt("PAGE_ID"));
				        		rptList.add(rpt);
				        	}
				        	return rptList;
				        }
				        });


		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return rptList;
	}

	public List<CustomRptField> getCustRptChoices(String rptID,List<CustomRptField> fieldList ) throws NCASException
	{
		final String METHOD_NAME = "getCustRptChoices::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_CUST_RPT_CHOICES);
		Map responseMap = new HashMap();
		if(fieldList == null)
			fieldList = new ArrayList();
		try
		{
			GetCustRptChoicesResultSetRowMapper rowMapper = new GetCustRptChoicesResultSetRowMapper();
			Object[] params = new Object[]{Integer.parseInt(rptID)};
			List custList = getDBTemplate().query(SELECT_CUST_RPT_CHOICES,params,rowMapper);
			fieldList.addAll(custList);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return fieldList;
	}

	public List<CustomRptField> getGlobalFields(String section) throws NCASException
	{
		final String METHOD_NAME = "getGlobalFields::";
		_LOGGER.info(METHOD_NAME+"Entering");
		_LOGGER.info(METHOD_NAME + "SQL: " + SELECT_CUST_RPT_GLOBAL_FIELDS);
		Map responseMap = new HashMap();
		List<CustomRptField> fieldList = new ArrayList();
		try
		{
			GetCustRptChoicesResultSetRowMapper rowMapper = new GetCustRptChoicesResultSetRowMapper();
			Object[] params = new Object[]{section.toUpperCase()};
			fieldList = getDBTemplate().query(SELECT_CUST_RPT_GLOBAL_FIELDS,params,rowMapper);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
		return fieldList;
	}



	@SuppressWarnings("unchecked")
	public void updateReportControlCustom(String name, String desc,String loginid,int rptId) throws NCASException
	{
		final String METHOD_NAME = "updateReportControlDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		SqlUpdate updateRptCntlDet = null;
			_LOGGER.info(METHOD_NAME + "SQL: " + UPDATE_RPT_CNTL_CUSTOM);
			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				updateRptCntlDet = new SqlUpdate(getDataSource(), UPDATE_RPT_CNTL_CUSTOM);
				updateRptCntlDet.declareParameter(new SqlParameter("RPT_NAME", Types.VARCHAR));
				updateRptCntlDet.declareParameter(new SqlParameter("REPORT_DESCRIPTION", Types.VARCHAR));
				updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				updateRptCntlDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));
				updateRptCntlDet.declareParameter(new SqlParameter("RPT_ID", Types.INTEGER));

				updateRptCntlDet.compile();

					Object[] parameterValues = new Object[]{
							name,
							desc,
							lastUpdated.trim(),
							loginid,
							rptId};
					updateRptCntlDet.update(parameterValues);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		_LOGGER.info(METHOD_NAME+"Exiting");
	}

	public String stack2string(Exception e) {
		try {
			InetAddress localHost = InetAddress.getLocalHost();
		    StringWriter sw = new StringWriter();
		    PrintWriter pw = new PrintWriter(sw);
		    e.printStackTrace(pw);
		    return "------\r\n Host-IP:" + localHost.getHostAddress() + "------\r\n"+"------\r\n" + sw.toString() + "------\r\n";
		} catch(Exception e2) {
		    return "bad stack2string";
		}
	}



	public void insertViewAudit(List auditList) throws NCASException
	{
		final String METHOD_NAME = "insertViewAudit::";
		_LOGGER.info(METHOD_NAME+"Entering");
		BatchSqlUpdate insertAuditDet = null;
		int totalRowsUpdated = 0;
		String defaultDate = "1900-01-01";
		_LOGGER.info(METHOD_NAME + "SQL: " + INSERT_VIEW_AUDIT);
		if ((auditList != null) && (auditList.size() > 0))
		{

			try
			{
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
				String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));

				insertAuditDet = new BatchSqlUpdate(getDataSource(), INSERT_VIEW_AUDIT);

				insertAuditDet.declareParameter(new SqlParameter("ACCESS_TYPE", Types.CHAR));
				insertAuditDet.declareParameter(new SqlParameter("MAN", Types.CHAR));
				insertAuditDet.declareParameter(new SqlParameter("BAN", Types.CHAR));
				insertAuditDet.declareParameter(new SqlParameter("ABAN", Types.CHAR));
				insertAuditDet.declareParameter(new SqlParameter("BILL_DATE", Types.DATE));
				insertAuditDet.declareParameter(new SqlParameter("OSID", Types.CHAR));
				insertAuditDet.declareParameter(new SqlParameter("USER_OID", Types.DECIMAL));
				insertAuditDet.declareParameter(new SqlParameter("PORTAL_LOGIN_ID", Types.VARCHAR));
				insertAuditDet.declareParameter(new SqlParameter("IMP_LOGIN_ID", Types.VARCHAR));
				insertAuditDet.declareParameter(new SqlParameter("CREATED_TIMESTAMP", Types.TIMESTAMP));
				insertAuditDet.declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertAuditDet.declareParameter(new SqlParameter("LAST_UPDATED_BY", Types.VARCHAR));


				insertAuditDet.compile();
				for(int i = 0;i<auditList.size();i++){
					Audit auditDetail  = (Audit)auditList.get(i);
					if(auditDetail.getBillDate().isEmpty())
						auditDetail.setBillDate(defaultDate);
					Object[] parameterValues = new Object[]{auditDetail.getAccessType(),auditDetail.getMan(),auditDetail.getBan(),auditDetail.getAban(),java.sql.Date.valueOf(auditDetail.getBillDate()),auditDetail.getOsid(),auditDetail.getUserOid(),auditDetail.getLoginId(),
							auditDetail.getImpLoginId(),lastUpdated, lastUpdated, auditDetail.getImpLoginId()};
					int rowsUpdated = insertAuditDet.update(parameterValues);
					totalRowsUpdated += rowsUpdated;
				}
				insertAuditDet.flush();
				_LOGGER.info(METHOD_NAME + " Success, Rows Inserted=" + totalRowsUpdated);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				String[] errMsg = new String[2];
			    errMsg[0] = METHOD_NAME;
			    errMsg[1] = ex.getMessage();
				_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
				throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
			}
		}
		_LOGGER.info(METHOD_NAME+"Exiting");
	}
}