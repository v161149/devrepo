package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;

import com.verizon.enterprise.common.ncas.approval.Designation;

public class VBIFInsertDesignation extends SqlUpdate{

	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	
	public VBIFInsertDesignation(DataSource dataSource,String sql) {
		super(dataSource, sql);	
		declareParametersForInsertingDesignation();//this is for type safety
		compile();		
	}
	
	private void declareParametersForInsertingDesignation(){
		declareParameter(new SqlParameter("DESIGNATOR_ID",Types.VARCHAR));
		declareParameter(new SqlParameter("APPROVER_ID",Types.VARCHAR));
		declareParameter(new SqlParameter("START_DATE",Types.DATE));
		declareParameter(new SqlParameter("END_DATE",Types.DATE));
		declareParameter(new SqlParameter("LAST_UPDATED_BY",Types.VARCHAR));
		declareParameter(new SqlParameter("LAST_UPD_TIMESTAMP",Types.TIMESTAMP));
	}
	
	public void insertDesignation(Designation designationInfo) throws Exception{		
		 String METHOD_NAME="VBIFInsertDesignation->insertDesignation::";
		_LOGGER.info(METHOD_NAME+this.getSql());
		
	
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
		String createdTimestamp = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
		_LOGGER.error("Timestamp: " + createdTimestamp);

		Object[] params = new Object[]{designationInfo.getUserDelegation().getDesignatorVZID(),designationInfo.getUserDelegation().getApproverVZID(), 
				designationInfo.getUserDelegation().getStartDate(), designationInfo.getUserDelegation().getEndDate(),designationInfo.getUserDelegation().getLastUpdatedBy(),
				createdTimestamp};
		
		this.update(params);
	}
}