package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.vzbreports.ScheduleReportData;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;

public class SPUpdateScheduledRpt extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger
			.getLogger(SPGetReportStatuses.class);

	private static List spInOutList;

	//private static GetUserRptScheduledRowMapperImpl rowMapper;

	static {
		//rowMapper = new GetUserRptScheduledRowMapperImpl();
		spInOutList = new ArrayList();
		spInOutList.add(new Object[] { "APP_USER_ID",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "DEBUG_LEVEL",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });

		spInOutList.add(new Object[] { "RETURN_CODE",getSqlDataType(Types.INTEGER),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "REASON_CODE",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "ERROR_TEXT",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLCODE",getSqlDataType(Types.INTEGER),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLTOKENS",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLSTATE",getSqlDataType(Types.VARCHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });

		spInOutList.add(new Object[] { "ACTION",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "SCHEDULED_RPT_ID",getSqlDataType(Types.TIMESTAMP),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "NEW_SCHEDULED_DATE",getSqlDataType(Types.DATE),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "NEW_FREQUENCY",	getSqlDataType(Types.CHAR),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "NEW_BILL_DATE",	getSqlDataType(Types.DATE),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "NEW_THRU_DATE",	getSqlDataType(Types.DATE),	NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
	}

	public SPUpdateScheduledRpt(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "."
				+ NCASBOSIConstants.SP_UPDT_SCHEDULED_RPT, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel,
			Map inputMap) throws Exception {
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		
		StringBuffer myParams = new StringBuffer();

		myParams.append("SP Params [");

		paramValueList.add(userId);// APP_USER_ID
		myParams.append(userId + "^");
		paramValueList.add(debugLevel);// DEBUG_LEVEL
		myParams.append(debugLevel + "^");
		paramValueList.add((String) inputMap.get("action")); // ACTION
		myParams.append((String) inputMap.get("action") + "^");
		
/*		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		paramValueList.add(ft.format(scheduledRptId));// SCHEDULED_RPT_ID

		//paramValueList.add(scheduledRptId);
		myParams.append(ft.format(scheduledRptId) + "^");
		*/
		
		String dateString = ""	; 
/*		if (newSchedDate !=  null)
		{
			SimpleDateFormat formatter
			= new SimpleDateFormat("yyyy-MM-dd");
			      
			dateString = formatter.format(newSchedDate);
		}
		*/
		paramValueList.add((String) inputMap.get("scheduledRptId"));		// SCHEDULED_RPT_ID	
		myParams.append(inputMap.get("scheduledRptId") + "^");
		
		
		//Date schedDt = new SimpleDateFormat("MM-dd-yyyy").parse((String) inputMap.get("newSchedDate"));
		//String strSchedDt = new SimpleDateFormat("yyyy-MM-dd").format(schedDt);
		
		String strSchedDt = (String) inputMap.get("newSchedDate");
				
		paramValueList.add(strSchedDt);		// NEW_SCHEDULED_DATE	
		myParams.append(strSchedDt + "^");
		
		paramValueList.add((String) inputMap.get("newFrequency"));// NEW_FREQUENCY
		myParams.append((String) inputMap.get("newFrequency") + "^");

		dateString = ""	; 
/*		if (newBillDate !=  null)
		{
			SimpleDateFormat formatter
			= new SimpleDateFormat("yyyy-MM-dd");
			      
			dateString = formatter.format(newBillDate);
		}
		*/
		//Date billDt = new SimpleDateFormat("MM-dd-yyyy").parse((String) inputMap.get("newBillDate"));
		//String strBillDt = new SimpleDateFormat("yyyy-MM-dd").format(billDt);
		String strBillDt = (String) inputMap.get("newBillDate");
		

		paramValueList.add(strBillDt);		// NEW_BILL_DATE	
		myParams.append(strBillDt + "^");

		dateString = ""	; 
		/*if (newThruDate !=  null)
		{
			SimpleDateFormat formatter
			= new SimpleDateFormat("yyyy-MM-dd");
			      
			dateString = formatter.format(newThruDate);
		}*/
		//Date thruDt = new SimpleDateFormat("MM-dd-yyyy").parse((String) inputMap.get("newThruDate"));
		//String strThruDt = new SimpleDateFormat("yyyy-MM-dd").format(thruDt);
		
		String strThruDt  = (String) inputMap.get("newThruDate");
		paramValueList.add(strThruDt);		// NEW_THRU_DATE	
		myParams.append(strThruDt + "^");
		
		_LOGGER.debug("SPUpdateScheduledRpt:executeStoredProcedure" + myParams.toString());
		

		return executeStoredProcedure(paramValueList) ;
	}

	public Map executeStoredProcedure(Object paramValues) throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
