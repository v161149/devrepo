package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;

public class BISearchDataMapper implements RowMapper
{

	static private final Logger _LOGGER = Logger.getLogger(BISearchDataMapper.class);


	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		BillInquiry resBI = null;

		_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry.BISearchDataMapper");
		if(rs != null)
		{
			resBI = new BillInquiry();


			resBI.setStatus(rs.getString("BI_STATUS_DESC"));
			_LOGGER.info("BI_STATUS_DESC = "+rs.getString("BI_STATUS_DESC"));

			resBI.setReasonCode(rs.getString("BI_REASON_CODE"));
			_LOGGER.info("BI_REASON_CODE = "+rs.getString("BI_REASON_CODE"));

			resBI.setReason(rs.getString("BI_REASON_DESC"));
			_LOGGER.info("BI_REASON_DESC = "+rs.getString("BI_REASON_DESC"));

			resBI.setSrcSysBIID(rs.getString("SRC_SYS_BI_ID"));
			_LOGGER.info("SRC_SYS_BI_ID = "+rs.getString("SRC_SYS_BI_ID"));

			resBI.setBICategory(rs.getString("BI_CATEGORY"));
			_LOGGER.info("BI_CATEGORY = "+rs.getString("BI_CATEGORY"));

			resBI.setOSID(rs.getString("ORIGINATING_SYS_ID"));
			_LOGGER.info("ORIGINATING_SYS_ID = "+rs.getString("ORIGINATING_SYS_ID"));

			resBI.setOrigLogin(rs.getString("ORIGINATOR_LOGINID"));
			_LOGGER.info("ORIGINATOR_LOGINID = "+rs.getString("ORIGINATOR_LOGINID"));

			resBI.setBAN(rs.getString("BAN"));
			_LOGGER.info("BAN = "+rs.getString("BAN"));

			resBI.setSAN(rs.getString("MAN"));
			_LOGGER.info("MAN = "+rs.getString("MAN"));

			resBI.setAcctName(rs.getString("ACCOUNT_NAME"));
			_LOGGER.info("ACCOUNT_NAME = "+rs.getString("ACCOUNT_NAME"));

			resBI.setInvoiceNum(rs.getString("INVOICE_NUMBER"));
			_LOGGER.info("INVOICE_NUMBER = "+rs.getString("INVOICE_NUMBER"));

			resBI.setBillDate((Date)rs.getObject("BILL_DATE"));
			_LOGGER.info("BILL_DATE = "+(Date)rs.getObject("BILL_DATE"));

			resBI.setSenderLastName(rs.getString("CONTACT_LAST_NAME"));
			_LOGGER.info("CONTACT_LAST_NAME = "+rs.getString("CONTACT_LAST_NAME"));

			resBI.setSenderFirstName(rs.getString("CONTACT_FIRST_NAME"));
			_LOGGER.info("CONTACT_LAST_NAME = "+rs.getString("CONTACT_FIRST_NAME"));

			resBI.setSenderPhone(rs.getString("CONTACT_PHONE"));
			_LOGGER.info("CONTACT_PHONE = "+rs.getString("CONTACT_PHONE"));

			resBI.setDisputeAmount(String.valueOf(rs.getBigDecimal("CREDIT_DISP_AMT")));
			_LOGGER.info("CREDIT_DISP_AMT = "+rs.getDouble("CREDIT_DISP_AMT"));

			resBI.setCreatedDate((Date)rs.getObject("CREATE_DATE"));
			_LOGGER.info("CREATE_DATE = "+rs.getObject("CREATE_DATE"));

			resBI.setCreatedSDate(rs.getString("CREATE_DATE"));
			_LOGGER.info("CREATE_SDATE = "+rs.getString("CREATE_DATE"));

			resBI.setCloseDate((Date)rs.getObject("CLOSED_DATE"));
			_LOGGER.info("CLOSED_DATE ="+rs.getObject("CLOSED_DATE"));

			resBI.setClaimTrackingNumber(rs.getString("SRC_SYS_CLM_ID"));
			_LOGGER.info("SRC_SYS_CLM_ID= "+rs.getString("SRC_SYS_CLM_ID"));

			resBI.setSourcePortal(rs.getString("VBC_OR_VBCC"));
			_LOGGER.info("VBC_OR_VBCC= "+rs.getString("VBC_OR_VBCC"));

			resBI.setStatusCode(rs.getInt("BI_STATUS"));
			_LOGGER.info("BI_STATUS= "+rs.getInt("BI_STATUS"));

			// Added for Displaying link for Trackingid in Backend IBI BI Central
    		//06/2008 Anand Lourdes Ignatius
            String category = (String) rs.getString("BI_CATEGORY");
            if (category != null && (category.equalsIgnoreCase("POV") || category.equalsIgnoreCase("ECP") || category.equalsIgnoreCase("OV")))
    		{
            	resBI.setLinkable(true);
    		}
    		else
    		{
    			resBI.setLinkable(false);
    		}
            //Added IBI Aug/2008 PVB
            resBI.setRegion(rs.getString("REGION_CD"));
			_LOGGER.info("REGION_CD = "+rs.getString("REGION_CD"));
		}

	  return resBI;
	}
}