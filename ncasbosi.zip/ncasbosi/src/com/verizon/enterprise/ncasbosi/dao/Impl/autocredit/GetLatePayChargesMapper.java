package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.BillingElement;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetLatePayChargesMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetLatePayChargesMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetLatePayChargesMapper - Mapping Row# "+rowNum);
		BillingElement lpc = null;
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";

		if(rs!=null){
			lpc = new BillingElement();
			
			lpc.setLatePayCharge("L");  // L for late payment charge
			lpc.setDescription("LATE PAYMENT CHARGE");
			lpc.setFromDate(CommonUtil.formatDate(rs.getString("MAN_BILL_DATE"), formatDb2, formatDisplayed));
			lpc.setThruDate(CommonUtil.formatDate(rs.getString("MAN_BILL_DATE"), formatDb2, formatDisplayed));
			
			
			lpc.setInvDate(CommonUtil.formatDate(rs.getString("MAN_BILL_DATE"), formatDb2, formatDisplayed));
			lpc.setInvNbr(rs.getString("INVOICE_NBR"));
			lpc.setCharge(CommonUtil.formatDouble(rs.getDouble("LATE_PAY_CHGS")));
		}
		return lpc;
	}
}
