package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.reports.CustomRptField;


public class GetCustRptChoicesResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetCustRptChoicesResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetCustRptChoicesResultSetRowMapper::mapRow rowNum - " + rowNum);

		CustomRptField rptField = new CustomRptField(rs.getString("FIELD_NAME"),rs.getString("SOURCE_ABBR"));
		rptField.setFieldGrp(rs.getString("FIELD_GROUP"));
		return rptField;
	}
}


