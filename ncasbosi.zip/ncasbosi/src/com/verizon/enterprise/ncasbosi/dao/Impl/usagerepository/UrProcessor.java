package com.verizon.enterprise.ncasbosi.dao.Impl.usagerepository;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.usagerepository.UrInterface;

/*
 * This class decides which operation to be performed
 */
public class UrProcessor {
	private static UrInterface interfaceObj;
	private static final Logger _LOGGER = Logger.getLogger(UrProcessor.class);
	
	private static synchronized UrInterface getURObject(){
		if(interfaceObj==null){
			_LOGGER.info("Getting the singleton Usage Repisitory Object");
			interfaceObj = DAOFactory.getInstance().getUrImplementationReference();
			_LOGGER.info("Successfully retrieved handle to the Usage Repisitory Object");
		}
		return interfaceObj;
	}
	
	public static Map processUr(Object input,String function)throws NCASException{
		_LOGGER.info("Entering processUr");
		Map responseMap = null;
		try{
			Method method = getURObject().getClass().getMethod(function, new Class[]{Object.class});
			responseMap = (Map)method.invoke(getURObject(),new Object[]{input});
		}catch(InvocationTargetException exception){
			throw new NCASException("UR1001",UrProcessor.class,exception.getTargetException());
		}catch(Exception exception){
			throw new NCASException("UR1001",UrProcessor.class,exception);
		}
		_LOGGER.info("responseMap=" + responseMap);
		_LOGGER.info("Exiting processUr");
		return responseMap;
	}
}
