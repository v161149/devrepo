package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Interface.adjustments.GetStructureInfoInterface;

public class GetStructureInfoDAOImpl extends NCASSpringJDBCBase implements GetStructureInfoInterface, NCASBOSIConstants{

	private static final Logger _LOGGER = Logger.getLogger(GetStructureInfoDAOImpl.class);
	private JdbcTemplate vamJdbcTemplate;//jdbctemplate created for VAM dataSource

	
	//public List getStructureInfo(String subscriberOid)throws NCASException{
	public Map getStructureInfo(Map inputMap)throws NCASException{
		_LOGGER.info("Entering getStructureInfo()");
		
		Map responseMap = new HashMap();
		List accountList = null;
		String subscriberOid = (String) inputMap.get("subscriberOid");
		String loginId = (String) inputMap.get("loginId");
		String userOid = (String) inputMap.get("userOid");
		
		List paramValues = new ArrayList();
		paramValues.add("vbbhipb");
		paramValues.add("Y");
		paramValues.add("");
		paramValues.add("SB");
		paramValues.add(subscriberOid);
		paramValues.add("");
		paramValues.add("0");				
		paramValues.add(loginId);
		paramValues.add(userOid);		
		
		try
		{
			SPGetStructureInfo getStructureInfo = new SPGetStructureInfo(getVAMDataSource(), getVAMSchemaName());
			responseMap = getStructureInfo.executeStoredProcedure(paramValues);
		}
		catch(Exception e)
		{
			 _LOGGER.error("Exception : ", e);
			 throw new NCASException("CL1001", SPGetStructureInfo.class, e);
			 //throw e;
		}
		
		//outputMap.put("accountList", accountList);
		
		_LOGGER.info("Exiting getStructureInfo");
		return responseMap;
	}

	private String getVAMSchemaName() {
		String schemaName = BOSIConfig.getProperty(VAM_SCHEMA_NAME, " ");
		_LOGGER.info("SCHEMA NAME ##  -> " + schemaName);
		return schemaName;
	}

}
