package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.util.Date;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.DuplicateClaim;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.util.commonUtil;

/*
 * Author:Ram/v992473
 */

public class GetDupeClaimMapper implements RowMapper{
	
	private static final Logger _LOGGER = Logger.getLogger(GetDupeClaimMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetDupeClaimMapper - Mapping Row# "+rowNum);
		DuplicateClaim dupeClaim = null;
		if(rs!=null){
			BigDecimal claimNumber = rs.getBigDecimal("ESG_CLAIM_NUMBER");
			Date entryDate = (Date)rs.getObject("CLM_ENTRY_DATE");
			String claimAmount = commonUtil.formatNumber(CommonUtil.formatDouble(rs.getDouble("CLM_TOT_ADJ_AMOUNT")),"#,##0.00 ; -#,##0.00");
			_LOGGER.info("claimNumber::"+claimNumber);
			_LOGGER.info("entryDate::"+entryDate);
			_LOGGER.info("claimAmount::"+claimAmount);
			dupeClaim = new DuplicateClaim(claimNumber,entryDate,claimAmount);
		}
		return dupeClaim;
	}
}
