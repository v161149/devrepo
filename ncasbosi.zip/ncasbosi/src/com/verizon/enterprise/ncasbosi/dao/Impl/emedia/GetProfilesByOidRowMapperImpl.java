package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;


import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.eMedia.manage.Profile;

public class GetProfilesByOidRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(GetProfilesByOidRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.debug("Inside GetProfilesByOidRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		Map profilesMap = new HashMap();
		while(rs.next()) {
			//rs.getInt("LINE_NUM");
			//rs.getString("PROFILE");
			//rs.getString("BM_MEDIA_TYPE");
			//rs.getString("CONFIG_NAME");


			String number = rs.getString("PROFILE");
			String name = rs.getString("CONFIG_NAME");
			String mediaType = rs.getString("MEDIA_TYPE");
			String bmmediaType = rs.getString("BM_MEDIA_TYPE");
			String billPeriod = rs.getString("BILL_PERIOD");
			String osid = rs.getString("ORIG_SYSTEM_ID");
			String nationalInd = rs.getString("NATL_IND");
			int cdCopies = rs.getInt("CD_COPIES");
			String softwareVersion = rs.getString("SOFTWARE_VER");
			String gcsConvFlag = rs.getString("GCS_CONV_FLAG");
			String lbsConvFlag = rs.getString("LBS_CONV_FLAG");
			String ixplusConvFlag = rs.getString("IXPLUS_CONV_FLAG");
			String megaVoiceCnvFlag = rs.getString("MEGAVOICE_CNV_FLAG");
			String ibrsConvFlag = rs.getString("IBRS_CONV_FLAG");
			String visionConvFlag = rs.getString("VISION_CONV_FLAG");
//			 Donnelly  9/2007 - added logic for Digix, MWAN and Millenium
			String millenConvFlag = rs.getString("MILLEN_CONV_FLAG");
			String sViewConvFlag = rs.getString("SVIEW_CONV_FLAG");
			
			double configSubsOid = rs.getDouble("CONFIG_SUBS_OID");
			String custType = rs.getString("CUSTOMER_TYPE");

			Profile profile = new Profile();

			if(CommonUtil.isNotNull(number)) {
				profile.setNumber(number.trim());
			}
			if(CommonUtil.isNotNull(name)) {
				profile.setName(name.trim());
			}
			if(CommonUtil.isNotNull(bmmediaType)) {
				profile.setBmMediaType(bmmediaType.trim());
			}
			if(CommonUtil.isNotNull(mediaType)) {
				profile.setMediaType(mediaType.trim());
			}
			if(CommonUtil.isNotNull(billPeriod)) {
				profile.setBillPeriod(billPeriod.trim());
			}
			if(CommonUtil.isNotNull(osid)) {
				profile.setOsid(osid.trim());
			}
			if(CommonUtil.isNotNull(gcsConvFlag)) {
				profile.setGcsConversionFlag(gcsConvFlag.trim());
			}
			if(CommonUtil.isNotNull(ibrsConvFlag)) {
				profile.setIbrsConversionFlag(ibrsConvFlag.trim());
			}
			if(CommonUtil.isNotNull(ixplusConvFlag)) {
				profile.setIxplusConversionFlag(ixplusConvFlag.trim());
			}
			if(CommonUtil.isNotNull(lbsConvFlag)) {
				profile.setLbsConversionFlag(lbsConvFlag.trim());
			}
			if(CommonUtil.isNotNull(mediaType)) {
				profile.setMediaType(mediaType.trim());
			}
			if(CommonUtil.isNotNull(megaVoiceCnvFlag)) {
				profile.setMegaVoiceConversionFlag(megaVoiceCnvFlag.trim());
			}
			if(CommonUtil.isNotNull(nationalInd)) {
				profile.setNationalIndicator(nationalInd.trim());
			}
			if(CommonUtil.isNotNull(softwareVersion)) {
				profile.setVersion(softwareVersion.trim());
			}
			if(CommonUtil.isNotNull(visionConvFlag)) {
				profile.setVisionConversionFlag(visionConvFlag.trim());
			}
			if(CommonUtil.isNotNull(millenConvFlag )) {
				profile.setMillenConversionFlag(millenConvFlag .trim());
			}
			if(CommonUtil.isNotNull(sViewConvFlag)) {
				profile.setSingleViewConversionFlag(sViewConvFlag.trim());
			}			
			
			if(CommonUtil.isNotNull(custType)) {
				profile.setCustomerType(custType.trim());
			}
			profile.setCdCopies(String.valueOf(cdCopies));
			String key = CommonUtil.convertStringFromDouble(configSubsOid);

			profile.setConfigSubsOid(key);
			String configSubsOidStr = rs.getString("CONFIG_SUBS_OID");
			_LOGGER.debug("inserting key - " + configSubsOidStr + " , value - " + profile);
			profilesMap.put(configSubsOidStr, profile);
		}
		return profilesMap;
	}
}
