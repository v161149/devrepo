package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPCleanupCalcDetail extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPCleanupCalcDetail.class);
	private static List spInOutList;
	
	static{
		_LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STATUS",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPCleanupCalcDetail(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_CLEANUP_CALC_DTL, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		
		/* get input values */
		Map inputMap = (Map)input;
		VamDO vamDO = (VamDO)inputMap.get("vamDO");
		if (vamDO == null){
			throw new Exception("SPCleanupCalcDetail: input data object is null");
		}
		String claimNumber = vamDO.getClaimNumber();
		String status = vamDO.getStatus();
		_LOGGER.info("claimNumber::"+claimNumber);
		_LOGGER.info("status::"+status); 
		
		/* map input vars to sp parameters */
		List inputList = new ArrayList();
		inputList.add(new BigDecimal(claimNumber));//ESG_CLAIM_NUMBER      DECIMAL(13,0)
		inputList.add(status);//Status - null vac clean all, '2' only cleans those.
		
		/* execute sp */
		Map resMap = executeSP(inputList, false);
		
		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
