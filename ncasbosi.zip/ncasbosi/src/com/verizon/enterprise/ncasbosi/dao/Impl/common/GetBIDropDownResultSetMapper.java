package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.common.GetBIDropdownsHelper;

public class GetBIDropDownResultSetMapper implements ResultSetExtractor{
	
	private String biCategory = null;

	public String getBiCategory() {
		return biCategory;
	}

	public void setBiCategory(String biCategory) {
		this.biCategory = biCategory;
	}

	@Override
	public Object extractData(ResultSet rs) throws SQLException,DataAccessException {
		return new GetBIDropdownsHelper(biCategory).construcBICategoryMap(rs);
	}

}
