package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaAFTConstants;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetAFTDetailInfo extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPUploadAFTInfo.class);

	private static List spInOutList;
	
	private static GetAFTDetailInfoRowMapperImpl updateResultSetRowMapper;
	private static GetAFTEDIDetailInfoRowMapperImpl ediResultSetRowMapper;
	private static GetAFTVECDetailInfoRowMapperImpl vecResultSetRowMapper;

	static
	{
		 spInOutList = new ArrayList();
		 
		 updateResultSetRowMapper = new GetAFTDetailInfoRowMapperImpl();
		 ediResultSetRowMapper = new GetAFTEDIDetailInfoRowMapperImpl();
		 vecResultSetRowMapper = new GetAFTVECDetailInfoRowMapperImpl();
		 
		 spInOutList.add(new Object[]{"updateReportAccounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,updateResultSetRowMapper});
		 spInOutList.add(new Object[]{"ediReportAccounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,ediResultSetRowMapper});
		 spInOutList.add(new Object[]{"vecAccounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,vecResultSetRowMapper});

		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQUEST_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQUEST_MODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"FILTER_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetAFTDetailInfo(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_AFT_DETAIL, spInOutList);
	}

	protected Map executeStoredProcedure(String appUserId, String debugLevel, String aftRequestId, String aftMode,
			String whereFilter, String sortFilter, Pagination pagination) throws Exception {
		
		Map responseMap = new HashMap();
		List paramValueList = new ArrayList();
		paramValueList.add(appUserId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(aftRequestId);//REQUEST_ID
		paramValueList.add(aftMode);//REQUEST_MODE
		paramValueList.add(whereFilter);//FILTER_STRING
		paramValueList.add(sortFilter);//SORT_STRING

		String pageOffset = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(pageOffset==null) {
			pageOffset = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}
		paramValueList.add(String.valueOf(pageOffset));//PAGE_OFFSET
		paramValueList.add(String.valueOf(pageSize));//PAGE_SIZE

		Map procMap = executeStoredProcedure(paramValueList);
		
		List accountsList = null;

		if (aftMode.equalsIgnoreCase(EMediaAFTConstants.AFT_EDI_REPORT_TYPE)) {
			accountsList = (List) procMap.get("ediReportAccounts");
		} else if (aftMode.equalsIgnoreCase(EMediaAFTConstants.AFT_VEC_REPORT_TYPE)) {
			accountsList = (List) procMap.get("vecAccounts");
		} else {
			//If not EDI or VEC, then it is UPDATE / REPORT - 1st resultset.
			accountsList = (List) procMap.get("updateReportAccounts");
		}
		procMap.put("accounts", accountsList);
		//List accountsList = (List)procMap.get("accounts");
		pagination.setDefaultSize(pagination.getItemsPerPage());
		if(accountsList!=null) {
			pagination.setResultSize(Integer.toString(accountsList.size()));
		} else {
			pagination.setResultSize("0");		
		}
		
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		pagination.updateTotalPages(rowcountrStr.intValue());
		
		responseMap.put("recordsMap", procMap);
		responseMap.put("pagination", pagination);

		return responseMap;
	}

	protected Map executeStoredProcedure(Object paramValues) throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}

}
