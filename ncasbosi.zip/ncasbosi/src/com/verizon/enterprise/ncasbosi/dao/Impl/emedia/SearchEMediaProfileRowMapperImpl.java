package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import java.util.ArrayList;
import java.util.List;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDlvryOptCommMeth;
import com.verizon.enterprise.common.eMedia.EMediaKeyProfile;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class SearchEMediaProfileRowMapperImpl implements RowMapper {

	static private final Logger logger = Logger.getLogger(SearchEMediaProfileRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "SearchEMediaProfileRowMapperImpl::mapRow()";

		logger.debug(METHOD_NAME + " ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		logger.info(METHOD_NAME + " rowNumber="	+ rowNum);

		EMediaProfile profile = null;

		try
		{
			EMediaKeyProfile profileKey = new EMediaKeyProfile();
			EMediaCustInfo custInfo = new EMediaCustInfo();
			EMediaAcctTeamInfo acctTeamInfo = new EMediaAcctTeamInfo();
			EMediaDlvryOptCommMeth dlvryInfo = new EMediaDlvryOptCommMeth();
			profile = new EMediaProfile();

			String configSubscriptionOid = (String) rs.getBigDecimal("CONFIG_SUBS_OID").toString();
			String configId = rs.getString("CONFIG_ID");
			String serviceType = rs.getString("SERVICE_TYPE");
			String profStatus = rs.getString("PROF_STATUS");
			String companyName = rs.getString("COMPANY_NAME");
			String distributionName = rs.getString("DISTRBUTION_NAME");
     		String customerType = rs.getString("CUSTOMER_TYPE");
			String lobIndicator = rs.getString("LOB_IND");
			String startDate = rs.getString("START_DATE");
			String endDate = rs.getString("END_DATE");
			String createdDate = rs.getString("DATE_CREATED");
			String ediDelivOpt = rs.getString("EDI_DELIV_OPT");
			String commMethod = rs.getString("COMM_METHOD");
			String profileComplete = rs.getString("PROFILE_COMPLETE");
			String billPeriod = rs.getString("BP_DAY");
			String nationalInd = rs.getString("CONFIG_NATL_IND");
			String mediaOpt = rs.getString("MEDIA_OPT");
			String secabsDeliOpt = rs.getString("SECABS_DELIV_OPT");
			String ddDelivOpt = rs.getString("DD_DELIV_OPT");
			int holdDays = rs.getInt("HOLD_DAYS");
			String softwareVersion = rs.getString("SOFTWARE_VER");
			String smpContractId = rs.getString("SMP_CONTRACT_ID");
			String smpContractOid = (String) rs.getBigDecimal("SB_CONTRACT_OID").toString();

			//print out values returned
			List valuesList = new ArrayList();
			valuesList.add("CONFIG_SUBS_OID=" + configSubscriptionOid);
			valuesList.add("CONFIG_ID=" + configId);
			valuesList.add("SERVICE_TYPE=" + serviceType);
			valuesList.add("PROF_STATUS=" + profStatus);
			valuesList.add("COMPANY_NAME=" + companyName);
			valuesList.add("DISTRBUTION_NAME=" + distributionName);
			valuesList.add("CUSTOMER_TYPE=" + customerType);
			valuesList.add("LOB_IND=" + lobIndicator);
			valuesList.add("START_DATE=" + startDate);
			valuesList.add("END_DATE=" + endDate);
			valuesList.add("DATE_CREATED=" + createdDate);
			valuesList.add("EDI_DELIV_OPT=" + ediDelivOpt);
			valuesList.add("COMM_METHOD=" + commMethod);
			valuesList.add("PROFILE_COMPLETE=" + profileComplete);
			valuesList.add("BP_DAY=" + billPeriod);
			valuesList.add("CONFIG_NATL_IND=" + nationalInd);
			valuesList.add("MEDIA_OPT=" + mediaOpt);
			valuesList.add("SECABS_DELIV_OPT=" + secabsDeliOpt);
			valuesList.add("DD_DELIV_OPT=" + ddDelivOpt);
			valuesList.add("HOLD_DAYS=" + holdDays);
			valuesList.add("SOFTWARE_VER=" + softwareVersion);
			valuesList.add("SMP_CONTRACT_ID=" + smpContractId);
			valuesList.add("SB_CONTRACT_OID=" + smpContractOid);

			CommonUtil.prettyPrintValues(valuesList);

			profileKey.setConfigSubscriptionOid(Double.parseDouble(configSubscriptionOid));

			if (CommonUtil.isNotNull(configId)) {
				profileKey.setConfigID(configId.trim());
			}
			if (CommonUtil.isNotNull(serviceType)) {
				profile.setServiceType(serviceType.trim());
			}
			if (CommonUtil.isNotNull(profStatus)) {
				profile.setProfileStatus(profStatus.trim());
			}
			if (CommonUtil.isNotNull(companyName)) {
				custInfo.setCustCpnyName(companyName.trim());
			}
			if (CommonUtil.isNotNull(distributionName)) {
				profile.setDistName(distributionName);
			}
			if (CommonUtil.isNotNull(customerType)) {
				custInfo.setCustType(customerType.trim());
			}
			if (CommonUtil.isNotNull(lobIndicator)) {
				acctTeamInfo.setLob(lobIndicator.trim());
			}

			profile.setStartDate(CommonUtil.getDateFromString(startDate));
			profile.setEndDate(CommonUtil.getDateFromString(endDate));
			profile.setDtCreated(CommonUtil.getDateFromString(createdDate));

			if (CommonUtil.isNotNull(ediDelivOpt)) {
				dlvryInfo.setDelOptCommMeth(ediDelivOpt.trim());
			}
			if (CommonUtil.isNotNull(commMethod)) {
				dlvryInfo.setCommMethod2(commMethod.trim());
			}
			if (CommonUtil.isNotNull(profileComplete)) {
				profile.setProfComplete(profileComplete.trim());// PROFILE_COMPLETE
			}
			if (CommonUtil.isNotNull(billPeriod)) {
				profile.setBillPeriod(billPeriod.trim());// BP_DAY
			}
			if (CommonUtil.isNotNull(nationalInd)) {
				profile.setNationalInd(nationalInd.trim());// CONFIG_NATL_IND
			}
			if (CommonUtil.isNotNull(mediaOpt)) {
				profile.setMediaOpt(mediaOpt.trim());
			}
			if (CommonUtil.isNotNull(secabsDeliOpt)) {
				profile.setSecabsDeliveryOption(secabsDeliOpt.trim());
			}
			if (CommonUtil.isNotNull(ddDelivOpt)) {
				profile.setDdDeliveryOpt(ddDelivOpt.trim());
			}

			profile.setHoldDays(rs.getInt("HOLD_DAYS"));

			if (CommonUtil.isNotNull(softwareVersion)) {
				profile.setSoftwareVersion(softwareVersion.trim());
			}

			if (CommonUtil.isNotNull(smpContractId))
			{
				profile.setSmpContractId(smpContractId.trim());
			}

			if (CommonUtil.isNotNull(smpContractOid))
			{
				profile.setSmpContractOid(smpContractOid.trim());
			}

			profile.setProfileKey(profileKey);
			profile.setCustInfo(custInfo);
			profile.setAcctTeamInfo(acctTeamInfo);
			profile.setDlvryOptCommMeth(dlvryInfo);
		}
		catch (NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.info("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			logger.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.info("Exception occured while parsing the resultset \n"
					+ e.getMessage());
			logger.error("Exception occured while parsing the resultset \n"
					+ e.getMessage());
		}

		logger.info(METHOD_NAME + " profile=" + profile);
		logger.debug(METHOD_NAME + " EXIT");

		return profile;
	}

}
