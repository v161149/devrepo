package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.ClaimDetail;


/*
 * Author:PVB
 */

public class GetSearchClaimMapper implements RowMapper{
	
	private static final Logger _LOGGER = Logger.getLogger(GetSearchClaimMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetSearchClaimMapper - Mapping Row# "+rowNum);
		//declare search results objects;		
		ClaimDetail claim = null;
		if(rs!=null){
			claim = new ClaimDetail();
			_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.autocredit.GetSearchClaimMapper");
			
			claim.setClaimNumber(rs.getString("ESG_CLAIM_NUMBER"));
			_LOGGER.info("ESG_CLAIM_NUMBER= "+rs.getString("ESG_CLAIM_NUMBER"));

			claim.setClaimID(rs.getString("SRC_SYS_CLM_ID"));
			_LOGGER.info("SRC_SYS_CLM_ID= "+rs.getString("SRC_SYS_CLM_ID"));
			
			claim.setBillinquiryID(rs.getString("SRC_SYS_BI_ID"));
			_LOGGER.info("SRC_SYS_BI_ID= "+rs.getString("SRC_SYS_BI_ID"));
			
			claim.setBillingAccount(rs.getString("ACCOUNT_NUMBER"));
			_LOGGER.info("ACCOUNT_NUMBER= "+rs.getString("ACCOUNT_NUMBER"));
			
			claim.setEntryDate(rs.getString("ENTRY_DATE"));
			_LOGGER.info("ENTRY_DATE= "+rs.getString("ENTRY_DATE"));
			
			claim.setApprovedAmount(rs.getDouble("CLM_APPROV_AMOUNT"));
			_LOGGER.info("CLM_APPROV_AMOUNT= "+rs.getString("CLM_APPROV_AMOUNT"));

			claim.setClaimStatus(String.valueOf(rs.getInt("CLM_STATUS")));
			_LOGGER.info("CLM_STATUS= "+String.valueOf(rs.getInt("CLM_STATUS")));	
			
			claim.setClaimStatusDesc(rs.getString("CLM_STATUS_DESC"));
			_LOGGER.info("CLM_STATUS_DESC= "+rs.getString("CLM_STATUS_DESC"));
			
			claim.setClaimSubStatus(String.valueOf(rs.getInt("CLM_SUB_STATUS")));
			_LOGGER.info("CLM_SUB_STATUS= "+String.valueOf(rs.getInt("CLM_SUB_STATUS")));
			
			claim.setClaimSubStatusDesc(rs.getString("CLM_SUBSTATUS_DESC"));
			_LOGGER.info("CLM_SUBSTATUS_DESC= "+rs.getString("CLM_SUBSTATUS_DESC"));

			claim.setAuditorVZId(rs.getString("CLM_CURR_OWN_VZID"));
			_LOGGER.info("CLM_CURR_OWN_VZID= "+rs.getString("CLM_CURR_OWN_VZID"));
			
			claim.setSegment(rs.getString("SEGMENT"));
			_LOGGER.info("SEGMENT= "+rs.getString("SEGMENT"));
			
			claim.setServiceCenter(rs.getString("SERVICE_CENTER"));
			_LOGGER.info("SERVICE_CENTER= "+rs.getString("SERVICE_CENTER"));
			
			//PVB 04-28-2009 new fields so we can show in AC Central
			claim.setCreditType(rs.getString("CALC_TYPE"));
			_LOGGER.info("CALC_TYPE= "+claim.getCreditType());
			
			claim.setCreditType_Desc(rs.getString("CALC_TYPE_DESC"));
			_LOGGER.info("CALC_TYPE_DESC= "+claim.getCreditType_Desc());

			claim.setSubType(rs.getString("CALC_SUB_TYPE"));
			_LOGGER.info("CALC_SUB_TYPE= "+claim.getSubType());
			
			claim.setSubType_Desc(rs.getString("CALC_SUB_TYPE_DESC"));
			_LOGGER.info("CALC_SUB_TYPE_DESC= "+claim.getSubType_Desc());

		}	
		return claim;
			}
}
