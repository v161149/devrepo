package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadAFTVECAccountsRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadAFTVECAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		_LOGGER.info("Inside DownloadAFTVECAccountsRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List accountsList = new ArrayList();
		List account = new ArrayList();
		try {
			while(rs.next()) {
				account = new ArrayList();
				//Set the values
				String requestNumber = rs.getString("REQUEST_NO");
				String man = rs.getString("MAN");
				String ban = rs.getString("BAN");
				String aban = rs.getString("ABAN");
				String osid = rs.getString("OSID");
				String accountNumber = rs.getString("ACCOUNT");
				String accountStatus = rs.getString("ACCOUNT_STATUS");
				String lob = rs.getString("LOB");
				String channelCode = rs.getString("CHANNEL_CD");
				String subscriptionOid = rs.getString("SUBSCRIPTION_OID");
				String entitlementStatus = rs.getString("VEC_ENTITLE_STATUS");
				String userId = rs.getString("VEC_USER_ID");
				String emailId = rs.getString("VEC_USER_EMAIL");
				String userIdStatus = rs.getString("VEC_USER_STATUS");
				String userName = rs.getString("VEC_USER_NAME");
				String companyName = rs.getString("VEC_COMPANY_NAME");
				String entitlementType = rs.getString("ENTITLEMENT_TYPE");
				String permissionGroupOid = rs.getString("PERM_GROUP_OID");
				String permissionGroupSubscriberName = rs.getString("PERM_GRP_SUB_NAME");
				String errorCode = rs.getString("ERROR_CODE");
				String errorDescription = rs.getString("ERROR_TEXT");
				
				/*
				StringBuffer sb = new StringBuffer();
				sb.append("REQUEST_NO - " + requestNumber);
				sb.append(", MAN - " + man);
				sb.append(", BAN - " + ban);
				sb.append(", ABAN - " + aban);
				sb.append(", OSID - " + osid);
				sb.append(", ACCOUNT - " + account);
				sb.append(", ACCOUNT_STATUS - " + accountStatus);
				sb.append(", LOB - " + lob);
				sb.append(", CHANNEL_CD - " + channelCode);
				sb.append(", SUBSCRIPTION_OID - " + subscriptionOid);
				sb.append(", VEC_ENTITLE_STATUS - " + entitlementStatus);
				sb.append(", VEC_USER_ID - " + userId);
				sb.append(", VEC_USER_EMAIL - " + emailId);
				sb.append(", VEC_USER_STATUS - " + userIdStatus);
				sb.append(", VEC_USER_NAME - " + userName);
				sb.append(", VEC_COMPANY_NAME - " + companyName);
				sb.append(", ENTITLEMENT_TYPE - " + entitlementType);
				sb.append(", PERM_GROUP_OID - " + permissionGroupOid);
				sb.append(", PERM_GRP_SUB_NAME - " + permissionGroupSubscriberName);
				sb.append(", ERROR_CODE - " + errorCode);
				sb.append(", ERROR_TEXT - " + errorDescription);
				
				_LOGGER.info("### " + sb.toString() + " ###");
				*/

				if(CommonUtil.isNotNull(requestNumber)) {
					account.add(new Cell(requestNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(man)) {
					account.add(new Cell(man.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ban)) {
					account.add(new Cell(ban.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(aban)) {
					account.add(new Cell(aban.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(osid)) {
					account.add(new Cell(osid.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(accountNumber)) {
					account.add(new Cell(accountNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(accountStatus)) {
					account.add(new Cell(accountStatus.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(lob)) {
					account.add(new Cell(lob.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(channelCode)) {
					account.add(new Cell(channelCode.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(subscriptionOid)) {
					account.add(new Cell(subscriptionOid.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(entitlementStatus)) {
					account.add(new Cell(entitlementStatus.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(userId)) {
					account.add(new Cell(userId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(emailId)) {
					account.add(new Cell(emailId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(userIdStatus)) {
					account.add(new Cell(userIdStatus.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(userName)) {
					account.add(new Cell(userName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(companyName)) {
					account.add(new Cell(companyName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(entitlementType)) {
					account.add(new Cell(entitlementType.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(permissionGroupOid)) {
					account.add(new Cell(permissionGroupOid.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(permissionGroupSubscriberName)) {
					account.add(new Cell(permissionGroupSubscriberName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(errorCode)) {
					account.add(new Cell(errorCode.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(errorDescription)) {
					account.add(new Cell(errorDescription.trim()));
				} else {
					account.add(new Cell(""));
				}
				
				accountsList.add(account);
			}
		} catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadAFTVECAccountsRowMapperImpl's account -  " + account);
		}
		return accountsList;
	}
}