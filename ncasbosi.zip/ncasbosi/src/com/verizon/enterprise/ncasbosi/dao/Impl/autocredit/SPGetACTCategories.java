package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/**
 * @author v992473
 * This class represents the vac api GET_ACT_CATEGORIES
 */

public class SPGetACTCategories extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPGetACTCategories.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"CATEGORY_MAP", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new GetACTCategoriesMapper()});
		 spInOutList.add(new Object[]{"A_R_SYSTEM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPGetACTCategories(DataSource dataSource){
		super(dataSource,NCASBOSIConstants.SP_GET_ACT_CATEGORIES,spInOutList);
	}
	
	public Map executeStoredProcedure(Object pARSystem)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		String ARSystem = (String)pARSystem;
		_LOGGER.info("ARSystem::"+ARSystem);
		List inputList = new ArrayList();
		inputList.add(ARSystem);//A_R_SYSTEM
		Map resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
	
}
