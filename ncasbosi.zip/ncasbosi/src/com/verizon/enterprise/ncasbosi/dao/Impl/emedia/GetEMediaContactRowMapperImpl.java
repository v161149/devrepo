package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaContactInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetEMediaContactRowMapperImpl implements RowMapper {
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaContactRowMapperImpl.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.info("Inside GetEMediaContactRowMapperImpl::mapRow rowNumber -> " + rowNum);
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		EMediaContactInfo contactInfo = new EMediaContactInfo();
		
		int contactSeq = rs.getInt("CONTACT_SEQ");
		double configSubscriptionOid = rs.getDouble("CONFIG_SUBS_OID");
		String contactType = rs.getString("CONTACT_TYPE");
		String configId = rs.getString("CONFIG_ID");
		String serviceType = rs.getString("SERVICE_TYPE");
		Date startDate = rs.getDate("START_DATE");
		Date endDate = rs.getDate("END_DATE");
		String contactName = rs.getString("CONTACT_NAME");
		String contactTitle = rs.getString("CONTACT_TITLE");
		String contactArea = rs.getString("CONTACT_AREA");
		String contactPhone = rs.getString("CONTACT_PHONE");
		String phoneExtn = rs.getString("CONTACT_PHONE_EXT");
		String email = rs.getString("CONTACT_EMAIL_ID");
		String timeZone = rs.getString("CONTACT_EMAIL_ZONE");
		int timeZoneNumber = rs.getInt("EMAIL_ZONE_NBR");
		String contactVnetNumber = rs.getString("CONTACT_VNET_NO");
		String vecUserId = rs.getString("VEC_LOGIN_ID");
		
		//Pretty print the DB Values - GBR - as per Paul request.
		List valuesList = new ArrayList();
		valuesList.add(contactSeq);
		valuesList.add(rs.getString("CONFIG_SUBS_OID"));
		valuesList.add(contactType);
		valuesList.add(configId);
		valuesList.add(serviceType);
		valuesList.add(rs.getString("START_DATE"));
		valuesList.add(rs.getString("END_DATE"));
		valuesList.add(contactName);
		valuesList.add(contactTitle);
		valuesList.add(contactArea);
		valuesList.add(contactPhone);
		valuesList.add(phoneExtn);
		valuesList.add(email);
		valuesList.add(vecUserId);
		valuesList.add(timeZone);
		valuesList.add(rs.getString("EMAIL_ZONE_NBR"));
		valuesList.add(contactVnetNumber);
		CommonUtil.prettyPrintValues(valuesList);
		 
		if(contactType != null) {
			contactInfo.setContactType(contactType.trim());
		}
		if(configId != null) {
			contactInfo.setConfigId(configId.trim());
		}
		if(serviceType != null) {
			contactInfo.setServiceType(serviceType.trim());
		}
		if(contactName != null) {
			contactInfo.setContactName(contactName.trim());
		}
		if(contactTitle != null) {
			contactInfo.setContactTitle(contactTitle.trim());
		}
		if(contactArea != null) {
			contactInfo.setFunctionalArea(contactArea.trim());
		}
		if(contactPhone != null) {
			contactInfo.setContactPhone(contactPhone.trim());
		}
		if(phoneExtn != null) {
			contactInfo.setContactPhoneExt(phoneExtn.trim());
		}
		if(contactVnetNumber != null) {
			contactInfo.setContactVnetNumber(contactVnetNumber.trim());
		}
		if(email != null) {
			contactInfo.setEMail(email.trim());
		}

		if(vecUserId != null) {
			contactInfo.setVecUserId(vecUserId.trim());
		}

		if(timeZone != null) {
			contactInfo.setTimeZone(timeZone.trim());
		}
		
		if(startDate != null) {
			contactInfo.setStartDate(startDate);
		}
		if(endDate != null) {
			contactInfo.setEndDate(endDate);
		}
		
		contactInfo.setContactSeq(contactSeq);
		contactInfo.setTimeZoneNumber(timeZoneNumber);
		contactInfo.setConfigSubscriptionOid(configSubscriptionOid);
			
		return contactInfo;
	}
}
