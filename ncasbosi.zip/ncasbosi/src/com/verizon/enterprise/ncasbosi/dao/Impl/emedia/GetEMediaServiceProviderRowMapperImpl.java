package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.verizon.enterprise.common.eMedia.EMediaAddress;
import com.verizon.enterprise.common.eMedia.EMediaSrvcProviderInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;

public class GetEMediaServiceProviderRowMapperImpl implements RowMapper{
	
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaServiceProviderRowMapperImpl.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		//_LOGGER.debug("Inside GetEMediaServiceProviderRowMapperImpl::mapRow rowNumber -> " + rowNum);
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		EMediaSrvcProviderInfo serviceProviderInfo = new EMediaSrvcProviderInfo();
		
		String providerName = rs.getString("SERV_PVDR_NAME");
		
		serviceProviderInfo.setProviderNumber(rs.getInt("SERV_PVDR_NBR"));
		if(CommonUtil.isNotNull(providerName)) {
			serviceProviderInfo.setProviderName(providerName.trim());
		}
		
		String addressTypeIndicator = rs.getString("SERV_ADDR_TYPE");
		String address1 = rs.getString("SERV_ADDR_1");
		String address2 = rs.getString("SERV_ADDR_2");
		String city = rs.getString("SERV_CITY");
		String state = rs.getString("SERV_STATE");
		String zipCode = rs.getString("SERV_ZIP");
		String country = rs.getString("SERV_COUNTRY");

		EMediaAddress address = new EMediaAddress();
		if(CommonUtil.isNotNull(addressTypeIndicator)) {
			address.setAddTypeInd(addressTypeIndicator.trim());
		}
		if(CommonUtil.isNotNull(address1)) {
			address.setAddress1(address1.trim());
		}
		if(CommonUtil.isNotNull(address2)) {
			address.setAddress2(address2.trim());
		}
		if(CommonUtil.isNotNull(city)) {
			address.setCity(city.trim());
		}
		if(CommonUtil.isNotNull(state)) {
			address.setState(state.trim());
		}
		if(CommonUtil.isNotNull(zipCode)) {
			address.setZip(zipCode.trim());
		}
		if(CommonUtil.isNotNull(country)) {
			address.setCountry(country.trim());
		}
		
		serviceProviderInfo.setAddress(address);
			
		_LOGGER.debug("GetEMediaServiceProviderRowMapperImpl's serviceProviderInfo ==> " + serviceProviderInfo);
		return serviceProviderInfo;
	}
}
