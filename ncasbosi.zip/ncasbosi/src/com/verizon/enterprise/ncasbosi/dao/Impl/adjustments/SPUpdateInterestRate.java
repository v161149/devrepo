package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import com.verizon.enterprise.common.ncas.adjustments.InterestRateDetails;

public class SPUpdateInterestRate extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPUpdateInterestRate.class);
	
	private static List spInOutList;
	
	private static GetInterestRateRowMapperImpl rowMapper = null;

	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new GetInterestRateRowMapperImpl();
		 
		 spInOutList.add(new Object[]{"LIST_INTEREST_RATE_DETAILS",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 
		 spInOutList.add(new Object[]{"USER_ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"STATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"YEAR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"YEARLY_INT_RATE", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LAST_UPD_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});		  
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPUpdateInterestRate(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_UPDATE_INT_RATE, spInOutList);	
	}

	public Map executeStoredProcedure(Map inputMap) throws Exception	{
		InterestRateDetails inIntRateDetails = 
			(InterestRateDetails) inputMap.get("INTEREST_RATE_DETAILS");		
		List paramValueList = new ArrayList();
		paramValueList.add(inIntRateDetails.getUserAction());
		paramValueList.add(inIntRateDetails.getState());
		paramValueList.add(inIntRateDetails.getYear());
		paramValueList.add(new BigDecimal(inIntRateDetails.getIntRate()));
		paramValueList.add(inIntRateDetails.getLastUpdVzid());

		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(responseMap);		
		return responseMap;
	}
}