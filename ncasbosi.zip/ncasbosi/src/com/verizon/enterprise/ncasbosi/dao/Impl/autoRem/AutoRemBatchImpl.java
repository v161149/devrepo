package com.verizon.enterprise.ncasbosi.dao.Impl.autoRem;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.util.Iterator;
import com.verizon.enterprise.common.ncas.payments.EmailTemplateInfo;
import com.verizon.enterprise.common.ncas.payments.PaymentDetails;
import com.verizon.enterprise.common.ncas.payments.RecurPayment;
import com.verizon.enterprise.common.ncas.EmailUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.PaymentsTemplateConfig;
import com.verizon.enterprise.ncasbosi.dao.Interface.autoRem.AutoRemBatchInterface;
import com.verizon.kernel.xml.XmlParse;

public class AutoRemBatchImpl extends AutoRemDAOImpl implements AutoRemBatchInterface, NCASBOSIConstants
{
	private final Logger _LOGGER = Logger.getLogger(AutoRemBatchImpl.class);
	private VisionHelper visionHelpObj = null;

	private VisionHelper getVisionHelperInstance()
	{
		if (visionHelpObj == null)
		{
			visionHelpObj = new VisionHelper();
			return visionHelpObj;
		}
		else
		{
			return visionHelpObj;
		}
	}

	public void doAutoRemUpdateBatch() throws NCASException
	{
		final String METHOD_NAME = "doAutoRemUpdateBatch::";
		try
		{
			//The following block will be replaced with queries against PL_VIEW_AUDIT_T which will be the reference for all the transactions
			/*List<PaymentDetails> oneTimePayList = DAOFactory.getInstance().getPayments().getPayDetEligibleForAutoRem();
			List<RecurPayment> recPayList = DAOFactory.getInstance().getPayments().getRecPayEligibleForAutoRem();
			processRemUpdForPayDet(oneTimePayList);
			processRemUpdForRecPay(recPayList);*/
			List<Map<String, Object>> autoRemList = getListEligibleForAutoRem();
			_LOGGER.info(METHOD_NAME + " ListSize=" + autoRemList.size());
			processAutoRemList(autoRemList);
		}
		catch(NCASException e)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + e.getMessage());
			sendAutoRemIssuesByEmail(stack2string(e),METHOD_NAME);
			throw e;
		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + ex.getMessage());
			sendAutoRemIssuesByEmail(stack2string(ex),METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, AutoRemBatchImpl.class, ex);
		}
	}

	//TBD
	protected void processAutoRemList(List<Map<String, Object>> itemList) throws NCASException
	{
		final String METHOD_NAME = "processAutoRemList::";
		_LOGGER.info(METHOD_NAME + "  Entering");
		Map<String, String> inpMap = null;
		String currentPortalLogId = null;
		List<Map<String, Object>> successList = null;
		List acctList = new ArrayList();
		Map<String, List> emailEligList = new HashMap<String, List>();

		try
		{
			VisionHelper visionHelpObj = new VisionHelper();
			successList = new ArrayList<Map<String, Object>>();
			for (Map<String, Object> item : itemList)
			{
				String serviceId = (String)item.get("BAN");
				String impLoginId = (String)item.get("IMP_LOGIN_ID");
				String portalLogId = (String)item.get("PORTAL_LOGIN_ID");
				String accessType = (String)item.get("ACCESS_TYPE");
				String createdTS = CommonUtil.getDisplayDateTime((java.sql.Timestamp)item.get("CREATED_TS"));
				String transaction = VisionHelper.getTransactionForAccessType(accessType);

				inpMap = new HashMap<String, String>();
				if (accessType.equals("PAY_RECUR_UPD_VW"))
				{
					String man = (String)item.get("MAN");
					if (serviceId.length() == 0)
					{
						serviceId = getBanFromRecuPayId(man);
					}
					//Got to handle email Notification as well (TBD)
				}
				inpMap.put("SERVICE_ID", serviceId);
				inpMap.put("BILLING_SYS", "VISION_EAST");
				inpMap.put("CLIENT_ID", "VZB-VAM");
				inpMap.put("SERVICE_NAME", "autoRemarkUpdate");
				inpMap.put("REMARK_TYPE", DEFAULT_REMARK_TYPE);
				inpMap.put("REMARK_TEXT", transaction + " CHANGED VIA VEC, USER ID " + impLoginId+ ", "+createdTS);
				inpMap.put("CONTACT_METHOD", DEFAULT_CONTACT_METHOD);

				String inpXml = visionHelpObj.getServiceReqXmlForAutoRem(inpMap);
				//_LOGGER.info(METHOD_NAME + "InputXml for accountNo=" + serviceId + ", userid=" + portalLoginId + "=" + inpXml);
				String response = visionHelpObj.invokeURL(inpXml);
				//_LOGGER.info(METHOD_NAME + "Response for accountNo=" + serviceId + ", userid=" + portalLoginId + "=" + response);
				XmlParse respXml = new XmlParse(response);
				respXml.moveToRoot();
				respXml.moveTo("serviceHeader");

				if (respXml.getNodeValue("statusCode").equals("00"))
				{
					successList.add(item);
					//_LOGGER.info(METHOD_NAME + "CurrentLogId=" + currentPortalLogId + ", PortalLoginId=" + portalLogId);
					if (accessType.equals("PAY_RECUR_UPD_VW"))
					{
						if (acctList.size() == 0)
						{
							acctList.add(NCASDataUtil.getMaskedAcctNo(serviceId));
							currentPortalLogId = portalLogId;
							//_LOGGER.info(METHOD_NAME + "Condition1 Satisfied, Id=" + currentPortalLogId);
						}
						else if(currentPortalLogId.equals(portalLogId))
						{
							acctList.add(NCASDataUtil.getMaskedAcctNo(serviceId));
						}
						else if (!currentPortalLogId.equals(portalLogId))
						{
							emailEligList.put(currentPortalLogId, acctList);
							currentPortalLogId = portalLogId;
							acctList = null;
							acctList = new ArrayList();
							acctList.add(NCASDataUtil.getMaskedAcctNo(serviceId));
						}
					}
				}
				else
				{
					String statusCode = respXml.getNodeValue("statusCode");
					String errorCode = respXml.getNodeValue("errorCode");
					String errorMsg = respXml.getNodeValue("errorMsg");
					String cicsErrorCode = respXml.getNodeValue("cicsErrorCode");

					String errorText = "Input: " +  inpMap.toString() + ", statusCode=" + statusCode +
										", errorCode=" + errorCode + ", errorMsg=" + errorMsg +
										", cicsErrorCode=" + cicsErrorCode;
					_LOGGER.error(METHOD_NAME + "Vision Error::" +errorText);
					sendAutoRemIssuesByEmail(errorText, METHOD_NAME);
				}
			}
			updateAuditDetails(successList);
			if (acctList.size() > 0)
			{
				_LOGGER.info(METHOD_NAME + currentPortalLogId + ",ListSize=" + acctList.size());
				emailEligList.put(currentPortalLogId, acctList);
				sendMail(NcasConstants.RECUR_PAYMENT, emailEligList);
			}
			_LOGGER.info(METHOD_NAME + "  Exiting");
		}
		catch(NCASException e)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + e.getMessage());
			//sendRptIssuesByEmail(stack2string(e),METHOD_NAME);
			throw e;
		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + e.getMessage());
			//sendAutoRemIssuesByEmail(stack2string(e),METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, AutoRemBatchImpl.class, e);
		}
	}

	protected void sendMail(String tranName, Map<String, List> inpMap) throws NCASException
	{
		final String METHOD_NAME = "sendMail::";
		String template = null;

		try
		{
			_LOGGER.info(METHOD_NAME + "Values=" + inpMap.toString());
			Collection keys = inpMap.keySet();
			Iterator itr = keys.iterator();
			EmailUtil emailUtilObj = new EmailUtil();

			while (itr.hasNext())
			{
				String portalLogId = (String)itr.next();
				List acctList = (List)inpMap.get(portalLogId);

				if (acctList.size() > 10)
				{
					template = NcasConstants.VZW_IMP_TEMP_FOR_GREAT_THAN_TEN;
				}
				else
				{
					template = NcasConstants.VZW_IMP_TEMP_FOR_LESS_THAN_ELEVEN;
				}
				Map<String, Object> tempMap = getEmailTemplate(template);
				EmailTemplateInfo tempInfo = (EmailTemplateInfo)tempMap.get("TEMPLATE");
				emailUtilObj.setImpNotificationMessage(tranName, acctList,
						   								   tempInfo.getSubject(),
						   								   tempInfo.getTemplateDesc());
				//Commented till June'2011 Release
				//emailUtilObj.setToAddr(getUserEmail(portalLogId));
				List mailList = new ArrayList();
				//mailList.add("siddharth.x.srinivasan@verizon.com");
				//emailUtilObj.setToAddr(mailList);
				//emailUtilObj.sendMail(getUserEmail(portalLogId));
				//emailUtilObj.sendMail(mailList);
				emailUtilObj.sendMail(getUserEmail(portalLogId));
				_LOGGER.info(METHOD_NAME + ", EmailAddr=" + emailUtilObj.getToAddr().toString() + ", Content=" + emailUtilObj.getMessage());
			}
		}
		catch(NCASException ne)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + ne.getMessage());
			//sendRptIssuesByEmail(stack2string(e),METHOD_NAME);
			throw ne;
		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + e.getMessage());
			//sendAutoRemIssuesByEmail(stack2string(e),METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, AutoRemBatchImpl.class, e);
		}
	}

	protected void processRemUpdForPayDet(List<PaymentDetails> oneTimePayList) throws NCASException
	{
		final String METHOD_NAME = "processRemUpdForPayDet::";
		_LOGGER.info(METHOD_NAME + "  Entering");
		Map<String, String> inpMap = null;
		String transactionName = "MAKE WIRELESS ONE TIME PAYMENT";
		try
		{
			//VisionHelper visionHelpObj = new VisionHelper();
			VisionHelper visionHelpObj = getVisionHelperInstance();
			for (PaymentDetails item : oneTimePayList)
			{
				String serviceId = item.getServiceID().trim();
				String portalLoginId = item.getLoginId().trim();

				inpMap = new HashMap<String, String>();
				inpMap.put("SERVICE_ID", serviceId);
				inpMap.put("BILLING_SYS", "VISION_EAST");
				inpMap.put("CLIENT_ID", "VZB-VAM");
				inpMap.put("SERVICE_NAME", "autoRemarkUpdate");
				inpMap.put("REMARK_TYPE", DEFAULT_REMARK_TYPE);
				inpMap.put("REMARK_TEXT", transactionName + " CHANGED VIA VEC, USER ID " + portalLoginId);
				inpMap.put("CONTACT_METHOD", DEFAULT_CONTACT_METHOD);

				String inpXml = visionHelpObj.getServiceReqXmlForAutoRem(inpMap);
				_LOGGER.info(METHOD_NAME + "InputXml for accountNo=" + serviceId + ", userid=" + portalLoginId + "=" + inpXml);
				String response = visionHelpObj.invokeURL(inpXml);
				_LOGGER.info(METHOD_NAME + "Response for accountNo=" + serviceId + ", userid=" + portalLoginId + "=" + response);
			}
			_LOGGER.info(METHOD_NAME + "  Exiting");
		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + e.getMessage());
			//sendAutoRemIssuesByEmail(stack2string(e),METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, AutoRemBatchImpl.class, e);
		}
	}

	protected void processRemUpdForRecPay(List<RecurPayment> recPayList) throws NCASException
	{
		final String METHOD_NAME = "processRemUpdForRecPay::";
		_LOGGER.info(METHOD_NAME + "  Entering");
		Map<String, String> inpMap = null;
		final String EDIT_OR_CANCEL = "EDIT/CANCEL WIRELESS RECURRING PAYMENTS";
		final String SETUP = "SETUP WIRELESS RECURRING PAYMENT";
		String tranName = null;
		try
		{
			//VisionHelper visionHelpObj = new VisionHelper();
			VisionHelper visionHelpObj = getVisionHelperInstance();

			for (RecurPayment item : recPayList)
			{
				String serviceId = item.getServiceID().trim();
				String portalLoginId = item.getLoginId().trim();

				if (item.getPaymentStatus().equals(NcasConstants.RECUR_PAY_SCHEDULED_STATUS))
				{
					tranName = SETUP;
				}
				else
				{
					tranName = EDIT_OR_CANCEL;
				}

				inpMap = new HashMap<String, String>();
				inpMap.put("SERVICE_ID", serviceId);
				inpMap.put("BILLING_SYS", "VISION_EAST");
				inpMap.put("CLIENT_ID", "VZB-VAM");
				inpMap.put("SERVICE_NAME", "autoRemarkUpdate");
				inpMap.put("REMARK_TYPE", DEFAULT_REMARK_TYPE);
				inpMap.put("REMARK_TEXT", tranName + " CHANGED VIA VEC, USER ID " + portalLoginId);
				inpMap.put("CONTACT_METHOD", DEFAULT_CONTACT_METHOD);

				String inpXml = visionHelpObj.getServiceReqXmlForAutoRem(inpMap);
				_LOGGER.info(METHOD_NAME + "InputXml for accountNo =" + serviceId + ", userid=" + portalLoginId + "=" + inpXml);
				String response = visionHelpObj.invokeURL(inpXml);
				_LOGGER.info(METHOD_NAME + "Response for accountNo =" + serviceId + ", userid=" + portalLoginId + "=" + response);
			}
			_LOGGER.info(METHOD_NAME + "  Exiting");
		}
		catch(Exception e)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + e.getMessage());
			//sendAutoRemIssuesByEmail(stack2string(e), METHOD_NAME);
			throw new NCASException(BILLING_EXCEPTION_850, AutoRemBatchImpl.class, e);
		}
	}

	public String stack2string(Exception e)
	{
		try
		{
			InetAddress localHost = InetAddress.getLocalHost();
		    StringWriter sw = new StringWriter();
		    PrintWriter pw = new PrintWriter(sw);
		    e.printStackTrace(pw);
		    return "------\r\n Host-IP:" + localHost.getHostAddress() + "------\r\n"+"------\r\n" + sw.toString() + "------\r\n";
		}
		catch(Exception e2)
		{
		    return "bad stack2string";
		}
	}

	protected void sendAutoRemIssuesByEmail(String errMsg,String method)
	{
		final String METHOD_NAME = "sendAutoRemIssuesByEmail()";
		_LOGGER.info(METHOD_NAME+" Entering");
		String userEmail = NCASBOSIConfig.getProperty(PAYMENTS_EMAIL_ADDRESS, DEFAULT_PAYMENTS_EMAIL_ADDRESS);
		_LOGGER.info(METHOD_NAME+"::User email = "+userEmail);
		if(userEmail.length()>0)
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
			String errDateTime = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			List emailAddrList = new ArrayList();
			emailAddrList.add(userEmail);
			StringBuffer contentBuf = new StringBuffer();
			contentBuf.append("This email is to notify you that ")
			          .append(method)
			          .append(" has failed at ")
			          .append(errDateTime)
			          .append(". Below is the exception message::\r\n")
			          .append(errMsg);
			try
			{
				EmailUtil emailUtil = new EmailUtil();
				emailUtil.setMessage(contentBuf.toString());
				emailUtil.setSubject("Exception or Error in Auto Remark Update Batch Processing");
				emailUtil.sendMail(emailAddrList);
			}
			catch(Exception ex)
			{
				_LOGGER.error(METHOD_NAME + "\n" + ex.getMessage());
			}
		}
		else
		{
			_LOGGER.error(METHOD_NAME + " failed because of missing email address!");
		}
		_LOGGER.info(METHOD_NAME+" Exiting");
	}

	public Map<String, Object> getEmailTemplate(String templateName) throws NCASException
	{
		final String METHOD_NAME = "getEmailTemplate()";
		Map<String, Object> output = null;
		try
		{
			_LOGGER.info(METHOD_NAME + "TemplateName=" + templateName);
			Map<String,EmailTemplateInfo> emailTemplateInfoMap = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo();
			EmailTemplateInfo tempInfo = emailTemplateInfoMap.get(templateName);
			output = new HashMap<String, Object>();
			output.put("TEMPLATE", tempInfo);
			_LOGGER.info(METHOD_NAME + " Exiting");
		}
		catch(Exception ex)
		{
			_LOGGER.error(METHOD_NAME + "Failed \n" + ex.getMessage());
			throw new NCASException(BILLING_EXCEPTION_850, AutoRemBatchImpl.class, ex);
		}
		return output;
	}
}