package com.verizon.enterprise.ncasbosi.dao.Impl.email;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.EmailUtil;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.ticket.Email;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.email.EmailInterface;


public class EmailUIImpl extends EmailDAOImpl implements NCASBOSIConstants,EmailInterface {

	private static final Logger _LOGGER = Logger.getLogger(EmailUIImpl.class);

	@Override
	public Map processEmail(Map params) throws NCASException {
		Map retMap = null;
		Email email = (Email)params.get("EMAIL");
		DAOFactory.getInstance().getVbifImpl().addEmail(email);
		return retMap;

	}
	
	

	public Map createTicketFromEmail(Map params) throws NCASException {
		final String METHOD_NAME = "createTicketFromEmail => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		
			Map retMap = null;
			Email email = (Email)params.get("EMAIL");
			retMap = DAOFactory.getInstance().getVbifImpl().createTicketFromEmail(email);

		_LOGGER.info(METHOD_NAME+"Exiting ::"+retMap);			
			return retMap;
	}
	
	public Map validateTicket(Map params) throws NCASException {
		final String METHOD_NAME = "validateTicket => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		
		Map retMap = null;
		String ticket = (String)params.get("TICKET");
		retMap = DAOFactory.getInstance().getVbifImpl().validateTicket(ticket);
		
		_LOGGER.info(METHOD_NAME+"Exiting ::"+retMap);			
		return retMap;
	}
	
	public Map processException(Map params) throws Exception {
		Map retMap = null;
		List emailAddrList = new ArrayList();
		String toAddr = SystemParamConfig.getProperty("TICKET_EMAIL_EXCEPTION");
		
		if(toAddr!=null && !toAddr.isEmpty()){
			String values[] = toAddr.split(",");
			emailAddrList = Arrays.asList(values);
	   }
		
		Email email = (Email)params.get("EMAIL");
		String exp = (String)params.get("EXCEPTION");
		EmailUtil util = new EmailUtil();
		util.setMessage("EXCEPTION:::"+exp+"\nTICKET:::"+email);							
		util.setSubject("ICI TICKET EMAIL EXCEPTION");					
		util.sendMail(emailAddrList);
		return retMap;

	}

	

	@Override
	public Map processMessageData(Map params) throws NCASException {
		final String METHOD_NAME = "processEmails => ";
		_LOGGER.info(METHOD_NAME+"Entering");

		String method = (String)params.get("method");
		Map result = null;
		if("insert".equalsIgnoreCase(method)){
			result = insertMessageData(params);
			_LOGGER.info(" Message data inserted into DB "+result.get("oid"));
		}else if("select".equalsIgnoreCase(method)){
			result = selectMessageData(params);
		}
		return result;

	}

	@Override
	public Map emailMonitor(Map params) throws NCASException {
		final String METHOD_NAME = "emailMonitor => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		String method = (String)params.get("method");
		Map result = super.emailMonitor(params);;
		return result;

	}


}




