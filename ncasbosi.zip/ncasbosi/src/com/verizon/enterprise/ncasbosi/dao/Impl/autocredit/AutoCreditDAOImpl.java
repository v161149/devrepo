package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.math.BigDecimal;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Impl.common.SPGetARSystem;
import com.verizon.enterprise.ncasbosi.dao.Impl.common.SPGetCANDates;
import com.verizon.enterprise.ncasbosi.dao.Impl.common.SPGetProductDropDown;
import com.verizon.enterprise.ncasbosi.dao.Impl.common.SPGetRsnSubCatDropDown;
import com.verizon.enterprise.ncasbosi.dao.Interface.autocredit.AutoCreditInterface;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;

import com.verizon.enterprise.common.ncas.autocredit.BillingElement;
import com.verizon.enterprise.common.ncas.autocredit.CreditType;
import com.verizon.enterprise.common.ncas.autocredit.LineItem;
import com.verizon.enterprise.common.ncas.autocredit.VamDO;


/*
 * Author:Ram/v992473
 */

public class AutoCreditDAOImpl extends NCASSpringJDBCBase implements AutoCreditInterface{

	private static final Logger _LOGGER = Logger.getLogger(AutoCreditDAOImpl.class);
	private JdbcTemplate vamJdbcTemplate;//jdbctemplate created for VAM dataSource

	public void setVAMDataSource(DataSource dataSource){
		vamJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[VAMjdbcTemplate datasource set ]");
	}

	public DataSource getVAMDataSource(){
		return vamJdbcTemplate.getDataSource();
	}

	public Map createClaim(Object claimInput)throws NCASException{
		_LOGGER.info("Entering createClaim");
		Map returnMap = null;
		try{
			returnMap = new SPCreateClaim(getDataSource()).executeStoredProcedure(claimInput);
		}catch(Exception createClaimException){
			 _LOGGER.error("createClaim - failed::"+createClaimException.getMessage());
			 createClaimException.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,createClaimException);
		}
		_LOGGER.info("Exiting createClaim");
		return returnMap;
	}

	public Map getClaim(Object claimNumber)throws NCASException{
		_LOGGER.info("Entering getClaim");
		Map returnMap = null;
		try{
			returnMap = new SPGetClaim(getDataSource()).executeStoredProcedure(claimNumber);
		}catch(Exception getClaimException){
			 _LOGGER.error("getClaim - failed::"+getClaimException.getMessage());
			 getClaimException.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,getClaimException);
		}
		_LOGGER.info("Exiting getClaim");
		return returnMap;
	}

	public Map getDupeClaims(Object claimNumber)throws NCASException{
		_LOGGER.info("Entering getDupeClaims");
		Map returnMap = null;
		try{
			returnMap = new SPGetDupeClaims(getDataSource()).executeStoredProcedure(claimNumber);
		}catch(Exception getDupeClaimException){
			 _LOGGER.error("getDupeClaims - failed::"+getDupeClaimException.getMessage());
			 getDupeClaimException.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,getDupeClaimException);
		}
		_LOGGER.info("Exiting getDupeClaims");
		return returnMap;
	}

	public Map searchClaims(Object claimSearch)throws NCASException
	{
		_LOGGER.info("Entering searchClaims");
		Map returnMap = null;
		try{
			returnMap = new SPSearchClaims(getDataSource()).executeStoredProcedure(claimSearch);
		}catch(Exception getSearchClaimException){
			 _LOGGER.error("getSearchClaims - failed::"+getSearchClaimException.getMessage());
			 getSearchClaimException.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,getSearchClaimException);
		}
		_LOGGER.info("Exiting getSearchClaims");
		return returnMap;
	}

	public Map acsearchClaims(Object claimSearch)throws NCASException
	{
		_LOGGER.info("Entering searchClaims");
		Map returnMap = null;
		try{
			returnMap = new SPSearchClaims(getDataSource()).executeStoredProcedure(claimSearch);
		}catch(Exception getSearchClaimException){
			 _LOGGER.error("getSearchClaims - failed::"+getSearchClaimException.getMessage());
			 getSearchClaimException.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,getSearchClaimException);
		}
		_LOGGER.info("Exiting getSearchClaims");
		return returnMap;
	}

	public Map reassignClaimsFromACCentral(Object pClaimMap)throws NCASException{
		_LOGGER.info("Entering reassignClaimsFromACCentral");
		Map returnMap = null;
		Map inputMap = (Map)pClaimMap;
		List selectedClaimsList = (List)inputMap.get("SELECTED_CLAIMS");
		for(int i=0;i<selectedClaimsList.size();i++){
			try{
				inputMap.put("ESG_CLAIM_NUMBER",(String)selectedClaimsList.get(i));
				updateClaim(inputMap);
			}catch(Exception updateClaimException){
				_LOGGER.info("updateClaim - Reassign AC Central failed::"+updateClaimException.getMessage());
				updateClaimException.printStackTrace();
				throw new NCASException("AC1001",AutoCreditDAOImpl.class,updateClaimException);
			}
		}
		_LOGGER.info("Exiting reassignClaimsFromACCentral");
		return returnMap;
	}

	public Map updateClaim(Object pClaimMap)throws NCASException{
		_LOGGER.info("Entering updateClaim");
		Map returnMap = null;
		try{
			returnMap = new SPUpdateClaim(getDataSource()).executeStoredProcedure(pClaimMap);
		}catch(Exception updateClaimException){
			_LOGGER.info("updateClaim - failed::"+updateClaimException.getMessage());
			updateClaimException.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,updateClaimException);
		}
		_LOGGER.info("Exiting updateClaim");
		return returnMap;
	}

	public Map submitClaim(Object pClaimMap)throws NCASException{
		_LOGGER.info("Entering submitClaim");
		Map returnMap = null;
		try{
			//making two calls for submit
			//first, calling with USER_ACTION = SAVE_FOR_SUBMIT
			((Map)pClaimMap).put("USER_ACTION","SAVE_FOR_SUBMIT");
			returnMap = new SPUpdateClaim(getDataSource()).executeStoredProcedure(pClaimMap);
			//if reached here,then no exception from the previous call.
			//second calling with USER_ACTION = SUBMIT
			((Map)pClaimMap).put("USER_ACTION","SUBMIT");
			returnMap = new SPUpdateClaim(getDataSource()).executeStoredProcedure(pClaimMap);
		}catch(Exception submitClaimException){
			_LOGGER.info("submitClaim - failed::"+submitClaimException.getMessage());
			submitClaimException.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,submitClaimException);
		}
		_LOGGER.info("Exiting submitClaim");
		return returnMap;
	}


	public Map getReasonCode(Object input)throws NCASException{
		_LOGGER.info("Entering getReasonCode");
		Map returnMap = new HashMap();
		Map inputMap = (Map)input;
		try{
			//setting reasoncode null (because not required)for reason code dropdown call
			inputMap.put("REASON_CD",null);
			inputMap.put("DROP_DOWN_NAME",NcasConstants.DROP_DOWN_REASON_CODE);
			Map outMap = new SPGetRsnSubCatDropDown(getDataSource()).executeStoredProcedure(inputMap);
			returnMap.put("REASON_CODE_LIST",(List)outMap.get("DROP_DOWN_LIST"));				
		}catch(Exception ex){
			_LOGGER.info("getReasonCode - failed::"+ex.getMessage());
			ex.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,ex);
		}
		_LOGGER.info("Exiting getReasonCode");
		return returnMap;
	}

	public Map getSubCategory(Object inputMap)throws NCASException{
		_LOGGER.info("Entering getSubCategory");
		Map returnMap = new HashMap();
		try{	
			((Map)inputMap).put("DROP_DOWN_NAME",NcasConstants.DROP_DOWN_SUB_CATEGORY);
			Map outMap = new SPGetRsnSubCatDropDown(getDataSource()).executeStoredProcedure(inputMap);
			returnMap.put("SUB_CATEGORY_LIST",(List)outMap.get("DROP_DOWN_LIST"));			
		}catch(Exception ex){
			_LOGGER.info("getSubCategory - failed::"+ex.getMessage());
			ex.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,ex);
		}
		_LOGGER.info("Exiting getSubCategory");
		return returnMap;
	}
	
	public Map getProduct(Object inputMap)throws NCASException{
		_LOGGER.info("Entering getProduct");
		Map returnMap = new HashMap();
		try{	
			Map outMap = new SPGetProductDropDown(getDataSource()).executeStoredProcedure(inputMap);
			returnMap.put("PRODUCT_LIST",(List)outMap.get("DROP_DOWN_LIST"));			
		}catch(Exception ex){
			_LOGGER.info("getProduct - failed::"+ex.getMessage());
			ex.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,ex);
		}
		_LOGGER.info("Exiting getProduct");
		return returnMap;
	}

	public Map getCANDates(Object inputMap)throws NCASException{
		_LOGGER.info("Entering getCANDates");
		Map returnMap = null;
		try{
			((Map)inputMap).put("APP_USER_ID", NCASBOSIConstants.VAM_USER_ID);
			((Map)inputMap).put("DEBUG_LEVEL", NCASBOSIConstants.VAM_DEBUG_LEVEL);
			((Map)inputMap).put("CUST_NO", "0");
			((Map)inputMap).put("CONFIG_NO", "0");
			returnMap = new SPGetCANDates(getVAMDataSource()).executeStoredProcedure(inputMap);
		}catch(Exception ex){
			_LOGGER.info("getCANDates - failed::"+ex.getMessage());
			ex.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,ex);
		}
		_LOGGER.info("Exiting getCANDates");
		return returnMap;
	}


	/* user selected a serviceid to add to the claim, check to see if this service id
	 * is already there
	 * RETURN_CODE=0 no collision
	 * RETURN_CODE=-8 service id already exists on claim
	 *
	 * input Map
		"vamDO" VamDO
	 */
	public Map getDupeServiceId(Object input)throws NCASException{
		_LOGGER.info("Entering getDupeServiceId");
		Map returnMap = null;
		try{
			SPGetDupeServiceId sp = new SPGetDupeServiceId(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error("getDupeServiceId - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getDupeServiceId");
		return returnMap;
	}

	/* get list of serviceId's (circuits) that match user entered mask and date range
	 * input List
	 * 	input.0 = vamDO
	 * */
	public Map getServiceIds(Object input)throws NCASException
	{
		_LOGGER.info("Entering getServiceIds");
		Map returnMap = null;
		try{
			List inputList = (ArrayList)input;
			VamDO vamDO = (VamDO)inputList.get(0);
			String serviceIdType = vamDO.getServiceIdType();

			if (serviceIdType == null || "".equals(serviceIdType))
			{
				SPGetServiceIds sp = new SPGetServiceIds(getVAMDataSource());
				returnMap = sp.executeStoredProcedure(input);
			}
			else
			{
				SPGetM3ServiceIds sp = new SPGetM3ServiceIds(getVAMDataSource());
				returnMap = sp.executeStoredProcedure(input);
			}
		}catch(Exception e){
			 _LOGGER.error("getServiceIds - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getServiceIds");
		return returnMap;
	}


	/* user selected a service id, this api gets all the billing elements assoiated with the
	 * serviceId for the time period the user selected
	 * input Map
	 * 	"vamDO" VamDO
	 * 	"pagination" Pagination
	 */
	public Map getBillElements(Object input)throws NCASException
	{
		_LOGGER.info("Entering getBillElements");
		Map returnMap = null;
		try{

			SPGetBillElements sp = new SPGetBillElements(getVAMDataSource());
			returnMap = sp.executeStoredProcedure(input);

		}catch(Exception e){
			 _LOGGER.error("getBillElements - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getBillElements");
		return returnMap;
	}
	
	/* same as getBillElements but for usage instead of charges.
	 * input Map
	 * 	"vamDO" VamDO
	 * 	"pagination" Pagination
	 */
	public Map getUsageBillElements(Object input)throws NCASException
	{
		_LOGGER.info("Entering getUsageBillElements");
		Map returnMap = null;
		try{

			SPGetUsageBillElements sp = new SPGetUsageBillElements(getVAMDataSource());
			returnMap = sp.executeStoredProcedure(input);

		}catch(Exception e){
			 _LOGGER.error("getUsageBillElements - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getUsageBillElements");
		return returnMap;
	}
	

	/* get all the late payment charges we charged the serciceid
	 * input List
	 * 	input.0 = vamDO */
	public Map getLatePayCharges(Object input)throws NCASException
	{
		_LOGGER.info("Entering getLatePayCharges");
		Map returnMap = null;
		try{
			SPGetLatePayCharges sp = new SPGetLatePayCharges(getVAMDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error("getLatePayCharges - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getLatePayCharges");
		return returnMap;
	}

	/* get all the taxes we on the bill for the service id
	 * input List
	 * 	input.0 = vamDO */
	public Map getTaxes(Object input)throws NCASException
	{
		_LOGGER.info("Entering getTaxes");
		Map returnMap = null;
		try{
			SPGetTaxes sp = new SPGetTaxes(getVAMDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error("getTaxes - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getTaxes");
		return returnMap;
	}

	/* Retrieve the data from the VAC_INT_CALC_DTL table, given a claim number.  
	 * This API is called by VzT auto calc when user clicks "Attach calc dtl" from claim.
	 * input map
	 * 		"claimNumber"  String
	 */	
	public Map getInterestCalculationDetails(Object input)throws NCASException
	{
		_LOGGER.info("Entering getInterestCalculationDetails");
		Map returnMap = null;
		try{
			SPGetInterestCalculationDetails sp = new SPGetInterestCalculationDetails(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error("getInterestCalculationDetails - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getInterestCalculationDetails");
		return returnMap;
	}
	
	/* get the details (bill elements) that make up the cliam shown on calc details popup
	 * page and also saved as an attachemnt to the claim.
	 * input map
	 * 		"claimNumber"  String
	 * 		"pagination"   pagination object
	 */
	public Map getCalculationDetails(Object input)throws NCASException
	{
		_LOGGER.info("Entering getCalculationDetails");
		Map returnMap = null;
		try{
			SPGetCalculationDetails sp = new SPGetCalculationDetails(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error("getCalculationDetails - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getCalculationDetails");
		return returnMap;
	}

	/*
	 * create adjustemnts,
	 * input map
	 * 		"vamDO"  data from screen
		    "billElements" list of bill elements user wants to create adjustment for
		    "dateList"  list of invoice dates in the "billElements"
	 */
	public Map createAdjustments(Object input)throws NCASException
	{
		_LOGGER.info("Entering createAdjustments");


		Map inputMap = (HashMap) input;
		Map returnMap = null;
		List latePaymentCharges = new ArrayList();
		List taxes = new ArrayList();

		/* first get late payment charges and taxes assoiated with the bill elements
		 * need to call this multiple times,  use date on bill element and get any late
		 * payment charges for that bill.  and then get the next bill elements late pay charges
		 * this was initially written to get all late payment charges in a date range but the
		 * rep can delete bill elements so there my be gaps in the bills.  the action creates
		 * the date list and we make sure its unique and loop thur it here */
		try
		{
			List dateList = (ArrayList)inputMap.get("dateList");
			if (dateList == null)
				throw new Exception("AutoCreditDAOImpl:createAdjustments: input data object is null");

			//get bool, if true we will include taxes in adjs. if false will skip taxes.
			boolean calcTaxes = false;
			String ct = (String)inputMap.get("calcTaxes");
			if (ct != null)
				calcTaxes =  (Boolean.valueOf(ct)).booleanValue();

			//get bool, if true we will include LPC's in adjs. if false will skip LPC's.
			boolean calcLPCs = false;
			String clpc = (String)inputMap.get("calcLPCs");
			if (clpc != null)
				calcLPCs =  (Boolean.valueOf(clpc)).booleanValue();

			//make sure list of dates has unique values.
			Set set = new HashSet(dateList);
			List uniqueDateList = new ArrayList(set);

			for (int i = 0; i < uniqueDateList.size(); i++)
			{
				inputMap.put("billDate", uniqueDateList.get(i));
				//get lpc's
				if(calcLPCs)
				{
					Map lpcMap = getLatePayCharges(inputMap);
					List latePaymentChargesForBillDate = (ArrayList)lpcMap.get("RESULT_SET_ONE");
					latePaymentCharges.addAll(latePaymentChargesForBillDate);
				}
				//get taxes
				if (calcTaxes)
				{
					Map taxMap = getTaxes(inputMap);
					List taxesForBillDate = (ArrayList)taxMap.get("RESULT_SET_ONE");
					taxes.addAll(taxesForBillDate);
				}
			}
			
		}
		catch(Exception e)
		{
			_LOGGER.error("error getting late payment charges or taxes::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		
		/* now call vac to create the adjustments using the bill elements, taxes, and lpc's */

		VamDO vamDO = (VamDO)inputMap.get("vamDO");
		if (vamDO == null){
			throw new NCASException("AC1001", AutoCreditDAOImpl.class, null, new String[] {"AutoCreditDAOImpl:createAdjustments: input vamDO is null"}); 
		}
		boolean vacPersistsBEs = Boolean.valueOf(vamDO.getVacPersistsBEs());
		if (vacPersistsBEs)
		{			
			if(CreditType.LATE_DISCONNECT.equalsIgnoreCase(vamDO.getCreditType()) || CreditType.SERVICE_SETUP_ERROR.equalsIgnoreCase(vamDO.getCreditType()) || CreditType.TAX_EXEMPT_CREDIT.equalsIgnoreCase(vamDO.getCreditType()) || CreditType.LATE_PAYMENT_CHARGE.equalsIgnoreCase(vamDO.getCreditType()) ){//not calling calc_act_adjs for LD,SS,Tx & LP(from ticket) - instead calling calc_late_disc BAU
				returnMap=createAdjustmentsPassingBEs(inputMap, latePaymentCharges, taxes);
			}else{
				returnMap=createAdjustmentsPersistedBEs(inputMap, latePaymentCharges, taxes);
			}			
		}
		else
		{
			returnMap=createAdjustmentsPassingBEs(inputMap, latePaymentCharges, taxes);
		}
		return returnMap;

	}

	// call vac passing taxes and late pay charges, they already have the bill elements so we do not pass them.
	public Map createAdjustmentsPersistedBEs(Map inputMap, List latePaymentCharges, List taxes) throws NCASException
	{
		Map returnMap = null;
		try{

			VamDO vamDO = (VamDO)inputMap.get("vamDO");
			List details = new ArrayList();

			details.addAll(latePaymentCharges);
			details.addAll(taxes);

			int totalRows = details.size();  //total rows we will send vac, may need to call multiple times to get up to this number.
			inputMap.put("totalRows", totalRows + "");
			
			//vac can only handle 32000 bytes in a string, if we have more than that call vac multiple times.
			int varCharLimit = 32000;
//			if (_LOGGER.isDebugEnabled())
//				varCharLimit = 300;
			_LOGGER.info("varCharLimit=" + varCharLimit );
			StringBuffer inputString = new StringBuffer(varCharLimit);
			int inputRows = 0;  //how many rows we are sending vac for this call.
			
			for (int i = 0; i < details.size(); i ++)
			{
				BillingElement detail = (BillingElement) details.get(i);
				String detailVacString = detail.toVacCalcActAdjsString(vamDO.getBatchId());
				if (inputString.length() + detailVacString.length() > varCharLimit)
				{
					SPCalcActAdjs sp = new SPCalcActAdjs(getDataSource());
					inputMap.put("vacString", inputString.toString());
					inputMap.put("inputRows", inputRows + "");
					inputMap.put("moreInd", "Y");  // a Y means we will call vac again
					sp.executeStoredProcedure(inputMap);
					inputString = new StringBuffer(varCharLimit);
					inputRows = 0;
				}

				inputString.append(detailVacString);
				inputRows ++;
			}

			SPCalcActAdjs sp = new SPCalcActAdjs(getDataSource());
			inputMap.put("vacString", inputString.toString());
			inputMap.put("inputRows", inputRows + "");
			inputMap.put("moreInd", "N");  // a N means this is the last call
			returnMap=sp.executeStoredProcedure(inputMap);


		}catch(Exception e){
			_LOGGER.error("createAdjustmentsPersistedBEs - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting createAdjustmentsPersistedBEs");
		return returnMap;
	}

	// call vac passing billelements, taxes and late pay charges
	public Map createAdjustmentsPassingBEs(Map inputMap, List latePaymentCharges, List taxes) throws NCASException
	{
		Map returnMap = null;
		try{

			List billElements = (ArrayList)inputMap.get("billElements");
			
			//the first time we call vac they return a batchId, if we need to call them again we pass then back the batchId.
			String batchId = null;
			
			//LD - ticket changes for June 2011 - forwarding the batchId passed from UI
			//also not passing the standard charges as VAC already persisted them
			//also for proceed action,batchId is not required
			VamDO vamDO = (VamDO)inputMap.get("vamDO");
			if((new Boolean(vamDO.getVacPersistsBEs())).booleanValue() &&  !"PROCEED".equalsIgnoreCase(vamDO.getButtonClicked())){
				billElements = new ArrayList();
				batchId = vamDO.getBatchId();
			}			
						
			if (billElements == null){
				throw new Exception("AutoCreditDAOImpl:createAdjustmentsPassingBEs: input billElements List is null");
			}

			List details = new ArrayList();

			details.addAll(billElements);
			details.addAll(latePaymentCharges);
			details.addAll(taxes);

			int totalRows = details.size();  //total rows we will send vac, may need to call multiple times to get up to this number.
			inputMap.put("totalRows", totalRows + "");
			
			
			inputMap.put("batchId", batchId);

			//vac can only handle 32000 bytes in a string, if we have more than that call vac multiple times.
			int varCharLimit = 32000;
//			if (_LOGGER.isDebugEnabled())
//				varCharLimit = 300;
			_LOGGER.info("varCharLimit=" + varCharLimit );
			StringBuffer inputString = new StringBuffer(varCharLimit);
			int inputRows = 0;  //how many rows we are sending vac for this call.
			
			_LOGGER.info("vamDO.osId=" + vamDO.getOsid());
			_LOGGER.info("vamDO.serviceId=" + vamDO.getServiceId());
			for (int i = 0; i < details.size(); i ++)
			{
				BillingElement detail = (BillingElement) details.get(i);
				String detailVacString = detail.toVacCalcLateDiscAdjString(vamDO.getOsid(),vamDO.getServiceId());
				if (inputString.length() + detailVacString.length() > varCharLimit)
				{
					SPCalcLateDiscAdjustments sp = new SPCalcLateDiscAdjustments(getDataSource());
					inputMap.put("vacString", inputString.toString());
					inputMap.put("inputRows", inputRows + "");
					inputMap.put("moreInd", "Y");  // a Y means we will call vac again
					Map tempMap = sp.executeStoredProcedure(inputMap);
					// PVB emer fix removed cast to String  - which is invalid 6/16/2009
					BigDecimal bdBatchId = (BigDecimal)tempMap.get("OUT_BATCH_ID");
					inputMap.put("batchId", bdBatchId.toString());
					_LOGGER.info("batch id back from vac: " + bdBatchId.toString());
					inputString = new StringBuffer(varCharLimit);
					inputRows = 0;
				}

				inputString.append(detailVacString);
				inputRows ++;
			}

			SPCalcLateDiscAdjustments sp = new SPCalcLateDiscAdjustments(getDataSource());
			inputMap.put("vacString", inputString.toString());
			inputMap.put("inputRows", inputRows + "");
			inputMap.put("moreInd", "N");  // a N means this is the last call
			returnMap=sp.executeStoredProcedure(inputMap);


		}catch(Exception e){
			_LOGGER.error("createAdjustmentsPassingBEs - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting createAdjustmentsPassingBEs");
		return returnMap;
	}

	/*
	 * get adjustemnts,
	 * input Map - items same name as vac sp inputs
	 */
	public Map getAdjustments(Object input)throws NCASException
	{
		_LOGGER.info("Entering getAdjustments");

		Map returnMap = null;
		try{
			SPGetAdjustments sp = new SPGetAdjustments(getDataSource());
			returnMap = sp.executeStoredProcedure(input);

			// calculate the total of all the adjustments.
			ArrayList lineItems = (ArrayList)returnMap.get("RESULT_SET_ONE");
			BigDecimal total = new BigDecimal(0.0);
			LineItem li = null;
			for (int i = 0; i < lineItems.size(); i++)
			{
				li = (LineItem)lineItems.get(i);
				total = total.add(new BigDecimal(li.getCreditAmount()));
				
				//checking the update option for tax row and tax exempt credit type(T-TX together)
				String adjustmentIndicator = li.getAdjustmentIndicator();
				String creditType = (String)returnMap.get("CALC_TYPE");
				String osId = li.getOrig_System_Id();
				String product = li.getProduct();
				if(NcasConstants.IBRS.equalsIgnoreCase(osId) || NcasConstants.VISION.equalsIgnoreCase(osId)){
					if(CreditType.TAX_EXEMPT_CREDIT.equalsIgnoreCase(creditType) && NcasConstants.TAX_ADJUSTMENT.equalsIgnoreCase(adjustmentIndicator)){
						if(product==null || product.trim().length()==0){
							li.setUpdateNeeded(true);
						}else{
							li.setUpdateNeeded(false);
						}
					}
				}
				
			}
			returnMap.put("total", total);

		}catch(Exception e){
			 _LOGGER.error("getAdjustments - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getAdjustments");
		return returnMap;
	}

	/*
	 * update adjustemnts,
	 * input Map - items same name as vac sp inputs
	 * will update a single adjustment if id passed in, will also update all adjustments for service id
	 * they adjustments are presisted in vac on create, but they are tempory, this api can 'save' them and make them
	 * perminate or 'delete' them, or 'update' them one at a time with reason codes etc.
	 */
	public Map updateAdjustments(Object input)throws NCASException
	{
		_LOGGER.info("Entering updateAdjustments");

		Map returnMap = null;
		try{
			SPUpdateAdjustments sp = new SPUpdateAdjustments(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			 _LOGGER.error("updateAdjustments - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting updateAdjustments");
		return returnMap;
	}

	public Map updateAllAdjustments(Object input)throws NCASException
	{
		_LOGGER.info("Entering updateAllAdjustments");

		Map inputMap = (HashMap) input;
		Map returnMap = null;
		Map adjMap = null;
		Map updateMap = null;
		LineItem li = null;
		
		_LOGGER.info("inputMap::"+inputMap);
		
		try{
			// figure out if we came from calc wiz or claim management,
			String serviceId = (String)inputMap.get("SERVICE_ID");
			String userAction = (String)inputMap.get("USER_ACTION");
			String creditDebit = (String)inputMap.get("CREDIT_DEBIT");
			if (userAction!=null && userAction.equalsIgnoreCase("SAVE"))
			{
				inputMap.put("ADJ_STATUS", null);  //tells getAdjustments to get adjs added to claim
			}
			else
			{
				inputMap.put("ADJ_STATUS", "0"); //tells getAdjustments to get adjs in work in progress
			}

			inputMap.put("SORT_FIELD", "TARGET_INVOICE_DT");//SORT_FIELD
			inputMap.put("SORT_DIR", "D");//SORT_DIR
			inputMap.put("SORT_POS", "1");//SORT_POS
			inputMap.put("NUM_ROWS", "10000");//NUM_ROWS

			adjMap = getAdjustments(inputMap);
			String calcType = (String)adjMap.get("CALC_TYPE");
			_LOGGER.info("CALC_TYPE from getAdjustments::"+calcType);
			if(calcType == null || calcType.trim().length()==0){
				throw new Exception("CALC_TYPE cannot be empty on getAdjustments::It is needed for updating adjs");
			}
			
			ArrayList adjustments = (ArrayList)adjMap.get("RESULT_SET_ONE");

			if (adjustments != null)
			{
				for (int i = 0; i < adjustments.size(); i++)
				{
					li = (LineItem)adjustments.get(i);
					
					//checking multiple adjustments to see they have same DR/CR value as the one passed from UI 
					//and update only those that match
					_LOGGER.info("creditDebit of a lineItem on getAdj::"+li.getCreditDebit());
					if(creditDebit==null || !creditDebit.equalsIgnoreCase(li.getCreditDebit())){
						//not updating adjustments if CR/DR value dont match
						continue;
					}			
					
					inputMap.put("VAC_ADJUST_ID", li.getAdjustmentId());
					
					// update monthly charges, non-recurring,usage
					if (li.getAdjustmentIndicator().equalsIgnoreCase(NcasConstants.MRC_ADJUSTMENT) ||
						li.getAdjustmentIndicator().equalsIgnoreCase(NcasConstants.NRC_ADJUSTMENT) ||	
						li.getAdjustmentIndicator().equalsIgnoreCase(NcasConstants.USAGE_ADJUSTMENT))
					{
						updateMap = updateAdjustments(inputMap);
					}else if(li.getAdjustmentIndicator().equalsIgnoreCase(NcasConstants.TAX_ADJUSTMENT) && 
						    CreditType.TAX_EXEMPT_CREDIT.equalsIgnoreCase(calcType)){
						//this is the situation where we have only tax rows for tax exempt credit
						//when this if is reached,it is only for IBRS/VISION(for now - not sure may have to tweak this for future requirements)
						//so from UI,only updated value of product is passed(and rest are all VAC self-populated values) 
					 	inputMap.put("VZB_REASON_CODE", li.getReasonCode());
						inputMap.put("SUB_CAT_CD",li.getSubCategory());
						updateMap = updateAdjustments(inputMap);
					}
				}
			}
		}catch(Exception e){
			 _LOGGER.error("updateAllAdjustments - failed::"+e.getMessage());
			 e.printStackTrace();
			 throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting updateAllAdjustments");
		return returnMap;
	}


	public Map retargetAdjustment(Object input)throws NCASException{
		_LOGGER.info("Entering retargetAdjustment");
		Map returnMap = null;
		try{
			SPRetargetAdjustment sp = new SPRetargetAdjustment(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			_LOGGER.error("retargetAdjustment - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting retargetAdjustment");
		return returnMap;
	}

	public Map getARSystem(Object input)throws NCASException{
		_LOGGER.info("Entering getARSystem");
		Map returnMap = null;
		try{
			SPGetARSystem sp = new SPGetARSystem(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			_LOGGER.error("getARSystem - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getARSystem");
		return returnMap;
	}

	public Map getARSystems(Object input)throws NCASException{
		_LOGGER.info("Entering getARSystems");
		Map outMap = null;
		try{
			List inputList = (List)input;
			outMap = new HashMap();
			Iterator it = inputList.iterator();
			while(it.hasNext()){
				String osId = (String)it.next();
				HashMap inputMap = new HashMap();
				inputMap.put("ORIGINATING_SYS_ID", osId);
				Map resMap = getARSystem(inputMap);
				String ARSystem = (String)resMap.get("A_R_SYSTEM");
				outMap.put(osId, ARSystem);
			}
		}catch(Exception e){
			_LOGGER.error("getARSystems - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getARSystems");
		return outMap;
	}
	
	public Map getACTCategories(Object input)throws NCASException{
		_LOGGER.info("Entering getACTCategories");
		Map returnMap = null;
		try{
			SPGetACTCategories sp = new SPGetACTCategories(getDataSource());
			returnMap = sp.executeStoredProcedure(input);
		}catch(Exception e){
			_LOGGER.error("getACTCategories - failed::"+e.getMessage());
			e.printStackTrace();
			throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
		}
		_LOGGER.info("Exiting getACTCategories");
		return returnMap;
	}

	   public Map getAuditorDetails(Object input)throws NCASException{
	        _LOGGER.info("Entering getAuditorDetails");
	        Map returnMap = null;
	        try{
	            Map inputMap = (Map)input;
	            String key = (String)inputMap.get("KEY"); 
	            _LOGGER.info("KEY :: -> "+key);
	            SPGetAuditorDetails sp = new SPGetAuditorDetails(getDataSource(),key);
	            returnMap = sp.executeStoredProcedure(inputMap);
	        }catch(Exception e){
	            _LOGGER.error("getAuditorDetails - failed::"+e.getMessage());
	            e.printStackTrace();
	            throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
	        }
	        _LOGGER.info("Exiting getAuditorDetails");
	        return returnMap;
	    }

	    public Map updateAuditorDetails(Object input)throws NCASException{
	        _LOGGER.info("Entering updateAuditorDetails");
	        Map returnMap = null;
	        try{
	            Map inputMap = new HashMap();
	            SPUpdateAuditorDetails sp = new SPUpdateAuditorDetails(getDataSource());
	            returnMap = sp.executeStoredProcedure(input);
	        }catch(Exception e){
	            _LOGGER.error("updateAuditorDetails - failed::"+e.getMessage());
	            e.printStackTrace();
	            throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
	        }
	        _LOGGER.info("Exiting updateAuditorDetails");
	        return returnMap;
	    }
	    
	    public Map cleanupCalcDetail(Object input)throws NCASException{
	        _LOGGER.info("Entering cleanupCalcDetail");
	        Map returnMap = null;
	        try{
	            SPCleanupCalcDetail sp = new SPCleanupCalcDetail(getDataSource());
	            returnMap = sp.executeStoredProcedure(input);
	        }catch(Exception e){
	            _LOGGER.error("cleanupCalcDetail - failed::"+e.getMessage());
	            e.printStackTrace();
	            throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
	        }
	        _LOGGER.info("Exiting cleanupCalcDetail");
	        return returnMap;
	    }
	    
	    public Map updateCalcDetail(Object input)throws NCASException{
	        _LOGGER.info("Entering updateCalcDetail");
	        Map returnMap = null;
	        try{
	            SPUpdateCalcDetail sp = new SPUpdateCalcDetail(getDataSource());
	            returnMap = sp.executeStoredProcedure(input);
	        }catch(Exception e){
	            _LOGGER.error("updateCalcDetail - failed::"+e.getMessage());
	            e.printStackTrace();
	            throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
	        }
	        _LOGGER.info("Exiting updateCalcDetail");
	        return returnMap;
	    }
	    
	    public Map createCalcDetail(Object input)throws NCASException
		{
			_LOGGER.info("Entering createCalcDetail");

			Map inputMap = (Map)input;
			Map returnMap = null;
			try{
				List billElements = (ArrayList)inputMap.get("billElements");
				if (billElements == null){
					throw new Exception("AutoCreditDAOImpl:createCalcDetail: input billElements List is null");
				}
				int totalRows = billElements.size();  //total rows we will send vac, may need to call multiple times to get up to this number.
				inputMap.put("totalRows", String.valueOf(totalRows));
								
				//the first time we call vac they return a batchId, if we need to call them again we pass then back the batchId.
				String batchId = null;
				inputMap.put("batchId", batchId);
				
				//vac can only handle 32000 bytes in a string, if we have more than that call vac multiple times.
				int varCharLimit = 32000;
				_LOGGER.info("varCharLimit=" + varCharLimit );
				StringBuffer inputString = new StringBuffer(varCharLimit);
				int inputRows = 0;  //how many rows we are sending vac for this call.
				VamDO vamDO = (VamDO)inputMap.get("vamDO");
				_LOGGER.info("vamDO.osId=" + vamDO.getOsid());
				_LOGGER.info("vamDO.serviceId=" + vamDO.getServiceId());
				for (int i = 0; i < billElements.size(); i ++){
						BillingElement detail = (BillingElement) billElements.get(i);
						String detailVacString = detail.toVacCreateCalcDtlString(vamDO.getOsid(),vamDO.getServiceId());
						if (inputString.length() + detailVacString.length() > varCharLimit){
							SPCreateCalcDetail sp = new SPCreateCalcDetail(getDataSource());
							inputMap.put("vacString", inputString.toString());
							inputMap.put("inputRows", String.valueOf(inputRows));
							inputMap.put("moreInd", "Y");  // a Y means we will call vac again
							Map tempMap = sp.executeStoredProcedure(inputMap);
							// PVB emer fix removed cast to String  - which is invalid 6/16/2009
							BigDecimal bdBatchId = (BigDecimal)tempMap.get("OUT_BATCH_ID");
							inputMap.put("batchId", bdBatchId.toString());
							_LOGGER.info("batch id back from vac2: " + bdBatchId.toString());
							inputString = new StringBuffer(varCharLimit);
							inputRows = 0;
						}
						inputString.append(detailVacString);
						inputRows ++;
					}
	
					SPCreateCalcDetail sp = new SPCreateCalcDetail(getDataSource());
					inputMap.put("vacString", inputString.toString());
					inputMap.put("inputRows", String.valueOf(inputRows));
					inputMap.put("moreInd", "N");  // a N means this is the last call
					returnMap=sp.executeStoredProcedure(inputMap);

			}catch(Exception e){
				_LOGGER.error("createCalcDetail - failed::"+e.getMessage());
				e.printStackTrace();
				throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
			}
			_LOGGER.info("Exiting createCalcDetail");
			return returnMap;
		}
	       public Map getActTaxes(Object inputMap)throws NCASException{
	            _LOGGER.info("Entering getActTaxes");
	            Map returnMap = null;
	            try{
	                ((Map)inputMap).put("APP_USER_ID", NCASBOSIConstants.VAM_USER_ID);
	                ((Map)inputMap).put("DEBUG_LEVEL", NCASBOSIConstants.VAM_DEBUG_LEVEL);
	                returnMap = new SPGetActTaxes(getVAMDataSource()).executeStoredProcedure(inputMap);
	            }catch(Exception ex){
	                _LOGGER.info("getActTaxes - failed::"+ex.getMessage());
	                ex.printStackTrace();
	                throw new NCASException("AC1001",AutoCreditDAOImpl.class,ex);
	            }
	            _LOGGER.info("Exiting getActTaxes");
	            return returnMap;
	        }
	       
	       public Map getUsageDropDown(Object dropdownField)throws NCASException{
	            _LOGGER.info("Entering getUsageDropDown");
	            Map returnMap = null;
	            try{
	                SPGetUsageDropDown sp = new SPGetUsageDropDown(getVAMDataSource());
	                returnMap = sp.executeStoredProcedure(NCASBOSIConstants.VAM_USER_ID, NCASBOSIConstants.VAM_DEBUG_LEVEL, (String)dropdownField);
	            }catch(Exception e){
	                _LOGGER.error("getUsageDropDown - failed::"+e.getMessage());
	                e.printStackTrace();
	                throw new NCASException("AC1001",AutoCreditDAOImpl.class,e);
	            }
	            _LOGGER.info("Exiting getUsageDropDown");
	            return returnMap;
	        } 

	   	/**
	   	 * Method inserts One View/R2 log into DB. table - OBDS_OV_AUDIT
	   	 * @author v898809  
	   	 */

	       public void logOneViewR2Details(Object input) throws NCASException {

			int insCount = 0;
			_LOGGER.info("Entering logOneViewR2Details");
			Map inputMap=(Map)input;
			String sysid = (String) inputMap.get("SYS_ID");
			String punchForm = (String) inputMap.get("PUNCH_FORM");
			
			_LOGGER.info("SYSTEM ID==" + sysid);
			_LOGGER.info("=PUNCH FORM=" + punchForm);

			_LOGGER.info("Insert SQL: " + NCASBOSIConstants.WS_LOG_INSERT_SQL);
			_LOGGER.info("ONEVIEW_R2_ACTION: " + NCASBOSIConstants.ONEVIEW_R2_ACTION);
			_LOGGER.info("LAST_UPDATED_BY: " + NCASBOSIConstants.ONEVIEW_R2_USER);

			insCount = jdbcTemplate.update(NCASBOSIConstants.WS_LOG_INSERT_SQL, new Object[] {
					NCASBOSIConstants.ONEVIEW_R2_ACTION, sysid, punchForm, " ", " ",
					NCASBOSIConstants.ONEVIEW_R2_USER });

			if (insCount > 0) {
				_LOGGER.info("One View / R2 Response logged successfully \n Number of Records logged "+ insCount);
			}
			_LOGGER.info("Exiting logOneViewR2Details");
		}
	     
		
	    
	   	//VALIDATE_NASP_ID
	   	public Map validateNaspId(Object input)throws NCASException{
			_LOGGER.info("Entering validateNaspId");
			Map returnMap = null;
			try{
				returnMap = new SPValidateNASPID(getDataSource()).executeStoredProcedure(input);
			}catch(Exception validateException){
				 _LOGGER.error("validateNaspId - failed::"+validateException.getMessage());
				 validateException.printStackTrace();
				 throw new NCASException("AC1001",AutoCreditDAOImpl.class,validateException);
			}
			_LOGGER.info("Exiting validateNaspId");
			return returnMap;
		}
	       
	   	//GET_DUP_ADJ_DTLS
	    public Map getDupeClaimAdjs(Object input) throws NCASException {
	    	_LOGGER.info("Entering getDupeClaimAdjs");
			Map returnMap = null;
			try{
				returnMap = new SPGetDupeClaimAdjs(getDataSource()).executeStoredProcedure(input);
			}catch(Exception getDupeException){
				 _LOGGER.error("getDupeClaimAdjs - failed::"+getDupeException.getMessage());
				 getDupeException.printStackTrace();
				 throw new NCASException("AC1001",AutoCreditDAOImpl.class,getDupeException);
			}
			_LOGGER.info("Exiting getDupeClaimAdjs");
			return returnMap;
	    }
	    
	    //CALC_ACT_ADJS - override duplicate
	    public Map calcAdjs_OverrideDuplicate(Object input) throws NCASException {
	    	_LOGGER.info("Entering calcAdjs_OverrideDuplicate");
			Map returnMap = null;
			try{
				returnMap = new SPCalcActAdjs(getDataSource()).executeStoredProcedure_OverrideDuplicate(input);
			}catch(Exception calcAdjsException){
				 _LOGGER.error("calcAdjs_OverrideDuplicate - failed::"+calcAdjsException.getMessage());
				 calcAdjsException.printStackTrace();
				 throw new NCASException("AC1001",AutoCreditDAOImpl.class,calcAdjsException);
			}
			_LOGGER.info("Exiting calcAdjs_OverrideDuplicate");
			return returnMap;	    	
	    }
	    
	  //CALC_LATEDISC_ADJS - override duplicate
	    public Map calcLateDiscoAdjs_OverrideDuplicate(Object input) throws NCASException {
	    	_LOGGER.info("Entering calcLateDiscoAdjs_OverrideDuplicate");
			Map returnMap = null;
			try{
				returnMap = new SPCalcLateDiscAdjustments(getDataSource()).executeStoredProcedure_OverrideDuplicate(input);
			}catch(Exception calcAdjsException){
				 _LOGGER.error("calcLateDiscoAdjs_OverrideDuplicate - failed::"+calcAdjsException.getMessage());
				 calcAdjsException.printStackTrace();
				 throw new NCASException("AC1001",AutoCreditDAOImpl.class,calcAdjsException);
			}
			_LOGGER.info("Exiting calcLateDiscoAdjs_OverrideDuplicate");
			return returnMap;
	    }
}
