package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.vbif.AdjTktNonPor;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetIciAdjDataNonPorRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetIciAdjDataNonPorRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetIciAdjDataNonPorRowMapper::mapRow rowNum - " + rowNum);

		AdjTktNonPor adjTktNonPor = new AdjTktNonPor();

		String nonpAdjTotCr = commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_CR"), "#,###,###,##0.00;-#,###,##0.00");
		String nonpAdjTotDr = commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_DR"), "#,###,###,##0.00;-#,###,##0.00");
		String nonpAdjInt = commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_INT"), "#,###,###,##0.00;-#,###,##0.00");
		String nonpAdjTotNet = commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_NET"), "#,###,###,##0.00;-#,###,##0.00");
		Date dateAdjPosted = rs.getDate("DATE_ADJ_POSTED");
		String chkReq = rs.getString("CHECK_REQUIRED");

		if (CommonUtil.isNotNull(nonpAdjTotCr)) {
			adjTktNonPor.setNonpAdjTotCr(nonpAdjTotCr.trim());
		}
		if (CommonUtil.isNotNull(nonpAdjTotDr)) {
			adjTktNonPor.setNonpAdjTotDr(nonpAdjTotDr.trim());
		}
		if (CommonUtil.isNotNull(nonpAdjInt)) {
			adjTktNonPor.setNonpAdjInt(nonpAdjInt.trim());
		}
		if (CommonUtil.isNotNull(nonpAdjTotNet)) {
			adjTktNonPor.setNonpAdjTotNet(nonpAdjTotNet.trim());
		}
		if (dateAdjPosted != null) {
			adjTktNonPor.setDateAdjPosted(CommonUtil.getDisplayDateFromString(dateAdjPosted, "MM/dd/yyyy"));
		}
		if (CommonUtil.isNotNull(chkReq)) {
			adjTktNonPor.setChkReq(chkReq.trim());
		}
		
		//if nonpAdjTotCr OR nonpAdjTotDr are non zero then we have a non portal adjustment
		if ( nonpAdjTotCr.equalsIgnoreCase("0.00" ) && nonpAdjTotDr.equalsIgnoreCase("0.00"))  {
			adjTktNonPor.setShowNonPortal("N");
		} else {
			adjTktNonPor.setShowNonPortal("Y");			
		}
		return adjTktNonPor;
	}
}
