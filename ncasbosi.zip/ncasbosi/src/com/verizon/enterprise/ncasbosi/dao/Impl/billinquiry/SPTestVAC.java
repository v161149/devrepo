package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

public class SPTestVAC extends StoredProcedure implements NCASBOSIConstants
{
  static private final Logger _LOGGER = Logger.getLogger(SPGetBI.class);	
  public SPTestVAC(DataSource dataSource) 
  {
    super(dataSource, NCASBOSIConstants.SP_TEST_VAC);
    declareParameter(new SqlReturnResultSet("RESULT_SET", new RSMapper()));
    declareParameter(new SqlParameter("ESG_CLAIM_NUMBER", Types.DOUBLE));
    declareParameter(new SqlOutParameter("RETURN_CODE",Types.INTEGER));
    declareParameter(new SqlOutParameter("REASON_CODE",Types.CHAR));
    declareParameter(new SqlOutParameter("ERROR_TEXT",Types.VARCHAR));
    declareParameter(new SqlOutParameter("SP_SQLCODE",Types.INTEGER));
    declareParameter(new SqlOutParameter("SP_SQLTOKENS",Types.CHAR));
    declareParameter(new SqlOutParameter("SP_SQLSTATE",Types.CHAR));
    declareParameter(new SqlOutParameter("TOTAL_ROWS",Types.INTEGER));
    compile();
   }

  public Map execute(double trackingNum)
  {
   Map inputs = new HashMap();
   inputs.put("ESG_CLAIM_NUMBER", new Double(trackingNum));
   return super.execute(inputs);
  }
  
  public final class RSMapper implements RowMapper 
  {
	   	 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	  		Map myMap = new HashMap();
	    	myMap.put(rs.getMetaData().getColumnName(2), rs.getString(2));
	    	myMap.put(rs.getMetaData().getColumnName(3), rs.getString(3));
	        _LOGGER.info(rs.getString(2));
	       return myMap;
	    }
	    
	}

} //end SPGetBI
