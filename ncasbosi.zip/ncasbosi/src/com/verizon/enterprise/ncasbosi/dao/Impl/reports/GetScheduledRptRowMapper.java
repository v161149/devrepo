package com.verizon.enterprise.ncasbosi.dao.Impl.reports;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.reports.RptCntl;


public class GetScheduledRptRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetScheduledRptRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetScheduledRptRowMapper::mapRow rowNum - " + rowNum);

		RptCntl rptCntlItem = new RptCntl();

		rptCntlItem.setRptId(rs.getInt("RPT_ID"));
		rptCntlItem.setRptName(rs.getString("RPT_NAME"));
		rptCntlItem.setRptSubGroup(rs.getString("REPORT_SUB_GROUP"));	
		rptCntlItem.setInterPageId(rs.getInt("INTER_PAGE_ID"));
		rptCntlItem.setPageId(rs.getInt("PAGE_ID"));
		rptCntlItem.setPageSubset(rs.getString("PAGE_SUBSET"));
		return rptCntlItem;
	}
}


