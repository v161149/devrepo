package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.reports.RptEmail;

public class GetRptEmailDetResultSetRowMapper implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetRptEmailDetResultSetRowMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetRptEmailDetResultSetRowMapper::mapRow rowNum - " + rowNum);

		RptEmail rptEmailItem = new RptEmail();
        int rptExecId = rs.getInt("RPT_EXEC_MAIL_ID");
        int rptRequestId = rs.getInt("RPT_REQUEST_ID");                                      //RPT_REQUEST_ID
		String createdTimestamp = CommonUtil.getDisplayDateTimeEx(rs.getTimestamp("CREATED_TIMESTAMP"));          //CREATED_TIMESTAMP
		String templateName = rs.getString("EMAIL_TEMPLATE_NAME"); 												//EMAIL_TEMPLATE_NAME
		String emailAddr = rs.getString("EMAIL_ADDR");		
		String desc = rs.getString("DOWNLOAD_DESCRIPTION");	
		String name = rs.getString("RPT_NAME");	
		String sub = rs.getString("REPORT_SUB_GROUP");	
		String category = rs.getString("RPT_CATEGORY");
		String section = rs.getString("RPT_SECTION");
		String loginId = rs.getString("PORTAL_LOGIN_ID");
		int rptId = rs.getInt("RPT_ID");

		if (NCASDataUtil.isNotNull(sub)) sub = sub.trim();
		if (NCASDataUtil.isNotNull(name)) name = name.trim();
		if (NCASDataUtil.isNotNull(category)) category = category.trim();
		if (NCASDataUtil.isNotNull(section)) section = section.trim();
		

		if(sub!=null&&!sub.isEmpty())
			name += " - " + sub;
		
		if(String.valueOf(rptId).equals(NcasConstants.DEFFERED_DOWNLOAD_RPT_ID))
			name = desc;

        rptEmailItem.setRptExecMailId(rptExecId);
        rptEmailItem.setRptRequestId(rptRequestId);
		rptEmailItem.setCreatedTimestamp(createdTimestamp);
		rptEmailItem.setTemplateName(templateName);
		rptEmailItem.setEmailAddr(emailAddr);
		rptEmailItem.setName(name);
		rptEmailItem.setCategory(category);
		rptEmailItem.setSection(section);
		rptEmailItem.setCreatedTimestamp(createdTimestamp);
		rptEmailItem.setLoginId(loginId);
		rptEmailItem.setDesc(desc);
		
		return rptEmailItem;
	}
}
