package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

/**
 * @author v992473
 * This class is the resultset extractor for the vam SP: SERVICE_SECABS_V10
 * and is the callback class for SPDownloadSecabsAcctsByService.
 * This is used when downloading secabs accts by service
 * 
 */
public class DownloadSecabsAcctsByServiceRowMapperImpl implements ResultSetExtractor {
	
	private static final Logger _LOGGER = Logger.getLogger(DownloadSecabsAcctsByServiceRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadSecabsAcctsByServiceRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());						
		List<List<Cell>> profilesList = new ArrayList<List<Cell>>();
		List<Cell> summary = new ArrayList<Cell>();
		
			while(rs.next()) {
				summary = new ArrayList<Cell>();
				
				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String corpId = rs.getString("CORP_ID");				
				String banDan = rs.getString("BAN_DAN");											
				String billPeriod = rs.getString("BILL_PERIOD");
				String channelCode = rs.getString("CHANNEL_CODE");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");					
				String accountName = rs.getString("ACCT_NAME");
				                
				if(CommonUtil.isNotNull(enterpriseId)) {
					summary.add(new Cell(enterpriseId.trim()));
				}
				if(CommonUtil.isNotNull(corpId)) {
					summary.add(new Cell(corpId.trim()));
				}
				if(CommonUtil.isNotNull(banDan)) {
					summary.add(new Cell(banDan.trim()));
				}
				if(CommonUtil.isNotNull(systemAbbrv)) {
					summary.add(new Cell(systemAbbrv.trim()));
				}
				if(CommonUtil.isNotNull(accountName)) {
					summary.add(new Cell(accountName.trim()));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
					summary.add(new Cell(billPeriod.trim()));
				}
				if(CommonUtil.isNotNull(channelCode)) {
					summary.add(new Cell(channelCode.trim()));
				}												
				profilesList.add(summary);
			}
			_LOGGER.info("Exiting DownloadSecabsAcctsByServiceRowMapperImpl -> ");
			return profilesList;
	}
}


