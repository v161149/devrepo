package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.billinquiry.IBIDropDown;

public class SPGetIBIDropdowns  extends BaseStoredProcedure {
  static private final Logger _LOGGER = Logger.getLogger(SPGetIBIDropdowns.class);
  private static List spInOutList;

  static {
    _LOGGER.info("Static Init");
    spInOutList = new ArrayList();
    spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, new IBIDropdowns()});
    spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
    spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
    spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
  }

  public SPGetIBIDropdowns(DataSource dataSource) {
    super(dataSource, NCASBOSIConstants.SP_GET_IBI_DROPDOWN, spInOutList);
  }

  public Map executeStoredProcedure(Object paramValues) throws Exception {
    _LOGGER.info("Entering executeStoredProcedure for "+getStoredProcedureName());
    List paramValueList =(List)paramValues;
    _LOGGER.info("Exiting executeStoredProcedure for "+getStoredProcedureName());
    Map resMap = executeSP(paramValueList, false);
    _LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
    return resMap;
  }

  public static final class IBIDropdowns implements RowMapper {

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      IBIDropDown iBIDropDownObj = new IBIDropDown();
      if(rs != null) {
        iBIDropDownObj.setRegioncode(rs.getString("REGION_CD"));
        _LOGGER.info("REGION_CD = "+iBIDropDownObj.getRegioncode());
        iBIDropDownObj.setDropdownName(rs.getString("DROP_DOWN_NAME"));
        _LOGGER.info("DROP_DOWN_NAME = "+iBIDropDownObj.getDropdownName());
        iBIDropDownObj.setDropdownOption(rs.getString("DROP_DOWN_OPTION"));
        _LOGGER.info("DROP_DOWN_OPTION = "+iBIDropDownObj.getDropdownOption());
      }
      return iBIDropDownObj;
    }
  }
}
