package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

public class OneViewRespVO 
{
	private String action;
    private String trackingID;
    private String responseCode;
    private String responseMessage;
    private String requestXML;
    private String responseXML;
	
	public OneViewRespVO()
	{
		action= "";
	    trackingID= "";
	    responseCode="";
	    responseMessage="";
	    requestXML= "";
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}

	public String getRequestXML() {
		return requestXML;
	}

	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	public String toString()
	{
		return "Action="+action+",Tracking ID="+trackingID+", ResponseCode= "+responseCode+", ResponseMessage= "+responseMessage+" ,RequestXML= "+requestXML;
	}

	public String getResponseXML() {
		return responseXML;
	}

	public void setResponseXML(String responseXML) {
		this.responseXML = responseXML;
	}

}
