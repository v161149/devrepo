package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaAddress;
import com.verizon.enterprise.common.eMedia.EMediaConversionComments;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDlvryOptCommMeth;
import com.verizon.enterprise.common.eMedia.EMediaEnvISAGSRecInfo;
import com.verizon.enterprise.common.eMedia.EMediaKeyProfile;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaSrvcProviderInfo;
import com.verizon.enterprise.common.eMedia.EMediaSubscriber;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetEMediaProfileRowMapperImpl implements RowMapper
{
	static private final Logger logger = Logger.getLogger(GetEMediaProfileRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "GetEMediaProfileRowMapperImpl::mapRow()";

		logger.debug(METHOD_NAME + " ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		EMediaProfile profile = new EMediaProfile();

		try
		{
			String startDate = rs.getString("START_DATE");
			String bmConfigID = rs.getString("BM_CONFIG_ID");
			String configSubscriptionOid = (String) rs.getBigDecimal("CONFIG_SUBS_OID").toString();
			String configName = rs.getString("CONFIG_NAME");
			String configId = rs.getString("CONFIG_ID");
			String custAddr1 = rs.getString("CUST_ADDR_1");
			String custAddr2 = rs.getString("CUST_ADDR_2");
			String city = rs.getString("CUST_CITY");
			String state = rs.getString("CUST_STATE");
			String zipCode = rs.getString("CUST_ZIP");
			String country = rs.getString("CUST_COUNTRY");
			String addrType = rs.getString("CUST_ADDR_TYPE");
			String companyName = rs.getString("COMPANY_NAME");
			String custId = rs.getString("CUSTOMER_ID");
			String custType = rs.getString("CUSTOMER_TYPE");
			String divSub = rs.getString("DIVISION_SUBSID");
			String custContractID = rs.getString("CUST_CONTRACT_ID");
			String otherContactInfo1 = rs.getString("OTH_CONTACT_INFO_1");
			String otherContactInfo2 = rs.getString("OTH_CONTACT_INFO_2");
			String loa = rs.getString("LOA");
			String serviceProviderLocation = rs.getString("SERV_PVDR_LOC");
			int serviceProviderNumber = rs.getInt("SERV_PVDR_NBR");
			String lobIndicator = rs.getString("LOB_IND");
			String strTotalBillInvoiceAmount = rs.getString("TOT_BILL_INV_AMT");
			String gcsConvFlag = rs.getString("GCS_CONV_FLAG");
			String lbsConvFlag = rs.getString("LBS_CONV_FLAG");
			String ixplusConvFlag = rs.getString("IXPLUS_CONV_FLAG");
			String megaVoiceCnvFlag = rs.getString("MEGAVOICE_CNV_FLAG");
			String visionConvFlag = rs.getString("VISION_CONV_FLAG");
			String ibrsConvFlag = rs.getString("IBRS_CONV_FLAG");
			String millenConvFlag = rs.getString("MILLEN_CONV_FLAG");
			String singleViewConvFlag = rs.getString("SVIEW_CONV_FLAG");
			String winCnvrsnFlg = rs.getString("WIN_CONV_FLAG");
			String transSoftwarePkg = rs.getString("TRANS_SW_PKG");
			String platform1 = rs.getString("PLATFORM1");
			String platform2 = rs.getString("PLATFORM2");
			String busAppSoftwarePkg = rs.getString("BUS_APP_SW_PKG");
			String custSuppEdiTrans = rs.getString("CUST_SUPP_EDI_TRAN");
			String custSuppEdiVer = rs.getString("CUST_SUPP_EDI_VER");
			String flag811 = rs.getString("FILE_READY_EMAIL");
			String enterpriseId = rs.getString("ENTERPRISE_ID");
			String ediDelivOpt = rs.getString("EDI_DELIV_OPT");
			String dataGrpId = rs.getString("EFTP_DATA_GRP_ID");
			String eftpDataGrpName = rs.getString("EFTP_DATA_GRP_NAM");
			String eftpUserName = rs.getString("EFTP_USER_NAME");
			String eftpVbccUserId = rs.getString("EFTP_VBCC_USER_ID");
			String eftpUserPhone = rs.getString("EFTP_USER_PHONE");
			String eftpUserEMail = rs.getString("EFTP_USER_EMAIL");
			String eftpRevLoc = rs.getString("EFTP_REV_LOC");
			String eftpBillId = rs.getString("EFTP_BILL_ID");
			String eftpSegment = rs.getString("EFTP_SEGMENT");
			String eftpAppAction = rs.getString("EFTP_APP_ACTION");
			String commMethod = rs.getString("COMM_METHOD");
			String vanName = rs.getString("VAN_NAME");
			String ediEnvironment = rs.getString("EDI_ENVIRONMENT");
			String prodIsaRcvrQual = rs.getString("PROD_ISA_RCVR_QUAL");
			String prodIsaRcvrId = rs.getString("PROD_ISA_RCVR_ID");
			String prodGsRcvrId = rs.getString("PROD_GS_RCVR_ID");
			String testIsaRcvrQual = rs.getString("TEST_ISA_RCVR_QUAL");
			String testIsaRcvrId = rs.getString("TEST_ISA_RCVR_ID");
			String testGsRcvrId = rs.getString("TEST_GS_RCVR_ID");
			String asciiEbcdicFlag = rs.getString("ASCII_EBCDIC_FLAG");
			String prodSegTerm = rs.getString("PROD_SEG_TERM");
			String prodElementSeparator = rs.getString("PROD_ELE_SEP");
			String prodSubElementSeparator = rs.getString("PROD_SUB_ELE_SEP");
			String testSegTerminator = rs.getString("TEST_SEG_TERM");
			String testElementSeparator = rs.getString("TEST_ELE_SEP");
			String testSubElementSeparator = rs.getString("TEST_SUB_ELE_SEP");
			String EDI864 = rs.getString("EDI_864");
			String serviceType = rs.getString("SERVICE_TYPE");
			String requestType = rs.getString("REQUEST_TYPE");
			String profileStatus = rs.getString("PROF_STATUS");
			String profileStatusComments = rs.getString("PROF_STATUS_COMM");
			String distributionName = rs.getString("DISTRBUTION_NAME");
			String commEdiCustIndicator = rs.getString("COMM_EDI_CUST_IND");
			String softwareVersion = rs.getString("SOFTWARE_VER");
			String mediaOpt = rs.getString("MEDIA_OPT");
			String ddDelivOpt = rs.getString("DD_DELIV_OPT");
			String sFTPMailboxId = rs.getString("SFTP_MAILBOX_ID");
			String sFTPMailboxName = rs.getString("SFTP_MAILBOX_NAME");
			String userName = rs.getString("EXT_UPDT_USR_NAME");// - Char(80)
			String userId = rs.getString("EXT_UPDT_USR_ID");// - Char(30)
			String profileComplete = rs.getString("PROFILE_COMPLETE");// -
			String subscriberName = rs.getString("SUBSCRIBER_NAME");
			String nationalInd = rs.getString("CONFIG_NATL_IND"); // - Char(1)
			String natBillPay = rs.getString("NAT_BILL_PAY"); // Char(1)
			String mailInd = rs.getString("MAIL_IND"); // Char(1)
			String overnightMailOpt = rs.getString("OVERNIGHT_MAIL_OPT");// Char(1)
			String databasePW = rs.getString("DATBASE_PW"); // Char(7)
			String cdChargeWaiver = rs.getString("BM_CD_CHG_WAIVER"); // Char(1)
			String billPeriod = rs.getString("BP_DAY");
			String origSystemId = rs.getString("ORIG_SYSTEM_ID");
			String comment = rs.getString("PROFILE_COMMENT");// VARCHAR(500)
			String cdChargeAcct = rs.getString("BM_CD_CHG_ACCT");// VARCHAR
			String callDetailInd = rs.getString("CALL_DETAIL_IND");
			String perspectiveInd = rs.getString("PERSPECT_EXT_IND");
			String bicCode = rs.getString("BIC");
			String guduns = rs.getString("GUDUNS");
			String secabsDeliveryOption = rs.getString("SECABS_DELIV_OPT");
			String ipAddress = rs.getString("IP_ADDRESS");
			String ndmUserId = rs.getString("NDM_USER_ID");
			String ndmPassword = rs.getString("NDM_PASSWORD");
			String sftpHostname = rs.getString("SFTP_HOSTNAME");
			String sftpDestDir = rs.getString("SFTP_DEST_DIR");
			String sftpPassword = rs.getString("SFTP_PASSWORD");
			String outputDSN = rs.getString("OUTPUT_DSN");
			String industry = rs.getString("INDUSTRY");
			String send997Email = rs.getString("SEND_997_EMAIL");
			String sFtpZip = rs.getString("SFTP_ZIP");
			String bmCallDetailInd = rs.getString("BM_CALL_DETAIL_IND");
			String bpOverride = rs.getString("BP_OVERRIDE");
			String verifiedFlag = rs.getString("VERIFIED_FLAG");
			String smpContractId = rs.getString("SMP_CONTRACT_ID");
			String smpContractOid = (String) rs.getBigDecimal("SB_CONTRACT_OID").toString();
			String acna = rs.getString("ACNA");
			//vallabh added for pb accounts
			String primebillerCnvrsnFlg = rs.getString("PB_CONV_FLAG");
			String usPrimebillerCnvrsnFlg = rs.getString("US_PB_CONV_FLAG");
			String vbeCnvrsnFlg = rs.getString("VBE_CONV_FLAG");
			
			EMediaKeyProfile profileKey = new EMediaKeyProfile();
			profile.setStartDate(CommonUtil.getDateFromString(startDate));
			profileKey.setConfigSubscriptionOid(Double.parseDouble(configSubscriptionOid));

			if (CommonUtil.isNotNull(configId)) {
				profileKey.setConfigID(configId.trim());
			}
			if (CommonUtil.isNotNull(configName)) {
				profileKey.setConfigName(configName.trim());
			}
			if (CommonUtil.isNotNull(bmConfigID)) {
				profileKey.setBmConfigID(bmConfigID.trim());
			}

			EMediaAddress custAddr = new EMediaAddress();

			if (CommonUtil.isNotNull(custAddr1)) {
				custAddr.setAddress1(custAddr1.trim());
			}
			if (CommonUtil.isNotNull(custAddr2)) {
				custAddr.setAddress2(custAddr2.trim());
			}
			if (CommonUtil.isNotNull(city)) {
				custAddr.setCity(city.trim());
			}
			if (CommonUtil.isNotNull(state)) {
				custAddr.setState(state.trim());
			}
			if (CommonUtil.isNotNull(zipCode)) {
				custAddr.setZip(zipCode.trim());
			}
			if (CommonUtil.isNotNull(country)) {
				custAddr.setCountry(country.trim());
			}
			if (CommonUtil.isNotNull(addrType)) {
				custAddr.setAddTypeInd(addrType.trim());
			}

			EMediaCustInfo custInfo = new EMediaCustInfo();

			if (CommonUtil.isNotNull(companyName)) {
				custInfo.setCustCpnyName(companyName.trim());
			}
			if (CommonUtil.isNotNull(custId)) {
				custInfo.setCustId(custId.trim());
			}
			if (CommonUtil.isNotNull(custType)) {
				custInfo.setCustType(custType.trim());
			}
			if (CommonUtil.isNotNull(divSub)) {
				custInfo.setDivSub(divSub.trim());
			}
			if (CommonUtil.isNotNull(custContractID)) {
				custInfo.setCustContractId(custContractID.trim());
			}
			if (CommonUtil.isNotNull(otherContactInfo1)) {
				custInfo.setOtherContactInfo1(otherContactInfo1.trim());
			}
			if (CommonUtil.isNotNull(otherContactInfo2)) {
				custInfo.setOtherContactInfo2(otherContactInfo2.trim());
			}
			if (CommonUtil.isNotNull(industry)) {
				custInfo.setIndustry(industry.trim());
			}

			custInfo.setAddress(custAddr);

			EMediaAddress serviceProviderAddr = new EMediaAddress();
			EMediaSrvcProviderInfo serviceProviderInfo = new EMediaSrvcProviderInfo();

			serviceProviderInfo.setProviderNumber(serviceProviderNumber);

			if (CommonUtil.isNotNull(loa)) {
				serviceProviderInfo.setLoa(loa.trim());
			}
			if (CommonUtil.isNotNull(serviceProviderLocation)) {
				serviceProviderInfo.setProviderLoc(serviceProviderLocation
						.trim());
			}

			serviceProviderInfo.setAddress(serviceProviderAddr);

			EMediaAcctTeamInfo acctTeamInfo = new EMediaAcctTeamInfo();

			if (CommonUtil.isNotNull(lobIndicator)) {
				acctTeamInfo.setLob(lobIndicator.trim());
			}
			if (strTotalBillInvoiceAmount != null && strTotalBillInvoiceAmount.trim().length() > 0) {
				double totalBillInvoiceAmount = Double.parseDouble(strTotalBillInvoiceAmount);
				acctTeamInfo.setTotalMnthBillAmt(totalBillInvoiceAmount);
			}

			EMediaConversionComments conversionComments = new EMediaConversionComments();

			if (CommonUtil.isNotNull(gcsConvFlag)) {
				conversionComments.setGcsCnvrsnFlg(gcsConvFlag.trim());
			}
			if (CommonUtil.isNotNull(lbsConvFlag)) {
				conversionComments.setLbsCnvrsnFlg(lbsConvFlag.trim());
			}
			if (CommonUtil.isNotNull(ixplusConvFlag)) {
				conversionComments.setIxPlusCnvrsnFlg(ixplusConvFlag.trim());
			}
			if (CommonUtil.isNotNull(megaVoiceCnvFlag)) {
				conversionComments.setMegaVoiceCnfrCnvrsnFlg(megaVoiceCnvFlag.trim());
			}
			if (CommonUtil.isNotNull(visionConvFlag)) {
				conversionComments.setVisionCnvrsnFlg(visionConvFlag.trim());
			}
			if (CommonUtil.isNotNull(ibrsConvFlag)) {
				conversionComments.setIbrsCnvrsnFlg(ibrsConvFlag.trim());
			}
			if (CommonUtil.isNotNull(millenConvFlag)) {
				conversionComments.setMillenCnvrsnFlg(millenConvFlag.trim());
			}
			if (CommonUtil.isNotNull(singleViewConvFlag)) {
				conversionComments.setSingleViewCnvrsnFlg(singleViewConvFlag.trim());
			}
			if (CommonUtil.isNotNull(winCnvrsnFlg)) {
				conversionComments.setWinCnvrsnFlg(winCnvrsnFlg);
			}
			if (CommonUtil.isNotNull(primebillerCnvrsnFlg)) {
				conversionComments.setPrimebillerCnvrsnFlg(primebillerCnvrsnFlg);
			}
			if (CommonUtil.isNotNull(usPrimebillerCnvrsnFlg)) {
				conversionComments.setUsPrimebillerCnvrsnFlg(usPrimebillerCnvrsnFlg);
			}
			if (CommonUtil.isNotNull(vbeCnvrsnFlg)) {
				conversionComments.setVbeCnvrsnFlg(vbeCnvrsnFlg);
			}


			EMediaTransDetailInfo transInfo = new EMediaTransDetailInfo();

			if (CommonUtil.isNotNull(transSoftwarePkg)) {
				transInfo.setTransSoftPackage(transSoftwarePkg.trim());
			}
			if (CommonUtil.isNotNull(platform1)) {
				transInfo.setPlatform1(platform1.trim());
			}
			if (CommonUtil.isNotNull(platform2)) {
				transInfo.setPlatform2(platform2.trim());
			}
			if (CommonUtil.isNotNull(busAppSoftwarePkg)) {
				transInfo.setBsnsSoftPackage(busAppSoftwarePkg.trim());
			}
			if (CommonUtil.isNotNull(custSuppEdiTrans)) {
				transInfo.setCustSuppTrans(custSuppEdiTrans.trim());
			}
			if (CommonUtil.isNotNull(custSuppEdiVer)) {
				transInfo.setCustSuppVers(custSuppEdiVer.trim());
			}
			if (CommonUtil.isNotNull(flag811)) {
				transInfo.setFlag811(flag811.trim());
			}
			if (CommonUtil.isNotNull(enterpriseId)) {
				transInfo.setEnterpriseID(enterpriseId.trim());
			}
			if (CommonUtil.isNotNull(send997Email)) {
				transInfo.setSend997email(send997Email.trim());
			}

			EMediaDlvryOptCommMeth dlvryInfo = new EMediaDlvryOptCommMeth();

			if (CommonUtil.isNotNull(ediDelivOpt)) {
				dlvryInfo.setDelOptCommMeth(ediDelivOpt.trim());
			}
			if (CommonUtil.isNotNull(dataGrpId)) {
				dlvryInfo.setDataGrpID(dataGrpId.trim());
			}
			if (CommonUtil.isNotNull(eftpDataGrpName)) {
				dlvryInfo.setDataGrpName(eftpDataGrpName.trim());
			}
			if (CommonUtil.isNotNull(eftpUserName)) {
				dlvryInfo.setUserName(eftpUserName.trim());
			}
			if (CommonUtil.isNotNull(eftpVbccUserId)) {
				dlvryInfo.setUserID(eftpVbccUserId.trim());
			}
			if (CommonUtil.isNotNull(eftpUserPhone)) {
				dlvryInfo.setPhoneNum(eftpUserPhone.trim());
			}
			if (CommonUtil.isNotNull(eftpUserEMail)) {
				dlvryInfo.setEmailID(eftpUserEMail.trim());
			}
			if (CommonUtil.isNotNull(eftpRevLoc)) {
				dlvryInfo.setRevLOC(eftpRevLoc.trim());
			}
			if (CommonUtil.isNotNull(eftpBillId)) {
				dlvryInfo.setBillCorpID(eftpBillId.trim());
			}
			if (CommonUtil.isNotNull(eftpSegment)) {
				dlvryInfo.setSegment(eftpSegment.trim());
			}
			if (CommonUtil.isNotNull(eftpAppAction)) {
				dlvryInfo.setAppAction(eftpAppAction.trim());
			}
			if (CommonUtil.isNotNull(commMethod)) {
				dlvryInfo.setCommMethod2(commMethod.trim());
			}
			if (CommonUtil.isNotNull(vanName)) {
				dlvryInfo.setVanName(vanName.trim());
			}
			if (CommonUtil.isNotNull(sFtpZip)) {
				dlvryInfo.setSFtpZip(sFtpZip.trim());
			}

			EMediaEnvISAGSRecInfo envInfo = new EMediaEnvISAGSRecInfo();

			if (CommonUtil.isNotNull(ediEnvironment)) {
				envInfo.setEnvironment(ediEnvironment.trim());
			}
			if (CommonUtil.isNotNull(prodIsaRcvrQual)) {
				envInfo.setProdISARecQlfr(prodIsaRcvrQual.trim());
			}
			if (CommonUtil.isNotNull(prodIsaRcvrId)) {
				envInfo.setProdISARecID(prodIsaRcvrId.trim());
			}
			if (CommonUtil.isNotNull(prodGsRcvrId)) {
				envInfo.setProdGSRecID(prodGsRcvrId.trim());
			}
			if (CommonUtil.isNotNull(testIsaRcvrQual)) {
				envInfo.setTestISARecQlfr(testIsaRcvrQual.trim());
			}
			if (CommonUtil.isNotNull(testIsaRcvrId)) {
				envInfo.setTestISARecID(testIsaRcvrId.trim());
			}
			if (CommonUtil.isNotNull(testGsRcvrId)) {
				envInfo.setTestGSRecID(testGsRcvrId.trim());
			}
			if (CommonUtil.isNotNull(asciiEbcdicFlag)) {
				envInfo.setAsciiEBCDICFlag(asciiEbcdicFlag.trim());
			}
			if (CommonUtil.isNotNull(prodSegTerm)) {
				envInfo.setProdSegTermntr(prodSegTerm.trim());
			}
			if (CommonUtil.isNotNull(prodElementSeparator)) {
				envInfo.setProdEleTermntr(prodElementSeparator.trim());
			}
			if (CommonUtil.isNotNull(prodSubElementSeparator)) {
				envInfo.setProdSubElesprtr(prodSubElementSeparator.trim());
			}
			if (CommonUtil.isNotNull(testSegTerminator)) {
				envInfo.setTestSegTermntr(testSegTerminator.trim());
			}
			if (CommonUtil.isNotNull(testElementSeparator)) {
				envInfo.setTestEleTermntr(testElementSeparator.trim());
			}
			if (CommonUtil.isNotNull(testSubElementSeparator)) {
				envInfo.setTestSubElesprtr(testSubElementSeparator.trim());
			}
			if (CommonUtil.isNotNull(EDI864)) {
				envInfo.setEdi864(EDI864.trim());
			}

			EMediaSubscriber subscriber = new EMediaSubscriber();

			if (CommonUtil.isNotNull(subscriberName)) {
				subscriber.setSubscriberName(subscriberName.trim());
			}
			if (CommonUtil.isNotNull(bicCode)) {
				subscriber.setBusinessIdentifierCode(bicCode.trim());
			}
			if (CommonUtil.isNotNull(guduns)) {
				subscriber.setGuduns(guduns.trim());
			}
			if(CommonUtil.isNotNull(verifiedFlag)) {
				subscriber.setConfigVerFlag(verifiedFlag.trim());
			}

			subscriber.setSubscriberOid(CommonUtil.convertStringFromDouble(rs.getDouble("SUBSCRIBER_OID")));

			if (CommonUtil.isNotNull(serviceType)) {
				profile.setServiceType(serviceType.trim());
			}
			if (CommonUtil.isNotNull(requestType)) {
				profile.setRequestType(requestType.trim());
			}
			if (CommonUtil.isNotNull(profileStatusComments)) {
				profile.setProfStatusComnts(profileStatusComments.trim());
			}
			if (CommonUtil.isNotNull(profileStatus)) {
				profile.setProfileStatus(profileStatus.trim());
			}
			if (CommonUtil.isNotNull(distributionName)) {
				profile.setDistName(distributionName.trim());
			}
			if (CommonUtil.isNotNull(commEdiCustIndicator)) {
				profile.setCustIndicator(commEdiCustIndicator.trim());
			}
			if (CommonUtil.isNotNull(softwareVersion)) {
				profile.setSoftwareVersion(softwareVersion.trim());
			}
			if (CommonUtil.isNotNull(mediaOpt)) {
				profile.setMediaOpt(mediaOpt.trim());
			}
			if (CommonUtil.isNotNull(ddDelivOpt)) {
				profile.setDdDeliveryOpt(ddDelivOpt.trim());
			}
			if (CommonUtil.isNotNull(sFTPMailboxId)) {
				profile.setSFtpMailboxId(sFTPMailboxId.trim());
			}
			if (CommonUtil.isNotNull(sFTPMailboxName)) {
				profile.setSFtpMailboxName(sFTPMailboxName.trim());
			}
			if (CommonUtil.isNotNull(profileComplete)) {
				profile.setProfComplete(profileComplete.trim());
			}
			if (CommonUtil.isNotNull(nationalInd)) {
				profile.setNationalInd(nationalInd.trim());
			}
			if (CommonUtil.isNotNull(natBillPay)) {
				profile.setNatBillPay(natBillPay.trim());
			}
			if (CommonUtil.isNotNull(mailInd)) {
				profile.setMailInd(mailInd.trim());
			}
			if (CommonUtil.isNotNull(overnightMailOpt)){
				profile.setOvernightMailOpt(overnightMailOpt);
			}
			if (CommonUtil.isNotNull(databasePW)) {
				profile.setDatabasePW(databasePW.trim());
			}
			if (CommonUtil.isNotNull(cdChargeWaiver)) {
				profile.setCdChargeWaiver(cdChargeWaiver.trim());
			}
			if (CommonUtil.isNotNull(billPeriod)) {
				profile.setBillPeriod(billPeriod.trim());
			}
			if (CommonUtil.isNotNull(origSystemId)) {
				profile.setOrigSystemId(origSystemId.trim());
			}
			if (CommonUtil.isNotNull(userName)) {
				profile.setUserName(userName.trim());
			}
			if (CommonUtil.isNotNull(userId)) {
				profile.setUserId(userId.trim());
			}
			if (CommonUtil.isNotNull(comment)) {
				profile.setComments(comment.trim());
			}
			if(CommonUtil.isNotNull(cdChargeAcct)) {
				profile.setCdChargeAcct(cdChargeAcct.trim());
			}
			if(CommonUtil.isNotNull(callDetailInd)) {
				profile.setCallDetailInd(callDetailInd.trim());
			}
			if(CommonUtil.isNotNull(perspectiveInd)) {
				profile.setPerspectiveInd(perspectiveInd.trim());
			}
			if (CommonUtil.isNotNull(bmCallDetailInd)) {
				profile.setBmCallDetSumInd(bmCallDetailInd.trim());
			}
			if (CommonUtil.isNotNull(bpOverride)) {
				profile.setBpOverRideInd(bpOverride.trim());
			}
			if(CommonUtil.isNotNull(secabsDeliveryOption)) {
				profile.setSecabsDeliveryOption(secabsDeliveryOption.trim());
			}
			if(CommonUtil.isNotNull(ipAddress)) {
				profile.setIpAddress(ipAddress.trim());
			}
			if(CommonUtil.isNotNull(ndmUserId)) {
				profile.setNdmUserId(ndmUserId.trim());
			}
			if(CommonUtil.isNotNull(ndmPassword)) {
				profile.setNdmPassword(ndmPassword.trim());
			}
			if(CommonUtil.isNotNull(sftpHostname)) {
				profile.setSftpHostname(sftpHostname.trim());
			}
			if(CommonUtil.isNotNull(sftpDestDir)) {
				profile.setSftpDestDir(sftpDestDir.trim());
			}
			if(CommonUtil.isNotNull(sftpPassword)) {
				profile.setSftpPassword(sftpPassword.trim());
			}
			if(CommonUtil.isNotNull(outputDSN)) {
				profile.setOutputDSN(outputDSN.trim());
			}

			profile.setHoldDays(rs.getInt("HOLD_DAYS"));
			profile.setDtCreated(rs.getDate("DATE_CREATED"));
			profile.setEndDate(rs.getDate("END_DATE"));
			profile.setModDtTime(rs.getTimestamp("UPDATE_TIMESTAMP"));
			profile.setLastConfigBillDate(rs.getString("LAST_BILL_DATE"));
			profile.setConfigRecordsProcessedCount(rs.getInt("CONFIG_REC_CNT"));
			profile.setLastChargeBillDate(rs.getString("CHARGE_DATE"));
			profile.setBmCDChargeAccount(rs.getString("BM_CD_CHG_ACCT"));

			if (CommonUtil.isNotNull(smpContractId))
			{
				if (smpContractId.trim().length()== 0) {
					profile.setSmpContractId("N/A");
				} else {
					profile.setSmpContractId(smpContractId.trim());
				}
			} else {
				profile.setSmpContractId("N/A");
			}

			if (CommonUtil.isNotNull(smpContractOid))
			{
				profile.setSmpContractOid(smpContractOid.trim());
			}

			profile.setProfileKey(profileKey);
			profile.setCustInfo(custInfo);
			profile.setSrvcProviderInfo(serviceProviderInfo);
			profile.setAcctTeamInfo(acctTeamInfo);
			profile.setConversionComments(conversionComments);
			profile.setTransDetailInfo(transInfo);
			profile.setDlvryOptCommMeth(dlvryInfo);
			profile.setEnvISAGSRecInfo(envInfo);
			profile.setSubscriber(subscriber);
			if(CommonUtil.isNotNull(acna)) {
				profile.setAcna(acna.trim());
			}			
		}
		catch (NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.info(METHOD_NAME + " Exception occured while parsing the resultset \n" + nfe.getMessage());
			logger.error(METHOD_NAME + " Exception occured while parsing the resultset \n" + nfe.getMessage());
		}

		logger.debug(METHOD_NAME + " profile=" + profile);
		logger.debug(METHOD_NAME + " EXIT");

		return profile;
	}
}
