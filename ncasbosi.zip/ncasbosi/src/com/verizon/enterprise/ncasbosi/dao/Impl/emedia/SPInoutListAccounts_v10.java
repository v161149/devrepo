package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;

/**
 * @author v992473
 * This class has the declaration list of input and output params common for the following apis(except a single param difference)
 * SUMMARY_GCP_V10,CORP_GCP_V10,SERVICE_GCP_V10 
 */

public class SPInoutListAccounts_v10 {
	
	/**
	 * @param mapperImplObject
	 * @return the list of in/out params matching the api structure(without row mapper object)
	 * 
	 */
	
	private static List<Object[]> getInoutListAccount_v10_WithoutMapper(Object mapperImplObject_spApi){	 
		 List<Object[]> spInOutList = new ArrayList<Object[]>();	
		 
		 spInOutList.add(new Object[]{"APP_USER_ID", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 if((mapperImplObject_spApi instanceof String && NCASBOSIConstants.SP_GET_GCP_ACCTS_BY_SUBSCRIPTION.equalsIgnoreCase((String)mapperImplObject_spApi)) ||
			 mapperImplObject_spApi instanceof GetGCPAccountsBySubscriptionRowMapperImpl || mapperImplObject_spApi instanceof DownloadGCPAccountsBySubscriptionRowMapperImpl	 
		 	){
			 //SERVICE_ID for the SERVICE_GCP_V10
			 spInOutList.add(new Object[]{"SERVICE_ID", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 }else{
			 //CUST_NO and CUSTOMER_TYPE for the SUMMARY_GCP_V10,CORP_GCP_V10
			 spInOutList.add(new Object[]{"CUST_NO", BaseStoredProcedure.getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"CUSTOMER_TYPE", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 }
		 
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", BaseStoredProcedure.getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_PHRASE", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", BaseStoredProcedure.getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", BaseStoredProcedure.getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAGE_OFFSET", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", BaseStoredProcedure.getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", BaseStoredProcedure.getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 return spInOutList;
	}
	
	
	/**
	 * @param mapperImplObject
	 * @return the list of in/out params(along with mapper object) that is cached in the SP class 
	 */
	public static List<Object[]> getInoutListForAccount_v10(ResultSetExtractor mapperImplObject){
		List<Object[]> inOutList = new ArrayList<Object[]>();
		inOutList.add(new Object[]{"accounts", BaseStoredProcedure.getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,mapperImplObject});
		inOutList.addAll(getInoutListAccount_v10_WithoutMapper(mapperImplObject));
		return inOutList;
	}

	/**
	 * @param storedProcedureApi
	 * @return the list of in/out params(no mapper) that is cached in the SP class
	 * This is used when you dont need mapper object to run through the resultsets
	 */
	public static List<Object[]> getInoutListForAccount_v10(String storedProcedureApi){
		List<Object[]> inOutList = new ArrayList<Object[]>();
		inOutList.addAll(getInoutListAccount_v10_WithoutMapper(storedProcedureApi));
		return inOutList;
	}
}
