package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.reports.RptCustUser;

public class GetCustomRptUser implements RowMapper
{
	static private final Logger _LOGGER = Logger.getLogger(GetCustomRptUser.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		_LOGGER.debug("Inside GetCustomRptMetaResultSetRowMapper::mapRow rowNum - " + rowNum);

		RptCustUser customRpt = new RptCustUser();
		customRpt.setRptCustUser(rs.getInt("RPT_ID"),rs.getString("PORTAL_LOGIN_ID"),
				rs.getDouble("USER_OID"),rs.getDouble("ECPD_ID"),rs.getString("SHARE_IND"),"");
		
		_LOGGER.debug(customRpt.toString());
		return customRpt;
	}
}
