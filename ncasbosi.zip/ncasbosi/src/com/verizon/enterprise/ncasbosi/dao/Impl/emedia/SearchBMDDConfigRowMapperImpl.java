package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class SearchBMDDConfigRowMapperImpl implements RowMapper {
	static private final Logger _LOGGER = Logger.getLogger(SearchBMDDConfigRowMapperImpl.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.info("Inside SearchBMDDConfigRowMapperImpl::mapRow rowNumber -> " + rowNum);
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		String companyName = rs.getString("COMPANY_NAME");
		String customerId = rs.getString("CUSTOMER_ID");
		
		EMediaProfile profile = new EMediaProfile();
		EMediaCustInfo custInfo = new EMediaCustInfo();
		
		if(CommonUtil.isNotNull(companyName)) {
			custInfo.setCustCpnyName(companyName.trim());
		}
		if(CommonUtil.isNotNull(customerId)) {
			custInfo.setCustId(customerId.trim());
		}
		
		profile.setCustInfo(custInfo);
		
		
		_LOGGER.info("SearchBMDDConfigRowMapperImpl's profile ==> " + profile);
		return profile;
	}
}
