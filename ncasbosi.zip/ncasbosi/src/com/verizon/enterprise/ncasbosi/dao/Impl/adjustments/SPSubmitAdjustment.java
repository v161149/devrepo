package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPSubmitAdjustment extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPSubmitAdjustment.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"INPUT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INPUT_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADJ_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATING_SYS_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CHANNEL_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIBER_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ERATE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_AMOUNT", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_TAX", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEXT_APPROV_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEXT_APPROV_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MANAGER_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MANAGER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DIRECTOR_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DIRECTOR_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VP_VZID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VP_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WORKGROUP_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WORKGROUP_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DESCRIPTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROOT_CAUSE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION_TAKEN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CORRECTIVE_ACTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANSACTION_NOTE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"VAC_TRANSACTION_ID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"TX_CATEGORY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEXT_APPROV_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEXT_APPROV_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEXT_APPROV_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEXT_APPROV_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MANAGER_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MANAGER_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MANAGER_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MANAGER_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DIRECTOR_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DIRECTOR_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DIRECTOR_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DIRECTOR_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VP_FIRST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VP_LAST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VP_MID_IN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VP_SUFF", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ESG_CLAIM_NBR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_INTEREST", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPSubmitAdjustment(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SUBMIT_ADJUSTMENT, spInOutList);
	}

	public Map executeStoredProcedure(Map inputMap, String debugLevel)throws Exception	{
		//input param debugLevel is not used, its to differentiate the exectueStoreProcedure method defined here
		String inputString = (String) inputMap.get("INPUT_STRING");
		String inputRows = (String) inputMap.get("INPUT_ROWS");
		String adjustmentStatus = (String) inputMap.get("ADJ_STATUS");
		String ban = (String) inputMap.get("BAN");
		String osid = (String) inputMap.get("ORIGINATING_SYS_ID");
		String channelCode = (String) inputMap.get("CHANNEL_CODE");
		String subscriberId = (String) inputMap.get("SUBSCRIBER_ID");
		String erateFlag = (String) inputMap.get("ERATE_FLAG");
		BigDecimal transactionAmount = new BigDecimal((String) inputMap.get("TRANS_AMOUNT")).setScale(2);
		BigDecimal transactionTax = new BigDecimal((String) inputMap.get("TRANS_TAX")).setScale(2);
		String transactionStatus = (String) inputMap.get("TRANS_STATUS");
		String originatorLoginId = (String) inputMap.get("ORIGINATOR_LOGINID");
		String originatorVzid = (String) inputMap.get("ORIGINATOR_VZID");
		String originatorName = (String) inputMap.get("ORIGINATOR_NAME");
		String nextApproverVzid = (String) inputMap.get("NEXT_APPROV_VZID");
		String nextApproverName = (String) inputMap.get("NEXT_APPROV_NAME");
		String managerVzid = (String) inputMap.get("MANAGER_VZID");
		String managerName = (String) inputMap.get("MANAGER_NAME");
		String directorVzid = (String) inputMap.get("DIRECTOR_VZID");
		String directorName = (String) inputMap.get("DIRECTOR_NAME");
		String vpVzid= (String) inputMap.get("VP_VZID");
		String vpName = (String) inputMap.get("VP_NAME");
		String workgroupId = (String) inputMap.get("WORKGROUP_ID");
		String workgroupName = (String) inputMap.get("WORKGROUP_NAME");
		String description = (String) inputMap.get("DESCRIPTION");
		String rootCause = (String) inputMap.get("ROOT_CAUSE");
		String actionTaken = (String) inputMap.get("ACTION_TAKEN");
		String correctiveAction= (String) inputMap.get("CORRECTIVE_ACTION");
		String transactionNote = (String) inputMap.get("TRANSACTION_NOTE");
		String transactionCategory = (String) inputMap.get("TX_CATEGORY");
		String originatorFirstName = (String) inputMap.get("ORIGINATOR_FIRST");
		String originatorLastName = (String) inputMap.get("ORIGINATOR_LAST");
		String originatorMiddleInitial = (String) inputMap.get("ORIGINATOR_MID_IN");
		String originatorSuffix = (String) inputMap.get("ORIGINATOR_SUFF");
		String nextApproverFirstName = (String) inputMap.get("NEXT_APPROV_FIRST");
		String nextApproverLastName = (String) inputMap.get("NEXT_APPROV_LAST");
		String nextApproverMiddleInitial = (String) inputMap.get("NEXT_APPROV_MID_IN");
		String nextApproverSuffix = (String) inputMap.get("NEXT_APPROV_SUFF");
		String managerFirstName = (String) inputMap.get("MANAGER_FIRST");
		String managerLastName = (String) inputMap.get("MANAGER_LAST");
		String managerMiddleInitial = (String) inputMap.get("MANAGER_MID_IN");
		String managerSuffix = (String) inputMap.get("MANAGER_SUFF");
		String directorFirstName = (String) inputMap.get("DIRECTOR_FIRST");
		String directorLastName = (String) inputMap.get("DIRECTOR_LAST");
		String directorMiddleInitial = (String) inputMap.get("DIRECTOR_MID_IN");
		String directorSuffix = (String) inputMap.get("DIRECTOR_SUFF");
		String vpFirstName = (String) inputMap.get("VP_FIRST");
		String vpLastName = (String) inputMap.get("VP_LAST");
		String vpMiddleInitial = (String) inputMap.get("VP_MID_IN");
		String vpSuffix = (String) inputMap.get("VP_SUFF");
		String esgClaimNumber = (String) inputMap.get("ESG_CLAIM_NBR");
		BigDecimal transactionInterest = new BigDecimal((String) inputMap.get("TRANS_INTEREST")).setScale(2);

		List paramValueList = new ArrayList();
		paramValueList.add(inputString);//INPUT_STRING
		paramValueList.add(inputRows);//INPUT_ROWS
		paramValueList.add(adjustmentStatus); //ADJ_STATUS
		paramValueList.add(ban); //BAN
		paramValueList.add(osid); //ORIGINATING_SYS_ID
		paramValueList.add(channelCode); //CHANNEL_CODE
		paramValueList.add(subscriberId); //SUBSCRIBER_ID
		paramValueList.add(erateFlag); //ERATE_FLAG
		paramValueList.add(transactionAmount); //TRANS_AMOUNT
		paramValueList.add(transactionTax); //TRANS_TAX
		paramValueList.add(transactionStatus); //TRANS_STATUS
		paramValueList.add(originatorLoginId); //ORIGINATOR_LOGINID
		paramValueList.add(originatorVzid); //ORIGINATOR_VZID
		paramValueList.add(originatorName); //ORIGINATOR_NAME
		paramValueList.add(nextApproverVzid); //NEXT_APPROV_VZID
		paramValueList.add(nextApproverName); //NEXT_APPROV_NAME
		paramValueList.add(managerVzid); //MANAGER_VZID
		paramValueList.add(managerName); //MANAGER_NAME
		paramValueList.add(directorVzid); //DIRECTOR_VZID
		paramValueList.add(directorName); //DIRECTOR_NAME
		paramValueList.add(vpVzid); //VP_VZID
		paramValueList.add(vpName); //VP_NAME
		paramValueList.add(workgroupId); //WORKGROUP_ID
		paramValueList.add(workgroupName); //WORKGROUP_NAME
		paramValueList.add(description); //DESCRIPTION
		paramValueList.add(rootCause); //ROOT_CAUSE
		paramValueList.add(actionTaken); //ACTION_TAKEN
		paramValueList.add(correctiveAction); //CORRECTIVE_ACTION
		paramValueList.add(transactionNote); //TRANSACTION_NOTE
		paramValueList.add(transactionCategory); //TX_CATEGORY
		paramValueList.add(originatorFirstName); //ORIGINATOR_FIRST
		paramValueList.add(originatorLastName); //ORIGINATOR_LAST
		paramValueList.add(originatorMiddleInitial); //ORIGINATOR_MID_IN
		paramValueList.add(originatorSuffix); //ORIGINATOR_SUFF
		paramValueList.add(nextApproverFirstName); //NEXT_APPROV_FIRST
		paramValueList.add(nextApproverLastName); //NEXT_APPROV_LAST
		paramValueList.add(nextApproverMiddleInitial); //NEXT_APPROV_MID_IN
		paramValueList.add(nextApproverSuffix); //NEXT_APPROV_SUFF
		paramValueList.add(managerFirstName); //MANAGER_FIRST
		paramValueList.add(managerLastName); //MANAGER_LAST
		paramValueList.add(managerMiddleInitial); //MANAGER_MID_IN
		paramValueList.add(managerSuffix); //MANAGER_SUFF
		paramValueList.add(directorFirstName); //DIRECTOR_FIRST
		paramValueList.add(directorLastName); //DIRECTOR_LAST
		paramValueList.add(directorMiddleInitial); //DIRECTOR_MID_IN
		paramValueList.add(directorSuffix); //DIRECTOR_SUFF
		paramValueList.add(vpFirstName); //VP_FIRST
		paramValueList.add(vpLastName); //VP_LAST
		paramValueList.add(vpMiddleInitial); //VP_MID_IN
		paramValueList.add(vpSuffix); //VP_SUFF
		paramValueList.add(esgClaimNumber); //ESG_CLAIM_NBR
		paramValueList.add(transactionInterest); //TRANS_INTEREST

		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
