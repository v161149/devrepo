package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.Clob;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.common.status.CurrentReports;
import com.verizon.enterprise.common.status.ListDetails;


public class SPGetAccountsFromList extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetAccountsFromList.class);
	
	private static List spInOutList;
	
	private static GetAccountsFromListRowMapperImpl rowMapper;
	
	static
	{
		rowMapper = new GetAccountsFromListRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCT_LIST_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCT_LIST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});		 
		 spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPGetAccountsFromList(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_ACCT_LIST, spInOutList);	
	}

	public Map executeStoredProcedure(String userId, String debugLevel, 
			String userOid,String acctListType, String acctListName,String sortOrder,
			String tokenSt,Pagination pagination)throws Exception
	{
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		StringBuffer myParam = new StringBuffer();
		myParam.append("MyParam=");
		paramValueList.add(userId);//APP_USER_ID
		myParam.append("userId:" +userId+"^");
		
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		myParam.append("debugLevel:"+debugLevel+"^");
		
		paramValueList.add(userOid);		// USER_OID
		myParam.append("userOid:"+ userOid+"^");
		paramValueList.add(acctListType);	// ACCT_LIST_TYPE
		myParam.append("acctListType:"+ acctListType+"^");
		paramValueList.add(acctListName);	// ACCT_LIST_NAME
		myParam.append("acctListName:"+acctListName+"^");
		
		
		if(sortOrder == null || sortOrder.equals("")) {
			paramValueList.add("");//SORT_ORDER
		} else {
			paramValueList.add(sortOrder);//SORT_ORDER
		}
		myParam.append("sortOrder:"+sortOrder+"^");
		paramValueList.add(tokenSt);	// TOKEN_ST
		myParam.append("tokenSt:"+tokenSt+"^");

		String lineOffSet = pagination.getPageOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}
		
		paramValueList.add(lineOffSet);//LINE_OFFSET
		myParam.append("lineOffSet:"+lineOffSet+"^");
		paramValueList.add(pageSize);//PAGE_SIZE
		myParam.append("pageSize:"+pageSize+"^");

		 
		_LOGGER.debug(myParam.toString());
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		//pagination.updateCurrPageNum();
		Integer rowcountrStr = (Integer)procMap.get("TOTAL_ROWS");
		
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		
		Map actualList = (Map)procMap.get("accounts");
		pagination.setResultSize(Integer.toString(actualList.size()));
		
		ListDetails object = (ListDetails) actualList.get("listDetails");
		
		//System.out.println(object.toString());
		
		object.setPageOffset(Integer.parseInt(lineOffSet));
		object.setPageSize(Integer.parseInt(pageSize));
		object.setTotalRows(rowcountrStr.intValue());

		
		resultMap.put("recordsMap", (ListDetails) object);
		resultMap.put("procMap", procMap);

		return resultMap ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
