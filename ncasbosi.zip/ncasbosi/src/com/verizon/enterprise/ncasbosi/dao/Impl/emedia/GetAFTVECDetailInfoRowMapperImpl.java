package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAFTVECReportInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAFTVECDetailInfoRowMapperImpl implements RowMapper{
	static private final Logger _LOGGER = Logger.getLogger(GetAFTVECDetailInfoRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetAFTVECDetailInfoRowMapperImpl::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		EMediaAFTVECReportInfo aftDetailInfo = new EMediaAFTVECReportInfo();

		try {
			//Set the values
			String requestNumber = rs.getString("REQUEST_NO");
			String man = rs.getString("MAN");
			String ban = rs.getString("BAN");
			String aban = rs.getString("ABAN");
			String osid = rs.getString("OSID");
			String accountNumber = rs.getString("ACCOUNT");
			String accountStatus = rs.getString("ACCOUNT_STATUS");
			int lob = rs.getInt("LOB");
			int channelCode = rs.getInt("CHANNEL_CD");
			double subscriptionOid = rs.getDouble("SUBSCRIPTION_OID");
			String entitlementStatus = rs.getString("VEC_ENTITLE_STATUS");
			String userId = rs.getString("VEC_USER_ID");
			String emailId = rs.getString("VEC_USER_EMAIL");
			String userIdStatus = rs.getString("VEC_USER_STATUS");
			String userName = rs.getString("VEC_USER_NAME");
			String companyName = rs.getString("VEC_COMPANY_NAME");
			String entitlementType = rs.getString("ENTITLEMENT_TYPE");
			double permissionGroupOid = rs.getDouble("PERM_GROUP_OID");
			String permissionGroupSubscriberName = rs.getString("PERM_GRP_SUB_NAME");
			String errorCode = rs.getString("ERROR_CODE");
			String errorDescription = rs.getString("ERROR_TEXT");

			if(CommonUtil.isNotNull(requestNumber)) {
				aftDetailInfo.setRequestNumber(requestNumber.trim());
			}
			if(CommonUtil.isNotNull(man)) {
				aftDetailInfo.setMan(man.trim());
			}
			if(CommonUtil.isNotNull(ban)) {
				aftDetailInfo.setBan(ban.trim());
			}
			if(CommonUtil.isNotNull(aban)) {
				aftDetailInfo.setAban(aban.trim());
			}
			if(CommonUtil.isNotNull(osid)) {
				aftDetailInfo.setOsid(osid.trim());
			}
			if(CommonUtil.isNotNull(accountNumber)) {
				aftDetailInfo.setAccountNumber(accountNumber.trim());
			}
			if(CommonUtil.isNotNull(accountStatus)) {
				aftDetailInfo.setAccountStatus(accountStatus.trim());
			}
			aftDetailInfo.setLob(String.valueOf(lob));
			aftDetailInfo.setChannelCode(String.valueOf(channelCode));
			aftDetailInfo.setSubscriptionOid(String.valueOf(subscriptionOid));
			if(CommonUtil.isNotNull(entitlementStatus)) {
				aftDetailInfo.setEntitlementStatus(entitlementStatus.trim());
			}
			if(CommonUtil.isNotNull(userId)) {
				aftDetailInfo.setUserId(userId.trim());
			}
			if(CommonUtil.isNotNull(emailId)) {
				aftDetailInfo.setEmail(emailId.trim());
			}
			if(CommonUtil.isNotNull(userIdStatus)) {
				aftDetailInfo.setUserIdStatus(userIdStatus.trim());
			}
			if(CommonUtil.isNotNull(userName)) {
				aftDetailInfo.setUserName(userName.trim());
			}
			if(CommonUtil.isNotNull(companyName)) {
				aftDetailInfo.setCompanyName(companyName.trim());
			}
			if(CommonUtil.isNotNull(entitlementType)) {
				aftDetailInfo.setEntitlementType(entitlementType.trim());
			}
			aftDetailInfo.setPermissionGroupOid(String.valueOf(permissionGroupOid));
			if(CommonUtil.isNotNull(permissionGroupSubscriberName)) {
				aftDetailInfo.setPermissionGroupSubscriberName(permissionGroupSubscriberName.trim());
			}
			if(CommonUtil.isNotNull(errorCode)) {
				aftDetailInfo.setErrorCode(errorCode.trim());
			}
			if(CommonUtil.isNotNull(errorDescription)) {
				aftDetailInfo.setErrorDescription(errorDescription.trim());
			}
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ e.getMessage());
		}
		_LOGGER.debug("aftDetailInfo ^^ " + aftDetailInfo);
		return aftDetailInfo;
	}

}
