package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.BatchData;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetBatchDataResultSetMapper implements RowMapper {
	
	/*
	 * added worklist fields for VBE/PB Feb/2012 PVB
	 */

	static private final Logger _LOGGER = Logger.getLogger(GetBatchDataResultSetMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetBatchDataResultSetMapper::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		BatchData batchData = new BatchData();
		
		String batchId = rs.getString("BATCH_ID");
		String ticketId = rs.getString("TICKET_ID");
		String serviceId = rs.getString("SERVICE_ID");
		String serviceIdType = rs.getString("SERVICE_ID_TYPE");

		Date fromDate = rs.getDate("FROM_DATE");
		String fromDateStr = CommonUtil.getDisplayDateFromString(fromDate,"MM/dd/yyyy");
		
		Date thruDate = rs.getDate("THRU_DATE");
		String thruDateStr = CommonUtil.getDisplayDateFromString(thruDate,"MM/dd/yyyy");

		String chargeCodeType = rs.getString("CHG_TYPE_CD");
		String sourceSysClaimId = rs.getString("SRC_SYS_CLM_ID");
		String creditMethod = rs.getString("CREDIT_METHOD");
		String batchStatus = rs.getString("BATCH_STATUS");
		String displayText = rs.getString("SVC_DISPLAY_TEXT");
		String account = rs.getString("ACCOUNT");	
		String worklistStatusDesc = rs.getString("WORKLIST_STATUS_DESCR");	
		String worklistStatusCode = rs.getString("WORKLIST_STATUS_CD");	
		
		
		if (CommonUtil.isNotNull(batchId)) {
			batchData.setBatchId(batchId.trim());
		}
		if (CommonUtil.isNotNull(ticketId)) {
			batchData.setTicketId(ticketId.trim());
		}
		if (CommonUtil.isNotNull(serviceId)) {
			batchData.setServiceId(serviceId.trim());
		}
		if (CommonUtil.isNotNull(serviceIdType)) {
			batchData.setServiceIdType(serviceIdType.trim());
		}
		if (CommonUtil.isNotNull(fromDateStr)) {
			batchData.setFromDate(fromDateStr.trim());
		}
		if (CommonUtil.isNotNull(thruDateStr)) {
			batchData.setThruDate(thruDateStr.trim());
		}
		if (CommonUtil.isNotNull(chargeCodeType)) {
			if (chargeCodeType.equalsIgnoreCase("M")) {
				chargeCodeType = "MRC";
			} else if (chargeCodeType.equalsIgnoreCase("N")) {
				chargeCodeType = "NRC";
			} else if (chargeCodeType.equalsIgnoreCase("T")) {
				chargeCodeType = "TAX";
			} else if (chargeCodeType.equalsIgnoreCase("L")) {
				chargeCodeType = "LPC";
			}
			batchData.setChargeTypeCode(chargeCodeType.trim());
		}
		if (CommonUtil.isNotNull(sourceSysClaimId)) {
			batchData.setSourceSysClaimId(sourceSysClaimId.trim());
		}
		if (CommonUtil.isNotNull(creditMethod)) {
			batchData.setCreditMethod(creditMethod.trim());
		}
		if(CommonUtil.isNotNull(batchStatus)){
			batchData.setBatchStatus(batchStatus.trim());
		}
		if (CommonUtil.isNotNull(displayText)) {
			batchData.setDisplayText(displayText.trim());
		}
		if (CommonUtil.isNotNull(account)) {
			batchData.setAccount(account.trim());
		}		
		if (CommonUtil.isNotNull(worklistStatusDesc)) {
			batchData.setWorklistStatusDesc(worklistStatusDesc.trim());
		}		
		if (CommonUtil.isNotNull(worklistStatusCode)) {
			batchData.setWorklistStatusCode(worklistStatusCode.trim());
		}		
		
		
		return batchData;
	}
}
