package com.verizon.enterprise.ncasbosi.dao.Impl.usagerepository;

import java.sql.ResultSet;import java.sql.SQLException;import org.apache.log4j.Logger;import org.springframework.jdbc.core.RowMapper;import com.verizon.enterprise.common.ncas.usagerepository.UrUsageDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetUsageMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetUsageMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetClientViewDateListMapper - Mapping Row# "+rowNum);
		UrUsageDO usageDO = null;		String origTerm = null;
		if(rs!=null){
			usageDO = new UrUsageDO();						usageDO.setOrigNbr((String)rs.getString("ORIG_NUMBER"));			usageDO.setTermNbr((String)rs.getString("TERM_NUMBER"));			usageDO.setDate((String)rs.getString("CALL_DATE"));			usageDO.setTime((String)rs.getString("CONNECT_TIME"));			usageDO.setDuration((String)rs.getString("CALL_MINUTES") + ":" +  (String)rs.getString("CALL_SECONDS"));			origTerm = ((String)rs.getString("ORIG_TERM"));			usageDO.setCallType((String)rs.getString("CALL_TYPE"));			//if call dated after 2005-04-01 update the orig term from number to letter. 1 is for Term, 0 is for Orig, before the date the indicator was no set.			if ("2005-04-01".compareTo(usageDO.getDate()) < 0)			{				if ("1".equals(origTerm))				{					usageDO.setOrigTerm("T");				}				else if ("G".equals(origTerm))  //grinich mean time
				{
					usageDO.setOrigTerm("G");
				}
				else				{					usageDO.setOrigTerm("O");				}			}			else			{				usageDO.setOrigTerm(" ");			}			
		}
		return usageDO;
	}
}
