package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.custom.CLink;
import com.verizon.enterprise.common.ncas.display.BillViewPagination;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.display.CellWork;
import com.verizon.enterprise.common.ncas.display.CellBase;
import com.verizon.enterprise.common.ncas.display.CellHeader;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.common.ncas.display.Navigation;
import com.verizon.enterprise.common.ncas.display.PageCache;
import com.verizon.enterprise.common.ncas.display.PageView;
import com.verizon.enterprise.common.ncas.display.SearchResult;
import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.reports.RptAudit;
import com.verizon.enterprise.common.ncas.vbif.TicketUpdate;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.dao.Impl.reports.ReportsUIProcessor;
import com.verizon.enterprise.dataobjects.Structure;
/**
 * @author V238591
 *
 */
public class SPBillView extends BaseStoredProcedure {
		static private final Logger _LOGGER = Logger.getLogger(SPBillView.class);
		private static List spInOutList;
		private static GetBreadCrumbRowMapperImpl bCrumbrowMapper;
		private static GetLeftNavRowMapperImpl leftNavrowMapper;
		private static GetHeaderRowMapperImpl headerrowMapper;
		private static GetContentRowMapperImpl contentrowMapper;
		private static GetLinkedObjectRowMapperImpl linkObjectrowMapper;

		public SPBillView(DataSource dataSource, String schemaName, String storedProcName)
		{
			super(dataSource, schemaName + "." + storedProcName, spInOutList);
		}

		static
		{
			 spInOutList = new ArrayList();
			 bCrumbrowMapper = new GetBreadCrumbRowMapperImpl();
			 leftNavrowMapper = new GetLeftNavRowMapperImpl();
			 headerrowMapper = new GetHeaderRowMapperImpl();
			 contentrowMapper = new GetContentRowMapperImpl();
			 linkObjectrowMapper = new GetLinkedObjectRowMapperImpl();

			 spInOutList.add(new Object[]{"breadcrumb",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,bCrumbrowMapper});
			 spInOutList.add(new Object[]{"leftnav",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,leftNavrowMapper});
			 spInOutList.add(new Object[]{"header",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,headerrowMapper});
			 spInOutList.add(new Object[]{"tables",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,contentrowMapper});
			 spInOutList.add(new Object[]{"linkobject",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,linkObjectrowMapper});

			 spInOutList.add(new Object[]{"PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"LINK_PARAMS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"FILTER_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"SORT_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"PAGE_SUBSET", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

			 spInOutList.add(new Object[]{"BEGIN_ROW", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"SCROLL_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

			 spInOutList.add(new Object[]{"EMPLOYEE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"PORTAL_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"MISC", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

			 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PAGE_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PAGE_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});


			 spInOutList.add(new Object[]{"TABLE_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_1_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_2_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_3_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_4_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_5_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_6_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_7_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_8_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_9_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_10_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_11_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"TBL_12_TITLE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PARENT_PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"PAGINATE_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"STRUCTURE_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"STRUCTURE_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"POSITION_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"POSITION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
			 spInOutList.add(new Object[]{"CHANNEL_CD_LIST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"ALIAS_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"MATCH_FOUND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"BILL_FOUND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
			 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"FIND_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
			 spInOutList.add(new Object[]{"IMP_LOGIN_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		}




		public Map executeStoredProcedure(String userId, String debugLevel, Map params) throws Exception
		{
			String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
			List paramValueList = new ArrayList();
			Map returnMap = new HashMap();
			boolean errorFlg = false;

			PageCache page = (PageCache) params.get("PAGE");
			String employeeFlag  = (String) params.get("EMPLFLAG");
			String portalUserID  = (String) params.get("LOGIND");
			String userOid = (String) params.get("USEROID");
			String portalInd = (String)params.get("PORTAL");
			Boolean isAdmin = (Boolean)params.get("ISADMIN");
			List userPermissions = (List)params.get("USER_PERM");
			Structure struct = (Structure)params.get("STRUCTURE");
			
			
			String misc = page.getMisc();
			String action = page.getAction();
			Link linkObject = page.getLink();
			BillViewPagination pagination = page.getPagination();


			if(linkObject.getAuditAction().equals("RPT_AUDIT"))
				addAuditInfo(linkObject,portalUserID,userOid);


			if (action.equals("") || action.length() == 0) {
				action = "O";
			}

		    String downloadType = page.getDownloadType();

			paramValueList.add(linkObject.getPageId().trim());    //PAGE_ID
			paramValueList.add(linkObject.getLinkParam()); //LINK_PARAMS
			String filterString = linkObject.getFilterString();
			String searchString = linkObject.getSearchString();
			String sortString = linkObject.getSortString();
			if(filterString == null) {
				filterString = "";
			}
			if(sortString == null) {
				sortString = "";
			}
			if(searchString == null) {
				searchString = "";
			}

			paramValueList.add(filterString);//FILTER_STRING
			paramValueList.add(sortString);  //SORT_STRING
			paramValueList.add(linkObject.getPageSubset());//PAGE_SUBSET
			int lineOffSet = pagination.getLineOffset();
			int pageSize = pagination.getItemsPerPage();
			if (pagination.isSelectAll()) {
				lineOffSet = 1;
				pageSize = pagination.getRowCount();
			}


			paramValueList.add(lineOffSet); //LINE_OFFSET
			paramValueList.add(pageSize);   //PAGE_SIZE

			paramValueList.add(userId);     //APP_USER_ID
			paramValueList.add(debugLevel); //DEBUG_LEVEL

			paramValueList.add(employeeFlag); //EMPLOYEE_FLAG
			paramValueList.add(portalUserID); //PORTAL_USER_ID
			paramValueList.add(misc);  //MISC
			paramValueList.add(action);//ACTION
			
			addStructureValues(paramValueList,struct,employeeFlag);

			paramValueList.add("");  //CHANNEL_CD_LIST in (not used)
			String aliasFlag = (String) params.get("ALIAS_FLAG");
			if(aliasFlag==null||(aliasFlag!=null&&aliasFlag.equals("")))
				aliasFlag = "N";
			paramValueList.add(aliasFlag);  //ALIAS_FLAG in

			String lang = (String)params.get("LANG");
			if(lang==null||(lang!=null&&lang.trim().equals("")))
				lang=NcasConstants.LANG_CODE_US_ENGLISH_VAM;
			paramValueList.add(lang);
			paramValueList.add(searchString);//FIND_STRING
			String impLoginID = (String)params.get("IMPLOGIND");
			if(impLoginID == null)
				impLoginID = "";
			paramValueList.add(impLoginID);//IMP_LOGIN_ID

			Map procMap = executeStoredProcedure(paramValueList);

			int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
			String debugStr = (String)procMap.get("MSG_STRING");
			if (debugStr == null) {
			    debugStr = "";
			}
			if( returnCode > 0 ) {
				errorFlg = true;
				if(returnCode == 2) {
					returnMap.put("RETURNCODE", "2");
				  returnMap.put("RETURNMSG", debugStr.trim());
				} else{
                    _LOGGER.error("In executeStoredProcedure - debugStr = " + debugStr);
					String[] errMsg = new String[3];
				    errMsg[0] = "getBillView";
				    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_BILL_VIEW;
				    errMsg[2] = debugStr;
				    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
				}
			}

			boolean isDownload = false;
			if (action.equalsIgnoreCase("D")) {
				isDownload = true;
			}

			Navigation bcrumb = (Navigation)procMap.get("breadcrumb");
			Navigation leftNav = (Navigation)procMap.get("leftnav");
			Content header = (Content)procMap.get("header");
			Content tables = (Content)procMap.get("tables");
			Map linkMap = (LinkedHashMap)procMap.get("linkobject");
			String pageTitle = (String)procMap.get("PAGE_TITLE");

			Navigation newLeftNav = populateLeftNav(leftNav, userPermissions, portalInd, isAdmin.booleanValue());
			Content newHeader = populateContent(header,linkMap);
			Content newTables =  populateTable(tables,linkMap, isDownload);

			//Pagination on table
			Integer allcountrStr = (Integer)procMap.get("TOTAL_ROWS");
			Integer rowcountrStr = (Integer)procMap.get("PAGE_ROWS");
			Integer beginRow = (Integer)procMap.get("BEGIN_ROW");
			Integer tableCount = (Integer)procMap.get("TABLE_COUNT");
			String paginate_flag = (String)procMap.get("PAGINATE_FLAG");
			if(paginate_flag!=null && paginate_flag.equalsIgnoreCase("N"))
				pagination.setPaginate(false);


			if(!searchString.isEmpty()&&!errorFlg)
				  pagination.updateCurrentPageFromServer(allcountrStr, rowcountrStr,beginRow+1) ;
			else  pagination.updateCurrentPageFromServer(allcountrStr, rowcountrStr,0) ;


//			linkObject.setSearchString("");
			newHeader.setLink(linkObject);
			newTables.setLink(linkObject);
			newTables.setPagination(pagination);





			if(linkObject.getLinkParam().equals(""))
				linkObject.setLinkParam("  ");
			String tblName = "";
			int tableCountInt = tableCount.intValue();
			if(tableCountInt >= 1 && tableCountInt <= 12){
				List tabHeader = new ArrayList();
				for(int i=0;i<tableCountInt;i++){
					tblName = "TBL_"+ String.valueOf(i+1)+"_TITLE";
					tabHeader.add((String)procMap.get(tblName));
				}
				newTables.setTabHeaders(tabHeader);
			}
			if(action.equalsIgnoreCase("D")) {
 	      if (downloadType.equals("")) {
		  	  newTables =  populateDownload(newTables,newHeader);
		    } else {
		   	  newTables =  populateDownload2(newTables,newHeader);
		    }
			}

			if(bcrumb!=null && bcrumb.getCells()!=null && bcrumb.getCells().size()==0)
				bcrumb = null;
			if(newLeftNav!=null && newLeftNav.getCells()!=null && newLeftNav.getCells().size()==0)
				newLeftNav = null;
			if(newHeader!=null && newHeader.getRows()!=null && newHeader.getRows().size()==0)
				newHeader = null;
			if(newTables==null || ( newTables!=null && newTables.getRows()==null))
				newTables = null;

			/*if(newTables != null&&newTables.getColumns()!=null){
				int tableWidth = newTables.getTableWidth();
				redistributeTable(newTables.getColumns(),tableWidth,newTables.getColumns().size());
			}
			*/
			String parentPageID = ((Integer)procMap.get("PARENT_PAGE_ID")).toString();
			PageView pgView = new PageView(bcrumb,newLeftNav,newHeader,newTables,pageTitle, parentPageID);
			_LOGGER.debug("In SPBILLVIEW - Return pgView :: "+pgView);

			returnMap.put("PAGEVIEW", pgView);

			return returnMap;
		}






		private Content populateDownload(Content table, Content header) {
			Content newTable =  new Content();
			ArrayList newRows = new ArrayList();
			String valCell = "";
			newTable.setRows(newRows);
			ArrayList newCellList = null;
			int hdrDataSize = 0;

	
			
			ArrayList headerNameList = new ArrayList();
			ArrayList headerDataList = new ArrayList();
			if(header!=null){
				List rows_header = header.getRows();
				if(rows_header!=null){
					Iterator rowIter_header = rows_header.iterator() ;
					while (rowIter_header.hasNext()){
						valCell = "";
						List cellList_header = (List)rowIter_header.next();
						if(cellList_header != null){
							CellHeader headerCell = (CellHeader)cellList_header.get(0);
							hdrDataSize = headerDataList.size();
							if(!headerCell.getName().equals("")){
								headerNameList.add(new Cell(headerCell.getName()) );
								if (headerCell.getValue().isEmpty() && cellList_header.size() > 1) {
									CellHeader headerCell1 = (CellHeader)cellList_header.get(1);
									valCell = headerCell1.getValue();
								} else {
									valCell = headerCell.getValue();
								}
								headerDataList.add(new Cell(valCell));
							}else if(hdrDataSize> 0 && headerCell.getFormat().equalsIgnoreCase("HDR_AD_R")){								
								valCell = ((Cell)headerDataList.get(hdrDataSize-1)).getValue();
								headerDataList.set(hdrDataSize-1, new Cell(valCell +" "+headerCell.getValue()));
							}
						}
					}
				}
			}

			if(table!=null){
				List rows = table.getRows();
				if(rows!=null){
					Iterator rowIter = rows.iterator() ;
					newCellList = new ArrayList();
					newCellList.addAll(headerNameList);

					while (rowIter.hasNext()){

						List cellList = (List)rowIter.next();
						Iterator cellIter = cellList.iterator() ;
						boolean first = true;
						while (cellIter.hasNext()){
							Cell item = (Cell)cellIter.next();
							if(!item.getFormat().equals("TBL_TL")&& !item.getFormat().equals("TBL_GRAND_TL") && !item.getType().equals("LEGEND")){
								if(first&&!item.getFormat().equals("COL_HDR")){
									newCellList.addAll(headerDataList);
									first = false;
								}
								newCellList.add(item);
							}
						}
						//newCellList.addAll(cellList);
						newRows.add(newCellList);
						newCellList = new ArrayList();
					}
				}

			}
			return newTable;
	}
	private Content populateDownload2(Content table, Content header) {
	  Content newTable =  new Content();
	  ArrayList newRows = new ArrayList();
	  newTable.setRows(newRows);
	  ArrayList newCellList = null;

	  if (table!=null){
		List rows = table.getFooter();
		if (rows!=null){
		  Iterator rowIter = rows.iterator() ;
		  newCellList = new ArrayList();
		  while (rowIter.hasNext()){
			Cell cellItem = (Cell)rowIter.next();
			if (cellItem != null){
			  newCellList.add(cellItem);
			  newRows.add(newCellList);
			  newCellList = new ArrayList();
			}
		  }
		}
	  }
	  if (header!=null){
		List rows_header = header.getRows();
		if (rows_header!=null){
		  Iterator rowIter_header = rows_header.iterator();
		  newCellList = new ArrayList();
		  while (rowIter_header.hasNext()){
			List cellList_header = (List)rowIter_header.next();
			if (cellList_header != null){
  			  CellHeader headerCell = (CellHeader)cellList_header.get(0);
  			  newCellList.add(new Cell(headerCell.getName()));
  			  newCellList.add(new Cell(headerCell.getValue()));
			  newRows.add(newCellList);
			  newCellList = new ArrayList();
			}
		  }
		}
	  }
	  if(table!=null){
		List rows = table.getRows();
		if (rows!=null){
		  Iterator rowIter = rows.iterator() ;
		  newCellList = new ArrayList();
		  while (rowIter.hasNext()){
			List cellList = (List)rowIter.next();
			Iterator cellIter = cellList.iterator() ;
			while (cellIter.hasNext()){
			  Cell item = (Cell)cellIter.next();
			  if(!item.getFormat().equals("TBL_TL")&& !item.getFormat().equals("TBL_GRAND_TL") && !item.getType().equals("LEGEND")){
				newCellList.add(item);
			  }
			}
			newRows.add(newCellList);
			newCellList = new ArrayList();
 		  }
		}
	  }
	  return newTable;
	}

   private Navigation populateLeftNav(Navigation leftNav,
			List userPermissions, String portalInd, boolean isAdmin) throws Exception {
		Navigation newLeftNav = new Navigation();
		ArrayList newCellList = new ArrayList();
		newLeftNav.setCells(newCellList);
		String newFormat = null;
		String newName = null;
		String newValue = null;
		boolean overrideBoolean = false;

		if (leftNav != null) {
			List cellList = leftNav.getCells();
			if (cellList != null) {
				Iterator cellIter = cellList.iterator();
				while (cellIter.hasNext()) {
					CellBase element = (CellBase) cellIter.next();
					String lnkType = element.getLnkType();
					if (lnkType != null && lnkType.length() > 0) {
						if (!CommonUtil.linkHasExclusion(lnkType, portalInd, isAdmin)) {
							_LOGGER.debug("The link " + lnkType + "  for portal " + portalInd	+ " doesn't have exclusion.So displaying it");
							int currentLink = CommonUtil.getLinkKeyFromFormat(lnkType);
							int overrideLink = CommonUtil.linkHasOverride(currentLink, lnkType, portalInd);
							if (currentLink != overrideLink) {
								_LOGGER.debug("The link " + lnkType + "  for portal " + portalInd + " has an override.");
								// There is a override. So modify the CELL.
								CLink newCLink = CommonUtil.getCLinkFromKey(overrideLink);
								if (newCLink != null) {
									newName = newCLink.getName();
									newFormat = newCLink.getType();
									newValue = newCLink.getExtFunc();
									_LOGGER	.debug("The new link will have the name ->"	+ newName + " And the new format-> " + newFormat	+ " And the new javascript func->" + newValue);
									element.setName(newName);
									element.setFormat(newFormat);
									element.setLnkType(newValue);
									overrideBoolean = true;
									// Anything else that can be overriden
									// should be updated in the CELL as well.
								}
							}
							if (overrideBoolean)
								lnkType = newFormat;

							if (CommonUtil.userHasPermission(userPermissions,lnkType)) {
								_LOGGER.debug("The user has permission to view this link->" + lnkType);
								newCellList.add(element);
							}
							overrideBoolean = false;
						}
					} else {
						newCellList.add(element);
					}
				}
			}
		}
		return newLeftNav;
	}

        /*
         * header
         */
		private Content populateContent(Content header,Map linkMap)throws Exception
		{
			Content newHeader =  new Content();
			ArrayList newRows = new ArrayList();
			newHeader.setRows(newRows);
			ArrayList newCellList = null;

			if(header!=null && linkMap!=null){
				List rows = header.getRows();
				if(rows!=null){
					Iterator rowIter = rows.iterator() ;
					while (rowIter.hasNext()){
						List cellList = (List)rowIter.next();
						Iterator cellIter = cellList.iterator() ;
						newCellList = new ArrayList();
						while (cellIter.hasNext()){
							CellWork element = (CellWork)cellIter.next();
							if(!element.getName().equals("") || !element.getValue().equals("")){
								CellHeader ch = new CellHeader(element.getName(),element.getValue(), element.getToolTip(), element.getLink(),
										 element.getType(), element.getFormat(), element.getLnkType(), element.getSelectType(), element.getCurrencyCode());
								newCellList.add(ch);
								if(!element.getLinkKey().equals("0")){
									List linkList = (List)linkMap.get(element.getLinkKey());
									if(linkList!=null){
										Iterator linkIter = linkList.iterator() ;
										while (linkIter.hasNext()){
											Cell item = (Cell)linkIter.next();
											CellHeader ch1 = new CellHeader(item.getName(),item.getValue(), item.getToolTip(), item.getLink(),
													item.getType(), item.getFormat(), item.getLnkType(), item.getSelectType(), item.getCurrencyCode());
											newCellList.add(ch1);
										}
									}
								}
							}
						}
						if (newCellList.size() > 0) {
						  newRows.add(newCellList);
						}
					}
				}
			}
			return newHeader;
		}

	private Content populateTable(Content table, Map linkMap, boolean isDownload) throws Exception {
		Content newTable = new Content();
		ArrayList newRows = new ArrayList();
		newTable.setRows(newRows);
		ArrayList newCellList = null;
		ArrayList newFooter = new ArrayList();
		newTable.setFooter(newFooter);
		ArrayList newCellofCellsList = null;
		boolean bFirst = true;

		if (table != null && linkMap != null) {
			List rows = table.getRows();
			if (rows != null) {
				Iterator rowIter = rows.iterator();
				while (rowIter.hasNext()) {
					List cellList = (List) rowIter.next();
					Iterator cellIter = cellList.iterator();
					newCellList = new ArrayList();
					while (cellIter.hasNext()) {
						CellWork wrkElem = (CellWork) cellIter.next();
						Cell element = new Cell(
						wrkElem.getName(),wrkElem.getValue(), wrkElem.getToolTip(),
						wrkElem.getLink(),wrkElem.getType(), wrkElem.getFormat(),
						wrkElem.getLnkType(), wrkElem.getSelectType(),
						wrkElem.getCurrencyCode(),wrkElem.getSortAble(),wrkElem.getFilterAble(),
						wrkElem.getSelected(), wrkElem.getCells());
						element.setColIndex(wrkElem.getColIndex());
						List linkList = (List) linkMap.get(wrkElem.getLinkKey());
						if (linkList != null) {
							Iterator linkIter = linkList.iterator();
							bFirst = true;
							newCellofCellsList = new ArrayList();
							while (linkIter.hasNext()) {
								Cell item = (Cell) linkIter.next();
								if (bFirst) {
									element.setValue(CommonUtil.getFormattedDisplayValue(item.getType(), item.getFormat(), element.getName(), item.getCurrencyCode().trim(),isDownload));
									if (!item.getLnkType().equals("")) {
										element.setLink(item.getLink());
									}
									element.setFormat(item.getFormat());
									element.setType(item.getType());
									element.setToolTip(item.getToolTip());
									element.setLnkType(item.getLnkType());
									element.setName(item.getName());
									element.setFilterAble(item.getFilterAble());
									element.setSortAble(item.getSortAble());
								} else {
									Cell newCell = new Cell();
									newCell.setValue(CommonUtil.getFormattedDisplayValue(item.getType(), item.getFormat(), item.getValue(), item.getCurrencyCode().trim(),	isDownload));
									if (!item.getLnkType().equals("")) {
										newCell.setLink(item.getLink());
									}
									newCell.setFormat(item.getFormat());
									newCell.setType(item.getType());
									newCell.setToolTip(item.getToolTip());
									newCell.setLnkType(item.getLnkType());
									newCell.setName(item.getName());
									newCellofCellsList.add(newCell);
								}
								bFirst = false;
							} // end while
							if (element.getType().equals("LEGEND")) {
								newFooter.add(element);
							} else {
								if (!element.getType().equals("DOWNLOAD")
										|| (element.getType().equals("DOWNLOAD") && isDownload)) {
									if (newCellofCellsList.size() > 0) {
										element.setCells(newCellofCellsList);
									}
									newCellList.add(element);
								}
							}
						}
					}
					if (newCellList.size() > 0) {
						newRows.add(newCellList);
					}
				}
			}
		}
		return newTable;
	}

		public Map executeStoredProcedure(Object paramValues)throws Exception
		{
			List paramValueList = (List) paramValues;
			return executeSP(paramValueList, false);
		}

		public Map doSearch(String userId, String debugLevel, Map params) throws Exception
		{
			String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
			List paramValueList = new ArrayList();
			Map returnMap = new HashMap();

			String linkparam = (String) params.get("LINKPARAM");
			String employeeFlag  = (String) params.get("EMPLFLAG");
			String portalUserID  = (String) params.get("LOGIND");
			Structure struct = (Structure)params.get("STRUCTURE");
			String passthru = (String)params.get("PASSTHRU");


			paramValueList.add("45");    //PAGE_ID
			paramValueList.add(linkparam); //LINK_PARAMS
			paramValueList.add("");//FILTER_STRING
			paramValueList.add("");  //SORT_STRING
			paramValueList.add("ALL");//PAGE_SUBSET



			paramValueList.add("1"); //LINE_OFFSET
			paramValueList.add("50");   //PAGE_SIZE

			paramValueList.add(userId);     //APP_USER_ID
			paramValueList.add(debugLevel); //DEBUG_LEVEL

			paramValueList.add(employeeFlag); //EMPLOYEE_FLAG
			paramValueList.add(portalUserID); //PORTAL_USER_ID

			String misc = (String) params.get("MISC");
			if (misc == null) {
				misc = "";
			}
			paramValueList.add(misc);  //MISC
			paramValueList.add("O");//ACTION
			paramValueList.add(struct.getStructureType());    //STRUCTURE_TYPE inout
			paramValueList.add(struct.getStructureValue());   //STRUCTURE_OID inout
			paramValueList.add(struct.getPositionType());    //POSITION_TYPE inout
			paramValueList.add(struct.getPositionValue());   //POSITION_OID inout


			if(passthru==null)
				passthru = "";

			paramValueList.add(passthru);  //CHANNEL_CD_LIST in (not used) Use for entitlement ON/OFF


			String aliasFlag = (String) params.get("ALIAS_FLAG");
			if(aliasFlag==null)
				aliasFlag = "Y";
			paramValueList.add(aliasFlag);  //ALIAS_FLAG in

			String lang = (String)params.get("LANG");
			if(lang==null||(lang!=null&&lang.trim().equals("")))
				lang=NcasConstants.LANG_CODE_US_ENGLISH_VAM;
			paramValueList.add(lang);
			paramValueList.add("");//FIND_STRING
			String impLoginID = (String)params.get("IMPLOGIND");
			if(impLoginID == null)
				impLoginID = "";
			paramValueList.add(impLoginID);//IMP_LOGIN_ID

			Map procMap = executeStoredProcedure(paramValueList);

			int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
			String debugStr = (String)procMap.get("MSG_STRING");

			if( returnCode > 0 ) {
					String[] errMsg = new String[3];
				    errMsg[0] = "getBillView";
				    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_BILL_VIEW;
				    errMsg[2] = debugStr;
				    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			Content tables = (Content)procMap.get("tables");
			SearchResult result = null;
			String match_found = (String)procMap.get("MATCH_FOUND");
			String bill_found = (String)procMap.get("BILL_FOUND");
			if(match_found!=null && !match_found.equalsIgnoreCase("N"))
				result = new SearchResult(tables);

			returnMap.put("SEARCH_RESULT", result);
			returnMap.put("MATCH_FOUND", match_found);
			returnMap.put("BILL_FOUND", bill_found);
			return returnMap;
		}

		public Map getVBIFVamData(String userId, String debugLevel, Map params) throws Exception	{

			String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
			List paramValueList = new ArrayList();
			Map returnMap = new HashMap();

			String linkparam = (String) params.get("LINKPARAM");
			String employeeFlag  = (String) params.get("EMPLFLAG");
			String portalUserID  = (String) params.get("LOGIND");
			Structure struct = (Structure)params.get("STRUCTURE");

			paramValueList.add("49");    //PAGE_ID
			paramValueList.add(linkparam); //LINK_PARAMS
			paramValueList.add("");//FILTER_STRING
			paramValueList.add("");  //SORT_STRING
			paramValueList.add("1");//PAGE_SUBSET

			paramValueList.add("1"); //LINE_OFFSET
			paramValueList.add("10");   //PAGE_SIZE

			paramValueList.add(userId);     //APP_USER_ID
			paramValueList.add(debugLevel); //DEBUG_LEVEL

			paramValueList.add(employeeFlag); //EMPLOYEE_FLAG
			paramValueList.add(portalUserID); //PORTAL_USER_ID

			String misc = (String) params.get("MISC");
			if (misc == null) {
				misc = "";
			}
			paramValueList.add(misc);  //MISC
			paramValueList.add("O");//ACTION
			paramValueList.add(struct.getStructureType());    //STRUCTURE_TYPE inout
			paramValueList.add(struct.getStructureValue());   //STRUCTURE_OID inout
			paramValueList.add(struct.getPositionType());    //POSITION_TYPE inout
			paramValueList.add(struct.getPositionValue());   //POSITION_OID inout

			paramValueList.add("");  //CHANNEL_CD_LIST in (not used) Use for entitlement ON/OFF

			String aliasFlag = (String) params.get("ALIAS_FLAG");
			if(aliasFlag==null)
				aliasFlag = "Y";
			paramValueList.add(aliasFlag);  //ALIAS_FLAG in


			String lang = (String)params.get("LANG");
			if(lang==null||(lang!=null&&lang.trim().equals("")))
				lang=NcasConstants.LANG_CODE_US_ENGLISH_VAM;
			paramValueList.add(lang);
			paramValueList.add("");//FIND_STRING
			String impLoginID = (String)params.get("IMPLOGIND");
			if(impLoginID == null)
				impLoginID = "";
			paramValueList.add(impLoginID);//IMP_LOGIN_ID



			Map procMap = executeStoredProcedure(paramValueList);

			int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
			String debugStr = (String)procMap.get("MSG_STRING");

			if( returnCode > 0 ) {
					String[] errMsg = new String[3];
				    errMsg[0] = "doVBifSearch";
				    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_BILL_VIEW;
				    errMsg[2] = debugStr;
				    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
			}

			Content tables = (Content)procMap.get("tables");

			TicketUpdate ticket = new TicketUpdate();

			if (tables != null) {
				List rows = tables.getRows();
				if (rows != null && rows.size() >= 2) {
					List headerList = (List) rows.get(0);
					Iterator headercellIter = headerList.iterator();
					List dataList = (List) rows.get(1);
					Iterator datacellIter = dataList.iterator();
					while (headercellIter.hasNext() && datacellIter.hasNext()) {
						Cell element = (Cell) headercellIter.next();
						String name = element.getName();
						Cell data = (Cell) datacellIter.next();
						String value = data.getName();
						if (name.equalsIgnoreCase("MAN"))
							ticket.setMan(value);
						else if (name.equalsIgnoreCase("BAN"))
							ticket.setBan(value);
						else if (name.equalsIgnoreCase("MAN DAN"))
							ticket.setManDan(value);
						else if (name.equalsIgnoreCase("BAN DAN"))
							ticket.setBanDan(value);
						else if (name.equalsIgnoreCase("Subscriber Name"))
							ticket.setSubscriberName(value);
						else if (name.equalsIgnoreCase("Subscriber OID"))
							ticket.setSubscriberOid(value);
						else if (name.equalsIgnoreCase("Subscription OID"))
							ticket.setSubscriptionOid(value);
						else if (name.equalsIgnoreCase("Originating System ID"))
							ticket.setOsid(value);
						else if (name.equalsIgnoreCase("Backend System"))
							ticket.setEcpSysName(value);
						else if (name.equalsIgnoreCase("Service Type"))
							ticket.setServiceType(value);
						else if (name.equalsIgnoreCase("Customer Service Type"))
							ticket.setCustSrvType(value);
	   				    else if (name.equalsIgnoreCase("Entity Code"))
							ticket.setEntityCode(value);
						else if (name.equalsIgnoreCase("Invoice Number"))
							ticket.setLastInvoiceNum(value);
						else if (name.equalsIgnoreCase("MAN Bill Date"))
							ticket.setManBillDate(value);
						else if (name.equalsIgnoreCase("Bill Date"))
							ticket.setLastBillDate(value);
						else if (name.equalsIgnoreCase("Name Address 1")) {
							ticket.getAuth().setAuthCustomerName(value);
						    ticket.getAuth().setAuthSource("VAM");    // need to set the source of address
						}                                             // data, so doing it here
						else if (name.equalsIgnoreCase("Name Address 2"))
							ticket.getAuth().setAuthAddrLine1(value);
						else if (name.equalsIgnoreCase("Name Address 3"))
							ticket.getAuth().setAuthAddrLine2(value);
						else if (name.equalsIgnoreCase("Name Address 4"))
							ticket.getAuth().setAuthAddrLine3(value);
						else if (name.equalsIgnoreCase("City"))
							ticket.getAuth().setAuthAddrCity(value);
						else if (name.equalsIgnoreCase("State"))
							ticket.getAuth().setAuthAddrState(value);
						else if (name.equalsIgnoreCase("Zip Code"))
							ticket.getAuth().setAuthAddrZip(value);
						else if (name.equalsIgnoreCase("Country"))
							ticket.getAuth().setAuthCountry(value);
					}
				}
			}

			returnMap.put(NcasConstants.VBIF_TICKETUPDATE_OBJ, ticket);
			return returnMap;
		}

		private void addAuditInfo(Link linkObject,String loginId,String userOid) {

			try{
					String auditInfo = linkObject.getAuditInfo();
					String linkParam = linkObject.getLinkParam();
					String rptId = NCASDataUtil.getStringValue(linkParam,"RPT_ID =");
					if(rptId!=null &&!rptId.isEmpty())
						auditInfo = rptId;
					RptAudit rptAudit = new RptAudit();
					rptAudit.setRptId(Integer.parseInt(auditInfo));
					rptAudit.setRptActionType(NcasConstants.RPT_AUDIT_VIEW);
					rptAudit.setPortalLoginId(loginId);
					rptAudit.setUserOid(new Double(userOid));
					Map inputMap = new HashMap();
					inputMap.put("AUDIT",  rptAudit);
					ReportsUIProcessor.processRptUIRequest(inputMap, "insertAudit");
					linkObject.setAuditInfo(auditInfo);
			}
			catch(Exception e){
				 _LOGGER.error("In addAuditInfo - exception = " + e);
			}

		}
		
		private void addStructureValues(List paramValueList,Structure struct,String employeeFlag) {
			String structType = struct.getStructureType();
			String structValue = struct.getStructureValue();
			String posType = struct.getPositionType();
			String posValue = struct.getPositionValue();
			
			if(structType == null||structValue == null) {
				if(employeeFlag!=null&&employeeFlag.equals("N")){
					structType = "US";
					structValue = "0";
					posType = "";
					posValue = "0";
				}else{
					structType = "SB";
					structValue = "0";
					posType = "";
					posValue = "0";					
				}
			}
			if(posType == null||posValue == null){
				posType = "";
				posValue = "0";					
			}
						
			paramValueList.add(structType);    //STRUCTURE_TYPE inout
			paramValueList.add(structValue);   //STRUCTURE_OID inout
			paramValueList.add(posType);       //POSITION_TYPE inout
			paramValueList.add(posValue);      //POSITION_OID inout
		}
		
}


