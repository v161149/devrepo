package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.domain.SelectOption;

/*
 * Author:Ram/v992473
 */

public class VACDropDownMapper implements RowMapper {
	
	private static final Logger _LOGGER = Logger.getLogger(VACDropDownMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("VACDropDownMapper - Mapping Row# "+rowNum);
		SelectOption selectOption = null;
		int columnCount = rs.getMetaData().getColumnCount();
		_LOGGER.info("Number of columns::"+columnCount);
		if (columnCount == 1) {
			String value = rs.getString(1);
			selectOption = new SelectOption();
			selectOption.setValue(trimSpace(value));//keeping the label and value same.
		} else if (columnCount == 3) {
			/* 
			 * VBIF GET_TKT_DROP_DOWNS api returns 3 columns, (DROP_DOWN_SEQ, DD_OPTION_CODE, DD_OPTION_NAME)
			 * It is assumed if the result set has 3 columns, then it is VBIF.
			 * Tomorrow if some other api returns 3 columns, then either one of the logic needs to moved to different class
			 */
			selectOption = new SelectOption(trimSpace(rs.getString(3)),trimSpace(rs.getString(2)));//treating the first argument(getString(3)) as text and the second(getString(2)) as code which will be behind the text in the dropdown.
		} else if (columnCount > 1) {
			selectOption = new SelectOption(trimSpace(rs.getString(2)),trimSpace(rs.getString(1)));//treating the first argument(getString(2)) as text and the second(getString(1)) as code which will be behind the text in the dropdown.
		}
		_LOGGER.info("select option::"+selectOption);
		return selectOption;
	}
	
	//Trimmer to remove spaces that VAC sends
	private String trimSpace(String input){
		return input!=null?input.trim():input;
	}
}
