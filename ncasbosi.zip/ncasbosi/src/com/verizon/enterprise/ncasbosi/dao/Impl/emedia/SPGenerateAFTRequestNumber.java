package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGenerateAFTRequestNumber extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGenerateAFTRequestNumber.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"REQUEST_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CONFIG_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONFIG_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_DATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"COMMENT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SS_FILE_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_MONTH", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_YEAR", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RPT_REQUEST_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
}

	public SPGenerateAFTRequestNumber(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GENERATE_AFT_REQUEST_NO, spInOutList);
	}

	protected Map executeStoredProcedure(String userId, String debugLevel, String configType,
			String configId, String custName, String action, String mode, String userName,
			String startDateStr, String comment, String fileName, String billMonth,
			String billYear, String rptRequestId ) throws Exception {

		if (rptRequestId == null || rptRequestId.trim().equals(""))
		rptRequestId = "0";

		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL

		paramValueList.add(configType);//CONFIG_TYPE
		paramValueList.add(configId);//CONFIG_ID
		if(custName == null) {
			custName = "";
		}
		paramValueList.add(custName);//CUST_NAME
		paramValueList.add(action);//ACTION
		paramValueList.add(mode);//MODE
		paramValueList.add(userName);//USER_NAME

		_LOGGER.debug("Date Str - " + startDateStr);
		String formattedDateStr = "";
		Date startDate = new Date();
		if( CommonUtil.isNotNull(startDateStr) && !startDateStr.equals("")) {
			startDate = new Date(startDateStr);
		}
		SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd");
		formattedDateStr = formatter.format(startDate);

		paramValueList.add(formattedDateStr);//START_DATE
		paramValueList.add(comment);//COMMENT
		paramValueList.add(fileName);//SS_FILE_NAME
		paramValueList.add(billMonth);//BILL_MONTH
		paramValueList.add(billYear);//BILL_YEAR
		paramValueList.add(rptRequestId);//RPT_REQUEST_ID

		Map responseMap = executeStoredProcedure(paramValueList);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(responseMap, VAM);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
		
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
