package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;


import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAccountListRowMapperImpl  implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetAccountListRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
        if (_LOGGER.isDebugEnabled()) {
        	_LOGGER.debug("Inside GetAccountListRowMapperImpl -> ");
        }		
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List<String> acctList = new ArrayList<String>();

	
		while(rs.next()) {
			String name = rs.getString("DISP_ACCT_NUM");
			name = name.trim();
			if(!name.isEmpty())
				acctList.add(name.trim());
		}
		return acctList;
	}
}
