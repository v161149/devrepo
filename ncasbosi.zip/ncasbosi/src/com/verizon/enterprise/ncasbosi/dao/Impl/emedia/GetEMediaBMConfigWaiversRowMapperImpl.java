package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.eMedia.EMediaWaiverRecord;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetEMediaBMConfigWaiversRowMapperImpl  implements ResultSetExtractor {
	
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaBMConfigWaiversRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetEMediaBMConfigWaiversRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		EMediaWaiverRecord waiverRecord = null;
		List refList = new ArrayList();
		
		Date todayDate = new Date();
		
		try{
			while(rs.next()) {
				
				waiverRecord = new EMediaWaiverRecord();
				//int lineNum = rs.getInt("LINE_NUM");
				String configId = rs.getString("CONFIG_ID");
				String companyName = rs.getString("COMPANY_NAME");
				String masterContractId = rs.getString("MASTER_CONTRACT_ID");
				String cdorCustomerName = rs.getString("CDOR_CUSTOMER_NAME");
				String bcasignDate = CommonUtil.getDisplayVAMDateFromString(rs.getDate("BCASIGN_DATE"));
				String dateCreated =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("DATE_CREATED"));
				
				String startDateStr =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("START_DATE"));
				Date startDate  = rs.getDate("START_DATE");
				Date endDate  = rs.getDate("END_DATE");
				String status = "";
				
				if (endDate == null )
				{
					if (todayDate.equals(startDate) || (todayDate.after(startDate)))
					{
						status = "Active";
					}
					else
						status = "Inactive";
				}
				else
				{
					if( todayDate.equals(startDate) || todayDate.after(startDate) )
					{
						if (todayDate.before(endDate) || todayDate.equals(endDate) )
						{
							status = "Active";
						}
						else
							status = "Inactive";
					}
					else
						status = "Inactive";
				}
				
				
				String endDateStr =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("END_DATE"));

				if(CommonUtil.isNotNull(configId)) { waiverRecord.setConfigId(configId.trim()); }
				if(CommonUtil.isNotNull(companyName)) { waiverRecord.setCompanyName((companyName.trim())); }
				if(CommonUtil.isNotNull(masterContractId)) { waiverRecord.setMasterContractId(masterContractId.trim()); }
				if(CommonUtil.isNotNull(cdorCustomerName)) { waiverRecord.setCdorCustomerName(cdorCustomerName.trim()); }
				
				if(CommonUtil.isNotNull(bcasignDate)) {waiverRecord.setBcasignDate(bcasignDate.trim()); }
				if(CommonUtil.isNotNull(dateCreated)) {waiverRecord.setDateCreated(dateCreated.trim()); }
				if(CommonUtil.isNotNull(startDateStr)) { waiverRecord.setStartDate(startDateStr.trim()); }
				if(CommonUtil.isNotNull(endDateStr)) { waiverRecord.setEndDate(endDateStr.trim()) ; }
				if(CommonUtil.isNotNull(status)) { waiverRecord.setStatus(status.trim()) ; }
				
				

				refList.add(waiverRecord);
				//returnMap.put("waiverList",refList);
					
			}
			//returnMap.put("waiverList",refList);

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			return refList;
		}
}