package com.verizon.enterprise.ncasbosi.dao;


import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;


import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.verizon.enterprise.ncasbosi.dao.Interface.adjustments.AdjustmentInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.adjustments.GetStructureInfoInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.autocredit.AutoCreditInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.batch.BatchRequestInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.billinquiry.BillInquiryInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.billmanager.BillmanagerDataInterface;

import com.verizon.enterprise.ncasbosi.dao.Interface.billview.BillViewInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.ApprovalAuditInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.VacDropDownsInterface;


import com.verizon.enterprise.ncasbosi.dao.Interface.dbadmin.DBAdminInterface;


import com.verizon.enterprise.ncasbosi.dao.Interface.email.EmailInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.emaillog.EmailLogInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaProfileInterface;


import com.verizon.enterprise.ncasbosi.dao.Interface.status.StatAndSchedInterface;


import com.verizon.enterprise.ncasbosi.dao.Interface.ticket.TicketUIInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.tracking.BillTrackingInterface;


import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;


import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaEditInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaMsgInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.permissions.AdminPermissionInterface;

import com.verizon.enterprise.ncasbosi.dao.Interface.emedia.EMediaCustomerInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.portallinks.PortalLinkInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.payments.*;
import com.verizon.enterprise.ncasbosi.dao.Interface.billmanager.MediaDownloadInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.brinetworx.BriNetworxInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.historicalinvoice.HistoricalInvoiceInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.usagerepository.UrInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.vbif.VBIFInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.admin.AdminCompareInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.admin.AdminPaymentEmailRequestinterface;

import com.verizon.enterprise.ncasbosi.dao.Interface.Reprint.ReprintRequestInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.intl.InternationalInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.vua.VUAUIInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.billinquiry.BillInquiryMigrationinterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.bugtracker.BugTrackerDataInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.perf.LogPerfInterface;

import com.verizon.enterprise.ncasbosi.dao.Interface.reports.ReportsUIInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.reports.ReportsBatchInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.SystemParamCacheInterface;
import com.verizon.enterprise.ncasbosi.dao.Interface.autoRem.AutoRemBatchInterface;

public class DAOFactory implements NCASBOSIConstants {


    private static DAOFactory defaultInstance;


    private ApplicationContext ncasSpringCtx;


    private DAOFactory(ApplicationContext ctx) {

        ncasSpringCtx = ctx;

    }


    public static synchronized DAOFactory getInstance() {

        if (defaultInstance == null) {

            String[] configFiles = new String[] {

                                   "/ncasbosi/ncasbosi-springcontext.xml"};

            ApplicationContext defaultCtx = new ClassPathXmlApplicationContext(

                    configFiles);

            defaultInstance = new DAOFactory(defaultCtx);

        }

        return defaultInstance;

    }


    public BillInquiryInterface getBI() {

        return (BillInquiryInterface) ncasSpringCtx.getBean(

                BILL_INQUIRY_BEAN_NAME);

    }


    // For NBR Tracking







    public BillTrackingInterface getBillTracking() {

        return (BillTrackingInterface) ncasSpringCtx.getBean(

                BILL_TRACKING_BEAN_NAME);

    }


    public EMediaProfileInterface getEMediaProfile() {

        return (EMediaProfileInterface) ncasSpringCtx.getBean(

                EMEDIA_PROFILE_BEAN_NAME);

    }


//  THIS SECTION IS FOR STATUS AND SCHEDULING PROJECT - START-








    public StatAndSchedInterface getStatAndSched() {

        return (StatAndSchedInterface) ncasSpringCtx.getBean(STATUS_BEAN_NAME);

//  THIS SECTION IS FOR STATUS AND SCHEDULING PROJECT - END-







    }

    public BillViewInterface getBillView() {

        return (BillViewInterface) ncasSpringCtx.getBean(BILL_VIEW_BEAN_NAME);

    }


    public DBAdminInterface getDBAdmin() {

        return (DBAdminInterface) ncasSpringCtx.getBean(DB_ADMIN_BEAN_NAME);

    }
    
    public DBAdminInterface getDBAdminExcel() {

        return (DBAdminInterface) ncasSpringCtx.getBean(DB_ADMIN_EXCEL_TRANS_BEAN_NAME);

    }


    public EMediaEditInterface getEMediaEdit() {

        return (EMediaEditInterface) ncasSpringCtx.getBean(

                EMEDIA_EDIT_BEAN_NAME);

    }


    public EMediaMsgInterface getEMediaMsg() {

        return (EMediaMsgInterface) ncasSpringCtx.getBean(EMEDIA_MSG_BEAN_NAME);

    }

    public EMediaCustomerInterface getEMediaCustomer() {

        return (EMediaCustomerInterface) ncasSpringCtx.getBean(
                EMEDIA_CUSTOMER_BEAN_NAME);

    }
    public AdminPermissionInterface getAdminPermission() {
        return (AdminPermissionInterface) ncasSpringCtx.getBean(ADMIN_PERMISSIONS_BEAN_NAME);
    }
    public PortalLinkInterface getPortalLink() {
        return (PortalLinkInterface) ncasSpringCtx.getBean(PORTAL_LINKS_BEAN_NAME);
    }
	public PortalLinkInterface getPortalLinkForECP() {

		return (PortalLinkInterface) ncasSpringCtx.getBean(PORTAL_LINKS_ECP_BEAN_NAME);
	}

	public AutoCreditInterface getAutoCreditImplementationReference(){
		return (AutoCreditInterface) ncasSpringCtx.getBean(AUTO_CREDIT_BEAN_NAME);
	}

	public VacDropDownsInterface getVacDropDownsImplementationReference(){
		return (VacDropDownsInterface) ncasSpringCtx.getBean(VAC_DROP_DOWNS_BEAN_NAME);
	}

	public BatchRequestInterface getBatchRequestProcessor() {

		return (BatchRequestInterface) ncasSpringCtx.getBean(BATCH_BEAN_NAME);
	}
    public PaymentsBatchInterface getPaymentsBatchImpl() {
        return (PaymentsBatchInterface) ncasSpringCtx.getBean(PAYMENTS_BATCH_BEAN_NAME);
    }
    public PaymentsBatchInterface getPaymentsVZBBatchImpl() {
        return (PaymentsBatchInterface) ncasSpringCtx.getBean(PAYMENTS_VZB_BEAN_NAME);
    }
    public PaymentsBatchInterface getPaymentsVZWBatchImpl() {
        return (PaymentsBatchInterface) ncasSpringCtx.getBean(PAYMENTS_VZW_BEAN_NAME);
    }
    public PaymentsUIInterface getPaymentsUIImpl() {
        return (PaymentsUIInterface) ncasSpringCtx.getBean(PAYMENTS_UI_BEAN_NAME);
    }
    public PaymentsInterface getPayments() {
        return (PaymentsInterface) ncasSpringCtx.getBean(PAYMENTS_BEAN_NAME);
    }
	public PaymentsInternalInterface getPaymentsBeanForECP() {
		return (PaymentsInternalInterface) ncasSpringCtx.getBean(PAYMENTS_ECP_BEAN_NAME);
	}
    public AdjustmentInterface getAdjustments() {
        return (AdjustmentInterface) ncasSpringCtx.getBean(ADJUSTMENTS_BEAN_NAME);
    }
//  BillManager
    public BillmanagerDataInterface getEMediaList(){
    	return (BillmanagerDataInterface) ncasSpringCtx.getBean(EMEDIA_BEAN_NAME);
    }

    public AdminCompareInterface selectCompareDBdetails(){
    	return (AdminCompareInterface) ncasSpringCtx.getBean(COMP_ECP_XLS);
    }
    public MediaDownloadInterface getMediaDownload(){
    	return (MediaDownloadInterface) ncasSpringCtx.getBean(MEDIA_DOWNLOAD_BEAN_NAME);
    }
// Payment and memo bill distribution
    public AdminPaymentEmailRequestinterface selectPaymentEmailDetailsRequest()
    {
    return (AdminPaymentEmailRequestinterface) ncasSpringCtx.getBean(PAYMENT_EMAIL_BEAN);

    }
	public AdminPaymentEmailRequestinterface selectMemobillDetailsRequest()
	    {
	    return (AdminPaymentEmailRequestinterface) ncasSpringCtx.getBean(PAYMENT_EMAIL_BEAN);

    }
	  public AdminPaymentEmailRequestinterface selectMemobillEmailDetailsRequest()
		    {
		    return (AdminPaymentEmailRequestinterface) ncasSpringCtx.getBean(PAYMENT_EMAIL_BEAN);

    }





    public HistoricalInvoiceInterface getHistoricalInvoiceImplementationReference(){
		return (HistoricalInvoiceInterface) ncasSpringCtx.getBean(HISTORICAL_INVOICE_BEAN_NAME);
	}

    public BriNetworxInterface getBriNetworxImplementationReference(){
		return (BriNetworxInterface) ncasSpringCtx.getBean(BRI_NETWORX_BEAN_NAME);
	}


    public ReprintRequestInterface submitReprintRequest(){
        return (ReprintRequestInterface) ncasSpringCtx.getBean(SUM_REPRINT_REQ);
    }
    public ReprintRequestInterface submitReprintRequestVSSI(){
        return (ReprintRequestInterface) ncasSpringCtx.getBean(SUM_REPRINT_REQ_VSSI);
    }

    public UrInterface getUrImplementationReference(){
		return (UrInterface) ncasSpringCtx.getBean(USAGE_REPOSITORY_BEAN_NAME);
	}
    public EmailLogInterface getEmailLogImpl() {
        return (EmailLogInterface) ncasSpringCtx.getBean(EMAIL_LOG_BEAN_NAME);
    }
    public InternationalInterface getInternationalImpl() {
        return (InternationalInterface) ncasSpringCtx.getBean(INTERNATIONAL_BEAN_NAME);
    }
    public VBIFInterface getVbifImpl() {
        return (VBIFInterface) ncasSpringCtx.getBean(VBIF_BEAN_WITH_TXN);
    }
    public VUAUIInterface getVuaUIImpl(){
    	return(VUAUIInterface) ncasSpringCtx.getBean(VUAUI_BEAN_NAME);
    }  
    //DfrgMigration
    public BillInquiryMigrationinterface getBillInquiryMigration(){
        return(BillInquiryMigrationinterface) ncasSpringCtx.getBean(BILL_MIGRATION_BEAN_NAME);
    }
    //BugTrackerData
    public BugTrackerDataInterface getBugTrackerData(){
    	return(BugTrackerDataInterface) ncasSpringCtx.getBean(BUG_TRACKER_BEAN_NAME);
    }
    //PerformanceTracking
    public  LogPerfInterface getPerformanceImpl(){
    	return(LogPerfInterface) ncasSpringCtx.getBean(PERFORMANCE_TRACKER_BEAN_NAME);
    }

    //Reports UI
    public ReportsUIInterface getReportsUIImpl(){
    	return(ReportsUIInterface) ncasSpringCtx.getBean(REPORTS_UI_BEAN_NAME);
    }
    //Reports Batch
    public ReportsBatchInterface getReportsBatchImpl() {
        return (ReportsBatchInterface) ncasSpringCtx.getBean(REPORTS_BATCH_BEAN_NAME);
    } 
  //SystemParam Cache
    public SystemParamCacheInterface getSystemParamCache(){
    	return (SystemParamCacheInterface) ncasSpringCtx.getBean(SYSTEM_PARAM_BEAN_NAME);
    }
    //For Auto Remarks
    public AutoRemBatchInterface getAutoRemBatchImpl()
    {
    	return (AutoRemBatchInterface)ncasSpringCtx.getBean(AUTO_REM_BATCH_BEAN);
    }
    
    public GetStructureInfoInterface getStructureInfoBean()
    {
    	return (GetStructureInfoInterface)ncasSpringCtx.getBean(GET_STRUCTURE_INFO_BEAN);
    }
    
    //Tickets UI
    public TicketUIInterface getTicketsUIImpl(){
    	return(TicketUIInterface) ncasSpringCtx.getBean(TICKETS_UI_BEAN_NAME);
    }
    

    public EmailInterface getEmailUIImpl(){
    	return(EmailInterface) ncasSpringCtx.getBean(EMAIL_UI_BEAN_NAME);
    }
    public DataSource getVAMDataSource(){
    	return (DataSource) ncasSpringCtx.getBean("VAMDataSource");
    }
    
    public DataSource getVACDataSource(){
    	return (DataSource) ncasSpringCtx.getBean("dataSource");
    }
    
    public DataSource getVGWDataSource(){
    	return (DataSource) ncasSpringCtx.getBean("VGWDataSource");
    }
    
    public ApprovalAuditInterface getApprovalAudit(){
    	return (ApprovalAuditInterface)ncasSpringCtx.getBean("ApprovalAuditBean");
    }
}
