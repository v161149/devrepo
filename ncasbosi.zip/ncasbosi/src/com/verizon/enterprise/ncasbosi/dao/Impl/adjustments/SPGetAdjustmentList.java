package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.adjustments.Adjustment;
import com.verizon.enterprise.common.ncas.display.Navigation;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetAdjustmentList extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPGetAdjustmentList.class);

	private static List spInOutList;
	private static GetAdjListAcctLvlRowMapperImpl acctLvlRowMapper = null;
	private static GetAdjListDetailRowMapperImpl dtlRowMapper = null;
	static {
		spInOutList = new ArrayList();
		acctLvlRowMapper = new GetAdjListAcctLvlRowMapperImpl();
		dtlRowMapper = new GetAdjListDetailRowMapperImpl();
		spInOutList.add(new Object[] { "acctLevel", getSqlDataType(Types.NULL), NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, acctLvlRowMapper });
		spInOutList.add(new Object[] { "dtlLevel", getSqlDataType(Types.NULL), NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET, dtlRowMapper });
		spInOutList.add(new Object[] { "APP_USER_ID", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "DEBUG_LEVEL", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "RETURN_CODE", getSqlDataType(Types.INTEGER), NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "REASON_CODE", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "ERROR_TEXT", getSqlDataType(Types.VARCHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLCODE", getSqlDataType(Types.INTEGER), NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLTOKENS", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "SP_SQLSTATE", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
		spInOutList.add(new Object[] { "MAN", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "MAN_BILL_DATE", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "BAN", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "BILL_DATE", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "OSID", getSqlDataType(Types.CHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "PAGE_ID", getSqlDataType(Types.INTEGER), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "PARM1", getSqlDataType(Types.VARCHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "PARM2", getSqlDataType(Types.VARCHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "PARM3", getSqlDataType(Types.VARCHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
		spInOutList.add(new Object[] { "KEY_STRING", getSqlDataType(Types.VARCHAR), NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
	}

	public SPGetAdjustmentList(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_ADJUSTMENTS_DETAILS, spInOutList);
	}

	public Map executeStoredProcedure(Map paramMap) throws Exception {

		String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
		Map returnMap = new HashMap<String, Adjustment>();
		
		List paramValueList = new ArrayList();
		String userId = (String) paramMap.get("APP_USER_ID");
		String debuglevel = (String) paramMap.get("DEBUG_LEVEL");
		String man = (String) paramMap.get("MAN");
		String manbilldate = (String) paramMap.get("MAN_BILL_DATE");
		String ban = (String) paramMap.get("BAN");
		String billdate = (String) paramMap.get("BILL_DATE");
		String osid = (String) paramMap.get("OSID");
		String pageId = (String) paramMap.get("PAGE_ID");
		String parm1 = (String) paramMap.get("PARM1");
		String parm2 = (String) paramMap.get("PARM2");
		String parm3 = (String) paramMap.get("PARM3");
		String keystring = (String) paramMap.get("KEY_STRING");

		paramValueList.add(userId);
		paramValueList.add(debuglevel);
		paramValueList.add(man);
		paramValueList.add(manbilldate);
		paramValueList.add(ban);
		paramValueList.add(billdate);
		paramValueList.add(osid);
		paramValueList.add(pageId);
		paramValueList.add(parm1);
		paramValueList.add(parm2);
		paramValueList.add(parm3);
		paramValueList.add(keystring);

		Map procMap = (HashMap) executeStoredProcedure(paramValueList);

        int returnCode = ((Integer) procMap.get("RETURN_CODE")).intValue();
		String debugStr = (String) procMap.get("ERROR_TEXT");
		if (returnCode > 0) {
			String[] errMsg = new String[3];
			errMsg[0] = "SPGetAdjustmentList";
			errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_ADJUSTMENTS_DETAILS;
			errMsg[2] = debugStr + "  SP_SQLCODE = " + (Integer) procMap.get("SP_SQLCODE");;
			throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg, returnCode);
		}

		Adjustment acctLevel = (Adjustment) procMap.get("acctLevel");
		List<Adjustment> dtlLevel = (List<Adjustment>) procMap.get("dtlLevel");
	
		List<Adjustment> newList = new ArrayList<Adjustment>();

		Iterator<Adjustment> itr = dtlLevel.iterator();
		while (itr.hasNext()) {
			Adjustment adjustment = itr.next();
			adjustment.setMan(acctLevel.getMan());
			adjustment.setBan(acctLevel.getBan());
			adjustment.setAban(acctLevel.getAban());
			adjustment.setOsId(acctLevel.getOsId());
			adjustment.setAccountSysId(acctLevel.getAccountSysId());
			adjustment.setAdjustmentStatus(acctLevel.getAdjustmentStatus());
			adjustment.setBillDate(acctLevel.getBillDate());
			adjustment.setClassOfServiceType(acctLevel.getClassOfServiceType());
			if (adjustment.getState().length() == 0) {
				adjustment.setState(acctLevel.getState());	
			}
			adjustment.setCompany_Code(acctLevel.getCompany_Code());
			adjustment.setDatabaseSegID(acctLevel.getDatabaseSegID());
			adjustment.setTaxStatusFed(acctLevel.getTaxStatusFed());
			adjustment.setTaxStatusState(acctLevel.getTaxStatusState());
			adjustment.setTaxStatusE911(acctLevel.getTaxStatusE911());
			adjustment.setTaxStatusSurch(acctLevel.getTaxStatusSurch());
			adjustment.setTaxStatusLocal(acctLevel.getTaxStatusLocal());
			adjustment.setEcpBackendSys(acctLevel.getEcpBackendSys());
			newList.add(adjustment);
		}
		returnMap.put("adjList", newList);
		return returnMap;
	}

	public Map executeStoredProcedure(Object paramValues) throws Exception {
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
