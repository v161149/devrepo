package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetEMediaAccountsRowMapperImpl  implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetEMediaAccountsRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetEMediaAccountsRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new LinkedHashMap();
		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid=0.0;
		double previousOid=0.0;
		List refList = null;
		String key = "";
		try{
			while(rs.next()) {
				emediaRecord = new EMediaRecord();

				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String ban = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String man = rs.getString("MAN");
				//String manDan = rs.getString("MAN_DAN");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String startBillPeriod = rs.getString("START_DATE");
				String endBillPeriod = rs.getString("END_DATE");
				String accountName = rs.getString("COMPANY_NAME");
				String billPeriod = rs.getString("BP_DAY");
				String edi05 = rs.getString("PROD_ISA_05");
				String edi06 = rs.getString("PROD_ISA_06");
				String edi02 = rs.getString("PROD_GS_02");
				String channelCode = rs.getString("LOB_IND");
				String ediDeliveryOption = rs.getString("EDI_DELIV_OPT");
				String ediDataGroup = rs.getString("DATA_GROUP");
				String vz450DeliveryOption = rs.getString("DD_DELIV_OPT");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String acctStatus = rs.getString("ACCT_STATUS");
				acctSubscriptionOid = rs.getDouble("SUBSCRIPTION_OID");
				
				
				if(CommonUtil.isNotNull(enterpriseId)) {emediaRecord.setEnterprise(enterpriseId.trim());}


				if(CommonUtil.isNotNull( ban)) {emediaRecord.setBan(ban.trim());}
				if(CommonUtil.isNotNull( man)) {emediaRecord.setMan(man.trim());}


				if(CommonUtil.isNotNull( origSysId)){ origSysId = origSysId.trim();}
				else origSysId = "";


				if((!origSysId.startsWith("M1")&&!origSysId.startsWith("M2")&&!origSysId.startsWith("M3")&&!origSysId.startsWith("M9")) && (banDan==null ||(banDan!=null && banDan.trim().equals("")))){
					banDan = man;
					man = "";
				}

				emediaRecord.setOrigSysId(origSysId);

				if(CommonUtil.isNotNull( banDan)) {emediaRecord.setBan_dan(CommonUtil.getFormattedAccount(banDan.trim(),emediaRecord.getOrigSysId(), ""));}
				if(CommonUtil.isNotNull( man)) {emediaRecord.setMan_dan(CommonUtil.getFormattedAccount(man.trim(),emediaRecord.getOrigSysId(), ""));}




				if(CommonUtil.isNotNull( accountName)) {emediaRecord.setAccountName(accountName.trim());}
				if(CommonUtil.isNotNull( billPeriod)) {emediaRecord.setBillPeriod(billPeriod.trim());}
				if(CommonUtil.isNotNull( edi05)) {emediaRecord.setEdi05(edi05.trim());}
				if(CommonUtil.isNotNull( edi06)) {emediaRecord.setEdi06(edi06.trim());}
				if(CommonUtil.isNotNull( edi02)) {emediaRecord.setEdi02(edi02.trim());}
				if(CommonUtil.isNotNull( channelCode)) {emediaRecord.setChannelCode(channelCode.trim());}
				if(CommonUtil.isNotNull( ediDeliveryOption)) {emediaRecord.setEdiDeliveryOption(ediDeliveryOption.trim());}
				if(CommonUtil.isNotNull( ediDataGroup)) {emediaRecord.setEdiDataGroup(ediDataGroup.trim());}
				if(CommonUtil.isNotNull( vz450DeliveryOption)) {emediaRecord.setVz450DeliveryOption(vz450DeliveryOption.trim());}
				if(CommonUtil.isNotNull( systemAbbrv)) {emediaRecord.setSystemAbbrv(systemAbbrv.trim());}
				if(CommonUtil.isNotNull( startBillPeriod)) {emediaRecord.setStartBillPeriod(CommonUtil.getDisplayDateFromString(startBillPeriod.trim()));}
				if(CommonUtil.isNotNull( endBillPeriod)) {emediaRecord.setEndBillPeriod(CommonUtil.getDisplayDateFromString(endBillPeriod.trim()));}
				if(CommonUtil.isNotNull( acctStatus)) emediaRecord.setStatus(acctStatus.trim());
				
				key = CommonUtil.convertStringFromDouble(acctSubscriptionOid);
				emediaRecord.setAcctSubscriptionOid(key);

				if(previousOid!=acctSubscriptionOid){
					refList = new ArrayList();
					returnMap.put(key,refList);
				}
				refList.add(emediaRecord);
				previousOid = acctSubscriptionOid;
			}

		}
		catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
				_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
				throw nfe;
		}
			return returnMap;
		}
}