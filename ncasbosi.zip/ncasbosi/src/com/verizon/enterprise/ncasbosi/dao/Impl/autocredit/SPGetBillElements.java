package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import com.verizon.enterprise.common.ncas.autocredit.CreditType;
import com.verizon.enterprise.common.ncas.autocredit.SubType;
import com.verizon.enterprise.common.ncas.NcasConstants;


public class SPGetBillElements extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetBillElements.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();

		 spInOutList.add(new Object[]{"APP_USER_ID",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"MAN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"OSID",        getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CREDIT_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FROM_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"THRU_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MRC_NRC_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SERVICE_ID",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SERVICE_ID_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"SORT_ORDER",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE",   getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"ROW_COUNT",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

	 }

	public SPGetBillElements(DataSource dataSource){
		super(dataSource, getVAMSchemaName() + "." + NCASBOSIConstants.SP_GET_BILL_ELEMENTS, getInoutList()); 
	}
	
	//forms a new in/out List with unique mapper object bound to each SP call 
	private static List getInoutList(){
		List inOutList = new ArrayList();
		inOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetBillElementsMapper()});
		inOutList.addAll(spInOutList);
		return inOutList;
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		VamDO vamDO = (VamDO)inputMap.get("vamDO");
		Pagination myPag = (Pagination)inputMap.get("pagination");
		_LOGGER.info("input DO::"+vamDO);
		_LOGGER.info("input pagination::"+myPag);

		if (vamDO == null){
			throw new Exception("SPGetBillElements: input data object is null");
		}
		if (myPag == null){
			throw new Exception("SPGetBillElements: Pagination obj is null");
		}


		String formatIn = "MM/dd/yyyy";
		String formatOut = "yyyy-MM-dd";
		//convert date user entered into date db2 can use.
		String fromDate = CommonUtil.formatDate(vamDO.getFromDate(), formatIn, formatOut);
		String thruDate = CommonUtil.formatDate(vamDO.getThruDate(), formatIn, formatOut);

		/* display inputs */
		_LOGGER.info("fromDate db2 ::"+fromDate);
		_LOGGER.info("thruDate db2 ::"+thruDate);

		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add("SPGetBillElements");   // APP_USER_ID       CHAR (20)
		if (_LOGGER.isDebugEnabled())
		{
			callList.add("1");                 // DEBUG_LEVEL       CHAR (1)
		}
		else
		{
			callList.add("0");                 // DEBUG_LEVEL       CHAR (1)
		}
		callList.add(vamDO.getMan());      // MAN               CHAR (13)
		callList.add(vamDO.getBan());      // BAN               CHAR (13)
		callList.add(vamDO.getOsid());     // OSID              CHAR (2)
		callList.add(vamDO.getCreditType()); //CREDIT_TYPE       CHAR (2)
		callList.add(fromDate);            // FROM_DATE         CHAR (10)
		callList.add(thruDate);            // THRU_DATE         CHAR (10)
		callList.add(getMrcNrc(vamDO.getCreditType(), vamDO.getSubType()));   // MRC_NRC_IND       CHAR (1)
		callList.add(vamDO.getServiceId());// SERVICE_ID        CHAR (30)
		callList.add(getServiceIdType(vamDO.getOsid(),vamDO.getSubType(),vamDO.getServiceIdType()));// SERVICE_ID_TYPE
		callList.add(myPag.getVamSortOrder());// SORT_ORDER        VARCHAR (500)
		callList.add(new Integer(myPag.getLineOffset()));  // LINE_OFFSET       INTEGER
		callList.add(new Integer(myPag.getPageSize()));    // PAGE_SIZE         SMALLINT

		
		//populate osId and serviceId of GetBillElementsMapper before executing the stored procedure
		Object[] resultSetDeclarationArray = (Object[])this.getAllParamList().get(0);
		GetBillElementsMapper getBillElementsMapper = (GetBillElementsMapper)resultSetDeclarationArray[3];
		getBillElementsMapper.setOsId(vamDO.getOsid());
		getBillElementsMapper.setServiceId(vamDO.getServiceId());
		
		
		/* execute sp */
		Map resMap = executeSP(callList, false);

		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}

	// return Service Id Type as "I" if invoice Level - MRI NRI USI 
	public String getServiceIdType(String osid, String subType, String serviceIdType)
	{
	   if(osid != null && osid.equalsIgnoreCase(NcasConstants.IXPLUS))  // if IXPLUS
	   {
 	    if (subType.equalsIgnoreCase(SubType.USAGE_INVOICE_LEVEL) || subType.equalsIgnoreCase(SubType.NON_RECURRING_CHARGES_INVOICE_LEVEL) || subType.equalsIgnoreCase(SubType.RECURRING_CHARGES_INVOICE_LEVEL))
		return "I";  // Invoice Level	
	   }
		return serviceIdType;
	}

	// get mrc or nrc value, usage and tax should not be coming to this api but
	//  put in code for clarity.
	public String getMrcNrc(String creditType, String subType)
	{
		if (creditType != null)
		{
			if (creditType.equals(CreditType.LATE_DISCONNECT) ||
				creditType.equals(CreditType.SERVICE_AVAILABILITY) ||
				creditType.equals(CreditType.SERVICE_SETUP_ERROR))
			{
				return "M";
			}
			if (creditType.equals(CreditType.PRICE_SETUP_ERROR) ||
				creditType.equals(CreditType.ALL_OTHER_ERRORS))
			{
				if (subType != null)
				{
					if (subType.equals(SubType.NON_RECURRING_CHARGES) || subType.equals(SubType.NON_RECURRING_CHARGES_INVOICE_LEVEL))
					{
						return "N";
					}
					if (subType.equals(SubType.RECURRING_CHARGES) || subType.equals(SubType.RECURRING_CHARGES_INVOICE_LEVEL))
					{
						return "M";
					}
					if (subType.equals(SubType.USAGE_INVOICE_LEVEL) ||
						subType.equals(SubType.USAGE_SERVICEID_LEVEL))
					{
						return "U";
					}
				}
			}
			if (creditType.equals(CreditType.TAX_EXEMPT_CREDIT))
			{
				return "T";
			}
		}

		logger.error("no mrc/nrc value found for credit type:"+ creditType + " subtype:" + subType);
		return "";
	}
}
