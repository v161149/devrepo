package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.vbif.AdjTktSummary;
import com.verizon.enterprise.common.util.commonUtil;

public class GetIciAdjDataSummRowMapper implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetIciAdjDataSummRowMapper.class);

	public Object extractData(ResultSet rs) throws SQLException {

		ArrayList<AdjTktSummary> adjTktSummaryList = new ArrayList();
		AdjTktSummary adjTktSummary = null;

		while (rs.next()) {
			adjTktSummary = new AdjTktSummary();
			adjTktSummary.setLabel("Miscellaneous");
			adjTktSummary.setTotCrTxLpc(commonUtil.formatNumber(rs.getBigDecimal("MISC_ADJ_CR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotDrTx(commonUtil.formatNumber(rs.getBigDecimal("MISC_ADJ_DR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotInt(commonUtil.formatNumber(rs.getBigDecimal("MISC_ADJ_INT"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotNet(commonUtil.formatNumber(rs.getBigDecimal("MISC_ADJ_NET"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummaryList.add(adjTktSummary);
	
			adjTktSummary = new AdjTktSummary();
			adjTktSummary.setLabel("Other Charges & Credits");
			adjTktSummary.setTotCrTxLpc(commonUtil.formatNumber(rs.getBigDecimal("OCC_ADJ_CR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotDrTx(commonUtil.formatNumber(rs.getBigDecimal("OCC_ADJ_DR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotInt(commonUtil.formatNumber(rs.getBigDecimal("OCC_ADJ_INT"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotNet(commonUtil.formatNumber(rs.getBigDecimal("OCC_ADJ_NET"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummaryList.add(adjTktSummary);
	
			adjTktSummary = new AdjTktSummary();
			adjTktSummary.setLabel("Non-Portal");
			adjTktSummary.setTotCrTxLpc(commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_CR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotDrTx(commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_DR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotInt(commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_INT"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotNet(commonUtil.formatNumber(rs.getBigDecimal("NP_ADJ_TOT_NET"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummaryList.add(adjTktSummary);
	
			adjTktSummary = new AdjTktSummary();
			adjTktSummary.setLabel("Automated");
			adjTktSummary.setTotCrTxLpc(commonUtil.formatNumber(rs.getBigDecimal("AUTO_PORT_ADJ_CR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotDrTx(commonUtil.formatNumber(rs.getBigDecimal("AUTO_PORT_ADJ_DR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotInt(commonUtil.formatNumber(rs.getBigDecimal("AUTO_PORT_ADJ_INT"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotNet(commonUtil.formatNumber(rs.getBigDecimal("AUTO_PORT_ADJ_NET"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummaryList.add(adjTktSummary);
	
			adjTktSummary = new AdjTktSummary();
			adjTktSummary.setLabel("Totals");
			adjTktSummary.setTotCrTxLpc(commonUtil.formatNumber(rs.getBigDecimal("ADJ_TOT_CR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotDrTx(commonUtil.formatNumber(rs.getBigDecimal("ADJ_TOT_DR"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotInt(commonUtil.formatNumber(rs.getBigDecimal("ADJ_TOT_INT"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummary.setTotNet(commonUtil.formatNumber(rs.getBigDecimal("ADJ_TOT_NET"), "#,###,###,##0.00;-#,###,##0.00"));
			adjTktSummaryList.add(adjTktSummary);
		}
		return adjTktSummaryList;
	}
}
