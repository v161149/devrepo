package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.common.CANDatesInfo;

/*
 * Author:Ram/v992473
 * This class serves as a row Mapper for SPGetCANDates. 
 */

public class GetCANDatesMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetCANDatesMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetCANDatesMapper - Mapping Row# "+rowNum);
		CANDatesInfo canInfo = null;
		if(rs!=null){
			canInfo = new CANDatesInfo();
			canInfo.setCANDate((Date)rs.getObject("BILL_DATE"));
			canInfo.setInvoiceNumber(trimSpace(rs.getString("INVOICE_NBR")));
		}
		return canInfo; 
	}
	
	//Trimmer to trim trailing spaces usually comes from VAC
	private String trimSpace(String input){
		return input!=null?input.trim():null;
	}
}
