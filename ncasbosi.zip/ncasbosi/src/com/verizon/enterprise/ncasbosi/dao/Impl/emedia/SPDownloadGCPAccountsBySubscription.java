package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDownloadGCPAccountsBySubscription extends BaseStoredProcedure {

	private static List spInOutList;

	static
	{
		spInOutList = SPInoutListAccounts_v10.getInoutListForAccount_v10(new DownloadGCPAccountsBySubscriptionRowMapperImpl());
	}
	
	public SPDownloadGCPAccountsBySubscription(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_GCP_ACCTS_BY_SUBSCRIPTION, spInOutList);
	}

	public Content executeStoredProcedure(String userId, String debugLevel,
											String serviceId, String wherePhrase, String sortOrder,
											String tokenString,String configSubsOid) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		if(serviceId == null ) {
			serviceId = "";
		}
		if(wherePhrase == null) {
			wherePhrase = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(tokenString == null) {
			tokenString = "";
		}
		// clearing out token_st for each call, so doesn't execute same 
		tokenString = "";

		paramValueList.add(serviceId);//SERVICE_ID
		paramValueList.add(configSubsOid);//SERVICE_ID
		paramValueList.add(wherePhrase);//WHERE_PHRASE
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(tokenString);//TOKEN_ST
		paramValueList.add("1");//PAGE_OFFSET
		paramValueList.add("10000");//PAGE_SIZE
		
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);		
		checkVACErrors(procMap);//call this method to identify any errors using the return code and throw exception accordingly 
		List actualList = (List)procMap.get("accounts");
		Content retObj = new Content();
		retObj.setRows(actualList);

		return retObj ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
