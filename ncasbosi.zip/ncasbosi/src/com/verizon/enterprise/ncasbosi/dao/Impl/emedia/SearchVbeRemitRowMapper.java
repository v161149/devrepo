package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.gbr.VbeRemitPoint;

public class SearchVbeRemitRowMapper implements RowMapper
{
	static private final Logger logger = Logger.getLogger(SearchVbeRemitRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "SearchVbeRemitRowMapper::mapRow() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		VbeRemitPoint vbeRemitPoint = null;

		if(rs != null)
		{
			vbeRemitPoint = new VbeRemitPoint();

			if(CommonUtil.isNotNull(rs.getString("CONFIG_SUBS_OID")))
			{
				vbeRemitPoint.setConfigSubsOid(rs.getString("CONFIG_SUBS_OID").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("REMIT_OID")))
			{
				vbeRemitPoint.setRemitOid(rs.getString("REMIT_OID").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("CONFIG_ID")))
			{
				vbeRemitPoint.setConfigId(rs.getString("CONFIG_ID").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("REMIT_ID")))
			{
				vbeRemitPoint.setRemitId(rs.getString("REMIT_ID").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("DEFAULT_REMIT")))
			{
				vbeRemitPoint.setDefaultRemit(rs.getString("DEFAULT_REMIT").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("REMIT_ACCTS")))
			{
				vbeRemitPoint.setRemitAccounts(rs.getInt("REMIT_ACCTS"));
			}

			if(CommonUtil.isNotNull(rs.getString("DEFLT_ACCTS")))
			{
				vbeRemitPoint.setDefaultAccounts (rs.getInt("DEFLT_ACCTS"));
			}

			if(CommonUtil.isNotNull(rs.getString("CONFIG_NAME")))
			{
				vbeRemitPoint.setRemitName(rs.getString("CONFIG_NAME").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("SERVICE_TYPE")))
			{
				vbeRemitPoint.setServiceType(rs.getString("SERVICE_TYPE").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("REMIT_START")))
			{
				vbeRemitPoint.setRemitStart(rs.getString("REMIT_START").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("REMIT_END")))
			{
				vbeRemitPoint.setRemitEnd(rs.getString("REMIT_END").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("LANGUAGE_CODE")))
			{
				vbeRemitPoint.setLanguage_code(rs.getString("LANGUAGE_CODE").trim());
			}

			if(CommonUtil.isNotNull(rs.getString("CURRENCY_CODE")))
			{
				vbeRemitPoint.setCurrency_code(rs.getString("CURRENCY_CODE").trim());
			}
		}

		return vbeRemitPoint;
	}
}
