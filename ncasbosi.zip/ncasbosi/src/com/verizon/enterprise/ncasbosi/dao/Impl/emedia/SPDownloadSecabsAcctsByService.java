package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Cell;

/**
 * @author v992473
 * This class represents the vam sp:SERVICE_SECABS_V10
 * This is used when downloading secabs accts by service
 *
 */
public class SPDownloadSecabsAcctsByService extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPDownloadSecabsAcctsByService.class);
	private static List<Object[]> spInOutList;
	
	static
	{
		 spInOutList = new ArrayList<Object[]>();		 
		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new DownloadSecabsAcctsByServiceRowMapperImpl()});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"SERVICE_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_STMT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_ID_TS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPDownloadSecabsAcctsByService(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_SECABS_ACCTS_BY_SUBSCRIPTION, spInOutList);	
	}
	
	public Content executeStoredProcedure(Map<String,Object> params) throws Exception{
		_LOGGER.info("Entering executeStoredProcedure");		
		String lineOffset = "1";
		String pageSize = "10000";
		String serviceId = (String)params.get("SERVICEID");
		String configSubsOid = (String)params.get("CONFIGSUBSOID");
		String wherePhrase =(String)params.get("FILTER");
		String sortOrder = (String)params.get("SORT");
		String tokenString = (String)params.get("CURSOR");
		
		if(serviceId == null ){
			serviceId = "";
		}
		if(wherePhrase == null){
			wherePhrase = "";
		}
		if(sortOrder == null){
			sortOrder = "";
		}
		if(tokenString == null){
			tokenString = "";
		}
		
		List<Object> paramValueList = new ArrayList<Object>();
		paramValueList.add(NCASBOSIConstants.VAM_USER_ID);//APP_USER_ID
		paramValueList.add(NCASBOSIConstants.VAM_DEBUG_LEVEL);//DEBUG_LEVEL		
		paramValueList.add(serviceId);//SERVICE_ID
		paramValueList.add(new BigDecimal(configSubsOid));//CONFIG_SUBS_OID
		paramValueList.add(wherePhrase);//WHERE_STMT
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(tokenString);//REPORT_ID_TS			
		paramValueList.add(Integer.valueOf(lineOffset));//LINE_OFFSET
		paramValueList.add(Integer.valueOf(pageSize));//PAGE_SIZE
		
		Map<String,Object> procMap = (HashMap)executeStoredProcedure(paramValueList);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(procMap);
		List<List<Cell>> actualList = (List)procMap.get("accounts");
		Content retObj = new Content();
		retObj.setRows(actualList);
		_LOGGER.info("Exiting executeStoredProcedure");
		return retObj;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
