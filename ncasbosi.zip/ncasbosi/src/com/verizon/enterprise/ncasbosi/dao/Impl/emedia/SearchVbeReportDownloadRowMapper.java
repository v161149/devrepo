package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;

public class SearchVbeReportDownloadRowMapper implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(SearchVbeReportDownloadRowMapper.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "SearchVbeReportDownloadRowMapper::extractData() ";

		logger.info(METHOD_NAME + "ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> reportList = new ArrayList<List<Cell>>();
		List<Cell> report = new ArrayList<Cell>();

		try
		{
			while(rs.next())
			{
				report = new ArrayList<Cell>();

				//report fields
				report.add(new Cell((val(rs.getString("CONFIG_SUBS_OID")))));  //col_1
				report.add(new Cell((val(rs.getString("CONFIG_ID")))));  //col_2
				report.add(new Cell((val(rs.getString("SERVICE_TYPE"))))); //col_3
				
				//report identity
				report.add(new Cell((val(rs.getString("REPORT_OID"))))); //col_4
				report.add(new Cell((val(rs.getString("REPORT_ID"))))); //col_5
				report.add(new Cell((val(rs.getString("REPORT_NAME"))))); //col_6
				report.add(new Cell((val(rs.getString("REPORT_START"))))); //col_7
				report.add(new Cell(val(rs.getString("REPORT_END")))); //col_8
				//report address
				report.add(new Cell((val(rs.getString("CUST_ADDR_TYPE"))))); //col_9
				report.add(new Cell((val(rs.getString("CUST_ADDR_1"))))); //col_10
				report.add(new Cell((val(rs.getString("CUST_ADDR_2"))))); //col_11
				report.add(new Cell((val(rs.getString("CUST_ADDR_3"))))); //col_12
				report.add(new Cell(val(rs.getString("CUST_CITY")))); //col_13
				report.add(new Cell((val(rs.getString("CUST_STATE"))))); //col_14
				report.add(new Cell((val(rs.getString("CUST_ZIP"))))); //col_15
				report.add(new Cell((val(rs.getString("POSTAL_CODE"))))); //col_16
				report.add(new Cell((val(rs.getString("CUST_COUNTRY"))))); //col_17
				//report fields
				report.add(new Cell((val(rs.getString("LANGUAGE_CODE"))))); //col_18
				report.add(new Cell((val(rs.getString("CURRENCY_CODE"))))); //col_19
				
				//node 
//				report.add(new Cell((val(rs.getString("NODE_TYPE"))))); //col_20
//				report.add(new Cell((val(rs.getString("PARENT_NODE_TYPE")))));  //col_21
				report.add(new Cell((val("NODE_TYPE")))); //col_20
				report.add(new Cell((val("PARENT_NODE_TYPE"))));  //col_21
				
				//remit
				report.add(new Cell((val(rs.getString("REMIT_OID"))))); //col_22
				report.add(new Cell((val(rs.getString("REMIT_ID"))))); //col_23
				report.add(new Cell((val(rs.getString("REMIT_NAME"))))); //col_24
				report.add(new Cell((val(rs.getString("DEFAULT_REMIT"))))); //col_25
				
				reportList.add(report);

				if(logger.isEnabledFor(Level.DEBUG))
				{
					logger.debug(METHOD_NAME + "report=" + report);
				}
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();

			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();

			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
		}

		if(logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + "reportList.size()=" + reportList.size());
		}

		return reportList;
	}
	
	private String val (String in)
	{
		if (in == null) in = "";
		in = in.trim();
		return commonUtil.excelTextValueOf(in);

	}
}
