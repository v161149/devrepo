package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.lang.Integer;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.gbr.VbeRemitPoint;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

// create a new remitPointOid, still need to call ManageVbeRemit after to populate the data
public class SPManageVbeRemit extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPManageVbeRemit.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ID",       getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME",     getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID",  getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REMIT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"DEFAULT_REMIT", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"USE_VBE_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CONFIG_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"USE_VBE_ADDRESS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_1", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_2", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ADDR_3", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_CITY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_STATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_ZIP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"POSTAL_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CUST_COUNTRY", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"LANGUAGE_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"CURRENCY_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAPER_STATUS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"NASP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"REVLOC_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"PAYMENT_DUE_INT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
	}

	public SPManageVbeRemit(DataSource dataSource)
	{
		super(dataSource, getVAMSchemaName() + "." + "MANAGE_VBE_REMIT", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception
	{

		_LOGGER.debug("entering SPGenerateVbeRemit executeStoredProcedure api");
		Map requestMap = (HashMap)input;
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		VbeRemitPoint remitPoint = (VbeRemitPoint) requestMap.get("remitPoint");

		String debugLevel = "0";

		List callList = new ArrayList();
		callList.add("esgportal"); // APP_USER_ID
		callList.add(remitPoint.getExtUpdtUserId()); // USER_ID
		callList.add(remitPoint.getExtUpdtUserName()); // USER_NAME
		callList.add(debugLevel);    // IN_DEBUG_LEVEL
		callList.add(new BigDecimal(remitPoint.getConfigSubsOid())); //CONFIG_SUBS_OID
		callList.add(new BigDecimal(remitPoint.getRemitOid())); //REMIT_OID
		callList.add((String) requestMap.get ("ACTION"));
		callList.add(remitPoint.getRemitStart ()); // START_DATE
		callList.add(remitPoint.getDefaultRemit()); // DEFAULT_REMIT
		callList.add(remitPoint.getUseVbeName ()); // USE_VBE_NAME
		callList.add(remitPoint.getRemitName ()); // CONFIG_NAME
		callList.add(remitPoint.getUseVbeAddress ()); // USE_VBE_ADDRESS
		callList.add(remitPoint.getCustAddrType ()); // CUST_ADDR_TYPE
		callList.add(remitPoint.getCustAddr1 ()); // CUST_ADDR_1
		callList.add(remitPoint.getCustAddr2 ()); // CUST_ADDR_2
		callList.add(remitPoint.getCustAddr3 ()); // CUST_ADDR_3
		callList.add(remitPoint.getCustCity ()); // CUST_CITY
		callList.add(remitPoint.getCustState ()); // CUST_STATE
		callList.add(remitPoint.getCustZip ()); // CUST_ZIP
		callList.add(remitPoint.getPostalCode ()); // POSTAL_CODE
		callList.add(remitPoint.getCustCountry ()); // CUST_COUNTRY
		callList.add(remitPoint.getLanguage_code ()); // LANGUAGE_CODE
		callList.add(remitPoint.getCurrency_code ()); // CURRENCY_CODE
		callList.add(remitPoint.getPaperStatus()); // PAPER_STATUS
		callList.add(remitPoint.getNaspId()); // NASP
		callList.add(remitPoint.getRevLoc()); // REVLOC
		callList.add(remitPoint.getPaymentDueInterval()); // PAYMENT_DUE_INT

		Map responseMap = executeSP(callList, false);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(responseMap, VAM);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
	}




}

