package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadGBRAccountsRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadGBRAccountsRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadGBRAccountsRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> accountsList = new ArrayList<List<Cell>>();
		List<Cell> account = new ArrayList<Cell>();
		
		try {
			while(rs.next()) {
				account = new ArrayList<Cell>();
	
				String corpId = rs.getString("CORP_ID");//Char(1)
				String acctNum = rs.getString("BAN");
				String banDan = rs.getString("BAN_DAN");
				String accountName = rs.getString("COMPANY_NAME");
				String gbrInvoiceType = rs.getString("GBR_INVOICE_TYPE");
				String gbrRegionName = rs.getString("GBR_REGION_NAME");
				String billingSystem = rs.getString("SYST_ABBREVIATION");
				String billPeriod = rs.getString("BP_DAY");
				String billingFrequency  = rs.getString("BILLING_FREQ");
				String manBillDate = rs.getString("MAN_BILL_DATE");
				
				// resultSet
				String man = rs.getString("MAN");
				String ban = rs.getString("BAN");
				String manDan = rs.getString("MAN_DAN");
				String origSysId = rs.getString("ORIG_SYSTEM_ID");
				String startBillPeriod = rs.getString("START_DATE");
				String endBillPeriod = rs.getString("END_DATE");
				String channelCode = rs.getString("LOB_IND");
				String acctStatus = rs.getString("ACCT_STATUS");
				String allBPInd = rs.getString("ALL_BILL_PAYER_IND");
				String allSubAcctInd = rs.getString("ALL_SUB_ACCT_IND");
				String enterpriseId = rs.getString("ENTERPRISE_ID");
				String configId = rs.getString("CONFIG_ID");
				String systemAbbrv = rs.getString("SYST_ABBREVIATION");
				String orgLevel1No = rs.getString("ORG_LEVEL1_NO");
				String orgLevel1Name = rs.getString("ORG_LEVEL1_NAME");
				String orgLevel2No = rs.getString("ORG_LEVEL2_NO");
				String orgLevel2Name = rs.getString("ORG_LEVEL2_NAME");
				
				if(CommonUtil.isNotNull(corpId)) {
					account.add(new Cell(commonUtil.excelTextValueOf(corpId.trim())));				
				}
						
/*	The bandan is not used in UI presentation - follow GbrComponent ( com.verizon.enterprise.common.ncas.gbr.GbrComponent)			
 * So the bandan logic below is removed - 5/31/10 - SJ
 * if(acctNum!=null && banDan!=null && acctNum.trim().equals(banDan.trim()))
				{
					if(CommonUtil.isNotNull(acctNum)) {
						account.add(new Cell(commonUtil.excelTextValueOf(acctNum.trim())));
					}
				}else {
					if(CommonUtil.isNotNull(acctNum)) {
						account.add(new Cell(commonUtil.excelTextValueOf(acctNum.trim() +" (" + (banDan!=null?banDan.trim():"") + ")")));
					}
				}*/
			
				if(CommonUtil.isNotNull(acctNum)) {
					account.add(new Cell(commonUtil.excelTextValueOf(acctNum.trim())));
				}
					
				if(CommonUtil.isNotNull(accountName)) {
					account.add(new Cell(commonUtil.excelTextValueOf(accountName.trim())));
				}
				
				if(CommonUtil.isNotNull(gbrInvoiceType)) {
					if (CommonUtil.isNotNull(gbrRegionName)){
						if (!(gbrRegionName.trim().isEmpty()))
							account.add(new Cell(gbrRegionName.trim() + "/" + gbrInvoiceType.trim()));
						else 
							account.add(new Cell(gbrInvoiceType.trim()));
					}else 
						account.add(new Cell(gbrInvoiceType.trim()));
				}

				if(CommonUtil.isNotNull(billingSystem)) {
					account.add(new Cell(commonUtil.excelTextValueOf(billingSystem.trim())));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
					account.add(new Cell(commonUtil.excelTextValueOf(billPeriod.trim())));
				}
				if(CommonUtil.isNotNull(billingFrequency)) {
					account.add(new Cell(commonUtil.excelTextValueOf(billingFrequency.trim())));
				}
				if(CommonUtil.isNotNull(manBillDate)) {
					//account.add(new Cell(commonUtil.excelTextValueOf(manBillDate.trim())));
					account.add(new Cell(CommonUtil.getDisplayDateFromString(manBillDate.trim())));
				}

				accountsList.add(account);
			}
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		}catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadGBRaccount's account  " + account);
		}
		return accountsList;
	}
}
