package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetIciAdjMapper implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetIciAdjMapper.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetIciAdjMapper::extractData() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";

		List returnList = new ArrayList();

		try
		{
			while(rs.next())
			{
				Map rowMap = new HashMap();

				//save result set values for the row into a map
				rowMap.put("VAC_ADJUST_ID", rs.getDouble("VAC_ADJUST_ID"));
				rowMap.put("INVOICE_NUM", trimIt(rs.getString("INVOICE_NUM")));
				rowMap.put("INVOICE_DT", trimIt(rs.getString("INVOICE_DT")));
				rowMap.put("FROM_DATE", trimIt(rs.getString("FROM_DATE")));
				rowMap.put("THRU_DATE", trimIt(rs.getString("THRU_DATE")));
				rowMap.put("ADJ_AMOUNT", rs.getDouble("ADJ_AMOUNT"));
				rowMap.put("ADJ_CREDIT_DEBIT", trimIt(rs.getString("ADJ_CREDIT_DEBIT")));
				rowMap.put("REASON_CD", trimIt(rs.getString("REASON_CD")));
				rowMap.put("REASON_DESC", trimIt(rs.getString("REASON_DESC")));
				rowMap.put("SUB_REASON_CD", trimIt(rs.getString("SUB_REASON_CD")));
				rowMap.put("SUB_REASON_DESC", trimIt(rs.getString("SUB_REASON_DESC")));
				rowMap.put("SVC_TYPE_CD", trimIt(rs.getString("SVC_TYPE_CD")));
				rowMap.put("SVC_TYPE_DESC", trimIt(rs.getString("SVC_TYPE_DESC")));
				rowMap.put("POSTING_LEVEL", trimIt(rs.getString("POSTING_LEVEL")));
				rowMap.put("LPC_IND", trimIt(rs.getString("LPC_IND")));
				rowMap.put("ADJ_CLASSIF_CODE", trimIt(rs.getString("ADJ_CLASSIF_CODE")));
				rowMap.put("ADJ_CLASSIF_DESC", trimIt(rs.getString("ADJ_CLASSIF_DESC")));
				rowMap.put("MISC_TYPE_DESC", trimIt(rs.getString("MISC_TYPE_DESC")));
				rowMap.put("POF", trimIt(rs.getString("POF")));
				rowMap.put("POE", trimIt(rs.getString("POE")));
				rowMap.put("REM", trimIt(rs.getString("REM")));
				rowMap.put("USOC", trimIt(rs.getString("USOC")));
				rowMap.put("PROD_GRP_DESC", trimIt(rs.getString("PROD_GRP_DESC")));
				rowMap.put("PROD_SUBGRP_DESC", trimIt(rs.getString("PROD_SUBGRP_DESC")));
				rowMap.put("ADJ_TAX_AMOUNT", rs.getDouble("ADJ_TAX_AMOUNT"));
				rowMap.put("ECP_BACKEND_SYS", trimIt(rs.getString("ECP_BACKEND_SYS")));
				rowMap.put("ADJ_STATUS_DESC", trimIt(rs.getString("ADJ_STATUS_DESC")));
				rowMap.put("ENTITY_CODE", trimIt(rs.getString("ENTITY_CODE")));
				rowMap.put("ENTITY_NM", trimIt(rs.getString("ENTITY_NM")));

				
				//reformat decimal and date fields 
				rowMap.put("String_VAC_ADJUST_ID", CommonUtil.formatDouble(rs.getDouble("VAC_ADJUST_ID")));
				rowMap.put("String_ADJ_AMOUNT", CommonUtil.formatDouble(rs.getDouble("ADJ_AMOUNT")));
				rowMap.put("MMddyyyy_INVOICE_DT", CommonUtil.formatDate(rs.getString("INVOICE_DT"), formatDb2, formatDisplayed));
				rowMap.put("MMddyyyy_FROM_DATE", CommonUtil.formatDate(rs.getString("FROM_DATE"), formatDb2, formatDisplayed));
				rowMap.put("MMddyyyy_THRU_DATE", CommonUtil.formatDate(rs.getString("THRU_DATE"), formatDb2, formatDisplayed));
				rowMap.put("String_ADJ_TAX_AMOUNT", CommonUtil.formatDouble(rs.getDouble("ADJ_TAX_AMOUNT")));
				
				//add the rowMap to the list
				returnList.add(rowMap);
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();
			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			throw nfe;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + ex.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + ex.getMessage());
		}

		return returnList;
	}
	
	private String trimIt(String in)
	{
		if (in == null) return null;
		return in.trim();
		
	}
	
}

