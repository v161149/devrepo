package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.adjustments.AdjustmentDetails;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAdjustmentsByIdRowMapperImpl implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(GetAdjustmentsByIdRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "GetAdjustmentsByIdRowMapperImpl::extractData() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		CommonUtil.printMetaDataInfo(rs.getMetaData());

		List adjustmentsList = new ArrayList();
		AdjustmentDetails adjustmentDetailsRecord = null;
		try{
			while(rs.next()) {
				adjustmentDetailsRecord = new AdjustmentDetails();
				String adjustmentId = rs.getString("VAC_ADJUST_ID");
				String man = rs.getString("MAN");
				String ban = rs.getString("BAN");
				String irbBan = rs.getString("IRB_BAN");
				String aban = rs.getString("ABAN");
				String childBan = rs.getString("CHILD_BAN");
				String osid = rs.getString("ORIGINATING_SYS_ID");
				String adjustmentLevel = rs.getString("ADJ_LEVEL");
				String adjustmentAmount = rs.getString("ADJ_AMOUNT");
				String adjustmentTaxAmount = rs.getString("ADJ_TAX_AMOUNT");
				String existingAdjustmentAmount = rs.getString("EXIST_ADJ_AMOUNT");
				String adjustmentCreditDebit = rs.getString("ADJ_CREDIT_DEBIT");
				String adjustmentStatus = rs.getString("ADJ_STATUS");
				String circuit = rs.getString("CIRCUIT");
				String wtn = rs.getString("WTN");
				String billedAmount = rs.getString("BILLED_AMOUNT");
				String billDate = rs.getString("BILL_DATE");
				String originatorLoginId = rs.getString("ORIGINATOR_LOGINID");
				String adjustmentSubDate = rs.getString("ADJ_SUB_DATE");
				String adjustmentClassificationCode = rs.getString("ADJ_CLASSIF_CODE");
				String adjustmentStatusChangeDate = rs.getString("ADJ_STATUS_CHG_DT");
				String adjustmentReasonCode = rs.getString("ADJ_REASON_CODE");
				String geoCode = rs.getString("GEO_CODE");
				String taxLocation = rs.getString("TAX_LCTN_Y");
				String vz450OccCategory = rs.getString("VZ450_OCC_CAT");
				String vz450RecordNumber = rs.getString("VZ450_RECORD_NBR");
				String pof = rs.getString("POF");
				String poe = rs.getString("POE");
				String rem = rs.getString("REM");
				String taxPof = rs.getString("TAX_POF");
				String taxPoe = rs.getString("TAX_POE");
				String taxRem = rs.getString("TAX_REM");
				String balanceTypeCdoe = rs.getString("BALANCE_TYPE_CODE");
				String usoc = rs.getString("USOC");
				String rao = rs.getString("RAO");
				String productDescription = rs.getString("PRODUCT_DESC");
				String channelCode = rs.getString("CHANNEL_CODE");
				String channelSubCode = rs.getString("CHANNEL_SUB_CODE");
				String custLineType = rs.getString("CUST_LINE_TYPE");
				String entityCode = rs.getString("ENTITY_CODE");
				String chargeType = rs.getString("CHARGE_TYPE");
				String returnCode = rs.getString("RETURN_CODE");
				String returnDesc = rs.getString("RETURN_DESC");
				String classOfServType = rs.getString("CLASS_OF_SERV_TYPE");
				String taxExemptionIndicator = rs.getString("TAX_EXEMPT_IND");
				String state = rs.getString("STATE");
				String prodJurisdiction = rs.getString("PROD_JURISDICTION");
				String taxDeterminant = rs.getString("TAX_DETERMINANT");
				String taxAppliedIndicator = rs.getString("TAX_APPLIED_IND");
				String fractionalNumberOfDays = rs.getString("FRACTIONAL_NO_DAYS");
				String callMinutes = rs.getString("CALL_MINS");
				String callSeconds = rs.getString("CALL_SECS");
				String vendorId = rs.getString("VENDOR_ID");
				String emiCategory = rs.getString("EMI_CATEGORY");
				String emiGroup = rs.getString("EMI_GROUP");
				String emiRecordType = rs.getString("EMI_RECORD_TYPE");
				String sensorId = rs.getString("SENSOR_ID");
				String termCity = rs.getString("TERM_CITY");
				String termState = rs.getString("TERM_STATE");
				String callDate = rs.getString("CALL_DATE");
				String startTime = rs.getString("START_TIME");
				String toNPA = rs.getString("TO_NPA");
				String toNXX = rs.getString("TO_NXX");
				String toLineNumber = rs.getString("TO_LINE_NUMBER");
				String msgRatePeriod = rs.getString("MSG_RATE_PERIOD");
				String rateClass = rs.getString("RATE_CLASS");
				String settlementCode = rs.getString("SETTLEMENT_CODE");
				String intlFromNumber = rs.getString("INTL_FROM_NUMBER");
				String intlToNumber = rs.getString("INTL_TO_NUMBER");
				String fromNPA = rs.getString("FROM_NPA");
				String fromNXX = rs.getString("FROM_NXX");
				String fromLineNumber = rs.getString("FROM_LINE_NUMBER");
				String additionalReasonCode = rs.getString("ADDL_REASON_CODE");
				String taxStatusFed = rs.getString("TAX_STATUS_FED");
				String taxStatusState = rs.getString("TAX_STATUS_STATE");
				String taxStatusE911 = rs.getString("TAX_STATUS_E911");
				String taxStatusSurcharge = rs.getString("TAX_STATUS_SURCH");
				String taxStatusLocal = rs.getString("TAX_STATUS_LOCAL");
				String acctTypeCode = rs.getString("ACCT_TYPE_CD");
				String emrTaxExemptIndicator = rs.getString("EMR_TAX_EXEMPT_IND");
				String taxEngineCode = rs.getString("TAX_ENGINE_CODE");
				String companyCode = rs.getString("COMPANY_CODE");
				String databaseSegID = rs.getString("DATABASE_SEG_ID");
				String taxEngineProdIndicator = rs.getString("TAX_ENG_PROD_IND");
				String adjustmentType = rs.getString("ADJ_TYPE");
				String taxGroupId = rs.getString("TAX_GROUP_ID");
				String numberOfMonths = rs.getString("NO_OF_MONTHS");
				String adjustmentInterestAmount = rs.getString("ADJ_INTEREST_AMT");
				String numberOfDays = rs.getString("NO_OF_DAYS");
				String extendedBilledAmount = rs.getString("EXT_BILLED_AMT");
				String perMonthAdjustmentAmount = rs.getString("PER_MONTH_ADJ_AMT");
				String accountStatus = rs.getString("ACCT_STATUS");
				String writeOffIndicator = rs.getString("WRITEOFF_IND");

				if(CommonUtil.isNotNull(adjustmentId)) {
					adjustmentDetailsRecord.setAdjustmentId(adjustmentId.trim());
				}
				if(CommonUtil.isNotNull(man)) {
					adjustmentDetailsRecord.setMan(man.trim());
				}
				if(CommonUtil.isNotNull(ban)) {
					adjustmentDetailsRecord.setBan(ban.trim());
				}
				if(CommonUtil.isNotNull(irbBan)) {
					adjustmentDetailsRecord.setIrbBan(irbBan.trim());
				}
				if(CommonUtil.isNotNull(aban)) {
					adjustmentDetailsRecord.setAban(aban.trim());
				}
				if(CommonUtil.isNotNull(childBan)) {
					adjustmentDetailsRecord.setChildBan(childBan.trim());
				}
				if(CommonUtil.isNotNull(osid)) {
					adjustmentDetailsRecord.setOsid(osid.trim());
				}
				if(CommonUtil.isNotNull(adjustmentLevel)) {
					adjustmentDetailsRecord.setAdjustmentLevel(adjustmentLevel.trim());
				}
				if(CommonUtil.isNotNull(adjustmentAmount)) {
					adjustmentDetailsRecord.setAdjustmentAmount(adjustmentAmount.trim());
				}
				if(CommonUtil.isNotNull(adjustmentTaxAmount)) {
					adjustmentDetailsRecord.setAdjustmentTaxAmount(adjustmentTaxAmount.trim());
				}
				if(CommonUtil.isNotNull(existingAdjustmentAmount)) {
					adjustmentDetailsRecord.setExistingAdjustmentAmount(existingAdjustmentAmount.trim());
				}
				if(CommonUtil.isNotNull(adjustmentCreditDebit)) {
					adjustmentDetailsRecord.setAdjustmentCreditDebit(adjustmentCreditDebit.trim());
				}
				if(CommonUtil.isNotNull(adjustmentStatus)) {
					adjustmentDetailsRecord.setAdjustmentStatus(adjustmentStatus.trim());
				}
				if(CommonUtil.isNotNull(circuit)){
					adjustmentDetailsRecord.setCircuit(circuit.trim());
				}
				if(CommonUtil.isNotNull(wtn)) {
					adjustmentDetailsRecord.setWtn(wtn.trim());
				}
				if(CommonUtil.isNotNull(billedAmount)) {
					adjustmentDetailsRecord.setBilledAmount(billedAmount.trim());
				}
				if(CommonUtil.isNotNull(billDate)) {
					adjustmentDetailsRecord.setBillDate(billDate.trim());
				}
				if(CommonUtil.isNotNull(originatorLoginId)) {
					adjustmentDetailsRecord.setOriginatorLoginId(originatorLoginId.trim());
				}
				if(CommonUtil.isNotNull(adjustmentSubDate)) {
					adjustmentDetailsRecord.setAdjustmentSubDate(adjustmentSubDate.trim());
				}
				if(CommonUtil.isNotNull(adjustmentClassificationCode)) {
					adjustmentDetailsRecord.setAdjustmentClassificationCode(adjustmentClassificationCode.trim());
				}
				if(CommonUtil.isNotNull(adjustmentStatusChangeDate)) {
					adjustmentDetailsRecord.setAdjustmentStatusChangeDate(adjustmentStatusChangeDate.trim());
				}
				if(CommonUtil.isNotNull(adjustmentReasonCode)) {
					adjustmentDetailsRecord.setAdjustmentReasonCode(adjustmentReasonCode.trim());
				}
				if(CommonUtil.isNotNull(geoCode)) {
					adjustmentDetailsRecord.setGeoCode(geoCode.trim());
				}
				if(CommonUtil.isNotNull(taxLocation)) {
					adjustmentDetailsRecord.setTaxLocation(taxLocation.trim());
				}
				if(CommonUtil.isNotNull(vz450OccCategory)) {
					adjustmentDetailsRecord.setVz450OccCategory(vz450OccCategory.trim());
				}
				if(CommonUtil.isNotNull(vz450RecordNumber)) {
					adjustmentDetailsRecord.setVz450RecordNumber(vz450RecordNumber.trim());
				}
				if(CommonUtil.isNotNull(pof)) {
					adjustmentDetailsRecord.setPof(pof.trim());
				}
				if(CommonUtil.isNotNull(poe)) {
					adjustmentDetailsRecord.setPoe(poe.trim());
				}
				if(CommonUtil.isNotNull(rem)) {
					adjustmentDetailsRecord.setRem(rem.trim());
				}
				if(CommonUtil.isNotNull(taxPof)) {
					adjustmentDetailsRecord.setTaxPof(taxPof.trim());
				}
				if(CommonUtil.isNotNull(taxPoe)) {
					adjustmentDetailsRecord.setTaxPoe(taxPoe.trim());
				}
				if(CommonUtil.isNotNull(taxRem)) {
					adjustmentDetailsRecord.setTaxRem(taxRem.trim());
				}
				if(CommonUtil.isNotNull(balanceTypeCdoe)) {
					adjustmentDetailsRecord.setBalanceTypeCdoe(balanceTypeCdoe.trim());
				}
				if(CommonUtil.isNotNull(usoc)) {
					adjustmentDetailsRecord.setUsoc(usoc.trim());
				}
				if(CommonUtil.isNotNull(rao)) {
					adjustmentDetailsRecord.setRao(rao.trim());
				}
				if(CommonUtil.isNotNull(productDescription)) {
					adjustmentDetailsRecord.setProductDescription(productDescription.trim());
				}
				if(CommonUtil.isNotNull(channelCode)) {
					adjustmentDetailsRecord.setChannelCode(channelCode.trim());
				}
				if(CommonUtil.isNotNull(channelSubCode)) {
					adjustmentDetailsRecord.setChannelSubCode(channelSubCode.trim());
				}
				if(CommonUtil.isNotNull(custLineType)) {
					adjustmentDetailsRecord.setCustLineType(custLineType.trim());
				}
				if(CommonUtil.isNotNull(entityCode)) {
					adjustmentDetailsRecord.setEntityCode(entityCode.trim());
				}
				if(CommonUtil.isNotNull(chargeType)) {
					adjustmentDetailsRecord.setChargeType(chargeType.trim());
				}
				if(CommonUtil.isNotNull(returnCode)) {
					adjustmentDetailsRecord.setReturnCode(returnCode.trim());
				}
				if(CommonUtil.isNotNull(returnDesc)) {
					adjustmentDetailsRecord.setReturnDesc(returnDesc.trim());
				}
				if(CommonUtil.isNotNull(classOfServType)) {
					adjustmentDetailsRecord.setClassOfServiceType(classOfServType.trim());
				}
				if(CommonUtil.isNotNull(taxExemptionIndicator)) {
					adjustmentDetailsRecord.setTaxExemptionIndicator(taxExemptionIndicator.trim());
				}
				if(CommonUtil.isNotNull(state)) {
					adjustmentDetailsRecord.setState(state.trim());
				}
				if(CommonUtil.isNotNull(prodJurisdiction)) {
					adjustmentDetailsRecord.setProdJurisdiction(prodJurisdiction.trim());
				}
				if(CommonUtil.isNotNull(taxDeterminant)) {
					adjustmentDetailsRecord.setTaxDeterminant(taxDeterminant.trim());
				}
				if(CommonUtil.isNotNull(taxAppliedIndicator)) {
					adjustmentDetailsRecord.setTaxAppliedIndicator(taxAppliedIndicator.trim());
				}
				if(CommonUtil.isNotNull(fractionalNumberOfDays)) {
					adjustmentDetailsRecord.setFractionalNumberOfDays(fractionalNumberOfDays.trim());
				}
				if(CommonUtil.isNotNull(callMinutes)) {
					adjustmentDetailsRecord.setCallMinutes(callMinutes.trim());
				}
				if(CommonUtil.isNotNull(callSeconds)) {
					adjustmentDetailsRecord.setCallSeconds(callSeconds.trim());
				}
				if(CommonUtil.isNotNull(vendorId)) {
					adjustmentDetailsRecord.setVendorID(vendorId.trim());
				}
				if(CommonUtil.isNotNull(emiCategory)) {
					adjustmentDetailsRecord.setEmiCategory(emiCategory.trim());
				}
				if(CommonUtil.isNotNull(emiGroup)) {
					adjustmentDetailsRecord.setEmiGroup(emiGroup.trim());
				}
				if(CommonUtil.isNotNull(emiRecordType)) {
					adjustmentDetailsRecord.setEmiRecordType(emiRecordType.trim());
				}
				if(CommonUtil.isNotNull(sensorId)) {
					adjustmentDetailsRecord.setSensorId(sensorId.trim());
				}
				if(CommonUtil.isNotNull(termCity)) {
					adjustmentDetailsRecord.setTermCity(termCity.trim());
				}
				if(CommonUtil.isNotNull(termState)) {
					adjustmentDetailsRecord.setTermState(termState.trim());
				}
				if(CommonUtil.isNotNull(callDate)) {
					adjustmentDetailsRecord.setCallDate(callDate.trim());
				}
				if(CommonUtil.isNotNull(startTime)) {
					adjustmentDetailsRecord.setStartTime(startTime.trim());
				}
				if(CommonUtil.isNotNull(toNPA)) {
					adjustmentDetailsRecord.setToNPA(toNPA.trim());
				}
				if(CommonUtil.isNotNull(toNXX)) {
					adjustmentDetailsRecord.setToNXX(toNXX.trim());
				}
				if(CommonUtil.isNotNull(toLineNumber)) {
					adjustmentDetailsRecord.setToLineNumber(toLineNumber.trim());
				}
				if(CommonUtil.isNotNull(msgRatePeriod)) {
					adjustmentDetailsRecord.setMsgRatePeriod(msgRatePeriod.trim());
				}
				if(CommonUtil.isNotNull(rateClass)) {
					adjustmentDetailsRecord.setRateClass(rateClass.trim());
				}
				if(CommonUtil.isNotNull(settlementCode)) {
					adjustmentDetailsRecord.setSettlementCode(settlementCode.trim());
				}
				if(CommonUtil.isNotNull(intlFromNumber)) {
					adjustmentDetailsRecord.setIntlFromNumber(intlFromNumber.trim());
				}
				if(CommonUtil.isNotNull(intlToNumber)) {
					adjustmentDetailsRecord.setIntlToNumber(intlToNumber.trim());
				}
				if(CommonUtil.isNotNull(fromNPA)) {
					adjustmentDetailsRecord.setFromNPA(fromNPA.trim());
				}
				if(CommonUtil.isNotNull(fromNXX)) {
					adjustmentDetailsRecord.setFromNXX(fromNXX.trim());
				}
				if(CommonUtil.isNotNull(fromLineNumber)) {
					adjustmentDetailsRecord.setFromLineNumber(fromLineNumber.trim());
				}
				if(CommonUtil.isNotNull(additionalReasonCode)) {
					adjustmentDetailsRecord.setAdditionalReasonCode(additionalReasonCode.trim());
				}
				if(CommonUtil.isNotNull(taxStatusFed)) {
					adjustmentDetailsRecord.setTaxStatusFed(taxStatusFed.trim());
				}
				if(CommonUtil.isNotNull(taxStatusState)) {
					adjustmentDetailsRecord.setTaxStatusState(taxStatusState.trim());
				}
				if(CommonUtil.isNotNull(taxStatusE911)) {
					adjustmentDetailsRecord.setTaxStatusE911(taxStatusE911.trim());
				}
				if(CommonUtil.isNotNull(taxStatusSurcharge)) {
					adjustmentDetailsRecord.setTaxStatusSurcharge(taxStatusSurcharge.trim());
				}
				if(CommonUtil.isNotNull(taxStatusLocal)) {
					adjustmentDetailsRecord.setTaxStatusLocal(taxStatusLocal.trim());
				}
				if(CommonUtil.isNotNull(acctTypeCode)) {
					adjustmentDetailsRecord.setAccountTypeCode(acctTypeCode.trim());
				}
				if(CommonUtil.isNotNull(emrTaxExemptIndicator)) {
					adjustmentDetailsRecord.setEmrTaxExemptIndicator(emrTaxExemptIndicator.trim());
				}
				if(CommonUtil.isNotNull(taxEngineCode)) {
					adjustmentDetailsRecord.setTaxEngineCode(taxEngineCode.trim());
				}
				if(CommonUtil.isNotNull(companyCode)) {
					adjustmentDetailsRecord.setCompanyCode(companyCode.trim());
				}
				if(CommonUtil.isNotNull(databaseSegID)) {
					adjustmentDetailsRecord.setDatabaseSegID(databaseSegID.trim());
				}
				if(CommonUtil.isNotNull(taxEngineProdIndicator)) {
					adjustmentDetailsRecord.setTaxEngineProdIndicator(taxEngineProdIndicator.trim());
				}
				if(CommonUtil.isNotNull(adjustmentType)) {
					adjustmentDetailsRecord.setAdjustmentType(adjustmentType.trim());
				}
				if(CommonUtil.isNotNull(taxGroupId)) {
					adjustmentDetailsRecord.setTaxGroupId(taxGroupId.trim());
				}
				if(CommonUtil.isNotNull(numberOfMonths)) {
					adjustmentDetailsRecord.setNumberOfMonths(numberOfMonths.trim());
				}

				if(CommonUtil.isNotNull(adjustmentInterestAmount))
				{
					adjustmentDetailsRecord.setAdjustmentInterestAmount(adjustmentInterestAmount.trim());
				}

				if(CommonUtil.isNotNull(numberOfDays))
				{
					adjustmentDetailsRecord.setNumberOfDays(numberOfDays.trim());
				}

				if(CommonUtil.isNotNull(extendedBilledAmount))
				{
					adjustmentDetailsRecord.setExtendedBilledAmount(extendedBilledAmount.trim());
				}

				if(CommonUtil.isNotNull(perMonthAdjustmentAmount))
				{
					adjustmentDetailsRecord.setPerMonthAdjustmentAmount(perMonthAdjustmentAmount.trim());
				}

				if(CommonUtil.isNotNull(accountStatus))
				{
					adjustmentDetailsRecord.setAccountStatus(accountStatus.trim());
				}

				if(CommonUtil.isNotNull(writeOffIndicator))
				{
					adjustmentDetailsRecord.setWriteOffIndicator(writeOffIndicator.trim());
				}

				//finally add the adjustmentDetailsRecord to the list
				adjustmentsList.add(adjustmentDetailsRecord);
			}
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			logger.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			throw nfe;
		}catch(Exception ex) {
			ex.printStackTrace();
			logger.debug("Exception occured while parsing the resultset \n"+ex.getMessage());
			logger.error("Exception occured while parsing the resultset \n"+ex.getMessage());
		}
		return adjustmentsList;
	}
}
