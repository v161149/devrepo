package com.verizon.enterprise.ncasbosi.dao.Impl.reports;

import java.io.Serializable;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.exception.NCASException;

public class SPGetCustomPageId extends BaseStoredProcedure
{
	static private final Logger _LOGGER = Logger.getLogger(SPGetCustomPageId.class);

	private static List spInOutList;

	static
	{
		spInOutList = new ArrayList();

		spInOutList.add(new Object[]{"IN_DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"OUT_PAGE_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"OUT_MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetCustomPageId(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_CUST_PAGE_ID, spInOutList);
	}

	public Map executeStoredProcedure(String debugLevel) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(debugLevel);//DEBUG_SW
		Map spResult = executeStoredProcedure(paramValueList);
		int returnCode = ((Integer)spResult.get("RETURN_CODE")).intValue();
		if (returnCode > 0)
		{
			String msgString = (String)spResult.get("OUT_MSG_STRING");
			String[] errMsg = new String[3];
			errMsg[0] = "getCustomPageId";
			errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_CUST_PAGE_ID;
			errMsg[2] = msgString;
			throw new NCASException(NCASBOSIConstants.ERROR_VAM, errMsg, returnCode);
		}
		String pageId = Integer.toString((Integer)spResult.get("OUT_PAGE_ID"));
		Map result = new HashMap();
		result.put("PAGE_ID", pageId);
		return result;
	}

	protected Map executeStoredProcedure(Object paramValues) throws Exception
	{
		List paramValueList = (List)paramValues;
		return executeSP(paramValueList, false);
	}
}

