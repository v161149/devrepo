package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author v992473
 * This class is used to count the number of eligible accounts from candidate apis(SERVICE_GCP_V10,SUMMARY_GCP_V10,CORP_GCP_V10)
 * 
 */
public class SPCandidateEligibleAccountsCount extends BaseStoredProcedure{
	
	private static final Logger _LOGGER = Logger.getLogger(SPCandidateEligibleAccountsCount.class);
	private String candidateApiName;
	public SPCandidateEligibleAccountsCount(DataSource dataSource, String schemaName,String candidateApiName) {
		super(dataSource, schemaName + "." + candidateApiName, SPInoutListAccounts_v10.getInoutListForAccount_v10(candidateApiName));
		this.candidateApiName = candidateApiName;
	}
	
	public Map<String,Object> executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return (Map<String,Object>)executeSP(paramValueList, false);
	}
	
	//this method is for SUMMARY_GCP_V10 & CORP_GCP_V10
	public Map<String,Integer> executeStoredProcedure(String userId, String debugLevel,String customerNo, String customerType,String whereFilter, String sortOrder,String tokenString, Pagination pagination,String configSubsOid) throws Exception
	{
		List<Object> paramValueList = getInputValueList(userId, debugLevel, customerNo, customerType, whereFilter, sortOrder, tokenString, pagination, configSubsOid, null);
		Map<String,Object> procMap = (HashMap<String,Object>)executeStoredProcedure(paramValueList);
		checkErrors(procMap);
		Map<String,Integer> outMap = new HashMap<String,Integer>();
		outMap.put("ELIGIBLE_ACCOUNTS_COUNT", (Integer)procMap.get("TOTAL_ROWS"));
		return outMap;
	}
	
	//this method is for SERVICE_GCP_V10
	public Map<String,Integer> executeStoredProcedure(String userId, String debugLevel,String serviceId, String wherePhrase, String sortOrder,String tokenString, Pagination pagination,String configSubsOid) throws Exception
	{
		List<Object> paramValueList = getInputValueList(userId, debugLevel, null, null, wherePhrase, sortOrder, tokenString, pagination, configSubsOid, serviceId);
		Map<String,Object> procMap = (HashMap<String,Object>)executeStoredProcedure(paramValueList);
		checkErrors(procMap);
		Map<String,Integer> outMap = new HashMap<String,Integer>();
		outMap.put("ELIGIBLE_ACCOUNTS_COUNT", (Integer)procMap.get("TOTAL_ROWS"));
		return outMap;
	}
	
	private void checkErrors(Map<String,Object> resMap)throws Exception{
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		_LOGGER.info("Printing the response Map::"+resMap);
	}
	
	private List<Object> getInputValueList(String userId, String debugLevel,String customerNo, String customerType,String whereFilter, String sortOrder,String tokenString, Pagination pagination,String configSubsOid,String serviceId)
	{
		List<Object> paramValueList = new ArrayList<Object>();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		
		if(NCASBOSIConstants.SP_GET_GCP_ACCTS_BY_SUBSCRIPTION.equalsIgnoreCase(this.candidateApiName)){
			if(serviceId == null ) {
				serviceId = "";
			}
			paramValueList.add(serviceId);//SERVICE_ID
		}else{
			//for SUMMARY_GCP_V10 and CORP_GCP_V10
			if(customerNo == null ) {
				customerNo = "";
			}
			if(customerType == null) {
				customerType = "";
			}
			paramValueList.add(customerNo);//CUST_NO
			paramValueList.add(customerType);//CUSTOMER_TYPE
		}
		
		if(whereFilter == null) {
			whereFilter = "";
		}
		whereFilter = whereFilter.trim();
		whereFilter = whereFilter.length()>0?whereFilter+" AND ELIGIBILITY_IND='01'":"ELIGIBILITY_IND='01'";
		
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(tokenString == null) {
			tokenString = "";
		}
		// clearing out token_st for each call, so doesn't execute same 
		tokenString = "";
		
		
		paramValueList.add(configSubsOid);//CONFIG_SUBS_OID
		paramValueList.add(whereFilter);//WHERE_PHRASE
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(tokenString);//TOKEN_ST

		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();

		if(pagination.isAllSelect()){
			lineOffSet = "1";
			pageSize = pagination.getMaxSize();
		}else{
			if(lineOffSet==null) {
				lineOffSet = "1";
			}
			if(pageSize==null) {
				pageSize = "50";
			}
		}

		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE
		return paramValueList;
	}
}
