package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.autocredit.BillingElement;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

/*
 * Author:Ram/v992473
 */

public class GetBillElementsMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetBillElementsMapper.class);
	private String osId;//osId passed from SPGetBillElements to determine whether to populate serviceId or not
	private String serviceId;//serviceId passed from SPGetBillElements
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.info("GetBillElementsMapper - Mapping Row# "+rowNum);
		BillingElement be = null;
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";

		if(rs!=null){
			be = new BillingElement();

			be.setInvDate(CommonUtil.formatDate(rs.getString("BILL_DATE"), formatDb2, formatDisplayed));
			be.setInvNbr(rs.getString("INVOICE_NBR"));
			be.setCircuitId(rs.getString("CIRCUIT_ID"));
			be.setDescription(rs.getString("CHG_DESC"));
			be.setFromDate(CommonUtil.formatDate(rs.getString("FROM_DATE"), formatDb2, formatDisplayed));
			be.setThruDate(CommonUtil.formatDate(rs.getString("THRU_DATE"), formatDb2, formatDisplayed));
			be.setCharge(CommonUtil.formatDouble(rs.getDouble("CHARGE_AMT")));
			be.setEstDiscounts(CommonUtil.formatDouble(rs.getDouble("DISC_AMT")));
			be.setEstTaxes(CommonUtil.formatDouble(rs.getDouble("TAX_AMT")));
			be.setLatePayCharge(rs.getString("CHG_TYPE_CD"));  // M for monthly charge, P for promotion, D for discount
			
			//populating the serviceId based on osId
			_LOGGER.info("osId::"+osId);
			_LOGGER.info("serviceId::"+serviceId);
			if(NcasConstants.IBRS.equalsIgnoreCase(osId) || NcasConstants.VISION.equalsIgnoreCase(osId)){
				be.setServiceId(serviceId);
				be.setServiceIdDisplay(serviceId);
				//circuit id is already populated - we go with whatever VAM gives us.
			}else if(NcasConstants.IXPLUS.equalsIgnoreCase(osId)){
				be.setServiceId(serviceId);//the id we used to do search
				be.setServiceIdDisplay("");//not populated for IXPLUS
				be.setCircuitId(serviceId);//overriding the already populated circuit id with the id used to do search
			}
		}
		return be;
	}
	
	public String getOsId() {
		return osId;
	}
	public void setOsId(String osId) {
		this.osId = osId;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
}
