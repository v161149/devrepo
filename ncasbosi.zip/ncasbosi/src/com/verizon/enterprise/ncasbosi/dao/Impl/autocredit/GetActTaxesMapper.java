package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.ActTaxesInfo;

/**
 * @author v898809/Arun Karthick P 
 * This class gets the complete resultset of GET_ACT_TAXES and
 * populates in ActTaxesInfo object.
 * 
 */
public class GetActTaxesMapper implements RowMapper
{
    private final Logger _LOGGER = Logger.getLogger(this.getClass());

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
        _LOGGER.info("GetActTaxesMapper - Mapping Row# "+rowNum);
        ActTaxesInfo acttax = null;
        if(rs!=null){
            acttax = new ActTaxesInfo();
            acttax.setManbilldate(((Date)rs.getObject("MAN_BILL_DATE")));
            acttax.setInvoiceNBR(trimSpace(rs.getString("INVOICE_NBR")));
            acttax.setTextValue(trimSpace(rs.getString("TEXT_VALUE")));
            acttax.setTaxtype(trimSpace(rs.getString("TAX_TYPE_CD")));
            acttax.setTaxphrase(trimSpace(rs.getString("TEXT_PHRASE_CD")));
            acttax.setTaxAmt((rs.getBigDecimal("TAX_AMT")));
        }
        return acttax; 
    }
    
    //Space Trimmer
    private String trimSpace(String input){
        return input!=null?input.trim():null;
    }
}