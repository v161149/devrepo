package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.HashMap;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.NCASSpringJDBCBase;
import com.verizon.enterprise.ncasbosi.dao.Impl.vbif.SPGetTicketDropDowns;
import com.verizon.enterprise.ncasbosi.dao.Interface.common.VacDropDownsInterface;

/*
 * Author:Ram/v992473
 */

public class VacDropDownsDAOImpl extends NCASSpringJDBCBase implements VacDropDownsInterface{

	static private final Logger _LOGGER = Logger.getLogger(VacDropDownsDAOImpl.class);
	private JdbcTemplate vamJdbcTemplate;//jdbctemplate created for VAM dataSource
										 //this template may be used for future - standalone SQL queries and etc.

	public void setVAMDataSource(DataSource dataSource){
		vamJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[VAMjdbcTemplate datasource set ]");
	}

	public DataSource getVAMDataSource(){
		return vamJdbcTemplate.getDataSource();
	}


	public Map getDropDownValues(Object input)throws NCASException{
		String dropDownName = null;
		if(input instanceof String){
			dropDownName = (String)input;
		}else if(input instanceof Map){
			dropDownName = (String)((Map)input).get(NcasConstants.DROP_DOWN_NAME);
		}
		_LOGGER.info("getDropDownValues::"+input);

		Map responseMap = null;
		try{
			if(NcasConstants.DROP_DOWN_AREA_OF_ORIGINATION_VZB.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROP_DOWN_OVERALL_CATEGORY__VZB.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROP_DOWN_SERVICE_CENTER.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROP_DOWN_RESPONSIBLE_ORG_VZB.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROP_DOWN_POSTING_LEVEL.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROP_DOWN_SERVICE_CENTER_ACT.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROPDOWN_TAX_TYPE.equalsIgnoreCase(dropDownName) ||
			   NcasConstants.DROPDOWN_STATE_CODE.equalsIgnoreCase(dropDownName) ) {
				 responseMap = new SPGetClaimDropDown(getDataSource()).executeStoredProcedure(dropDownName);
			}else if(NcasConstants.DROP_DOWN_ROOT_CAUSE.equalsIgnoreCase(dropDownName)){
				responseMap = new SPGetClaimRootCauseDropDown(getDataSource()).executeStoredProcedure(null);
			}else if(NcasConstants.DROP_DOWN_SUB_ROOT_CAUSE.equalsIgnoreCase(dropDownName)){
				responseMap = new SPGetClaimRootCauseDropDown(getDataSource()).executeStoredProcedure((String)((Map)input).get(NcasConstants.ROOT_CAUSE));
			}else if(NcasConstants.DROP_DOWN_ROOT_CAUSE.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_NOTIFICATION.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_MARKET_CHANNEL.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_ATTACHMENT_TYPE.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_ATTACHMENT_NCAS.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_ATTACHMENT_TYPE_REFUND.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_REFUND_ROUTE_AMOUNT.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_VBCI_OSID.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_GROUP_SUBTYPE.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_RULE_SUBTYPE.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_LOCATION.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_DEPARTMENT.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_BITS_PRODUCT.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_RT_CAUSE_VBIF.equalsIgnoreCase(dropDownName)||
					NcasConstants.DROP_DOWN_FINOPS_ACTION.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_FINOPS_ACTION_FP.equalsIgnoreCase(dropDownName) ||
					NcasConstants.DROP_DOWN_ORIGINATION_SOURCE.equalsIgnoreCase(dropDownName)||
					NcasConstants.DROP_DOWN_TRANSFER_DEST.equalsIgnoreCase(dropDownName)||
					NcasConstants.DROP_DOWN_CLOSE_REQ_REASON.equalsIgnoreCase(dropDownName)||
					NcasConstants.DROP_DOWN_RT_CAUSE_DEPARTMENT.equalsIgnoreCase(dropDownName)||
					NcasConstants.DROP_DOWN_CONSULTANT_COMPANY.equalsIgnoreCase(dropDownName)||
                    NcasConstants.DROP_DOWN_CONTACT_TYPE.equalsIgnoreCase(dropDownName)||
                    NcasConstants.DROP_DOWN_CLASSIFICATION_CODE.equalsIgnoreCase(dropDownName)||
                    NcasConstants.DROP_DOWN_OCC_TYPE.equalsIgnoreCase(dropDownName)||
                    NcasConstants.DROP_DOWN_VCAPR_USAGE_TYPE.equalsIgnoreCase(dropDownName)||
                    NcasConstants.DROP_DOWN_MISC_TYPE.equalsIgnoreCase(dropDownName) ||
				    NcasConstants.DROP_DOWN_FOLLOWUP_TYPE.equalsIgnoreCase(dropDownName) ||
				    NcasConstants.DROP_DOWN_OPCO.equalsIgnoreCase(dropDownName)) {
				responseMap = new SPGetTicketDropDowns(getDataSource()).executeStoredProcedure(dropDownName);
			}else if(NcasConstants.DROP_DOWN_HOT_NASP_ID.equalsIgnoreCase(dropDownName)){
				responseMap = new SPGetHotNaspId(getDataSource()).executeStoredProcedure(null);//no inputs needed for GET_NASP_ID call
			}else if(NcasConstants.SQL_DROP_DOWN_EMAIL.equalsIgnoreCase(dropDownName) ||
			         NcasConstants.SQL_DROP_DOWN_ROUTE.equalsIgnoreCase(dropDownName) ||
			         NcasConstants.SQL_DROP_DOWN_MARKET_SEGMENT.equalsIgnoreCase(dropDownName)||
			         NcasConstants.SQL_DROP_DOWN_QLINK.equalsIgnoreCase(dropDownName)){
				responseMap = DAOFactory.getInstance().getVbifImpl().getSQLDropDown(dropDownName);
			}
		}catch(Exception dropDownException){
			_LOGGER.error("dropdown - failed::"+dropDownException.getMessage());
			throw new NCASException("",VacDropDownsDAOImpl.class,dropDownException);
		}
		return responseMap;
	}

}
