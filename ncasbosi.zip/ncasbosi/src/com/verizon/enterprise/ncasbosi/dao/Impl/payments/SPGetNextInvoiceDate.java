package com.verizon.enterprise.ncasbosi.dao.Impl.payments;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetNextInvoiceDate extends BaseStoredProcedure {
	static private final Logger _LOGGER = Logger.getLogger(SPGetNextInvoiceDate.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"SUBSCRIPTION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_SW", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"NEXT_BILL_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"INVOICE_NBR", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetNextInvoiceDate(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_NEXT_INV_DATE, spInOutList);
	}

	public Map executeStoredProcedure(String subscriptionOId, String billDate, String debugLevel) throws Exception {
		List paramValueList = new ArrayList();
		paramValueList.add(subscriptionOId);//SUBSCRIPTION_OID
		paramValueList.add(billDate);//BILL_DATE
		paramValueList.add(debugLevel);//DEBUG_SW
		return executeStoredProcedure(paramValueList);
	}

	protected Map executeStoredProcedure(Object paramValues) throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
