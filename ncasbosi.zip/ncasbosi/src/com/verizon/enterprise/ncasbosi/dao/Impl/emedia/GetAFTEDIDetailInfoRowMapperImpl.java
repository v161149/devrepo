package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAFTEDIReportInfo;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAFTEDIDetailInfoRowMapperImpl implements RowMapper{
	static private final Logger _LOGGER = Logger.getLogger(GetAFTDetailInfoRowMapperImpl.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetAFTEDIDetailInfoRowMapperImpl::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		
		EMediaAFTEDIReportInfo aftDetailInfo = new EMediaAFTEDIReportInfo();
		
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

			//Set the values
			String requestNumber = rs.getString("REQUEST_NO");
			String accountNumber = rs.getString("ACCOUNT");
			String status = rs.getString("STATUS");
			String man = rs.getString("MAN");
			String ban = rs.getString("BAN");
			String aban = rs.getString("ABAN");
			String profStatus = rs.getString("PROF_STATUS");
			String invoiceNumber = rs.getString("INVOICE_NUMBER");
			String deliveryStatus = rs.getString("DELIVERY_STATUS");
			String commOutputFileName = rs.getString("COMM_OUTPUT_DSN");
			String vz450OutputFileName = rs.getString("VZ450_INPUT_DSN");
			String commMethod = rs.getString("COMM_METHOD");
			String isaControlNumber = rs.getString("ISA_CNTL_NUM");
			String isaSenderQualilfier = rs.getString("ISA_SENDER_QUAL");
			String isaSenderId = rs.getString("ISA_SENDER_ID");
			String gsSenderId = rs.getString("GS_SENDER_ID");
			String isaReceiverQualifier = rs.getString("ISA_RECVR_QUAL");
			String isaReceiverId = rs.getString("ISA_RECVR_ID");
			String gsReceiverId = rs.getString("GS_RECVR_ID");
			String originatingSystem = rs.getString("ORIG_SOURCE_SYSTEM");

			try {

				Date lastDate = rs.getDate("LAST_BILL_DATE");//Date
				Date startDate = rs.getDate("ACCT_START_DATE");
				Date endDate = rs.getDate("ACCT_END_DATE");
				Date commDeliveryDate = rs.getDate("COMM_DELV_DT");
				Date customerAckDate = rs.getDate("CUST_ACK_DT");
				Date invoiceDate = rs.getDate("INVOICE_DT");

				if (lastDate != null) {
					String lastDateStr =  formatter.format(lastDate);
					if(CommonUtil.isNotNull(lastDateStr)) {
						aftDetailInfo.setLastBillDate(lastDateStr.trim());
					}
				}
				if (startDate != null) {
					String startDateStr =  formatter.format(startDate);
					if(CommonUtil.isNotNull(startDateStr)) {
						aftDetailInfo.setAcctStartDate(startDateStr.trim());
					}
				}
				if (endDate != null) {
					String endDateStr =  formatter.format(endDate);
					if(CommonUtil.isNotNull(endDateStr)) {
						aftDetailInfo.setAcctEndDate(endDateStr.trim());
					}
				}
				if (commDeliveryDate != null) {
					String commDeliveryDateStr =  formatter.format(commDeliveryDate);
					if(CommonUtil.isNotNull(commDeliveryDateStr)) {
						aftDetailInfo.setCommDeliveryDate(commDeliveryDateStr.trim());
					}
				}
				if (customerAckDate != null) {
					String custAckDateStr =  formatter.format(customerAckDate);
					if(CommonUtil.isNotNull(custAckDateStr)) {
						aftDetailInfo.setCustomerAckDate(custAckDateStr.trim());
					}
				}
				if (invoiceDate != null) {
					String invoiceDateStr =  formatter.format(invoiceDate);
					if(CommonUtil.isNotNull(invoiceDateStr)) {
						aftDetailInfo.setInvoiceDate(invoiceDateStr.trim());
					}
				}
			} catch(IllegalArgumentException iae) {
				iae.printStackTrace();
				_LOGGER.debug("Exception occured while parsing the Date \n"
						+ iae.getMessage());
				_LOGGER.error("Exception occured while parsing the Date \n"
						+ iae.getMessage());
			} catch(SQLException sqle) {
				sqle.printStackTrace();
				_LOGGER.debug("SQLException occured while parsing the Date \n"
						+ sqle.getMessage());
				_LOGGER.error("SQLException occured while parsing the Date \n"
						+ sqle.getMessage());
			}
			
			if(CommonUtil.isNotNull(requestNumber)) {
				aftDetailInfo.setRequestNumber(requestNumber.trim());
			}
			if(CommonUtil.isNotNull(accountNumber)) {
				aftDetailInfo.setAccountNumber(accountNumber.trim());
			}
			if(CommonUtil.isNotNull(status)) {
				aftDetailInfo.setAccountFoundStatus(status.trim());
			}
			if(CommonUtil.isNotNull(man)) {
				aftDetailInfo.setMan(man.trim());
			}
			if(CommonUtil.isNotNull(ban)) {
				aftDetailInfo.setBan(ban.trim());
			}
			if(CommonUtil.isNotNull(aban)) {
				aftDetailInfo.setAban(aban.trim());
			}
			if(CommonUtil.isNotNull(profStatus)) {
				aftDetailInfo.setAccountStatus(profStatus.trim());
			}
			if(CommonUtil.isNotNull(invoiceNumber)) {
				aftDetailInfo.setInvoiceNumber(invoiceNumber.trim());
			}
			if(CommonUtil.isNotNull(deliveryStatus)) {
				aftDetailInfo.setDeliveryStatus(deliveryStatus.trim());
			}
			if(CommonUtil.isNotNull(commOutputFileName)) {
				aftDetailInfo.setCommOutputFileName(commOutputFileName.trim());
			}
			if(CommonUtil.isNotNull(vz450OutputFileName)) {
				aftDetailInfo.setVz450InputFileName(vz450OutputFileName.trim());
			}
			if(CommonUtil.isNotNull(commMethod)) {
				aftDetailInfo.setCommMethod(commMethod.trim());
			}
			if(CommonUtil.isNotNull(isaControlNumber)) {
				aftDetailInfo.setIsaControlNumber(isaControlNumber.trim());
			}
			if(CommonUtil.isNotNull(isaSenderQualilfier)) {
				aftDetailInfo.setIsaSenderQualifier(isaSenderQualilfier.trim());
			}
			if(CommonUtil.isNotNull(isaSenderId)) {
				aftDetailInfo.setIsaSenderId(isaSenderId.trim());
			}
			if(CommonUtil.isNotNull(gsSenderId)) {
				aftDetailInfo.setGsSenderId(gsSenderId.trim());
			}
			if(CommonUtil.isNotNull(isaReceiverQualifier)) {
				aftDetailInfo.setIsaReceiverQualifier(isaReceiverQualifier.trim());
			}
			if(CommonUtil.isNotNull(isaReceiverId)) {
				aftDetailInfo.setIsaReceiverId(isaReceiverId.trim());
			}
			if(CommonUtil.isNotNull(gsReceiverId)) {
				aftDetailInfo.setGsReceiverId(gsReceiverId.trim());
			}
			if(CommonUtil.isNotNull(originatingSystem)) {
				aftDetailInfo.setOriginatingSystem(originatingSystem.trim());
			}
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ e.getMessage());
		}
		_LOGGER.debug("aftDetailInfo ^^ " + aftDetailInfo);
		return aftDetailInfo;
	}
}
