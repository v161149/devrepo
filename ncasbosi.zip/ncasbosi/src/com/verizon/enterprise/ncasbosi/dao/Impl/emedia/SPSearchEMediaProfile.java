package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.display.Pagination;


public class SPSearchEMediaProfile extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPSearchEMediaProfile.class);
	
	private static List spInOutList;
	
	private static SearchEMediaProfileRowMapperImpl rowMapper;
	
	static
	{
		 rowMapper = new SearchEMediaProfileRowMapperImpl();
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"profiles",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPSearchEMediaProfile(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SEARCH_EM_PROFILE, spInOutList);	
	}

	public Map executeStoredProcedure(String userId, String debugLevel, 
			String whereClause, String sortOrder, EMediaProfile profile,Pagination pagination)throws Exception
	{
		List paramValueList = new ArrayList();
		Map resultMap = new HashMap();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(whereClause);//WHERE_FILTER
		if(sortOrder == null || sortOrder.equals("")) {
			paramValueList.add("");//SORT_ORDER
		} else {
			paramValueList.add(sortOrder);//SORT_ORDER
		}
		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}
		
		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE

		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		//pagination.updateCurrPageNum();
		Integer rowcountrStr = (Integer)procMap.get("ROW_COUNT");
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		List actualList = (List)procMap.get("profiles");
		if(actualList!=null)
			pagination.setResultSize(Integer.toString(actualList.size()));
		else pagination.setResultSize("0");		
		resultMap.put("recordsMap", procMap);
		resultMap.put("pagination", pagination);

		return resultMap ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		Map responseMap = executeSP(paramValueList, false);
		return responseMap;
	}
}
