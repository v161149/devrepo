package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.eMedia.GBREMediaProfile;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;



public class SPManageGBROrg extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPManageGBROrg.class);

	private static List spInOutList;

	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"ORG_LEVEL1_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ORG_LEVEL1_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ORG_LEVEL2_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"ORG_LEVEL2_NAME", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
	}
	
	public SPManageGBROrg(DataSource dataSource, String schemaName)	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_MANAGE_GBR_ORG, spInOutList);
	}

	/**
	 * @param userId
	 * @param debugLevel
	 * @param profile
	 * @return
	 * @throws Exception
	 */
	public Map executeStoredProcedure(String userId, String debugLevel,	Map input, String action)throws Exception
	{
		List paramValueList = new ArrayList();
		
		StringBuffer myParams = new StringBuffer();
		myParams.append("SP Params [");
		
		String orgLevel1Number = (String) input.get("orgLevel1Number");
		String orgLevel1Name =  (String) input.get("orgLevel1Name");
		String orgLevel2Number =  (String) input.get("orgLevel2Number");;
		String orgLevel2Name = (String) input.get("orgLevel2Name");

		
		
		paramValueList.add(userId);//APP_USER_ID
		myParams.append(userId + "^");
		
		paramValueList.add(input.get("USER_ID"));//USER_ID
		myParams.append(input.get("USER_ID") + "^");
		
		paramValueList.add(input.get("USER_NAME"));//USER_NAME
		myParams.append(input.get("USER_NAME") + "^");
		
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		myParams.append(debugLevel + "^");
		
        DecimalFormat decimalFormatter = new DecimalFormat("##########");
		//String configSubscriptionOid = decimalFormatter.format(profile.getProfileKey().getConfigSubscriptionOid());
		//_LOGGER.info("configSubscriptionOid - " + configSubscriptionOid);
		paramValueList.add(input.get("configSubsOid"));//CONFIG_SUBS_OID	
		myParams.append(input.get("configSubsOid") + "^");
		
		paramValueList.add(action);//ACTION
		myParams.append(action + "^");
		
		if(orgLevel1Number == null) orgLevel1Number = "";
		paramValueList.add(orgLevel1Number);//ORG_LEVEL1_NO     
		myParams.append(orgLevel1Number + "^");

		if(orgLevel1Name == null) orgLevel1Name = "";
		paramValueList.add(orgLevel1Name);//ORG_LEVEL1_NAME     
		myParams.append(orgLevel1Name + "^");

		if(orgLevel2Number == null) orgLevel2Number = "";
		paramValueList.add(orgLevel2Number);//ORG_LEVEL2_NO     
		myParams.append(orgLevel2Number + "^");

		if(orgLevel2Name == null) orgLevel2Name = "";
		paramValueList.add(orgLevel2Name);//ORG_LEVEL2_NAME     
		myParams.append(orgLevel2Name + "]");
		
		_LOGGER.debug(myParams.toString());



		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}

