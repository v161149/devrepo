package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.CellWork;
import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.PortalLinkDBConfig;

public class GetHeaderRowMapperImpl  implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetHeaderRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
        if (_LOGGER.isDebugEnabled()) {
        	_LOGGER.debug("Inside GetHeaderRowMapperImpl -> ");
        }
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Content content = new Content();
		ArrayList rows = new ArrayList();
		content.setRows(rows);		
		ArrayList cellList = null;		
		CellWork cell = null;
		Link link = null;
	
		while(rs.next()) {

			cellList = new ArrayList();			
			String name = rs.getString("NAME");
			String value = rs.getString("D_VALUE");			
			String tooltip = rs.getString("MISC_STRING");
			String type = rs.getString("TYPE");
			String lType = rs.getString("L_TYPE");			
			String format = rs.getString("FMT");
			String pageID = Integer.toString(rs.getInt("TARGET_PAGE_ID"));
			String linkParam = rs.getString("TARGET_PARMS");
			String pageSubset = rs.getString("TARGET_SUBSET");
			String selectType = rs.getString("SELECT_LINK");
			String linkKey = Integer.toString(rs.getInt("XREF_ID"));
			String currencyCode = rs.getString("CURRENCY_CD");			
			
			cell = new CellWork();
			//ltype that starts with NOLNK is used so we can add it's value NOLINK_XXXX
			//to the link table to be used for exclusion/permission
			//normally the omission of a ltype is enough not to have a link			
			if (lType !=null && lType.trim().length() > 0 && !lType.startsWith("NOLNK")){		
			  link = new Link();
			  link.setPageId(pageID.trim());
			  link.setPageSubset(pageSubset.trim());
			  link.setLinkParam(PortalLinkDBConfig.getInstance().getExternalLink(lType.trim(), linkParam.trim()));
			  cell.setLink(link);
			}  
			cell.setName(name.trim());
  		    cell.setValue(CommonUtil.getFormattedDisplayValue(type.trim(), format.trim(),  value.trim(), currencyCode.trim(), false));
			cell.setToolTip(tooltip.trim());
			cell.setFormat(format.trim());
			cell.setType(type.trim());
			cell.setLnkType(lType.trim());
			cell.setLinkKey(linkKey.trim());
			cell.setSelectType(selectType.trim());
			cell.setCurrencyCode(currencyCode);
			cellList.add(cell);
			rows.add(cellList);			
		}
		return content;
	}
}