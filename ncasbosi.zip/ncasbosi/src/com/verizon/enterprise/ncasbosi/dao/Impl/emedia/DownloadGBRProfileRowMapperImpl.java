package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadGBRProfileRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadEMediaProfileRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadGBRProfileRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List profilesList = new ArrayList();
		List profile = new ArrayList();

		try {
			while(rs.next()) {
				profile = new ArrayList();

				String configSubscriptionOid = (String) rs.getBigDecimal("CONFIG_SUBS_OID").toString();
				_LOGGER.info("configSubscriptionOid - " + configSubscriptionOid);
				String configId = rs.getString("CONFIG_ID");
				String profileStatus = rs.getString("PROF_STATUS");//Char(1)
				String companyName = rs.getString("COMPANY_NAME");
				String configName  = rs.getString("CONFIG_NAME");
				String currencyCode = rs.getString("CURRENCY_CODE");
				String languageCode = rs.getString("LANGUAGE_CODE");
				String startDate = rs.getString("START_DATE");
				String endDate = rs.getString("END_DATE");
				String dateCreated = rs.getString("DATE_CREATED");
				String billPeriod = rs.getString("BP_DAY");
				String serviceType = rs.getString("SERVICE_TYPE");

				String creatorUserName = rs.getString("CREATE_USR_NAME");

				if(CommonUtil.isNotNull(configId)) {
					profile.add(new Cell(configId.trim()));
				}
				if(CommonUtil.isNotNull(billPeriod)) {
					profile.add(new Cell(billPeriod.trim()));//BP_DAY
				}
				if(CommonUtil.isNotNull(companyName)) {
					profile.add(new Cell(companyName.trim()));
				}
				if(CommonUtil.isNotNull(configName)) {
					profile.add(new Cell(configName.trim()));
				}
				if(CommonUtil.isNotNull(currencyCode)) {
					profile.add(new Cell(currencyCode.trim()));
				}
				if(CommonUtil.isNotNull(languageCode)) {
					languageCode = languageCode.trim();
					if("en".equalsIgnoreCase(languageCode))
						languageCode = "UK English";
					if("EN5".equalsIgnoreCase(languageCode))
						languageCode = "US English";

					profile.add(new Cell(languageCode));
				}
				profile.add(new Cell(CommonUtil.getDisplayDateFromString(startDate)));
				profile.add(new Cell(CommonUtil.getDisplayDateFromString(endDate)));
				profile.add(new Cell(CommonUtil.getDisplayDateFromString(dateCreated)));
				if(CommonUtil.isNotNull(profileStatus)) {
					profile.add(new Cell(profileStatus.trim()));
				}

				if(CommonUtil.isNotNull(creatorUserName)) {
					profile.add(new Cell(creatorUserName.trim()));
					}

				profilesList.add(profile);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			//throw new NCASException("Exception occured while parsing the resultset \n"+pe.toString(),DownloadGBRProfileRowMapperImpl.class,pe);
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadGBRProfile's profile  " + profile);
		}
		return profilesList;
	}
}
