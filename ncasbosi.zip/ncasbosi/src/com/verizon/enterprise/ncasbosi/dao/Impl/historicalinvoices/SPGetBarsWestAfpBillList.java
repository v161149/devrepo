package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import com.verizon.enterprise.common.util.DateUtility;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.historicalinvoice.DocType;
import com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices.DocTypes;
import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;

public class SPGetBarsWestAfpBillList extends BaseStoredProcedure {

	private static final Logger _LOGGER = Logger.getLogger(SPGetBarsWestAfpBillList.class);
	private static List spInOutList;

	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SYSTEM_ID",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BTN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CAN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FROM_BILL_DATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TO_BILL_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"SP_SQLCODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS",getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"BILL_LIST_COUNT",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"BILL_LIST_ARRAY",  getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}

	public SPGetBarsWestAfpBillList(DataSource dataSource){
		super(dataSource, getBarsWestSchemaName() + "." + "BAWPS01", spInOutList);
	}

	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map requestMap = (HashMap)input;
		HiSelectDO hiDO = (HiSelectDO)requestMap.get("hiDO");
		String preferredLanguageCode = (String)requestMap.get("preferredLanguageCode");

		String debugLevel = "0";
//		if (_LOGGER.isDebugEnabled()) debugLevel = "1";

		String userId = hiDO.getUserId();
		if (userId == null) userId = "null";
		if (userId.length() > 8)  userId = userId.substring(0, 8);  //if userid longer than 8 digits crop to 8 digits

		List callList = new ArrayList();
		callList.add(userId); //APP_USER_ID
		callList.add(debugLevel); //DEBUG_LEVEL
		callList.add("VW"); //SYSTEM_ID
		callList.add(""); //BTN  pass empty btn, only need the can
		callList.add(hiDO.getCan()); //CAN
		callList.add(""); //FROM_BILL_DATE
		callList.add(""); //TO_BILL_DATE

		Map responseMap = executeSP(callList, false);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		String reasonCode = (String)responseMap.get("REASON_CODE");
		if (!"PS01#005".equals(reasonCode) &&  // dont throw exception on bill not found
			!"PS01#002".equals(reasonCode))  // max bills returned is 100, if there are more than that bars returns this error, just ignore it.
		{
			checkErrors(responseMap, BARS);
		}

		// the bill list comes back as a string, convert to an arraylist
		/** bill list is an array whose item length is 36 **/
		String billList = (String)responseMap.get("BILL_LIST_ARRAY");
 		int item_size = 36;
		int numberOfBillsArchived = billList.length() / item_size;

		_LOGGER.debug("billList = " + billList.toString());
		_LOGGER.debug("billList.length = " + billList.length());
		_LOGGER.debug("number of bills = " + numberOfBillsArchived);

		ArrayList <HiSelectDO> selectList = new ArrayList();
		String formatDb2 = "yyyy-MM-dd";
		String formatDisplayed = "MM/dd/yyyy";


		if (numberOfBillsArchived > 0)
		{
			for (int i = 0; i < numberOfBillsArchived; i++) {
				int idx = i * item_size;

				HiSelectDO selectItem = new HiSelectDO();

				//echo back inputs
				selectItem.setMan(hiDO.getMan());
				selectItem.setBan(hiDO.getBan());
				selectItem.setOsid(hiDO.getOsid());

				//get outputs
				selectItem.setBtn(billList.substring(idx + 0, idx + 10));  //get btn off data passed back from archive
				selectItem.setBillDate(billList.substring(idx + 20, idx + 30));  //date
				selectItem.setSections(billList.substring(idx + 31, idx + 35)); //sections
				selectItem.setStartSection("1"); // start section
				selectItem.setLocation(billList.substring(idx + 30, idx + 31)); //location -> D=disk T=tape
				selectItem.setAcctLevel(billList.substring(idx + 35, idx + 36)); //acctLevel -> M=master S=standalone
				selectItem.setFileType("MIX"); //fileType -> afp or pdf
				selectItem.setAban(""); //aban (invoice number)
				selectItem.setDocType("vz");  //lables displayed to user
				selectItem.setDocTypeObj(DocTypes.getDocTypeObj(selectItem.getDocType(), selectItem.getOsid(), preferredLanguageCode)); //lables displayed to user

				//create fields mapped to the screen.
				selectItem.setYearMonth(DateUtility.convertDate(selectItem.getBillDate(), "yyyy-MM-dd", "yyyy MMM"));
				selectItem.setBillPayer(selectItem.getBan());
				selectItem.setInvNbr(selectItem.getAban());
				selectItem.setInvDate(DateUtility.convertDate(selectItem.getBillDate(), formatDb2, formatDisplayed));

				selectList.add(selectItem);

			}
		}

		_LOGGER.debug(selectList);
		responseMap.put("RESULT_SET_ONE", selectList);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return responseMap;
	}

	private String val(String input)
	{
		if (input == null)
			return "";

		return input;
	}
}
