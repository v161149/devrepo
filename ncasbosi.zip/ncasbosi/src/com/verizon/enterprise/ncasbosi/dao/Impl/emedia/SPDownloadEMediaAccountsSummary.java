package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Content;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPDownloadEMediaAccountsSummary extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPDownloadEMediaAccountsSummary.class);

	private static List spInOutList;

	private static DownloadEMediaAccountsSummaryRowMapperImpl rowMapper;

	static
	{
		spInOutList = new ArrayList();
		rowMapper = new DownloadEMediaAccountsSummaryRowMapperImpl();

		spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		spInOutList.add(new Object[]{"SERVICE_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"WHERE_PHRASE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		spInOutList.add(new Object[]{"PAGE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPDownloadEMediaAccountsSummary(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_EM_ACCTS_BY_SEARCH, spInOutList);	
	}

	public Content executeStoredProcedure(String userId, String debugLevel, 
			String serviceId, String wherePhrase, String sortOrder,
			String tokenString) throws Exception
			{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);// APP_USER_ID
		paramValueList.add(debugLevel);// DEBUG_LEVEL
		if(serviceId == null ) {
			serviceId = "";
		}
		if(wherePhrase == null) {
			wherePhrase = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(tokenString == null) {
			tokenString = "";
		}

		paramValueList.add(serviceId);// SERVICE_ID
		paramValueList.add(wherePhrase);// WHERE_PHRASE
		paramValueList.add(sortOrder);// SORT_ORDER
		paramValueList.add(tokenString);// TOKEN_ST

		paramValueList.add("1");// LINE_OFFSET
		paramValueList.add("10000");// PAGE_SIZE
		
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		List actualList = (List)procMap.get("accounts");

		Content retObj = new Content();
		retObj.setRows(actualList);

		return retObj;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
