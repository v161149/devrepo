package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;


import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPGetGCPSummaryAccounts extends BaseStoredProcedure {

	private static List spInOutList;
	static
	{
		 spInOutList = SPInoutListAccounts_v10.getInoutListForAccount_v10(new GetGCPSummaryAccountsRowMapperImpl());
	}
	
	public SPGetGCPSummaryAccounts(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_GCP_SUMMARY, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel,
										String customerNo, String customerType,
										String whereFilter, String sortOrder,
										String cursorId, Pagination pagination,String configSubsOid) throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(userId);//APP_USER_ID
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		if(customerNo == null ) {
			customerNo = "";
		}
		if(customerType == null) {
			customerType = "";
		}
		if(whereFilter == null) {
			whereFilter = "";
		}
		if(sortOrder == null) {
			sortOrder = "";
		}
		if(cursorId == null) {
			cursorId = "";
		}
		// clearing out token_st for each call, so doesn't execute same 
		cursorId = "";

		paramValueList.add(customerNo);//CUST_NO
		paramValueList.add(customerType);//CUSTOMER_TYPE
		paramValueList.add(configSubsOid);//CONFIG_SUBS_OID
		paramValueList.add(whereFilter!=null?whereFilter.trim():whereFilter);//WHERE_PHRASE
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(cursorId);//TOKEN_ST

		String lineOffSet = pagination.getLineOffset();
		String pageSize = pagination.getPageSize();

		if(pagination.isAllSelect()){
			lineOffSet = "1";
			pageSize = pagination.getMaxSize();
		}
		else{
			if(lineOffSet==null) {
				lineOffSet = "1";
			}
			if(pageSize==null) {
				pageSize = "50";
			}
		}


		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE
		Map resultMap = new HashMap();
		Map procMap = (HashMap)executeStoredProcedure(paramValueList);
		pagination.setAllSelect(false);
		//pagination.updateCurrPageNum();
		Integer rowcountrStr = (Integer)procMap.get("TOTAL_ROWS");
		pagination.updateTotalPages(rowcountrStr.intValue());
		pagination.setDefaultSize(pagination.getItemsPerPage());
		Map acctMap = (HashMap)procMap.get("accounts");
		if(acctMap!=null)
			pagination.setResultSize(Integer.toString(CommonUtil.getMapSize(acctMap)));
		else 
			pagination.setResultSize("0");
		resultMap.put("accountsMap", acctMap);
		resultMap.put("pagination", pagination);
		resultMap.put("RETURN_CODE", procMap.get("RETURN_CODE"));
		resultMap.put("REASON_CODE", procMap.get("REASON_CODE"));
		resultMap.put("ERROR_TEXT", procMap.get("ERROR_TEXT"));
		resultMap.put("SP_SQLCODE", procMap.get("SP_SQLCODE"));
		resultMap.put("SP_SQLTOKENS", procMap.get("SP_SQLTOKENS"));
		resultMap.put("SP_SQLSTATE", procMap.get("SP_SQLSTATE"));
		resultMap.put("TOKEN_ST", procMap.get("TOKEN_ST"));

		return resultMap ;
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}