package com.verizon.enterprise.ncasbosi.dao.Impl.adjustments;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.adjustments.Adjustment;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetAdjListAcctLvlRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetAdjListAcctLvlRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetAdjListAcctLvlRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Adjustment adjustment = new Adjustment();
		try {
			while (rs.next()) {  //there will be only one
				String man = rs.getString("MAN"); // Char(13)
				String ban = rs.getString("BAN"); // Char(13)
				String aban = rs.getString("ABAN"); // Char(13)
				String osid = rs.getString("ORIG_SYSTEM_ID"); // Char(2)
				String billSystemId = rs.getString("BILL_SYSTEM_ID"); // Char(1)
				int statusWip = rs.getInt("STATUS_WIP"); // Integer
				Date billDate = rs.getDate("BILL_DATE"); // Date
				String clsOfServiceType = rs.getString("CLS_OF_SVC_TYPE"); // Char(1)
				String stateCode = rs.getString("STATE_CODE"); // Char(2)
				String companyCode = rs.getString("COMPANY_CD"); // Char(4)
				String dbSegmentId = rs.getString("DB_SEGMENT_ID"); // Char(1)
				String taxStatusFederal = rs.getString("TAX_STATUS_FD"); // Char(1)
				String taxStatusState = rs.getString("TAX_STATUS_ST"); // Char(1)
				String taxStatusE911 = rs.getString("TAX_STATUS_E911"); // Char(1)
				String taxStatusSurcharge = rs.getString("TAX_STATUS_SCHG"); // Char(1)
				String taxStatusLocal = rs.getString("TAX_STATUS_LOC"); // Char(1)
				String backendSystem = rs.getString("BACKEND_SYSTEM"); // Char(10)

				if (CommonUtil.isNotNull(man)) {
					adjustment.setMan(man.trim());
				}
				if (CommonUtil.isNotNull(ban)) {
					adjustment.setBan(ban.trim());
				}
				if (CommonUtil.isNotNull(aban)) {
					adjustment.setAban(aban.trim());
				}
				if (CommonUtil.isNotNull(osid)) {
					adjustment.setOsId(osid.trim());
				}				
				if (CommonUtil.isNotNull(billSystemId)) {
					adjustment.setAccountSysId(billSystemId.trim());
				}
				String tmpString = "";
				tmpString = Integer.toString(statusWip);
				if (tmpString != null && tmpString.length() > 0) {
				  adjustment.setAdjustmentStatus(tmpString);
				} else {
				  adjustment.setAdjustmentStatus("0"); //default to wip
				}
				try {
					String billDateStr = formatter.format(billDate);
					if (CommonUtil.isNotNull(billDateStr)) {
						adjustment.setBillDate(billDateStr.trim());
					}
				} catch (IllegalArgumentException iae) {
					iae.printStackTrace();
					_LOGGER.debug("Exception occured while parsing the Date \n" + iae.getMessage());
					_LOGGER.error("Exception occured while parsing the Date \n" + iae.getMessage());
				}
				if (CommonUtil.isNotNull(clsOfServiceType)) {
					adjustment.setClassOfServiceType(clsOfServiceType.trim());
				}
				if (CommonUtil.isNotNull(stateCode)) {
					adjustment.setState(stateCode.trim());
				}
				if (CommonUtil.isNotNull(companyCode)) {
					adjustment.setCompany_Code(companyCode.trim());
				}				
				if (CommonUtil.isNotNull(dbSegmentId)) {
					adjustment.setDatabaseSegID(dbSegmentId.trim());
				}			
				if (CommonUtil.isNotNull(taxStatusFederal)) {
					adjustment.setTaxStatusFed(taxStatusFederal.trim());
				}
				if (CommonUtil.isNotNull(taxStatusState)) {
					adjustment.setTaxStatusState(taxStatusState.trim());
				}
				if (CommonUtil.isNotNull(taxStatusE911)) {
					adjustment.setTaxStatusE911(taxStatusE911);
				}
				if (CommonUtil.isNotNull(taxStatusSurcharge)) {
					adjustment.setTaxStatusSurch(taxStatusSurcharge.trim());
				}
				if (CommonUtil.isNotNull(taxStatusLocal)) {
					adjustment.setTaxStatusLocal(taxStatusLocal);
				}
				if (CommonUtil.isNotNull(backendSystem)) {
					adjustment.setEcpBackendSys(backendSystem);
				}
			}
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n" + nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n" + nfe.getMessage());
			throw nfe;
		}
		return adjustment;
	}

}
