package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.verizon.enterprise.common.ncas.vbe.VbeHierDO;

public class GetVbeHierRowMapper2 implements RowMapper
{
	static private final Logger logger = Logger.getLogger(GetVbeHierRowMapper2.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		final String METHOD_NAME = "GetVbeHierRowMapper2::mapRow() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		VbeHierDO myDO = null;

		if(rs != null)
		{
			myDO = new VbeHierDO();
			
			//config 
			BigDecimal parentOid = rs.getBigDecimal("PARENT_OID");
			BigDecimal childOid = rs.getBigDecimal("CHILD_OID");
			myDO.setParentOid(parentOid.toPlainString());
			myDO.setChildOid(childOid.toPlainString());

		}

		return myDO;
	}
}
