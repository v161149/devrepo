package com.verizon.enterprise.ncasbosi.dao.Impl.reports;


import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.ncas.display.PaymentRow;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.reports.*;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.DAOFactory;
import com.verizon.enterprise.ncasbosi.dao.Interface.reports.ReportsUIInterface;


public class ReportsUIImpl extends ReportsDAOImpl implements NCASBOSIConstants,ReportsUIInterface {

	private static final Logger _LOGGER = Logger.getLogger(ReportsUIImpl.class);

	//get Reports Cache
	public Map getReportCache(Map params)throws NCASException
	{
		Map retMap = new HashMap();
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");
		String portal = (String)params.get("PORTAL");

		retMap.put("LIST", getReportCache(langCode,userOid,section,portal));
		return retMap;
	}
	//get Reports Batch
	public Map getReportBatch(Map params)throws NCASException
	{
		Map retMap = new HashMap();
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");
		String category = (String)params.get("CATEGORY");

		retMap.put("LIST", getReportBatch(langCode,userOid,section,category));
		return retMap;
	}
	//get Custom Reports
	public Map getCustomReports(Map params) throws NCASException
	{
		Map retMap = new HashMap();
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");

		retMap.put("LIST", getCustomReports(langCode,userOid,section));
		return retMap;
	}
	//get Favorite Reports
	public Map getFavoriteReports(Map params) throws NCASException
	{
		Map retMap = new HashMap();
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");

		retMap.put("LIST", getFavoriteReports(langCode,userOid,section));
		return retMap;
	}
	//get Shared Reports
	public Map getSharedReports(Map params) throws NCASException
	{
		Map retMap = new HashMap();
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");

		retMap.put("LIST", getSharedReports(langCode,userOid,section));
		return retMap;
	}
	//get Scheduled Reports
	public Map getScheduleReports(Map params) throws NCASException
	{
		Map retMap = new HashMap();
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");

		retMap.put("LIST", getScheduledReports(langCode,userOid,section));
		return retMap;
	}


	public Map insertScheduledReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "insertScheduledReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		RptRecur reportRecur = (RptRecur)params.get("RPT_RECUR");
		double rptId = insertReportRecurDetails(reportRecur);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//delete Schedule Reports
	public Map deleteScheduledReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "deleteScheduledReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		List<RptRecur> reportRecurIdList = (List<RptRecur>)params.get("RPT_RECUR");
		retMap = deleteReportRecurDetails(reportRecurIdList);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//update Schedule Reports
	public Map updateScheduledReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "updateScheduledReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		RptRecur reportRecur = (RptRecur)params.get("RPT_RECUR");
		retMap = updateReportRecurDetails(reportRecur);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//retrieve Schedule Reports
	public Map getScheduledReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "getScheduledReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		String recurID = (String)params.get("RPT_RECUR_ID");
		retMap.put("LIST", getScheduledReportForID(recurID));
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	public Map insertImmediateReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "insertImmediateReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		RptRequest reportRequest = (RptRequest)params.get("RPT_REQUEST");
		List<RptRequest> reportReqList = new ArrayList();
		reportReqList.add(reportRequest);

		retMap=insertReportReqDetails(reportReqList);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	public Map updateReportReqDetails(Map params) throws NCASException
	{
		final String METHOD_NAME = "updateReportReqDetails::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		RptRequest reportRequest = (RptRequest)params.get("RPT_REQUEST");
		List<RptRequest> reportReqList = new ArrayList();
		reportReqList.add(reportRequest);

		retMap=updateReportReqDetails(reportReqList);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//delete Custom Report
	public Map deleteCustomReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "deleteCustomReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();

		List<RptCustUser> rptCustUserList = (List<RptCustUser>)params.get("RPT_CUSTUSER");
		deleteCustomUser(rptCustUserList);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}



	//update Custom Report
	public Map updateCustomReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "updateCustomReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = updateReportControlDetail(params);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//update Custom Shared Report
	public Map updateCustomSharedReport(Map params) throws NCASException
	{
		final String METHOD_NAME = "updateCustomSharedReport::";
		_LOGGER.info(METHOD_NAME+"Entering");
		List<RptCustUser> rptUserList = (List<RptCustUser>)params.get("RPT_CUST_USER");
		String loginId = (String)params.get("PORTAL_LOGIN_ID");
		Map retMap = updateCustomSharedReport(rptUserList,loginId);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//insert Audit Entry
	public Map insertAudit(Map params) throws NCASException
	{
		final String METHOD_NAME = "insertAudit::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		RptAudit reportAudit = (RptAudit)params.get("AUDIT");
		insertReportAuditDetail(reportAudit);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}


	//deleteReportExec
	public Map deleteReportExec(Map params) throws NCASException
	{
		final String METHOD_NAME = "deleteReportExec::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		List idList = (List)params.get("EXECLIST");
		deleteReportExecDetails(idList);
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	//getReportName
	public Map getReportName(Map params) throws NCASException
	{
		final String METHOD_NAME = "getReportName::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		String rptId = (String)params.get("RPT_ID");

		RptCntl myRptCntl = getReportDetails(rptId);
		retMap.put("REPORT_NAME", myRptCntl.getRptName());

		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}


	@SuppressWarnings("unchecked")
	public Map getAllCustomAttributes(Map params) throws NCASException {
		final String METHOD_NAME = "getAllCustomAttributes::";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map retMap = new HashMap();
		retMap.put("LIST", geAllCustomAttributes());
		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}

	public Map getSelectedReportFields(Map params) throws NCASException {
		final String METHOD_NAME = "getSelectedReportFields::";
		_LOGGER.info(METHOD_NAME+"Entering");

		String rptId = (String)params.get("RPT_ID");
		String parentrptId = (String)params.get("PARENT_RPT_ID");
		String section = (String)params.get("tabid");
		if(rptId==null)rptId = "";
		if(parentrptId==null)parentrptId = "";

		List<CustomRptField> fldList = new ArrayList();
		if(!rptId.isEmpty()){
			getCustRptChoices(rptId,fldList);
		}
		else if(!parentrptId.isEmpty()){
			getCustRptChoices(parentrptId,fldList);
		}

		if(fldList.size()==0)
			fldList = getGlobalFields(section);

		Map retMap = new HashMap();
		retMap.put("RPT_SELECTEDFIELDS",fldList);


		_LOGGER.info(METHOD_NAME+"Exiting");
		return retMap;
	}


	public Map getCustomize(Map params) throws NCASException {
		final String METHOD_NAME = "setCustomize::";
		_LOGGER.info(METHOD_NAME+"Entering");
		String step = (String)params.get("STEP");
		String rptId = (String)params.get("RPT_ID");
		String userOid = (String)params.get("USEROID");
		String section = (String)params.get("SECTION");
		String parentrptId = (String)params.get("PARENT_RPT_ID");
		String name = (String)params.get("RPT_NAME");
		String desc = (String)params.get("RPT_DESC");
		if(name==null)name = "";
		if(desc==null)desc = "";


		List flds = null;
		if(rptId==null)rptId = "";
		if(parentrptId==null)parentrptId = "";

		params.put("RPT_SELECTEDFIELDS","");
		params.put("SHARED", "N");
		if(step!=null){
			if(step.equals("1")){
				if(!name.isEmpty()){
					RptCntl rpt = new RptCntl();
					rpt.setRptName(name);
					rpt.setRptDescription(desc);
					params.put("RPT_CNTL", rpt);
				}
				else if(!rptId.isEmpty()||!parentrptId.isEmpty()){
					if(rptId.isEmpty() && !parentrptId.isEmpty())
						rptId = parentrptId;
					params.put("RPT_CNTL", getReportDetails(rptId));
				}
			}else if(step.equals("2")){
				List<CustomRptField> fldList = new ArrayList();
				if(!rptId.isEmpty()){
					getCustRptChoices(rptId,fldList);
					params.put("RPT_CNTL", getReportDetails(rptId));
				}
				else if(!parentrptId.isEmpty()){
					getCustRptChoices(parentrptId,fldList);
					params.put("PARENT_RPT_CNTL", getReportDetails(parentrptId));
				}

				if(fldList.size()==0)
					fldList = getGlobalFields(section);
				params.put("RPT_SELECTEDFIELDS",fldList);
			}else if(step.equals("3")){
				if(!rptId.isEmpty()){
					Map data = getCustomFilterInfo(params);
					flds = (List)data.get("userpreference");
				}
				if(flds==null)
					flds = new ArrayList();
				params.put("userpreference",flds);
			}else if(step.equals("4")){
				if(!rptId.isEmpty())
					params.put("SHARED", getSharedReport(rptId,userOid));
			}
		}


		return params;
	}

	public Map setCustomize(Map params) throws NCASException,Exception {
		final String METHOD_NAME = "setCustomize::";
		_LOGGER.info(METHOD_NAME+"Entering");
		String name = (String)params.get("RPT_NAME");
		String desc = (String)params.get("RPT_DESC");
		String rptId = (String)params.get("RPT_ID");
		String parentrptId = (String)params.get("PARENT_RPT_ID");
		String rptFilter = (String)params.get("RPT_FILTER");
		String userOid = (String)params.get("USEROID");
		String langCode = (String)params.get("LANG");
		String section = (String)params.get("SECTION");
		String login_id = (String)params.get("PORTAL_LOGIN_ID");

		String report_type = (String)params.get("RPT_TYPE");
		String view_by = (String)params.get("VIEW_BY");


		String fldSource = (String)params.get("RPT_FIELDS_SRC");
		String fldName =   (String)params.get("RPT_FIELDS_FN");
		String fldGrps =   (String)params.get("RPT_FIELD_GROUPS");

		String byPassDup =   (String)params.get("BYPASSDUP");
		String portal =   (String)params.get("PORTAL");
		String parentPageId = (String)params.get("PARENT_PAGE_ID");

		String step = (String)params.get("STEP");

		if(rptId==null)rptId = "";
		if(parentrptId==null)parentrptId = "";
		if(report_type==null)report_type = "";
		if(view_by==null)view_by = "";
		if(name==null)name = "";
		if(byPassDup==null)byPassDup = "";
		if(parentPageId==null||(parentPageId!=null&&parentPageId.isEmpty()))parentPageId = "0";

		name = name.trim();



		RptCustUser reportCustUser = null;
		boolean errorFlg = false;

		try{
				if(step!=null){
					if(step.equals("1")){
						if(name.isEmpty()){
							params.put("ERROR_MSG", "Invalid Report name. Please enter another report name.");
							errorFlg = true;
						}
						if(byPassDup.equals("")&& isDuplicateReport(userOid,name,section)){
							if(section.equalsIgnoreCase("Wireless"))
								  params.put("ERROR_MSG", "Report name already exists. Please choose another report name.  Report names must be unique across your company.");
							else   params.put("ERROR_MSG", "Report name already exists. Please choose another report name.");
							errorFlg = true;
						}


						if(!errorFlg && !rptId.isEmpty()){ //Update  isDuplicateReport(String userOid,String rptName)
								updateReportControlCustom(name, desc, login_id,Integer.parseInt(rptId));
						}

						if(!errorFlg)
							params.put("STEP", "2");
						getCustomize(params);
					}else if(step.equals("2")){
						if(name.isEmpty()){
							params.put("ERROR_MSG", "Invalid Report name. Please enter another report name.");
							errorFlg = true;
							params.put("STEP", "1");
						}

						else if( !fldName.isEmpty() && rptId.isEmpty()){ //New Customize
							if(isDuplicateReport(userOid,name,section)){
								if(section.equalsIgnoreCase("Wireless"))
									  params.put("ERROR_MSG", "Report name already exists. Please choose another report name.  Report names must be unique across your company.");
								else   params.put("ERROR_MSG", "Report name already exists. Please choose another report name.");
								errorFlg = true;
								params.put("STEP", "1");
							}
							else{
							    String newPageId = getCustomPageId();
								int newRptId = createReportControl(parentrptId,login_id,newPageId, name, desc,section,report_type,view_by,parentPageId);
								if(!section.equalsIgnoreCase("Wireless") || (section.equalsIgnoreCase("Wireless") && (portal.equalsIgnoreCase("VZW")||portal.equalsIgnoreCase("VBC")||portal.equalsIgnoreCase("VPS")))){
									reportCustUser = new RptCustUser();
									reportCustUser.setRptCustUser(newRptId, login_id, new Double(userOid).doubleValue(), 0,"N",login_id);
									insertCustomUserDetails(reportCustUser);
								}
								else{
									List<Double> ecpdIdList = DAOFactory.getInstance().getPaymentsBeanForECP().selectAllECPDIdsForUser(new Double(userOid).doubleValue());
									for(int i=0;i<ecpdIdList.size();i++){
										reportCustUser = new RptCustUser();
										reportCustUser.setRptCustUser(newRptId, login_id, new Double(userOid).doubleValue(), ecpdIdList.get(i),"N",login_id);
										insertCustomUserDetails(reportCustUser);
									}
								}
								params.put("RPT_ID", newRptId+"");
								rptId = String.valueOf(newRptId);
							}
						}else if( fldName.isEmpty()){
							params.put("ERROR_MSG", "Problems with Setting Report Fields - Please select fields to be displayed on report.");
							errorFlg = true;
						}


						if(!errorFlg && !rptId.isEmpty()){
							List<CustomRptField> fields = new ArrayList();
							Map fldtmpMap = new HashMap();
							String [] fldNameArray = null;
							fldNameArray = fldName.split("~");
							String [] fldSourceArray = null;
							fldSourceArray = fldSource.split("~");
							String [] fldGrpsArray = null;
							fldGrpsArray = fldGrps.split("~");


							CustomRptField custFld = null;
							for(int i=0;i<fldNameArray.length;i++){
								if(!fldtmpMap.containsKey(fldNameArray[i])){
									custFld = new CustomRptField(fldNameArray[i],fldSourceArray[i]);
									custFld.setFieldGrp(fldGrpsArray[i]);
									fields.add(custFld);
									fldtmpMap.put(fldNameArray[i], fldSourceArray[i]);
								}
							}
							if(fields.size()>0){
								insertRptChoices(fields,rptId);
								params.put("RPT_FILTERS","");
								setCustomFilterInfo(params);
								params.put("STEP", "3");
							}
							else params.put("ERROR_MSG", "Problems with Setting Report Fields - Please select fields to be displayed on report.");
						}
						getCustomize(params);
					}else if(step.equals("3")){
						if(!rptId.isEmpty()){
							setCustomFilterInfo(params);
							if(section.equalsIgnoreCase("Wireless")){
								params.put("STEP", "4");
							}
							else{
								params.put("STEP", "FINISH");
								params.put("RPT_CNTL", getReportDetails(rptId));
							}
						}
						else errorFlg = true;
						if(errorFlg)
							params.put("ERROR_MSG", "Problems with Setting Filter - Need to complete prior steps.");
						getCustomize(params);
					}else if(step.equals("4")){
						if(!rptId.isEmpty()){
							setShared( params);
							params.put("STEP", "FINISH");
							params.put("RPT_CNTL", getReportDetails(rptId));
						}
						else params.put("ERROR_MSG", "Problems with Sharing Report - Need to complete prior steps.");
						getCustomize(params);
					}
				}

		}
		catch(RemoteException ex){
			ex.printStackTrace();
			String[] errMsg = new String[2];
		    errMsg[0] = METHOD_NAME;
		    errMsg[1] = ex.getMessage();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(REPORT_EXCEPTION_950,errMsg,ex);
		}


		_LOGGER.info(METHOD_NAME+"Exiting");
		return params;
	}




	public void setShared(Map params)throws NCASException
	{
		String name = (String)params.get("RPT_NAME");
		String rptId = (String)params.get("RPT_ID");
		String userOid = (String)params.get("USEROID");
		String login_id = (String)params.get("PORTAL_LOGIN_ID");
		String share_ind = (String)params.get("SHARED");
		if(share_ind==null)share_ind = "N";


		RptCustUser custUser = new RptCustUser();
		custUser.setShareInd(share_ind);
		custUser.setRptCustomUserId(Integer.parseInt(rptId));
		List<RptCustUser> rptUserList = new ArrayList();
		rptUserList.add(custUser);
		updateCustomSharedReport(rptUserList,login_id);

	}

		public int createReportControl(String rptId,String login_id,String custom_page_id,String reportName,String reportDesc,String section,String reportType,String rptSubGroup,String parentPageId) throws NCASException
		{
			RptCntl reportCntl = null;

			if(rptId.isEmpty()){
				reportCntl = new RptCntl();
				reportCntl.setRptSection(section);
				reportCntl.setArchiveSystemId("R1");
				reportCntl.setEmailTemplateName("REPORT_NOTIFICATION_VZW");
				reportCntl.setReportType(reportType);
				reportCntl.setRptSubGroup(rptSubGroup);
				reportCntl.setStdReport("Y");
			}
			else{
				reportCntl = getReportDetails(rptId);
			}
			reportCntl.setInterPageId(13040);
			reportCntl.setPageSubset("1");

			reportCntl.setPageId(new Integer(custom_page_id));
			reportCntl.setCustomRpt("Y");
			reportCntl.setLastUpdatedBy(login_id);
			reportCntl.setRptName(reportName);
			reportCntl.setRptDescription(reportDesc);
			reportCntl.setParentPageId(new Integer(parentPageId));

			return insertReportControlDetails(reportCntl);
		}


		public void addBillViewAudit(Map params) throws NCASException
		{
			List auditList = (List)params.get("AUDIT");
			insertViewAudit(auditList);
		}

		public Map setICICustomize(Map params) throws NCASException {
			final String METHOD_NAME = "setICICustomize::";

			String newPageId = "";
			int rptId;
			String userOid = (String)params.get("USEROID");
			String login_id = (String)params.get("PORTAL_LOGIN_ID");

			List custRptList = getCustomRptList(userOid);
			if(custRptList!=null &&custRptList.size()<=0){
				newPageId = getCustomPageId();
				RptCntl reportCntl = null;
				reportCntl = new RptCntl();
				reportCntl.setRptSection("ICICUSTOM");
				reportCntl.setArchiveSystemId("XX");
				reportCntl.setEmailTemplateName("XXX");
				reportCntl.setStdReport("N");
				reportCntl.setPageId(new Integer(newPageId));
				reportCntl.setCustomRpt("Y");
				reportCntl.setLastUpdatedBy(login_id);
				reportCntl.setRptName("ICI Customize");
				reportCntl.setRptDescription("ICI Customize Group Rpt");
				reportCntl.setParentPageId(1801);
				reportCntl.setPageSubset("1");
				rptId = insertReportControlDetails(reportCntl);
			    RptCustUser reportCustUser = new RptCustUser();
				reportCustUser.setRptCustUser(rptId, login_id, new Double(userOid).doubleValue(), 0,"N",login_id);
				insertCustomUserDetails(reportCustUser);
			}else{
				RptCntl rpt = (RptCntl)custRptList.get(0);
				rptId = rpt.getRptId();
			}
		    List<CustomRptField> fields = new ArrayList();
		    getCustRptChoices("-1",fields);
			insertRptChoices(fields,String.valueOf(rptId));


			params.put("RPT_ID",String.valueOf(rptId));
			params.put("RPT_FILTERS",params.get("USR_GRP"));

			setCustomFilterInfo(params);
			return params;

		}

		public Map getICICustomize(Map params) throws NCASException {
			final String METHOD_NAME = "getICICustomize::";
			String userOid = (String)params.get("USEROID");

			List custRptList = getCustomRptList(userOid);
			if(custRptList!=null && custRptList.size()> 0){
				RptCntl rpt = (RptCntl)custRptList.get(0);
				params.put("RPT_ID",String.valueOf(rpt.getRptId()));
				params = getCustomFilterInfo(params);
			}
			return params;
		}


}





