package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.math.BigDecimal;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.common.ncas.gbr.GetGbrComponentDO;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import org.apache.log4j.Logger;

public class SPGetVBEEMediaAccounts extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPGetVBEEMediaAccounts.class);

	private static List spInOutList;

	private static GetVBEEMediaAccountsRowMapperImpl rowMapper;

	static
	{
		 spInOutList = new ArrayList();
		 rowMapper = new GetVBEEMediaAccountsRowMapperImpl();

		 spInOutList.add(new Object[]{"accounts",getSqlDataType(Types.NULL),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,rowMapper});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"CONFIG_SUBS_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REMIT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REPORT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TAB", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"WHERE_FILTER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SORT_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"LINE_OFFSET", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PAGE_SIZE", getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ROW_COUNT", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	public SPGetVBEEMediaAccounts(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_GET_VBE_ACCTS, spInOutList);
	}

	public Map executeStoredProcedure(Object input) throws Exception
	{
		Map requestMap = (HashMap)input;
		List paramValueList = new ArrayList();

		String configSubscriptionOid = (String) requestMap.get("CONFIG_SUBS_OID");
		String whereFilter = (String) requestMap.get("WHERE_FILTER");
		String sortOrder = (String) requestMap.get("SORT_ORDER");
		String tabInd = (String) requestMap.get("TAB");
		String remitOid = (String) requestMap.get("REMIT_OID");
		String reportOid = (String) requestMap.get("REPORT_OID");
		String lineOffSet = (String) requestMap.get("LINE_OFFSET");
		String pageSize = (String) requestMap.get("PAGE_SIZE");
		if(lineOffSet==null) {
			lineOffSet = "1";
		}
		if(pageSize==null) {
			pageSize = "50";
		}
		
		if (configSubscriptionOid == null || "".equals(configSubscriptionOid)) configSubscriptionOid = "0";
		if (remitOid == null || "".equals(remitOid)) remitOid = "0";
		if (reportOid == null || "".equals(reportOid)) reportOid = "0";

		paramValueList.add("portal");//APP_USER_ID
		paramValueList.add("0");//DEBUG_LEVEL

		Map resultMap = new HashMap();
		paramValueList.add(new BigDecimal(configSubscriptionOid));//CONFIG_SUBS_OID
		paramValueList.add(new BigDecimal(remitOid));//REMIT_OID
		paramValueList.add(new BigDecimal(reportOid));//REPORT_OID
		paramValueList.add(tabInd);//TAB
		paramValueList.add(whereFilter);//WHERE_FILTER
		paramValueList.add(sortOrder);//SORT_ORDER
		paramValueList.add(lineOffSet);//LINE_OFFSET
		paramValueList.add(pageSize);//PAGE_SIZE

		Map responseMap = executeSP(paramValueList, false);

		_LOGGER.info("Now calling checkErrors to identify any errors or issued warnings");
		checkErrors(responseMap, VAM);

		List tempAcctList = (List)responseMap.get("accounts");
		if (tempAcctList == null) tempAcctList = new ArrayList(); //handle no rows returned


		// new logic starts
		for (int i=0; i<tempAcctList.size(); i++) {
			EMediaRecord emediaRecord = (EMediaRecord)tempAcctList.get(i);
			if (tabInd.equalsIgnoreCase("ACCT_ELIG_REMIT")||tabInd.equalsIgnoreCase("CORP_ELIG_REMIT")||tabInd.equalsIgnoreCase("LOC_ELIG_REMIT")||
				tabInd.equalsIgnoreCase("ACCT_ELIG_REPORT")||tabInd.equalsIgnoreCase("LOC_ELIG_REPORT")||tabInd.equalsIgnoreCase("REPORT_ELIG_REPORT")	) {
				emediaRecord.setEligibleForSelection(false);
				if (emediaRecord.getEligibilityInd().equalsIgnoreCase("01")||emediaRecord.getEligibilityInd().equalsIgnoreCase("05")) {
					emediaRecord.setEligibleForSelection(true);
				}
			} else if (tabInd.equalsIgnoreCase("ACCT_IN_REMIT")||tabInd.equalsIgnoreCase("CORP_IN_REMIT")||tabInd.equalsIgnoreCase("LOC_IN_REMIT")||
				tabInd.equalsIgnoreCase("ACCT_IN_REPORT")||tabInd.equalsIgnoreCase("LOC_IN_REPORT")||tabInd.equalsIgnoreCase("REPORT_IN_REPORT")) {
				emediaRecord.setEligibleForSelection(true);
				if (emediaRecord.getEligibilityInd().equalsIgnoreCase("05")||emediaRecord.getEligibilityInd().equalsIgnoreCase("21")) {
					emediaRecord.setEligibleForSelection(false);
				}
			}
		}
		// new logic ends
		responseMap.put("accounts", tempAcctList);

		return responseMap;
	}

}

