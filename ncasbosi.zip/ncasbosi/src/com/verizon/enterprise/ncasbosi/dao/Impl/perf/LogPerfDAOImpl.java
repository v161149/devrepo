package com.verizon.enterprise.ncasbosi.dao.Impl.perf;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.object.BatchSqlUpdate;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.perf.LogPerf;
import com.verizon.enterprise.ncasbosi.dao.Interface.perf.LogPerfInterface;
import java.util.HashMap;
import javax.sql.DataSource;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.sql.Timestamp;

public class LogPerfDAOImpl extends JdbcDaoSupport implements LogPerfInterface,
		NCASBOSIConstants {
	private static final Logger _LOGGER = Logger
			.getLogger(LogPerfDAOImpl.class);
	
	String SELECT_LOG_MODULE = null;

	private JdbcTemplate dbTemplate;

	private String getSchemaName() {
		String schemaName = NCASBOSIConstants.VAM_SCHEMA;
		
		return schemaName;
	}

	public Map processLogPerf(String operation, Map inputMap)
			throws NCASException {
		Map resultMap = new HashMap();
		List logPerfList = null;
		String METHOD_NAME = "processLogPerf()  ";
		_LOGGER.info(METHOD_NAME + "  Enter  operation = " + operation);
		if (operation.equalsIgnoreCase("I")) {
			logPerfList = (List) inputMap.get("perLogList");
			resultMap = insertPerfLog(logPerfList);
		} else if (operation.equalsIgnoreCase("M")) {
			resultMap = getUniqueModule();
		} else if (operation.equalsIgnoreCase("L")) {
			resultMap = logAnalysis(inputMap);
		} else if (operation.equalsIgnoreCase("LU")) {
			resultMap = getPerfLogDetails(inputMap);
		}
		return resultMap;

	}

	protected void initDao() throws Exception {
		super.initDao();
		SELECT_LOG_MODULE = "SELECT DISTINCT MODULE FROM " + getSchemaName()
				+ ".PL_LOGS_PERF_T";

	}

	String SELECT_LOG_KEYS = "SELECT DISTINCT MISC_KEY  FROM "
			+ getSchemaName()
			+ ".PL_LOGS_PERF_T WHERE DOMAIN=? AND START_TS LIKE ? AND MODULE=?";
	// This Query is For UI to display log details
	String SELECT_LOG_DETAILS = "SELECT A.PAGE_ID,A.START_TS,A.END_TS,A.ELASPED_TIME,B.START_TS AS BOSI_START_TS,B.END_TS AS "
			+

			"BOSI_END_TS,B.ELASPED_TIME AS BOSI_ELASPED_TIME ,A.PORTAL_LOGIN_ID FROM "
			+ "(SELECT PAGE_ID,START_TS,END_TS,ELASPED_TIME, MISC_KEY ,PORTAL_LOGIN_ID FROM "
			+ getSchemaName()
			+ ".PL_LOGS_PERF_T WHERE DOMAIN = ? "
			+

			"AND  DATE(START_TS)= ? AND ELASPED_TIME >=?)A "
			+ "LEFT OUTER JOIN "
			+ "(SELECT PAGE_ID,START_TS,END_TS,ELASPED_TIME, MISC_KEY,PORTAL_LOGIN_ID FROM "
			+ getSchemaName()
			+ ".PL_LOGS_PERF_T WHERE DOMAIN = 'BOSI' "
			+ "AND DATE(START_TS)= ? )B on A.MISC_KEY =B.MISC_KEY";

	String SELECT_PERF_KEYS = "SELECT DISTINCT MISC_KEY  FROM "
			+ getSchemaName()
			+ ".PL_LOGS_PERF_T WHERE DATE(LAST_UPD_TIMESTAMP)= CURRENT DATE AND DOMAIN=?";
	// This Query is For APM scheduler to send a mail alert
	String SELECT_PERF_LASTUPDATED = "SELECT A.PAGE_ID,A.START_TS,A.END_TS,A.ELASPED_TIME,B.START_TS AS BOSI_START_TS,B.END_TS AS "
			+

			"BOSI_END_TS,B.ELASPED_TIME AS BOSI_ELASPED_TIME ,A.PORTAL_LOGIN_ID FROM "
			+ "(SELECT PAGE_ID,START_TS,END_TS,ELASPED_TIME, MISC_KEY,PORTAL_LOGIN_ID FROM "
			+ getSchemaName()
			+ ".PL_LOGS_PERF_T WHERE DOMAIN = ? "
			+

			"AND ELASPED_TIME > 10000 AND DATE(START_TS)= (CURRENT DATE - 1 DAY))A "
			+ "LEFT OUTER JOIN "
			+ "(SELECT PAGE_ID,START_TS,END_TS,ELASPED_TIME, MISC_KEY ,PORTAL_LOGIN_ID FROM "
			+ getSchemaName()
			+ ".PL_LOGS_PERF_T WHERE DOMAIN = 'BOSI' "
			+ " AND DATE(START_TS)= (CURRENT DATE - 1 DAY))B on A.PAGE_ID=B.PAGE_ID AND A.MISC_KEY =B.MISC_KEY AND A.PORTAL_LOGIN_ID=B.PORTAL_LOGIN_ID";
	private SelectPerfLogModule selectPerfLogModule;
	private SelectPerfLogKeys selectPerfLogKeys;
	private SelectPerfLogDetails selectPerfLogDetails;
	
	private SelectPerfLastUpdated selectPerfLastUpdated;
	private UpdatePerfLog updatePerfLog;

	protected JdbcTemplate getDBTemplate() {
		if (this.dbTemplate == null
				|| getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}

	abstract class AbstractSelect extends MappingSqlQuery {
		public AbstractSelect(DataSource dataSource, String sql) {
			super(dataSource, sql);
		}
	}

	class SelectPerfLogModule extends AbstractSelect {
		private String sql;

		public SelectPerfLogModule(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			// LogPerf logPerf = new LogPerf();
			String moduleName = "";
			moduleName = rs.getString("MODULE");
			// logPerf.setModule(moduleName);

			return moduleName;
		}
	}

	class SelectPerfLastUpdated extends AbstractSelect {
		private String sql;

		public SelectPerfLastUpdated(DataSource dataSource, String myQuery) {
			super(dataSource, myQuery);
		}

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			LogPerf logPerf = new LogPerf();
			int logId = rs.getInt("LOG_ID");
			int pageId = rs.getInt("PAGE_ID");
			String startTs = rs.getString("START_TS");
			String endTs = rs.getString("END_TS");
			int elapsedTs = rs.getInt("ELASPED_TIME");
			String domain = rs.getString("DOMAIN");
			String portalLoginId = rs.getString("PORTAL_LOGIN_ID");
			String module = rs.getString("MODULE");
			String miscKey = rs.getString("MISC_KEY");
			String lastUpdateTimeStamp = rs.getString("LAST_UPD_TIMESTAMP");
			String lastUpdated = rs.getString("LASTUPDATED");
			logPerf.setLogId(logId);
			logPerf.setPageId(pageId);
			logPerf.setStartTimestamp(startTs);
			logPerf.setEndTimestamp(endTs);
			logPerf.setElapsedTime(elapsedTs);
			logPerf.setDomain(domain);
			logPerf.setLoginId(portalLoginId);
			logPerf.setModule(module);
			logPerf.setMisc(miscKey);
			logPerf.setLastupdatedTimestamp(lastUpdateTimeStamp);
			logPerf.setLastUpdatedBy(lastUpdated);

			return logPerf;
		}
	}

	class UpdatePerfLog extends SqlUpdate {
		public UpdatePerfLog(DataSource dataSource, String updateQuery) {
			super(dataSource, updateQuery);

		}
	}

	public Map insertPerfLog(List<LogPerf> perfLogList) throws NCASException {
		BatchSqlUpdate insertPerfLogSql = null;
		String METHOD_NAME = "insertPerfLog";
		_LOGGER.info(METHOD_NAME + "  Enter ");
		String INSERT_PERFLOG = " INSERT INTO "
				+ getSchemaName()
				+ ".PL_LOGS_PERF_T(PAGE_ID,START_TS,END_TS,ELASPED_TIME,DOMAIN,PORTAL_LOGIN_ID,MODULE,MISC_KEY,LAST_UPD_TIMESTAMP,LASTUPDATED)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?)";
		boolean status = false;
		Map resultMap = new HashMap();
		int insCount = 0;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				"yyyy-MM-dd-HH.mm.ss.SSS");
		String lastUpdated = simpleDateFormat.format(new Timestamp(System
				.currentTimeMillis()));
		try {
			if (insertPerfLogSql == null) {
				insertPerfLogSql = new BatchSqlUpdate(getDataSource(),
						INSERT_PERFLOG);
				insertPerfLogSql.declareParameter(new SqlParameter("PAGE_ID",
						Types.VARCHAR));
				insertPerfLogSql.declareParameter(new SqlParameter("START_TS",
						Types.TIMESTAMP));
				insertPerfLogSql.declareParameter(new SqlParameter("END_TS",
						Types.TIMESTAMP));
				insertPerfLogSql.declareParameter(new SqlParameter(
						"ELASPED_TIME", Types.INTEGER));
				insertPerfLogSql.declareParameter(new SqlParameter("DOMAIN",
						Types.VARCHAR));
				insertPerfLogSql.declareParameter(new SqlParameter(
						"PORTAL_LOGIN_ID", Types.VARCHAR));
				insertPerfLogSql.declareParameter(new SqlParameter("MODULE",
						Types.VARCHAR));
				insertPerfLogSql.declareParameter(new SqlParameter("MISC_KEY",
						Types.VARCHAR));
				insertPerfLogSql.declareParameter(new SqlParameter(
						"LAST_UPD_TIMESTAMP", Types.TIMESTAMP));
				insertPerfLogSql.declareParameter(new SqlParameter(
						"LASTUPDATED", Types.VARCHAR));
				insertPerfLogSql.setBatchSize(100);

			}
			for (LogPerf logPerfObject : perfLogList) {
				Object[] parameterValues = new Object[] {
						logPerfObject.getPageId(),
						logPerfObject.getStartTimestamp(),
						logPerfObject.getEndTimestamp(),
						logPerfObject.getElapsedTime(),
						logPerfObject.getDomain(), logPerfObject.getLoginId(),
						logPerfObject.getModule(), logPerfObject.getMisc(),
						lastUpdated, logPerfObject.getLastUpdatedBy() };

				     insertPerfLogSql.update(parameterValues);
				   

				
			}
			if (insertPerfLogSql != null)
				insertPerfLogSql.flush();
			status=true;

		} catch (Exception vamEx) {
			vamEx.printStackTrace();
			_LOGGER
					.debug("insertPerfLog in VAM Failed \n"
							+ vamEx);
			_LOGGER
					.error("insertPerfLog in VAM Failed \n"
							+ vamEx);
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					LogPerfDAOImpl.class, vamEx);
		}
		resultMap.put("Status", status);
		return resultMap;
	}

	public Map getUniqueModule() throws NCASException {
		final String METHOD_NAME = "getPerfLogModule => ";
		_LOGGER.info(METHOD_NAME + " Entering");
		Map<String, List> resultMap = new HashMap<String, List>();
		List moduleList = null;
		try {
			selectPerfLogModule = new SelectPerfLogModule(getDataSource(),
					SELECT_LOG_MODULE);
			_LOGGER.info(METHOD_NAME + "Exiting");
			moduleList = selectPerfLogModule.execute(new Object[] {});
			resultMap.put("moduleList", moduleList);
		} catch (Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					LogPerfDAOImpl.class, vamEx);
		}
		return resultMap;
	}

	class SelectPerfLogKeys extends JdbcDaoSupport {
		private String sql;

		public SelectPerfLogKeys(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public List<String> getLogKeys(Object[] params) {
			final String METHOD_NAME = "getLogKeys => ";
			_LOGGER.info(METHOD_NAME + " Entering");
			return (List) getDBTemplate().query(sql, params,
					new ResultSetExtractor() {
						public Object extractData(ResultSet rs)
								throws SQLException {

							List<String> keyList = new ArrayList<String>();
							String keyName = "";
							while (rs.next()) {
								keyName = rs.getString("MISC_KEY");
								keyList.add(keyName);
							}

							return keyList;
						}
					});
		}
	}

	public List getPerfLogKeys(LogPerf logPerf) throws NCASException {
		final String METHOD_NAME = "getPerfLogKeys => ";
		_LOGGER.info(METHOD_NAME + " Entering");
		try {
			selectPerfLogKeys = new SelectPerfLogKeys(SELECT_LOG_KEYS);
			_LOGGER.info(METHOD_NAME + "Exiting");
			return selectPerfLogKeys.getLogKeys(new Object[] {
					logPerf.getDomain(), logPerf.getStartTimestamp(),
					logPerf.getModule() });
		} catch (Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					LogPerfDAOImpl.class, vamEx);
		}
	}

	class SelectPerfLogDetails extends JdbcDaoSupport {
		private String sql;

		public SelectPerfLogDetails(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map getLogDetails(Object[] params) {
			final String METHOD_NAME = "getLogDetails => ";
			_LOGGER.info(METHOD_NAME + " Entering");
			return (Map) getDBTemplate().query(sql, params,
					new ResultSetExtractor() {
						public Object extractData(ResultSet rs)
								throws SQLException {

							List logList = null;
							Map resultMap = new HashMap();
							int pageId = 0;
							String startTs = null;
							String endTs = null;
							int elapsedTs = 0;
							int pageIdBosi = 0;
							String startTsBosi = null;
							String endTsBosi = null;
							int elaspsedTsBosi = 0;
							String portalLoginId = null;
							int rowValue = 0;

							while (rs.next()) {
								logList = new ArrayList();
								pageId = rs.getInt("PAGE_ID");
								startTs = rs.getString("START_TS");
								endTs = rs.getString("END_TS");
								elapsedTs = rs.getInt("ELASPED_TIME");
								startTsBosi = rs.getString("BOSI_START_TS");
								endTsBosi = rs.getString("BOSI_END_TS");
								elaspsedTsBosi = rs.getInt("BOSI_ELASPED_TIME");
								portalLoginId = rs.getString("PORTAL_LOGIN_ID");
								if (startTs == null) {
									startTs = "NF";
								}
								if (endTs == null) {
									endTs = "NF";
								}
								if (startTsBosi == null) {
									startTsBosi = "NF";
								}
								if (endTsBosi == null) {
									endTsBosi = "NF";
								}
								if (portalLoginId == null) {
									portalLoginId = "NF";
								}
								logList.add(pageId);
								logList.add(startTs);
								logList.add(endTs);
								logList.add(elapsedTs);
								logList.add(startTsBosi);
								logList.add(endTsBosi);
								logList.add(elaspsedTsBosi);
								logList.add(portalLoginId);
								resultMap.put(rowValue, logList);
								rowValue++;
							}

							return resultMap;
						}
					});
		}
	}

	public Map getPerfLogDetails(Map inputMap) throws NCASException {
		final String METHOD_NAME = "getPerfLogDetails => ";
		_LOGGER.info(METHOD_NAME + " Entering");

		Map resultMap = new HashMap();

		String domainName = "";
		String startTs = "";
		String module = "";
		int elapsedTime = 0;
		try {
			LogPerf logPerf = (LogPerf) inputMap.get("inputMap");
			selectPerfLogDetails = new SelectPerfLogDetails(SELECT_LOG_DETAILS);
			domainName = logPerf.getDomain();
			startTs = logPerf.getStartTimestamp();
			elapsedTime = logPerf.getElapsedTime();
			// module = logPerf.getModule();
			_LOGGER.info("domainName::" + domainName);
			_LOGGER.info("startTs::" + startTs);
			// _LOGGER.info("module::"+module);
			_LOGGER.info("elapsedTime::" + elapsedTime);
			resultMap = selectPerfLogDetails.getLogDetails(new Object[] {
					domainName, startTs, elapsedTime, startTs });

		} catch (Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					LogPerfDAOImpl.class, vamEx);
		}
		return resultMap;
	}

	public Map logAnalysis(Map inputMap) throws NCASException {
		Map resultMap = new HashMap();
		final String METHOD_NAME = "logAnalysis => ";
		_LOGGER.info(METHOD_NAME + " Entering");

		try {
			String domainName = (String) inputMap.get("domain");
			selectPerfLogDetails = new SelectPerfLogDetails(
					SELECT_PERF_LASTUPDATED);

			resultMap = selectPerfLogDetails
					.getLogDetails(new Object[] { domainName });

		} catch (Exception vamEx) {
			_LOGGER.error(METHOD_NAME + " Failed \n" + vamEx.getMessage());
			throw new NCASException(NCASBOSIConstants.DB_ADMIN_EXCEPTION_950,
					LogPerfDAOImpl.class, vamEx);
		}
		return resultMap;
	}

}
