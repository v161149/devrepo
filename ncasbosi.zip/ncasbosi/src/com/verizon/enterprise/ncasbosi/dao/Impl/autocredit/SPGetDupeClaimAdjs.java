package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/**
 * @author v992473
 * This class represents the GET_DUP_ADJ_DTLS api 
 * It is used to get duplicate claims/adjustments for a given claim number 
 * 
 */

public class SPGetDupeClaimAdjs extends BaseStoredProcedure {
	
	private final static Logger _LOGGER = Logger.getLogger(SPGetDupeClaimAdjs.class);
	private static List<Object[]> spInOutList;
	
	static{		 
		 spInOutList = new ArrayList<Object[]>();
		 spInOutList.add(new Object[]{"DUPE_CLAIM_ADJS_LIST", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetDupeClaimAdjsMapper()});
		 spInOutList.add(new Object[]{"ESG_CLAIM_NUMBER", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});		 
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});		 
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});		 
	 }
	
	public SPGetDupeClaimAdjs(DataSource dataSource){
		super(dataSource, NCASBOSIConstants.SP_GET_DUP_ADJ_DTLS, spInOutList);
	}
	
	public Map<String,Object> executeStoredProcedure(Object pInput)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());
		Map<String,Object> inputMap = (HashMap<String,Object>)pInput;
		_LOGGER.info("inputMap::"+inputMap);
		if(inputMap==null){
			throw new Exception("Input Object cannot be null");
		}
				
		String userAction = (String)inputMap.get("USER_ACTION");
		String claimNumber = (String)inputMap.get("ESG_CLAIM_NUMBER");
		
		List<Object> inputList = new ArrayList<Object>();
		inputList.add(new BigDecimal(claimNumber));//ESG_CLAIM_NUMBER
		inputList.add(userAction);//USER_ACTION
		
		Map<String,Object> resMap = executeSP(inputList, false);
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;	
	}	
}
