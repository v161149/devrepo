package com.verizon.enterprise.ncasbosi.dao.Impl.payments;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;
import com.verizon.enterprise.common.ncas.payments.Pay;
import com.verizon.enterprise.common.ncas.payments.PaymentDetails;
import com.verizon.enterprise.common.ncas.payments.PaymentProfile;
import com.verizon.enterprise.common.ncas.payments.RecurPayment;

public class Lv2Lv3Handler {
	private static final Logger _LOGGER = Logger.getLogger(Lv2Lv3Handler.class);
	public Pay pay;
	public PaymentDetails payDetails;
	public RecurPayment recurPay;
	public PaymentProfile payProfile;
	public String level_2_3="";

	public Lv2Lv3Handler(){

	}

	public Lv2Lv3Handler(Pay payment,PaymentProfile payProfile){
		this.payProfile=payProfile;
		this.pay=payment;
		if(payment instanceof PaymentDetails){
			this.payDetails=(PaymentDetails)payment;
		}
		else if(payment instanceof RecurPayment){
			this.recurPay=(RecurPayment)payment;
		}
	}

	public String getLevel_2_3() throws ParseException{
		final String METHOD_NAME = "getLevel_2_3 => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		StringBuffer sb = new StringBuffer();
		String length = SystemParamConfig.getProperty("PAY_LEVEL2_LENGTH");
		int totalAttr = 0;
		String standardSuffix = "_PAY_LV2";

		if (!length.isEmpty())
		{
			totalAttr = Integer.parseInt(length);
		}

		for (int i=1;i<=totalAttr;i++)
		{
			String index = Integer.toString(i);
			String key = index + standardSuffix;
			sb.append(processMetaData(key,SystemParamConfig.getProperty(key)));
		}
		this.level_2_3=sb.toString();
		_LOGGER.info(METHOD_NAME+":portal track id:"+pay.getPortalTrackID()+"::service id:"+pay.getServiceID()+"::lv2lv3 String:"+this.level_2_3);
		_LOGGER.info(METHOD_NAME+":lv2lv3 String Length:"+this.level_2_3.length());
		_LOGGER.info(METHOD_NAME+"Exiting");
		return this.level_2_3;
	}

	//This converts the VALUE to the actual value expected by ePay
	public String processMetaData(String key, String value) throws ParseException
	{
		String result = "";
		String sourceKey = getLinKeyValue(value, "SOURCE");
		String constant = getLinKeyValue(value, "CONSTANT");
		int length = Integer.parseInt(getLinKeyValue(value, "LENGTH"));
		String pad = getLinKeyValue(value, "PADDING");
		String just = getLinKeyValue(value, "JUST");
		if ((pad != null) && (pad.trim().length() > 0))
		{
			if (sourceKey != null && sourceKey.trim().length() > 0)
				result = applyPad(getSource(sourceKey), length, pad, just);
			else
				result = applyPad(constant, length, pad, just);
		}
		else
		{
			if (sourceKey != null && sourceKey.trim().length() > 0)
				result = getSource(sourceKey);
			else
				result = constant;
		}
		return result;
	}
	public String getSource(String sourceKey) throws ParseException{
		String result="";
		if(this.pay instanceof PaymentDetails){
			result= getSourceDetails(sourceKey);
		}
		else if(this.pay instanceof RecurPayment){
			result=getSourceRecur(sourceKey);
		}
		return result;
	}
	//This method is used to handle cases where the value has to be derived from SP or fetched from PL_PAY_RECUR
	public String getSourceRecur(String sourceKey) throws ParseException{
		String result="";
		_LOGGER.info("Not Implemeted Yet.");
		return result;
	}
	
	protected String getTaxAmtString(double taxAmt)
	{
		String temp =Double.toString(taxAmt).trim();
		String dollars = "0";
		String cents = "0";
		StringTokenizer st = new StringTokenizer(temp, ".");
		dollars = st.nextToken();
		if (st.hasMoreTokens())
		{
			cents = st.nextToken();
			if (cents.length() > 2)
			{
				cents = cents.substring(0, 2);
			}
			else if (cents.length() < 2)
			{
				cents = applyPad(cents, 2, "ZEROS", "L");
			}
		}
		//Calculate final amt
		int total = Integer.parseInt(dollars) * 100 + Integer.parseInt(cents);
		String retResult=String.valueOf(total);
		return retResult;
	}
	//This method is used to handle cases where the value has to be derived or fetched from PL_PAY_DETAILS
	public String getSourceDetails(String sourceKey) throws ParseException
	{
		String result = "";
		if (sourceKey.equals("SALES_TAX"))
		{
			//amount of sales tax in cents
			/*String taxAmt= payDetails.getSalesTax().trim();
			double temp=(Double.parseDouble(taxAmt))*100;
			int tempTax=(int)temp;
			result=String.valueOf(tempTax);*/
			result=getTaxAmtString(payDetails.getSalesTax());
		}
		else if (sourceKey.equals("CUST_CODE"))
		{
			result = payDetails.getCustAcctNum().trim();
		}
		else if (sourceKey.equals("SALES_TAX_IND"))
		{
			result = payDetails.getSalesTaxIndicator().trim();
		}
		else if(sourceKey.equals("SERVICE_ID"))
		{
			result=payDetails.getServiceID().trim();
		}
		else if (sourceKey.equals("ORDER_DATE"))
		{
			// format (YYMMDD)from(yyyy-MM-dd)
			String invDate =payDetails.getInvoiceDate();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			GregorianCalendar temp = new GregorianCalendar();
			temp.setTime(df.parse(invDate));
			String month = String.valueOf((temp.get(Calendar.MONTH))+1);
			if(month.length()<2){
				month="0"+month;
			}
			String year =String.valueOf((temp.get(Calendar.YEAR))%100);
			if(year.length()<2){
				year="0"+year;
			}
			String day = String.valueOf(temp.get(Calendar.DAY_OF_MONTH));
			if(day.length()<2){
				day="0"+day;
			}
			result=year+month+day;

		}
		else if (sourceKey.equals("DEST_ZIP"))
		{
			result = payDetails.getDestinationZip().trim();
		}
		else if (sourceKey.equals("DEST_COUNTRY"))
		{
			result = payDetails.getDestinationCountryCode().trim();
		}
		else if (sourceKey.equals("ITEM_COM_PROD_CODE"))
		{
			result =payDetails.getCustAcctNum().trim();
		}
		else if (sourceKey.equals("ITEM_PROD_CODE"))
		{
			result = payDetails.getCustAcctNum().trim();
		}
		else if (sourceKey.equals("ITEM_QUANTITY"))
		{
			String cardType=payProfile.getTypeCode().trim();
			if(cardType.equalsIgnoreCase("VI"))
			{
				result = "000000010000";
			}
			else if(cardType.equalsIgnoreCase("MC"))
			{
				result = "000000010000";
			}
			else if(cardType.equalsIgnoreCase("AE"))
			{
				result = "000000000001";
			}
			else if(cardType.equalsIgnoreCase("DC"))
			{
				result = "000000000001";
			}
		}
		else if (sourceKey.equals("EXTND_ITEM_AMNT"))
		{
			// in hundredths of cent (four implied decimal places)
			String itemAmt =Double.toString( payDetails.getPaymentAmnt()).trim();
			String dollars = "0";
			String cents = "0";
			StringTokenizer st = new StringTokenizer(itemAmt, ".");
			dollars = st.nextToken();
			if (st.hasMoreTokens())
			{
				cents = st.nextToken();
				if (cents.length() > 4)
				{
					cents = cents.substring(0, 4);
				}
				else if (cents.length() < 4)
				{
					cents = applyPad(cents, 4, "ZEROS", "L");
				}
			}
			//Calculate final amt
			int total = Integer.parseInt(dollars) * 10000 + Integer.parseInt(cents);
			result=String.valueOf(total);
		}
		else if (sourceKey.equals("ITEM_TAX_AMNT"))
		{
			// amount in cents
			String cardType=payProfile.getTypeCode().trim();
			if((cardType.equalsIgnoreCase("MC"))|| (cardType.equalsIgnoreCase("DC")))
			{
				/*String taxAmt= payDetails.getSalesTax().trim();
				double temp=(Double.parseDouble(taxAmt))*100;
				int tempTax=(int)temp;
				result=String.valueOf(tempTax);*/
				result=getTaxAmtString(payDetails.getSalesTax());
			}
		}
		return result;
	}


	//Padding handler
	public String applyPad(String value, int length, String padType, String just)
	{
		String zeros = "000000000000000000000000000000000000000000000000000000000000000000000000";
		String spaces = "                                                                        ";
		String temp = "";

		if (value.length() < length)
		{
			if (padType.equals("ZEROS"))
				temp = zeros.substring(0, length - value.length());
			else
				temp = spaces.substring(0, length - value.length());
		}
		else if (value.length() > length)
			value = value.substring(0, length);
		if (just.equals("L") || just.equals(""))
			return value + temp;
		else
			return temp + value;
	}

	//This is used to obtain the values of the individual tokens of PL_SYS_PARM_T.VALUE
	public String getLinKeyValue(String linkParam , String compareTo)
	{
		String value ="";
		String[] params = linkParam.split(" AND ");
		return getLinKeyValue (params , compareTo );
	}

	//A helper
	public String getLinKeyValue(String[] params , String compareTo)
	{
		String value ="";
		int paramCount = params.length;
		for (int lnkIndex=0; lnkIndex<paramCount; lnkIndex++)
		{
			if(params[lnkIndex].contains(compareTo))
			{
				String keyValue[] = params[lnkIndex].split("=");
				value = keyValue[1];
				if(value.contains("'"))
					value = value.replace("'", "");
			}
		}
		return value.trim();
	}


}
