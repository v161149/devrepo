package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

/*
 * get late payment charges for all bills between from date and thru date.
 * this api is not called by ul directly, the get adjustments api calls this.
 */

public class SPGetLatePayCharges extends BaseStoredProcedure {
	
	private static final Logger _LOGGER = Logger.getLogger(SPGetLatePayCharges.class);
	private static List spInOutList;
	
	static{
		 _LOGGER.info("Static init ");
		 spInOutList = new ArrayList();
		 
	     spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetLatePayChargesMapper()});
		 
		 spInOutList.add(new Object[]{"APP_USER_ID",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL",  getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
		 spInOutList.add(new Object[]{"RETURN_CODE",  getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT",   getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE",   getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE",  getSqlDataType(Types.CHAR),   NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 
		 spInOutList.add(new Object[]{"MAN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN",         getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"OSID",        getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"FROM_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"THRU_DATE",   getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 
	 }
	
	public SPGetLatePayCharges(DataSource dataSource){
		super(dataSource, getVAMSchemaName() + "." + NCASBOSIConstants.SP_GET_LPCS, spInOutList);
	}
	
	public Map executeStoredProcedure(Object input)throws Exception{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		/* get input values */
		Map inputMap = (HashMap)input;
		VamDO vamDO = (VamDO)inputMap.get("vamDO");
		_LOGGER.info("input DO::"+vamDO);
		String billDate = (String)inputMap.get("billDate");
		_LOGGER.info("input billDate::"+billDate);
		
		if (vamDO == null){
			throw new Exception("SPGetLatePayCharges: input data object is null");
		}
		if (billDate == null){
			throw new Exception("SPGetLatePayCharges: input billDate is null");
		}

		
		String formatIn = "MM/dd/yyyy";
		String formatOut = "yyyy-MM-dd";
		//convert date user entered into date db2 can use.
		String fromDate = CommonUtil.formatDate(billDate, formatIn, formatOut);
		String thruDate = CommonUtil.formatDate(billDate, formatIn, formatOut);
		
		/* display inputs */
		_LOGGER.info("fromDate db2 ::"+fromDate);
		_LOGGER.info("thruDate db2 ::"+thruDate);
		
		/* map input vars to sp parameters */
		List callList = new ArrayList();
		callList.add("SPGetBillElements");   // APP_USER_ID       CHAR (20) 
		callList.add("0");                 // DEBUG_LEVEL       CHAR (1)
		
		callList.add(vamDO.getMan());      // MAN               CHAR (13)
		callList.add(vamDO.getBan());      // BAN               CHAR (13)
		callList.add(vamDO.getOsid());     // OSID              CHAR (2)
		callList.add(fromDate);            // FROM_DATE         CHAR (10)
		callList.add(thruDate);            // THRU_DATE         CHAR (10)
		
		/* execute sp */
		Map resMap = executeSP(callList, false);
		
		/* look for errors */
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}
}
