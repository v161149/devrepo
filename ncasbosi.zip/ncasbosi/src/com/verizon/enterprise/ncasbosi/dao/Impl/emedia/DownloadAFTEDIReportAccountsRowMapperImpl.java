package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadAFTEDIReportAccountsRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadAFTEDIReportAccountsRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		_LOGGER.info("Inside DownloadAFTEDIReportAccountsRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List accountsList = new ArrayList();
		List account = new ArrayList();
		try {
			while(rs.next()) {
				account = new ArrayList();

				//Set the values
				String requestNumber = rs.getString("REQUEST_NO");
				String accountNumber = rs.getString("ACCOUNT");
				String status = rs.getString("STATUS");
				String man = rs.getString("MAN");
				String ban = rs.getString("BAN");
				String aban = rs.getString("ABAN");
				String profStatus = rs.getString("PROF_STATUS");
				String sourceSystem = rs.getString("ORIG_SOURCE_SYSTEM");// - Varchar(1)
				String ebid = rs.getString("EBID");//- Char(6)
				String deliveryStatus = rs.getString("DELIVERY_STATUS");
				String invoiceNumber = rs.getString("INVOICE_NUMBER");
				String archiveFileName = rs.getString("ARCHIVE_FILE_NAME");
				String commOutputFileName = rs.getString("COMM_OUTPUT_DSN");
				String vz450OutputFileName = rs.getString("VZ450_INPUT_DSN");
				String commMethod = rs.getString("COMM_METHOD");
				String isaControlNumber = rs.getString("ISA_CNTL_NUM");
				String isaSenderQualilfier = rs.getString("ISA_SENDER_QUAL");
				String isaSenderId = rs.getString("ISA_SENDER_ID");
				String gsSenderId = rs.getString("GS_SENDER_ID");
				String isaReceiverQualifier = rs.getString("ISA_RECVR_QUAL");
				String isaReceiverId = rs.getString("ISA_RECVR_ID");
				String gsReceiverId = rs.getString("GS_RECVR_ID");

				if(CommonUtil.isNotNull(requestNumber)) {
					account.add(new Cell(requestNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(accountNumber)) {
					account.add(new Cell(accountNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(status)) {
					account.add(new Cell(status.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(man)) {
					account.add(new Cell(man.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ban)) {
					account.add(new Cell(ban.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(aban)) {
					account.add(new Cell(aban.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(profStatus)) {
					account.add(new Cell(profStatus.trim()));
				} else {
					account.add(new Cell(""));
				}
				try {
					Date lastDate = rs.getDate("LAST_BILL_DATE");//Date
					if (lastDate != null) {
						String lastDateStr =  formatter.format(lastDate);
						if(CommonUtil.isNotNull(lastDateStr)) {
							account.add(new Cell(lastDateStr.trim()));
						}
					}
				} catch(IllegalArgumentException iae) {
					account.add(new Cell(""));
				} catch(SQLException sqle) {
					account.add(new Cell(""));
				}
				try {
					Date invoiceDate = rs.getDate("INVOICE_DT");//Date
					if (invoiceDate != null) {
						String invoiceDateStr =  formatter.format(invoiceDate);
						if(CommonUtil.isNotNull(invoiceDateStr)) {
							account.add(new Cell(invoiceDateStr.trim()));
						}
					}
				} catch(IllegalArgumentException iae) {
					account.add(new Cell(""));
				} catch(SQLException sqle) {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(sourceSystem)) {
					account.add(new Cell(sourceSystem.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(ebid)) {
					account.add(new Cell(ebid.trim()));
				} else {
					account.add(new Cell(""));
				}
				try {

					Date startDate = rs.getDate("ACCT_START_DATE");
					if (startDate != null) {
						String startDateStr =  formatter.format(startDate);
						if(CommonUtil.isNotNull(startDateStr)) {
							account.add(new Cell(startDateStr.trim()));
						}
					}
				} catch(IllegalArgumentException iae) {
					account.add(new Cell(""));
				} catch(SQLException sqle) {
					account.add(new Cell(""));
				}
				try {
					Date endDate = rs.getDate("ACCT_END_DATE");
					if (endDate != null) {
						String endDateStr =  formatter.format(endDate);
						if(CommonUtil.isNotNull(endDateStr)) {
							account.add(new Cell(endDateStr.trim()));
						}
					}
				} catch(IllegalArgumentException iae) {
					account.add(new Cell(""));
				} catch(SQLException sqle) {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(deliveryStatus)) {
					account.add(new Cell(deliveryStatus.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(invoiceNumber)) {
					account.add(new Cell(invoiceNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(archiveFileName)) {
					account.add(new Cell(archiveFileName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(commOutputFileName)) {
					account.add(new Cell(commOutputFileName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(vz450OutputFileName)) {
					account.add(new Cell(vz450OutputFileName.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(commMethod)) {
					account.add(new Cell(commMethod.trim()));
				} else {
					account.add(new Cell(""));
				}
				try {
					Date commDeliveryDate = rs.getDate("COMM_DELV_DT");
					if (commDeliveryDate != null) {
						String commDeliveryDateStr =  formatter.format(commDeliveryDate);
						if(CommonUtil.isNotNull(commDeliveryDateStr)) {
							account.add(new Cell(commDeliveryDateStr.trim()));
						}
					}
				} catch(IllegalArgumentException iae) {
					account.add(new Cell(""));
				} catch(SQLException sqle) {
					account.add(new Cell(""));
				}
				try {
					Date customerAckDate = rs.getDate("CUST_ACK_DT");
					if (customerAckDate != null) {
						String customerAckDateStr =  formatter.format(customerAckDate);
						if(CommonUtil.isNotNull(customerAckDateStr)) {
							account.add(new Cell(customerAckDateStr.trim()));
						}
					}
				} catch(IllegalArgumentException iae) {
					account.add(new Cell(""));
				} catch(SQLException sqle) {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(isaControlNumber)) {
					account.add(new Cell(isaControlNumber.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(isaSenderQualilfier)) {
					account.add(new Cell(isaSenderQualilfier.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(isaSenderId)) {
					account.add(new Cell(isaSenderId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(gsSenderId)) {
					account.add(new Cell(gsSenderId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(isaReceiverQualifier)) {
					account.add(new Cell(isaReceiverQualifier.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(isaReceiverId)) {
					account.add(new Cell(isaReceiverId.trim()));
				} else {
					account.add(new Cell(""));
				}
				if(CommonUtil.isNotNull(gsReceiverId)) {
					account.add(new Cell(gsReceiverId.trim()));
				} else {
					account.add(new Cell(""));
				}
				accountsList.add(account);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadAFTEDIReportAccountsRowMapperImpl's account -  " + account);
		}
		return accountsList;
	}
}
