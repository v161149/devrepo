package com.verizon.enterprise.ncasbosi.dao.Impl.status;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.eMedia.EMediaAcctTeamInfo;
import com.verizon.enterprise.common.eMedia.EMediaCustInfo;
import com.verizon.enterprise.common.eMedia.EMediaDropDown;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.common.eMedia.EMediaRecord;
import com.verizon.enterprise.common.eMedia.EMediaTransDetailInfo;
import com.verizon.enterprise.common.status.BaseReportList;
import com.verizon.enterprise.common.status.CurrentReports;
import com.verizon.enterprise.common.status.ScheduledReports;
import com.verizon.enterprise.common.status.ReportsAddParam;
import com.verizon.enterprise.common.status.StatusSchedulingUtility;
import com.verizon.enterprise.common.status.TableCell;
import com.verizon.enterprise.common.status.TableHeaderCell;
import com.verizon.enterprise.common.status.TableRow;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class GetUserRptScheduledRowMapperImpl  implements ResultSetExtractor {
	
	static private final Logger _LOGGER = Logger.getLogger(GetUserRptScheduledRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside GetUserRptScheduledRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		EMediaRecord emediaRecord = null;
		double acctSubscriptionOid = 0.0;
		double previousOid = 0.0;
		List refList = null;
		
		String key = "";
		ArrayList al = new ArrayList();
		
		al.add(new String[] { "REPORT_TITLE", "SUBSCRIBER_NAME",
				"ACCT_LIST_NAME", "SCHEDULED_DATE", "END_DATE", "FREQUENCY",
				"ACTIVE_IND" });
		
		try {

			
			 while (rs.next()) {

				ReportsAddParam schedRptAddParam = new ReportsAddParam();
				String reportTitle = rs.getString("REPORT_TITLE");
				String subName = rs.getString("SUBSCRIBER_NAME");
				String selType = rs.getString("SELECTION_TYPE");
				String listName = null;
				String acctListName = rs.getString("ACCT_LIST_NAME");
				String acctListType = rs.getString("ACCT_LIST_TYPE");
				
				if(selType!=null){
					selType = selType.trim();
				}
				if(acctListName!=null){
					acctListName = acctListName.trim();
				}
				if(acctListType!=null){
					acctListType = acctListType.trim();
				}
				
				if ("A".equalsIgnoreCase(selType)) {
					listName = "All";
				} else if ("B".equalsIgnoreCase(selType)) {
					listName = "Invoice Type "
							+ rs.getString("BILL_TYPE_FILTER");
				} else if ("L".equalsIgnoreCase(selType)) {
					if ("ANON".equalsIgnoreCase(acctListType)) {
						schedRptAddParam.setAnonListName(rs
								.getString("ACCT_LIST_NAME"));
						listName = "Account Selection List";
					} else
						listName = acctListName;
				}
				String billDate = rs.getString("BILL_DATE");
				String startDate = CommonUtil.getDisplayVAMDateFromString(rs
						.getDate("SCHEDULED_DATE"));
				String endDate = CommonUtil.getDisplayVAMDateFromString(rs
						.getDate("END_DATE"));
				String frequency = rs.getString("FREQUENCY");
				if (frequency != null) {
					if ("O".equalsIgnoreCase(frequency.trim())) {
						frequency = "One Time";
					} else if ("M".equalsIgnoreCase(frequency.trim())) {
						frequency = "Monthly";
					}
				}
				String status = "";
				// String compDate = CommonUtil.getDisplayDateFromString(rs
				// .getDate("STATUS_TIMESTAMP"));
				// String statusMsg = rs.getString("STATUS_MESSAGE");
				String activeInd = rs.getString("ACTIVE_IND");

				if ("I".equalsIgnoreCase(activeInd))
					status = "Inactive";
				else
					status = "Active";

				schedRptAddParam.setSelectionType(selType);
				schedRptAddParam.setAcctListType(acctListType);
				schedRptAddParam.setAcctListName(listName);
				schedRptAddParam.setBillTypeFilter(rs
						.getString("BILL_TYPE_FILTER"));
				schedRptAddParam.setSubscriberName(rs
						.getString("SUBSCRIBER_NAME"));
				schedRptAddParam.setOsid(rs.getString("ORIG_SYSTEM_ID"));
				schedRptAddParam.setCorpId(rs.getString("CORP_ID"));
				schedRptAddParam.setBanDan(rs.getString("BAN_DAN"));
				schedRptAddParam.setTnType(rs.getString("TN_TYPE"));
				// schedRptAddParam.setSchedledInd(rs.getString("SCHEDULED_IND"));
				// currRptAddParam.setScheduledDate(CommonUtil.getDisplayDateFromString(rs.getDate("SCHEDULED_DATE")));
				schedRptAddParam.setScheduldRptId(rs
						.getString("SCHEDULED_RPT_ID"));
				_LOGGER.info("SCHEDULED_RPT_ID :"
						+ rs.getString("SCHEDULED_RPT_ID"));
				schedRptAddParam.setThruDate(rs.getString("THRU_DATE"));
				// currRptAddParam.setRetryCout(rs.getString("RETRY_COUNT"));
				schedRptAddParam.setReportNumber(rs.getInt("REPORT_NUMBER"));
				
				if(selType != null && selType.trim().equalsIgnoreCase("S")){
					schedRptAddParam.setAcctListName(schedRptAddParam.getBanDan());
				}

				al.add(new Object[] { reportTitle, subName, schedRptAddParam,
						startDate, endDate, frequency, status });

			}
			 
			 _LOGGER.info("al size = "  + al.size());
			// _LOGGER.info("al DATA = "  + al.toString());

			 ScheduledReports object = populateScheduledReportsDataModel(al);
			 
			
			 
			 //object = (BaseReportList) populateCurrentReportsDataModel(al);
			 
			 //_LOGGER.debug("after populating datamodel  " + (CurrentReports) object );
			
		     printScheduledReportsDataModel(object);	 
		     //_LOGGER.debug("adding printing datamodel  " );
		     returnMap.put("schedReport", (ScheduledReports)  object);
		     

		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"
					+ nfe.getMessage());
			throw nfe;
		}
		return returnMap;
	}

	private void printScheduledReportsDataModel(ScheduledReports schedRpt) {
		if (schedRpt != null) {
			//System.out.println(schedRpt.toString());
		} else {
			//System.out.println("scheduled report data Model not created");
		}
	}

	
	
	
	public ScheduledReports populateScheduledReportsDataModel(ArrayList al) {
		
		String METHOD_NAME = " populateCurrentReportsDataModel";
		_LOGGER.debug(METHOD_NAME + "Exception occured while parsing the resultset \n");
		
		ScheduledReports scheduledReports = new ScheduledReports();
		/*
		 * String[] total = (String[]) al.get(0);
		 * currentReports.setPageOffset(Integer.parseInt(total[0]));
		 * currentReports.setPageSize(Integer.parseInt(total[1]));
		 * currentReports.setTotalRows(Integer.parseInt(total[2]));
		 */
		scheduledReports.setRecordsReturned(al.size() - 1);
		
		_LOGGER.debug(METHOD_NAME + "records returned = " + scheduledReports.getRecordsReturned());
		

		// Setting Header row
		ArrayList objectHeader = new ArrayList();
		String[] dbName = (String[]) al.get(0);
		for (int k = 0; k < dbName.length; k++) {
			//_LOGGER.debug(METHOD_NAME + "header parsing  " + k);
			TableHeaderCell header = new TableHeaderCell();
			header.setDbName((String)dbName[k]);
			//_LOGGER.debug(METHOD_NAME + "header cell values  " + dbName[k]);
			header.setRightJustify(StatusSchedulingUtility
					.getRightJustificationInfo("ScheduledReport", dbName[k]));
			header.setUiName(StatusSchedulingUtility.getUIName("ScheduledReport",
					dbName[k]));
			header.setSortInfo(StatusSchedulingUtility.getSortInfo(
					"ScheduledReport", dbName[k]));
			header.setFilterInfo(StatusSchedulingUtility.getFilterInfo(
					"ScheduledReport", dbName[k]));
			objectHeader.add(header);
		}
		//_LOGGER.debug(METHOD_NAME + "adding header row into datamodel  " );
		scheduledReports.setTableHeaderRow((TableHeaderCell[]) objectHeader
				.toArray(new TableHeaderCell[0]));

		// setting data row. fsdfsdf
		//sdfsdfsdf
		ArrayList object = new ArrayList();
		for (int i = 1; i < al.size(); i++) {
			//_LOGGER.debug(METHOD_NAME + "header total rows values  " + i);
			TableRow tableRow = new TableRow();
			Object[] cellValues = (Object[]) al.get(i);
			ArrayList cellArrayList = new ArrayList();
			for (int z = 0; z < cellValues.length; z++) {
				//_LOGGER.debug(METHOD_NAME + "header cell values  " + z);
				//_LOGGER.debug(METHOD_NAME + "header cell values  " + cellValues[z]);
				TableCell tableCell = new TableCell();
				
				if(cellValues[z] != null)
					tableCell.setCellValue(cellValues[z]);
				else if(cellValues[z] == null)
					tableCell.setCellValue("");
				
				tableCell.setDataType(StatusSchedulingUtility.getDataType(
						"ScheduledReport", dbName[z]));
				tableCell.setRightJustify(StatusSchedulingUtility
						.getRightJustificationInfo("ScheduledReport", dbName[z]));
				tableCell.setWrapInfo(StatusSchedulingUtility.getColWrapInfo(
						"ScheduledReport", dbName[z]));
				cellArrayList.add(tableCell);
			}
			tableRow.setTableCell((TableCell[]) cellArrayList
					.toArray(new TableCell[0]));
			object.add(tableRow);
		}
		//_LOGGER.debug(METHOD_NAME + "adding data into datamodel  " );
		scheduledReports.setTableRows((TableRow[]) object.toArray(new TableRow[0]));
		//_LOGGER.debug(METHOD_NAME + "after adding data into datamodel  " );
		return scheduledReports;
	}
}