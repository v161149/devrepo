package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadAFTReportViewRequestRowMapperImpl implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(DownloadAFTReportViewRequestRowMapperImpl.class);

	public Object extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		_LOGGER.info("Inside DownloadAFTReportViewRequestRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List requestsList = new ArrayList();
		List request = new ArrayList();
		try {
			while(rs.next()) {
				request = new ArrayList();
				
				String requestNumber = rs.getString("REQUEST_NO");//Char(17)
				//String afpUserId = rs.getString("APP_USER_ID");//Char(20)
				String userName = rs.getString("USER_NAME");//Char(50)
				String configType = rs.getString("CONFIG_TYPE");//Char(20)
				String configId = rs.getString("CONFIG_ID");//Char(20)
				String customerName = rs.getString("CUSTOMER_NAME");//Char(55)
				String action = rs.getString("ACTION");//Char(8)
				String mode = rs.getString("MODE");//Char(8)

				//Date startDate = rs.getDate("START_DATE");//Date
				//SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				//String startDateStr =  formatter.format(startDate);
				String startDateStr =  rs.getString("START_DATE");//Date
				
				String comments = rs.getString("COMMENTS");//LongVarchar(500)
				String fileName = rs.getString("SS_FILE_NAME");//Varchar(100)
				String status = rs.getString("STATUS");//Char(10)
				String billMonth = rs.getString("BILL_MONTH");//Char(2)
				String billYear = rs.getString("BILL_YEAR");//Char(4)
				int recordCount = rs.getInt("RECORD_COUNT");//SmallInt
				int recordsFailedCount = rs.getInt("RECORDS_FAILED");//SmallInt
				int recordsAddedCount = rs.getInt("RECORDS_ADDED");//SmallInt
				int recordsDeletedCount = rs.getInt("RECORDS_DELETE");//SmallInt
				
				if(CommonUtil.isNotNull(requestNumber)) {
					request.add(new Cell(requestNumber.trim()));
				}
				if(CommonUtil.isNotNull(userName)) {
					request.add(new Cell(userName.trim()));
				}
				if(CommonUtil.isNotNull(configType)) {
					request.add(new Cell(configType.trim()));
				}
				if(CommonUtil.isNotNull(configId)) {
					request.add(new Cell(configId.trim()));
				}
				if(CommonUtil.isNotNull(customerName)) {
					request.add(new Cell(customerName.trim()));
				}
				if(CommonUtil.isNotNull(action)) {
					request.add(new Cell(action.trim()));
				}
				if(CommonUtil.isNotNull(mode)) {
					request.add(new Cell(mode.trim()));
				}
				if(CommonUtil.isNotNull(startDateStr)) {
					request.add(new Cell(startDateStr.trim()));
				}
				if(CommonUtil.isNotNull(comments)) {
					request.add(new Cell(comments.trim()));
				}
				if(CommonUtil.isNotNull(fileName)) {
					request.add(new Cell(fileName.trim()));
				}
				if(CommonUtil.isNotNull(status)) {
					request.add(new Cell(status.trim()));
				}
				if(CommonUtil.isNotNull(billMonth)) {
					request.add(new Cell(billMonth.trim()));
				}
				if(CommonUtil.isNotNull(billYear)) {
					request.add(new Cell(billYear.trim()));
				}
				if(recordCount >= 0) {
					request.add(new Cell(String.valueOf(recordCount)));
				}
				if(recordsFailedCount >= 0) {
					request.add(new Cell(String.valueOf(recordsFailedCount)));
				}
				if(recordsAddedCount >= 0) {
					request.add(new Cell(String.valueOf(recordsAddedCount)));
				}
				if(recordsDeletedCount >= 0) {
					request.add(new Cell(String.valueOf(recordsDeletedCount)));
				}
				
				requestsList.add(request);
			}
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("DownloadAFTReportViewRequestRowMapperImpl's request -  " + request);
		}
		return requestsList;
	}
}
