package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class FullDownloadVBEAccountsRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(FullDownloadVBEAccountsRowMapperImpl.class);
	
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside FullDownloadVBEAccountsRowMapperImpl::extractData ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> accountsList = new ArrayList<List<Cell>>();
		List<Cell> remit = new ArrayList<Cell>();
		
		try {
			while(rs.next()) {
             remit = new ArrayList<Cell>();

				
				String configId = rs.getString("CONFIG_ID");//VBE Bill Id
				String vbeName=rs.getString("VBE_NAME");//VBE Bill Name
				String remitId = rs.getString("REMIT_ID");//Remit Pt Id
				String remitConfigName = rs.getString("CONFIG_NAME");//Remit Config Name
				String defaultRemit = rs.getString("DEFAULT_REMIT");//Remit Default Ind
				String currencyCode = rs.getString("CURRENCY_CODE");
				String languageCode = rs.getString("LANGUAGE_CODE");
			    String nasp=rs.getString("NASP");
	            String revLoc=rs.getString("REVLOC");
                String custCountry=rs.getString("CUST_COUNTRY");
                String custState=rs.getString("CUST_STATE");
                String postalCode=rs.getString("POSTAL_CODE");
                String custCity=rs.getString("CUST_CITY");
                String custAddress1=rs.getString("CUST_ADDR_1");
                String custAddress2=rs.getString("CUST_ADDR_2");
                String custAddress3=rs.getString("CUST_ADDR_3");
                String serviceId=rs.getString("SERVICE_ID");
                String serviceCountry=rs.getString("SERV_COUNTRY");
                String serviceState=rs.getString("SERV_STATE");
                String servicePostalCode=rs.getString("SERV_POSTAL_CODE");
                String serviceCity=rs.getString("SERV_CITY");
                String serviceAddress1=rs.getString("SERV_ADDR_1");
                String serviceAddress2=rs.getString("SERV_ADDR_2");
                String serviceAddress3=rs.getString("SERV_ADDR_3");
                String serviceProduct=rs.getString("PRODUCT_DESC");
                String corpId=rs.getString("CORP_ID");
                String biller=rs.getString("BILLER");
			    String useVbeAddress=rs.getString("USE_VBE_ADDRESS");
						    		
            	if(CommonUtil.isNotNull(configId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(configId.trim())));
				}
            	if(CommonUtil.isNotNull(vbeName))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(vbeName.trim())));
				}
			
				if(CommonUtil.isNotNull(remitId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitId.trim())));
				}
                if(CommonUtil.isNotNull(remitConfigName))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitConfigName.trim())));
				}
				if(CommonUtil.isNotNull(defaultRemit))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(defaultRemit.trim())));
				}

				if(CommonUtil.isNotNull(currencyCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(currencyCode.trim())));
				}
				if(CommonUtil.isNotNull(languageCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(languageCode.trim())));
				}

				
				if(CommonUtil.isNotNull(nasp))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(nasp.trim())));
				}
            
                if(CommonUtil.isNotNull(revLoc))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(revLoc.trim())));
				}
				if(CommonUtil.isNotNull(custCountry))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custCountry.trim())));
				}
				if(CommonUtil.isNotNull(custState))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custState.trim())));
				}
			
				if(CommonUtil.isNotNull(postalCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(postalCode.trim())));
				}
				if(CommonUtil.isNotNull(custCity))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custCity.trim())));
				}
				if(CommonUtil.isNotNull(custAddress1))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custAddress1.trim())));
				}
				if(CommonUtil.isNotNull(custAddress2))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custAddress2.trim())));
				}
				if(CommonUtil.isNotNull(custAddress3))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custAddress3.trim())));
				}
				if(CommonUtil.isNotNull(serviceId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceId.trim())));
				}
				
				
				
				if(CommonUtil.isNotNull(serviceCountry))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceCountry.trim())));
				}
				if(CommonUtil.isNotNull(serviceState))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceState.trim())));
				}
				if(CommonUtil.isNotNull(servicePostalCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(servicePostalCode.trim())));
				}
				if(CommonUtil.isNotNull(serviceCity))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceCity.trim())));
				}
				if(CommonUtil.isNotNull(serviceAddress1))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceAddress1.trim())));
				}
				if(CommonUtil.isNotNull(serviceAddress2))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceAddress2.trim())));
				}
				if(CommonUtil.isNotNull(serviceAddress3))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceAddress3.trim())));
				}
				if(CommonUtil.isNotNull(serviceProduct))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceProduct.trim())));
				}
				if(CommonUtil.isNotNull(corpId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(corpId.trim())));
				}
				if(CommonUtil.isNotNull(biller))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(biller.trim())));
				}
				if(CommonUtil.isNotNull(useVbeAddress))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(useVbeAddress.trim())));
				}
				
				accountsList.add(remit);
				if(_LOGGER.isEnabledFor(Level.DEBUG)) {
					_LOGGER.debug("DownloadVBEAccountsRowMapperImpl  :: account info ->" + remit);
				}				
			}
		}catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
		}catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("FullDownloadVBEAccountsRowMapperImpl  :: accountsList size = " + accountsList.size());
		}
		return accountsList;
	}
}
