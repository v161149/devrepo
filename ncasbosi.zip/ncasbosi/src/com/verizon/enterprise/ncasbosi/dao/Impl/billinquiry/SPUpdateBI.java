package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.common.ncas.billinquiry.BillInquiryNote;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPUpdateBI  extends BaseStoredProcedure
{

	static private final Logger _LOGGER = Logger.getLogger(SPUpdateBI.class);
	private static List spInOutList;

	static
	{
		_LOGGER.info("Static init");
		spInOutList = new ArrayList();
		spInOutList.add(new Object[]{"USER_ACTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"BI_CATEGORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"UPD_USER_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"COMMENT_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		
		// added these 3 OUT fields ibi Aug/2008
		spInOutList.add(new Object[]{"BI_STATUS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"BI_STATUS_DESC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		spInOutList.add(new Object[]{"SECONDRY_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});		
		spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"USER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		// added these 3 IN fields ibi Aug/2008
		spInOutList.add(new Object[]{"ATTACHMENT_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"SECONDARY_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		spInOutList.add(new Object[]{"PUBLIC_PRIVATE_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
	}

	public SPUpdateBI(DataSource dataSource)
	{

	   super(dataSource, NCASBOSIConstants.SP_UPDATE_BI, spInOutList);

	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		_LOGGER.info("Entering executeStoredProcedure "+getStoredProcedureName());

		List paramValueList = null;
		BillInquiry bi =(BillInquiry)paramValues;
		String noteText = null;
		String pubInd = null;   // 1 is public in vac, 2 private
		String attachmentFlg = null;
		String emeaKey = null;
		
		if(bi != null)
		{
		  _LOGGER.info(getStoredProcedureName() + " action: " + bi.getAction());		
		  //set note and other new fields PVB Aug/2008
		  noteText = bi.getInquiryMemo(); //location if CREATE OR CANCEL
		  attachmentFlg = (bi.getAction().equals(NcasConstants.BI_ATTACHMENT_ACTION) ? "Y" : "N");	
		  emeaKey = (bi.getAction().equals(NcasConstants.BI_EMEAKEY_ACTION) ? bi.getEmeaKey() : null);
		  if (bi.getAction().equals(NcasConstants.BI_CLOSE_ACTION))
			  pubInd = VAC_PUBLIC;
		  else if (bi.getAction().equals(NcasConstants.BI_CANCEL_ACTION))
		  {

			  if (bi.getBICategory() != null && bi.getBICategory().equals(NcasConstants.IBICATEGORY))
			  {
			  //from EMEA CANCEL
			  if ((Long.toString(bi.getUserOid())).equals("999999"))
			  {
			  pubInd = VAC_PRIVATE;
			  }
			  else
			  {
				  //pull note text out of note object for cancel PORTAL
			   List cancelnoteList = bi.getBillInquiryNote();
			   if ( (cancelnoteList != null) && (!cancelnoteList.isEmpty()) )
			  {
				  BillInquiryNote cancelmyNote = (BillInquiryNote) cancelnoteList.get(0);
				  if (cancelmyNote != null)
				  {
					  noteText = cancelmyNote.getNoteText();
					  pubInd = (cancelmyNote.isPublicNote()? VAC_PUBLIC : VAC_PRIVATE);
			      }
			   }
			   else throw new Exception ("BI CANCEL NOTE BUT CANCEL NOTE is null: "+ bi);
			   _LOGGER.info(getStoredProcedureName() + " cancelnote: " + noteText);
			  _LOGGER.info(getStoredProcedureName() + " cancelpubFlg: " + pubInd);
			  }
		     }
			  else
			  {
			  	  pubInd = VAC_PRIVATE;
		      }
	       }
		  _LOGGER.info(getStoredProcedureName() + " noteText: " + noteText);
		  _LOGGER.info(getStoredProcedureName() + " attachflg: " + attachmentFlg);
		  _LOGGER.info(getStoredProcedureName() + " emeakey: " + emeaKey);
		  _LOGGER.info(getStoredProcedureName() + " pubInd: " + pubInd);		  
		  if (bi.getAction().equals(NcasConstants.BI_NOTE_ACTION))
		  {
			  //pull note text out of note object
			  List noteList = bi.getBillInquiryNote();
			  if ( (noteList != null) && (!noteList.isEmpty()) )
			  {
				  BillInquiryNote myNote = (BillInquiryNote) noteList.get(0);
				  if (myNote != null)
				  {
					  noteText = myNote.getNoteText();
					  pubInd = (myNote.isPublicNote()? VAC_PUBLIC : VAC_PRIVATE);					  
				  }
				  else throw new Exception ("BI ADD NOTE BUT NOTE is null: "+ bi);
			  }	  
			  _LOGGER.info(getStoredProcedureName() + " note: " + noteText);
			  _LOGGER.info(getStoredProcedureName() + " pubFlg: " + pubInd);  
		  }
				
		  paramValueList = new ArrayList();
		  paramValueList.add(bi.getAction()); 
		  paramValueList.add(bi.getSrcSysBIID());
		  paramValueList.add(bi.getBICategory());
		  paramValueList.add(bi.getOrigLogin());
		  paramValueList.add(noteText);	//"note text in diff place for create/cancel vs add note
		  paramValueList.add(bi.getSourcePortal());	//"VBC_OR_VBCC"
		  paramValueList.add(Double.valueOf(Long.toString(bi.getUserOid()))); //"USER_OID"
		  //added Aug/2008 IBI
		  paramValueList.add(attachmentFlg);//"attachment flg"
		  paramValueList.add(emeaKey);//"EMEA key"
		  paramValueList.add(pubInd);//"Pub/pri indicator"
		  
		}
		Map resMap = executeSP(paramValueList, false);		
		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
	}

}
