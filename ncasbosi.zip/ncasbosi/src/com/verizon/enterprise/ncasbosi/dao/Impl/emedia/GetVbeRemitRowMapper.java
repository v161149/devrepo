package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.gbr.VbeRemitPoint;

public class GetVbeRemitRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger
			.getLogger(GetGBROrgsRowMapperImpl.class);

	public Object mapRow(ResultSet rs,  int rowNum) throws SQLException {
		_LOGGER.info("Inside GetVbeRemitRowMapper -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		VbeRemitPoint remitPoint = null;

		if(rs!=null)
		{
			remitPoint = new VbeRemitPoint();
			remitPoint.setConfigSubsOid (trim(rs.getString("CONFIG_SUBS_OID")));
			remitPoint.setRemitOid (trim(rs.getString("REMIT_OID")));
			remitPoint.setConfigId (trim(rs.getString("CONFIG_ID")));
			remitPoint.setRemitId (trim(rs.getString("REMIT_ID")));
			remitPoint.setServiceType (trim(rs.getString("SERVICE_TYPE")));
			remitPoint.setRemitStart (trim(rs.getString("REMIT_START")));
			remitPoint.setRemitEnd (trim(rs.getString("REMIT_END")));
			remitPoint.setDefaultRemit (trim(rs.getString("DEFAULT_REMIT")));
			remitPoint.setRemitAccounts (rs.getInt("REMIT_ACCTS"));
			remitPoint.setDefaultAccounts (rs.getInt("DEFLT_ACCTS"));
			remitPoint.setUseVbeName (trim(rs.getString("USE_VBE_NAME")));
			remitPoint.setRemitName (trim(rs.getString("CONFIG_NAME")));
			remitPoint.setUseVbeAddress (trim(rs.getString("USE_VBE_ADDRESS")));
			remitPoint.setCustAddrType (trim(rs.getString("CUST_ADDR_TYPE")));
			remitPoint.setCustAddr1 (trim(rs.getString("CUST_ADDR_1")));
			remitPoint.setCustAddr2 (trim(rs.getString("CUST_ADDR_2")));
			remitPoint.setCustAddr3 (trim(rs.getString("CUST_ADDR_3")));
			remitPoint.setCustCity (trim(rs.getString("CUST_CITY")));
			remitPoint.setCustState (trim(rs.getString("CUST_STATE")));
			remitPoint.setCustZip (trim(rs.getString("CUST_ZIP")));
			remitPoint.setCustCountry (trim(rs.getString("CUST_COUNTRY")));
			remitPoint.setPostalCode (trim(rs.getString("POSTAL_CODE")));
			remitPoint.setExtUpdtUserName (trim(rs.getString("EXT_UPDT_USR_NAME")));
			remitPoint.setExtUpdtUserId (trim(rs.getString("EXT_UPDT_USR_ID")));
			remitPoint.setUpdateTimestamp (trim(rs.getString("UPDATE_TIMESTAMP")));
			remitPoint.setProfileComplete (trim(rs.getString("PROFILE_COMPLETE")));
			remitPoint.setProfileComment (trim(rs.getString("PROFILE_COMMENT")));
			remitPoint.setSubscriberOid (trim(rs.getString("SUBSCRIBER_OID")));
			remitPoint.setSubscriberName (trim(rs.getString("SUBSCRIBER_NAME")));
			remitPoint.setBic (trim(rs.getString("BIC")));
			remitPoint.setGuduns (trim(rs.getString("GUDUNS")));
			remitPoint.setLanguage_code (trim(rs.getString("LANGUAGE_CODE")));
			remitPoint.setCurrency_code (trim(rs.getString("CURRENCY_CODE")));
			remitPoint.setPaperStatus (trim(rs.getString("PAPER_STATUS")));
			remitPoint.setNaspId (trim(rs.getString("NASP")));
			remitPoint.setNaspName (trim(rs.getString("NASP_NAME")));
			remitPoint.setRevLoc (trim(rs.getString("REVLOC_ID")));
			remitPoint.setPaymentDueInterval(trim(rs.getString("PAYMENT_DUE_INT")));
		}

		return remitPoint;
	}
	
	private String trim (String in)
	{
		if (in == null) return null;
		return in.trim();
	}
	
}
