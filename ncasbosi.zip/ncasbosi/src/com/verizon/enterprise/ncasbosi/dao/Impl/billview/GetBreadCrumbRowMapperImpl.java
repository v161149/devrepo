package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.ncas.display.CellBase;
import com.verizon.enterprise.common.ncas.display.Link;
import com.verizon.enterprise.common.ncas.display.Navigation;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.PortalLinkDBConfig;

public class GetBreadCrumbRowMapperImpl  implements ResultSetExtractor {
	static private final Logger _LOGGER = Logger.getLogger(GetBreadCrumbRowMapperImpl.class);
	public Object extractData(ResultSet rs) throws SQLException {
        if (_LOGGER.isDebugEnabled()) {
        	_LOGGER.debug("Inside GetBreadCrumbRowMapperImpl -> ");
        }		
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Navigation navigation = new Navigation();
		ArrayList rows = new ArrayList();
		navigation.setCells(rows);
		CellBase cell = null;
		Link link = null;
	
		while(rs.next()) {
			String name = rs.getString("NAME");
			String miscString = rs.getString("MISC_STRING");
			String type = rs.getString("TYPE");
			String lType =  rs.getString("L_TYPE");	
			String pageID = Integer.toString(rs.getInt("TARGET_PAGE_ID"));
			String linkParam = rs.getString("TARGET_PARMS");
			String pageSubset = rs.getString("TARGET_SUBSET");
			String format = rs.getString("FMT");
			
			cell = new CellBase();
			//ltype that starts with NOLNK is used so we can add it's value NOLINK_XXXX
			//to the link table to be used for exclusion/permission
			//normally the omission of a ltype is enough not to have a link
			if (lType !=null && lType.trim().length() > 0 && !lType.startsWith("NOLNK")){
			  link = new Link();
			  link.setPageId(pageID.trim());
			  link.setPageSubset(pageSubset.trim());
			  link.setLinkParam(PortalLinkDBConfig.getInstance().getExternalLink(lType.trim(), linkParam.trim()));
			  cell.setLink(link);			  
			}
			cell.setName(CommonUtil.getFormattedDisplayValue(type.trim(), format.trim(),name.trim(), "", false));
			cell.setToolTip(miscString.trim());
			cell.setType(type.trim());
			cell.setLnkType(lType.trim());			
			cell.setFormat(format.trim());
			rows.add(cell);
		}
		return navigation;
	}
}