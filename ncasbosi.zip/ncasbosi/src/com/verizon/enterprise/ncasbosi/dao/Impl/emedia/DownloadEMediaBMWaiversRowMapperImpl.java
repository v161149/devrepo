package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.common.eMedia.EMediaWaiverRecord;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class DownloadEMediaBMWaiversRowMapperImpl implements ResultSetExtractor {

	static private final Logger _LOGGER = Logger.getLogger(DownloadEMediaBMWaiversRowMapperImpl.class);

	//public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	public Object extractData(ResultSet rs) throws SQLException {
		_LOGGER.info("Inside DownloadEMediaBMWaiversRowMapperImpl -> ");
		CommonUtil.printMetaDataInfo(rs.getMetaData());

		Map returnMap = new HashMap();
		//sEMediaWaiverRecord waiverRecord = null;
		List refList = new ArrayList();
		List bmWaiver = new ArrayList();
		
		Date todayDate = new Date();
		
		try{
			while(rs.next()) {
				
				//waiverRecord = new EMediaWaiverRecord();
				//int lineNum = rs.getInt("LINE_NUM");
				bmWaiver = new ArrayList();
				String createUserName = rs.getString("CREATE_USR_NAME");
				String createUserId = rs.getString("CREATE_USR_ID");
				String dateCreated =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("DATE_CREATED"));
				String startDateStr =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("START_DATE"));
				String endDateStr =  CommonUtil.getDisplayVAMDateFromString(rs.getDate("END_DATE"));
				
				_LOGGER.debug("endDateStr1" + endDateStr );
				
				if ("12-31-9999".equalsIgnoreCase(endDateStr)){
					endDateStr = "";
				}
				_LOGGER.debug("endDateStr2" + endDateStr );


				String cdorCustomerName = rs.getString("CDOR_CUSTOMER_NAME");				
				String masterContractId = rs.getString("MASTER_CONTRACT_ID");				
				String bcasignDate = CommonUtil.getDisplayVAMDateFromString(rs.getDate("BCASIGN_DATE"));
				String extUpdUsetName = rs.getString("EXT_UPDT_USR_NAME");
				String extUpdUsetId = rs.getString("EXT_UPDT_USR_ID");
				String updateTimeStamp = CommonUtil.getDisplayVAMDateFromString(rs.getTimestamp("UPDATE_TIMESTAMP"));

				Date startDate  = rs.getDate("START_DATE");
				Date endDate  = rs.getDate("END_DATE");
				String status = "";
				
				if (endDate == null )
				{
					if (todayDate.equals(startDate) || (todayDate.after(startDate)))
					{
						status = "Active";
					}
					else
						status = "Inactive";
				}
				else
				{
					if( todayDate.equals(startDate) || todayDate.after(startDate) )
					{
						if (todayDate.before(endDate) || todayDate.equals(endDate) )
						{
							status = "Active";
						}
						else
							status = "Inactive";
					}
					else
						status = "Inactive";
				}


				if(CommonUtil.isNotNull(createUserName)) {  bmWaiver.add(new Cell(createUserName.trim())); }
				if(CommonUtil.isNotNull(createUserId)) {  bmWaiver.add(new Cell(createUserId.trim()));}
				if(CommonUtil.isNotNull(dateCreated)) { bmWaiver.add(new Cell(dateCreated.trim())); }
				if(CommonUtil.isNotNull(startDateStr)) {  bmWaiver.add(new Cell(startDateStr.trim())); }
				if(CommonUtil.isNotNull(endDateStr)) {  bmWaiver.add(new Cell(endDateStr.trim()));}
				if(CommonUtil.isNotNull(cdorCustomerName)) {  bmWaiver.add(new Cell(cdorCustomerName.trim())); }
				if(CommonUtil.isNotNull(masterContractId)) {  bmWaiver.add(new Cell(masterContractId.trim())); }
				if(CommonUtil.isNotNull(bcasignDate)) { bmWaiver.add(new Cell(bcasignDate.trim())); }
				if(CommonUtil.isNotNull(extUpdUsetName)) { bmWaiver.add(new Cell(extUpdUsetName.trim())); }
				if(CommonUtil.isNotNull(extUpdUsetId)) { bmWaiver.add(new Cell(extUpdUsetId.trim())); }
				if(CommonUtil.isNotNull(updateTimeStamp)) { bmWaiver.add(new Cell(updateTimeStamp.trim())); }
				if(CommonUtil.isNotNull(status)) {  bmWaiver.add(new Cell(status.trim()));}
				
				
				_LOGGER.debug("waiverRecord" + bmWaiver.toString() );

				refList.add(bmWaiver);
				//returnMap.put("waiverList",refList);
					
			}
			//returnMap.put("waiverList",refList);
			
		}  catch(NumberFormatException nfe) {
			nfe.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+nfe.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+nfe.getMessage());
			//throw new NCASException("Exception occured while parsing the resultset \n"+pe.toString(),GetProfileRowMapperImpl.class,pe);
		} catch(Exception e) {
			e.printStackTrace();
			_LOGGER.debug("Exception occured while parsing the resultset \n"+e.getMessage());
			_LOGGER.error("Exception occured while parsing the resultset \n"+e.getMessage());
		}
		if(_LOGGER.isEnabledFor(Level.DEBUG)) {
			_LOGGER.debug("SearchEMediaProfile's Waiver  " + bmWaiver);
		}
		return refList;
	}
}
