package com.verizon.enterprise.ncasbosi.dao.Impl.billmanager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.verizon.enterprise.common.ncas.billmanager.BillManager;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.display.Pagination;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

public class SPGetEMedia extends BaseStoredProcedure
{
	static private final Logger _LOGGER = Logger.getLogger(SPGetEMedia.class);
	private static List spInOutList;
	public SPGetEMedia(DataSource dataSource,String schemaName)
	{
		super(dataSource, schemaName + "." +NCASBOSIConstants.SP_GET_EMEDIA_LIST,spInOutList);
	}
	static{
		 _LOGGER.info("Static Init");
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"RESULT_SET_ONE", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,  new GetEMediaMapper()});
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_CONFIG_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONFIG_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MEDIA_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOKEN_ST", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"START_POS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NUM_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TOTAL_ROWS", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public Map executeStoredProcedure(Object input)throws Exception
	{ 
		
		 
		_LOGGER.info("Entering Execute SP in " + getStoredProcedureName());
		BillManager billmanager=(BillManager)input;
		
		Pagination myPag = null; 
		List paramValueList = new ArrayList();
		
		if((billmanager !=null) && (billmanager instanceof BillManager )) {
			myPag=billmanager.getMyPag();
		}else{
			throw new Exception("SPGetEMedia: bad input expect BMCUSTIDSearchForm got:" + billmanager);
		}
		if (myPag == null){
			throw new Exception("SPGetEMedia: Bill manager pagination is null");
		}
		String man=billmanager.getManServiceID();
		String custconfigid=billmanager.getCustidBM3();
		String configname=billmanager.getConfigName();
		String mediatype=billmanager.getMediaOption();
		paramValueList.add("");  //APP_USER_ID
		paramValueList.add("1");  //DEBUG_LEVEL
		paramValueList.add(man);  //MAN
		paramValueList.add(custconfigid);  //CUST_CONFIG_ID
		paramValueList.add(configname);  //CONFIG_NAME
		paramValueList.add(mediatype);  //MEDIA_TYPE
		paramValueList.add(""); //TOKEN_ST
		paramValueList.add(new Integer(myPag.getLineOffset())); // START_POS
		paramValueList.add(new Integer(myPag.getPageSize())); // NUM_ROWS
		/***** call the SP *************/
		Map resMap = executeSP(paramValueList, false);
		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;
		
	}
//	get value from variable, if empty string set to null.
	private String getV (String input)
	{
		if (input != null && !"".equals(input))
		{
			return input;
		}
		else
		{
			return "";
		}
	}
}
