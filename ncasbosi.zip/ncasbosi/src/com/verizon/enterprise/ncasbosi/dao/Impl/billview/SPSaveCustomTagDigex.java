package com.verizon.enterprise.ncasbosi.dao.Impl.billview;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import javax.sql.DataSource;

import com.verizon.enterprise.common.ncas.exception.NCASException;

import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;


public class SPSaveCustomTagDigex extends BaseStoredProcedure {
	
	static private final Logger _LOGGER = Logger.getLogger(SPSaveCustomTagDigex.class);
	private static List spInOutList;
	
	static
	{
		 spInOutList = new ArrayList();
		 
		 spInOutList.add(new Object[]{"LINK_PARAMS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USERID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MSG_STRING", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	}
	
	public SPSaveCustomTagDigex(DataSource dataSource, String schemaName) {
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_SAVE_CUSTOM_TAG_DIGEX, spInOutList);
	}

	public Map executeStoredProcedure(String userId, String debugLevel, Map params) throws Exception {
		String schemaName = BOSIConfig.getProperty(NCASBOSIConstants.VAM_SCHEMA_NAME, " ");
		List paramValueList = new ArrayList();
		Map procMap = null;
		paramValueList.add((String)params.get("LINK_PARAMS"));//LINK_PARAMS
		String tagValue = (String)params.get("TAG");
		if (tagValue != null) {
			tagValue = tagValue.trim();
			if (tagValue.length() > 50) {
				tagValue = tagValue.substring(0, 50);
			}
		}
		
		paramValueList.add(tagValue);//TAG - MAX 50 CHARS
		paramValueList.add((String)params.get("USERID"));//USERID
		paramValueList.add(debugLevel);//DEBUG_FLAG
		procMap = (HashMap)executeStoredProcedure(paramValueList);
		int returnCode = ((Integer)procMap.get("RETURN_CODE")).intValue();
		String debugStr = (String)procMap.get("MSG_STRING");
		if( returnCode > 0 ) {
		    String[] errMsg = new String[3];
		    errMsg[0] = "saveCustomTageDigex";
		    errMsg[1] = schemaName + "." + NCASBOSIConstants.SP_SAVE_CUSTOM_TAG_DIGEX;
		    errMsg[2] = debugStr;

		    throw new NCASException(NCASBOSIConstants.ERROR_VAM,errMsg,returnCode);
		}
		return procMap;
	}
	
	public Map executeStoredProcedure(Object paramValues)throws Exception {
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
