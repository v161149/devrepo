package com.verizon.enterprise.ncasbosi.dao.Impl.historicalinvoices;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.historicalinvoice.HiSelectDO;import com.verizon.enterprise.common.util.DateUtility;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetClientViewDetailListMapper implements RowMapper{

	private static final Logger _LOGGER = Logger.getLogger(GetClientViewDetailListMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		_LOGGER.debug("GetClientViewDetailListMapper - Mapping Row# "+rowNum);				String formatDb2 = "yyyy-MM-dd";		String formatDisplayed = "MM/dd/yyyy";
		HiSelectDO hiDO = null;
		if(rs!=null){
			hiDO = new HiSelectDO();
			hiDO.setMan(val(rs.getString("MAN")));			hiDO.setBan(val(rs.getString("BAN")));			hiDO.setOsid(val(rs.getString("ORIG_SYS")));			hiDO.setDocType(val(rs.getString("DOCUMENT_TYPE")));			hiDO.setAban(val(rs.getString("ABAN")));			hiDO.setBillDate(val(rs.getString("BILL_DATE")));			hiDO.setLocation(val(rs.getString("LOCATION")));			hiDO.setTotalPages(val(rs.getInt("NUMBER_OF_PAGES") + ""));			hiDO.setRemitInd(val(rs.getString("REMIT_IND")));			hiDO.setZipFileNumber(val(rs.getString("DOCUMENT_NUMBER")));  //for zip file in gas			hiDO.setZipFileStatus(val(rs.getString("DOCUMENT_STATUS")));  //for zip file in gas			hiDO.setZipFileName(val(rs.getString("FILE_NAME")));			////needed for osid MU where use this api to get detail but then call fvz api (VGWD500) to view the pdf.			hiDO.setSections(val(rs.getInt("SECTIONS") + ""));  			hiDO.setStartSection("0");			hiDO.setZipFileSystem(val(rs.getString("DOCUMENT_SYSTEM_ID")));			hiDO.setAcctLevel(rs.getString("MASTER"));  //Master or Standalone			hiDO.setFileType(rs.getString("FORMAT"));  // afp or pdf									hiDO.setInvNbr(showSpacesIfZeros(hiDO.getAban()));			hiDO.setInvDate(CommonUtil.formatDate(hiDO.getBillDate(), formatDb2, formatDisplayed));		}
		return hiDO;
	}		private String val(String input)	{		if (input == null)			return "";				return input.trim();	}		private String showSpacesIfZeros(String input)	{		if (input == null)			return "";				for (int i = 0; i < input.length(); i ++)		{			if (input.charAt(i) != ' ' && input.charAt(i) != '0')			{				return input;			}		}				return "";	}
}
