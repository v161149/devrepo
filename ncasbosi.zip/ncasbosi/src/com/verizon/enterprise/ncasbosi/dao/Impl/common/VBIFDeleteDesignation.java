package com.verizon.enterprise.ncasbosi.dao.Impl.common;

import javax.sql.DataSource;
import java.sql.*;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

import com.verizon.enterprise.common.ncas.approval.Designation;

public class VBIFDeleteDesignation extends SqlUpdate{
	private final Logger _LOGGER = Logger.getLogger(this.getClass());
	
	public VBIFDeleteDesignation(DataSource dataSource,String sql) {
		super(dataSource, sql);		
		declareParametersForDeletingDesignee();//this is for type safety
		compile();		
	}
	
	private void declareParametersForDeletingDesignee(){
		declareParameter(new SqlParameter("DESIGNATOR_VZID",Types.VARCHAR));
		declareParameter(new SqlParameter("APPROVER_VZID",Types.VARCHAR));
		declareParameter(new SqlParameter("START_DATE",Types.DATE));
		declareParameter(new SqlParameter("END_DATE",Types.DATE));
	}
	
	public int deleteDesignation(Designation designationInfo) throws Exception{	
		String METHOD_NAME="VBIFDeleteDesignation->deleteDesignation::";
		_LOGGER.info(METHOD_NAME+this.getSql());
		
		Object[] params = new Object[]{designationInfo.getUserDelegation().getDesignatorVZID(),designationInfo.getUserDelegation().getApproverVZID(), designationInfo.getUserDelegation().getStartDate(), designationInfo.getUserDelegation().getEndDate()};
		return this.update(params);
	}
}