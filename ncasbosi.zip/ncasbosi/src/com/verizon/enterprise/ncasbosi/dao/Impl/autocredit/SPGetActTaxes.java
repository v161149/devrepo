package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import java.sql.Types;
import org.apache.log4j.Logger;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import com.verizon.enterprise.common.ncas.autocredit.VamDO;
import com.verizon.enterprise.common.ncas.display.Pagination;

public class SPGetActTaxes extends BaseStoredProcedure
{
    private static final Logger _LOGGER = Logger.getLogger(SPGetActTaxes.class);

    private static ArrayList spInOutList = new ArrayList();
    static
    {
        spInOutList.add(new Object[]{"RESULTSET", getSqlDataType(NCASBOSIConstants.DATA_TYPE_RESULTSET),NCASBOSIConstants.SP_PARAMETER_TYPE_RESULTSET,new GetActTaxesMapper()});
        
        spInOutList.add(new Object[] { "APP_USER_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "DEBUG_LEVEL",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });

        spInOutList.add(new Object[] { "RETURN_CODE",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "REASON_CODE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "ERROR_TEXT",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "SP_SQLCODE",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "SP_SQLTOKENS",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        spInOutList.add(new Object[] { "SP_SQLSTATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
        
        spInOutList.add(new Object[] { "MAN", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "BAN",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "OSID",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "FROM_DATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "THRU_DATE",getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "SORT_ORDER",getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "LINE_OFFSET",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "PAGE_SIZE",getSqlDataType(Types.SMALLINT),NCASBOSIConstants.SP_PARAMETER_TYPE_IN });
        spInOutList.add(new Object[] { "ROW_COUNT",getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT });
               
    }

    public SPGetActTaxes(DataSource dataSource)
    {
        super(dataSource, NCASBOSIConstants.SP_GET_ACT_TAXES,spInOutList);
    }

    public Map executeStoredProcedure(Object input) throws Exception
    {
        _LOGGER.info("Entering executeStoredProcedure");
        Map inputMap = (Map) input;
        List paramValueList = new ArrayList();
        VamDO vamdo = null;
        Pagination pag = null;
        if(inputMap!=null){
             vamdo = (VamDO)inputMap.get("vamDO");
             pag = (Pagination)inputMap.get("pagination");
        }
        
        if (vamdo == null){
            throw new Exception("SPGetActTaxes: input data object is null");
        }
        if (pag == null){
            throw new Exception("SPGetActTaxes: Pagination obj is null");
        }
        
        String formatIn = "MM/dd/yyyy";
        String formatOut = "yyyy-MM-dd";
        //convert date user entered into date db2 can use.
        String fromDate = CommonUtil.formatDate(vamdo.getFromDate(), formatIn, formatOut);
        String thruDate = CommonUtil.formatDate(vamdo.getThruDate(), formatIn, formatOut);
        
        paramValueList.add((String)inputMap.get("APP_USER_ID"));//APP_USER_ID
        paramValueList.add((String)inputMap.get("DEBUG_LEVEL"));//DEBUG_LEVEL
        paramValueList.add(vamdo.getMan()); //MAN
        paramValueList.add(vamdo.getBan()); //BAN
        paramValueList.add(vamdo.getOsid()); //OSID
        paramValueList.add(fromDate); //FROM_DATE
        paramValueList.add(thruDate); //THRU_DATE
        paramValueList.add(pag.getVamSortOrder()); //SORT_ORDER
        paramValueList.add(new Integer(pag.getLineOffset())); //LINE_OFFSET
        paramValueList.add(new Integer(pag.getPageSize())); //PAGE_SIZE
        
        // * *** call the SP ************
        Map resMap = executeSP(paramValueList, false);
        _LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
        checkVACErrors(resMap);
        _LOGGER.info("Exiting ExecuteStoredProcedure in "+ getStoredProcedureName());
        return resMap;
    }
}
