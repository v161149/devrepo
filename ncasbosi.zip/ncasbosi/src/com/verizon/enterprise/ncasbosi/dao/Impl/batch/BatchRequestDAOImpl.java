package com.verizon.enterprise.ncasbosi.dao.Impl.batch;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.apache.log4j.Logger;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import com.verizon.enterprise.ncasbosi.common.BOSIConfig;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncasbosi.beans.Request;
import com.verizon.enterprise.ncasbosi.dao.Interface.batch.BatchRequestInterface;
import javax.sql.DataSource;


public class BatchRequestDAOImpl extends JdbcDaoSupport implements BatchRequestInterface, NCASBOSIConstants {

private static final Logger _LOGGER = Logger.getLogger(BatchRequestDAOImpl.class);

private static final String SCHEMA_NAME = "verizon.ebosi.bill.vam.schema";

private SelectAllRequest selectAllReq;
private SelectByTypeRequest selectbyTypeReq;
private SelectByNumRequest selectbyNumReq;
private SelectByStatusRequest selectbyStatusReq;
private SelectByStatusTypeRequest selectbyStatusTypeReq;
private DeleteRequest deleteReq;
private UpdateRequest updateReq;
private InsertRequest insertReq;
private LockBatchControl lockBatchControl;
private UnlockBatchControl unlockBatchControl;
private String SELECT_REQUEST_ID = "SELECT DISTINCT REQUEST_ID FROM "+getSchemaName()+".PL_REQSTATUS";
private String SELECT_ALL_REQUEST = "SELECT REQUEST_ID,TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,PARAM6,PARAM7,STATUS,ITERATION,ERROR_MSG,PORTAL,EMPLOYEE_FLAG,LOGINID,LAST_UPDATED,LAST_UPDATED_BY,EMAIL_TEXT FROM "+getSchemaName()+".PL_REQSTATUS";
private String SELECT_BYTYPE = SELECT_ALL_REQUEST + " WHERE TYPE=?";
private String SELECT_BYSTATUS = SELECT_ALL_REQUEST + " WHERE STATUS=?";
private String SELECT_BY_STATUS_AND_TYPE = SELECT_ALL_REQUEST + " WHERE STATUS=? AND TYPE=? ORDER BY LAST_UPDATED";
private String SELECT_BYNUM = SELECT_ALL_REQUEST + " WHERE REQUEST_ID=?";
private String DELETE_REQUEST = "DELETE FROM " + getSchemaName() +".PL_REQSTATUS WHERE REQUEST_ID=?";
private String UPDATE_REQUEST = "UPDATE " + getSchemaName() +".PL_REQSTATUS "+ " SET TYPE=?,PARAM1=?,PARAM2=?,PARAM3=?,PARAM4=?,PARAM5=?,PARAM6=?,PARAM7=?,STATUS=?,ITERATION=?,ERROR_MSG=?,PORTAL=?,EMPLOYEE_FLAG=?,LOGINID=?,LAST_UPDATED_BY=?,LAST_UPDATED=?,EMAIL_TEXT=?  WHERE REQUEST_ID=?";
private String INSERT_REQUEST = "INSERT into "+ getSchemaName() +".PL_REQSTATUS "+ "(TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,PARAM6,PARAM7,STATUS,ITERATION,ERROR_MSG,PORTAL,EMPLOYEE_FLAG,LOGINID,LAST_UPDATED_BY,LAST_UPDATED,CREATED_TIMESTAMP,EMAIL_TEXT)" + " VALUES (?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
private String LOCK_BATCH_CONTROL = "UPDATE "+getSchemaName()+".PL_BATCH_CTL SET LOCK='"+NcasConstants.BATCH_RUNNING_LOCK_YES+"', LAST_RUN=? WHERE BATCH_NAME=? AND LOCK='"+NcasConstants.BATCH_RUNNING_LOCK_NO+"'";
private String UNLOCK_BATCH_CONTROL = "UPDATE "+getSchemaName()+".PL_BATCH_CTL SET LOCK='"+NcasConstants.BATCH_RUNNING_LOCK_NO+"' WHERE BATCH_NAME=?";
private String SELECT_BATCH_CONTROL = "SELECT LAST_RUN FROM "+getSchemaName()+".PL_BATCH_CTL WHERE BATCH_NAME=? AND LOCK='"+NcasConstants.BATCH_RUNNING_LOCK_YES+"'";
private String UPDATE_LAST_RUN_BATCH_CONTROL = "UPDATE "+getSchemaName()+".PL_BATCH_CTL SET LOCK='"+NcasConstants.BATCH_RUNNING_LOCK_YES+"', LAST_RUN=? WHERE BATCH_NAME=?"+" AND (SELECT (TIMESTAMPDIFF(4,CHAR(CURRENT_TIMESTAMP -(SELECT LAST_RUN LAST_UPD FROM "+ NCASBOSIConstants.VAM_SCHEMA +".PL_BATCH_CTL WHERE BATCH_NAME = ?))))/60.0 AS HOURS_DIFF FROM SYSIBM.SYSDUMMY1)>1"; 
private SelectRequestId selectRequestId = null;


public List doBatchReq(String operation,int requestNum,Request reqObj, String type)  throws RemoteException,NCASException
{
		  List returnList=null;
		  try{
			  if(reqObj!=null)
		      _LOGGER.info("doBatchReq in NCASBOSI - Request:" +requestNum+" **DETAILS::"+reqObj.toString());

		  if(operation.equalsIgnoreCase(NcasConstants.BATCH_INSERT_REQ))
			  returnList = insertRequest(reqObj);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_UPDATE_REQ))
			  updateRequest(requestNum,reqObj);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_DELETE_REQ))
			  deleteRequest(requestNum);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_GET_REQ_ID))
			  returnList = selectRequestId();
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_GET_NUM_REQ))
			  returnList = selectByNumRequest(requestNum);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_GET_TYPE_REQ))
			  returnList = selectByTypeRequest(type);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_GET_STATUS_REQ))
			  returnList = selectByStatusRequest(type);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_GET_W_STATUS))
			  returnList = selectByStatusRequest(NcasConstants.BATCH_REQ_WORKING);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_UPDATE_STATUS_REQ))
			  updateStatus(reqObj);
		  else if(operation.equalsIgnoreCase(NcasConstants.BATCH_GET_W_STATUS_AND_TYPE)){
			  String status = NcasConstants.BATCH_REQ_WORKING;//default
			  if(reqObj.getStatus()!= null && reqObj.getStatus().trim().length() > 0){
				  status = reqObj.getStatus().trim();
			  }
			  returnList = selectByStatusTypeRequest(status, reqObj.getType());
		  }else returnList = selectALL_Request();
	  	}catch(Exception e){
		  e.printStackTrace();
	      _LOGGER.debug("doBatchReq in NCASBOSI Failed \n" +e.getMessage());
	      _LOGGER.error("doBatchReq in NCASBOSI Failed \n" +e.getMessage());
	      throw new NCASException(NCASBOSIConstants.MEMO_BILL_EXCEPTION_950, BatchRequestDAOImpl.class, e);
		}

		  return returnList;
}

protected void initDao() throws Exception{
	super.initDao();
	selectAllReq = new SelectAllRequest(getDataSource()) ;
	selectbyTypeReq = new SelectByTypeRequest(getDataSource());
	selectbyStatusReq = new SelectByStatusRequest(getDataSource());
	selectbyNumReq = new SelectByNumRequest(getDataSource()) ;
	deleteReq = new DeleteRequest(getDataSource()) ;
	updateReq = new UpdateRequest(getDataSource()) ;
	insertReq = new InsertRequest(getDataSource()) ;
	selectbyStatusTypeReq = new SelectByStatusTypeRequest(getDataSource());
}

abstract class AbstractSelect extends MappingSqlQuery{

	public AbstractSelect(DataSource dataSource,String sql){
		super(dataSource,sql);
	}

}

class DeleteRequest extends BatchSqlUpdate{
	public DeleteRequest(DataSource dataSource){
		super(dataSource,DELETE_REQUEST);
		declareParameter(new SqlParameter(Types.INTEGER));
	}
}

class UpdateRequest extends BatchSqlUpdate{
	public UpdateRequest(DataSource dataSource){
		super(dataSource,UPDATE_REQUEST);
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.CHAR));
		declareParameter(new SqlParameter(Types.INTEGER));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.CHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.TIMESTAMP));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.INTEGER));
	}
}

class InsertRequest extends BatchSqlUpdate{
	public InsertRequest(DataSource dataSource){
		super(dataSource,INSERT_REQUEST);
		setReturnGeneratedKeys(true);//this is to make sure PreparedStatement(which is abstracted & executed behind the scenes)handle the Auto-gen Key
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.CHAR));
		declareParameter(new SqlParameter(Types.INTEGER));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.CHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.TIMESTAMP));
		declareParameter(new SqlParameter(Types.TIMESTAMP));
		declareParameter(new SqlParameter(Types.VARCHAR));
	}
}
class SelectAllRequest extends AbstractSelect{
		public SelectAllRequest(DataSource dataSource){
			super(dataSource,SELECT_ALL_REQUEST);
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		      return createRequest(rs);
		}
}

class SelectByTypeRequest extends AbstractSelect{
		public SelectByTypeRequest(DataSource dataSource){
			super(dataSource,SELECT_BYTYPE);
			declareParameter(new SqlParameter(Types.VARCHAR));
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		      return createRequest(rs);
		}
}
class SelectByStatusRequest extends AbstractSelect{
		public SelectByStatusRequest(DataSource dataSource){
			super(dataSource,SELECT_BYSTATUS);
			declareParameter(new SqlParameter(Types.CHAR));
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		      return createRequest(rs);
		}
}
class SelectByStatusTypeRequest extends AbstractSelect{
	public SelectByStatusTypeRequest(DataSource dataSource){
		super(dataSource,SELECT_BY_STATUS_AND_TYPE);
		declareParameter(new SqlParameter(Types.CHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
	}
	protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
	      return createRequest(rs);
	}
}
class SelectByNumRequest extends AbstractSelect{
		public SelectByNumRequest(DataSource dataSource){
			super(dataSource,SELECT_BYNUM);
			declareParameter(new SqlParameter(Types.INTEGER));
		}
		protected Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		      return createRequest(rs);
		}
}

private List selectByNumRequest(int requestNum) throws Exception{
		 _LOGGER.info("Select SQL: " + SELECT_BYNUM);
		 return selectbyNumReq.execute(new Object[]{new Integer(requestNum)});
}


private List selectByTypeRequest(String type) throws Exception{
	 _LOGGER.info("Select SQL: " + SELECT_BYTYPE);
	 return selectbyTypeReq.execute(new Object[]{new String(type)});
}

private List selectByStatusRequest(String status) throws Exception {
	 _LOGGER.info("Select SQL: " + SELECT_BYSTATUS);
	 return selectbyStatusReq.execute(new Object[]{new String(status)});
}

private List selectByStatusTypeRequest(String status,String type) throws Exception {
	 _LOGGER.info("Select SQL: " + SELECT_BY_STATUS_AND_TYPE);
	 return selectbyStatusTypeReq.execute(new Object[]{new String(status),new String(type)});
}

private List selectALL_Request() throws Exception{
	 _LOGGER.info("Select SQL: " + SELECT_ALL_REQUEST);
	 selectAllReq = new SelectAllRequest(getDataSource()) ;
	 _LOGGER.info("Exiting selectALL_Request");
	 return selectAllReq.execute(new Object[]{});
}

private void deleteRequest(int requestNum)  throws Exception{
	 _LOGGER.info("delete SQL: " + DELETE_REQUEST);
	 deleteReq.update(new Object[]{new Integer(requestNum)});
	 deleteReq.flush();
}

private void updateRequest(int requestNum, Request reqObj) throws Exception{
	 _LOGGER.info("update SQL: " + UPDATE_REQUEST);
	 updateReq.update(createRequest(requestNum, reqObj));
	 updateReq.flush();
}

private List insertRequest(Request reqObj)  throws Exception{
	List list = new ArrayList();
	 _LOGGER.info("insert SQL: " + INSERT_REQUEST);
	 KeyHolder keyHolder = new GeneratedKeyHolder();

	 Object[] inputObjectArray = createRequest(reqObj);
	 insertReq.update(inputObjectArray,keyHolder);
	 insertReq.flush();
	 int reqId = keyHolder.getKey().intValue();
	 _LOGGER.info("The request id that got inserted is "+reqId);
	 list.add((Integer)reqId);
	 return list;
}

private Request createRequest(ResultSet rs)throws SQLException{
	 int reqID = rs.getInt("REQUEST_ID");

	 String type = rs.getString("TYPE");
	 String param1 = rs.getString("PARAM1");
	 String param2 = rs.getString("PARAM2");
	 String param3 = rs.getString("PARAM3");
	 String param4 = rs.getString("PARAM4");
	 String param5 = rs.getString("PARAM5");
	 String param6 = rs.getString("PARAM6");
	 String param7 = rs.getString("PARAM7");
	 String status = rs.getString("STATUS");
	 int iteration = rs.getInt("ITERATION");
	 String error = rs.getString("ERROR_MSG");
	 String portal = rs.getString("PORTAL");
	 String empflg = rs.getString("EMPLOYEE_FLAG");
	 String login = rs.getString("LOGINID");
	 String lastUpdated = rs.getString("LAST_UPDATED");
	 String updateby = rs.getString("LAST_UPDATED_BY");
	 String emailText = rs.getString("EMAIL_TEXT");
     Request req = new Request(reqID, type, param1, param2, param3, param4, param5, param6, param7, status, iteration, error, portal,empflg,login,lastUpdated,updateby);
     req.setEmailText(emailText);
     return req;
}



private Object[] createRequest(int requestNum, Request reqObj) throws Exception{
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
	Object[] objArray = new Object[18];
	objArray[0]=new String(reqObj.getType());
	objArray[1]=new String(reqObj.getParam1());
	objArray[2]=new String(reqObj.getParam2());
	objArray[3]=new String(reqObj.getParam3());
	objArray[4]=new String(reqObj.getParam4());
	objArray[5]=new String(reqObj.getParam5());
	objArray[6]=new String(reqObj.getParam6());
	objArray[7]=new String(reqObj.getParam7());
	objArray[8]=new String(reqObj.getStatus());
	objArray[9]=new Integer(reqObj.getIteration());
	objArray[10]=new String(reqObj.getErrormsg());
	objArray[11]=new String(reqObj.getPortal());
	objArray[12]=new String(reqObj.getEmployeeflag());
	objArray[13] =new String(reqObj.getLogin());
	objArray[14]=new String(reqObj.getLastUpdatedBy());
	objArray[15]=new String(simpleDateFormat.format(new Timestamp(System.currentTimeMillis())));
	objArray[16]=new String(reqObj.getEmailText());
	objArray[17]=new Integer(requestNum);
    return objArray;
}

private synchronized Object[] createRequest(Request reqObj) throws Exception{
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
	Object[] objArray = new Object[18];
	objArray[0]=new String(reqObj.getType());
	objArray[1]=new String(reqObj.getParam1());
	objArray[2]=new String(reqObj.getParam2());
	objArray[3]=new String(reqObj.getParam3());
	objArray[4]=new String(reqObj.getParam4());
	objArray[5]=new String(reqObj.getParam5());
	objArray[6]=new String(reqObj.getParam6());
	objArray[7]=new String(reqObj.getParam7());
	objArray[8]=new String(reqObj.getStatus());
	objArray[9]=new Integer(reqObj.getIteration());
	objArray[10]=new String(reqObj.getErrormsg());
	objArray[11]=new String(reqObj.getPortal());
	objArray[12]=new String(reqObj.getEmployeeflag());
	objArray[13] =new String(reqObj.getLogin());
	objArray[14]=new String(reqObj.getLastUpdatedBy());
	objArray[15]=new String(simpleDateFormat.format(new Timestamp(System.currentTimeMillis())));
	objArray[16]=new String(simpleDateFormat.format(new Timestamp(System.currentTimeMillis())));
	objArray[17]=new String(reqObj.getEmailText());
    return objArray;
}

class SelectRequestId extends AbstractSelect {
	public SelectRequestId(DataSource dataSource) {
		super(dataSource, SELECT_REQUEST_ID);
	}

	protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		int request_id = rs.getInt("REQUEST_ID");
		return new Integer(request_id);
	}
}

public List selectRequestId() throws Exception{
	List requestList = null;
	requestList = new ArrayList();
	selectRequestId = new SelectRequestId(getDataSource());
	requestList = selectRequestId.execute(new Object[] {});
	_LOGGER.info("Exiting SelectRequestId");
	return requestList;
}

class UnlockBatchControl extends SqlUpdate{
	public UnlockBatchControl(DataSource dataSource){
		super(dataSource,UNLOCK_BATCH_CONTROL);
		declareParameter(new SqlParameter(Types.VARCHAR));
	}
}
public int unlockBatchControl(String batchName) throws NCASException{
	 _LOGGER.info("update SQL: " + UNLOCK_BATCH_CONTROL);
	 int updatedRows = 0;
	 try{
		 unlockBatchControl = new UnlockBatchControl(getDataSource());
		 updatedRows = unlockBatchControl.update(batchName);
		}catch(Exception e) {
			_LOGGER.error("unlockBatchControl in NCASBOSI Failed \n" +e.getMessage());
			throw new NCASException(NCASBOSIConstants.PAYMENT_EXCEPTION_950, BatchRequestDAOImpl.class, e);
		}
	 return updatedRows;
}
class LockBatchControl extends SqlUpdate{
	public LockBatchControl(DataSource dataSource){
		super(dataSource,LOCK_BATCH_CONTROL);
		declareParameter(new SqlParameter(Types.TIMESTAMP));
		declareParameter(new SqlParameter(Types.VARCHAR));
	}
}
public int lockBatchControl(String batchName, boolean autoUnlockEnabled) throws NCASException{
	 _LOGGER.info("update SQL: " + LOCK_BATCH_CONTROL);
	 int updatedRows = 0;
	 try{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS");
			String lastUpdated = simpleDateFormat.format(new Timestamp(System.currentTimeMillis()));
			lockBatchControl = new LockBatchControl(getDataSource());
			updatedRows = lockBatchControl.update(lastUpdated,batchName);
			if (updatedRows == 0)
			{
				// Check LAST_RUN date, if older than 1 hr allow this process to run
				SelectBatchControl selectBatchControl = new SelectBatchControl(getDataSource());
				List selectRows = selectBatchControl.execute(batchName);
				
				if (selectRows.size() == 1)
				{
					Date lastRun = (Date) selectRows.get(0);
					String lastRunStr = simpleDateFormat.format(lastRun);
					Calendar currCalDate = Calendar.getInstance();
					currCalDate.add(Calendar.HOUR, -1);
					if (currCalDate.getTime().getTime() > lastRun.getTime() && autoUnlockEnabled)
					{
						_LOGGER.error("lockBatchControl[" + batchName + "] - LAST_RUN date[" + lastRunStr +"] is being reset");
						UpdateLastRunBatchControl updateLastRunBatchControl = new UpdateLastRunBatchControl(getDataSource());
						updatedRows = updateLastRunBatchControl.update(new Object[]{lastUpdated,batchName,batchName});
					}
					else
					{
						_LOGGER.error("lockBatchControl[" + batchName + "] - LAST_RUN date[" + lastRunStr +"] not reset");
					}
				}
				else
				{
					_LOGGER.error("lockBatchControl[" + batchName + "] - ERROR: expected 1, selectRows size = " + selectRows.size());
				}
			}
		}catch(Exception e) {
			_LOGGER.error("lockBatchControl in NCASBOSI Failed \n" +e.getMessage());
			throw new NCASException(NCASBOSIConstants.PAYMENT_EXCEPTION_950, BatchRequestDAOImpl.class, e);
		}
	 return updatedRows;
}
class SelectBatchControl extends AbstractSelect{
	public SelectBatchControl(DataSource dataSource){
		super(dataSource,SELECT_BATCH_CONTROL);
		declareParameter(new SqlParameter(Types.VARCHAR));
	}
	
	protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		//String lastRun = rs.getString("LAST_RUN");
		Date lastRun = rs.getDate("LAST_RUN");
		return lastRun;
	}
}
class UpdateLastRunBatchControl extends SqlUpdate{
	public UpdateLastRunBatchControl(DataSource dataSource){
		super(dataSource,UPDATE_LAST_RUN_BATCH_CONTROL);
		declareParameter(new SqlParameter(Types.TIMESTAMP));
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.VARCHAR));
		compile();
	}
}


private String getSchemaName() {
    String schemaName = BOSIConfig.getProperty(SCHEMA_NAME, " ");
    return schemaName;
 }

 private void updateStatus(Request req){
	// _LOGGER.info("Update Status");
	 String sql = "UPDATE "+getSchemaName()+".PL_REQSTATUS SET LAST_UPDATED=CURRENT_TIMESTAMP,STATUS=?,PARAM7=?,ERROR_MSG=?,PARAM3=? WHERE REQUEST_ID=?";
	 int types[] = new int[]{Types.CHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.INTEGER};
	 Object[] params = new Object[]{req.getStatus(),req.getParam7(),req.getErrormsg(),req.getParam3(),req.getRequest_id()};
	 getJdbcTemplate().update(sql, params, types);
	// _LOGGER.info("Finished Updating Status");
 }

}




