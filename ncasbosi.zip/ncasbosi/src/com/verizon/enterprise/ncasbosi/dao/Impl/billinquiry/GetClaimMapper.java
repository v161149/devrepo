package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import com.verizon.enterprise.common.ncas.claim.Claim;

public class GetClaimMapper implements RowMapper
{

	private final Logger _LOGGER = Logger.getLogger(GetClaimMapper.class);
	private final String EMPTY_SPACE = "";

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException{
		Claim resClaim = null;
		if(rs != null){
			_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry.GetClaimMapper");
			resClaim = new Claim();

			resClaim.setCorporateEntity(checkEmptySpaces(rs.getString("VPS_VZB_IND")));
			_LOGGER.info("VPS_VZB_IND= "+rs.getString("VPS_VZB_IND"));

			resClaim.setTrackingNumber(checkEmptySpaces(rs.getString("TRACKING_NUMBER")));
			_LOGGER.info("TRACKING_NUMBER= "+rs.getString("TRACKING_NUMBER"));

			resClaim.setBan(checkEmptySpaces(rs.getString("ACCOUNT_NUMBER")).trim());//Added code to trim the spaces in the account number
			_LOGGER.info("ACCOUNT_NUMBER= "+rs.getString("ACCOUNT_NUMBER"));

			resClaim.setClaimAmount(rs.getDouble("CLM_AMOUNT"));
			_LOGGER.info("CLM_AMOUNT= "+rs.getDouble("CLM_AMOUNT"));

			resClaim.setEntryDate(rs.getDate("CLM_ENTRY_DATE"));
			_LOGGER.info("CLM_ENTRY_DATE= "+rs.getDate("CLM_ENTRY_DATE"));

			resClaim.setStatus(checkEmptySpaces(rs.getString("CLM_STATUS_DESC")));
			_LOGGER.info("CLM_STATUS_DESC= "+rs.getString("CLM_STATUS_DESC"));

			resClaim.setStatusCode(rs.getInt("CLM_STATUS"));
			_LOGGER.info("CLM_STATUS= "+rs.getInt("CLM_STATUS"));

			resClaim.setAcctName(checkEmptySpaces(rs.getString("COMPANY_NAME")));
			_LOGGER.info("COMPANY_NAME= "+rs.getString("COMPANY_NAME"));
			
			resClaim.setClaimBans(checkEmptySpaces(rs.getString("CLM_BANS")));
			_LOGGER.info("CLM_BANS= "+rs.getString("CLM_BANS"));
			
			resClaim.setClosedDate(rs.getDate("DT_CLOSED"));
			_LOGGER.info("DT_CLOSED= "+rs.getDate("DT_CLOSED"));
			
			resClaim.setBillInquiryId(checkEmptySpaces(rs.getString("SRC_SYS_BI_ID")));
			_LOGGER.info("SRC_SYS_BI_ID= "+rs.getString("SRC_SYS_BI_ID"));
			
			resClaim.setBiCategory(checkEmptySpaces(rs.getString("BI_CATEGORY")));
			_LOGGER.info("BI_CATEGORY= "+rs.getString("BI_CATEGORY"));

		}
		return resClaim;
	}
	private String checkEmptySpaces(String input){
		if(input!=null && input.trim().length()==0){
			return EMPTY_SPACE;
		}else{
			return input;
		}
	}

}