package com.verizon.enterprise.ncasbosi.dao.Impl.email;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import com.verizon.enterprise.common.ncas.NCASDataUtil;
import com.verizon.enterprise.common.ncas.NcasConstants;
import com.verizon.enterprise.common.ncas.common.JMSUtility;
import com.verizon.enterprise.common.ncas.email.EmailMessageData;
import com.verizon.enterprise.common.ncas.exception.NCASException;
import com.verizon.enterprise.common.ncas.payments.EmailTemplateInfo;
import com.verizon.enterprise.common.util.commonUtil;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.common.PaymentsTemplateConfig;
import com.verizon.enterprise.ncasbosi.common.SystemParamConfig;



//DAOFactory.getInstance().getPaymentsBeanForECP().


public class EmailDAOImpl extends JdbcDaoSupport implements NCASBOSIConstants
{
	private static final Logger _LOGGER = Logger.getLogger(EmailDAOImpl.class);
	private JdbcTemplate dbTemplate;
	private JdbcTemplate vamJdbcTemplate;
	private final String PREPARED_INSERT_MESSAGE_DATA = "INSERT INTO MESSAGE_DATA "
			+ "(MESSAGE_DATA_OID, TYPE, FROM_ADDRESS, TO_ADDRESS, CHANNEL, SENT_DATE, SUBJECT, RECEIVED_DATE, CONTENT, ATTACHMENT, ATTACHMENT_FLAG, STATUS, USER_ID, CC_ADDRESS) "
			+ "VALUES (?, 'I',?, ?, ?, sysdate, ?, sysdate, ?, ?, ?, ?, ?, ?)";
	private String FILTER_MESSAGE_DATA = "SELECT MESSAGE_DATA_OID, TYPE, FROM_ADDRESS, TO_ADDRESS, STATUS, SUBJECT, CONTENT, CHANNEL, SENT_DATE, RECEIVED_DATE, USER_ID, "
			+ " TIMESTAMP, ATTACHMENT_FLAG, CC_ADDRESS FROM  ESG.MESSAGE_DATA WHERE  ";
	private LobHandler lobHandler;
	private DataFieldMaxValueIncrementer incrementer;
	
	private String SELECT_BATCH_CONTROL = "SELECT LAST_RUN FROM "+getSchemaName()+".PL_BATCH_CTL WHERE BATCH_NAME=? AND LOCK='"+NcasConstants.BATCH_RUNNING_LOCK_YES+"'";
	
	private String ECP_SELECT_EMAIL_MESSAGE_DATA = "SELECT MESSAGE_DATA_OID, TYPE, FROM_ADDRESS, TO_ADDRESS, STATUS, SUBJECT, CONTENT, CHANNEL, SENT_DATE, RECEIVED_DATE, USER_ID, "
			+ " TIMESTAMP, ATTACHMENT_FLAG, CC_ADDRESS FROM  ESG.MESSAGE_DATA WHERE CHANNEL IN (?) AND  TIMESTAMP > TO_TIMESTAMP('2012-06-06 02:26:00.0','YYYY-MM-DD HH:MI:SS.FF')";
	private String CHECK_VAC_EMAIL	=	" SELECT COUNT(*) AS MY_COUNT FROM "+NCASBOSIConstants.VAC_TABLESCHEMA+".VAC_EMAIL_T  WHERE EXT_EMAIL_ID = ?";
	
	private String EMAIL_SYNCH_MONITOR_EMAIL_TEMPLATE = "EMAIL_SYNCH_MONITOR_EMAIL_TEMPLATE";
	private String SYNC_REPORT_BETWEEN_ECP_AND_VAC = "SYNCREPORTBETWEENECPANDVAC";
	private String EMAIL_SYNC_MONITOR_DISTRO = "EMAIL_SYNC_MONITOR_DISTRO";
	
	protected void initDao() throws Exception{
		super.initDao();
	}


	public String getSchemaName()
	{
		String schemaName = NCASBOSIConstants.VAM_SCHEMA;
		return schemaName;
	}

	protected JdbcTemplate getDBTemplate()
	{
		if (this.dbTemplate == null || getDataSource() != this.dbTemplate.getDataSource())
			this.dbTemplate = new JdbcTemplate(getDataSource());
		return dbTemplate;
	}

	protected JdbcTemplate getVAMDBTemplate()
	{
		if (this.vamJdbcTemplate == null || getVAMDataSource() != this.vamJdbcTemplate.getDataSource())
			this.vamJdbcTemplate = new JdbcTemplate(getVAMDataSource());
		return vamJdbcTemplate;
	}

	// vam
	public void setVAMDataSource(DataSource dataSource)
	{
		vamJdbcTemplate = new JdbcTemplate(dataSource);
		_LOGGER.info("[vamJdbcTemplate datasource set ]");
	}

	protected DataSource getVAMDataSource()
	{
		return (this.vamJdbcTemplate != null ? this.vamJdbcTemplate.getDataSource() : null);
	}
	
	
	
	/**
	 * @param incrementer
	 *            The incrementer to set.
	 */
	public void setIncrementer(DataFieldMaxValueIncrementer incrementer) {
		this.incrementer = incrementer;
	}

	/**
	 * Set the LobHandler to use for BLOB/CLOB access. Could use a
	 * DefaultLobHandler instance as default, but relies on a specified
	 * LobHandler here.
	 *
	 * @see org.springframework.jdbc.support.lob.DefaultLobHandler
	 */
	public void setLobHandler(LobHandler lobHandler) {
		this.lobHandler = lobHandler;
	}

	public Map insertMessageData(Map params) throws NCASException
	{
		final String METHOD_NAME = "insertMessageData => ";
		_LOGGER.info(METHOD_NAME+"Entering");
		Map result = new HashMap();

       	final long oid;

		try {
			final EmailMessageData msgData = (EmailMessageData)params.get("msgData");

			final byte[] msgByteResult = msgData.getMimeMsgByte();

			// get the oid
			oid = incrementer.nextLongValue();
			getDBTemplate().execute(PREPARED_INSERT_MESSAGE_DATA,
					new AbstractLobCreatingPreparedStatementCallback(this.lobHandler) {

				@Override
				protected void setValues(PreparedStatement ps, LobCreator lobCreator)
						throws SQLException, DataAccessException {

					ps.setLong(1, oid);
					ps.setString(2, unNull(msgData.getFromAddress()));
					ps.setString(3, unNull(msgData.getToAddress()));
					ps.setString(4, unNull(msgData.getChannel()).toLowerCase());
					ps.setString(5, unNull(msgData.getSubject()));
					lobCreator.setClobAsString(ps, 6, unNull(msgData.getContent()));
					lobCreator.setBlobAsBytes(ps, 7, msgByteResult);
					ps.setString(8, unNull(msgData.getAttachmentFlag()));
					ps.setString(9, unNull(msgData.getStatus()));
					ps.setInt(10, msgData.getUserId());
					ps.setString(11, unNull(msgData.getCcAddress()));

				}
				private String unNull(String in) {
					if (in == null || in.length() == 0)
						return " ";
					else
						return in;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			_LOGGER.error(METHOD_NAME+"insertMessageData Failed \n"+e.getMessage());
			throw new NCASException(DB_ADMIN_EXCEPTION_950,EmailDAOImpl.class,e);
		}
		_LOGGER.info("Message Data inserted into DB "+oid);
		result.put("oid", oid);
		return result;
	}

	public Map selectMessageData(Map params) throws NCASException
	{
		final String METHOD_NAME = "selectMessageData => ";
		_LOGGER.info(METHOD_NAME+" Entering X0002 ");

		Map result = new HashMap();
		String searchCriteria = (String)params.get("searchCriteria");
		String channel = (String)params.get("channel");
		String startDate = (String)params.get("startDate");
		String endDate = (String)params.get("endDate");
		String lastMsgReceivedHrs = (String)params.get("hours");
		String lastRunTimeStamp	=	(String)params.get("lastRun");
		try {
			FilterMsgData msgData = null;
			_LOGGER.info(METHOD_NAME+"Exiting searchCriteria "+searchCriteria);
			StringBuffer prepareQuery = new StringBuffer();

			if("1".equalsIgnoreCase(searchCriteria)){
				prepareQuery.append(FILTER_MESSAGE_DATA);
				prepareQuery.append(" UPPER(TO_ADDRESS) IN ("+channel+") AND RECEIVED_DATE BETWEEN TO_DATE(?, 'MM-DD-YYYY') AND TO_DATE(?, 'MM-DD-YYYY') ");
				_LOGGER.info(" Filter Query .. "+prepareQuery.toString());
				msgData = new FilterMsgData(prepareQuery.toString());
				result = msgData.getMsgData(new Object[]{startDate, endDate });
			}else if ("2".equalsIgnoreCase(searchCriteria)){
				prepareQuery.append(FILTER_MESSAGE_DATA);
				prepareQuery.append(" UPPER(TO_ADDRESS) IN ("+channel+")  AND ABS((SYSDATE-RECEIVED_DATE)*24) <= ? ");
				_LOGGER.info(" Filter Query .. "+prepareQuery.toString());
				msgData = new FilterMsgData(prepareQuery.toString());
				result = msgData.getMsgData(new Object[]{lastMsgReceivedHrs });
			}else if ("3".equalsIgnoreCase(searchCriteria)){
				String ECP_LIST_EMAIL_MESSAGE_DATA = "SELECT MESSAGE_DATA_OID, TYPE, FROM_ADDRESS, TO_ADDRESS, STATUS" +
						" , SUBJECT, CONTENT, CHANNEL, SENT_DATE, RECEIVED_DATE, USER_ID, "
						+ " TIMESTAMP, ATTACHMENT_FLAG, CC_ADDRESS " +
						" FROM  ESG.MESSAGE_DATA " +
						" WHERE CHANNEL IN ("+channel+") " +
						" AND  TIMESTAMP > TO_TIMESTAMP('"+lastRunTimeStamp+"','YYYY-MM-DD HH:MI:SS.FF')";
				prepareQuery.append(ECP_LIST_EMAIL_MESSAGE_DATA);
				_LOGGER.info(" Filter Query .. "+prepareQuery.toString());
				msgData = new FilterMsgData(prepareQuery.toString());
				result = msgData.getMsgData(new Object[]{});
			}
			
		} catch (Exception ex) {
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(DB_ADMIN_EXCEPTION_950,EmailDAOImpl.class,ex);
		}

		return result;

	}

	
	class FilterMsgData extends JdbcDaoSupport{
		private String sql;
		public FilterMsgData(String sql) {
			this.sql = sql;
		}

		@SuppressWarnings("unchecked")
		public Map  getMsgData(Object[] params) {
			final String METHOD_NAME = "getMsgData => ";
			_LOGGER.info(METHOD_NAME+" Entering");
			return  (Map)getDBTemplate().query(sql, params, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException {
					Map<String,List<EmailMessageData>>  filterMsgData =   new HashMap<String,List<EmailMessageData>>();
					EmailMessageData msgData = null;
					List<EmailMessageData> retList = new ArrayList<EmailMessageData>();
					while (rs.next()) {
						msgData = new EmailMessageData();
						msgData.setMsgDataOid(rs.getString("MESSAGE_DATA_OID"));
						msgData.setType(rs.getString("TYPE"));
						msgData.setFromAddress(rs.getString("FROM_ADDRESS"));
						msgData.setToAddress(rs.getString("TO_ADDRESS"));
						msgData.setStatus(rs.getString("STATUS"));
						msgData.setSubject(rs.getString("SUBJECT"));
						msgData.setContent(rs.getString("CONTENT"));
						msgData.setChannel(rs.getString("CHANNEL"));
						msgData.setSentDate(rs.getDate("SENT_DATE"));
						msgData.setReceivedDate(rs.getDate("RECEIVED_DATE"));
						msgData.setUserId(rs.getInt("USER_ID"));
						msgData.setTimeStamp(rs.getTimestamp("TIMESTAMP"));
						msgData.setAttachmentFlag(rs.getString("ATTACHMENT_FLAG"));
						msgData.setCcAddress(rs.getString("CC_ADDRESS"));

						retList.add(msgData);
					}
					filterMsgData.put("msgList", retList);
					return filterMsgData;
				}});
		}
	}
	private String getChannels() throws NCASException{  
		final String METHOD_NAME = "getChannels => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		List<String> channelList 	=	null;
		StringBuffer channels	=	null;
		try {
			channels	=	new StringBuffer();
			channelList = NCASDataUtil.getConfigValues(NcasConstants.EMAIL_PROCESS_CHANNELS);
			for (Iterator iterator = channelList.iterator(); iterator.hasNext();) {
				String channel = (String) iterator.next();
				channels.append("'"+channel.trim()+"',");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		String channel	=	channels.toString();
		if(channel!=null && channel.length()>0){
			if(channel.lastIndexOf(",")>0)
				channel	=	channel.substring(0, channel.lastIndexOf(","));
		}
		_LOGGER.info(METHOD_NAME+" Existing"+channel);
		return channel;
	}
	
	private Object getLastRunTimeForEmailMonitor(String batchName) throws NCASException{
		final String METHOD_NAME = "getLastRunTimeForEmailMonitor => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		Object[] params = new Object[]{batchName};

		return  (Object) getVAMDBTemplate().query(SELECT_BATCH_CONTROL, params, new ResultSetExtractor(){
			        public Object extractData(ResultSet rs) throws SQLException {
			        	Object lastRun	=	null;
						while (rs.next())
							lastRun = rs.getTimestamp("LAST_RUN");
				          return lastRun;
			        }});
		
	}
	
	private Object isPresentInVac(String emailId) throws NCASException{
		final String METHOD_NAME = "isPresentInVac => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		Object[] params = new Object[]{emailId};

		return  (Object) getVAMDBTemplate().query(CHECK_VAC_EMAIL, params, new ResultSetExtractor(){
			        public Object extractData(ResultSet rs) throws SQLException {
			        	Object count	=	null;
						while (rs.next())
							 count = rs.getInt("MY_COUNT"); 
				          return count;
			        }});
	}
	public Map emailMonitor(Map params) throws NCASException
	{
		final String METHOD_NAME = "emailMonitor => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		Map result = new HashMap();
		String channels 	=	null;
		Map inputMap	=	new HashMap();
		Map ecpEmailList	=	null;
		List<EmailMessageData> retList	=	null;
		List<EmailMessageData> mismatchEmailList	=	new ArrayList<EmailMessageData>();
		try {
			channels	=	getChannels();
			Timestamp lastRun = (Timestamp)getLastRunTimeForEmailMonitor(NcasConstants.BATCH_INQ_EMAILS);
			String lastrunString	=	lastRun.toString();
			_LOGGER.info(METHOD_NAME+" **** lastRun ****"+lastrunString);
			inputMap.put("searchCriteria", "3");
			inputMap.put("channel", channels);
			inputMap.put("lastRun", lastrunString);
			ecpEmailList	=	selectMessageData(inputMap);
			retList =	(List<EmailMessageData>)ecpEmailList.get("msgList");
			for (EmailMessageData emailMessageData:retList) {
				_LOGGER.info(METHOD_NAME+"ecpEmailList*****size***"+retList.size());
				Integer count	=	(Integer)isPresentInVac(emailMessageData.getMsgDataOid());
				_LOGGER.info(METHOD_NAME+"****VACCOUNT****"+count);
				if(count == null || count.intValue() == 0){
					_LOGGER.info(METHOD_NAME+" ****Found the Message ID which is not in VAC****message id->"+emailMessageData.getMsgDataOid());
					mismatchEmailList.add(emailMessageData);
				}
			}
			if(mismatchEmailList.size()>0){
				result.put("mismatchEmailList", mismatchEmailList);
				sendEmailForSynch(mismatchEmailList);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(DB_ADMIN_EXCEPTION_950,EmailDAOImpl.class,ex);
		}

		return result;

	}
	private void sendEmailForSynch(List<EmailMessageData> mismatchEmailList) throws NCASException{
		final String METHOD_NAME = "sendEmailForSynch => ";
		_LOGGER.info(METHOD_NAME+" Entering");
		try{
			Map<String,Object> emailMap	=	new HashMap<String,Object>();
			StringBuffer htmlContent=new StringBuffer();
			for (EmailMessageData emailMessageData:mismatchEmailList) {
				htmlContent.append("<tr>");
				htmlContent.append("<td align='center'>").append(emailMessageData.getFromAddress()+"</td>");
				htmlContent.append("<td align='center'>").append(emailMessageData.getToAddress()+"</td>");
				htmlContent.append("<td align='center'>").append(emailMessageData.getSubject()+"</td>");
				htmlContent.append("<td align='center'>").append(emailMessageData.getSentDate()+"</td>");
				htmlContent.append("<td align='center'>").append(emailMessageData.getMsgDataOid()+"</td>");
				htmlContent.append("</tr>");
			}
				EmailTemplateInfo templateInfo = new EmailTemplateInfo();
				templateInfo = PaymentsTemplateConfig.getInstance().getEmailTemplateInfo().get(EMAIL_SYNCH_MONITOR_EMAIL_TEMPLATE);
				String template = templateInfo.getTemplateDesc();
				_LOGGER.debug("Email Sync monitor template -> "+template);
				String emailContent = template.replaceFirst(SYNC_REPORT_BETWEEN_ECP_AND_VAC, htmlContent.toString());
				List<String> toAddrList = null;
				List<String> ccAddrList = null;
				toAddrList = JMSUtility.getSplittedMailList(SystemParamConfig.getProperty(EMAIL_SYNC_MONITOR_DISTRO));
				_LOGGER.debug("email list -> "+toAddrList.toString());
				emailMap.put(NcasConstants.EMAIL_TO_ADDR, toAddrList);
				emailMap.put(NcasConstants.EMAIL_CC_ADDR, ccAddrList);
				emailMap.put(NcasConstants.EMAIL_SUBJECT, templateInfo.getSubject());								
				emailMap.put(NcasConstants.EMAIL_MESSAGE, emailContent);
				commonUtil.sendEmail(emailMap);
		}catch (Exception ex) {
			ex.printStackTrace();
			_LOGGER.error(METHOD_NAME + " Failed \n"+ex.getMessage());
			throw new NCASException(DB_ADMIN_EXCEPTION_950,EmailDAOImpl.class,ex);
		}
	}
}