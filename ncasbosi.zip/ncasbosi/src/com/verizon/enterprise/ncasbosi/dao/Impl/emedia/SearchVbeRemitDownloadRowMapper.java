package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;

public class SearchVbeRemitDownloadRowMapper implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(SearchVbeRemitDownloadRowMapper.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "SearchVbeRemitDownloadRowMapper::extractData() ";

		logger.info(METHOD_NAME + "ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> remitList = new ArrayList<List<Cell>>();
		List<Cell> remit = new ArrayList<Cell>();

		try
		{
			while(rs.next())
			{
				remit = new ArrayList<Cell>();

				String configSubsOid = rs.getString("CONFIG_SUBS_OID");
				String remitOid = rs.getString("REMIT_OID");
				String configId = rs.getString("CONFIG_ID");
				String remitId = rs.getString("REMIT_ID");
				String defaultRemit = rs.getString("DEFAULT_REMIT");
				String remitAccounts = String.valueOf(rs.getInt("REMIT_ACCTS"));
				String defaultAccounts = String.valueOf(rs.getInt("DEFLT_ACCTS"));
				String configName = rs.getString("CONFIG_NAME");
				String serviceType = rs.getString("SERVICE_TYPE");
				String remitStart = rs.getString("REMIT_START");
				String remitEnd = rs.getString("REMIT_END");
				String languageCode = rs.getString("LANGUAGE_CODE");
				String currencyCode = rs.getString("CURRENCY_CODE");

				if(CommonUtil.isNotNull(configSubsOid))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(configSubsOid.trim())));
				}

				if(CommonUtil.isNotNull(remitOid))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitOid.trim())));
				}

				if(CommonUtil.isNotNull(configId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(configId.trim())));
				}

				if(CommonUtil.isNotNull(remitId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitId.trim())));
				}

				if(CommonUtil.isNotNull(defaultRemit))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(defaultRemit.trim())));
				}

				if(CommonUtil.isNotNull(remitAccounts))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitAccounts.trim())));
				}

				if(CommonUtil.isNotNull(defaultAccounts))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(defaultAccounts.trim())));
				}

				if(CommonUtil.isNotNull(configName))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(configName.trim())));
				}

				if(CommonUtil.isNotNull(serviceType))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(serviceType.trim())));
				}

				if(CommonUtil.isNotNull(remitStart))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitStart.trim())));
				}

				if(CommonUtil.isNotNull(remitEnd))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitEnd.trim())));
				}

				if(CommonUtil.isNotNull(languageCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(languageCode.trim())));
				}

				if(CommonUtil.isNotNull(currencyCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(currencyCode.trim())));
				}

				remitList.add(remit);

				if(logger.isEnabledFor(Level.DEBUG))
				{
					logger.debug(METHOD_NAME + "remit=" + remit);
				}
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();

			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();

			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
		}

		if(logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + "remitList.size()=" + remitList.size());
		}

		return remitList;
	}
}
