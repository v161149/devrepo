package com.verizon.enterprise.ncasbosi.dao.Impl.vbif;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.vbif.AuditInfo;
import com.verizon.enterprise.common.ncas.vbif.TicketStatus;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;

public class AuditTicketResultSetRowMapper implements RowMapper {

	static private final Logger _LOGGER = Logger.getLogger(GetNotesResultSetRowMapper.class);

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		_LOGGER.debug("Inside GetNotesResultSetRowMapper::mapRow rowNum - " + rowNum);
		//CommonUtil.printMetaDataInfo(rs.getMetaData());
		AuditInfo auditInfo = new AuditInfo();
		TicketStatus ticketStatusInfo = new TicketStatus();
		
		String userName = rs.getString("USER_NAME");
		String userAction = rs.getString("USER_ACTION");
		Date lastUpdateDate = rs.getTimestamp("LAST_UPD_TIMESTAMP");
		String newOwner = rs.getString("NEW_OWNER");
		
		Integer ticketStatus  = rs.getInt("TKT_STATUS");
		String ticketStatusDesc = rs.getString("TKT_STATUS_DESC");
		Integer ticketSubStatus = rs.getInt("TKT_SUB_STATUS");
		String ticketSubStatusDesc = rs.getString("TKT_SUB_STAT_DESC");
		String status = "";
		String subStatus = "";
		if (status != null){
			status = String.valueOf(ticketStatus.intValue());
		}
		if (subStatus != null){
			subStatus = String.valueOf(ticketSubStatus.intValue());
		}
		if (CommonUtil.isNotNull(status)) {
			ticketStatusInfo.setStatus(status);
		}
		if (CommonUtil.isNotNull(ticketStatusDesc)) {
			ticketStatusInfo.setStatusText(ticketStatusDesc.trim());
		}
		if (CommonUtil.isNotNull(subStatus)) {
			ticketStatusInfo.setSubStatus(subStatus);
		}
		if (CommonUtil.isNotNull(ticketSubStatusDesc)) {
			ticketStatusInfo.setSubStatusText(ticketSubStatusDesc.trim());
		}
		ticketStatusInfo.setStatSubStat();  //combines the status's
		if (CommonUtil.isNotNull(userName)) {
			auditInfo.setUserName(userName.trim());
		}
		if (CommonUtil.isNotNull(userAction)) {
			auditInfo.setUserAction(userAction.trim());
		}
		if (lastUpdateDate!=null) {
			try { 
				auditInfo.setLastUpdatedTimeStamp(CommonUtil.getFormattedDateString(lastUpdateDate,"dd/MMM/yyyy HH:mm:ss"));
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
		if (CommonUtil.isNotNull(newOwner)) {
			auditInfo.setNewOwner(newOwner.trim());
		}
		auditInfo.setTicketStatus(ticketStatusInfo);
		
		return auditInfo;
	}
}
