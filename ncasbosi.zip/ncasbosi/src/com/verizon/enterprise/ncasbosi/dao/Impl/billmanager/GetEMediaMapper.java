package com.verizon.enterprise.ncasbosi.dao.Impl.billmanager;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.apache.log4j.Logger;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.common.ncas.billmanager.BillManager;
public class GetEMediaMapper implements RowMapper {
	private static final Logger _LOGGER = Logger.getLogger(GetEMediaMapper.class);
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException	{
		BillManager resBM=null;
		_LOGGER.info("Mapping Row# "+rowNum+ " within com.verizon.enterprise.ncasbosi.dao.Impl.billmanager.GetEMediaMapper");
		if(rs != null)
		{
			resBM=new BillManager();
			String profile=rs.getString("PROFILE");
			resBM.setProfile(profile!=null?profile.trim():profile);
			_LOGGER.info("PROFILE ="+rs.getString("PROFILE"));
			String configName = rs.getString("CONFIG_NAME");
			resBM.setConfigurationname(configName!=null?configName.trim():configName);
			_LOGGER.info("CONFIG_NAME="+configName);
			
		}
		return resBM;
	}
}
