package com.verizon.enterprise.ncasbosi.dao.Impl.autocredit;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;

import com.verizon.enterprise.common.ncas.autocredit.LineItem;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;


public class GetAdjustmentsMapper implements RowMapper
{
	private static final Logger logger = Logger.getLogger(GetAdjustmentsMapper.class);	public static final String [] adrValues =	{		"",		"MLO",		"WRO",		"PFT",		"PLT",		"TUL",		"RLO",		"TXI",		"WNP",		"NRG",		"OTH"	};

	public static final String [] adrText=	{		"",		"Military Objections",		"War Objections",		"Protesting Federal Taxes",		"Protesting the Local/State tax",		"Feels taxes are unlawful",		"Religious objection",		"Tax is invalid",		"Won't Pay",		"No Reason Given",		"Other"	};
	int adrIdx = 0;	public static final String [] classfValues =	{		"",		"U",		"C"	};

	public static final String [] classfText=	{		"",		"Uncollectable",		"Correct"	};
	int classfIdx = 0;

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException	{		final String METHOD_NAME = "GetAdjustmentsMapper::mapRow() ";

		if (logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + " ENTER");
		}

		logger.info(METHOD_NAME + "Mapping Row#=" + rowNum);
		LineItem li = null;		String formatDb2 = "yyyy-MM-dd";		String formatDisplayed = "MM/dd/yyyy";
		if(rs != null)		{			li = new LineItem();			li.setAdjustmentId(CommonUtil.formatDouble(rs.getDouble("VAC_ADJUST_ID")));			li.setAdjustmentStatus(rs.getInt("ADJ_STATUS") + "");			li.setBan(trimSpace(rs.getString("BAN")));			li.setOrig_System_Id(trimSpace(rs.getString("ORIGINATING_SYS_ID")));			li.setOrigInvoiceNum(trimSpace(rs.getString("INVOICE_NUM")));			li.setOrigInvoiceDate(CommonUtil.formatDate(rs.getString("ORIG_INVOICE_DT"), formatDb2, formatDisplayed));			li.setTargetInvoiceDate(CommonUtil.formatDate(rs.getString("TARGET_INVOICE_DT"), formatDb2, formatDisplayed));			li.setCreditFromDate(CommonUtil.formatDate(rs.getString("FROM_DATE"), formatDb2, formatDisplayed));			li.setCreditThroughDate(CommonUtil.formatDate(rs.getString("THRU_DATE"), formatDb2, formatDisplayed));			li.setCreditAmount(rs.getDouble("ADJ_AMOUNT"));			li.setCreditDebit(trimSpace(rs.getString("ADJ_CREDIT_DEBIT")));			li.setReasonCode(trimSpace(rs.getString("VZB_REASON_CODE")));			li.setReasonCode_Desc(trimSpace(rs.getString("ADJ_REASON_DESC")));			li.setSubCategory(trimSpace(rs.getString("SUB_CAT_CD")));			li.setSubCategory_Desc(trimSpace(rs.getString("SUB_CATEGORY_DESC")));			li.setProduct(trimSpace(rs.getString("SVC_TYPE_CD")));			li.setProduct_Desc(trimSpace(rs.getString("SVC_TYPE_DESC")));			li.setPostingLevel(trimSpace(rs.getString("POSTING_LEVEL")));			li.setErrorCode(trimSpace(rs.getString("RETURN_CODE")));			li.setErrorCodeText(trimSpace(rs.getString("RETURN_CODE_TEXT")));			li.setAdjustmentIndicator(trimSpace(rs.getString("LPC_IND")));			li.setRao(trimSpace(rs.getString("RAO")));			li.setAdditionalReasonCode(trimSpace(rs.getString("ADDL_REASON_CODE")));			li.setAdditionalReasonCode_Desc(getReasonCode_Txt(li.getAdditionalReasonCode()));			li.setClassificationCode(trimSpace(rs.getString("ADJ_CLASSIF_CODE")));			li.setClassificationCode_Desc(getClassificationCode_Txt(li.getClassificationCode()));			// user must update each row, set boolean to true if they still have not updated it.  The logic to figure			// out if user updated or not was debated so put code here so the ul will use same var even if logic to figure out			// if they updated changes.
			String reasonCode = trimSpace(rs.getString("VZB_REASON_CODE"));
			if (reasonCode == null || "".equals(reasonCode))				li.setUpdateNeeded(true);
			li.setWriteOffIndicator(trimSpace(rs.getString("WRITEOFF_IND")));
		}
		return li;	}
	//Trimmer to remove spaces that VAC sends	private String trimSpace(String input)	{
		return input!=null?input.trim():input;
	}
	private String getReasonCode_Txt(String adrCode)	{		//if null code return null text		if (adrCode == null)			return null;
		//check last value found		if (adrValues[adrIdx].equals(adrCode))			return adrText[adrIdx];		for (adrIdx=0; adrIdx < adrValues.length; adrIdx++)		{			if (adrValues[adrIdx].equals(adrCode))				return adrText[adrIdx];		}		adrIdx = 0; // if get to this point have not found condition set idx back to 0 to avoid error on next pass of this function.
		return "unknown";	}
	private String getClassificationCode_Txt(String classfCode)	{		//if null code return null text		if (classfCode == null)			return null;
		//check last value found		if (classfValues[classfIdx].equals(classfCode))			return classfText[classfIdx];		for (classfIdx=0; classfIdx < classfValues.length; classfIdx++)		{			if (classfValues[classfIdx].equals(classfCode))				return classfText[classfIdx];		}		classfIdx = 0; // if get to this point have not found condition set idx back to 0 to avoid error on next pass of this function.
		return "unknown";	}
}
