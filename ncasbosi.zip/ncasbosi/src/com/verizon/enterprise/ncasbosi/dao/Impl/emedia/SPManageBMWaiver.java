package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.Types;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.verizon.enterprise.common.eMedia.EMediaManageContact;
import com.verizon.enterprise.common.eMedia.EMediaProfile;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;

import org.apache.log4j.Logger;

public class SPManageBMWaiver extends BaseStoredProcedure {

	static private final Logger _LOGGER = Logger.getLogger(SPManageBMWaiver.class);

	private static List spInOutList;
	static
	{
		 spInOutList = new ArrayList();
		 spInOutList.add(new Object[]{"APP_USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"USER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DEBUG_LEVEL", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});

		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});

		 spInOutList.add(new Object[]{"ACTION", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTRACT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"START_DATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
		 spInOutList.add(new Object[]{"END_DATE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_INOUT});
	}
	public SPManageBMWaiver(DataSource dataSource, String schemaName)
	{
		super(dataSource, schemaName + "." + NCASBOSIConstants.SP_MANAGE_BM_WAIVER, spInOutList);
	}

	/**
	 * @param userId
	 * @param debugLevel
	 * @param profile
	 * @return
	 * @throws Exception
	 */
	/**
	 * @param userId
	 * @param debugLevel
	 * @param profile
	 * @return
	 * @throws Exception
	 */
	public Map executeStoredProcedure(String appUserId, String debugLevel,
			String userId,String userName,String action,String contractId,String startDate,String endDate)throws Exception
	{
		List paramValueList = new ArrayList();
		paramValueList.add(appUserId);//APP_USER_ID
		paramValueList.add(userId);//USER_ID
		paramValueList.add(userName);//USER_NAME
		paramValueList.add(debugLevel);//DEBUG_LEVEL
		paramValueList.add(action);//ACTION
		paramValueList.add(contractId);//CONTRACT_ID

		//Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		//String strStartDate = formatter.format(startDate);
		//_LOGGER.info("Formatted Expected Start Date = " + strStartDate);
		
		paramValueList.add(startDate);//START_DATE
		
		//Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		//String strEndDate = formatter.format(endDate);
		//_LOGGER.info("Formatted Expected End Date = " + strEndDate);
		paramValueList.add(endDate);//END_DATE
		

		return executeStoredProcedure(paramValueList);
	}

	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		List paramValueList = (List) paramValues;
		return executeSP(paramValueList, false);
	}
}
