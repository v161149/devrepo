package com.verizon.enterprise.ncasbosi.dao.Impl.billinquiry;


import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import java.math.BigDecimal;
import org.apache.log4j.Logger;

import com.verizon.enterprise.common.ncas.billinquiry.BillInquiry;
import com.verizon.enterprise.ncasbosi.common.NCASBOSIConstants;
import com.verizon.enterprise.ncasbosi.dao.BaseStoredProcedure;
import com.verizon.enterprise.ncasbosi.common.CommonUtil;



public class SPCreateBI extends BaseStoredProcedure

{



	 static private final Logger _LOGGER = Logger.getLogger(SPCreateBI.class);

	 private static List spInOutList;



	 static

	 {

		 _LOGGER.info("Static init ");

		 spInOutList = new ArrayList();

		 spInOutList.add(new Object[]{"SRC_SYS_BI_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BI_CATEGORY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"VBC_OR_VBCC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATING_SYS_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIGINATOR_LOGINID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"MAN", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCOUNT_NUM", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ACCOUNT_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INVOICE_NUMBER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BILL_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BI_REASON_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTACT_LAST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTACT_FIRST_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTACT_PHONE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTACT_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTACT_ADDL_EMAIL", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"BI_MEMO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CREDIT_DISP_AMT", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CREATE_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDL_BI_ID", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROBLEM_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROVIDER_NAME", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_WORK_ORDER", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ENTITLEMENT_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIBER_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SUBSCRIPTION_OID", getSqlDataType(Types.DECIMAL),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CUST_SVC_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CHANNEL_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CATEGORY_CODE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ATTACHMENT_FLAG", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PUBLIC_PRIVATE_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDR_ATTENTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDR_LINE1", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDR_LINE2", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDR_CITY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDR_STATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDR_ZIP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ATTACH_LETTER_IND", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INV_CPY_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEW_ADD_ATTENTION", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEW_ADD_LINE1", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEW_ADD_LINE2", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEW_ADD_CITY", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEW_ADD_STATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"NEW_ADD_ZIP", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CONTRACT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"AMMENDMENT_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADDL_ACCT_NOS", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ADJUST_REASON", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"EXPECTED_AMOUNT", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_FROM_ACCT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_TO_ACCT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TRANS_AMOUNT", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQUESTED_SVC", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_INSTL_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"DT_BILLING_BEGAN", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"INVOICE_PG_NO", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROB_BEGIN_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROB_END_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"PROMOTION_TYPE", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"SLA_SRVC_ID", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TT_NUMBER", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TAX_TYPE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"ORIG_DISC_DATE", getSqlDataType(Types.DATE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"POSTED_TO_ACCT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"CORRECT_PYMNT_ACT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"REQ_REFUND_AMT", getSqlDataType(Types.DOUBLE),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"TICKET_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_IN});
		 spInOutList.add(new Object[]{"RETURN_CODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"REASON_CODE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"ERROR_TEXT", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLCODE", getSqlDataType(Types.INTEGER),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"SP_SQLTOKENS", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT,});
		 spInOutList.add(new Object[]{"SP_SQLSTATE", getSqlDataType(Types.CHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
		 spInOutList.add(new Object[]{"OUT_TICKET_ID", getSqlDataType(Types.VARCHAR),NCASBOSIConstants.SP_PARAMETER_TYPE_OUT});
	 }

	public SPCreateBI(DataSource dataSource)
	{
		super(dataSource, NCASBOSIConstants.SP_CREATE_BI, spInOutList);
	}


	public Map executeStoredProcedure(Object paramValues)throws Exception
	{
		_LOGGER.info("Entering ExecuteStoredProcedure in "+getStoredProcedureName());

		BillInquiry bi = (BillInquiry)paramValues;
		List paramValueList = new ArrayList();
		String biCategory = bi.getBICategory();

		String acctName= "";
		String origLogin = "";
		String attachmentFlg = "";

		String pubInd = null;   // 1 is public in vac, 2 private

		_LOGGER.info("billInquiry Object::"+bi);

		paramValueList.add(bi.getSrcSysBIID()); //SRCSYSBID
		paramValueList.add(biCategory); //"POV" BI Category
		paramValueList.add(bi.getSourcePortal()); //"VBC" Source Portal
		paramValueList.add(bi.getOSID()); //ORIGINATING_SYS_ID
		
		// trunc origLogin to 20 - all VAC can handle now - will change later to 30
		// to match ECP def and then we can just change this code to act on 30.

		origLogin = bi.getOrigLogin();
		if(origLogin != null && origLogin.length()>20)
		{
			_LOGGER.info("Before Truncation \nOrigLogin: "+origLogin+"\nOrigLogin Length: "+origLogin.length());
			origLogin = origLogin.substring(0,20);
			_LOGGER.info("After Truncation \norigLogin: "+origLogin+"\norigLogin Length: "+origLogin.length());
		}
		else
		{
			int len = 0;
			if(origLogin != null){len = origLogin.length();}
			_LOGGER.info("Already VAC Compliant truncation is NOT required \norigLogin: "+origLogin+"\norigLogin Length: "+len);
		}

		paramValueList.add(origLogin); //ORIGINATOR_LOGINID
		paramValueList.add(bi.getBAN());//BAN
		paramValueList.add(bi.getSAN());//MAN
		paramValueList.add(bi.getAcctNum()); //ACCOUNT_NUM

		acctName = bi.getAcctName();
		_LOGGER.info("Checking Account Name for VAC Compliance");
		if(acctName != null && acctName.length()>40)
		{
			_LOGGER.info("Before Truncation \nAccount Name: "+acctName+"\nAccount Name Length: "+acctName.length());
			_LOGGER.info("Now trauncating Account Name to make it VAC Compliant");

			acctName = new String(acctName.substring(0, 40));
			_LOGGER.info("After Truncation \nAccount Name: "+acctName+"\nAccount Name Length: "+acctName.length());
		}
		else
		{
			int len = 0;
			if(acctName != null){len = acctName.length();}
			_LOGGER.info("Already VAC Compliant truncation is NOT required \nAccount Name: "+acctName+"\nAccount Name Length: "+len);
		}


		paramValueList.add(acctName);//ACCOUNT_NAME
		paramValueList.add(bi.getInvoiceNum()); //INVOICE_NUMBER
		paramValueList.add(bi.getBillDate()); //BILL_DATE
		paramValueList.add(bi.getReasonCode()); //BI_REASON_CODE
		paramValueList.add(bi.getSenderLastName());//CONTACT_LAST_NAME
		paramValueList.add(bi.getSenderFirstName());//CONTACT_FIRST_NAME
		paramValueList.add(bi.getSenderPhone());//CONTACT_PHONE
		paramValueList.add(bi.getSenderEmail()); //CONTACT_EMAIL
		paramValueList.add(bi.getAddlEmail()); //CONTACT_ADDL_EMAIL
		paramValueList.add(bi.getInquiryMemo()); //BI_MEMO
		paramValueList.add(new BigDecimal(checkForInteger(bi.getDisputeAmount())));//CREDIT_DISP_AMT
		paramValueList.add(bi.getCreatedDate());//CREATE_DATE
		paramValueList.add(null); //ADDL_BI_ID
		paramValueList.add(bi.getProblemType());//PROBLEM_TYPE
		paramValueList.add(null);//PROVIDER_NAME
		paramValueList.add(bi.getCustWO());//CUST_WORK_ORDER

		if(biCategory != null && biCategory.equalsIgnoreCase("POV")){
			  paramValueList.add(new Double(bi.getSubscriptionOid()));//SUBSCRIBER_OID
		}else if(biCategory != null && biCategory.equalsIgnoreCase("ECP")){
			  paramValueList.add(new Double(bi.getSubscriberOid()));//SUBSCRIBER_OID

		}else{
			_LOGGER.debug("Throwing BI Category Not Null Exception  in "+getStoredProcedureName());
			_LOGGER.error("Throwing BI Category Not Null Exception  in "+getStoredProcedureName());
			throw new Exception("BI Category either NULL or not known");

		}

		paramValueList.add(new Double(bi.getSubscriberOid()));
		paramValueList.add(new Double(bi.getSubscriptionOid()));
		paramValueList.add(bi.getCustSvcType());  //CUST_SVC_TYPE
		paramValueList.add(bi.getLob()); //CHANNEL_CODE
		//Added for BI OV enhacments anand Lourdes Ignatius

		paramValueList.add(bi.getCategoryCode());  //CATEGORY_CODE
		if (bi.isAttachmentFlg()) {
		        attachmentFlg="Y";
		} else {
		        attachmentFlg="N";
        }

		paramValueList.add(attachmentFlg);  //ATTACHMENT_FLAG
		if(biCategory != null && biCategory.equalsIgnoreCase("POV"))
		{
		   if (bi.getSourcePortal() != null && bi.getSourcePortal().equalsIgnoreCase("VBC"))
		       {
					paramValueList.add(VAC_PRIVATE);  //PUBLIC_PRIVATE_IND
			   }
			   else
			   {
				   paramValueList.add(VAC_PUBLIC);  //PUBLIC_PRIVATE_IND
			   }
	   }
	   else
	   {
		   paramValueList.add(checkForNullString(bi.getPublicIndicator()));  //PUBLIC_PRIVATE_IND
	   }

		paramValueList.add(checkForNullString(bi.getAddrAttention()));  //ADDR_ATTENTION
		paramValueList.add(checkForNullString(bi.getAddrLine1()));  //ADDR_LINE1
		paramValueList.add(checkForNullString(bi.getAddrLine2()));  //ADDR_LINE2
		paramValueList.add(checkForNullString(bi.getAddrCity()));  //ADDR_CITY
		paramValueList.add(checkForNullString(bi.getAddrState()));  //ADDR_STATE
		paramValueList.add(checkForNullString(bi.getAddrZip()));  //ADDR_ZIP
		paramValueList.add(checkForNullString(bi.getAttachmentInd()));  //ATTACH_LETTER_IND
		paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getInvoiceCopyDate())));  //INV_CPY_DATE
		paramValueList.add(checkForNullString(bi.getNewAddrAttention()));  //NEW_ADD_ATTENTION
		paramValueList.add(checkForNullString(bi.getNewAddrLine1()));  //NEW_ADD_LINE1
		paramValueList.add(checkForNullString(bi.getNewAddrLine2()));  //NEW_ADD_LINE2
		paramValueList.add(checkForNullString(bi.getNewAddrCity()));  //NEW_ADD_CITY
		paramValueList.add(checkForNullString(bi.getNewAddrState()));  //NEW_ADD_STATE
		paramValueList.add(checkForNullString(bi.getNewAddrZip()));  //NEW_ADD_ZIP
		paramValueList.add(checkForNullString(bi.getContractId()));  //CONTRACT_ID
		paramValueList.add(checkForNullString(bi.getAmendmentId()));  //AMMENDMENT_ID
		paramValueList.add(checkForNullString(bi.getAdditionalAcctNumbers()));  //ADDL_ACCT_NOS
		paramValueList.add(checkForNullString(bi.getAdjustmentReason()));  //ADJUST_REASON
		paramValueList.add(new BigDecimal(checkForInteger(bi.getExpectedAdjustment())));  //EXPECTED_AMOUNT
		paramValueList.add(checkForNullString(bi.getTransferFrom()));  //TRANS_FROM_ACCT
		paramValueList.add(checkForNullString(bi.getTransferTo()));  //TRANS_TO_ACCT
		paramValueList.add(new BigDecimal(checkForInteger(bi.getTransferAmount())));  //TRANS_AMOUNT
		paramValueList.add(checkForNullString(bi.getServiceRequested()));  //REQUESTED_SVC
		paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getInstallationDate())));  //REQ_INSTL_DATE
		paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getBillingDate())));  //DT_BILLING_BEGAN
		paramValueList.add(checkForNullString(bi.getImpactedInvoicePageNum()));  //INVOICE_PG_NO
		paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getProblemBeganDate())));  //PROB_BEGIN_DATE
		paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getProblemEndDate())));  //PROB_END_DATE
		paramValueList.add(checkForNullString(bi.getPromotionType()));  //PROMOTION_TYPE
		paramValueList.add(checkForNullString(bi.getAffectedServiceId()));  //SLA_SRVC_ID
		paramValueList.add(checkForNullString(bi.getTroubleTicketNum()));  //TT_NUMBER
		paramValueList.add(checkForNullString(bi.getTaxType()));  //TAX_TYPE
		paramValueList.add(CommonUtil.getDateFromString(checkForNull(bi.getDisconnectDate())));  //ORIG_DISC_DATE
		paramValueList.add(checkForNullString(bi.getPaymentPostedAcct()));  //POSTED_TO_ACCT
		paramValueList.add(checkForNullString(bi.getCorrectPaymentAcct()));  //CORRECT_PYMNT_ACT
		paramValueList.add(new BigDecimal(checkForInteger(bi.getRefundAmount())));  //REQ_REFUND_AMT
		paramValueList.add(checkForNullString(bi.getTicketid()));  //TICKET_ID

		Map resMap = executeSP(paramValueList, false);

		_LOGGER.info("Now calling checkVACErrors to identify any errors or issued warnings");
		checkVACErrors(resMap);

		_LOGGER.info("Exiting ExecuteStoredProcedure in "+getStoredProcedureName());
		return resMap;

	}

	        private String checkForInteger(String pInputParam){
					if(pInputParam == null || pInputParam.trim().length()==0){
						return "0";
					}else{
						return pInputParam;
					}
			}

	    	private String checkForNull(String pInputParam){
					if(pInputParam == null || pInputParam.trim().length()==0){
						return "";
					}else{
						return CommonUtil.formatDate(pInputParam,"MM/dd/yyyy","yyyy-MM-dd");
					}
		   }

			private String checkForNullString(String pInputParam){
					if(pInputParam == null || pInputParam.trim().length()==0){
						return "";
					}
					else{
						return pInputParam;
					}
		   }
}

