package com.verizon.enterprise.ncasbosi.dao.Impl.emedia;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.verizon.enterprise.ncasbosi.common.CommonUtil;
import com.verizon.enterprise.common.ncas.display.Cell;
import com.verizon.enterprise.common.util.commonUtil;

public class SearchVbeRemitFullDownloadRowMapper implements ResultSetExtractor
{
	static private final Logger logger = Logger.getLogger(SearchVbeRemitDownloadRowMapper.class);

	public Object extractData(ResultSet rs) throws SQLException
	{
		final String METHOD_NAME = "SearchVbeRemitFullDownloadRowMapper::extractData() ";

		logger.info(METHOD_NAME + "ENTER");

		CommonUtil.printMetaDataInfo(rs.getMetaData());
		List<List<Cell>> remitList = new ArrayList<List<Cell>>();
		List<Cell> remit = new ArrayList<Cell>();

		try
		{
			while(rs.next())
			{
				remit = new ArrayList<Cell>();

				
				String configId = rs.getString("CONFIG_ID");//VBE Bill Id
				String vbeName=rs.getString("VBE_NAME");//VBE Bill Name
				String remitId = rs.getString("REMIT_ID");//Remit Pt Id
				String remitConfigName = rs.getString("CONFIG_NAME");//Remit Config Name
				String defaultRemit = rs.getString("DEFAULT_REMIT");//Remit Default Ind
				String currencyCode = rs.getString("CURRENCY_CODE");
				String languageCode = rs.getString("LANGUAGE_CODE");
			    String nasp=rs.getString("NASP");
	            String revLoc=rs.getString("REVLOC");
                String custCountry=rs.getString("CUST_COUNTRY");
                String custState=rs.getString("CUST_STATE");
                String postalCode=rs.getString("POSTAL_CODE");
                String custCity=rs.getString("CUST_CITY");
                String custAddress1=rs.getString("CUST_ADDR_1");
                String custAddress2=rs.getString("CUST_ADDR_2");
                String custAddress3=rs.getString("CUST_ADDR_3");
                String useVbeAddress=rs.getString("USE_VBE_ADDRESS");
				String paymentDueInt=rs.getString("PAYMENT_DUE_INT");
                
			
						    		
            	if(CommonUtil.isNotNull(configId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(configId.trim())));
				}
            	if(CommonUtil.isNotNull(vbeName))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(vbeName.trim())));
				}
			
				if(CommonUtil.isNotNull(remitId))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitId.trim())));
				}
                if(CommonUtil.isNotNull(remitConfigName))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(remitConfigName.trim())));
				}
				if(CommonUtil.isNotNull(defaultRemit))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(defaultRemit.trim())));
				}

				if(CommonUtil.isNotNull(currencyCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(currencyCode.trim())));
				}
				if(CommonUtil.isNotNull(languageCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(languageCode.trim())));
				}

				
				if(CommonUtil.isNotNull(nasp))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(nasp.trim())));
				}
            
                if(CommonUtil.isNotNull(revLoc))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(revLoc.trim())));
				}
				if(CommonUtil.isNotNull(custCountry))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custCountry.trim())));
				}
				if(CommonUtil.isNotNull(custState))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custState.trim())));
				}
			
				if(CommonUtil.isNotNull(postalCode))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(postalCode.trim())));
				}
				if(CommonUtil.isNotNull(custCity))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custCity.trim())));
				}
				if(CommonUtil.isNotNull(custAddress1))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custAddress1.trim())));
				}
				if(CommonUtil.isNotNull(custAddress2))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custAddress2.trim())));
				}
				if(CommonUtil.isNotNull(custAddress3))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(custAddress3.trim())));
				}
				if(CommonUtil.isNotNull(useVbeAddress))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(useVbeAddress.trim())));
				}
				if(CommonUtil.isNotNull(paymentDueInt))
				{
					remit.add(new Cell(commonUtil.excelTextValueOf(paymentDueInt.trim())));
				}

				remitList.add(remit);

				if(logger.isEnabledFor(Level.DEBUG))
				{
					logger.debug(METHOD_NAME + "remit=" + remit);
				}
			}
		}
		catch(NumberFormatException nfe)
		{
			nfe.printStackTrace();

			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + nfe.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();

			logger.debug(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
			logger.error(METHOD_NAME + "Exception occured while parsing the resultset \n" + e.getMessage());
		}

		if(logger.isEnabledFor(Level.DEBUG))
		{
			logger.debug(METHOD_NAME + "remitList.size()=" + remitList.size());
		}

		return remitList;
	}
}
