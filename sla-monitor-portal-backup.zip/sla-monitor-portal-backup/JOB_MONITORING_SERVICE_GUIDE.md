# 📊 JOB MONITORING SERVICE - COMPLETE GUIDE

## 🎯 **OVERVIEW**

Automated background service that:
- ✅ Wakes up every **30 minutes**
- ✅ Scans for ETL jobs scheduled in **next 2-hour window**
- ✅ Parses **cron expressions** to calculate execution times
- ✅ Inserts records to **service_monitoring_log** table
- ✅ Prevents **duplicates** automatically
- ✅ Runs as **background thread** (like health monitoring)

---

## 📦 **DELIVERABLES**

### **1. Database Migration**
**[create_service_monitoring_log_table.py](computer:///mnt/user-data/outputs/create_service_monitoring_log_table.py)**
- Creates `service_monitoring_log` table
- Auto-incrementing ID
- UNIQUE constraint prevents duplicates
- Indexes for performance

### **2. Job Monitoring Service**
**[job_monitoring_service.py](computer:///mnt/user-data/outputs/job_monitoring_service.py)**
- Background thread (30-minute intervals)
- Cron expression parser
- 2-hour window calculator
- Duplicate detection

### **3. Database Service Updates**
**[database_service_updated.py](computer:///mnt/user-data/outputs/database_service_updated.py)** (updated)
- `get_scheduled_jobs_in_window()`
- `get_scheduled_jobs_by_service()`
- `get_scheduled_jobs_by_date()`
- `update_job_execution_status()`
- `get_job_monitoring_stats()`

### **4. API Service Updates**
**[api_service_updated.py](computer:///mnt/user-data/outputs/api_service_updated.py)** (updated)
- Import and initialize job monitoring
- API endpoints for querying scheduled jobs
- Auto-start on server startup

### **5. Requirements**
**[job_monitoring_requirements.txt](computer:///mnt/user-data/outputs/job_monitoring_requirements.txt)**
- croniter>=2.0.0

---

## 🚀 **INSTALLATION**

### **Step 1: Install Dependencies**

```bash
cd backend
pip install croniter>=2.0.0
```

Or add to requirements.txt:
```bash
cat job_monitoring_requirements.txt >> requirements.txt
pip install -r requirements.txt
```

---

### **Step 2: Run Database Migration**

```bash
cd backend
python create_service_monitoring_log_table.py
```

**Expected Output:**
```
======================================================================
Migrating: ../database/sla_portal.db
======================================================================
Creating service_monitoring_log table...
✓ Table created successfully

Creating indexes...
  ✓ Index on service_id
  ✓ Index on asset_id
  ✓ Index on scheduled_start_time
  ✓ Index on scheduled_execution_date
  ✓ Index on on_time_ind

Verifying table structure...

Table has 17 columns:
  1. id (INTEGER) PRIMARY KEY
  2. asset_id (TEXT) NOT NULL
  3. asset_name (TEXT)
  4. service_id (TEXT) NOT NULL
  5. service_name (TEXT)
  6. job_name (TEXT)
  7. job_type (TEXT)
  8. deployment_location (TEXT)
  9. job_schedule (TEXT)
  10. scheduled_execution_date (TEXT) NOT NULL
  11. scheduled_start_time (TEXT) NOT NULL
  12. scheduled_end_time (TEXT) NOT NULL
  13. scheduled_execution_duration (TEXT)
  14. start_time (TEXT)
  15. end_time (TEXT)
  16. on_time_ind (TEXT)
  17. creation_time (TIMESTAMP)

Indexes created: 6
  - sqlite_autoindex_service_monitoring_log_1
  - idx_sml_service_id
  - idx_sml_asset_id
  - idx_sml_scheduled_start_time
  - idx_sml_scheduled_execution_date
  - idx_sml_on_time_ind

Unique constraints: 1
  - sqlite_autoindex_service_monitoring_log_1 (prevents duplicate job executions)

======================================================================
SUCCESS! Table created successfully!
======================================================================
```

---

### **Step 3: Deploy Service Files**

```bash
# Copy job monitoring service
cp job_monitoring_service.py backend/job_monitoring_service.py

# Replace database service
cp database_service_updated.py backend/database_service.py

# Replace API service
cp api_service_updated.py backend/api_service.py
```

---

### **Step 4: Restart Backend**

```bash
cd backend
python api_service.py
```

**Expected Logs:**
```
INFO - Starting health monitoring service...
INFO - Health monitoring service started
INFO - Starting job monitoring service...
INFO - Job monitoring service started (checks every 30 minutes)
INFO - Job monitoring service thread started
INFO - Checking jobs scheduled between 2025-12-06 15:00:00 and 2025-12-06 17:00:00
INFO - Found 3 ETL job(s) with schedules
INFO - Job 'GRM Weekly ETL Job-2': 1 execution(s) scheduled
INFO - Job 'DevOPS Hourly ETL': 2 execution(s) scheduled
INFO - Inserted 3 new scheduled execution record(s)
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
```

---

## 📊 **HOW IT WORKS**

### **Timeline Example:**

```
Current Time: 7:00 AM
Window Start: 8:00 AM (next hour)
Window End: 10:00 AM (2 hours later)

Jobs Scheduled:
├─ Daily Job: "0 8 * * *" (every day at 8:00 AM)
│  └─ Insert: 08:00:00 - 08:30:00 (1 record)
│
├─ Hourly Job: "0 * * * *" (every hour at :00)
│  └─ Insert: 08:00:00 - 08:30:00 (1 record)
│  └─ Insert: 09:00:00 - 09:30:00 (1 record)
│
└─ Every 15 min: "*/15 * * * *"
   └─ Insert: 08:00, 08:15, 08:30, 08:45 (4 records)
   └─ Insert: 09:00, 09:15, 09:30, 09:45 (4 records)

Total: 11 records inserted
```

---

### **Window Calculation Logic:**

```python
Current Time → Next Window Start (top of next hour)

Examples:
7:00 AM → 8:00 AM (window: 8:00-10:00)
7:20 AM → 8:00 AM (window: 8:00-10:00)
7:59 AM → 8:00 AM (window: 8:00-10:00)
8:00 AM → 9:00 AM (window: 9:00-11:00)
8:01 AM → 9:00 AM (window: 9:00-11:00)
8:30 AM → 9:00 AM (window: 9:00-11:00)
```

---

### **Duplicate Prevention:**

**UNIQUE Constraint:**
```sql
UNIQUE(
    asset_id, 
    service_id, 
    job_name, 
    job_type, 
    scheduled_execution_date, 
    scheduled_start_time, 
    scheduled_end_time
)
```

**Behavior:**
- If exact same record exists → Skip (no insert)
- If any field differs → Insert new record
- Runs every 30 minutes → Checks if window already processed

---

## 🧪 **TESTING**

### **Test 1: Verify Service Started**

**Check Logs:**
```bash
# Backend logs should show:
INFO - Job monitoring service started (checks every 30 minutes)
INFO - Job monitoring service thread started
INFO - Checking jobs scheduled between ...
```

---

### **Test 2: Verify Table Created**

```sql
-- Check table exists
SELECT name FROM sqlite_master 
WHERE type='table' AND name='service_monitoring_log';

-- Check structure
PRAGMA table_info(service_monitoring_log);

-- Check indexes
PRAGMA index_list(service_monitoring_log);
```

---

### **Test 3: Add Test ETL Job**

```sql
-- Insert test ETL job with hourly schedule
INSERT INTO services (
    service_id, org_id, name, asset_id, 
    monitoring_method, deployment_location, 
    metadata, is_active
) VALUES (
    'svc-test001',
    'org-default',
    'Test Hourly ETL',
    'asset-001',
    'direct',
    'airflow',
    json('{
        "service_type": "etl_batch",
        "service_category": "Data Processing",
        "monitoring_method": "direct",
        "execution_time": "00:15:00",
        "config": {
            "job_name": "Test Hourly Job",
            "schedule": "0 * * * *"
        }
    }'),
    1
);
```

---

### **Test 4: Wait 30 Minutes or Force Check**

**Option A: Wait for next 30-minute cycle**

**Option B: Restart backend to trigger immediate check**
```bash
# Stop backend (Ctrl+C)
# Start backend
python api_service.py

# Check logs for:
# "Inserted X new scheduled execution record(s)"
```

---

### **Test 5: Query Scheduled Jobs**

```sql
-- View all scheduled jobs
SELECT * FROM service_monitoring_log
ORDER BY scheduled_start_time DESC
LIMIT 10;

-- View today's jobs
SELECT 
    job_name,
    scheduled_start_time,
    scheduled_end_time,
    scheduled_execution_duration
FROM service_monitoring_log
WHERE scheduled_execution_date = date('now')
ORDER BY scheduled_start_time;

-- Count by job
SELECT 
    job_name,
    COUNT(*) as execution_count
FROM service_monitoring_log
GROUP BY job_name
ORDER BY execution_count DESC;
```

---

### **Test 6: API Endpoints**

**Get Today's Scheduled Jobs:**
```bash
curl http://localhost:5000/api/v1/job-monitoring/scheduled \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Get Jobs by Service:**
```bash
curl "http://localhost:5000/api/v1/job-monitoring/scheduled?service_id=svc-test001" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Get Jobs by Date:**
```bash
curl "http://localhost:5000/api/v1/job-monitoring/scheduled?date=2025-12-06" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Get Monitoring Stats:**
```bash
curl http://localhost:5000/api/v1/job-monitoring/stats \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Response:**
```json
{
  "total_scheduled": 150,
  "scheduled_today": 24,
  "by_status": {
    "Unknown": 100,
    "Met": 30,
    "Unmet": 15,
    "In Progress": 5
  },
  "unique_jobs": 8
}
```

---

## 📋 **CRON EXPRESSION EXAMPLES**

| Expression | Meaning | Records Inserted (2-hour window) |
|------------|---------|----------------------------------|
| `0 8 * * *` | Daily at 8:00 AM | 1 (if 8:00 in window) |
| `0 */2 * * *` | Every 2 hours | 1 (8:00 or 10:00) |
| `0 * * * *` | Every hour | 2 (8:00, 9:00) |
| `*/30 * * * *` | Every 30 minutes | 4 (8:00, 8:30, 9:00, 9:30) |
| `*/15 * * * *` | Every 15 minutes | 8 (8:00, 8:15, 8:30, ..., 9:45) |
| `*/5 * * * *` | Every 5 minutes | 24 (8:00, 8:05, 8:10, ..., 9:55) |
| `0 20 * * 3` | Weekly Wed 8:00 PM | 1 (only if Wednesday) |
| `0 0 1 * *` | Monthly 1st midnight | 1 (only if 1st) |

**Cron Format:**
```
* * * * *
│ │ │ │ │
│ │ │ │ └─ Day of Week (0-6, 0=Sunday)
│ │ │ └─── Month (1-12)
│ │ └───── Day of Month (1-31)
│ └─────── Hour (0-23)
└───────── Minute (0-59)
```

---

## 💾 **DATABASE SCHEMA**

```sql
CREATE TABLE service_monitoring_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id TEXT NOT NULL,                    -- FK to assets
    asset_name TEXT,                            -- Denormalized
    service_id TEXT NOT NULL,                   -- FK to services
    service_name TEXT,                          -- Denormalized
    job_name TEXT,                              -- From metadata.config.job_name
    job_type TEXT,                              -- From metadata.service_type
    deployment_location TEXT,                   -- autosys/airflow/ansible_tower
    job_schedule TEXT,                          -- Cron expression
    scheduled_execution_date TEXT NOT NULL,     -- YYYY-MM-DD
    scheduled_start_time TEXT NOT NULL,         -- YYYY-MM-DD HH:MM:SS
    scheduled_end_time TEXT NOT NULL,           -- YYYY-MM-DD HH:MM:SS
    scheduled_execution_duration TEXT,          -- HH:MM:SS
    start_time TEXT,                            -- Actual start (for future use)
    end_time TEXT,                              -- Actual end (for future use)
    on_time_ind TEXT DEFAULT 'Unknown',        -- Met/Unmet/Unknown/In Progress/Failed
    creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id),
    FOREIGN KEY (service_id) REFERENCES services(service_id),
    
    -- Prevent duplicates
    UNIQUE(asset_id, service_id, job_name, job_type, 
           scheduled_execution_date, scheduled_start_time, scheduled_end_time)
);
```

---

## 🔍 **EXAMPLE QUERIES**

### **Jobs Scheduled in Next Hour:**
```sql
SELECT 
    job_name,
    scheduled_start_time,
    scheduled_execution_duration,
    on_time_ind
FROM service_monitoring_log
WHERE scheduled_start_time >= datetime('now')
  AND scheduled_start_time < datetime('now', '+1 hour')
ORDER BY scheduled_start_time;
```

---

### **Daily Schedule Report:**
```sql
SELECT 
    job_name,
    COUNT(*) as executions_today,
    MIN(scheduled_start_time) as first_run,
    MAX(scheduled_start_time) as last_run
FROM service_monitoring_log
WHERE scheduled_execution_date = date('now')
GROUP BY job_name
ORDER BY executions_today DESC;
```

---

### **Jobs by Hour:**
```sql
SELECT 
    strftime('%H:00', scheduled_start_time) as hour,
    COUNT(*) as job_count
FROM service_monitoring_log
WHERE scheduled_execution_date = date('now')
GROUP BY hour
ORDER BY hour;
```

---

### **Late or Missing Jobs:**
```sql
SELECT 
    job_name,
    scheduled_start_time,
    start_time,
    on_time_ind
FROM service_monitoring_log
WHERE scheduled_start_time < datetime('now')
  AND on_time_ind = 'Unknown'
ORDER BY scheduled_start_time;
```

---

## 🎨 **SERVICE BEHAVIOR**

### **Every 30 Minutes:**

```
┌─────────────────────────────────────────┐
│ Job Monitoring Service (Background)     │
└─────────────────────────────────────────┘
              │
              ↓
    Calculate Next 2-Hour Window
              │
              ↓
    Check if Window Already Processed
              │
         ┌────┴────┐
         │         │
      Yes│         │No
         │         │
         ↓         ↓
      Skip     Continue
                  │
                  ↓
         Get ETL Jobs with Schedules
                  │
                  ↓
         Parse Cron Expressions
                  │
                  ↓
      Calculate Execution Times in Window
                  │
                  ↓
         For Each Execution Time:
           - Calculate end time
           - Try to insert record
           - Skip if duplicate
                  │
                  ↓
         Log Results & Sleep 30 min
```

---

## 🔧 **CONFIGURATION**

### **Change Check Interval:**

Edit `job_monitoring_service.py`:
```python
self.check_interval = 1800  # 30 minutes (default)
# Change to:
self.check_interval = 600   # 10 minutes
self.check_interval = 3600  # 60 minutes
```

---

### **Change Window Size:**

Edit `_check_scheduled_jobs()` method:
```python
# Default: 2 hours
window_end = window_start + timedelta(hours=2)

# Change to:
window_end = window_start + timedelta(hours=4)  # 4-hour window
window_end = window_start + timedelta(hours=1)  # 1-hour window
```

---

## 📊 **MONITORING THE SERVICE**

### **Check Service is Running:**
```bash
# Backend logs should show every 30 minutes:
INFO - Checking jobs scheduled between ...
INFO - Found X ETL job(s) with schedules
INFO - Inserted Y new scheduled execution record(s)
```

---

### **Check for Errors:**
```bash
# Look for ERROR lines in logs:
grep "ERROR" backend.log
```

---

### **View Recent Activity:**
```sql
SELECT 
    creation_time,
    job_name,
    scheduled_start_time
FROM service_monitoring_log
ORDER BY creation_time DESC
LIMIT 20;
```

---

## 🐛 **TROUBLESHOOTING**

### **Service Not Starting:**

**Check:**
1. croniter installed: `pip list | grep croniter`
2. No import errors in logs
3. Database accessible

**Fix:**
```bash
pip install croniter>=2.0.0
```

---

### **No Jobs Being Inserted:**

**Check:**
1. ETL jobs exist with schedules
2. Schedules are valid cron expressions
3. Jobs are active (`is_active = 1`)

**Query:**
```sql
SELECT 
    service_id,
    name,
    json_extract(metadata, '$.service_type') as service_type,
    json_extract(metadata, '$.config.schedule') as schedule
FROM services
WHERE is_active = 1
  AND metadata LIKE '%etl_batch%';
```

---

### **Invalid Cron Expression:**

**Logs:**
```
WARNING - Invalid cron expression for job XYZ: invalid format
```

**Fix:**
Update the job's schedule in metadata:
```sql
UPDATE services
SET metadata = json_set(
    metadata,
    '$.config.schedule',
    '0 8 * * *'  -- Valid cron expression
)
WHERE service_id = 'svc-xxx';
```

---

### **Too Many Records Inserted:**

**Cause:** Very frequent jobs (e.g., every minute)

**Solution:**
- Adjust window size (reduce from 2 hours to 1 hour)
- Or filter to only insert jobs that run hourly or less frequently

---

## 📋 **CHECKLIST**

Installation:
- [ ] Install croniter library
- [ ] Run database migration
- [ ] Deploy job_monitoring_service.py
- [ ] Update database_service.py
- [ ] Update api_service.py
- [ ] Restart backend

Verification:
- [ ] Service starts successfully
- [ ] Logs show "Job monitoring service started"
- [ ] Table service_monitoring_log exists
- [ ] Records being inserted every 30 minutes
- [ ] API endpoints working
- [ ] No errors in logs

Testing:
- [ ] Add test ETL job with schedule
- [ ] Wait 30 minutes or restart
- [ ] Query service_monitoring_log table
- [ ] Verify records inserted correctly
- [ ] Test API endpoints
- [ ] Check duplicate prevention

---

## 🎉 **SUMMARY**

**Service:** Job Monitoring Service  
**Interval:** Every 30 minutes  
**Window:** Next 2 hours  
**Job Types:** ETL Batch (etl_batch)  
**Schedule Format:** Cron expressions  
**Duplicate Prevention:** UNIQUE constraint  
**Integration:** Background thread in api_service.py  

**Files Created:** 5  
**Database Tables:** 1  
**API Endpoints:** 3  
**Background Services:** 2 (health + job monitoring)  

**Complete implementation!** ✅  
**Ready to track scheduled jobs!** 📊  
**Perfect!** 🚀
