#!/bin/bash

# SLA Monitoring Portal - Quick Start Script
# This script automates the initial setup process

set -e  # Exit on error

echo "================================================"
echo "  SLA Monitoring Portal - Quick Start Setup"
echo "================================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check Python version
echo -e "${BLUE}Checking Python version...${NC}"
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Found Python $PYTHON_VERSION"

if ! python3 -c 'import sys; assert sys.version_info >= (3,8)' 2>/dev/null; then
    echo -e "${RED}Error: Python 3.8 or higher is required${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Python version check passed${NC}"
echo ""

# Step 1: Initialize Database
echo -e "${BLUE}Step 1: Initializing database...${NC}"
cd database
python3 init_db.py
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Database initialized successfully${NC}"
else
    echo -e "${RED}✗ Database initialization failed${NC}"
    exit 1
fi
cd ..
echo ""

# Step 2: Install Python Dependencies
echo -e "${BLUE}Step 2: Installing Python dependencies...${NC}"
echo "This may take a few minutes..."

# Check if virtual environment should be used
if command -v virtualenv &> /dev/null || command -v venv &> /dev/null; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    source venv/bin/activate
    echo -e "${GREEN}✓ Virtual environment created${NC}"
fi

pip install flask flask-cors --quiet --break-system-packages 2>/dev/null || pip install flask flask-cors --quiet

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependencies installed successfully${NC}"
else
    echo -e "${RED}✗ Dependency installation failed${NC}"
    echo "Try running: pip install -r requirements.txt --break-system-packages"
    exit 1
fi
echo ""

# Step 3: Create logs directory
echo -e "${BLUE}Step 3: Setting up directories...${NC}"
mkdir -p backend/logs
mkdir -p backups
echo -e "${GREEN}✓ Directories created${NC}"
echo ""

# Step 4: Create default .env file if it doesn't exist
if [ ! -f backend/.env ]; then
    echo -e "${BLUE}Step 4: Creating default configuration...${NC}"
    cat > backend/.env << EOF
# Database
DATABASE_PATH=../database/sla_portal.db

# API Configuration
API_HOST=0.0.0.0
API_PORT=5000
API_DEBUG=True
SECRET_KEY=dev-secret-key-change-in-production

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:5000,http://localhost:8080

# Logging
LOG_LEVEL=INFO
EOF
    echo -e "${GREEN}✓ Configuration file created${NC}"
else
    echo -e "${BLUE}Step 4: Configuration file already exists${NC}"
fi
echo ""

# Step 5: Start the server
echo -e "${BLUE}Step 5: Starting API server...${NC}"
echo ""
echo "================================================"
echo -e "${GREEN}Setup complete!${NC}"
echo "================================================"
echo ""
echo "Default login credentials:"
echo "  Email: admin@demo.com"
echo "  Password: admin123"
echo ""
echo "Starting server on http://localhost:5000..."
echo ""
echo "To access the frontend:"
echo "  1. Open sla-monitoring-portal.html in your browser"
echo "  2. Or run: python3 -m http.server 8080"
echo ""
echo "Press Ctrl+C to stop the server"
echo "================================================"
echo ""

# Start the API server
cd backend
python3 api_service.py
