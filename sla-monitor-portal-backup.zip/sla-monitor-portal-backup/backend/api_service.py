"""
Main API Service
Flask REST API that orchestrates all microservices
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import uuid
import json
import hashlib
from datetime import datetime, timedelta
from functools import wraps
import logging

from database_service import DatabaseService
from sla_evaluation_engine import SLAEvaluationEngine
from alerting_service import AlertingService
from health_monitoring_service import HealthMonitoringService
from alert_generation_service import AlertGenerationService
from job_monitoring_service import get_job_monitoring_service

# Initialize Flask app
app = Flask(__name__)
# Enable CORS for React frontend with explicit configuration
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:3000", "http://localhost:3001", "http://localhost:3010"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "supports_credentials": True
    }
})

# Initialize services
db_service = DatabaseService('../database/sla_portal.db')
sla_engine = SLAEvaluationEngine(db_service)
alert_service = AlertingService(db_service)
alert_generator = AlertGenerationService(db_service)
health_monitor = HealthMonitoringService(db_service, check_interval=60)  # Check every 60 seconds
job_monitor = get_job_monitoring_service(db_service)  # Job monitoring service (every 30 minutes)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ===== AUTHENTICATION & AUTHORIZATION =====

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Allow OPTIONS requests without authentication (CORS preflight)
        if request.method == 'OPTIONS':
            # Return an empty successful response for CORS preflight
            return ('', 200)
        
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'error': 'No authorization token provided'}), 401
        
        # Remove 'Bearer ' prefix if present
        if token.startswith('Bearer '):
            token = token[7:]
        
        # Validate token
        with db_service.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM sessions WHERE token = ? AND expires_at > ?",
                (token, datetime.now().isoformat())
            )
            session = cursor.fetchone()
        
        if not session:
            return jsonify({'error': 'Invalid or expired token'}), 401
        
        # Add user info to request
        request.user_id = dict(session)['user_id']
        return f(*args, **kwargs)
    
    return decorated_function

def get_user_org():
    """Get organization ID for current user"""
    # Get user_id from request context (set in require_auth decorator)
    user_id = getattr(request, 'user_id', None)
    if not user_id:
        return None
    
    # Query user by user_id to get their org_id
    with db_service.get_connection() as conn:
        cursor = conn.execute(
            "SELECT org_id FROM users WHERE user_id = ?", 
            (user_id,)
        )
        row = cursor.fetchone()
        return row['org_id'] if row else None

# ===== AUTHENTICATION ENDPOINTS =====

@app.route('/api/v1/auth/login', methods=['POST'])
def login():
    """Login endpoint"""
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({'error': 'Email and password required'}), 400
    
    # Get user
    user = db_service.get_user_by_email(email)
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Verify password
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    if user['password_hash'] != password_hash:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Create session
    session_id = f"sess-{uuid.uuid4().hex}"
    token = uuid.uuid4().hex
    expires_at = (datetime.now() + timedelta(days=7)).isoformat()
    
    with db_service.get_connection() as conn:
        conn.execute("""
            INSERT INTO sessions (session_id, user_id, token, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (session_id, user['user_id'], token, expires_at,
              request.remote_addr, request.headers.get('User-Agent')))
    
    logger.info(f"User {email} logged in")
    
    return jsonify({
        'token': token,
        'user': {
            'user_id': user['user_id'],
            'email': user['email'],
            'username': user['username'],
            'role': user['role'],
            'org_id': user['org_id']
        },
        'expires_at': expires_at
    })

@app.route('/api/v1/auth/logout', methods=['POST'])
@require_auth
def logout():
    """Logout endpoint"""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    
    with db_service.get_connection() as conn:
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
    
    return jsonify({'message': 'Logged out successfully'})

# ===== EVENT INGESTION ENDPOINTS =====

@app.route('/api/v1/events', methods=['POST'])
@require_auth
def ingest_event():
    """Ingest event and trigger SLA evaluation"""
    data = request.json
    
    # Validate required fields
    required_fields = ['service_id', 'timestamp', 'event_type']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Create event
    event_id = f"evt-{uuid.uuid4().hex[:12]}"
    event_data = {
        'event_id': event_id,
        'org_id': get_user_org(),
        'service_id': data['service_id'],
        'customer_id': data.get('customer_id'),
        'timestamp': data['timestamp'],
        'event_type': data['event_type'],
        'status': data.get('status'),
        'priority': data.get('priority'),
        'duration': data.get('duration'),
        'source': data.get('source', 'api'),
        'payload': data.get('attributes', {}),
        'normalized_data': data
    }
    
    try:
        db_service.create_event(event_data)
        
        # Trigger SLA evaluation
        evaluations = sla_engine.process_event(event_data)
        
        # Process any new alerts
        for evaluation in evaluations:
            if evaluation.get('is_breach'):
                # Find associated alert and process it
                alerts = db_service.get_alerts(event_data['org_id'], status='pending')
                for alert in alerts:
                    if alert['evaluation_id'] == evaluation.get('evaluation_id'):
                        alert_service.process_alert(alert['alert_id'])
        
        logger.info(f"Event {event_id} ingested and processed")
        
        return jsonify({
            'event_id': event_id,
            'evaluations': len(evaluations),
            'message': 'Event ingested successfully'
        }), 201
    
    except Exception as e:
        logger.error(f"Error ingesting event: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/events', methods=['GET'])
@require_auth
def get_events():
    """Get events with filters"""
    org_id = get_user_org()
    
    filters = {}
    if request.args.get('service_id'):
        filters['service_id'] = request.args.get('service_id')
    if request.args.get('event_type'):
        filters['event_type'] = request.args.get('event_type')
    if request.args.get('start_date'):
        filters['start_date'] = request.args.get('start_date')
    if request.args.get('end_date'):
        filters['end_date'] = request.args.get('end_date')
    
    limit = int(request.args.get('limit', 100))
    offset = int(request.args.get('offset', 0))
    
    events = db_service.get_events(org_id, filters, limit, offset)
    
    return jsonify({
        'events': events,
        'count': len(events),
        'limit': limit,
        'offset': offset
    })

# ===== SERVICE ENDPOINTS =====

@app.route('/api/v1/services', methods=['GET', 'OPTIONS'])
@require_auth
def get_services():
    """Get all services with health status"""
    if request.method == 'OPTIONS':
        return '', 200
    
    org_id = get_user_org()
    customer_id = request.args.get('customer_id')
    
    # Get services with health status
    if customer_id:
        services = db_service.get_services_by_org(org_id, customer_id)
    else:
        services = db_service.get_services_with_health(org_id)
    
    return jsonify({
        'data': services,  # Changed from 'services' to 'data' for consistency
        'count': len(services)
    })

@app.route('/api/v1/services/<service_id>', methods=['GET', 'PUT', 'DELETE'])
@require_auth
def handle_service(service_id):
    """Handle service operations by ID"""
    
    if request.method == 'GET':
        # Get service by ID with health status
        service = db_service.get_service(service_id)
        
        if not service:
            return jsonify({'error': 'Service not found'}), 404
        
        # Get health status
        health = db_service.get_service_health(service_id)
        if health:
            service['health_status'] = health['status']
            service['health_message'] = health['message']
            service['health_checked_at'] = health['checked_at']
            service['response_time'] = health.get('response_time')
        
        return jsonify(service)
    
    elif request.method == 'PUT':
        # Update service
        data = request.json
        
        try:
            # Update service
            updates = {}
            if 'name' in data:
                updates['name'] = data['name']
            if 'description' in data:
                updates['description'] = data['description']
            if 'owner_team' in data:
                updates['owner_team'] = data['owner_team']
            if 'is_active' in data:
                updates['is_active'] = data['is_active']
            if 'monitoring_method' in data:
                updates['monitoring_method'] = data['monitoring_method']
            if 'deployment_location' in data:
                updates['deployment_location'] = data['deployment_location']
            if 'execution_time' in data:
                updates['execution_time'] = data['execution_time']
            if 'metadata' in data:
                updates['metadata'] = data['metadata']
            if 'tags' in data:
                updates['tags'] = data['tags']
            
            with db_service.get_connection() as conn:
                # Build update query
                set_clauses = ', '.join([f"{k} = ?" for k in updates.keys()])
                values = list(updates.values())
                values.append(service_id)
                
                conn.execute(
                    f"UPDATE services SET {set_clauses} WHERE service_id = ?",
                    values
                )
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            org_id = get_user_org()
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': org_id,
                'user_id': request.user_id,
                'action': 'update_service',
                'resource_type': 'service',
                'resource_id': service_id,
                'ip_address': request.remote_addr,
                'changes': json.dumps(data),
                'metadata': json.dumps({'service_id': service_id})
            })
            
            return jsonify({'message': 'Service updated successfully'}), 200
        except Exception as e:
            logger.error(f"Error updating service: {e}")
            return jsonify({'error': str(e)}), 500
    
    elif request.method == 'DELETE':
        # Delete service
        try:
            with db_service.get_connection() as conn:
                # Check if service exists
                cursor = conn.execute(
                    "SELECT service_id FROM services WHERE service_id = ?",
                    (service_id,)
                )
                if not cursor.fetchone():
                    return jsonify({'error': 'Service not found'}), 404
                
                # Delete service (cascading will handle related records)
                conn.execute(
                    "DELETE FROM services WHERE service_id = ?",
                    (service_id,)
                )
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            org_id = get_user_org()
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': org_id,
                'user_id': request.user_id,
                'action': 'delete_service',
                'resource_type': 'service',
                'resource_id': service_id,
                'ip_address': request.remote_addr,
                'changes': json.dumps({}),
                'metadata': json.dumps({'service_id': service_id})
            })
            
            return jsonify({'message': 'Service deleted successfully'}), 200
        except Exception as e:
            logger.error(f"Error deleting service: {e}")
            return jsonify({'error': str(e)}), 500

@app.route('/api/v1/services', methods=['POST'])
@require_auth
def create_service():
    """Create new service"""
    data = request.json
    
    service_id = f"svc-{uuid.uuid4().hex[:8]}"
    service_data = {
        'service_id': service_id,
        'org_id': get_user_org(),
        'customer_id': data.get('customer_id'),
        'name': data['name'],
        'description': data.get('description'),
        'owner_team': data.get('owner_team'),
        'asset_id': data.get('asset_id'),  # Asset linking
        'monitoring_method': data.get('monitoring_method', 'direct'),  # Monitoring method
        'deployment_location': data.get('deployment_location'),  # Deployment location
        'execution_time': data.get('execution_time'),  # Execution time for ETL jobs
        'tags': data.get('tags', []),
        'metadata': data.get('metadata', {})  # Metadata for additional config
    }
    
    try:
        db_service.create_service(service_data)
        
        # Create audit log
        log_id = f"log-{uuid.uuid4().hex[:12]}"
        db_service.create_audit_log({
            'log_id': log_id,
            'org_id': service_data['org_id'],
            'user_id': request.user_id,
            'action': 'create_service',
            'resource_type': 'service',
            'resource_id': service_id,
            'ip_address': request.remote_addr,
            'metadata': {
                'name': data['name'], 
                'monitoring_method': service_data['monitoring_method'],
                'deployment_location': service_data.get('deployment_location'),
                'execution_time': service_data.get('execution_time')
            }
        })
        
        return jsonify({
            'service_id': service_id,
            'message': 'Service created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===== SLA ENDPOINTS =====

@app.route('/api/v1/services/<service_id>/slas', methods=['GET'])
@require_auth
def get_service_slas(service_id):
    """Get SLAs for a service (including both active and inactive)"""
    # Get all SLAs (active and inactive) for the service detail page
    slas = db_service.get_slas_by_service(service_id, active_only=False)
    
    return jsonify({
        'data': slas,  # Changed from 'slas' to 'data' to match frontend expectation
        'count': len(slas)
    })

@app.route('/api/v1/slas', methods=['GET', 'POST'])
@require_auth
def handle_slas():
    """Handle SLA operations"""
    try:
        if request.method == 'GET':
            # Get all SLAs for organization
            org_id = get_user_org()
            service_id = request.args.get('service_id')
            
            if service_id:
                # Get SLAs for specific service (including inactive)
                slas = db_service.get_slas_by_service(service_id, active_only=False)
            else:
                # Get all SLAs for organization
                slas = db_service.get_slas_by_org(org_id)
            
            return jsonify({
                'data': slas,
                'count': len(slas)
            })
        
        elif request.method == 'POST':
            # Create new SLA
            data = request.json
            
            sla_id = f"sla-{uuid.uuid4().hex[:8]}"
            
            # Handle both camelCase (from frontend) and snake_case field names
            start_condition = data.get('start_condition') or data.get('startCondition')
            stop_condition = data.get('stop_condition') or data.get('stopCondition')
            business_hours_id = data.get('business_hours_id') or data.get('businessHoursId')
            escalation_policy_id = data.get('escalation_policy_id') or data.get('escalationPolicyId')
            effective_from = data.get('effective_from') or data.get('effectiveFrom', datetime.now().isoformat())
            effective_until = data.get('effective_until') or data.get('effectiveUntil')
            
            # Collect metadata from various fields
            metadata = data.get('metadata', {})
            if 'thresholds' in data:
                metadata['thresholds'] = data['thresholds']
            if 'escalationSteps' in data:
                metadata['escalationSteps'] = data['escalationSteps']
            if 'penalties' in data:
                metadata['penalties'] = data['penalties']
            if 'incentives' in data:
                metadata['incentives'] = data['incentives']
            if 'pauseCondition' in data:
                metadata['pauseCondition'] = data['pauseCondition']
            if 'customCalendar' in data:
                metadata['customCalendar'] = data['customCalendar']
            
            sla_data = {
                'sla_id': sla_id,
                'org_id': get_user_org(),
                'service_id': data['service_id'],
                'customer_id': data.get('customer_id'),
                'name': data['name'],
                'metric_type': data['metric_type'],
                'target_value': data['target_value'],
                'target_unit': data['target_unit'],
                'priority': data.get('priority'),
                'business_hours_id': business_hours_id,
                'escalation_policy_id': escalation_policy_id,
                'start_condition': start_condition,
                'stop_condition': stop_condition,
                'effective_from': effective_from,
                'effective_until': effective_until,
                'created_by': request.user_id,
                'metadata': metadata
            }
            
            db_service.create_sla(sla_data)
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': sla_data['org_id'],
                'user_id': request.user_id,
                'action': 'create_sla',
                'resource_type': 'sla',
                'resource_id': sla_id,
                'ip_address': request.remote_addr,
                'metadata': {'name': data['name']}
            })
            
            return jsonify({
                'sla_id': sla_id,
                'message': 'SLA created successfully'
            }), 201
    
    except Exception as e:
        logger.error(f"Error in handle_slas: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/slas/<sla_id>', methods=['GET', 'PUT', 'DELETE'])
@require_auth
def handle_sla_detail(sla_id):
    """Handle individual SLA operations"""
    try:
        if request.method == 'GET':
            # Get SLA by ID
            sla = db_service.get_sla(sla_id)
            
            if not sla:
                return jsonify({'error': 'SLA not found'}), 404
            
            return jsonify(sla)
        
        elif request.method == 'PUT':
            # Update SLA
            data = request.json
            
            # Check if SLA exists
            sla = db_service.get_sla(sla_id)
            if not sla:
                return jsonify({'error': 'SLA not found'}), 404
            
            # Prepare update data
            update_data = {}
            
            # Fields that can be updated
            updatable_fields = [
                'name', 'description', 'metric_type', 'target_value', 'target_unit',
                'priority', 'business_hours_id', 'escalation_policy_id',
                'start_condition', 'stop_condition', 'effective_from', 'effective_until',
                'metadata', 'is_active'
            ]
            
            for field in updatable_fields:
                if field in data:
                    update_data[field] = data[field]
            
            # Update the SLA
            db_service.update_sla(sla_id, update_data)
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': sla['org_id'],
                'user_id': request.user_id,
                'action': 'update_sla',
                'resource_type': 'sla',
                'resource_id': sla_id,
                'ip_address': request.remote_addr,
                'metadata': {'updated_fields': list(update_data.keys())}
            })
            
            return jsonify({'message': 'SLA updated successfully'})
        
        elif request.method == 'DELETE':
            # Deactivate SLA (soft delete)
            logger.info(f"DELETE request for SLA: {sla_id}")
            
            # Step 1: Get SLA
            logger.info(f"Step 1: Fetching SLA {sla_id}")
            sla = db_service.get_sla(sla_id)
            logger.info(f"Step 1 complete: SLA found = {sla is not None}")
            
            if not sla:
                logger.warning(f"SLA not found: {sla_id}")
                return jsonify({'error': 'SLA not found'}), 404
            
            # Step 2: Update SLA
            logger.info(f"Step 2: Deactivating SLA {sla_id}")
            db_service.update_sla(sla_id, {'is_active': 0})
            logger.info(f"Step 2 complete: SLA deactivated")
            
            # Step 3: Create audit log
            logger.info(f"Step 3: Creating audit log")
            try:
                log_id = f"log-{uuid.uuid4().hex[:12]}"
                db_service.create_audit_log({
                    'log_id': log_id,
                    'org_id': sla['org_id'],
                    'user_id': request.user_id,
                    'action': 'deactivate_sla',
                    'resource_type': 'sla',
                    'resource_id': sla_id,
                    'ip_address': request.remote_addr,
                    'metadata': {'name': sla.get('name', 'Unknown')}
                })
                logger.info(f"Step 3 complete: Audit log created")
            except Exception as audit_error:
                logger.warning(f"Step 3 failed (non-critical): {audit_error}")
                # Continue anyway - deactivation succeeded
            
            logger.info(f"DELETE request successful for SLA: {sla_id}")
            return jsonify({'message': 'SLA deactivated successfully'})
    
    except Exception as e:
        error_msg = f"Error in handle_sla_detail for {sla_id}: {str(e)}"
        logger.error(error_msg)
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': str(e),
            'details': error_msg,
            'sla_id': sla_id,
            'method': request.method
        }), 500

@app.route('/api/v1/slas/<sla_id>/hard', methods=['DELETE'])
@require_auth
def hard_delete_sla(sla_id):
    """Permanently delete SLA (hard delete)"""
    try:
        logger.info(f"HARD DELETE request for SLA: {sla_id}")
        
        # Get SLA first to check if it exists and for audit log
        sla = db_service.get_sla(sla_id)
        
        if not sla:
            logger.warning(f"SLA not found for hard delete: {sla_id}")
            return jsonify({'error': 'SLA not found'}), 404
        
        # Create audit log before deletion
        try:
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': sla['org_id'],
                'user_id': request.user_id,
                'action': 'hard_delete_sla',
                'resource_type': 'sla',
                'resource_id': sla_id,
                'ip_address': request.remote_addr,
                'metadata': {
                    'name': sla.get('name', 'Unknown'),
                    'service_id': sla.get('service_id'),
                    'warning': 'PERMANENT DELETION - Data cannot be recovered'
                }
            })
        except Exception as audit_error:
            logger.warning(f"Failed to create audit log for hard delete: {audit_error}")
        
        # Permanently delete from database
        db_service.hard_delete_sla(sla_id)
        
        logger.info(f"HARD DELETE successful for SLA: {sla_id}")
        return jsonify({'message': 'SLA permanently deleted'})
    
    except Exception as e:
        error_msg = f"Error in hard_delete_sla for {sla_id}: {str(e)}"
        logger.error(error_msg)
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': str(e),
            'details': error_msg,
            'sla_id': sla_id
        }), 500

# ===== EVALUATION & REPORTING ENDPOINTS =====

@app.route('/api/v1/reports/sla-compliance', methods=['GET'])
@require_auth
def get_sla_compliance():
    """Get SLA compliance report"""
    org_id = get_user_org()
    service_id = request.args.get('service_id')
    period = request.args.get('period', '30d')
    
    # Parse period
    period_days = int(period.replace('d', ''))
    
    # Get compliance summary
    compliance = db_service.get_sla_compliance_summary(org_id, service_id)
    
    # Get evaluations for the period
    period_start = (datetime.now() - timedelta(days=period_days)).isoformat()
    evaluations = db_service.get_evaluations(org_id, filters={
        'service_id': service_id
    } if service_id else None)
    
    # Filter by period
    period_evaluations = [
        e for e in evaluations
        if e['start_timestamp'] >= period_start
    ]
    
    total_evaluations = len(period_evaluations)
    breaches = [e for e in period_evaluations if e['is_breach']]
    compliance_rate = ((total_evaluations - len(breaches)) / total_evaluations * 100) if total_evaluations > 0 else 100
    
    return jsonify({
        'period': period,
        'total_evaluations': total_evaluations,
        'breaches': len(breaches),
        'compliance_percentage': round(compliance_rate, 2),
        'summary': compliance,
        'breach_details': breaches[:10]  # Top 10 breaches
    })

@app.route('/api/v1/dashboard/metrics', methods=['GET'])
@require_auth
def get_dashboard_metrics():
    """Get dashboard metrics and generate alerts for breaches"""
    org_id = get_user_org()
    period_days = int(request.args.get('period_days', 30))
    
    # Generate alerts for any SLA breaches
    try:
        alert_generator.check_and_create_alerts(org_id)
    except Exception as e:
        logger.error(f"Error generating alerts: {e}")
    
    metrics = db_service.get_dashboard_metrics(org_id, period_days)
    
    return jsonify(metrics)

# ===== ALERT ENDPOINTS =====

@app.route('/api/v1/alerts', methods=['GET', 'OPTIONS'])
@require_auth
def get_alerts():
    """Get alerts"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        status = request.args.get('status')
        limit = request.args.get('limit')
        
        alerts = db_service.get_alerts(org_id, status)
        
        # Apply limit if provided
        if limit:
            try:
                limit_int = int(limit)
                alerts = alerts[:limit_int]
            except ValueError:
                pass
        
        return jsonify({
            'alerts': alerts,
            'count': len(alerts)
        })
    except Exception as e:
        logger.error(f"Error getting alerts: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to get alerts: {str(e)}'}), 500

@app.route('/api/v1/alerts/<alert_id>/acknowledge', methods=['POST'])
@require_auth
def acknowledge_alert(alert_id):
    """Acknowledge an alert"""
    result = alert_service.acknowledge_alert(alert_id, request.user_id)
    
    return jsonify(result)

# ===== WEBHOOK ENDPOINTS =====

@app.route('/api/v1/webhooks/datadog', methods=['POST'])
def webhook_datadog():
    """Receive webhook from Datadog"""
    data = request.json
    
    # Transform Datadog payload to our event format
    # This is a simplified example
    event_data = {
        'service_id': data.get('tags', {}).get('service', 'unknown'),
        'timestamp': datetime.now().isoformat(),
        'event_type': 'incident.created' if data.get('event_type') == 'triggered' else 'incident.resolved',
        'priority': 'P1' if data.get('priority') == 'high' else 'P2',
        'source': 'datadog',
        'attributes': data
    }
    
    logger.info(f"Received Datadog webhook: {data.get('id')}")
    
    return jsonify({'message': 'Webhook received'}), 200

@app.route('/api/v1/webhooks/slack', methods=['POST'])
def webhook_slack():
    """Receive webhook from Slack"""
    data = request.json
    
    logger.info(f"Received Slack webhook")
    
    return jsonify({'message': 'Webhook received'}), 200

# ===== HEALTH & INFO ENDPOINTS =====

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/v1/info', methods=['GET'])
def info():
    """API info endpoint"""
    return jsonify({
        'name': 'SLA Monitoring Portal API',
        'version': '1.0.0',
        'description': 'REST API for SLA monitoring and management'
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500


# ===== SERVICE MANAGEMENT ENDPOINTS =====

@app.route('/api/v1/services/test-connection', methods=['POST'])
@require_auth
def test_service_connection():
    """Test service connection"""
    data = request.json
    service_type = data.get('type')
    config = data.get('config', {})
    
    try:
        # Test connection based on service type
        
        if service_type in ['mysql', 'aurora']:
            # MySQL/Aurora connection test - REAL CONNECTION
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import pymysql
                
                # Attempt real connection
                connection = pymysql.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                # Execute test query
                with connection.cursor() as cursor:
                    cursor.execute("SELECT VERSION()")
                    version = cursor.fetchone()[0]
                
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to {service_type} database: {database} (MySQL {version})'
                }), 200
                
            except ImportError:
                # pymysql not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': f'Configuration validated for {service_type} (real connection testing unavailable - install pymysql)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except pymysql.err.OperationalError as e:
                error_msg = str(e)
                if 'Access denied' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif "Can't connect" in error_msg or 'Connection refused' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to {service_type} server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {error_msg}'
                    }), 200
                    
            except pymysql.err.ProgrammingError as e:
                error_msg = str(e)
                if 'Unknown database' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" does not exist on {host}:{port}'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Database error: {error_msg}'
                    }), 200
                    
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection test failed: {str(e)}'
                }), 200
        
        elif service_type == 'postgresql':
            # PostgreSQL connection test - REAL CONNECTION
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import psycopg2
                
                # Attempt real connection
                connection = psycopg2.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                # Execute test query
                cursor = connection.cursor()
                cursor.execute("SELECT version()")
                version = cursor.fetchone()[0]
                cursor.close()
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to PostgreSQL database: {database}'
                }), 200
                
            except ImportError:
                # psycopg2 not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for PostgreSQL (real connection testing unavailable - install psycopg2)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except psycopg2.OperationalError as e:
                error_msg = str(e)
                if 'authentication failed' in error_msg.lower():
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'does not exist' in error_msg and 'database' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" does not exist'
                    }), 200
                elif 'could not connect' in error_msg.lower() or 'connection refused' in error_msg.lower():
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to PostgreSQL server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {error_msg}'
                    }), 200
                    
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection test failed: {str(e)}'
                }), 200
        
        elif service_type == 'mongodb':
            # MongoDB connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database'
                }), 400
            
            try:
                from pymongo import MongoClient
                from pymongo.errors import ConnectionFailure, OperationFailure, ServerSelectionTimeoutError
                
                # Build connection string
                if username and password:
                    conn_string = f"mongodb://{username}:{password}@{host}:{port}/{database}"
                else:
                    conn_string = f"mongodb://{host}:{port}/{database}"
                
                # Attempt real connection
                client = MongoClient(conn_string, serverSelectionTimeoutMS=5000)
                
                # Test connection
                client.admin.command('ping')
                
                # Get server info
                server_info = client.server_info()
                version = server_info.get('version', 'unknown')
                
                client.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to MongoDB database: {database} (MongoDB {version})'
                }), 200
                
            except ImportError:
                # pymongo not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for MongoDB (real connection testing unavailable - install pymongo)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except OperationFailure as e:
                return jsonify({
                    'success': False,
                    'message': 'Authentication failed: Wrong username or password'
                }), 200
                
            except (ConnectionFailure, ServerSelectionTimeoutError) as e:
                return jsonify({
                    'success': False,
                    'message': f'Cannot connect to MongoDB server at {host}:{port}. Is the server running?'
                }), 200
                
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection test failed: {str(e)}'
                }), 200
        
        elif service_type == 'oracle':
            # Oracle Database connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            service_name = config.get('service_name')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, service_name, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, service_name, username, password'
                }), 400
            
            try:
                import cx_Oracle
                
                # Build connection string (format: username/password@host:port/service_name)
                dsn = cx_Oracle.makedsn(host, int(port), service_name=service_name)
                
                # Attempt real connection
                connection = cx_Oracle.connect(
                    user=username,
                    password=password,
                    dsn=dsn,
                    encoding="UTF-8"
                )
                
                # Execute test query
                cursor = connection.cursor()
                cursor.execute("SELECT BANNER FROM v$version WHERE ROWNUM = 1")
                version = cursor.fetchone()[0]
                cursor.close()
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to Oracle database: {service_name}'
                }), 200
                
            except ImportError:
                # cx_Oracle not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for Oracle (real connection testing unavailable - install cx_Oracle)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except Exception as e:
                error_msg = str(e).lower()
                if 'invalid username/password' in error_msg or 'ora-01017' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'ora-12541' in error_msg or 'no listener' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to Oracle server at {host}:{port}. Is the listener running?'
                    }), 200
                elif 'ora-12514' in error_msg or 'could not resolve' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Service name "{service_name}" not found. Check TNS configuration.'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {str(e)}'
                    }), 200
        
        elif service_type == 'mssql':
            # Microsoft SQL Server connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import pymssql
                
                # Attempt real connection
                connection = pymssql.connect(
                    server=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    timeout=5,
                    login_timeout=5
                )
                
                # Execute test query
                cursor = connection.cursor()
                cursor.execute("SELECT @@VERSION")
                version_info = cursor.fetchone()[0]
                # Extract version number
                version = version_info.split('\n')[0] if version_info else 'SQL Server'
                cursor.close()
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to SQL Server database: {database}'
                }), 200
                
            except ImportError:
                # pymssql not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for SQL Server (real connection testing unavailable - install pymssql)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except Exception as e:
                error_msg = str(e).lower()
                if 'login failed' in error_msg or '18456' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'cannot open database' in error_msg or '4060' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" does not exist or access denied'
                    }), 200
                elif 'connection refused' in error_msg or 'timed out' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to SQL Server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {str(e)}'
                    }), 200
        
        elif service_type == 'db2':
            # IBM DB2 connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import ibm_db
                
                # Build connection string
                conn_string = (
                    f"DATABASE={database};"
                    f"HOSTNAME={host};"
                    f"PORT={port};"
                    f"PROTOCOL=TCPIP;"
                    f"UID={username};"
                    f"PWD={password};"
                )
                
                # Attempt real connection
                connection = ibm_db.connect(conn_string, "", "")
                
                # Execute test query
                stmt = ibm_db.exec_immediate(connection, "SELECT SERVICE_LEVEL FROM SYSIBMADM.ENV_INST_INFO")
                result = ibm_db.fetch_tuple(stmt)
                version = result[0] if result else 'DB2'
                
                ibm_db.close(connection)
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to IBM DB2 database: {database}'
                }), 200
                
            except ImportError:
                # ibm_db not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for IBM DB2 (real connection testing unavailable - install ibm_db)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except Exception as e:
                error_msg = str(e).lower()
                if 'authorization failure' in error_msg or 'sql30082n' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'database not found' in error_msg or 'sql1013n' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" not found or not cataloged'
                    }), 200
                elif 'communication error' in error_msg or 'sql30081n' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to DB2 server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {str(e)}'
                    }), 200
            
        elif service_type in ['api_gateway', 'microservice', 'nginx', 'apache', 'esb']:
            # HTTP endpoint test - ACTUAL HTTP REQUEST
            url = config.get('url')
            health_endpoint = config.get('health_endpoint') or config.get('status_endpoint')
            
            if not url:
                return jsonify({
                    'success': False,
                    'message': 'Missing required field: url'
                }), 400
            
            # Validate that health_endpoint is just a path, not a full URL
            if health_endpoint and ('http://' in health_endpoint or 'https://' in health_endpoint):
                return jsonify({
                    'success': False,
                    'message': 'Health/Status Endpoint should be just a path (e.g., /health), not a full URL. Please enter only the path in the endpoint field.'
                }), 400
            
            # Perform actual HTTP request
            import requests
            try:
                # Construct full URL
                test_url = url
                endpoint_used = "base URL"
                
                if health_endpoint:
                    # Add health endpoint path
                    if not url.endswith('/'):
                        test_url += '/'
                    if health_endpoint.startswith('/'):
                        health_endpoint = health_endpoint[1:]
                    test_url += health_endpoint
                    endpoint_used = health_endpoint
                
                # Make HTTP request with timeout
                logger.info(f"Testing connection to: {test_url}")
                response = requests.get(test_url, timeout=5, verify=False)
                
                logger.info(f"Response status code: {response.status_code}")
                
                if response.status_code in [200, 201, 204]:
                    return jsonify({
                        'success': True,
                        'message': f'Successfully connected to {test_url} (Status: {response.status_code})'
                    }), 200
                elif response.status_code in [301, 302, 307, 308]:
                    # Redirect - could be success or not, treat as success with warning
                    return jsonify({
                        'success': True,
                        'message': f'Connected to {test_url} (Redirect {response.status_code}). Check endpoint configuration.'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection failed: {test_url} returned HTTP {response.status_code}'
                    }), 200
                    
            except requests.exceptions.Timeout:
                return jsonify({
                    'success': False,
                    'message': f'Connection timeout after 5 seconds'
                }), 200
            except requests.exceptions.ConnectionError:
                return jsonify({
                    'success': False,
                    'message': f'Connection refused or host unreachable'
                }), 200
            except requests.exceptions.RequestException as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection error: {str(e)}'
                }), 200
            
        elif service_type in ['snowflake', 'bigquery']:
            # Cloud data warehouse validation
            if service_type == 'snowflake':
                account = config.get('account')
                warehouse = config.get('warehouse')
                if not account or not warehouse:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: account and warehouse'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for Snowflake account: {account}'
                }), 200
                
            elif service_type == 'bigquery':
                project_id = config.get('project_id')
                dataset = config.get('dataset')
                if not project_id or not dataset:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: project_id and dataset'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for BigQuery project: {project_id}'
                }), 200
            
        elif service_type in ['etl_batch', 'spark_streaming', 'flink']:
            # Data processing jobs - validate endpoint if provided
            endpoint = config.get('endpoint') or config.get('master_url') or config.get('jobmanager_url')
            
            if endpoint:
                # Try to connect to monitoring endpoint
                import requests
                try:
                    response = requests.get(endpoint, timeout=5, verify=False)
                    if response.status_code in [200, 201, 204]:
                        return jsonify({
                            'success': True,
                            'message': f'Successfully connected to {service_type} at {endpoint}'
                        }), 200
                    else:
                        return jsonify({
                            'success': False,
                            'message': f'Endpoint returned HTTP {response.status_code}'
                        }), 200
                except Exception as e:
                    return jsonify({
                        'success': False,
                        'message': f'Connection failed: {str(e)}'
                    }), 200
            else:
                # Just validate configuration
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for {service_type}'
                }), 200
            
        elif service_type in ['kafka', 'rabbitmq', 'ibm_mq', 'aws_sqs']:
            # Messaging systems - validate configuration
            if service_type == 'kafka':
                servers = config.get('bootstrap_servers')
                if not servers:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required field: bootstrap_servers'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for Kafka: {servers}'
                }), 200
                
            elif service_type == 'rabbitmq':
                host = config.get('host')
                port = config.get('port')
                if not host or not port:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: host and port'
                    }), 400
                    
                # Try to connect to RabbitMQ management API
                import requests
                try:
                    mgmt_url = f"http://{host}:{port}/api/overview"
                    response = requests.get(mgmt_url, timeout=5, verify=False)
                    if response.status_code in [200, 401]:  # 401 means it's there but needs auth
                        return jsonify({
                            'success': True,
                            'message': f'Successfully found RabbitMQ at {host}:{port}'
                        }), 200
                except:
                    # Management API not accessible, just validate config
                    return jsonify({
                        'success': True,
                        'message': f'Configuration validated for RabbitMQ: {host}:{port}'
                    }), 200
                    
            elif service_type == 'ibm_mq':
                host = config.get('host')
                port = config.get('port')
                queue_manager = config.get('queue_manager')
                if not all([host, port, queue_manager]):
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: host, port, queue_manager'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for IBM MQ: {host}:{port}/{queue_manager}'
                }), 200
                
            elif service_type == 'aws_sqs':
                queue_url = config.get('queue_url')
                region = config.get('region')
                if not queue_url or not region:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: queue_url and region'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for AWS SQS: {queue_url}'
                }), 200
            
        else:
            return jsonify({
                'success': True,
                'message': f'Configuration validated for {service_type}'
            }), 200
            
    except Exception as e:
        logger.error(f"Connection test error: {e}")
        return jsonify({
            'success': False,
            'message': f'Connection test failed: {str(e)}'
        }), 500

# ===== ASSETS API ENDPOINTS =====

@app.route('/api/v1/assets', methods=['GET', 'POST', 'OPTIONS'])
@require_auth
def handle_assets():
    """Handle asset operations"""
    try:
        if request.method == 'GET':
            # Get all assets for organization
            org_id = get_user_org()
            
            # Get query parameters
            status = request.args.get('status')  # Filter by status
            asset_type = request.args.get('asset_type')  # Filter by type
            search = request.args.get('search')  # Search in name
            
            # Build query
            query = "SELECT * FROM assets WHERE org_id = ?"
            params = [org_id]
            
            if status:
                query += " AND status = ?"
                params.append(status)
            
            if asset_type:
                query += " AND asset_type = ?"
                params.append(asset_type)
            
            if search:
                query += " AND asset_name LIKE ?"
                params.append(f"%{search}%")
            
            query += " ORDER BY created_at DESC"
            
            with db_service.get_connection() as conn:
                cursor = conn.execute(query, params)
                assets = [dict(row) for row in cursor.fetchall()]
            
            # Get service count for each asset
            for asset in assets:
                with db_service.get_connection() as conn:
                    cursor = conn.execute(
                        "SELECT COUNT(*) as count FROM services WHERE asset_id = ?",
                        (asset['asset_id'],)
                    )
                    asset['service_count'] = cursor.fetchone()['count']
            
            return jsonify({
                'data': assets,
                'count': len(assets)
            })
        
        elif request.method == 'POST':
            # Create new asset
            data = request.json
            
            asset_id = f"asset-{uuid.uuid4().hex[:8]}"
            asset_data = {
                'asset_id': asset_id,
                'org_id': get_user_org(),
                'asset_name': data['asset_name'],
                'asset_type': data['asset_type'],
                'asset_owner': data.get('asset_owner'),
                'description': data.get('description'),
                'onboarded_date': data.get('onboarded_date', datetime.now().isoformat()),
                'status': data.get('status', 'active'),
                'created_by': request.user_id,
                'metadata': json.dumps(data.get('metadata', {}))
            }
            
            with db_service.get_connection() as conn:
                conn.execute("""
                    INSERT INTO assets (
                        asset_id, org_id, asset_name, asset_type, asset_owner,
                        description, onboarded_date, status, created_by, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    asset_data['asset_id'], asset_data['org_id'], asset_data['asset_name'],
                    asset_data['asset_type'], asset_data['asset_owner'], asset_data['description'],
                    asset_data['onboarded_date'], asset_data['status'], asset_data['created_by'],
                    asset_data['metadata']
                ))
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': asset_data['org_id'],
                'user_id': request.user_id,
                'action': 'create_asset',
                'resource_type': 'asset',
                'resource_id': asset_id,
                'ip_address': request.remote_addr,
                'metadata': {'name': data['asset_name']}
            })
            
            return jsonify({
                'asset_id': asset_id,
                'message': 'Asset created successfully'
            }), 201
    
    except Exception as e:
        logger.error(f"Error in handle_assets: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/assets/<asset_id>', methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
@require_auth
def handle_asset_detail(asset_id):
    """Handle individual asset operations"""
    try:
        if request.method == 'GET':
            # Get asset by ID
            with db_service.get_connection() as conn:
                cursor = conn.execute(
                    "SELECT * FROM assets WHERE asset_id = ?", (asset_id,)
                )
                asset = cursor.fetchone()
                
                if not asset:
                    return jsonify({'error': 'Asset not found'}), 404
                
                asset = dict(asset)
                
                # Get associated services
                cursor = conn.execute("""
                    SELECT * FROM services WHERE asset_id = ?
                    ORDER BY created_at DESC
                """, (asset_id,))
                asset['services'] = [dict(row) for row in cursor.fetchall()]
            
            return jsonify(asset)
        
        elif request.method == 'PUT':
            # Update asset
            data = request.json
            
            # Build update fields
            update_fields = []
            values = []
            
            if 'asset_name' in data:
                update_fields.append('asset_name = ?')
                values.append(data['asset_name'])
            
            if 'asset_type' in data:
                update_fields.append('asset_type = ?')
                values.append(data['asset_type'])
            
            if 'asset_owner' in data:
                update_fields.append('asset_owner = ?')
                values.append(data['asset_owner'])
            
            if 'description' in data:
                update_fields.append('description = ?')
                values.append(data['description'])
            
            if 'status' in data:
                update_fields.append('status = ?')
                values.append(data['status'])
            
            if 'metadata' in data:
                update_fields.append('metadata = ?')
                values.append(json.dumps(data['metadata']))
            
            # Add updated_at
            update_fields.append('updated_at = ?')
            values.append(datetime.now().isoformat())
            
            values.append(asset_id)
            
            with db_service.get_connection() as conn:
                conn.execute(
                    f"UPDATE assets SET {', '.join(update_fields)} WHERE asset_id = ?",
                    values
                )
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': get_user_org(),
                'user_id': request.user_id,
                'action': 'update_asset',
                'resource_type': 'asset',
                'resource_id': asset_id,
                'ip_address': request.remote_addr,
                'metadata': {'name': data.get('asset_name', 'Unknown')}
            })
            
            return jsonify({'message': 'Asset updated successfully'})
        
        elif request.method == 'DELETE':
            # Delete asset
            with db_service.get_connection() as conn:
                # Check if asset has services
                cursor = conn.execute(
                    "SELECT COUNT(*) as count FROM services WHERE asset_id = ?",
                    (asset_id,)
                )
                service_count = cursor.fetchone()['count']
                
                if service_count > 0:
                    return jsonify({
                        'error': f'Cannot delete asset with {service_count} associated services. Remove services first.'
                    }), 400
                
                # Delete asset
                conn.execute("DELETE FROM assets WHERE asset_id = ?", (asset_id,))
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': get_user_org(),
                'user_id': request.user_id,
                'action': 'delete_asset',
                'resource_type': 'asset',
                'resource_id': asset_id,
                'ip_address': request.remote_addr,
                'metadata': {}
            })
            
            return jsonify({'message': 'Asset deleted successfully'})
    
    except Exception as e:
        logger.error(f"Error in handle_asset_detail for {asset_id}: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/assets/<asset_id>/services', methods=['GET', 'POST', 'OPTIONS'])
@require_auth
def handle_asset_services(asset_id):
    """Handle services associated with an asset"""
    try:
        if request.method == 'GET':
            # Get all services for this asset
            with db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT s.*, 
                           COUNT(DISTINCT sla.sla_id) as sla_count
                    FROM services s
                    LEFT JOIN slas sla ON s.service_id = sla.service_id
                    WHERE s.asset_id = ?
                    GROUP BY s.service_id
                    ORDER BY s.created_at DESC
                """, (asset_id,))
                services = [dict(row) for row in cursor.fetchall()]
            
            return jsonify({
                'data': services,
                'count': len(services)
            })
        
        elif request.method == 'POST':
            # Associate existing service with asset or create new service for asset
            data = request.json
            
            if 'service_id' in data:
                # Associate existing service
                service_id = data['service_id']
                
                with db_service.get_connection() as conn:
                    conn.execute(
                        "UPDATE services SET asset_id = ? WHERE service_id = ?",
                        (asset_id, service_id)
                    )
                
                return jsonify({'message': 'Service associated with asset'})
            else:
                # Create new service for this asset
                service_id = f"svc-{uuid.uuid4().hex[:8]}"
                
                with db_service.get_connection() as conn:
                    conn.execute("""
                        INSERT INTO services (
                            service_id, org_id, service_name, service_type,
                            description, owner_team, asset_id, created_by
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        service_id, get_user_org(), data['service_name'],
                        data['service_type'], data.get('description'),
                        data.get('owner_team'), asset_id, request.user_id
                    ))
                
                return jsonify({
                    'service_id': service_id,
                    'message': 'Service created and associated with asset'
                }), 201
    
    except Exception as e:
        logger.error(f"Error in handle_asset_services for {asset_id}: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/dashboard/stats', methods=['GET', 'OPTIONS'])
@require_auth
def get_dashboard_stats():
    """Get dashboard statistics including assets"""
    try:
        org_id = get_user_org()
        
        with db_service.get_connection() as conn:
            # Get asset count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM assets WHERE org_id = ? AND status = 'active'",
                (org_id,)
            )
            total_assets = cursor.fetchone()['count']
            
            # Get service count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM services WHERE org_id = ?",
                (org_id,)
            )
            total_services = cursor.fetchone()['count']
            
            # Get SLA count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM slas WHERE org_id = ?",
                (org_id,)
            )
            total_slas = cursor.fetchone()['count']
            
            # Get active alert count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM alerts WHERE org_id = ? AND status = 'open'",
                (org_id,)
            )
            active_alerts = cursor.fetchone()['count']
        
        return jsonify({
            'total_assets': total_assets,
            'total_services': total_services,
            'total_slas': total_slas,
            'active_alerts': active_alerts
        })
    
    except Exception as e:
        logger.error(f"Error in get_dashboard_stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/dashboard/service-health-indirect', methods=['GET'])
@require_auth
def get_service_health_indirect():
    """
    Get service health data for indirect monitoring (scheduled jobs)
    Combines data from service_monitoring_log and slas tables
    """
    try:
        org_id = get_user_org()
        
        # Get pagination parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))  # Default 10 rows per page
        offset = (page - 1) * limit
        
        # Get filter parameters
        deployment_location = request.args.get('deployment_location', '')
        search = request.args.get('search', '')
        
        with db_service.get_connection() as conn:
            # Build query
            query = """
                SELECT 
                    sml.id,
                    sml.asset_id,
                    sml.asset_name,
                    sml.service_id,
                    sml.service_name,
                    sml.job_name,
                    sml.job_type,
                    sml.deployment_location,
                    sml.job_schedule,
                    sml.scheduled_execution_date,
                    sml.scheduled_start_time,
                    sml.scheduled_end_time,
                    sml.scheduled_execution_duration,
                    sml.start_time,
                    sml.end_time,
                    sml.on_time_ind,
                    sml.creation_time,
                    'indirect' as monitoring_method,
                    COUNT(DISTINCT sla.sla_id) as sla_count,
                    COUNT(DISTINCT CASE WHEN a.status = 'open' THEN a.alert_id END) as active_alerts
                FROM service_monitoring_log sml
                LEFT JOIN services s ON sml.service_id = s.service_id
                LEFT JOIN slas sla ON sml.service_id = sla.service_id
                LEFT JOIN alerts a ON sla.sla_id = a.sla_id
                WHERE s.org_id = ?
            """
            
            params = [org_id]
            
            # Add filters
            if deployment_location and deployment_location.lower() != 'all':
                query += " AND sml.deployment_location = ?"
                params.append(deployment_location)
            
            if search:
                query += """ AND (
                    sml.service_name LIKE ? OR 
                    sml.job_name LIKE ? OR 
                    sml.asset_name LIKE ?
                )"""
                search_param = f"%{search}%"
                params.extend([search_param, search_param, search_param])
            
            # Group by to aggregate SLA count and alerts
            query += """
                GROUP BY 
                    sml.id, sml.asset_id, sml.asset_name, sml.service_id, 
                    sml.service_name, sml.job_name, sml.job_type, 
                    sml.deployment_location, sml.job_schedule,
                    sml.scheduled_execution_date, sml.scheduled_start_time,
                    sml.scheduled_end_time, sml.scheduled_execution_duration,
                    sml.start_time, sml.end_time, sml.on_time_ind,
                    sml.creation_time
                ORDER BY sml.scheduled_start_time DESC
            """
            
            # Get total count for pagination
            count_query = f"""
                SELECT COUNT(DISTINCT sml.id) as total
                FROM service_monitoring_log sml
                LEFT JOIN services s ON sml.service_id = s.service_id
                WHERE s.org_id = ?
            """
            count_params = [org_id]
            
            if deployment_location and deployment_location.lower() != 'all':
                count_query += " AND sml.deployment_location = ?"
                count_params.append(deployment_location)
            
            if search:
                count_query += """ AND (
                    sml.service_name LIKE ? OR 
                    sml.job_name LIKE ? OR 
                    sml.asset_name LIKE ?
                )"""
                count_params.extend([search_param, search_param, search_param])
            
            cursor = conn.execute(count_query, count_params)
            total = cursor.fetchone()['total']
            
            # Add pagination
            query += " LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute main query
            cursor = conn.execute(query, params)
            services = [dict(row) for row in cursor.fetchall()]
            
            return jsonify({
                'data': services,
                'total': total,
                'page': page,
                'limit': limit,
                'total_pages': (total + limit - 1) // limit
            })
    
    except Exception as e:
        logger.error(f"Error in get_service_health_indirect: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ===== JOB MONITORING ENDPOINTS =====

@app.route('/api/v1/job-monitoring/scheduled', methods=['GET'])
@require_auth
def get_scheduled_jobs():
    """Get scheduled job executions"""
    try:
        # Get query parameters
        service_id = request.args.get('service_id')
        date = request.args.get('date')  # YYYY-MM-DD
        window_start = request.args.get('window_start')  # YYYY-MM-DD HH:MM:SS
        window_end = request.args.get('window_end')  # YYYY-MM-DD HH:MM:SS
        
        if service_id:
            # Get by service
            limit = int(request.args.get('limit', 100))
            jobs = db_service.get_scheduled_jobs_by_service(service_id, limit)
        elif date:
            # Get by date
            jobs = db_service.get_scheduled_jobs_by_date(date)
        elif window_start and window_end:
            # Get by window
            jobs = db_service.get_scheduled_jobs_in_window(window_start, window_end)
        else:
            # Get today's jobs by default
            from datetime import datetime
            today = datetime.now().strftime('%Y-%m-%d')
            jobs = db_service.get_scheduled_jobs_by_date(today)
        
        return jsonify({
            'data': jobs,
            'count': len(jobs)
        })
        
    except Exception as e:
        logger.error(f"Error getting scheduled jobs: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/job-monitoring/stats', methods=['GET'])
@require_auth
def get_job_monitoring_stats():
    """Get job monitoring statistics"""
    try:
        stats = db_service.get_job_monitoring_stats()
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"Error getting job monitoring stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/job-monitoring/execution/<int:record_id>', methods=['PUT'])
@require_auth
def update_job_execution(record_id):
    """Update job execution status"""
    try:
        data = request.json
        
        success = db_service.update_job_execution_status(
            record_id=record_id,
            start_time=data.get('start_time'),
            end_time=data.get('end_time'),
            on_time_ind=data.get('on_time_ind')
        )
        
        if success:
            return jsonify({'message': 'Job execution updated successfully'})
        else:
            return jsonify({'error': 'Failed to update job execution'}), 400
            
    except Exception as e:
        logger.error(f"Error updating job execution: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Start health monitoring service
    logger.info("Starting health monitoring service...")
    health_monitor.start()
    
    # Start job monitoring service
    logger.info("Starting job monitoring service...")
    job_monitor.start()
    
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    finally:
        # Stop services on shutdown
        logger.info("Stopping services...")
        health_monitor.stop()
        job_monitor.stop()
