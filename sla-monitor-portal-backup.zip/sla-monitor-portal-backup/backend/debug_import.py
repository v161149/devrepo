"""
Debug Script: Show which job_monitoring_service.py Python is actually loading
"""

import sys
import os

def show_import_path():
    """Show where Python will import job_monitoring_service from"""
    
    print("\n" + "="*70)
    print("PYTHON IMPORT DEBUG")
    print("="*70)
    
    print(f"\nCurrent working directory:")
    print(f"  {os.getcwd()}")
    
    print(f"\nPython executable:")
    print(f"  {sys.executable}")
    
    print(f"\nPython sys.path (import search order):")
    for i, path in enumerate(sys.path, 1):
        print(f"  {i}. {path}")
    
    # Try to import and show location
    print("\n" + "-"*70)
    print("Attempting to import job_monitoring_service...")
    print("-"*70)
    
    try:
        import job_monitoring_service
        import inspect
        
        file_path = inspect.getfile(job_monitoring_service)
        print(f"\n✓ Successfully imported from:")
        print(f"  {file_path}")
        
        # Check if it's the right file
        source_file = inspect.getsourcefile(job_monitoring_service)
        print(f"\nSource file:")
        print(f"  {source_file}")
        
        # Get the _get_etl_jobs_with_schedules method
        if hasattr(job_monitoring_service, 'JobMonitoringService'):
            cls = job_monitoring_service.JobMonitoringService
            if hasattr(cls, '_get_etl_jobs_with_schedules'):
                method = cls._get_etl_jobs_with_schedules
                source = inspect.getsource(method)
                
                print(f"\n" + "-"*70)
                print("Checking _get_etl_jobs_with_schedules method:")
                print("-"*70)
                
                if 'COALESCE(a.asset_name, a.name' in source:
                    print("\n✓ Method has CORRECT code (COALESCE)")
                    print("  This file should work!")
                    
                    # Show the actual line
                    for line in source.split('\n'):
                        if 'COALESCE' in line or 'a.name' in line:
                            print(f"\n  Found: {line.strip()}")
                
                elif 'a.name as asset_name' in source and 'COALESCE' not in source:
                    print("\n✗ Method has OLD code (a.name)")
                    print("  This is why it's failing!")
                    print(f"\n  The file at {file_path} needs to be updated")
                
                else:
                    print("\n⚠ Cannot determine version")
                    print("  Showing method source:")
                    print(source[:500])
        
    except ImportError as e:
        print(f"\n✗ Failed to import: {e}")
        print("\nThis means job_monitoring_service.py is not in Python's path")
    
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*70)
    print("DEBUG COMPLETE")
    print("="*70)
    
    print("\n💡 NEXT STEPS:")
    print("  1. Check if the file path above matches your backend directory")
    print("  2. If different, update THAT file")
    print("  3. Delete __pycache__ in THAT directory")
    print("  4. Restart backend")

if __name__ == "__main__":
    show_import_path()
