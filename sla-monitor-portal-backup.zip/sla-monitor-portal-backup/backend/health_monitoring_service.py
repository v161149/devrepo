"""
Health Monitoring Service
Periodically checks the health of all registered services
"""

import threading
import time
import logging
import requests
from datetime import datetime
from typing import Dict, Optional
import json

logger = logging.getLogger(__name__)

class HealthMonitoringService:
    def __init__(self, db_service, check_interval=60):
        """
        Initialize health monitoring service
        
        Args:
            db_service: Database service instance
            check_interval: Interval in seconds between health checks (default: 60)
        """
        self.db_service = db_service
        self.check_interval = check_interval
        self.running = False
        self.thread = None
        
    def start(self):
        """Start the health monitoring service"""
        if self.running:
            logger.warning("Health monitoring service is already running")
            return
            
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        logger.info(f"Health monitoring service started (interval: {self.check_interval}s)")
        
    def stop(self):
        """Stop the health monitoring service"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Health monitoring service stopped")
        
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                self._check_all_services()
            except Exception as e:
                logger.error(f"Error in health monitoring loop: {e}")
            
            # Sleep until next check
            time.sleep(self.check_interval)
            
    def _check_all_services(self):
        """Check health of all services"""
        # Get all services from all organizations
        with self.db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT service_id, org_id, name, metadata 
                FROM services 
                WHERE is_active = 1
            """)
            services = cursor.fetchall()
            
        logger.info(f"Checking health of {len(services)} services...")
        
        for service_row in services:
            service_id = service_row['service_id']
            org_id = service_row['org_id']
            name = service_row['name']
            metadata_raw = service_row['metadata']
            
            try:
                # Parse metadata
                if not metadata_raw:
                    continue
                    
                metadata = json.loads(metadata_raw)
                service_type = metadata.get('service_type')
                config = metadata.get('config', {})
                
                # Check health based on service type
                health_status = self._check_service_health(service_type, config)
                
                # Update service health status
                self._update_service_health(service_id, org_id, health_status)
                
                logger.debug(f"Service {name} ({service_id}): {health_status['status']}")
                
            except Exception as e:
                logger.error(f"Error checking service {name} ({service_id}): {e}")
                self._update_service_health(service_id, org_id, {
                    'status': 'unknown',
                    'message': f'Health check error: {str(e)}',
                    'checked_at': datetime.now().isoformat()
                })
                
    def _check_service_health(self, service_type: str, config: Dict) -> Dict:
        """
        Check health of a specific service
        
        Returns:
            Dict with 'status' ('healthy', 'unhealthy', 'unknown'), 'message', 'checked_at'
        """
        checked_at = datetime.now().isoformat()
        
        # HTTP-based services
        if service_type in ['api_gateway', 'microservice', 'nginx', 'apache', 'esb']:
            url = config.get('url')
            endpoint = config.get('health_endpoint') or config.get('status_endpoint')
            
            if not url:
                return {
                    'status': 'unknown',
                    'message': 'No URL configured',
                    'checked_at': checked_at
                }
                
            try:
                # Construct full URL
                test_url = url
                if endpoint:
                    if not url.endswith('/'):
                        test_url += '/'
                    if endpoint.startswith('/'):
                        endpoint = endpoint[1:]
                    test_url += endpoint
                    
                # Make HTTP request with short timeout
                response = requests.get(test_url, timeout=5, verify=False)
                
                if response.status_code in [200, 201, 204]:
                    return {
                        'status': 'healthy',
                        'message': f'HTTP {response.status_code}',
                        'response_time': response.elapsed.total_seconds(),
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'HTTP {response.status_code}',
                        'checked_at': checked_at
                    }
                    
            except requests.exceptions.Timeout:
                return {
                    'status': 'unhealthy',
                    'message': 'Connection timeout',
                    'checked_at': checked_at
                }
            except requests.exceptions.ConnectionError:
                return {
                    'status': 'unhealthy',
                    'message': 'Connection refused',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)}',
                    'checked_at': checked_at
                }
        
        # MySQL / Aurora Database
        elif service_type in ['mysql', 'aurora']:
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import pymysql
                start_time = datetime.now()
                
                connection = pymysql.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                with connection.cursor() as cursor:
                    cursor.execute("SELECT 1")
                
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'pymysql driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e)
                if 'Access denied' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif "Can't connect" in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
        
        # PostgreSQL Database
        elif service_type == 'postgresql':
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import psycopg2
                start_time = datetime.now()
                
                connection = psycopg2.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                cursor.close()
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'psycopg2 driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e).lower()
                if 'authentication failed' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif 'could not connect' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
        
        # MongoDB Database
        elif service_type == 'mongodb':
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                from pymongo import MongoClient
                from pymongo.errors import ConnectionFailure, OperationFailure
                start_time = datetime.now()
                
                if username and password:
                    conn_string = f"mongodb://{username}:{password}@{host}:{port}/{database}"
                else:
                    conn_string = f"mongodb://{host}:{port}/{database}"
                
                client = MongoClient(conn_string, serverSelectionTimeoutMS=5000)
                client.admin.command('ping')
                client.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'pymongo driver not installed',
                    'checked_at': checked_at
                }
            except OperationFailure:
                return {
                    'status': 'unhealthy',
                    'message': 'Authentication failed',
                    'checked_at': checked_at
                }
            except ConnectionFailure:
                return {
                    'status': 'unhealthy',
                    'message': 'Connection refused',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)[:50]}',
                    'checked_at': checked_at
                }
        
        # Oracle Database
        elif service_type == 'oracle':
            host = config.get('host')
            port = config.get('port')
            service_name = config.get('service_name')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, service_name, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import cx_Oracle
                start_time = datetime.now()
                
                dsn = cx_Oracle.makedsn(host, int(port), service_name=service_name)
                connection = cx_Oracle.connect(user=username, password=password, dsn=dsn)
                
                cursor = connection.cursor()
                cursor.execute("SELECT 1 FROM DUAL")
                cursor.close()
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'cx_Oracle driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e).lower()
                if 'invalid username/password' in error_msg or 'ora-01017' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif 'ora-12541' in error_msg or 'no listener' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
        
        # Microsoft SQL Server
        elif service_type == 'mssql':
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import pymssql
                start_time = datetime.now()
                
                connection = pymssql.connect(
                    server=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    timeout=5
                )
                
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                cursor.close()
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'pymssql driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e).lower()
                if 'login failed' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif 'connection refused' in error_msg or 'timed out' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
        
        # IBM DB2
        elif service_type == 'db2':
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import ibm_db
                start_time = datetime.now()
                
                conn_string = (
                    f"DATABASE={database};"
                    f"HOSTNAME={host};"
                    f"PORT={port};"
                    f"PROTOCOL=TCPIP;"
                    f"UID={username};"
                    f"PWD={password};"
                )
                
                connection = ibm_db.connect(conn_string, "", "")
                ibm_db.close(connection)
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'ibm_db driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e).lower()
                if 'authorization failure' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif 'communication error' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
                
        # For other service types, return unknown
        return {
            'status': 'unknown',
            'message': 'Health monitoring not yet implemented for this service type',
            'checked_at': checked_at
        }
        
    def _update_service_health(self, service_id: str, org_id: str, health_status: Dict):
        """Update service health status in database"""
        with self.db_service.get_connection() as conn:
            # Check if health record exists
            cursor = conn.execute("""
                SELECT health_check_id FROM service_health_checks 
                WHERE service_id = ? AND org_id = ?
            """, (service_id, org_id))
            
            existing = cursor.fetchone()
            
            if existing:
                # Update existing record
                conn.execute("""
                    UPDATE service_health_checks
                    SET status = ?, 
                        message = ?, 
                        response_time = ?,
                        checked_at = ?,
                        updated_at = ?
                    WHERE service_id = ? AND org_id = ?
                """, (
                    health_status['status'],
                    health_status['message'],
                    health_status.get('response_time'),
                    health_status['checked_at'],
                    datetime.now().isoformat(),
                    service_id,
                    org_id
                ))
            else:
                # Insert new record
                import uuid
                health_check_id = f"hc-{uuid.uuid4().hex[:8]}"
                conn.execute("""
                    INSERT INTO service_health_checks 
                    (health_check_id, service_id, org_id, status, message, response_time, checked_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    health_check_id,
                    service_id,
                    org_id,
                    health_status['status'],
                    health_status['message'],
                    health_status.get('response_time'),
                    health_status['checked_at']
                ))
                
    def check_service_now(self, service_id: str) -> Optional[Dict]:
        """
        Manually trigger health check for a specific service
        
        Args:
            service_id: ID of service to check
            
        Returns:
            Health status dict or None if service not found
        """
        with self.db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT service_id, org_id, name, metadata 
                FROM services 
                WHERE service_id = ? AND is_active = 1
            """, (service_id,))
            
            service_row = cursor.fetchone()
            
            if not service_row:
                return None
                
            metadata_raw = service_row['metadata']
            if not metadata_raw:
                return None
                
            metadata = json.loads(metadata_raw)
            service_type = metadata.get('service_type')
            config = metadata.get('config', {})
            
            # Check health
            health_status = self._check_service_health(service_type, config)
            
            # Update database
            self._update_service_health(service_id, service_row['org_id'], health_status)
            
            return health_status