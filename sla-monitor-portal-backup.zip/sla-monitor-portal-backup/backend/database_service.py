"""
Database Service Microservice
Handles all database operations with connection pooling and error handling
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
from contextlib import contextmanager
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseService:
    def __init__(self, db_path: str = 'sla_portal.db'):
        self.db_path = db_path
        
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Database error: {e}")
            raise
        finally:
            conn.close()
    
    def dict_factory(self, row):
        """Convert sqlite3.Row to dict"""
        return {key: row[key] for key in row.keys()}
    
    # ===== ORGANIZATION OPERATIONS =====
    
    def get_organization(self, org_id: str) -> Optional[Dict]:
        """Get organization by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM organizations WHERE org_id = ?", (org_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    # ===== USER OPERATIONS =====
    
    def create_user(self, user_data: Dict) -> str:
        """Create new user"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO users (user_id, org_id, email, username, password_hash, role)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_data['user_id'], user_data['org_id'], user_data['email'],
                  user_data['username'], user_data['password_hash'], user_data['role']))
            logger.info(f"Created user: {user_data['email']}")
            return user_data['user_id']
    
    def get_user_by_email(self, email: str) -> Optional[Dict]:
        """Get user by email"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM users WHERE email = ? AND is_active = 1", (email,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_users_by_org(self, org_id: str) -> List[Dict]:
        """Get all users in organization"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM users WHERE org_id = ? AND is_active = 1 ORDER BY created_at DESC",
                (org_id,)
            )
            return [dict(row) for row in cursor.fetchall()]
    
    # ===== SERVICE OPERATIONS =====
    
    def create_service(self, service_data: Dict) -> str:
        """Create new service"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO services (service_id, org_id, customer_id, name, description, 
                                      owner_team, asset_id, monitoring_method, deployment_location, 
                                      execution_time, tags, metadata, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (service_data['service_id'], service_data['org_id'], 
                  service_data.get('customer_id'), service_data['name'],
                  service_data.get('description'), service_data.get('owner_team'),
                  service_data.get('asset_id'),
                  service_data.get('monitoring_method', 'direct'),
                  service_data.get('deployment_location'),
                  service_data.get('execution_time'),
                  json.dumps(service_data.get('tags', [])),
                  json.dumps(service_data.get('metadata', {})),
                  1))  # Explicitly set is_active = 1
            logger.info(f"Created service: {service_data['name']} (monitoring: {service_data.get('monitoring_method', 'direct')}, deployment: {service_data.get('deployment_location', 'N/A')}, execution_time: {service_data.get('execution_time', 'N/A')})")
            return service_data['service_id']
    
    def get_service(self, service_id: str) -> Optional[Dict]:
        """Get service by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM services WHERE service_id = ? AND is_active = 1", (service_id,)
            )
            row = cursor.fetchone()
            if row:
                service = dict(row)
                # Parse JSON fields
                service['tags'] = json.loads(service['tags']) if service['tags'] else []
                service['metadata'] = json.loads(service['metadata']) if service['metadata'] else {}
                return service
            return None
    
    def get_services_by_org(self, org_id: str, customer_id: Optional[str] = None) -> List[Dict]:
        """Get all services for organization, optionally filtered by customer"""
        with self.get_connection() as conn:
            if customer_id:
                cursor = conn.execute(
                    "SELECT * FROM services WHERE org_id = ? AND customer_id = ? AND is_active = 1",
                    (org_id, customer_id)
                )
            else:
                cursor = conn.execute(
                    "SELECT * FROM services WHERE org_id = ? AND is_active = 1",
                    (org_id,)
                )
            services = [dict(row) for row in cursor.fetchall()]
            for service in services:
                # Parse JSON fields
                service['tags'] = json.loads(service['tags']) if service['tags'] else []
                service['metadata'] = json.loads(service['metadata']) if service['metadata'] else {}
            return services
    
    def update_service(self, service_id: str, updates: Dict) -> bool:
        """Update service"""
        with self.get_connection() as conn:
            set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
            set_clause += ", updated_at = ?"
            values = list(updates.values()) + [datetime.now().isoformat(), service_id]
            conn.execute(
                f"UPDATE services SET {set_clause} WHERE service_id = ?",
                values
            )
            return True
    
    # ===== SLA OPERATIONS =====
    
    def create_sla(self, sla_data: Dict) -> str:
        """Create new SLA"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO slas (
                    sla_id, org_id, service_id, customer_id, name, metric_type,
                    target_value, target_unit, priority, business_hours_id,
                    escalation_policy_id, start_condition, stop_condition,
                    effective_from, version, created_by, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                sla_data['sla_id'], sla_data['org_id'], sla_data['service_id'],
                sla_data.get('customer_id'), sla_data['name'], sla_data['metric_type'],
                sla_data['target_value'], sla_data['target_unit'], sla_data.get('priority'),
                sla_data.get('business_hours_id'), sla_data.get('escalation_policy_id'),
                json.dumps(sla_data['start_condition']), json.dumps(sla_data['stop_condition']),
                sla_data['effective_from'], sla_data.get('version', 1),
                sla_data.get('created_by'), json.dumps(sla_data.get('metadata', {}))
            ))
            logger.info(f"Created SLA: {sla_data['name']}")
            return sla_data['sla_id']
    
    def get_sla(self, sla_id: str) -> Optional[Dict]:
        """Get SLA by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM slas WHERE sla_id = ?", (sla_id,)
            )
            row = cursor.fetchone()
            if row:
                sla = dict(row)
                
                # Parse JSON fields safely
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                return sla
            return None
    
    def get_slas_by_service(self, service_id: str, active_only: bool = True) -> List[Dict]:
        """Get all SLAs for a service with compliance data"""
        with self.get_connection() as conn:
            query = "SELECT * FROM slas WHERE service_id = ?"
            params = [service_id]
            if active_only:
                query += " AND is_active = 1"
            
            cursor = conn.execute(query, params)
            
            slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Get latest health check for this service
                health_cursor = conn.execute("""
                    SELECT status FROM service_health_checks
                    WHERE service_id = ?
                    ORDER BY checked_at DESC
                    LIMIT 1
                """, (service_id,))
                
                health_row = health_cursor.fetchone()
                
                # Calculate compliance based on health status
                if health_row:
                    if health_row['status'] == 'healthy':
                        sla['current_compliance'] = 99.95
                        sla['service_health_status'] = 'healthy'
                    elif health_row['status'] == 'unhealthy':
                        sla['current_compliance'] = 0.0
                        sla['service_health_status'] = 'unhealthy'
                    else:
                        sla['current_compliance'] = None
                        sla['service_health_status'] = health_row['status']
                else:
                    sla['current_compliance'] = None
                    sla['service_health_status'] = 'unknown'
                
                # Parse JSON fields safely
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                slas.append(sla)
            
            return slas
    
    # ===== EVENT OPERATIONS =====
    
    def create_event(self, event_data: Dict) -> str:
        """Create new event"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO events (
                    event_id, org_id, service_id, customer_id, timestamp,
                    event_type, status, priority, duration, source, payload, normalized_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                event_data['event_id'], event_data['org_id'], event_data['service_id'],
                event_data.get('customer_id'), event_data['timestamp'], event_data['event_type'],
                event_data.get('status'), event_data.get('priority'), event_data.get('duration'),
                event_data.get('source'), json.dumps(event_data['payload']),
                json.dumps(event_data.get('normalized_data', {}))
            ))
            return event_data['event_id']
    
    def get_events(self, org_id: str, filters: Optional[Dict] = None, 
                   limit: int = 100, offset: int = 0) -> List[Dict]:
        """Get events with optional filters"""
        with self.get_connection() as conn:
            query = "SELECT * FROM events WHERE org_id = ?"
            params = [org_id]
            
            if filters:
                if 'service_id' in filters:
                    query += " AND service_id = ?"
                    params.append(filters['service_id'])
                if 'event_type' in filters:
                    query += " AND event_type = ?"
                    params.append(filters['event_type'])
                if 'start_date' in filters:
                    query += " AND timestamp >= ?"
                    params.append(filters['start_date'])
                if 'end_date' in filters:
                    query += " AND timestamp <= ?"
                    params.append(filters['end_date'])
            
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            cursor = conn.execute(query, params)
            events = [dict(row) for row in cursor.fetchall()]
            for event in events:
                event['payload'] = json.loads(event['payload'])
                event['normalized_data'] = json.loads(event['normalized_data']) if event['normalized_data'] else {}
            return events
    
    # ===== EVALUATION OPERATIONS =====
    
    def create_evaluation(self, eval_data: Dict) -> str:
        """Create new SLA evaluation"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO evaluations (
                    evaluation_id, org_id, sla_id, event_id, service_id, customer_id,
                    start_timestamp, stop_timestamp, total_duration, business_duration,
                    is_breach, breach_percentage, status, details
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                eval_data['evaluation_id'], eval_data['org_id'], eval_data['sla_id'],
                eval_data.get('event_id'), eval_data['service_id'], eval_data.get('customer_id'),
                eval_data['start_timestamp'], eval_data.get('stop_timestamp'),
                eval_data.get('total_duration'), eval_data.get('business_duration'),
                eval_data.get('is_breach', False), eval_data.get('breach_percentage'),
                eval_data.get('status', 'active'), json.dumps(eval_data.get('details', {}))
            ))
            return eval_data['evaluation_id']
    
    def update_evaluation(self, evaluation_id: str, updates: Dict) -> bool:
        """Update evaluation"""
        with self.get_connection() as conn:
            set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
            set_clause += ", updated_at = ?"
            values = list(updates.values()) + [datetime.now().isoformat(), evaluation_id]
            conn.execute(
                f"UPDATE evaluations SET {set_clause} WHERE evaluation_id = ?",
                values
            )
            return True
    
    def get_evaluations(self, org_id: str, filters: Optional[Dict] = None) -> List[Dict]:
        """Get evaluations with filters"""
        with self.get_connection() as conn:
            query = "SELECT * FROM evaluations WHERE org_id = ?"
            params = [org_id]
            
            if filters:
                if 'sla_id' in filters:
                    query += " AND sla_id = ?"
                    params.append(filters['sla_id'])
                if 'service_id' in filters:
                    query += " AND service_id = ?"
                    params.append(filters['service_id'])
                if 'is_breach' in filters:
                    query += " AND is_breach = ?"
                    params.append(filters['is_breach'])
            
            query += " ORDER BY start_timestamp DESC"
            cursor = conn.execute(query, params)
            evaluations = [dict(row) for row in cursor.fetchall()]
            for evaluation in evaluations:
                evaluation['details'] = json.loads(evaluation['details']) if evaluation['details'] else {}
            return evaluations
    
    # ===== ALERT OPERATIONS =====
    
    def create_alert(self, alert_data: Dict) -> str:
        """Create new alert"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO alerts (
                    alert_id, org_id, evaluation_id, sla_id, service_id,
                    alert_type, severity, message, channels, status, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                alert_data['alert_id'], alert_data['org_id'], alert_data['evaluation_id'],
                alert_data['sla_id'], alert_data['service_id'], alert_data['alert_type'],
                alert_data['severity'], alert_data['message'], json.dumps(alert_data['channels']),
                alert_data.get('status', 'pending'), json.dumps(alert_data.get('metadata', {}))
            ))
            return alert_data['alert_id']
    
    def get_alerts(self, org_id: str, status: Optional[str] = None) -> List[Dict]:
        """Get alerts"""
        with self.get_connection() as conn:
            query = "SELECT * FROM alerts WHERE org_id = ?"
            params = [org_id]
            if status:
                query += " AND status = ?"
                params.append(status)
            query += " ORDER BY created_at DESC"
            cursor = conn.execute(query, params)
            alerts = [dict(row) for row in cursor.fetchall()]
            for alert in alerts:
                # Parse channels
                if alert.get('channels') and isinstance(alert['channels'], str):
                    try:
                        alert['channels'] = json.loads(alert['channels'])
                    except:
                        alert['channels'] = []
                
                # Parse metadata - handle both JSON and string representation
                if alert.get('metadata') and isinstance(alert['metadata'], str):
                    try:
                        # Try parsing as JSON first
                        alert['metadata'] = json.loads(alert['metadata'])
                    except:
                        # If that fails, try eval (for Python dict string representation)
                        try:
                            import ast
                            alert['metadata'] = ast.literal_eval(alert['metadata'])
                        except:
                            # If both fail, just set to empty dict
                            alert['metadata'] = {}
                elif not alert.get('metadata'):
                    alert['metadata'] = {}
            return alerts
    
    # ===== AUDIT LOG OPERATIONS =====
    
    def create_audit_log(self, log_data: Dict) -> str:
        """Create audit log entry"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO audit_logs (
                    log_id, org_id, user_id, action, resource_type, resource_id,
                    ip_address, user_agent, changes, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                log_data['log_id'], log_data['org_id'], log_data.get('user_id'),
                log_data['action'], log_data.get('resource_type'), log_data.get('resource_id'),
                log_data.get('ip_address'), log_data.get('user_agent'),
                json.dumps(log_data.get('changes', {})), json.dumps(log_data.get('metadata', {}))
            ))
            return log_data['log_id']
    
    # ===== METRICS & REPORTING =====
    
    def get_sla_compliance_summary(self, org_id: str, service_id: Optional[str] = None) -> List[Dict]:
        """Get SLA compliance summary"""
        with self.get_connection() as conn:
            query = "SELECT * FROM sla_compliance_summary WHERE org_id = ?"
            params = [org_id]
            if service_id:
                query += " AND service_id = ?"
                params.append(service_id)
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_dashboard_metrics(self, org_id: str, period_days: int = 30) -> Dict:
        """Get dashboard metrics with real-time calculations"""
        with self.get_connection() as conn:
            from_date = (datetime.now() - timedelta(days=period_days)).isoformat()
            
            # Total services
            total_services = conn.execute(
                "SELECT COUNT(*) as count FROM services WHERE org_id = ? AND is_active = 1",
                (org_id,)
            ).fetchone()['count']
            
            # Total SLAs
            total_slas = conn.execute(
                "SELECT COUNT(*) as count FROM slas WHERE org_id = ? AND is_active = 1",
                (org_id,)
            ).fetchone()['count']
            
            # Calculate REAL breaches by checking current compliance
            # A breach occurs when current_value < target_value
            breach_count = 0
            compliant_count = 0
            total_compliance_sum = 0
            
            # Get all active SLAs
            slas = conn.execute("""
                SELECT sla_id, service_id, target_value, metric_type
                FROM slas 
                WHERE org_id = ? AND is_active = 1
            """, (org_id,)).fetchall()
            
            for sla in slas:
                # Get service health
                service_health = conn.execute("""
                    SELECT status FROM service_health_checks
                    WHERE service_id = ?
                    ORDER BY checked_at DESC
                    LIMIT 1
                """, (sla['service_id'],)).fetchone()
                
                if service_health:
                    # Calculate current value based on health status
                    if service_health['status'] == 'healthy':
                        current_value = 99.95  # Healthy = high uptime
                    else:
                        current_value = 0.0  # Unhealthy = 0% uptime (breach!)
                    
                    # Check if breached (current < target)
                    target_value = sla['target_value']
                    if current_value < target_value:
                        breach_count += 1
                    else:
                        compliant_count += 1
                    
                    # Add to compliance calculation
                    if target_value > 0:
                        compliance_pct = min(100, (current_value / target_value) * 100)
                    else:
                        compliance_pct = 100
                    
                    total_compliance_sum += compliance_pct
            
            # Calculate overall compliance
            if len(slas) > 0:
                overall_compliance = round(total_compliance_sum / len(slas), 2)
            else:
                overall_compliance = 100.0
            
            # Get active alerts (if table exists)
            try:
                active_alerts = conn.execute(
                    "SELECT COUNT(*) as count FROM alerts WHERE org_id = ? AND status IN ('open', 'pending')",
                    (org_id,)
                ).fetchone()['count']
            except:
                active_alerts = 0

            # Total assets (active)
            try:
                total_assets = conn.execute(
                    "SELECT COUNT(*) as count FROM assets WHERE org_id = ? AND status = 'active'",
                    (org_id,)
                ).fetchone()['count']
            except:
                total_assets = 0

            return {
                'total_assets': total_assets,
                'total_services': total_services,
                'total_slas': total_slas,
                'total_breaches': breach_count,
                'active_alerts': active_alerts,
                'overall_compliance': overall_compliance
            }
    
    # ===== HEALTH CHECK OPERATIONS =====
    
    def get_service_health(self, service_id: str) -> Optional[Dict]:
        """Get latest health check for a service"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_health_checks
                WHERE service_id = ?
                ORDER BY checked_at DESC
                LIMIT 1
            """, (service_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_services_with_health(self, org_id: str) -> List[Dict]:
        """Get all services with their latest health status and SLA count"""
        with self.get_connection() as conn:
            # Get services with latest health check and SLA count
            cursor = conn.execute("""
                SELECT 
                    s.*,
                    h.health_check_id,
                    h.status as health_status,
                    h.message as health_message,
                    h.response_time,
                    h.checked_at as health_checked_at,
                    (SELECT COUNT(*) FROM slas WHERE service_id = s.service_id AND is_active = 1) as sla_count
                FROM services s
                LEFT JOIN (
                    SELECT service_id, MAX(checked_at) as max_checked_at
                    FROM service_health_checks
                    GROUP BY service_id
                ) latest ON s.service_id = latest.service_id
                LEFT JOIN service_health_checks h ON s.service_id = h.service_id 
                    AND h.checked_at = latest.max_checked_at
                WHERE s.org_id = ? AND s.is_active = 1
                ORDER BY s.created_at DESC
            """, (org_id,))
            
            services = []
            for row in cursor.fetchall():
                service = dict(row)
                # Parse JSON fields
                service['tags'] = json.loads(service['tags']) if service['tags'] else []
                service['metadata'] = json.loads(service['metadata']) if service['metadata'] else {}
                services.append(service)
            
            return services
    
    # ===== ADDITIONAL SLA OPERATIONS =====
    
    def get_slas_by_org(self, org_id: str) -> List[Dict]:
        """Get all SLAs for an organization with service info and compliance"""
        with self.get_connection() as conn:
            # First get all SLAs with service info
            cursor = conn.execute("""
                SELECT 
                    s.*,
                    srv.name as service_name,
                    srv.description as service_description
                FROM slas s
                LEFT JOIN services srv ON s.service_id = srv.service_id
                WHERE s.org_id = ?
                ORDER BY s.created_at DESC
            """, (org_id,))
            
            slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Get latest health check for this service
                health_cursor = conn.execute("""
                    SELECT status FROM service_health_checks
                    WHERE service_id = ?
                    ORDER BY checked_at DESC
                    LIMIT 1
                """, (sla['service_id'],))
                
                health_row = health_cursor.fetchone()
                
                # Calculate compliance based on health status
                if health_row:
                    if health_row['status'] == 'healthy':
                        sla['current_compliance'] = 99.95
                        sla['service_health_status'] = 'healthy'
                    elif health_row['status'] == 'unhealthy':
                        sla['current_compliance'] = 0.0
                        sla['service_health_status'] = 'unhealthy'
                    else:
                        sla['current_compliance'] = None
                        sla['service_health_status'] = health_row['status']
                else:
                    # No health check data
                    sla['current_compliance'] = None
                    sla['service_health_status'] = 'unknown'
                
                # Parse JSON metadata if it exists
                if sla.get('metadata') and isinstance(sla['metadata'], str):
                    try:
                        sla['metadata'] = json.loads(sla['metadata'])
                    except:
                        pass
                
                # Parse JSON fields
                for field in ['start_condition', 'stop_condition']:
                    if sla.get(field) and isinstance(sla[field], str):
                        try:
                            sla[field] = json.loads(sla[field])
                        except:
                            pass
                
                slas.append(sla)
            
            return slas
    
    def update_sla(self, sla_id: str, updates: Dict):
        """Update SLA"""
        if not updates:
            return
        
        # Don't add updated_at - column doesn't exist in table
        # updates['updated_at'] = datetime.now().isoformat()
        
        set_clause = ", ".join([f"{key} = ?" for key in updates.keys()])
        values = list(updates.values()) + [sla_id]
        
        with self.get_connection() as conn:
            conn.execute(
                f"UPDATE slas SET {set_clause} WHERE sla_id = ?",
                values
            )
            logger.info(f"Updated SLA: {sla_id}")
    
    def hard_delete_sla(self, sla_id: str):
        """Permanently delete SLA from database (hard delete)"""
        with self.get_connection() as conn:
            # Delete the SLA permanently
            conn.execute("DELETE FROM slas WHERE sla_id = ?", (sla_id,))
            logger.warning(f"HARD DELETED SLA (permanent): {sla_id}")
    
    def create_business_hours(self, hours_data: Dict) -> str:
        """Create business hours calendar"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO business_hours (
                    business_hours_id, org_id, name, timezone,
                    monday_start, monday_end,
                    tuesday_start, tuesday_end,
                    wednesday_start, wednesday_end,
                    thursday_start, thursday_end,
                    friday_start, friday_end,
                    saturday_start, saturday_end,
                    sunday_start, sunday_end,
                    holidays, blackout_windows
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                hours_data['business_hours_id'],
                hours_data['org_id'],
                hours_data['name'],
                hours_data['timezone'],
                hours_data.get('monday_start'),
                hours_data.get('monday_end'),
                hours_data.get('tuesday_start'),
                hours_data.get('tuesday_end'),
                hours_data.get('wednesday_start'),
                hours_data.get('wednesday_end'),
                hours_data.get('thursday_start'),
                hours_data.get('thursday_end'),
                hours_data.get('friday_start'),
                hours_data.get('friday_end'),
                hours_data.get('saturday_start'),
                hours_data.get('saturday_end'),
                hours_data.get('sunday_start'),
                hours_data.get('sunday_end'),
                hours_data.get('holidays', '[]'),
                hours_data.get('blackout_windows', '[]')
            ))
            logger.info(f"Created business hours: {hours_data['business_hours_id']}")
            return hours_data['business_hours_id']
    
    def create_escalation_policy(self, policy_data: Dict) -> str:
        """Create escalation policy"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO escalation_policies (
                    escalation_policy_id, org_id, name, levels
                ) VALUES (?, ?, ?, ?)
            """, (
                policy_data['escalation_policy_id'],
                policy_data['org_id'],
                policy_data['name'],
                policy_data['levels']
            ))
            logger.info(f"Created escalation policy: {policy_data['escalation_policy_id']}")
            return policy_data['escalation_policy_id']
    
    def get_sla_compliance(self, sla_id: str) -> Optional[Dict]:
        """
        Get current compliance for SLA
        This is a simplified version - in production, this would calculate
        compliance based on recent evaluations and health check data
        """
        # Get the SLA
        sla = self.get_sla(sla_id)
        if not sla:
            return None
        
        # Get service health to calculate compliance
        try:
            service_health = self.get_service_health(sla['service_id'])
            
            # For uptime SLAs, use health check data
            if sla['metric_type'] == 'uptime' and service_health:
                # This is simplified - real implementation would aggregate over time period
                if service_health['status'] == 'healthy':
                    current_value = 99.95  # Placeholder
                elif service_health['status'] == 'unhealthy':
                    current_value = 95.0  # Placeholder
                else:
                    current_value = None
            else:
                # For other metrics, would need different calculation
                current_value = None
            
            return {
                'sla_id': sla_id,
                'current_value': current_value,
                'target_value': sla['target_value'],
                'status': 'compliant' if current_value and current_value >= sla['target_value'] else 'at_risk'
            }
        except Exception as e:
            logger.warning(f"Could not calculate SLA compliance for {sla_id}: {e}")
            return {
                'sla_id': sla_id,
                'current_value': None,
                'target_value': sla['target_value'],
                'status': 'unknown'
            }
    
    def get_sla_evaluations(self, sla_id: str, breached_only: bool = False, limit: int = 100) -> List[Dict]:
        """Get evaluations for SLA"""
        with self.get_connection() as conn:
            query = "SELECT * FROM evaluations WHERE sla_id = ?"
            params = [sla_id]
            
            if breached_only:
                query += " AND is_breach = 1"
            
            query += " ORDER BY start_timestamp DESC LIMIT ?"
            params.append(limit)
            
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    # ============================================================================
    # Job Monitoring Methods
    # ============================================================================
    
    def get_scheduled_jobs_in_window(self, window_start: str, window_end: str) -> List[Dict]:
        """
        Get all scheduled job executions within a time window
        
        Args:
            window_start: Start time (YYYY-MM-DD HH:MM:SS)
            window_end: End time (YYYY-MM-DD HH:MM:SS)
            
        Returns:
            List of scheduled job dictionaries
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_log
                WHERE scheduled_start_time >= ?
                  AND scheduled_start_time < ?
                ORDER BY scheduled_start_time ASC
            """, (window_start, window_end))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_scheduled_jobs_by_service(self, service_id: str, limit: int = 100) -> List[Dict]:
        """
        Get scheduled job executions for a specific service
        
        Args:
            service_id: Service ID
            limit: Maximum number of records to return
            
        Returns:
            List of scheduled job dictionaries
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_log
                WHERE service_id = ?
                ORDER BY scheduled_start_time DESC
                LIMIT ?
            """, (service_id, limit))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_scheduled_jobs_by_date(self, execution_date: str) -> List[Dict]:
        """
        Get all scheduled job executions for a specific date
        
        Args:
            execution_date: Execution date (YYYY-MM-DD)
            
        Returns:
            List of scheduled job dictionaries
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_log
                WHERE scheduled_execution_date = ?
                ORDER BY scheduled_start_time ASC
            """, (execution_date,))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def update_job_execution_status(self, record_id: int, start_time: str = None, 
                                    end_time: str = None, on_time_ind: str = None) -> bool:
        """
        Update job execution status
        
        Args:
            record_id: Monitoring log record ID
            start_time: Actual start time (YYYY-MM-DD HH:MM:SS)
            end_time: Actual end time (YYYY-MM-DD HH:MM:SS)
            on_time_ind: On-time indicator (Met/Unmet/Unknown/In Progress/Failed)
            
        Returns:
            True if successful
        """
        try:
            with self.get_connection() as conn:
                updates = []
                params = []
                
                if start_time:
                    updates.append("start_time = ?")
                    params.append(start_time)
                
                if end_time:
                    updates.append("end_time = ?")
                    params.append(end_time)
                
                if on_time_ind:
                    updates.append("on_time_ind = ?")
                    params.append(on_time_ind)
                
                if not updates:
                    return False
                
                params.append(record_id)
                
                conn.execute(f"""
                    UPDATE service_monitoring_log
                    SET {', '.join(updates)}
                    WHERE id = ?
                """, params)
                
                return True
                
        except Exception as e:
            logger.error(f"Error updating job execution status: {str(e)}")
            return False
    
    def get_job_monitoring_stats(self) -> Dict:
        """
        Get statistics about job monitoring
        
        Returns:
            Dictionary with monitoring statistics
        """
        with self.get_connection() as conn:
            stats = {}
            
            # Total scheduled executions
            cursor = conn.execute("SELECT COUNT(*) FROM service_monitoring_log")
            stats['total_scheduled'] = cursor.fetchone()[0]
            
            # Scheduled for today
            from datetime import datetime
            today = datetime.now().strftime('%Y-%m-%d')
            cursor = conn.execute("""
                SELECT COUNT(*) FROM service_monitoring_log
                WHERE scheduled_execution_date = ?
            """, (today,))
            stats['scheduled_today'] = cursor.fetchone()[0]
            
            # By status
            cursor = conn.execute("""
                SELECT on_time_ind, COUNT(*) 
                FROM service_monitoring_log
                GROUP BY on_time_ind
            """)
            stats['by_status'] = {row[0]: row[1] for row in cursor.fetchall()}
            
            # Unique jobs being monitored
            cursor = conn.execute("""
                SELECT COUNT(DISTINCT service_id) 
                FROM service_monitoring_log
            """)
            stats['unique_jobs'] = cursor.fetchone()[0]
            
            return stats
