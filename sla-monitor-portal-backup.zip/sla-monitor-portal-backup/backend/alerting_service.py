"""
Alerting and Notification Service Microservice
Handles sending alerts through various channels (email, Slack, PagerDuty, etc.)
"""

import uuid
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional
from database_service import DatabaseService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AlertingService:
    def __init__(self, db_service: DatabaseService):
        self.db = db_service
        self.notification_handlers = {
            'email': self._send_email,
            'slack': self._send_slack,
            'pagerduty': self._send_pagerduty,
            'teams': self._send_teams,
            'webhook': self._send_webhook
        }
    
    def process_alert(self, alert_id: str) -> Dict:
        """Process and send alert through configured channels"""
        # Get alert from database
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM alerts WHERE alert_id = ?", (alert_id,)
            )
            alert = dict(cursor.fetchone())
        
        if not alert:
            logger.error(f"Alert {alert_id} not found")
            return {'success': False, 'error': 'Alert not found'}
        
        channels = json.loads(alert['channels'])
        results = {}
        
        # Send to each channel
        for channel in channels:
            try:
                handler = self.notification_handlers.get(channel)
                if handler:
                    result = handler(alert)
                    results[channel] = result
                    
                    # Create notification record
                    self._create_notification_record(alert_id, channel, result)
                else:
                    logger.warning(f"No handler for channel: {channel}")
                    results[channel] = {'success': False, 'error': 'Unknown channel'}
            except Exception as e:
                logger.error(f"Error sending to {channel}: {e}")
                results[channel] = {'success': False, 'error': str(e)}
        
        # Update alert status
        all_sent = all(r.get('success', False) for r in results.values())
        status = 'sent' if all_sent else 'failed'
        
        with self.db.get_connection() as conn:
            conn.execute(
                "UPDATE alerts SET status = ?, sent_timestamp = ? WHERE alert_id = ?",
                (status, datetime.now().isoformat(), alert_id)
            )
        
        return {
            'alert_id': alert_id,
            'status': status,
            'results': results
        }
    
    def _create_notification_record(self, alert_id: str, channel: str, result: Dict):
        """Create notification history record"""
        notification_id = f"notif-{uuid.uuid4().hex[:12]}"
        
        with self.db.get_connection() as conn:
            conn.execute("""
                INSERT INTO notifications (
                    notification_id, alert_id, channel, recipient, status,
                    sent_at, response, retry_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                notification_id, alert_id, channel,
                result.get('recipient', 'N/A'),
                'sent' if result.get('success') else 'failed',
                datetime.now().isoformat(),
                json.dumps(result),
                0
            ))
    
    def _send_email(self, alert: Dict) -> Dict:
        """Send email notification"""
        # In production, integrate with SendGrid, AWS SES, or similar
        logger.info(f"Sending email for alert {alert['alert_id']}")
        
        # Get service and SLA details
        service = self.db.get_service(alert['service_id'])
        sla = self.db.get_sla(alert['sla_id'])
        
        email_content = {
            'to': self._get_recipients_for_alert(alert),
            'subject': f"[{alert['severity'].upper()}] SLA Alert: {alert['message']}",
            'body': self._format_alert_email(alert, service, sla)
        }
        
        # Simulate sending
        logger.info(f"Email sent to {email_content['to']}")
        
        return {
            'success': True,
            'recipient': ', '.join(email_content['to']),
            'timestamp': datetime.now().isoformat()
        }
    
    def _send_slack(self, alert: Dict) -> Dict:
        """Send Slack notification"""
        # In production, use Slack SDK or webhook
        logger.info(f"Sending Slack notification for alert {alert['alert_id']}")
        
        service = self.db.get_service(alert['service_id'])
        
        slack_payload = {
            'channel': '#sla-alerts',
            'username': 'SLA Monitor',
            'icon_emoji': ':warning:',
            'attachments': [{
                'color': self._get_slack_color(alert['severity']),
                'title': alert['message'],
                'fields': [
                    {'title': 'Service', 'value': service['name'], 'short': True},
                    {'title': 'Severity', 'value': alert['severity'], 'short': True},
                    {'title': 'Type', 'value': alert['alert_type'], 'short': True},
                    {'title': 'Time', 'value': alert['created_at'], 'short': True}
                ],
                'footer': 'SLA Monitoring Portal'
            }]
        }
        
        # Simulate sending
        logger.info(f"Slack message sent to {slack_payload['channel']}")
        
        return {
            'success': True,
            'recipient': slack_payload['channel'],
            'timestamp': datetime.now().isoformat()
        }
    
    def _send_pagerduty(self, alert: Dict) -> Dict:
        """Send PagerDuty notification"""
        # In production, use PagerDuty Events API v2
        logger.info(f"Sending PagerDuty alert for {alert['alert_id']}")
        
        pagerduty_payload = {
            'routing_key': 'your-integration-key',
            'event_action': 'trigger',
            'payload': {
                'summary': alert['message'],
                'severity': alert['severity'],
                'source': 'sla-monitor',
                'custom_details': {
                    'alert_id': alert['alert_id'],
                    'service_id': alert['service_id'],
                    'sla_id': alert['sla_id']
                }
            }
        }
        
        # Simulate sending
        logger.info("PagerDuty event triggered")
        
        return {
            'success': True,
            'recipient': 'PagerDuty',
            'incident_key': f"pd-{alert['alert_id']}",
            'timestamp': datetime.now().isoformat()
        }
    
    def _send_teams(self, alert: Dict) -> Dict:
        """Send Microsoft Teams notification"""
        logger.info(f"Sending Teams notification for alert {alert['alert_id']}")
        
        service = self.db.get_service(alert['service_id'])
        
        teams_payload = {
            '@type': 'MessageCard',
            '@context': 'https://schema.org/extensions',
            'summary': alert['message'],
            'themeColor': self._get_teams_color(alert['severity']),
            'title': f"SLA Alert: {alert['severity'].upper()}",
            'sections': [{
                'facts': [
                    {'name': 'Service', 'value': service['name']},
                    {'name': 'Alert Type', 'value': alert['alert_type']},
                    {'name': 'Message', 'value': alert['message']}
                ]
            }]
        }
        
        # Simulate sending
        logger.info("Teams message sent")
        
        return {
            'success': True,
            'recipient': 'Microsoft Teams',
            'timestamp': datetime.now().isoformat()
        }
    
    def _send_webhook(self, alert: Dict) -> Dict:
        """Send webhook notification"""
        logger.info(f"Sending webhook for alert {alert['alert_id']}")
        
        # Get configured webhooks for this org
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM webhooks WHERE org_id = ? AND is_active = 1",
                (alert['org_id'],)
            )
            webhooks = [dict(row) for row in cursor.fetchall()]
        
        results = []
        for webhook in webhooks:
            events = json.loads(webhook['events'])
            if alert['alert_type'] in events or 'all' in events:
                # Simulate webhook call
                logger.info(f"Webhook sent to {webhook['url']}")
                results.append({
                    'webhook_id': webhook['webhook_id'],
                    'url': webhook['url'],
                    'success': True
                })
        
        return {
            'success': True,
            'recipient': f"{len(results)} webhooks",
            'webhooks': results,
            'timestamp': datetime.now().isoformat()
        }
    
    def _get_recipients_for_alert(self, alert: Dict) -> List[str]:
        """Get email recipients for alert"""
        # In production, this would look up escalation policies and on-call schedules
        return ['oncall@company.com', 'sre-team@company.com']
    
    def _format_alert_email(self, alert: Dict, service: Dict, sla: Dict) -> str:
        """Format alert email body"""
        metadata = json.loads(alert['metadata']) if isinstance(alert['metadata'], str) else alert['metadata']
        
        return f"""
SLA Alert Notification

Severity: {alert['severity'].upper()}
Alert Type: {alert['alert_type']}
Service: {service['name']}
SLA: {sla['name']}

Message: {alert['message']}

Details:
- Target: {metadata.get('target', 'N/A')}
- Breach Percentage: {metadata.get('breach_percentage', 'N/A')}%
- Time: {alert['created_at']}

Please investigate and take appropriate action.

---
SLA Monitoring Portal
"""
    
    def _get_slack_color(self, severity: str) -> str:
        """Get Slack attachment color for severity"""
        colors = {
            'critical': 'danger',
            'high': 'warning',
            'medium': '#FFA500',
            'low': 'good'
        }
        return colors.get(severity, '#808080')
    
    def _get_teams_color(self, severity: str) -> str:
        """Get Teams card color for severity"""
        colors = {
            'critical': 'FF0000',
            'high': 'FFA500',
            'medium': 'FFFF00',
            'low': '00FF00'
        }
        return colors.get(severity, '808080')
    
    def process_escalation(self, alert_id: str) -> Dict:
        """Process alert escalation based on escalation policy"""
        logger.info(f"Processing escalation for alert {alert_id}")
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM alerts WHERE alert_id = ?", (alert_id,)
            )
            alert = dict(cursor.fetchone())
        
        if not alert:
            return {'success': False, 'error': 'Alert not found'}
        
        # Get SLA and escalation policy
        sla = self.db.get_sla(alert['sla_id'])
        
        if not sla.get('escalation_policy_id'):
            return {'success': False, 'error': 'No escalation policy defined'}
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM escalation_policies WHERE escalation_policy_id = ?",
                (sla['escalation_policy_id'],)
            )
            policy = dict(cursor.fetchone())
        
        levels = json.loads(policy['levels'])
        
        # Determine current escalation level based on time
        created_time = datetime.fromisoformat(alert['created_at'])
        elapsed_minutes = (datetime.now() - created_time).total_seconds() / 60
        
        current_level = 0
        for level in levels:
            if elapsed_minutes >= level['wait_minutes']:
                current_level = level['level']
        
        if current_level > 0:
            # Send escalation notifications
            logger.info(f"Escalating to level {current_level}")
            # In production, send notifications to escalation contacts
        
        return {
            'success': True,
            'current_level': current_level,
            'elapsed_minutes': elapsed_minutes
        }
    
    def acknowledge_alert(self, alert_id: str, user_id: str) -> Dict:
        """Acknowledge an alert"""
        with self.db.get_connection() as conn:
            conn.execute("""
                UPDATE alerts 
                SET status = 'acknowledged', 
                    acknowledged_by = ?,
                    acknowledged_at = ?
                WHERE alert_id = ?
            """, (user_id, datetime.now().isoformat(), alert_id))
        
        logger.info(f"Alert {alert_id} acknowledged by {user_id}")
        
        return {
            'success': True,
            'alert_id': alert_id,
            'acknowledged_by': user_id,
            'acknowledged_at': datetime.now().isoformat()
        }
