"""
Email Notification Service for SLA Breaches
Handles sending email alerts when SLAs are breached
"""

import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class EmailNotificationService:
    def __init__(self):
        # Email configuration from environment variables
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.smtp_username = os.getenv('SMTP_USERNAME', '')
        self.smtp_password = os.getenv('SMTP_PASSWORD', '')
        self.from_email = os.getenv('FROM_EMAIL', self.smtp_username)
        self.enabled = os.getenv('EMAIL_NOTIFICATIONS_ENABLED', 'false').lower() == 'true'
        
    def send_breach_notification(self, sla_data, service_data, breach_data):
        """
        Send email notification for SLA breach
        
        Args:
            sla_data (dict): SLA information
            service_data (dict): Service information
            breach_data (dict): Breach details (current_value, target_value, breach_percentage)
        """
        if not self.enabled:
            logger.info("Email notifications are disabled. Set EMAIL_NOTIFICATIONS_ENABLED=true to enable.")
            return False
            
        if not self.smtp_username or not self.smtp_password:
            logger.error("SMTP credentials not configured. Cannot send email.")
            return False
        
        try:
            # Get recipients from escalation policy
            recipients = self._get_recipients(sla_data)
            
            if not recipients:
                logger.warning(f"No recipients found for SLA {sla_data.get('sla_id')}")
                return False
            
            # Create email
            subject = f"⚠️ SLA BREACH ALERT: {sla_data.get('name')} for {service_data.get('name')}"
            html_body = self._create_breach_email_html(sla_data, service_data, breach_data)
            text_body = self._create_breach_email_text(sla_data, service_data, breach_data)
            
            # Send to all recipients
            for recipient in recipients:
                self._send_email(recipient, subject, html_body, text_body)
                logger.info(f"Breach notification sent to {recipient} for SLA {sla_data.get('sla_id')}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to send breach notification: {e}")
            return False
    
    def _get_recipients(self, sla_data):
        """Extract email recipients from SLA escalation policy"""
        recipients = []
        
        # Parse metadata to get escalation steps
        metadata = sla_data.get('metadata', {})
        if isinstance(metadata, str):
            import json
            metadata = json.loads(metadata)
        
        escalation_steps = metadata.get('escalationSteps', [])
        
        # Get contacts from all escalation levels
        for step in escalation_steps:
            contact = step.get('contact', '').strip()
            if contact and '@' in contact:  # Basic email validation
                if contact not in recipients:
                    recipients.append(contact)
        
        return recipients
    
    def _create_breach_email_html(self, sla_data, service_data, breach_data):
        """Create HTML email body for breach notification"""
        current_value = breach_data.get('current_value', 0)
        target_value = sla_data.get('target_value', 0)
        breach_percentage = breach_data.get('breach_percentage', 0)
        metric_type = sla_data.get('metric_type', 'unknown')
        target_unit = sla_data.get('target_unit', '')
        
        # Determine severity color
        if breach_percentage >= 5:
            severity_color = '#DC2626'  # Red - Critical
            severity_label = 'CRITICAL'
        elif breach_percentage >= 2:
            severity_color = '#F59E0B'  # Orange - High
            severity_label = 'HIGH'
        else:
            severity_color = '#EAB308'  # Yellow - Medium
            severity_label = 'MEDIUM'
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, {severity_color} 0%, #991B1B 100%); color: white; padding: 30px; border-radius: 10px 10px 0 0; text-align: center;">
                <h1 style="margin: 0; font-size: 24px;">⚠️ SLA BREACH ALERT</h1>
                <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.9;">
                    Severity: <strong>{severity_label}</strong> | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                </p>
            </div>
            
            <div style="background: #F9FAFB; padding: 30px; border-left: 4px solid {severity_color};">
                <h2 style="color: {severity_color}; margin-top: 0;">SLA Breach Detected</h2>
                <p style="font-size: 16px; margin: 10px 0;">
                    The SLA <strong>{sla_data.get('name')}</strong> for service 
                    <strong>{service_data.get('name')}</strong> has been breached.
                </p>
                
                <div style="background: white; border: 1px solid #E5E7EB; border-radius: 8px; padding: 20px; margin: 20px 0;">
                    <h3 style="margin-top: 0; color: #374151; font-size: 18px;">Breach Details</h3>
                    
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr style="border-bottom: 1px solid #E5E7EB;">
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">Service:</td>
                            <td style="padding: 12px 0; text-align: right;">{service_data.get('name')}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #E5E7EB;">
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">SLA Name:</td>
                            <td style="padding: 12px 0; text-align: right;">{sla_data.get('name')}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #E5E7EB;">
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">Metric Type:</td>
                            <td style="padding: 12px 0; text-align: right; text-transform: capitalize;">{metric_type.replace('_', ' ')}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #E5E7EB;">
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">Target Value:</td>
                            <td style="padding: 12px 0; text-align: right; color: #10B981;">{target_value} {target_unit}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #E5E7EB;">
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">Current Value:</td>
                            <td style="padding: 12px 0; text-align: right; color: {severity_color}; font-weight: bold;">{current_value:.2f} {target_unit}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #E5E7EB;">
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">Breach Amount:</td>
                            <td style="padding: 12px 0; text-align: right; color: {severity_color}; font-weight: bold;">{breach_percentage:.2f}%</td>
                        </tr>
                        <tr>
                            <td style="padding: 12px 0; font-weight: bold; color: #6B7280;">Priority:</td>
                            <td style="padding: 12px 0; text-align: right;">{sla_data.get('priority', 'N/A')}</td>
                        </tr>
                    </table>
                </div>
                
                <div style="background: #FEF3C7; border: 1px solid #FCD34D; border-radius: 8px; padding: 15px; margin: 20px 0;">
                    <h3 style="margin-top: 0; color: #92400E; font-size: 16px;">⚡ Immediate Action Required</h3>
                    <ul style="margin: 10px 0; padding-left: 20px; color: #78350F;">
                        <li>Review service health status</li>
                        <li>Check recent incidents or changes</li>
                        <li>Follow escalation procedures</li>
                        <li>Update stakeholders</li>
                    </ul>
                </div>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="http://localhost:3010/services/{service_data.get('service_id')}" 
                       style="background: {severity_color}; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                        View Service Details →
                    </a>
                </div>
            </div>
            
            <div style="background: #F3F4F6; padding: 20px; border-radius: 0 0 10px 10px; text-align: center; font-size: 12px; color: #6B7280;">
                <p style="margin: 5px 0;">
                    This is an automated notification from SLA Monitoring Portal
                </p>
                <p style="margin: 5px 0;">
                    Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                </p>
            </div>
        </body>
        </html>
        """
        return html
    
    def _create_breach_email_text(self, sla_data, service_data, breach_data):
        """Create plain text email body for breach notification"""
        current_value = breach_data.get('current_value', 0)
        target_value = sla_data.get('target_value', 0)
        breach_percentage = breach_data.get('breach_percentage', 0)
        metric_type = sla_data.get('metric_type', 'unknown')
        target_unit = sla_data.get('target_unit', '')
        
        text = f"""
========================================
⚠️  SLA BREACH ALERT
========================================

SLA BREACH DETECTED
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

BREACH DETAILS:
-------------------
Service:        {service_data.get('name')}
SLA Name:       {sla_data.get('name')}
Metric Type:    {metric_type.replace('_', ' ').title()}
Target Value:   {target_value} {target_unit}
Current Value:  {current_value:.2f} {target_unit}
Breach Amount:  {breach_percentage:.2f}%
Priority:       {sla_data.get('priority', 'N/A')}

IMMEDIATE ACTION REQUIRED:
-------------------
• Review service health status
• Check recent incidents or changes
• Follow escalation procedures
• Update stakeholders

VIEW DETAILS:
http://localhost:3010/services/{service_data.get('service_id')}

========================================
This is an automated notification from SLA Monitoring Portal
========================================
        """
        return text
    
    def _send_email(self, to_email, subject, html_body, text_body):
        """Send email using SMTP"""
        try:
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = self.from_email
            msg['To'] = to_email
            
            # Attach both plain text and HTML versions
            part1 = MIMEText(text_body, 'plain')
            part2 = MIMEText(html_body, 'html')
            msg.attach(part1)
            msg.attach(part2)
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(msg)
                
            logger.info(f"Email sent successfully to {to_email}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {e}")
            raise


# Create singleton instance
email_service = EmailNotificationService()
