"""
SLA Breach Detection Service
Monitors SLAs and sends email notifications when breaches occur
"""

import time
import threading
import logging
from datetime import datetime
from email_service import email_service

logger = logging.getLogger(__name__)


class BreachDetectionService:
    def __init__(self, db_service):
        self.db_service = db_service
        self.running = False
        self.check_interval = 60  # Check every 60 seconds
        self.thread = None
        self.last_breach_notifications = {}  # Track last notification time per SLA
        self.notification_cooldown = 300  # 5 minutes cooldown between notifications for same SLA
        
    def start(self):
        """Start the breach detection service"""
        if self.running:
            logger.warning("Breach detection service is already running")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        logger.info("Breach detection service started")
    
    def stop(self):
        """Stop the breach detection service"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Breach detection service stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        logger.info("Starting SLA breach monitoring loop")
        
        while self.running:
            try:
                self._check_all_slas()
            except Exception as e:
                logger.error(f"Error in breach monitoring loop: {e}")
            
            # Sleep for check interval
            time.sleep(self.check_interval)
    
    def _check_all_slas(self):
        """Check all active SLAs for breaches"""
        try:
            # Get all organizations (simplified - in production, iterate through all orgs)
            # For now, we'll check all active SLAs across all organizations
            
            # Get all active SLAs from database
            # Note: This is a simplified query - in production you'd get by org
            with self.db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT * FROM slas 
                    WHERE is_active = 1
                """)
                slas = [dict(row) for row in cursor.fetchall()]
            
            logger.info(f"Checking {len(slas)} active SLAs for breaches")
            
            for sla in slas:
                self._check_sla_breach(sla)
                
        except Exception as e:
            logger.error(f"Error checking SLAs: {e}")
    
    def _check_sla_breach(self, sla):
        """Check if a specific SLA is breached"""
        try:
            sla_id = sla['sla_id']
            service_id = sla['service_id']
            
            # Get service details
            service = self.db_service.get_service(service_id)
            if not service:
                logger.warning(f"Service {service_id} not found for SLA {sla_id}")
                return
            
            # Get current compliance
            compliance = self.db_service.get_sla_compliance(sla_id)
            if not compliance:
                logger.debug(f"No compliance data for SLA {sla_id}")
                return
            
            current_value = compliance.get('current_value')
            target_value = sla.get('target_value')
            
            if current_value is None or target_value is None:
                return
            
            # Check if breached (current value is below target)
            is_breached = current_value < target_value
            
            if is_breached:
                breach_percentage = ((target_value - current_value) / target_value) * 100
                
                logger.warning(
                    f"SLA BREACH DETECTED: {sla['name']} - "
                    f"Current: {current_value:.2f}, Target: {target_value}, "
                    f"Breach: {breach_percentage:.2f}%"
                )
                
                # Check if we should send notification (cooldown check)
                if self._should_send_notification(sla_id):
                    self._send_breach_notification(sla, service, {
                        'current_value': current_value,
                        'target_value': target_value,
                        'breach_percentage': breach_percentage
                    })
                    
                    # Update last notification time
                    self.last_breach_notifications[sla_id] = time.time()
                    
                    # Create alert record in database
                    self._create_breach_alert(sla, service, breach_percentage)
            else:
                # SLA is compliant
                logger.debug(
                    f"SLA COMPLIANT: {sla['name']} - "
                    f"Current: {current_value:.2f}, Target: {target_value}"
                )
                
        except Exception as e:
            logger.error(f"Error checking SLA {sla.get('sla_id')}: {e}")
    
    def _should_send_notification(self, sla_id):
        """Check if enough time has passed since last notification"""
        last_notification = self.last_breach_notifications.get(sla_id)
        
        if last_notification is None:
            return True
        
        time_since_last = time.time() - last_notification
        return time_since_last >= self.notification_cooldown
    
    def _send_breach_notification(self, sla, service, breach_data):
        """Send email notification for breach"""
        try:
            success = email_service.send_breach_notification(sla, service, breach_data)
            
            if success:
                logger.info(f"Breach notification sent for SLA {sla['sla_id']}")
            else:
                logger.warning(f"Failed to send breach notification for SLA {sla['sla_id']}")
                
        except Exception as e:
            logger.error(f"Error sending breach notification: {e}")
    
    def _create_breach_alert(self, sla, service, breach_percentage):
        """Create alert record in database"""
        try:
            import uuid
            
            alert_id = f"alert-{uuid.uuid4().hex[:12]}"
            alert_data = {
                'alert_id': alert_id,
                'org_id': sla['org_id'],
                'sla_id': sla['sla_id'],
                'service_id': service['service_id'],
                'alert_type': 'sla_breach',
                'severity': self._calculate_severity(breach_percentage),
                'title': f"SLA Breach: {sla['name']}",
                'message': f"SLA {sla['name']} for service {service['name']} has been breached by {breach_percentage:.2f}%",
                'status': 'open',
                'created_at': datetime.now().isoformat()
            }
            
            with self.db_service.get_connection() as conn:
                conn.execute("""
                    INSERT INTO alerts (
                        alert_id, org_id, sla_id, service_id, alert_type,
                        severity, title, message, status, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    alert_data['alert_id'],
                    alert_data['org_id'],
                    alert_data['sla_id'],
                    alert_data['service_id'],
                    alert_data['alert_type'],
                    alert_data['severity'],
                    alert_data['title'],
                    alert_data['message'],
                    alert_data['status'],
                    alert_data['created_at']
                ))
            
            logger.info(f"Created breach alert {alert_id} for SLA {sla['sla_id']}")
            
        except Exception as e:
            logger.error(f"Error creating breach alert: {e}")
    
    def _calculate_severity(self, breach_percentage):
        """Calculate alert severity based on breach percentage"""
        if breach_percentage >= 5:
            return 'critical'
        elif breach_percentage >= 2:
            return 'high'
        elif breach_percentage >= 1:
            return 'medium'
        else:
            return 'low'


# Global instance (will be initialized in api_service.py)
breach_detection_service = None


def initialize_breach_detection(db_service):
    """Initialize and start the breach detection service"""
    global breach_detection_service
    
    if breach_detection_service is None:
        breach_detection_service = BreachDetectionService(db_service)
        breach_detection_service.start()
        logger.info("Breach detection service initialized and started")
    
    return breach_detection_service
