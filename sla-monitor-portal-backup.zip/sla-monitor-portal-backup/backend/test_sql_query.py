"""
Direct Test: Check the actual SQL query being executed
"""

import sqlite3
import json

def test_query(db_path='../database/sla_portal.db'):
    """Test the actual query"""
    
    print("\n" + "="*70)
    print("TESTING SQL QUERY DIRECTLY")
    print("="*70)
    
    # Test 1: Check assets table structure
    print("\n1. Checking assets table structure...")
    conn = sqlite3.connect(db_path)
    cursor = conn.execute("PRAGMA table_info(assets)")
    columns = [col[1] for col in cursor.fetchall()]
    print(f"   Columns: {', '.join(columns)}")
    
    # Determine which column to use
    if 'asset_name' in columns:
        asset_col = 'asset_name'
        print(f"   ✓ Using column: asset_name")
    elif 'name' in columns:
        asset_col = 'name'
        print(f"   ✓ Using column: name")
    else:
        print(f"   ✗ No name column found!")
        conn.close()
        return
    
    # Test 2: Test the OLD query (should fail)
    print("\n2. Testing OLD query (a.name)...")
    try:
        cursor = conn.execute("""
            SELECT 
                s.service_id,
                s.name as service_name,
                s.asset_id,
                s.deployment_location,
                s.metadata,
                a.name as asset_name
            FROM services s
            LEFT JOIN assets a ON s.asset_id = a.asset_id
            WHERE s.is_active = 1
              AND s.metadata LIKE '%etl_batch%'
            LIMIT 1
        """)
        row = cursor.fetchone()
        print(f"   ✓ Query succeeded (unexpected!)")
        print(f"   This means assets table has 'name' column")
    except sqlite3.OperationalError as e:
        print(f"   ✗ Query failed: {e}")
        print(f"   This confirms the issue")
    
    # Test 3: Test the NEW query with COALESCE (should work)
    print("\n3. Testing NEW query (COALESCE)...")
    try:
        cursor = conn.execute(f"""
            SELECT 
                s.service_id,
                s.name as service_name,
                s.asset_id,
                s.deployment_location,
                s.metadata,
                COALESCE(a.asset_name, a.name, 'Unknown') as asset_name
            FROM services s
            LEFT JOIN assets a ON s.asset_id = a.asset_id
            WHERE s.is_active = 1
              AND s.metadata LIKE '%etl_batch%'
            LIMIT 1
        """)
        row = cursor.fetchone()
        if row:
            print(f"   ✓ Query succeeded!")
            print(f"   Service: {row[1]}")
            print(f"   Asset: {row[5]}")
        else:
            print(f"   ✓ Query succeeded (but no results)")
    except sqlite3.OperationalError as e:
        print(f"   ✗ Query failed: {e}")
    
    # Test 4: Test the CORRECT query (using detected column)
    print(f"\n4. Testing CORRECT query (a.{asset_col})...")
    try:
        cursor = conn.execute(f"""
            SELECT 
                s.service_id,
                s.name as service_name,
                s.asset_id,
                s.deployment_location,
                s.metadata,
                a.{asset_col} as asset_name
            FROM services s
            LEFT JOIN assets a ON s.asset_id = a.asset_id
            WHERE s.is_active = 1
              AND s.metadata LIKE '%etl_batch%'
        """)
        rows = cursor.fetchall()
        print(f"   ✓ Query succeeded!")
        print(f"   Found {len(rows)} ETL service(s)")
        
        if rows:
            for row in rows:
                metadata = json.loads(row[4]) if row[4] else {}
                config = metadata.get('config', {})
                schedule = config.get('schedule', '(no schedule)')
                job_name = config.get('job_name', row[1])
                
                print(f"\n   Service: {row[1]}")
                print(f"   Job Name: {job_name}")
                print(f"   Schedule: {schedule}")
                print(f"   Asset: {row[5] or '(no asset)'}")
    
    except sqlite3.OperationalError as e:
        print(f"   ✗ Query failed: {e}")
    
    conn.close()
    
    print("\n" + "="*70)
    print("TEST COMPLETE")
    print("="*70)
    
    print(f"\n✓ Correct query should use: a.{asset_col}")
    print(f"\nUpdate job_monitoring_service.py line 182 to use:")
    print(f"   a.{asset_col} as asset_name")
    print(f"\nOr use COALESCE for compatibility:")
    print(f"   COALESCE(a.asset_name, a.name, 'Unknown') as asset_name")

if __name__ == "__main__":
    import os
    
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db',
        'sla_portal.db'
    ]
    
    for db_path in databases:
        if os.path.exists(db_path):
            print(f"\nUsing database: {db_path}")
            test_query(db_path)
            break
    else:
        print("\n✗ Database not found!")
