"""
Verification Script: Check if job_monitoring_service.py is updated
"""

def check_file_version():
    """Check if the file has the fix"""
    try:
        with open('job_monitoring_service.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        print("\n" + "="*70)
        print("FILE VERSION CHECK")
        print("="*70)
        
        # Check for old version
        if 'a.name as asset_name' in content and 'COALESCE' not in content:
            print("\n✗ OLD VERSION DETECTED!")
            print("  The file still has: a.name as asset_name")
            print("  This will cause error: no such column: a.name")
            print("\n  ACTION REQUIRED:")
            print("  1. Download the updated job_monitoring_service.py")
            print("  2. Replace your backend/job_monitoring_service.py")
            print("  3. Restart backend")
            return False
        
        # Check for new version
        elif 'COALESCE(a.asset_name, a.name' in content:
            print("\n✓ NEW VERSION DETECTED!")
            print("  The file has been updated with: COALESCE(a.asset_name, a.name, 'Unknown')")
            print("  This handles both asset_name and name columns")
            
            # Check the exact line
            for i, line in enumerate(content.split('\n'), 1):
                if 'COALESCE(a.asset_name' in line:
                    print(f"\n  Line {i}: {line.strip()}")
            
            print("\n  ✓ File is correct!")
            print("  If you still see errors, make sure backend is restarted")
            return True
        
        else:
            print("\n⚠ UNKNOWN VERSION")
            print("  Could not determine file version")
            print("  Please check the _get_etl_jobs_with_schedules method")
            return False
        
    except FileNotFoundError:
        print("\n✗ FILE NOT FOUND!")
        print("  job_monitoring_service.py not found in current directory")
        print("\n  Run this script from the backend/ directory")
        return False
    
    except Exception as e:
        print(f"\n✗ ERROR: {str(e)}")
        return False

if __name__ == "__main__":
    import os
    
    print(f"\nCurrent directory: {os.getcwd()}")
    
    result = check_file_version()
    
    print("\n" + "="*70)
    
    if result:
        print("RESULT: File is updated correctly ✓")
        print("\nIf backend still shows error:")
        print("  1. Stop backend (Ctrl+C)")
        print("  2. Restart: python api_service.py")
        print("  3. Check logs for 'COALESCE' instead of 'a.name'")
    else:
        print("RESULT: File needs to be updated ✗")
        print("\nSteps to fix:")
        print("  1. Download: job_monitoring_service.py (updated version)")
        print("  2. Replace: backend/job_monitoring_service.py")
        print("  3. Verify: python check_file_version.py")
        print("  4. Restart: python api_service.py")
    
    print("="*70)
