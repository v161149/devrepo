"""
Diagnostic Script: Check ETL Jobs and Schedules
Run this to verify your ETL jobs have valid schedules
"""

import sqlite3
import json
import sys
from datetime import datetime, timedelta
from croniter import croniter

def check_etl_jobs(db_path):
    """Check ETL jobs and their schedules"""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        print("\n" + "="*70)
        print("ETL JOB DIAGNOSTIC CHECK")
        print("="*70)
        
        # Check assets table structure
        print("\n1. Checking assets table structure...")
        cursor.execute("PRAGMA table_info(assets)")
        asset_columns = [col[1] for col in cursor.fetchall()]
        print(f"   Columns: {', '.join(asset_columns)}")
        
        asset_name_col = 'asset_name' if 'asset_name' in asset_columns else 'name' if 'name' in asset_columns else None
        if asset_name_col:
            print(f"   ✓ Asset name column: {asset_name_col}")
        else:
            print("   ⚠ Warning: No name column found in assets table")
        
        # Get all services that look like ETL jobs
        print("\n2. Finding ETL services...")
        cursor.execute("""
            SELECT 
                service_id,
                name,
                asset_id,
                deployment_location,
                metadata,
                is_active
            FROM services
            WHERE metadata LIKE '%etl_batch%'
        """)
        
        services = cursor.fetchall()
        print(f"   Found {len(services)} service(s) with 'etl_batch' in metadata")
        
        if not services:
            print("\n   ✗ No ETL services found!")
            print("   Please add ETL services with metadata.service_type = 'etl_batch'")
            conn.close()
            return
        
        # Check each service
        print("\n3. Checking each ETL service:")
        print("   " + "-"*66)
        
        valid_jobs = 0
        for service in services:
            service_id = service['service_id']
            service_name = service['name']
            is_active = service['is_active']
            metadata_str = service['metadata']
            
            print(f"\n   Service: {service_name} ({service_id})")
            print(f"   Active: {'Yes' if is_active else 'No'}")
            
            if not is_active:
                print("   ⚠ SKIPPED: Service is inactive")
                continue
            
            # Parse metadata
            try:
                metadata = json.loads(metadata_str) if metadata_str else {}
            except:
                print("   ✗ ERROR: Invalid JSON metadata")
                continue
            
            # Check service_type
            service_type = metadata.get('service_type')
            print(f"   Service Type: {service_type}")
            
            if service_type != 'etl_batch':
                print("   ⚠ SKIPPED: Not etl_batch type")
                continue
            
            # Check config
            config = metadata.get('config', {})
            
            # Check job_name
            job_name = config.get('job_name')
            print(f"   Job Name: {job_name or '(missing)'}")
            
            # Check schedule
            schedule = config.get('schedule')
            print(f"   Schedule: {schedule or '(missing)'}")
            
            if not schedule:
                print("   ✗ ERROR: No schedule defined")
                continue
            
            # Validate cron expression
            try:
                cron = croniter(schedule)
                print(f"   ✓ Valid cron expression")
                
                # Calculate next 3 executions
                now = datetime.now()
                next_times = []
                cron = croniter(schedule, now)
                for _ in range(3):
                    next_times.append(cron.get_next(datetime))
                
                print(f"   Next executions:")
                for i, exec_time in enumerate(next_times, 1):
                    print(f"     {i}. {exec_time.strftime('%Y-%m-%d %H:%M:%S')}")
                
                valid_jobs += 1
                
            except Exception as e:
                print(f"   ✗ ERROR: Invalid cron expression - {str(e)}")
                continue
            
            # Check execution_time
            execution_time = metadata.get('execution_time', '00:30:00')
            print(f"   Execution Duration: {execution_time}")
            
            print(f"   ✓ This job will be monitored")
        
        print("\n   " + "-"*66)
        print(f"\n   Summary: {valid_jobs} valid ETL job(s) ready for monitoring")
        
        # Check if window already has records
        print("\n4. Checking next 2-hour window...")
        now = datetime.now()
        
        # Calculate next window (same logic as service)
        if now.minute == 0 and now.second == 0:
            window_start = now + timedelta(hours=1)
        else:
            window_start = now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
        
        window_end = window_start + timedelta(hours=2)
        
        print(f"   Window: {window_start.strftime('%Y-%m-%d %H:%M:%S')} to {window_end.strftime('%Y-%m-%d %H:%M:%S')}")
        
        cursor.execute("""
            SELECT COUNT(*) FROM service_monitoring_log
            WHERE scheduled_start_time >= ?
              AND scheduled_start_time < ?
        """, (
            window_start.strftime('%Y-%m-%d %H:%M:%S'),
            window_end.strftime('%Y-%m-%d %H:%M:%S')
        ))
        
        count = cursor.fetchone()[0]
        
        if count > 0:
            print(f"   ⚠ Window already has {count} record(s)")
            print(f"   Service will skip this window (already processed)")
        else:
            print(f"   ✓ Window is empty - service will process it")
        
        # Show what would be inserted
        print("\n5. Simulating what service will do:")
        print("   " + "-"*66)
        
        if valid_jobs == 0:
            print("   No jobs to process")
        else:
            for service in services:
                if not service['is_active']:
                    continue
                
                try:
                    metadata = json.loads(service['metadata']) if service['metadata'] else {}
                    if metadata.get('service_type') != 'etl_batch':
                        continue
                    
                    config = metadata.get('config', {})
                    schedule = config.get('schedule')
                    
                    if not schedule:
                        continue
                    
                    job_name = config.get('job_name', service['name'])
                    
                    # Get executions in window
                    cron = croniter(schedule, window_start)
                    executions = []
                    
                    max_iterations = 1000
                    for _ in range(max_iterations):
                        next_time = cron.get_next(datetime)
                        if next_time >= window_end:
                            break
                        executions.append(next_time)
                    
                    if executions:
                        print(f"\n   Job: {job_name}")
                        print(f"   Schedule: {schedule}")
                        print(f"   Will insert {len(executions)} record(s):")
                        for exec_time in executions[:5]:  # Show first 5
                            print(f"     - {exec_time.strftime('%Y-%m-%d %H:%M:%S')}")
                        if len(executions) > 5:
                            print(f"     ... and {len(executions) - 5} more")
                    
                except Exception as e:
                    continue
        
        conn.close()
        
        print("\n" + "="*70)
        print("DIAGNOSTIC COMPLETE")
        print("="*70)
        
        if valid_jobs == 0:
            print("\n⚠ ACTION REQUIRED:")
            print("  1. Add schedule to your ETL jobs")
            print("  2. Format: metadata.config.schedule = cron expression")
            print("  3. Example: '0 8 * * *' (daily at 8:00 AM)")
        else:
            print(f"\n✓ {valid_jobs} job(s) ready for monitoring")
            print("  Service will process them on next 30-minute cycle")
        
    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db',
        'sla_portal.db'
    ]
    
    found = False
    for db_path in databases:
        try:
            import os
            if os.path.exists(db_path):
                check_etl_jobs(db_path)
                found = True
                break
        except:
            continue
    
    if not found:
        print("\n✗ Database not found!")
        print("Searched in:")
        for db in databases:
            print(f"  - {db}")
