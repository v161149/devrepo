"""
Job Monitoring Service
Runs as a background thread to monitor scheduled ETL jobs
Wakes up every 30 minutes to check jobs scheduled in the next 2-hour window
"""

import threading
import time
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from croniter import croniter
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class JobMonitoringService:
    """Service to monitor and track scheduled ETL job executions"""
    
    def __init__(self, db_service):
        """
        Initialize the job monitoring service
        
        Args:
            db_service: Database service instance for database operations
        """
        self.db_service = db_service
        self.running = False
        self.thread = None
        self.check_interval = 1800  # 30 minutes in seconds
        
    def start(self):
        """Start the monitoring service in a background thread"""
        if self.running:
            logger.warning("Job monitoring service is already running")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        logger.info("Job monitoring service started (checks every 30 minutes)")
    
    def stop(self):
        """Stop the monitoring service"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Job monitoring service stopped")
    
    def _run(self):
        """Main monitoring loop - runs every 30 minutes"""
        logger.info("Job monitoring service thread started")
        
        # Run immediately on startup, then every 30 minutes
        while self.running:
            try:
                self._check_scheduled_jobs()
            except Exception as e:
                logger.error(f"Error in job monitoring cycle: {str(e)}", exc_info=True)
            
            # Sleep for 30 minutes (check every second to allow clean shutdown)
            for _ in range(self.check_interval):
                if not self.running:
                    break
                time.sleep(1)
    
    def _check_scheduled_jobs(self):
        """Check for jobs scheduled in the next 2-hour window"""
        try:
            current_time = datetime.now()
            
            # Calculate 2-hour window
            window_start = self._get_next_window_start(current_time)
            window_end = window_start + timedelta(hours=2)
            
            logger.info(f"Checking jobs scheduled between {window_start.strftime('%Y-%m-%d %H:%M:%S')} and {window_end.strftime('%Y-%m-%d %H:%M:%S')}")
            
            # Check if we already have records for this window
            if self._window_already_processed(window_start, window_end):
                logger.info(f"Window {window_start.strftime('%H:%M')}-{window_end.strftime('%H:%M')} already processed, skipping")
                return
            
            # Get all ETL jobs with schedules
            etl_jobs = self._get_etl_jobs_with_schedules()
            
            if not etl_jobs:
                logger.info("No ETL jobs with schedules found")
                return
            
            logger.info(f"Found {len(etl_jobs)} ETL job(s) with schedules")
            
            # Process each job
            total_inserted = 0
            for job in etl_jobs:
                inserted = self._process_job(job, window_start, window_end)
                total_inserted += inserted
            
            logger.info(f"Inserted {total_inserted} new scheduled execution record(s)")
            
        except Exception as e:
            logger.error(f"Error checking scheduled jobs: {str(e)}", exc_info=True)
    
    def _get_next_window_start(self, current_time: datetime) -> datetime:
        """
        Calculate the start of the next 2-hour window
        
        Examples:
        - 7:00 AM → 8:00 AM (next hour, rounded up)
        - 7:20 AM → 8:00 AM (next hour, rounded up)
        - 7:59 AM → 8:00 AM (next hour, rounded up)
        - 8:00 AM → 9:00 AM (next hour from current)
        - 8:01 AM → 9:00 AM (next hour, rounded up)
        
        Args:
            current_time: Current datetime
            
        Returns:
            Start of next 2-hour window (top of next hour)
        """
        # Round up to next hour
        if current_time.minute == 0 and current_time.second == 0:
            # Exactly on the hour, use next hour
            next_hour = current_time + timedelta(hours=1)
        else:
            # Round up to next hour
            next_hour = current_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
        
        return next_hour
    
    def _window_already_processed(self, window_start: datetime, window_end: datetime) -> bool:
        """
        Check if records already exist for this time window
        
        Args:
            window_start: Start of 2-hour window
            window_end: End of 2-hour window
            
        Returns:
            True if window has already been processed
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT COUNT(*) 
                    FROM service_monitoring_log
                    WHERE scheduled_start_time >= ? 
                      AND scheduled_start_time < ?
                """, (
                    window_start.strftime('%Y-%m-%d %H:%M:%S'),
                    window_end.strftime('%Y-%m-%d %H:%M:%S')
                ))
                
                count = cursor.fetchone()[0]
                return count > 0
                
        except Exception as e:
            logger.error(f"Error checking if window processed: {str(e)}")
            return False
    
    def _get_etl_jobs_with_schedules(self) -> List[Dict]:
        """
        Get all ETL jobs that have schedule configurations
        
        Returns:
            List of job dictionaries with service and asset info
        """
        try:
            with self.db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT 
                        s.service_id,
                        s.name as service_name,
                        s.asset_id,
                        s.deployment_location,
                        s.metadata,
                        a.asset_name
                    FROM services s
                    LEFT JOIN assets a ON s.asset_id = a.asset_id
                    WHERE s.is_active = 1
                      AND s.metadata LIKE '%etl_batch%'
                      AND s.metadata LIKE '%schedule%'
                """)
                
                jobs = []
                for row in cursor.fetchall():
                    try:
                        metadata = json.loads(row[4]) if row[4] else {}
                        
                        # Verify this is actually an ETL job with schedule
                        if metadata.get('service_type') != 'etl_batch':
                            continue
                        
                        config = metadata.get('config', {})
                        schedule = config.get('schedule')
                        
                        if not schedule:
                            continue
                        
                        job = {
                            'service_id': row[0],
                            'service_name': row[1],
                            'asset_id': row[2],
                            'asset_name': row[5] or 'Unknown',
                            'deployment_location': row[3],
                            'job_name': config.get('job_name', row[1]),  # Use service name as fallback
                            'job_type': metadata.get('service_type'),
                            'schedule': schedule,
                            'execution_time': metadata.get('execution_time', '00:30:00')
                        }
                        
                        jobs.append(job)
                        
                    except json.JSONDecodeError:
                        logger.warning(f"Invalid JSON metadata for service {row[0]}")
                        continue
                
                return jobs
                
        except Exception as e:
            logger.error(f"Error getting ETL jobs: {str(e)}")
            return []
    
    def _process_job(self, job: Dict, window_start: datetime, window_end: datetime) -> int:
        """
        Process a single job and insert execution records for the window
        
        Args:
            job: Job dictionary with schedule and metadata
            window_start: Start of 2-hour window
            window_end: End of 2-hour window
            
        Returns:
            Number of records inserted
        """
        try:
            schedule = job['schedule']
            
            # Validate cron expression
            if not self._is_valid_cron(schedule):
                logger.warning(f"Invalid cron expression for job {job['job_name']}: {schedule}")
                return 0
            
            # Get all execution times within the window
            execution_times = self._get_execution_times(schedule, window_start, window_end)
            
            if not execution_times:
                return 0
            
            # Parse execution duration
            duration = self._parse_duration(job['execution_time'])
            
            # Insert records for each execution time
            inserted_count = 0
            for exec_time in execution_times:
                end_time = exec_time + duration
                
                record = {
                    'asset_id': job['asset_id'],
                    'asset_name': job['asset_name'],
                    'service_id': job['service_id'],
                    'service_name': job['service_name'],
                    'job_name': job['job_name'],
                    'job_type': job['job_type'],
                    'deployment_location': job['deployment_location'],
                    'job_schedule': schedule,
                    'scheduled_execution_date': exec_time.strftime('%Y-%m-%d'),
                    'scheduled_start_time': exec_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'scheduled_end_time': end_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'scheduled_execution_duration': job['execution_time']
                }
                
                if self._insert_monitoring_record(record):
                    inserted_count += 1
                    logger.debug(f"Inserted: {job['job_name']} at {exec_time.strftime('%Y-%m-%d %H:%M:%S')}")
            
            if inserted_count > 0:
                logger.info(f"Job '{job['job_name']}': {inserted_count} execution(s) scheduled")
            
            return inserted_count
            
        except Exception as e:
            logger.error(f"Error processing job {job.get('job_name', 'unknown')}: {str(e)}")
            return 0
    
    def _is_valid_cron(self, cron_expression: str) -> bool:
        """
        Validate a cron expression
        
        Args:
            cron_expression: Cron expression string
            
        Returns:
            True if valid
        """
        try:
            croniter(cron_expression)
            return True
        except:
            return False
    
    def _get_execution_times(self, cron_expression: str, window_start: datetime, window_end: datetime) -> List[datetime]:
        """
        Get all execution times for a cron schedule within the time window
        
        Args:
            cron_expression: Cron expression (e.g., "0 8 * * *")
            window_start: Start of time window
            window_end: End of time window
            
        Returns:
            List of execution datetime objects
        """
        try:
            execution_times = []
            
            # Create croniter instance starting from window_start
            cron = croniter(cron_expression, window_start)
            
            # Get all occurrences within the window
            # Limit to 1000 iterations to prevent infinite loops
            max_iterations = 1000
            iteration = 0
            
            while iteration < max_iterations:
                next_time = cron.get_next(datetime)
                
                if next_time >= window_end:
                    break
                
                execution_times.append(next_time)
                iteration += 1
            
            if iteration >= max_iterations:
                logger.warning(f"Cron expression '{cron_expression}' generated too many executions (>1000)")
            
            return execution_times
            
        except Exception as e:
            logger.error(f"Error getting execution times for cron '{cron_expression}': {str(e)}")
            return []
    
    def _parse_duration(self, duration_str: str) -> timedelta:
        """
        Parse duration string (HH:MM:SS or HH:MM:SS.SSS) to timedelta
        
        Args:
            duration_str: Duration string (e.g., "00:30:00")
            
        Returns:
            timedelta object
        """
        try:
            # Handle HH:MM:SS.SSS format
            if '.' in duration_str:
                time_part, ms_part = duration_str.split('.')
                hours, minutes, seconds = map(int, time_part.split(':'))
                milliseconds = int(ms_part.ljust(3, '0')[:3])  # Pad or truncate to 3 digits
                return timedelta(hours=hours, minutes=minutes, seconds=seconds, milliseconds=milliseconds)
            else:
                # Handle HH:MM:SS format
                hours, minutes, seconds = map(int, duration_str.split(':'))
                return timedelta(hours=hours, minutes=minutes, seconds=seconds)
        except:
            # Default to 30 minutes if parsing fails
            logger.warning(f"Could not parse duration '{duration_str}', using default 30 minutes")
            return timedelta(minutes=30)
    
    def _insert_monitoring_record(self, record: Dict) -> bool:
        """
        Insert a monitoring record into the database
        
        The UNIQUE constraint prevents duplicates automatically
        
        Args:
            record: Record dictionary
            
        Returns:
            True if inserted, False if duplicate
        """
        try:
            with self.db_service.get_connection() as conn:
                conn.execute("""
                    INSERT INTO service_monitoring_log (
                        asset_id, asset_name, service_id, service_name,
                        job_name, job_type, deployment_location, job_schedule,
                        scheduled_execution_date, scheduled_start_time, scheduled_end_time,
                        scheduled_execution_duration, on_time_ind
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record['asset_id'],
                    record['asset_name'],
                    record['service_id'],
                    record['service_name'],
                    record['job_name'],
                    record['job_type'],
                    record['deployment_location'],
                    record['job_schedule'],
                    record['scheduled_execution_date'],
                    record['scheduled_start_time'],
                    record['scheduled_end_time'],
                    record['scheduled_execution_duration'],
                    'Unknown'  # Default on_time_ind
                ))
                
                return True
                
        except Exception as e:
            # Check if it's a UNIQUE constraint violation (duplicate)
            if 'UNIQUE constraint failed' in str(e):
                logger.debug(f"Duplicate record skipped: {record['job_name']} at {record['scheduled_start_time']}")
                return False
            else:
                logger.error(f"Error inserting monitoring record: {str(e)}")
                return False


# Global service instance
_job_monitoring_service = None


def get_job_monitoring_service(db_service):
    """
    Get or create the job monitoring service instance
    
    Args:
        db_service: Database service instance
        
    Returns:
        JobMonitoringService instance
    """
    global _job_monitoring_service
    
    if _job_monitoring_service is None:
        _job_monitoring_service = JobMonitoringService(db_service)
    
    return _job_monitoring_service
