#!/usr/bin/env python3
"""
Database Migration Script
Adds description column to slas table
"""

import sqlite3
import sys
import os
from datetime import datetime

# Configuration
DB_PATH = '../database/sla_portal.db'
MIGRATION_NAME = 'add_description_to_slas'
MIGRATION_VERSION = '001'

def get_db_connection(db_path):
    """Get database connection"""
    if not os.path.exists(db_path):
        print(f"❌ Error: Database not found at {db_path}")
        sys.exit(1)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def create_migrations_table(conn):
    """Create migrations tracking table if it doesn't exist"""
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            migration_id TEXT PRIMARY KEY,
            migration_name TEXT NOT NULL,
            version TEXT NOT NULL,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT CHECK(status IN ('applied', 'failed')) DEFAULT 'applied'
        )
    """)
    conn.commit()
    print("✓ Migrations table ready")

def check_if_applied(conn, migration_name):
    """Check if migration has already been applied"""
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM schema_migrations WHERE migration_name = ?",
        (migration_name,)
    )
    result = cursor.fetchone()
    return result is not None

def record_migration(conn, migration_id, migration_name, version, status='applied'):
    """Record migration in tracking table"""
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO schema_migrations (migration_id, migration_name, version, status)
        VALUES (?, ?, ?, ?)
    """, (migration_id, migration_name, version, status))
    conn.commit()

def column_exists(conn, table_name, column_name):
    """Check if column exists in table"""
    cursor = conn.cursor()
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [row['name'] for row in cursor.fetchall()]
    return column_name in columns

def migrate_add_description_column(conn):
    """
    Migration: Add description column to slas table
    """
    print("\n" + "="*60)
    print(f"Migration: {MIGRATION_NAME}")
    print(f"Version: {MIGRATION_VERSION}")
    print("="*60)
    
    try:
        # Check if column already exists
        if column_exists(conn, 'slas', 'description'):
            print("⚠️  Column 'description' already exists in 'slas' table")
            print("   Skipping column addition")
            skip_add = True
        else:
            skip_add = False
        
        # Step 1: Add description column
        if not skip_add:
            print("\nStep 1: Adding 'description' column to 'slas' table...")
            cursor = conn.cursor()
            cursor.execute("ALTER TABLE slas ADD COLUMN description TEXT")
            conn.commit()
            print("   ✓ Column added successfully")
        
        # Step 2: Update existing records with default descriptions
        print("\nStep 2: Updating existing SLAs with default descriptions...")
        cursor = conn.cursor()
        
        # Get count of SLAs without descriptions
        cursor.execute("SELECT COUNT(*) as count FROM slas WHERE description IS NULL")
        null_count = cursor.fetchone()['count']
        
        if null_count > 0:
            print(f"   Found {null_count} SLAs without descriptions")
            
            # Update them
            cursor.execute("""
                UPDATE slas 
                SET description = 'SLA for ' || name 
                WHERE description IS NULL
            """)
            conn.commit()
            print(f"   ✓ Updated {null_count} SLAs with default descriptions")
        else:
            print("   ℹ️  All SLAs already have descriptions")
        
        # Step 3: Verify changes
        print("\nStep 3: Verifying changes...")
        cursor.execute("PRAGMA table_info(slas)")
        columns = cursor.fetchall()
        
        description_col = None
        for col in columns:
            if col['name'] == 'description':
                description_col = col
                break
        
        if description_col:
            print("   ✓ Column 'description' verified:")
            print(f"      - Type: {description_col['type']}")
            print(f"      - Nullable: {'Yes' if description_col['notnull'] == 0 else 'No'}")
        else:
            raise Exception("Column 'description' not found after migration!")
        
        # Step 4: Show sample data
        print("\nStep 4: Sample data (first 3 SLAs):")
        cursor.execute("SELECT sla_id, name, description FROM slas LIMIT 3")
        samples = cursor.fetchall()
        
        if samples:
            for sla in samples:
                print(f"   - {sla['name']}")
                print(f"     Description: {sla['description']}")
        else:
            print("   ℹ️  No SLAs in database yet")
        
        print("\n" + "="*60)
        print("✓ Migration completed successfully!")
        print("="*60)
        
        return True
        
    except Exception as e:
        print(f"\n❌ Migration failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def rollback_migration(conn):
    """
    Rollback: Remove description column from slas table
    
    Note: SQLite doesn't support DROP COLUMN directly.
    Would need to recreate table without the column.
    """
    print("\n⚠️  Warning: SQLite doesn't support DROP COLUMN")
    print("   To rollback, you would need to:")
    print("   1. Create new table without 'description' column")
    print("   2. Copy data from old table to new table")
    print("   3. Drop old table")
    print("   4. Rename new table")
    print("\n   This is complex and risky. Consider keeping the column.")
    return False

def main():
    """Main migration execution"""
    print("="*60)
    print("SLA Portal - Database Migration Script")
    print("="*60)
    
    # Check if running from correct directory
    if not os.path.exists(DB_PATH):
        # Try alternative paths
        alt_paths = [
            'database/sla_portal.db',
            '../database/sla_portal.db',
            '../../database/sla_portal.db',
            'backend/database/sla_portal.db'
        ]
        
        found = False
        for path in alt_paths:
            if os.path.exists(path):
                DB_PATH_FINAL = path
                found = True
                break
        
        if not found:
            print(f"\n❌ Error: Could not find database file")
            print(f"   Looked in:")
            print(f"   - {DB_PATH}")
            for path in alt_paths:
                print(f"   - {path}")
            print(f"\n   Please run from project root or backend directory")
            sys.exit(1)
    else:
        DB_PATH_FINAL = DB_PATH
    
    print(f"\nDatabase: {DB_PATH_FINAL}")
    print(f"Migration: {MIGRATION_NAME}")
    print(f"Version: {MIGRATION_VERSION}")
    
    # Get user confirmation
    print("\n" + "-"*60)
    confirm = input("Proceed with migration? (yes/no): ").strip().lower()
    
    if confirm not in ['yes', 'y']:
        print("Migration cancelled.")
        sys.exit(0)
    
    # Connect to database
    try:
        conn = get_db_connection(DB_PATH_FINAL)
        print("✓ Connected to database")
    except Exception as e:
        print(f"❌ Failed to connect to database: {str(e)}")
        sys.exit(1)
    
    try:
        # Create migrations table
        create_migrations_table(conn)
        
        # Check if already applied
        if check_if_applied(conn, MIGRATION_NAME):
            print(f"\n⚠️  Migration '{MIGRATION_NAME}' has already been applied")
            print("   Skipping...")
            
            reapply = input("\nForce re-apply? (yes/no): ").strip().lower()
            if reapply not in ['yes', 'y']:
                print("Migration skipped.")
                conn.close()
                sys.exit(0)
        
        # Run migration
        migration_id = f"mig-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        success = migrate_add_description_column(conn)
        
        if success:
            # Record successful migration
            record_migration(conn, migration_id, MIGRATION_NAME, MIGRATION_VERSION, 'applied')
            print(f"\n✓ Migration recorded: {migration_id}")
            print("\n" + "="*60)
            print("NEXT STEPS:")
            print("="*60)
            print("1. Update backend/database_service.py:")
            print("   - Add 'description' to INSERT in create_sla()")
            print("   - Add sla_data.get('description') to VALUES")
            print("\n2. Restart backend:")
            print("   pkill -f api_service.py")
            print("   cd backend && python api_service.py &")
            print("\n3. Test:")
            print("   - Edit SLA from frontend")
            print("   - Should work without errors")
            print("="*60)
        else:
            # Record failed migration
            record_migration(conn, migration_id, MIGRATION_NAME, MIGRATION_VERSION, 'failed')
            print(f"\n❌ Migration failed and recorded: {migration_id}")
            sys.exit(1)
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        conn.close()
        print("\n✓ Database connection closed")

if __name__ == '__main__':
    main()