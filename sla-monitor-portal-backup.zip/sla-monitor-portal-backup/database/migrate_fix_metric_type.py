#!/usr/bin/env python3
"""
Database Migration Script
Fixes metric_type CHECK constraint to include 'error_rate'
"""

import sqlite3
import sys
import os
from datetime import datetime

# Configuration
DB_PATH = '../database/sla_portal.db'
MIGRATION_NAME = 'fix_metric_type_constraint'
MIGRATION_VERSION = '002'

def get_db_connection(db_path):
    """Get database connection"""
    if not os.path.exists(db_path):
        # Try alternative paths
        alt_paths = [
            'database/sla_portal.db',
            '../database/sla_portal.db',
            '../../database/sla_portal.db',
            'backend/database/sla_portal.db'
        ]
        
        for path in alt_paths:
            if os.path.exists(path):
                db_path = path
                break
        else:
            print(f"❌ Error: Database not found")
            sys.exit(1)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def record_migration(conn, migration_id, migration_name, version, status='applied'):
    """Record migration in tracking table"""
    cursor = conn.cursor()
    
    # Create migrations table if it doesn't exist
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            migration_id TEXT PRIMARY KEY,
            migration_name TEXT NOT NULL,
            version TEXT NOT NULL,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT CHECK(status IN ('applied', 'failed')) DEFAULT 'applied'
        )
    """)
    
    cursor.execute("""
        INSERT INTO schema_migrations (migration_id, migration_name, version, status)
        VALUES (?, ?, ?, ?)
    """, (migration_id, migration_name, version, status))
    conn.commit()

def migrate_fix_metric_type_constraint(conn):
    """
    Migration: Fix metric_type CHECK constraint
    
    SQLite doesn't support ALTER TABLE to modify constraints.
    We need to:
    1. Create new table with correct constraint
    2. Copy data from old table
    3. Drop old table
    4. Rename new table
    """
    print("\n" + "="*60)
    print(f"Migration: {MIGRATION_NAME}")
    print(f"Version: {MIGRATION_VERSION}")
    print("="*60)
    
    try:
        cursor = conn.cursor()
        
        # Step 1: Check current schema
        print("\nStep 1: Checking current schema...")
        cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='slas'")
        old_schema = cursor.fetchone()['sql']
        print("   ✓ Current schema retrieved")
        
        # Check if already has error_rate
        if "'error_rate'" in old_schema or '"error_rate"' in old_schema:
            print("   ℹ️  Schema already includes 'error_rate'")
            print("   Migration may have already been applied")
            return True
        
        # Step 2: Create new table with correct constraint
        print("\nStep 2: Creating new table with updated constraint...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS slas_new (
                sla_id TEXT PRIMARY KEY,
                org_id TEXT NOT NULL,
                service_id TEXT NOT NULL,
                customer_id TEXT,
                name TEXT NOT NULL,
                description TEXT,
                metric_type TEXT NOT NULL CHECK(metric_type IN ('response_time', 'resolution_time', 'uptime', 'error_rate', 'custom')),
                target_value REAL NOT NULL,
                target_unit TEXT NOT NULL,
                priority TEXT,
                business_hours_id TEXT,
                start_condition TEXT NOT NULL,
                stop_condition TEXT NOT NULL,
                escalation_policy_id TEXT,
                effective_from TIMESTAMP NOT NULL,
                effective_until TIMESTAMP,
                version INTEGER DEFAULT 1,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by TEXT,
                metadata TEXT,
                FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
                FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
                FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL,
                FOREIGN KEY (business_hours_id) REFERENCES business_hours(business_hours_id) ON DELETE SET NULL,
                FOREIGN KEY (escalation_policy_id) REFERENCES escalation_policies(escalation_policy_id) ON DELETE SET NULL
            )
        """)
        conn.commit()
        print("   ✓ New table created")
        
        # Step 3: Copy data from old table
        print("\nStep 3: Copying data from old table...")
        cursor.execute("SELECT COUNT(*) as count FROM slas")
        old_count = cursor.fetchone()['count']
        print(f"   Found {old_count} SLAs to copy")
        
        # Get column names from old table
        cursor.execute("PRAGMA table_info(slas)")
        columns = [col['name'] for col in cursor.fetchall()]
        columns_str = ', '.join(columns)
        
        # Copy data
        cursor.execute(f"""
            INSERT INTO slas_new ({columns_str})
            SELECT {columns_str} FROM slas
        """)
        conn.commit()
        
        # Verify count
        cursor.execute("SELECT COUNT(*) as count FROM slas_new")
        new_count = cursor.fetchone()['count']
        
        if new_count != old_count:
            raise Exception(f"Data copy mismatch! Old: {old_count}, New: {new_count}")
        
        print(f"   ✓ Copied {new_count} SLAs successfully")
        
        # Step 4: Drop dependent views
        print("\nStep 4: Dropping dependent views...")
        cursor.execute("""
            SELECT name, sql FROM sqlite_master 
            WHERE type='view' AND sql LIKE '%slas%'
        """)
        views = cursor.fetchall()
        
        view_definitions = {}
        for view in views:
            view_name = view['name']
            view_sql = view['sql']
            view_definitions[view_name] = view_sql
            cursor.execute(f"DROP VIEW IF EXISTS {view_name}")
            print(f"   ✓ Dropped view: {view_name}")
        
        conn.commit()
        
        # Step 5: Drop old table
        print("\nStep 5: Dropping old table...")
        cursor.execute("DROP TABLE slas")
        conn.commit()
        print("   ✓ Old table dropped")
        
        # Step 6: Rename new table
        print("\nStep 6: Renaming new table...")
        cursor.execute("ALTER TABLE slas_new RENAME TO slas")
        conn.commit()
        print("   ✓ Table renamed to 'slas'")
        
        # Step 7: Recreate views
        print("\nStep 7: Recreating views...")
        for view_name, view_sql in view_definitions.items():
            cursor.execute(view_sql)
            print(f"   ✓ Recreated view: {view_name}")
        conn.commit()
        
        # Step 8: Verify new schema
        print("\nStep 8: Verifying new schema...")
        cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='slas'")
        new_schema = cursor.fetchone()['sql']
        
        if "'error_rate'" in new_schema or '"error_rate"' in new_schema:
            print("   ✓ Schema now includes 'error_rate'")
        else:
            raise Exception("Migration failed: 'error_rate' not found in new schema")
        
        # Verify data count
        cursor.execute("SELECT COUNT(*) as count FROM slas")
        final_count = cursor.fetchone()['count']
        print(f"   ✓ Final count: {final_count} SLAs")
        
        # Step 9: Show allowed metric types
        print("\nStep 9: Allowed metric types:")
        allowed_types = ['response_time', 'resolution_time', 'uptime', 'error_rate', 'custom']
        for mtype in allowed_types:
            print(f"   ✓ {mtype}")
        
        print("\n" + "="*60)
        print("✓ Migration completed successfully!")
        print("="*60)
        
        return True
        
    except Exception as e:
        print(f"\n❌ Migration failed: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Try to rollback by renaming tables back
        try:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='slas_new'")
            if cursor.fetchone():
                print("\n⚠️  Attempting rollback...")
                cursor.execute("DROP TABLE IF EXISTS slas_new")
                conn.commit()
                print("   ✓ Cleanup completed")
        except:
            pass
        
        return False

def main():
    """Main migration execution"""
    print("="*60)
    print("SLA Portal - Fix Metric Type Constraint Migration")
    print("="*60)
    
    # Find database
    db_paths = [
        '../database/sla_portal.db',
        'database/sla_portal.db',
        '../../database/sla_portal.db',
        'backend/database/sla_portal.db'
    ]
    
    DB_PATH_FINAL = None
    for path in db_paths:
        if os.path.exists(path):
            DB_PATH_FINAL = path
            break
    
    if not DB_PATH_FINAL:
        print("\n❌ Error: Could not find database file")
        print("   Looked in:")
        for path in db_paths:
            print(f"   - {path}")
        sys.exit(1)
    
    print(f"\nDatabase: {DB_PATH_FINAL}")
    print(f"Migration: {MIGRATION_NAME}")
    print(f"Version: {MIGRATION_VERSION}")
    
    print("\n⚠️  WARNING: This migration will recreate the slas table")
    print("   Existing data will be preserved, but:")
    print("   - Foreign key references will be recreated")
    print("   - Table will be temporarily unavailable")
    print("   - Ensure backend is stopped before running")
    
    # Get user confirmation
    print("\n" + "-"*60)
    confirm = input("Proceed with migration? (yes/no): ").strip().lower()
    
    if confirm not in ['yes', 'y']:
        print("Migration cancelled.")
        sys.exit(0)
    
    # Connect to database
    try:
        conn = get_db_connection(DB_PATH_FINAL)
        print("\n✓ Connected to database")
    except Exception as e:
        print(f"\n❌ Failed to connect to database: {str(e)}")
        sys.exit(1)
    
    try:
        # Run migration
        migration_id = f"mig-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        success = migrate_fix_metric_type_constraint(conn)
        
        if success:
            # Record successful migration
            record_migration(conn, migration_id, MIGRATION_NAME, MIGRATION_VERSION, 'applied')
            print(f"\n✓ Migration recorded: {migration_id}")
            
            print("\n" + "="*60)
            print("NEXT STEPS:")
            print("="*60)
            print("1. Restart backend:")
            print("   cd backend && python api_service.py &")
            print("\n2. Test creating SLA with 'Error/Defect Rate':")
            print("   - Select metric type: 'Error/Defect Rate'")
            print("   - Should work without CHECK constraint error")
            print("\n3. Test existing SLAs still work:")
            print("   - View SLAs page")
            print("   - Edit existing SLA")
            print("   - All should work normally")
            print("="*60)
        else:
            # Record failed migration
            record_migration(conn, migration_id, MIGRATION_NAME, MIGRATION_VERSION, 'failed')
            print(f"\n❌ Migration failed and recorded: {migration_id}")
            sys.exit(1)
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        conn.close()
        print("\n✓ Database connection closed")

if __name__ == '__main__':
    main()
