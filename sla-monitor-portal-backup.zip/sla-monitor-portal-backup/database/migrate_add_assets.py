#!/usr/bin/env python3
"""
Database Migration: Add Assets Feature
Creates assets table and updates services table with asset relationship
"""

import sqlite3
import sys
import os
from datetime import datetime

DB_PATH = '../database/sla_portal.db'
MIGRATION_NAME = 'add_assets_feature'
MIGRATION_VERSION = '003'

def get_db_connection(db_path):
    """Get database connection"""
    alt_paths = [
        'sla_portal.db',
        '../database/sla_portal.db',
        '../../database/sla_portal.db',
        'database/sla_portal.db'
    ]
    
    for path in [db_path] + alt_paths:
        if os.path.exists(path):
            conn = sqlite3.connect(path)
            conn.row_factory = sqlite3.Row
            return conn, path
    
    print("❌ Error: Database not found")
    sys.exit(1)

def record_migration(conn, migration_id, migration_name, version, status='applied'):
    """Record migration in tracking table"""
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            migration_id TEXT PRIMARY KEY,
            migration_name TEXT NOT NULL,
            version TEXT NOT NULL,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT CHECK(status IN ('applied', 'failed')) DEFAULT 'applied'
        )
    """)
    
    cursor.execute("""
        INSERT INTO schema_migrations (migration_id, migration_name, version, status)
        VALUES (?, ?, ?, ?)
    """, (migration_id, migration_name, version, status))
    conn.commit()

def migrate_add_assets(conn):
    """
    Migration: Add Assets Feature
    - Creates assets table
    - Adds asset_id column to services table
    - Creates indexes for performance
    """
    print("\n" + "="*60)
    print(f"Migration: {MIGRATION_NAME}")
    print(f"Version: {MIGRATION_VERSION}")
    print("="*60)
    
    try:
        cursor = conn.cursor()
        
        # Step 1: Create assets table
        print("\nStep 1: Creating assets table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assets (
                asset_id TEXT PRIMARY KEY,
                org_id TEXT NOT NULL,
                asset_name TEXT NOT NULL,
                asset_type TEXT NOT NULL,
                asset_owner TEXT,
                description TEXT,
                onboarded_date TIMESTAMP NOT NULL,
                status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive', 'decommissioned')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                metadata TEXT,
                FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
            )
        """)
        conn.commit()
        print("   ✓ Assets table created")
        
        # Step 2: Check if asset_id column already exists in services
        print("\nStep 2: Checking services table...")
        cursor.execute("PRAGMA table_info(services)")
        columns = [row['name'] for row in cursor.fetchall()]
        
        if 'asset_id' in columns:
            print("   ℹ️  asset_id column already exists in services table")
        else:
            print("   Adding asset_id column to services table...")
            cursor.execute("ALTER TABLE services ADD COLUMN asset_id TEXT")
            conn.commit()
            print("   ✓ asset_id column added")
        
        # Step 3: Create indexes for performance
        print("\nStep 3: Creating indexes...")
        
        indexes = [
            ("idx_assets_org_id", "assets(org_id)"),
            ("idx_assets_asset_type", "assets(asset_type)"),
            ("idx_assets_status", "assets(status)"),
            ("idx_services_asset_id", "services(asset_id)")
        ]
        
        for idx_name, idx_def in indexes:
            cursor.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {idx_def}")
            print(f"   ✓ {idx_name}")
        
        conn.commit()
        
        # Step 4: Verify tables
        print("\nStep 4: Verifying tables...")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='assets'")
        if cursor.fetchone():
            print("   ✓ assets table exists")
        else:
            raise Exception("assets table not found after creation")
        
        cursor.execute("PRAGMA table_info(services)")
        columns = [row['name'] for row in cursor.fetchall()]
        if 'asset_id' in columns:
            print("   ✓ services.asset_id column exists")
        else:
            raise Exception("asset_id column not found in services table")
        
        # Step 5: Show table structure
        print("\nStep 5: Assets table structure:")
        cursor.execute("PRAGMA table_info(assets)")
        for col in cursor.fetchall():
            print(f"   - {col['name']} ({col['type']})")
        
        print("\n" + "="*60)
        print("✓ Migration completed successfully!")
        print("="*60)
        
        return True
        
    except Exception as e:
        print(f"\n❌ Migration failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main migration execution"""
    print("="*60)
    print("SLA Portal - Add Assets Feature Migration")
    print("="*60)
    
    # Connect to database
    conn, db_path = get_db_connection(DB_PATH)
    print(f"\nDatabase: {db_path}")
    print(f"Migration: {MIGRATION_NAME}")
    print(f"Version: {MIGRATION_VERSION}")
    
    print("\nThis migration will:")
    print("  - Create 'assets' table")
    print("  - Add 'asset_id' column to 'services' table")
    print("  - Create indexes for performance")
    print("  - Establish one-to-many relationship (Asset → Services)")
    
    # Get user confirmation
    print("\n" + "-"*60)
    confirm = input("Proceed with migration? (yes/no): ").strip().lower()
    
    if confirm not in ['yes', 'y']:
        print("Migration cancelled.")
        conn.close()
        sys.exit(0)
    
    try:
        # Run migration
        migration_id = f"mig-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        success = migrate_add_assets(conn)
        
        if success:
            # Record successful migration
            record_migration(conn, migration_id, MIGRATION_NAME, MIGRATION_VERSION, 'applied')
            print(f"\n✓ Migration recorded: {migration_id}")
            
            print("\n" + "="*60)
            print("NEXT STEPS:")
            print("="*60)
            print("1. Update schema.sql with new assets table")
            print("2. Add asset API endpoints to backend")
            print("3. Create Assets frontend components")
            print("4. Add 'Assets' link to sidebar")
            print("5. Add 'Total Assets' card to dashboard")
            print("6. Restart backend and test")
            print("="*60)
        else:
            record_migration(conn, migration_id, MIGRATION_NAME, MIGRATION_VERSION, 'failed')
            print(f"\n❌ Migration failed and recorded: {migration_id}")
            sys.exit(1)
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        conn.close()
        print("\n✓ Database connection closed")

if __name__ == '__main__':
    main()