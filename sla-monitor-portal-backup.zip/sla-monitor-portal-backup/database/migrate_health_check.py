#!/usr/bin/env python3
"""
Database Migration: Add service_health_checks table
"""

import sqlite3
import sys

db_path = 'sla_portal.db'

print("=" * 80)
print("DATABASE MIGRATION: Adding service_health_checks table")
print("=" * 80)
print()

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Check if table already exists
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='service_health_checks'
    """)
    
    if cursor.fetchone():
        print("✅ service_health_checks table already exists!")
        print("   No migration needed.")
    else:
        print("⚠️  service_health_checks table is MISSING!")
        print("   Creating table...")
        
        # Create service_health_checks table
        cursor.execute("""
            CREATE TABLE service_health_checks (
                health_check_id TEXT PRIMARY KEY,
                service_id TEXT NOT NULL,
                org_id TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT,
                response_time REAL,
                checked_at TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (service_id) REFERENCES services(service_id),
                FOREIGN KEY (org_id) REFERENCES organizations(org_id)
            )
        """)
        
        # Create index for faster lookups
        cursor.execute("""
            CREATE INDEX idx_health_service_id 
            ON service_health_checks(service_id)
        """)
        
        cursor.execute("""
            CREATE INDEX idx_health_org_id 
            ON service_health_checks(org_id)
        """)
        
        conn.commit()
        
        print("✅ Successfully created service_health_checks table!")
        print("✅ Created indexes for performance")
        
        # Verify
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='service_health_checks'
        """)
        
        if cursor.fetchone():
            print("✅ Verification: Table exists")
        else:
            print("❌ ERROR: Table still missing after creation!")
            sys.exit(1)
    
    print()
    print("=" * 80)
    print("Table schema:")
    print("=" * 80)
    cursor.execute("PRAGMA table_info(service_health_checks)")
    columns = cursor.fetchall()
    
    print(f"{'Column Name':<20} {'Type':<15} {'Not Null':<10} {'Default':<15}")
    print("-" * 80)
    for col in columns:
        col_name = col[1]
        col_type = col[2]
        not_null = "YES" if col[3] == 1 else "NO"
        default = col[4] if col[4] else "NULL"
        print(f"{col_name:<20} {col_type:<15} {not_null:<10} {str(default):<15}")
    
    print()
    print("=" * 80)
    print("MIGRATION COMPLETE!")
    print("=" * 80)
    print()
    print("Next steps:")
    print("1. Update api_service.py to start health monitoring")
    print("2. Restart backend to enable health checks")
    print("3. Services will be checked every 60 seconds")
    print("4. Health status will display on Services page")
    
    conn.close()
    
except Exception as e:
    print(f"❌ ERROR: {e}")
    print()
    print("Migration failed!")
    sys.exit(1)
