#!/usr/bin/env python3
"""
Database Recovery Script
Handles cases where slas table is missing or corrupted
"""

import sqlite3
import sys
import os
from datetime import datetime

DB_PATH = '../database/sla_portal.db'

def get_db_connection(db_path):
    """Get database connection"""
    alt_paths = [
        'sla_portal.db',
        '../database/sla_portal.db',
        '../../database/sla_portal.db',
        'database/sla_portal.db'
    ]
    
    for path in [db_path] + alt_paths:
        if os.path.exists(path):
            conn = sqlite3.connect(path)
            conn.row_factory = sqlite3.Row
            return conn, path
    
    print("❌ Error: Database not found")
    sys.exit(1)

def check_table_exists(conn, table_name):
    """Check if table exists"""
    cursor = conn.cursor()
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table_name,)
    )
    return cursor.fetchone() is not None

def check_for_backup_tables(conn):
    """Check for slas_new or other backup tables"""
    cursor = conn.cursor()
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'slas%'"
    )
    tables = [row['name'] for row in cursor.fetchall()]
    return tables

def restore_from_slas_new(conn):
    """Restore slas table from slas_new if it exists"""
    print("\n" + "="*60)
    print("RECOVERY: Restore from slas_new")
    print("="*60)
    
    try:
        cursor = conn.cursor()
        
        # Check if slas_new has data
        cursor.execute("SELECT COUNT(*) as count FROM slas_new")
        count = cursor.fetchone()['count']
        
        print(f"\nFound {count} SLAs in slas_new table")
        
        if count == 0:
            print("⚠️  Warning: slas_new is empty!")
            return False
        
        # Rename slas_new to slas
        print("\nRenaming slas_new → slas...")
        
        # First, drop views if they exist
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='view' AND sql LIKE '%slas%'
        """)
        views = cursor.fetchall()
        
        view_defs = {}
        for view in views:
            view_name = view['name']
            cursor.execute(f"SELECT sql FROM sqlite_master WHERE name='{view_name}'")
            view_def = cursor.fetchone()
            if view_def:
                view_defs[view_name] = view_def['sql']
            cursor.execute(f"DROP VIEW IF EXISTS {view_name}")
        
        # Rename table
        cursor.execute("ALTER TABLE slas_new RENAME TO slas")
        conn.commit()
        print("   ✓ Table renamed successfully")
        
        # Recreate views
        if view_defs:
            print(f"\nRecreating {len(view_defs)} views...")
            for view_name, view_sql in view_defs.items():
                cursor.execute(view_sql)
                print(f"   ✓ {view_name}")
            conn.commit()
        
        # Verify
        cursor.execute("SELECT COUNT(*) as count FROM slas")
        final_count = cursor.fetchone()['count']
        print(f"\n✓ Recovery successful! {final_count} SLAs restored")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Recovery failed: {e}")
        return False

def create_slas_table_from_scratch(conn):
    """Create slas table with correct schema"""
    print("\n" + "="*60)
    print("RECOVERY: Create slas table from scratch")
    print("="*60)
    print("\n⚠️  WARNING: This will create an empty slas table")
    print("   All SLA data will be lost!")
    
    confirm = input("\nProceed? (yes/no): ").strip().lower()
    if confirm not in ['yes', 'y']:
        return False
    
    try:
        cursor = conn.cursor()
        
        # Drop views first
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='view' AND sql LIKE '%slas%'
        """)
        views = cursor.fetchall()
        
        for view in views:
            cursor.execute(f"DROP VIEW IF EXISTS {view['name']}")
        
        # Create slas table with correct schema
        cursor.execute("""
            CREATE TABLE slas (
                sla_id TEXT PRIMARY KEY,
                org_id TEXT NOT NULL,
                service_id TEXT NOT NULL,
                customer_id TEXT,
                name TEXT NOT NULL,
                description TEXT,
                metric_type TEXT NOT NULL CHECK(metric_type IN ('response_time', 'resolution_time', 'uptime', 'error_rate', 'custom')),
                target_value REAL NOT NULL,
                target_unit TEXT NOT NULL,
                priority TEXT,
                business_hours_id TEXT,
                start_condition TEXT NOT NULL,
                stop_condition TEXT NOT NULL,
                escalation_policy_id TEXT,
                effective_from TIMESTAMP NOT NULL,
                effective_until TIMESTAMP,
                version INTEGER DEFAULT 1,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by TEXT,
                metadata TEXT,
                FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
                FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
                FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL,
                FOREIGN KEY (business_hours_id) REFERENCES business_hours(business_hours_id) ON DELETE SET NULL,
                FOREIGN KEY (escalation_policy_id) REFERENCES escalation_policies(escalation_policy_id) ON DELETE SET NULL
            )
        """)
        conn.commit()
        
        print("\n✓ slas table created successfully")
        print("   ⚠️  Table is empty - you'll need to recreate SLAs")
        
        # Recreate view
        cursor.execute("""
            CREATE VIEW IF NOT EXISTS sla_compliance_summary AS
            SELECT 
                s.org_id,
                s.service_id,
                s.customer_id,
                sla.sla_id,
                COUNT(e.evaluation_id) as total_evaluations,
                SUM(CASE WHEN e.is_breach = 1 THEN 1 ELSE 0 END) as total_breaches,
                ROUND(100.0 * (COUNT(e.evaluation_id) - SUM(CASE WHEN e.is_breach = 1 THEN 1 ELSE 0 END)) / COUNT(e.evaluation_id), 2) as compliance_percentage
            FROM slas sla
            JOIN services s ON sla.service_id = s.service_id
            LEFT JOIN evaluations e ON sla.sla_id = e.sla_id
            WHERE sla.is_active = 1
            GROUP BY s.org_id, s.service_id, s.customer_id, sla.sla_id
        """)
        conn.commit()
        
        print("   ✓ Views recreated")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Failed to create table: {e}")
        return False

def main():
    """Main recovery process"""
    print("="*60)
    print("SLA Portal - Database Recovery")
    print("="*60)
    
    # Connect to database
    conn, db_path = get_db_connection(DB_PATH)
    print(f"\nDatabase: {db_path}")
    
    # Check what tables exist
    print("\nChecking database state...")
    tables = check_for_backup_tables(conn)
    print(f"Found tables: {', '.join(tables)}")
    
    slas_exists = check_table_exists(conn, 'slas')
    slas_new_exists = check_table_exists(conn, 'slas_new')
    
    print(f"\nslas table exists: {slas_exists}")
    print(f"slas_new table exists: {slas_new_exists}")
    
    # Determine recovery strategy
    if slas_new_exists and not slas_exists:
        print("\n✓ Found slas_new table - can recover data!")
        print("   This table contains your SLAs from the failed migration")
        
        proceed = input("\nRestore from slas_new? (yes/no): ").strip().lower()
        if proceed in ['yes', 'y']:
            if restore_from_slas_new(conn):
                print("\n" + "="*60)
                print("RECOVERY SUCCESSFUL!")
                print("="*60)
                print("\nNext steps:")
                print("1. Verify data: SELECT COUNT(*) FROM slas;")
                print("2. Restart backend and test")
                print("3. Migration is already complete (error_rate added)")
            else:
                print("\n❌ Recovery failed")
        
    elif slas_exists and not slas_new_exists:
        print("\n✓ slas table exists - database is OK")
        print("   You can run the migration again")
        
    elif slas_exists and slas_new_exists:
        print("\n⚠️  Both slas and slas_new exist")
        print("   This shouldn't happen - migration cleanup failed")
        
        # Show counts
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as count FROM slas")
        slas_count = cursor.fetchone()['count']
        cursor.execute("SELECT COUNT(*) as count FROM slas_new")
        slas_new_count = cursor.fetchone()['count']
        
        print(f"\n   slas: {slas_count} rows")
        print(f"   slas_new: {slas_new_count} rows")
        
        print("\nRecommendation: Drop slas_new and keep slas")
        drop = input("Drop slas_new? (yes/no): ").strip().lower()
        if drop in ['yes', 'y']:
            cursor.execute("DROP TABLE slas_new")
            conn.commit()
            print("   ✓ slas_new dropped")
        
    else:  # Neither exists
        print("\n❌ No slas table found!")
        print("   Need to create from scratch or restore from backup")
        
        # Check for backup file
        backup_paths = [
            'sla_portal.db.backup',
            '../database/sla_portal.db.backup',
            'database/sla_portal.db.backup'
        ]
        
        backup_found = None
        for backup_path in backup_paths:
            if os.path.exists(backup_path):
                backup_found = backup_path
                break
        
        if backup_found:
            print(f"\n✓ Found backup: {backup_found}")
            print("\nOptions:")
            print("1. Restore from backup (recommended)")
            print("2. Create empty table")
            
            choice = input("\nChoice (1/2): ").strip()
            if choice == '1':
                print("\nTo restore from backup:")
                print(f"1. Close this database connection")
                print(f"2. Copy: {backup_found} → {db_path}")
                print(f"3. Run migration again")
            elif choice == '2':
                create_slas_table_from_scratch(conn)
        else:
            print("\n⚠️  No backup found")
            create_slas_table_from_scratch(conn)
    
    conn.close()
    print("\n✓ Database connection closed")

if __name__ == '__main__':
    main()
