#!/usr/bin/env python3
"""
Service Metadata Diagnostic Script
Check why specific service has no configuration
"""

import sqlite3
import json
import sys

# Get service ID from command line
if len(sys.argv) < 2:
    print("Usage: python diagnose_service.py <service_id>")
    print("Example: python diagnose_service.py svc-abc123")
    print()
    print("Or run without arguments to see all services:")
    sys.exit(1)

service_id = sys.argv[1] if len(sys.argv) > 1 else None

# Connect to database
conn = sqlite3.connect('sla_portal.db')
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

print("=" * 80)
print("SERVICE METADATA DIAGNOSTIC")
print("=" * 80)
print()

if not service_id:
    # Show all services
    print("ALL SERVICES:")
    print("-" * 80)
    cursor.execute("""
        SELECT service_id, name, 
               CASE WHEN metadata IS NULL THEN 'NULL'
                    WHEN metadata = '' THEN 'EMPTY'
                    WHEN metadata = '{}' THEN 'EMPTY OBJECT'
                    ELSE 'HAS DATA'
               END as metadata_status
        FROM services
        ORDER BY created_at DESC
    """)
    
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            print(f"Service ID: {row['service_id']}")
            print(f"Name: {row['name']}")
            print(f"Metadata: {row['metadata_status']}")
            print("-" * 80)
    else:
        print("No services found")
    
    conn.close()
    sys.exit(0)

# Check specific service
print(f"Checking service: {service_id}")
print("-" * 80)

cursor.execute("""
    SELECT service_id, org_id, name, description, owner_team, 
           tags, metadata, is_active, created_at, updated_at
    FROM services 
    WHERE service_id = ?
""", (service_id,))

row = cursor.fetchone()

if not row:
    print(f"❌ Service {service_id} not found in database!")
    conn.close()
    sys.exit(1)

print(f"✅ Service found: {row['name']}")
print()

# Check each field
print("FIELD VALUES:")
print("-" * 80)
print(f"Service ID: {row['service_id']}")
print(f"Org ID: {row['org_id']}")
print(f"Name: {row['name']}")
print(f"Description: {row['description']}")
print(f"Owner Team: {row['owner_team']}")
print(f"Is Active: {row['is_active']}")
print(f"Created: {row['created_at']}")
print(f"Updated: {row['updated_at']}")
print()

# Check tags
print("TAGS:")
print("-" * 80)
tags_raw = row['tags']
if tags_raw:
    try:
        tags = json.loads(tags_raw)
        print(f"Tags (parsed): {tags}")
    except Exception as e:
        print(f"❌ Tags parsing error: {e}")
        print(f"Tags (raw): {tags_raw}")
else:
    print("Tags: NULL or empty")
print()

# Check metadata - THE CRITICAL PART
print("METADATA:")
print("-" * 80)
metadata_raw = row['metadata']

if metadata_raw is None:
    print("❌ PROBLEM: metadata is NULL")
    print("   The metadata column exists but contains NULL")
    print("   This means the service was created WITHOUT metadata")
elif metadata_raw == '':
    print("❌ PROBLEM: metadata is empty string")
    print("   The metadata column exists but is empty")
elif metadata_raw == '{}':
    print("⚠️  PROBLEM: metadata is empty JSON object")
    print("   The metadata column has '{}' - no service_type or config")
else:
    print(f"Metadata (raw): {metadata_raw}")
    print()
    
    try:
        metadata = json.loads(metadata_raw)
        print("Metadata (parsed):")
        print(json.dumps(metadata, indent=2))
        print()
        
        # Check required fields
        if 'service_type' not in metadata:
            print("❌ PROBLEM: Missing 'service_type' in metadata")
            print("   Result: Service Type will show 'Unknown'")
        else:
            print(f"✅ Service Type: {metadata['service_type']}")
        
        if 'config' not in metadata:
            print("❌ PROBLEM: Missing 'config' in metadata")
            print("   Result: Configuration will show 'No configuration available'")
        else:
            print(f"✅ Config: {metadata['config']}")
            
    except Exception as e:
        print(f"❌ PROBLEM: Cannot parse metadata JSON")
        print(f"   Error: {e}")
        print(f"   Raw value: {metadata_raw}")

print()
print("=" * 80)
print("DIAGNOSIS COMPLETE")
print("=" * 80)
print()

# Provide recommendations
if metadata_raw is None or metadata_raw == '' or metadata_raw == '{}':
    print("RECOMMENDATIONS:")
    print("-" * 80)
    print("This service was created WITHOUT proper metadata.")
    print()
    print("You have 3 options:")
    print()
    print("Option 1: Delete and recreate the service")
    print("  DELETE FROM services WHERE service_id = '" + service_id + "';")
    print("  Then create a new service through the UI with all fixes in place")
    print()
    print("Option 2: Manually update the metadata")
    print("  UPDATE services")
    print("  SET metadata = '{\"service_type\":\"apache\",\"config\":{\"url\":\"http://localhost:8080\",\"status_endpoint\":\"/server-status\"}}'")
    print("  WHERE service_id = '" + service_id + "';")
    print()
    print("Option 3: Keep as-is (not recommended)")
    print("  The service will continue to show 'Unknown' and no configuration")
    print()
    print("RECOMMENDED: Option 1 - Delete and recreate with fixed backend")
    print()
    print("Make sure you have these fixes in place BEFORE recreating:")
    print("  1. Database has metadata column (run migrate_database.py)")
    print("  2. Backend uses api_service.py v10 (saves metadata)")
    print("  3. Backend uses database_service.py v4 (saves and parses metadata)")

conn.close()
