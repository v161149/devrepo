#!/usr/bin/env python3
"""
Database Migration Script
Add metadata column to services table
"""

import sqlite3
import sys

db_path = 'sla_portal.db'

print("=" * 80)
print("DATABASE MIGRATION: Adding metadata column to services table")
print("=" * 80)
print()

try:
    # Connect to database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Check if metadata column exists
    cursor.execute("PRAGMA table_info(services)")
    columns = cursor.fetchall()
    column_names = [col[1] for col in columns]
    
    print("Current columns in services table:")
    for col in column_names:
        print(f"  - {col}")
    print()
    
    if 'metadata' in column_names:
        print("✅ metadata column already exists!")
        print("   No migration needed.")
    else:
        print("⚠️  metadata column is MISSING!")
        print("   Adding metadata column...")
        
        # Add metadata column
        cursor.execute("""
            ALTER TABLE services 
            ADD COLUMN metadata TEXT
        """)
        
        conn.commit()
        
        print("✅ Successfully added metadata column!")
        print()
        
        # Verify
        cursor.execute("PRAGMA table_info(services)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        if 'metadata' in column_names:
            print("✅ Verification: metadata column now exists")
        else:
            print("❌ ERROR: metadata column still missing after migration!")
            sys.exit(1)
    
    print()
    print("=" * 80)
    print("Current services table schema:")
    print("=" * 80)
    cursor.execute("PRAGMA table_info(services)")
    columns = cursor.fetchall()
    
    print(f"{'Column Name':<20} {'Type':<15} {'Not Null':<10} {'Default':<15}")
    print("-" * 80)
    for col in columns:
        col_name = col[1]
        col_type = col[2]
        not_null = "YES" if col[3] == 1 else "NO"
        default = col[4] if col[4] else "NULL"
        print(f"{col_name:<20} {col_type:<15} {not_null:<10} {str(default):<15}")
    
    print()
    print("=" * 80)
    print("MIGRATION COMPLETE!")
    print("=" * 80)
    print()
    print("Next steps:")
    print("1. Restart your backend: python api_service.py")
    print("2. Create a new service to test")
    print("3. The metadata column will now be populated")
    
    conn.close()
    
except Exception as e:
    print(f"❌ ERROR: {e}")
    print()
    print("Migration failed!")
    sys.exit(1)
