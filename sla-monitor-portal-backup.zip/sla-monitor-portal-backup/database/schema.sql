-- SLA Monitoring Portal - Database Schema
-- SQLite Database Design

-- Enable foreign keys
PRAGMA foreign_keys = ON;

-- Organizations/Tenants Table
CREATE TABLE IF NOT EXISTS organizations (
    org_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    settings TEXT, -- JSON field for org-level settings
    data_retention_days INTEGER DEFAULT 90,
    is_active BOOLEAN DEFAULT 1
);

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('Admin', 'ServiceManager', 'SupportAgent', 'Viewer', 'ExternalCustomer')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT 1,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

CREATE INDEX idx_users_org ON users(org_id);
CREATE INDEX idx_users_email ON users(email);

-- Customers Table
CREATE TABLE IF NOT EXISTS customers (
    customer_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    name TEXT NOT NULL,
    contact_email TEXT,
    contact_phone TEXT,
    tier TEXT, -- Silver, Gold, Platinum
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata TEXT, -- JSON field
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

CREATE INDEX idx_customers_org ON customers(org_id);

-- Assets Table
CREATE TABLE assets (
    asset_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    asset_name TEXT NOT NULL,
    asset_type TEXT NOT NULL,
    asset_owner TEXT,
    description TEXT,
    onboarded_date TIMESTAMP NOT NULL,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata TEXT
);

-- Services Table
CREATE TABLE IF NOT EXISTS services (
    service_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    customer_id TEXT,
    name TEXT NOT NULL,
    description TEXT,
    owner_team TEXT,
    tags TEXT, -- JSON array
    metadata TEXT, -- JSON field
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT 1,
    asset_id TEXT, 
    monitoring_method TEXT DEFAULT 'direct',
    deployment_location TEXT, -- autosys, airflow, ansible_tower
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

CREATE INDEX idx_services_org ON services(org_id);
CREATE INDEX idx_services_customer ON services(customer_id);
CREATE INDEX idx_services_asset_id ON services(asset_id);

-- Business Hours Calendar
CREATE TABLE IF NOT EXISTS business_hours (
    business_hours_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    name TEXT NOT NULL,
    timezone TEXT NOT NULL,
    monday_start TEXT,
    monday_end TEXT,
    tuesday_start TEXT,
    tuesday_end TEXT,
    wednesday_start TEXT,
    wednesday_end TEXT,
    thursday_start TEXT,
    thursday_end TEXT,
    friday_start TEXT,
    friday_end TEXT,
    saturday_start TEXT,
    saturday_end TEXT,
    sunday_start TEXT,
    sunday_end TEXT,
    holidays TEXT, -- JSON array of holiday dates
    blackout_windows TEXT, -- JSON array of maintenance windows
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

-- Escalation Policies
CREATE TABLE IF NOT EXISTS escalation_policies (
    escalation_policy_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    name TEXT NOT NULL,
    levels TEXT NOT NULL, -- JSON array of escalation levels
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

-- SLA Definitions
CREATE TABLE IF NOT EXISTS slas (
    sla_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    service_id TEXT NOT NULL,
    customer_id TEXT,
    name TEXT NOT NULL,
    metric_type TEXT NOT NULL CHECK(metric_type IN ('response_time', 'resolution_time', 'uptime', 'custom')),
    target_value REAL NOT NULL,
    target_unit TEXT NOT NULL, -- minutes, hours, percentage
    priority TEXT, -- P1, P2, P3, P4
    business_hours_id TEXT,
    start_condition TEXT NOT NULL, -- JSON rule
    stop_condition TEXT NOT NULL, -- JSON rule
    escalation_policy_id TEXT,
    effective_from TIMESTAMP NOT NULL,
    effective_until TIMESTAMP,
    version INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    metadata TEXT, -- JSON field
    description TEXT,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL,
    FOREIGN KEY (business_hours_id) REFERENCES business_hours(business_hours_id) ON DELETE SET NULL,
    FOREIGN KEY (escalation_policy_id) REFERENCES escalation_policies(escalation_policy_id) ON DELETE SET NULL
);

CREATE INDEX idx_slas_org ON slas(org_id);
CREATE INDEX idx_slas_service ON slas(service_id);
CREATE INDEX idx_slas_customer ON slas(customer_id);
CREATE INDEX idx_slas_effective ON slas(effective_from, effective_until);

-- Service Monitoring Log Table
CREATE TABLE service_monitoring_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id TEXT NOT NULL,
    asset_name TEXT,
    service_id TEXT NOT NULL,
    service_name TEXT,
    job_name TEXT,
    job_type TEXT,
    deployment_location TEXT,
    job_schedule TEXT,
    scheduled_execution_date TEXT NOT NULL,
    scheduled_start_time TEXT NOT NULL,
    scheduled_end_time TEXT NOT NULL,
    scheduled_execution_duration TEXT,
    start_time TEXT,
    end_time TEXT,
    on_time_ind TEXT DEFAULT 'Unknown',
    creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(asset_id),
    FOREIGN KEY (service_id) REFERENCES services(service_id),
    UNIQUE(asset_id, service_id, job_name, job_type, scheduled_execution_date, scheduled_start_time, scheduled_end_time)
);

CREATE INDEX idx_sml_service_id ON service_monitoring_log(service_id);
CREATE INDEX idx_sml_asset_id ON service_monitoring_log(asset_id);
CREATE INDEX idx_sml_scheduled_start_time ON service_monitoring_log(scheduled_start_time);
CREATE INDEX idx_sml_scheduled_execution_date ON service_monitoring_log(scheduled_execution_date);
CREATE INDEX idx_sml_on_time_ind ON service_monitoring_log(on_time_ind);

-- Events Table (Raw telemetry and ticket data)
CREATE TABLE IF NOT EXISTS events (
    event_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    service_id TEXT NOT NULL,
    customer_id TEXT,
    timestamp TIMESTAMP NOT NULL,
    event_type TEXT NOT NULL, -- incident.created, incident.resolved, metric.datapoint, uptime.check, ticket.update
    status TEXT,
    priority TEXT,
    duration REAL, -- in seconds
    source TEXT, -- datadog, prometheus, servicenow, jira, etc.
    payload TEXT NOT NULL, -- JSON with original data
    normalized_data TEXT, -- JSON with normalized common fields
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

CREATE INDEX idx_events_org ON events(org_id);
CREATE INDEX idx_events_service ON events(service_id);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_events_type ON events(event_type);

-- SLA Evaluations
CREATE TABLE IF NOT EXISTS evaluations (
    evaluation_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    sla_id TEXT NOT NULL,
    event_id TEXT,
    service_id TEXT NOT NULL,
    customer_id TEXT,
    start_timestamp TIMESTAMP NOT NULL,
    stop_timestamp TIMESTAMP,
    total_duration REAL, -- in seconds
    business_duration REAL, -- in seconds (excluding non-business hours)
    is_breach BOOLEAN DEFAULT 0,
    breach_percentage REAL,
    status TEXT CHECK(status IN ('active', 'paused', 'completed', 'breached')),
    details TEXT, -- JSON with evaluation details
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (sla_id) REFERENCES slas(sla_id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

CREATE INDEX idx_evaluations_org ON evaluations(org_id);
CREATE INDEX idx_evaluations_sla ON evaluations(sla_id);
CREATE INDEX idx_evaluations_service ON evaluations(service_id);
CREATE INDEX idx_evaluations_timestamps ON evaluations(start_timestamp, stop_timestamp);
CREATE INDEX idx_evaluations_breach ON evaluations(is_breach);

-- Alerts
CREATE TABLE IF NOT EXISTS alerts (
    alert_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    evaluation_id TEXT NOT NULL,
    sla_id TEXT NOT NULL,
    service_id TEXT NOT NULL,
    alert_type TEXT NOT NULL CHECK(alert_type IN ('breach', 'warning', 'predicted_breach', 'degraded')),
    severity TEXT NOT NULL CHECK(severity IN ('critical', 'high', 'medium', 'low')),
    message TEXT NOT NULL,
    channels TEXT NOT NULL, -- JSON array: ['email', 'slack', 'pagerduty']
    sent_timestamp TIMESTAMP,
    status TEXT CHECK(status IN ('pending', 'sent', 'failed', 'acknowledged')),
    acknowledged_by TEXT,
    acknowledged_at TIMESTAMP,
    metadata TEXT, -- JSON field
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (evaluation_id) REFERENCES evaluations(evaluation_id) ON DELETE CASCADE,
    FOREIGN KEY (sla_id) REFERENCES slas(sla_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE
);

CREATE INDEX idx_alerts_org ON alerts(org_id);
CREATE INDEX idx_alerts_status ON alerts(status);
CREATE INDEX idx_alerts_created ON alerts(created_at);

-- Notification History
CREATE TABLE IF NOT EXISTS notifications (
    notification_id TEXT PRIMARY KEY,
    alert_id TEXT NOT NULL,
    channel TEXT NOT NULL, -- email, slack, pagerduty, teams, webhook
    recipient TEXT NOT NULL,
    status TEXT CHECK(status IN ('pending', 'sent', 'failed', 'retrying')),
    sent_at TIMESTAMP,
    response TEXT, -- API response from notification service
    retry_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (alert_id) REFERENCES alerts(alert_id) ON DELETE CASCADE
);

CREATE INDEX idx_notifications_alert ON notifications(alert_id);
CREATE INDEX idx_notifications_status ON notifications(status);

-- Integration Configurations
CREATE TABLE IF NOT EXISTS integrations (
    integration_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL, -- datadog, prometheus, jira, servicenow, slack, pagerduty, etc.
    config TEXT NOT NULL, -- JSON with API keys, webhooks, etc. (encrypted)
    is_active BOOLEAN DEFAULT 1,
    last_sync TIMESTAMP,
    sync_status TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

CREATE INDEX idx_integrations_org ON integrations(org_id);
CREATE INDEX idx_integrations_type ON integrations(type);

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    user_id TEXT,
    action TEXT NOT NULL,
    resource_type TEXT, -- sla, service, user, integration, etc.
    resource_id TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address TEXT,
    user_agent TEXT,
    changes TEXT, -- JSON with before/after values
    metadata TEXT, -- JSON field
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

CREATE INDEX idx_audit_org ON audit_logs(org_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_resource ON audit_logs(resource_type, resource_id);

-- Metrics Aggregations (for performance)
CREATE TABLE IF NOT EXISTS metrics_aggregations (
    aggregation_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    service_id TEXT NOT NULL,
    customer_id TEXT,
    period_start TIMESTAMP NOT NULL,
    period_end TIMESTAMP NOT NULL,
    period_type TEXT NOT NULL CHECK(period_type IN ('hourly', 'daily', 'weekly', 'monthly')),
    total_events INTEGER DEFAULT 0,
    total_breaches INTEGER DEFAULT 0,
    compliance_percentage REAL,
    mttr REAL, -- Mean Time To Resolution in seconds
    response_time_p50 REAL,
    response_time_p95 REAL,
    response_time_p99 REAL,
    uptime_percentage REAL,
    metrics TEXT, -- JSON with detailed metrics
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

CREATE INDEX idx_metrics_org ON metrics_aggregations(org_id);
CREATE INDEX idx_metrics_service ON metrics_aggregations(service_id);
CREATE INDEX idx_metrics_period ON metrics_aggregations(period_start, period_end);
CREATE INDEX idx_metrics_type ON metrics_aggregations(period_type);

-- Reports
CREATE TABLE IF NOT EXISTS reports (
    report_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    name TEXT NOT NULL,
    report_type TEXT NOT NULL CHECK(report_type IN ('sla_compliance', 'breach_analysis', 'trend', 'custom')),
    parameters TEXT NOT NULL, -- JSON with report parameters
    generated_by TEXT,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    file_path TEXT,
    status TEXT CHECK(status IN ('pending', 'processing', 'completed', 'failed')),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

CREATE INDEX idx_reports_org ON reports(org_id);
CREATE INDEX idx_reports_generated ON reports(generated_at);

-- Webhooks Configuration
CREATE TABLE IF NOT EXISTS webhooks (
    webhook_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    events TEXT NOT NULL, -- JSON array of event types to trigger
    secret TEXT, -- for signature verification
    is_active BOOLEAN DEFAULT 1,
    retry_policy TEXT, -- JSON with retry configuration
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

CREATE INDEX idx_webhooks_org ON webhooks(org_id);

-- Sessions (for authentication)
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    token TEXT UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address TEXT,
    user_agent TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_sessions_token ON sessions(token);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- Status Pages
CREATE TABLE IF NOT EXISTS status_pages (
    page_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    customer_id TEXT,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    services TEXT NOT NULL, -- JSON array of service_ids
    is_public BOOLEAN DEFAULT 1,
    custom_domain TEXT,
    branding TEXT, -- JSON with logo, colors, etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

CREATE INDEX idx_status_pages_org ON status_pages(org_id);
CREATE INDEX idx_status_pages_slug ON status_pages(slug);

-- Create views for common queries
CREATE VIEW IF NOT EXISTS sla_compliance_summary AS
SELECT 
    s.org_id,
    s.service_id,
    s.customer_id,
    sla.sla_id,
    COUNT(e.evaluation_id) as total_evaluations,
    SUM(CASE WHEN e.is_breach = 1 THEN 1 ELSE 0 END) as total_breaches,
    ROUND(100.0 * (COUNT(e.evaluation_id) - SUM(CASE WHEN e.is_breach = 1 THEN 1 ELSE 0 END)) / COUNT(e.evaluation_id), 2) as compliance_percentage
FROM slas sla
JOIN services s ON sla.service_id = s.service_id
LEFT JOIN evaluations e ON sla.sla_id = e.sla_id
WHERE sla.is_active = 1
GROUP BY s.org_id, s.service_id, s.customer_id, sla.sla_id;

-- Indexes for performance optimization
CREATE INDEX IF NOT EXISTS idx_events_org_timestamp ON events(org_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_evaluations_sla_timestamp ON evaluations(sla_id, start_timestamp DESC);
