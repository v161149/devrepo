"""
Database Migration: Add execution_time to metadata for existing ETL jobs
NO SCHEMA CHANGES - Only updates metadata JSON for existing services
"""

import sqlite3
import json
import sys

def update_etl_metadata(db_path):
    """Add execution_time to metadata for existing ETL jobs"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("Finding existing ETL jobs...")
        
        # Find ETL jobs by checking metadata for service_type = 'etl_batch'
        cursor.execute("""
            SELECT service_id, name, metadata 
            FROM services 
            WHERE metadata LIKE '%etl_batch%'
        """)
        
        etl_jobs = cursor.fetchall()
        updated_count = 0
        
        if not etl_jobs:
            print("  No ETL jobs found in database")
            return
        
        print(f"  Found {len(etl_jobs)} ETL job(s)")
        print("\nUpdating metadata with execution_time (00:30:00)...")
        
        for service_id, name, metadata_str in etl_jobs:
            # Parse existing metadata
            try:
                metadata = json.loads(metadata_str) if metadata_str else {}
            except json.JSONDecodeError:
                print(f"  ⚠ Skipping {name} - invalid metadata JSON")
                continue
            
            # Check if execution_time already exists
            if 'execution_time' in metadata and metadata['execution_time']:
                print(f"  ⊙ Skipped: {name} (already has execution_time: {metadata['execution_time']})")
                continue
            
            # Add execution_time to metadata
            metadata['execution_time'] = '00:30:00'
            
            # Update the service
            cursor.execute("""
                UPDATE services 
                SET metadata = ? 
                WHERE service_id = ?
            """, (json.dumps(metadata), service_id))
            
            print(f"  ✓ Updated: {name} ({service_id})")
            updated_count += 1
        
        conn.commit()
        
        print(f"\n✓ Updated {updated_count} ETL job(s) with default execution time")
        
        # Verify the changes
        print("\nVerifying updates...")
        cursor.execute("""
            SELECT service_id, name, metadata 
            FROM services 
            WHERE metadata LIKE '%etl_batch%'
        """)
        
        verified_count = 0
        for service_id, name, metadata_str in cursor.fetchall():
            metadata = json.loads(metadata_str) if metadata_str else {}
            if 'execution_time' in metadata:
                verified_count += 1
                print(f"  ✓ {name}: {metadata['execution_time']}")
            else:
                print(f"  ✗ {name}: Missing execution_time")
        
        print(f"\n✓ Verified: {verified_count}/{len(etl_jobs)} ETL jobs have execution_time")
        
        # Show sample metadata structure
        if etl_jobs:
            print("\nSample ETL job metadata structure:")
            cursor.execute("""
                SELECT name, metadata 
                FROM services 
                WHERE metadata LIKE '%etl_batch%'
                LIMIT 1
            """)
            sample_name, sample_metadata = cursor.fetchone()
            metadata = json.loads(sample_metadata)
            print(f"  Service: {sample_name}")
            print(f"  Metadata: {json.dumps(metadata, indent=2)}")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db'
    ]
    
    found_db = False
    for db_path in databases:
        try:
            print(f"\n{'='*70}")
            print(f"Migrating: {db_path}")
            print('='*70)
            update_etl_metadata(db_path)
            found_db = True
        except FileNotFoundError:
            print(f"Database not found: {db_path} (skipping)")
    
    if not found_db:
        print("\n✗ No database found! Please ensure sla_portal.db exists.")
        sys.exit(1)
    
    print(f"\n{'='*70}")
    print("Migration complete!")
    print('='*70)
    print("\nWhat was updated:")
    print("  - NO schema changes (no new columns)")
    print("  - Updated metadata JSON for ETL jobs")
    print("  - Added 'execution_time': '00:30:00' to metadata")
    print("\nMetadata structure:")
    print("  {")
    print('    "service_type": "etl_batch",')
    print('    "service_category": "data",')
    print('    "monitoring_method": "direct",')
    print('    "deployment_location": "autosys",')
    print('    "execution_time": "00:30:00",  ← ADDED')
    print('    "config": {...}')
    print("  }")
    print("\nNext steps:")
    print("  1. Replace frontend components (AddServiceModal, ServiceDetails)")
    print("  2. Restart frontend (backend unchanged!)")
    print("  3. Refresh browser and test")
    print("\nNote: Backend needs NO changes - already handles metadata!")
