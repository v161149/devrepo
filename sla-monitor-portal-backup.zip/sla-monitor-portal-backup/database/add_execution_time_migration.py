"""
Database Migration: Add execution_time column to services table
Run this script to add execution_time field for ETL jobs with default 30 minutes
"""

import sqlite3
import sys

def add_execution_time_column(db_path):
    """Add execution_time column to services table and set defaults for existing ETL jobs"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column already exists
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'execution_time' in columns:
            print("✓ execution_time column already exists in services table")
        else:
            # Add the new column
            print("Adding execution_time column to services table...")
            cursor.execute("""
                ALTER TABLE services 
                ADD COLUMN execution_time TEXT
            """)
            
            conn.commit()
            print("✓ Successfully added execution_time column")
            print("  - Column type: TEXT")
            print("  - Format: HH:MM:SS or HH:MM:SS.SSS")
            print("  - Nullable: Yes")
        
        # Set default execution_time for existing ETL jobs (service_type = 'etl_batch')
        print("\nUpdating existing ETL jobs with default execution time (00:30:00)...")
        
        # Find ETL jobs by checking metadata for service_type = 'etl_batch'
        cursor.execute("""
            SELECT service_id, name, metadata 
            FROM services 
            WHERE metadata LIKE '%etl_batch%'
        """)
        
        etl_jobs = cursor.fetchall()
        updated_count = 0
        
        for service_id, name, metadata in etl_jobs:
            # Only update if execution_time is NULL
            cursor.execute("""
                UPDATE services 
                SET execution_time = '00:30:00' 
                WHERE service_id = ? 
                  AND (execution_time IS NULL OR execution_time = '')
            """, (service_id,))
            
            if cursor.rowcount > 0:
                print(f"  ✓ Updated service: {name} ({service_id})")
                updated_count += 1
        
        conn.commit()
        
        print(f"\n✓ Updated {updated_count} ETL job(s) with default execution time")
        
        # Verify the changes
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'execution_time' in columns:
            print("✓ Column verified in database schema")
        
        # Show statistics
        cursor.execute("""
            SELECT COUNT(*) 
            FROM services 
            WHERE execution_time IS NOT NULL AND execution_time != ''
        """)
        with_time_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM services")
        total_count = cursor.fetchone()[0]
        
        print(f"\nServices Statistics:")
        print(f"  - Total services: {total_count}")
        print(f"  - Services with execution time: {with_time_count}")
        print(f"  - Services without execution time: {total_count - with_time_count}")
        
        # Show sample ETL jobs with execution time
        print(f"\nSample ETL jobs with execution time:")
        cursor.execute("""
            SELECT service_id, name, execution_time
            FROM services
            WHERE metadata LIKE '%etl_batch%'
            LIMIT 5
        """)
        
        for service_id, name, exec_time in cursor.fetchall():
            print(f"  - {name}: {exec_time or 'Not set'}")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db'
    ]
    
    for db_path in databases:
        try:
            print(f"\n{'='*70}")
            print(f"Migrating: {db_path}")
            print('='*70)
            add_execution_time_column(db_path)
        except FileNotFoundError:
            print(f"Database not found: {db_path} (skipping)")
    
    print(f"\n{'='*70}")
    print("Migration complete!")
    print('='*70)
    print("\nExecution Time Feature:")
    print("  - Column: execution_time (TEXT)")
    print("  - Format: HH:MM:SS or HH:MM:SS.SSS")
    print("  - Default: 00:30:00 (30 minutes)")
    print("  - Examples: '00:03:15', '01:30:00', '00:00:00.500'")
    print("  - Used for: ETL batch jobs")
    print("\nNext steps:")
    print("  1. Replace frontend components (AddServiceModal, ServiceDetails)")
    print("  2. Replace backend files (api_service.py, database_service.py)")
    print("  3. Restart backend server")
    print("  4. Refresh browser and test")
