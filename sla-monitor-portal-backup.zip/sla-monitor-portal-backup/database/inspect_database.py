#!/usr/bin/env python3
"""
Database Inspection Script
Check what's actually in the services table
"""

import sqlite3
import json
import sys

# Connect to database
conn = sqlite3.connect('../database/sla_portal.db')
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

print("=" * 80)
print("SERVICES TABLE INSPECTION")
print("=" * 80)
print()

# Check if metadata column exists
print("0. CHECKING TABLE SCHEMA:")
print("-" * 80)
cursor.execute("PRAGMA table_info(services)")
columns = cursor.fetchall()
column_names = [col[1] for col in columns]

print("Columns in services table:")
for col in column_names:
    print(f"  - {col}")
print()

has_metadata = 'metadata' in column_names

if not has_metadata:
    print("❌ ERROR: metadata column is MISSING!")
    print()
    print("The services table does not have a metadata column.")
    print("You need to run the migration script first:")
    print()
    print("  python migrate_database.py")
    print()
    print("=" * 80)
    conn.close()
    sys.exit(1)

print("✅ metadata column exists")
print()

# Get all services (including inactive)
print("1. ALL SERVICES (including is_active=0):")
print("-" * 80)
cursor.execute("SELECT service_id, name, org_id, is_active, metadata, created_at FROM services")
rows = cursor.fetchall()

if rows:
    for row in rows:
        print(f"Service ID: {row['service_id']}")
        print(f"Name: {row['name']}")
        print(f"Org ID: {row['org_id']}")
        print(f"Is Active: {row['is_active']}")
        print(f"Created: {row['created_at']}")
        
        # Parse metadata
        metadata = row['metadata']
        if metadata:
            try:
                parsed = json.loads(metadata)
                print(f"Service Type: {parsed.get('service_type', 'N/A')}")
                print(f"Config: {parsed.get('config', {})}")
            except:
                print(f"Metadata (raw): {metadata}")
        print("-" * 80)
else:
    print("NO SERVICES FOUND")
print()

# Count by is_active
print("2. SERVICE COUNTS BY is_active:")
print("-" * 80)
cursor.execute("SELECT is_active, COUNT(*) as count FROM services GROUP BY is_active")
counts = cursor.fetchall()
for row in counts:
    status = "Active" if row['is_active'] == 1 else "Inactive"
    print(f"{status} (is_active={row['is_active']}): {row['count']} services")
print()

# Count by org_id
print("3. SERVICE COUNTS BY org_id:")
print("-" * 80)
cursor.execute("SELECT org_id, COUNT(*) as count FROM services GROUP BY org_id")
orgs = cursor.fetchall()
for row in orgs:
    print(f"Org {row['org_id']}: {row['count']} services")
print()

# Check for NULL metadata
print("4. SERVICES WITH NULL METADATA:")
print("-" * 80)
cursor.execute("SELECT service_id, name, metadata FROM services WHERE metadata IS NULL")
null_metadata = cursor.fetchall()
if null_metadata:
    for row in null_metadata:
        print(f"Service: {row['service_id']} - {row['name']} - metadata: NULL")
else:
    print("All services have metadata")
print()

# Check for malformed metadata
print("5. CHECKING METADATA FORMAT:")
print("-" * 80)
cursor.execute("SELECT service_id, name, metadata FROM services WHERE metadata IS NOT NULL")
metadata_rows = cursor.fetchall()
for row in metadata_rows:
    try:
        parsed = json.loads(row['metadata'])
        if 'service_type' not in parsed:
            print(f"⚠️  Service {row['service_id']} - {row['name']}: Missing service_type in metadata")
        if 'config' not in parsed:
            print(f"⚠️  Service {row['service_id']} - {row['name']}: Missing config in metadata")
    except Exception as e:
        print(f"❌ Service {row['service_id']} - {row['name']}: Invalid JSON - {e}")
        print(f"   Raw metadata: {row['metadata']}")
print()

# Recommendations
print("=" * 80)
print("RECOMMENDATIONS:")
print("=" * 80)

# Check if there are inactive services
cursor.execute("SELECT COUNT(*) as count FROM services WHERE is_active = 0")
inactive_count = cursor.fetchone()['count']
if inactive_count > 0:
    print(f"⚠️  You have {inactive_count} inactive services (is_active=0)")
    print("   These won't show in the services list but count in the dashboard")
    print("   To fix: DELETE FROM services WHERE is_active = 0;")
    print()

# Check if there are services with NULL metadata
cursor.execute("SELECT COUNT(*) as count FROM services WHERE metadata IS NULL")
null_count = cursor.fetchone()['count']
if null_count > 0:
    print(f"⚠️  You have {null_count} services with NULL metadata")
    print("   These will show 'Unknown' service type and blank configuration")
    print("   To fix: DELETE FROM services WHERE metadata IS NULL;")
    print()

cursor.execute("SELECT COUNT(*) as count FROM services WHERE is_active = 1")
active_count = cursor.fetchone()['count']
print(f"✅ Total active services: {active_count}")

conn.close()
print()
print("=" * 80)
print("INSPECTION COMPLETE")
print("=" * 80)
