"""
Database Migration: Add is_active column to slas table for soft delete
Run this script to add the is_active column for activate/deactivate functionality
"""

import sqlite3
import sys

def add_is_active_to_slas(db_path):
    """Add is_active column to slas table"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column already exists
        cursor.execute("PRAGMA table_info(slas)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'is_active' in columns:
            print("✓ is_active column already exists in slas table")
        else:
            # Add the new column
            print("Adding is_active column to slas table...")
            cursor.execute("""
                ALTER TABLE slas 
                ADD COLUMN is_active BOOLEAN DEFAULT 1
            """)
            
            # Set all existing SLAs to active
            cursor.execute("""
                UPDATE slas 
                SET is_active = 1 
                WHERE is_active IS NULL
            """)
            
            conn.commit()
            print("✓ Successfully added is_active column")
            print("  - Default value: 1 (active)")
            print("  - All existing SLAs set to active")
        
        # Verify the change
        cursor.execute("PRAGMA table_info(slas)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'is_active' in columns:
            print("✓ Column verified in database schema")
        
        # Show current SLA status
        cursor.execute("SELECT COUNT(*) FROM slas WHERE is_active = 1")
        active_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM slas WHERE is_active = 0")
        inactive_count = cursor.fetchone()[0]
        
        print(f"\nCurrent SLA Status:")
        print(f"  - Active SLAs: {active_count}")
        print(f"  - Inactive SLAs: {inactive_count}")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db'
    ]
    
    for db_path in databases:
        try:
            print(f"\n{'='*60}")
            print(f"Migrating: {db_path}")
            print('='*60)
            add_is_active_to_slas(db_path)
        except FileNotFoundError:
            print(f"Database not found: {db_path} (skipping)")
    
    print(f"\n{'='*60}")
    print("Migration complete!")
    print('='*60)
    print("\nSoft Delete Functionality:")
    print("  - Deactivate: Sets is_active = 0 (keeps data)")
    print("  - Activate: Sets is_active = 1 (restores)")
    print("  - Delete: Permanently removes record")
