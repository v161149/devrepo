"""
Database Migration: Add deployment_location column to services table
Run this script to add the new deployment_location column
"""

import sqlite3
import sys

def add_deployment_location_column(db_path):
    """Add deployment_location column to services table"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column already exists
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'deployment_location' in columns:
            print("✓ deployment_location column already exists")
            return
        
        # Add the new column
        print("Adding deployment_location column...")
        cursor.execute("""
            ALTER TABLE services 
            ADD COLUMN deployment_location TEXT
        """)
        
        conn.commit()
        print("✓ Successfully added deployment_location column")
        print("  - Column allows NULL values (optional field)")
        print("  - Valid values: 'autosys', 'airflow', 'ansible_tower'")
        
        # Verify the change
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'deployment_location' in columns:
            print("✓ Column verified in database schema")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db'
    ]
    
    for db_path in databases:
        try:
            print(f"\n{'='*60}")
            print(f"Migrating: {db_path}")
            print('='*60)
            add_deployment_location_column(db_path)
        except FileNotFoundError:
            print(f"Database not found: {db_path} (skipping)")
    
    print(f"\n{'='*60}")
    print("Migration complete!")
    print('='*60)
    print("\nValid deployment location values:")
    print("  - autosys       → Autosys")
    print("  - airflow       → Airflow")
    print("  - ansible_tower → Ansible Tower")