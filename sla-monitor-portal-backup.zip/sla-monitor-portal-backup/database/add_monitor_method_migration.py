"""
Database Migration: Add monitoring_method column to services table
Run this script to add the new monitoring_method column
"""

import sqlite3
import sys

def add_monitoring_method_column(db_path):
    """Add monitoring_method column to services table"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column already exists
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'monitoring_method' in columns:
            print("✓ monitoring_method column already exists")
            return
        
        # Add the new column
        print("Adding monitoring_method column...")
        cursor.execute("""
            ALTER TABLE services 
            ADD COLUMN monitoring_method TEXT DEFAULT 'direct'
        """)
        
        # Update existing services to have 'direct' as default
        cursor.execute("""
            UPDATE services 
            SET monitoring_method = 'direct' 
            WHERE monitoring_method IS NULL
        """)
        
        conn.commit()
        print("✓ Successfully added monitoring_method column")
        print("  - Default value set to 'direct' for all existing services")
        
        # Verify the change
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'monitoring_method' in columns:
            print("✓ Column verified in database schema")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db'
    ]
    
    for db_path in databases:
        try:
            print(f"\n{'='*60}")
            print(f"Migrating: {db_path}")
            print('='*60)
            add_monitoring_method_column(db_path)
        except FileNotFoundError:
            print(f"Database not found: {db_path} (skipping)")
    
    print(f"\n{'='*60}")
    print("Migration complete!")
    print('='*60)
