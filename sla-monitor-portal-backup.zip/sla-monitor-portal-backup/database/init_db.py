"""
Database Initialization Script
Initializes SQLite database with schema and sample data
"""

import sqlite3
import json
from datetime import datetime, timedelta
import uuid
import hashlib

def get_db_connection(db_path='sla_portal.db'):
    """Create database connection"""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_database(db_path='sla_portal.db'):
    """Initialize database with schema"""
    conn = get_db_connection(db_path)
    
    # Read and execute schema
    with open('schema.sql', 'r') as f:
        schema = f.read()
        conn.executescript(schema)
    
    print("✓ Database schema created successfully")
    
    # Insert sample data
    insert_sample_data(conn)
    
    conn.commit()
    conn.close()
    print("✓ Database initialized successfully")

def insert_sample_data(conn):
    """Insert sample data for testing"""
    cursor = conn.cursor()
    
    # Sample Organization
    org_id = f"org-{uuid.uuid4().hex[:8]}"
    cursor.execute("""
        INSERT INTO organizations (org_id, name, data_retention_days, settings)
        VALUES (?, ?, ?, ?)
    """, (org_id, "Demo Organization", 90, json.dumps({"tier": "enterprise"})))
    
    # Sample Users
    admin_id = f"user-{uuid.uuid4().hex[:8]}"
    password_hash = hashlib.sha256("admin123".encode()).hexdigest()
    cursor.execute("""
        INSERT INTO users (user_id, org_id, email, username, password_hash, role)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (admin_id, org_id, "admin@demo.com", "Admin User", password_hash, "Admin"))
    
    # Sample Customers
    customer_ids = []
    for i, customer_name in enumerate(["Acme Corp", "TechStart Inc", "Global Services Ltd"]):
        customer_id = f"cust-{uuid.uuid4().hex[:8]}"
        customer_ids.append(customer_id)
        cursor.execute("""
            INSERT INTO customers (customer_id, org_id, name, tier, contact_email)
            VALUES (?, ?, ?, ?, ?)
        """, (customer_id, org_id, customer_name, ["Silver", "Gold", "Platinum"][i], 
              f"contact@{customer_name.lower().replace(' ', '')}.com"))
    
    # Sample Services
    service_ids = []
    for customer_id in customer_ids:
        for service_name in ["API Gateway", "Database Service", "Web Application"]:
            service_id = f"svc-{uuid.uuid4().hex[:8]}"
            service_ids.append(service_id)
            cursor.execute("""
                INSERT INTO services (service_id, org_id, customer_id, name, owner_team, tags)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (service_id, org_id, customer_id, service_name, "Platform Team", 
                  json.dumps(["production", "critical"])))
    
    # Sample Business Hours
    business_hours_id = f"bh-{uuid.uuid4().hex[:8]}"
    cursor.execute("""
        INSERT INTO business_hours (
            business_hours_id, org_id, name, timezone,
            monday_start, monday_end, tuesday_start, tuesday_end,
            wednesday_start, wednesday_end, thursday_start, thursday_end,
            friday_start, friday_end, holidays
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (business_hours_id, org_id, "Standard Business Hours", "America/New_York",
          "09:00", "17:00", "09:00", "17:00", "09:00", "17:00", "09:00", "17:00",
          "09:00", "17:00", json.dumps(["2025-12-25", "2025-01-01"])))
    
    # Sample Escalation Policy
    escalation_policy_id = f"ep-{uuid.uuid4().hex[:8]}"
    cursor.execute("""
        INSERT INTO escalation_policies (escalation_policy_id, org_id, name, levels)
        VALUES (?, ?, ?, ?)
    """, (escalation_policy_id, org_id, "Standard Escalation", json.dumps([
        {"level": 1, "wait_minutes": 15, "notify": ["team-lead@demo.com"]},
        {"level": 2, "wait_minutes": 30, "notify": ["manager@demo.com"]},
        {"level": 3, "wait_minutes": 60, "notify": ["director@demo.com"]}
    ])))
    
    # Sample SLAs
    for service_id in service_ids[:3]:  # First 3 services
        # Response Time SLA
        sla_id = f"sla-{uuid.uuid4().hex[:8]}"
        cursor.execute("""
            INSERT INTO slas (
                sla_id, org_id, service_id, customer_id, name, metric_type,
                target_value, target_unit, priority, business_hours_id,
                escalation_policy_id, start_condition, stop_condition, effective_from
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (sla_id, org_id, service_id, customer_ids[0], "P1 Response Time",
              "response_time", 60.0, "minutes", "P1", business_hours_id, escalation_policy_id,
              json.dumps({"event_type": "incident.created", "priority": "P1"}),
              json.dumps({"event_type": "agent.responded"}),
              datetime.now().isoformat()))
        
        # Resolution Time SLA
        sla_id = f"sla-{uuid.uuid4().hex[:8]}"
        cursor.execute("""
            INSERT INTO slas (
                sla_id, org_id, service_id, customer_id, name, metric_type,
                target_value, target_unit, priority, business_hours_id,
                start_condition, stop_condition, effective_from
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (sla_id, org_id, service_id, customer_ids[0], "P1 Resolution Time",
              "resolution_time", 240.0, "minutes", "P1", business_hours_id,
              json.dumps({"event_type": "incident.created", "priority": "P1"}),
              json.dumps({"event_type": "incident.resolved"}),
              datetime.now().isoformat()))
    
    # Sample Integrations
    integrations = [
        ("Datadog Integration", "datadog", {"api_key": "xxxxx", "app_key": "xxxxx", "webhook_url": "https://portal.demo.com/webhooks/datadog"}),
        ("Slack Integration", "slack", {"webhook_url": "https://hooks.slack.com/services/xxxxx", "channel": "#alerts"}),
        ("PagerDuty Integration", "pagerduty", {"api_key": "xxxxx", "service_id": "xxxxx"})
    ]
    
    for name, int_type, config in integrations:
        integration_id = f"int-{uuid.uuid4().hex[:8]}"
        cursor.execute("""
            INSERT INTO integrations (integration_id, org_id, name, type, config)
            VALUES (?, ?, ?, ?, ?)
        """, (integration_id, org_id, name, int_type, json.dumps(config)))
    
    # Sample Events (last 7 days)
    for i in range(20):
        event_id = f"evt-{uuid.uuid4().hex[:8]}"
        service_id = service_ids[i % len(service_ids)]
        timestamp = datetime.now() - timedelta(days=i%7, hours=i%24)
        
        cursor.execute("""
            INSERT INTO events (
                event_id, org_id, service_id, customer_id, timestamp, event_type,
                status, priority, source, payload, normalized_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (event_id, org_id, service_id, customer_ids[i % len(customer_ids)],
              timestamp.isoformat(), 
              ["incident.created", "incident.resolved"][i % 2],
              "open" if i % 2 == 0 else "resolved",
              ["P1", "P2", "P3"][i % 3],
              "datadog",
              json.dumps({"incident_id": f"inc-{i}", "description": f"Sample incident {i}"}),
              json.dumps({"service_id": service_id, "timestamp": timestamp.isoformat()})))
    
    print(f"✓ Inserted sample data:")
    print(f"  - 1 Organization")
    print(f"  - 1 Admin User")
    print(f"  - {len(customer_ids)} Customers")
    print(f"  - {len(service_ids)} Services")
    print(f"  - Multiple SLAs")
    print(f"  - 20 Sample Events")

if __name__ == "__main__":
    init_database()
