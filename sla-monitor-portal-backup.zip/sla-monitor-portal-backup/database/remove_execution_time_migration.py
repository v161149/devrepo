"""
Database Migration: Remove execution_time column from services table
This script removes the execution_time column if it was previously added.
Use this if you added the column but want to switch to the metadata-only approach.
"""

import sqlite3
import sys
import shutil
from datetime import datetime

def backup_database(db_path):
    """Create a backup of the database before making changes"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    
    try:
        shutil.copy2(db_path, backup_path)
        print(f"✓ Backup created: {backup_path}")
        return backup_path
    except Exception as e:
        print(f"✗ Failed to create backup: {str(e)}")
        return None

def remove_execution_time_column(db_path):
    """Remove execution_time column from services table"""
    try:
        # Create backup first
        print("\nCreating database backup...")
        backup_path = backup_database(db_path)
        if not backup_path:
            print("⚠ Warning: Proceeding without backup")
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column exists
        cursor.execute("PRAGMA table_info(services)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'execution_time' not in columns:
            print("✓ execution_time column does not exist - nothing to remove")
            conn.close()
            return
        
        print("\nColumn 'execution_time' found in services table")
        
        # SQLite doesn't support DROP COLUMN directly (before version 3.35.0)
        # We need to recreate the table without the column
        
        print("\nStep 1: Get current table schema...")
        cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='services'")
        create_table_sql = cursor.fetchone()[0]
        print(f"✓ Current schema retrieved")
        
        print("\nStep 2: Find and save dependent views...")
        cursor.execute("""
            SELECT name, sql 
            FROM sqlite_master 
            WHERE type='view' AND sql LIKE '%services%'
        """)
        views = cursor.fetchall()
        
        if views:
            print(f"✓ Found {len(views)} dependent view(s):")
            for view_name, _ in views:
                print(f"  - {view_name}")
        else:
            print("✓ No dependent views found")
        
        print("\nStep 3: Clean up any leftover tables from previous attempts...")
        cursor.execute("DROP TABLE IF EXISTS services_new")
        cursor.execute("DROP TABLE IF EXISTS services_old")
        print("✓ Cleanup complete")
        
        print("\nStep 4: Drop dependent views temporarily...")
        for view_name, _ in views:
            cursor.execute(f"DROP VIEW IF EXISTS {view_name}")
            print(f"  ✓ Dropped view: {view_name}")
        
        print("\nStep 5: Get all column names (excluding execution_time)...")
        cursor.execute("PRAGMA table_info(services)")
        all_columns = [col[1] for col in cursor.fetchall()]
        columns_to_keep = [col for col in all_columns if col != 'execution_time']
        columns_str = ', '.join(columns_to_keep)
        print(f"✓ Columns to keep: {len(columns_to_keep)}/{len(all_columns)}")
        
        print("\nStep 6: Create new table without execution_time column...")
        
        # Create new table schema (without execution_time)
        cursor.execute("""
            CREATE TABLE services_new (
                service_id TEXT PRIMARY KEY,
                org_id TEXT NOT NULL,
                customer_id TEXT,
                name TEXT NOT NULL,
                description TEXT,
                owner_team TEXT,
                asset_id TEXT,
                monitoring_method TEXT DEFAULT 'direct',
                deployment_location TEXT,
                tags TEXT,
                metadata TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (org_id) REFERENCES organizations(org_id),
                FOREIGN KEY (asset_id) REFERENCES assets(asset_id)
            )
        """)
        print("✓ New table 'services_new' created")
        
        print("\nStep 7: Copy data from old table to new table...")
        cursor.execute(f"""
            INSERT INTO services_new ({columns_str})
            SELECT {columns_str}
            FROM services
        """)
        rows_copied = cursor.rowcount
        print(f"✓ Copied {rows_copied} rows")
        
        print("\nStep 8: Drop old table...")
        cursor.execute("DROP TABLE services")
        print("✓ Old table dropped")
        
        print("\nStep 9: Rename new table to 'services'...")
        cursor.execute("ALTER TABLE services_new RENAME TO services")
        print("✓ Table renamed")
        
        # Recreate indexes if any existed
        print("\nStep 10: Recreate indexes...")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_services_org_id 
            ON services(org_id)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_services_asset_id 
            ON services(asset_id)
        """)
        print("✓ Indexes recreated")
        
        # Recreate views
        print("\nStep 11: Recreate dependent views...")
        for view_name, view_sql in views:
            try:
                cursor.execute(view_sql)
                print(f"  ✓ Recreated view: {view_name}")
            except Exception as e:
                print(f"  ⚠ Warning: Could not recreate view {view_name}: {str(e)}")
                print(f"    You may need to recreate this view manually")
        
        conn.commit()
        
        # Verify the change
        print("\nVerifying changes...")
        cursor.execute("PRAGMA table_info(services)")
        final_columns = [col[1] for col in cursor.fetchall()]
        
        if 'execution_time' not in final_columns:
            print("✓ Column 'execution_time' successfully removed")
        else:
            print("✗ Column 'execution_time' still exists!")
            conn.close()
            return
        
        # Show final schema
        print(f"\nFinal schema has {len(final_columns)} columns:")
        for i, col in enumerate(final_columns, 1):
            print(f"  {i}. {col}")
        
        # Count services
        cursor.execute("SELECT COUNT(*) FROM services")
        total_services = cursor.fetchone()[0]
        print(f"\n✓ Total services in table: {total_services}")
        
        # Verify views
        if views:
            print("\nVerifying recreated views...")
            cursor.execute("""
                SELECT name 
                FROM sqlite_master 
                WHERE type='view'
            """)
            recreated_views = [row[0] for row in cursor.fetchall()]
            print(f"✓ Views in database: {', '.join(recreated_views)}")
        
        conn.close()
        
        print("\n" + "="*70)
        print("SUCCESS! Column removed successfully!")
        print("="*70)
        if backup_path:
            print(f"\nBackup location: {backup_path}")
            print("Keep this backup until you've verified everything works correctly.")
        
    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        print("\n⚠ If an error occurred, restore from backup:")
        if backup_path:
            print(f"   cp {backup_path} {db_path}")
        sys.exit(1)

def check_metadata_has_execution_time(db_path):
    """Check if execution_time exists in metadata for ETL jobs"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("\nChecking if ETL jobs have execution_time in metadata...")
        
        cursor.execute("""
            SELECT service_id, name, metadata 
            FROM services 
            WHERE metadata LIKE '%etl_batch%'
        """)
        
        etl_jobs = cursor.fetchall()
        
        if not etl_jobs:
            print("  No ETL jobs found")
            conn.close()
            return
        
        print(f"  Found {len(etl_jobs)} ETL job(s)")
        
        import json
        has_execution_time = 0
        missing_execution_time = 0
        
        for service_id, name, metadata_str in etl_jobs:
            try:
                metadata = json.loads(metadata_str) if metadata_str else {}
                if 'execution_time' in metadata and metadata['execution_time']:
                    print(f"  ✓ {name}: {metadata['execution_time']}")
                    has_execution_time += 1
                else:
                    print(f"  ✗ {name}: Missing execution_time in metadata")
                    missing_execution_time += 1
            except:
                print(f"  ⚠ {name}: Invalid metadata JSON")
                missing_execution_time += 1
        
        print(f"\nSummary:")
        print(f"  - With execution_time: {has_execution_time}/{len(etl_jobs)}")
        print(f"  - Missing execution_time: {missing_execution_time}/{len(etl_jobs)}")
        
        if missing_execution_time > 0:
            print(f"\n⚠ Warning: {missing_execution_time} ETL job(s) don't have execution_time in metadata")
            print("  Run update_etl_metadata_migration.py to add execution_time to metadata")
        
        conn.close()
        
    except Exception as e:
        print(f"  Error checking metadata: {str(e)}")

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db',
        'sla_portal.db'
    ]
    
    found_db = False
    for db_path in databases:
        try:
            import os
            if not os.path.exists(db_path):
                continue
                
            print(f"\n{'='*70}")
            print(f"Processing: {db_path}")
            print('='*70)
            
            # First check if ETL jobs have execution_time in metadata
            check_metadata_has_execution_time(db_path)
            
            # Ask for confirmation
            print("\n⚠ WARNING: This will remove the execution_time column from services table")
            print("Make sure you've:")
            print("  1. Run update_etl_metadata_migration.py to add execution_time to metadata")
            print("  2. Updated frontend to use metadata-only approach")
            print("  3. Tested that everything works with metadata approach")
            
            response = input("\nDo you want to proceed? (yes/no): ").strip().lower()
            
            if response == 'yes':
                remove_execution_time_column(db_path)
                found_db = True
            else:
                print("Cancelled by user")
            
            break  # Only process first found database
            
        except FileNotFoundError:
            continue
    
    if not found_db:
        print("\n✗ No database found! Please ensure sla_portal.db exists.")
        print("Searched in:")
        for db in databases:
            print(f"  - {db}")
        sys.exit(1)
    
    print(f"\n{'='*70}")
    print("Migration complete!")
    print('='*70)
    print("\nWhat was changed:")
    print("  - Removed execution_time column from services table")
    print("  - Data preserved in metadata JSON")
    print("  - Table structure cleaned up")
    print("\nNext steps:")
    print("  1. Verify frontend still works correctly")
    print("  2. Test creating/editing ETL jobs")
    print("  3. Confirm execution_time is stored in metadata")
    print("  4. If everything works, delete the backup file")
    print("\nNote: Keep the backup until you're 100% sure everything works!")
