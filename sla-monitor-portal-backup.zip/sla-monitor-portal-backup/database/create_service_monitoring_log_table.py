"""
Database Migration: Create service_monitoring_log table
This table stores scheduled job execution tracking records
"""

import sqlite3
import sys
from datetime import datetime

def create_service_monitoring_log_table(db_path):
    """Create service_monitoring_log table"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if table already exists
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='service_monitoring_log'
        """)
        
        if cursor.fetchone():
            print("✓ service_monitoring_log table already exists")
            conn.close()
            return
        
        print("Creating service_monitoring_log table...")
        
        # Create the table
        cursor.execute("""
            CREATE TABLE service_monitoring_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_id TEXT NOT NULL,
                asset_name TEXT,
                service_id TEXT NOT NULL,
                service_name TEXT,
                job_name TEXT,
                job_type TEXT,
                deployment_location TEXT,
                job_schedule TEXT,
                scheduled_execution_date TEXT NOT NULL,
                scheduled_start_time TEXT NOT NULL,
                scheduled_end_time TEXT NOT NULL,
                scheduled_execution_duration TEXT,
                start_time TEXT,
                end_time TEXT,
                on_time_ind TEXT DEFAULT 'Unknown',
                creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (asset_id) REFERENCES assets(asset_id),
                FOREIGN KEY (service_id) REFERENCES services(service_id),
                UNIQUE(asset_id, service_id, job_name, job_type, scheduled_execution_date, scheduled_start_time, scheduled_end_time)
            )
        """)
        
        print("✓ Table created successfully")
        
        # Create indexes for performance
        print("\nCreating indexes...")
        
        cursor.execute("""
            CREATE INDEX idx_sml_service_id 
            ON service_monitoring_log(service_id)
        """)
        print("  ✓ Index on service_id")
        
        cursor.execute("""
            CREATE INDEX idx_sml_asset_id 
            ON service_monitoring_log(asset_id)
        """)
        print("  ✓ Index on asset_id")
        
        cursor.execute("""
            CREATE INDEX idx_sml_scheduled_start_time 
            ON service_monitoring_log(scheduled_start_time)
        """)
        print("  ✓ Index on scheduled_start_time")
        
        cursor.execute("""
            CREATE INDEX idx_sml_scheduled_execution_date 
            ON service_monitoring_log(scheduled_execution_date)
        """)
        print("  ✓ Index on scheduled_execution_date")
        
        cursor.execute("""
            CREATE INDEX idx_sml_on_time_ind 
            ON service_monitoring_log(on_time_ind)
        """)
        print("  ✓ Index on on_time_ind")
        
        conn.commit()
        
        # Verify table structure
        print("\nVerifying table structure...")
        cursor.execute("PRAGMA table_info(service_monitoring_log)")
        columns = cursor.fetchall()
        
        print(f"\nTable has {len(columns)} columns:")
        for col in columns:
            col_id, name, type_, notnull, default, pk = col
            print(f"  {col_id + 1}. {name} ({type_}){' PRIMARY KEY' if pk else ''}{' NOT NULL' if notnull else ''}")
        
        # Verify indexes
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='service_monitoring_log'
        """)
        indexes = cursor.fetchall()
        
        print(f"\nIndexes created: {len(indexes)}")
        for idx in indexes:
            print(f"  - {idx[0]}")
        
        # Verify UNIQUE constraint
        cursor.execute("PRAGMA index_list(service_monitoring_log)")
        unique_indexes = [idx for idx in cursor.fetchall() if idx[2] == 1]  # unique flag
        
        print(f"\nUnique constraints: {len(unique_indexes)}")
        for idx in unique_indexes:
            print(f"  - {idx[1]} (prevents duplicate job executions)")
        
        conn.close()
        
        print("\n" + "="*70)
        print("SUCCESS! Table created successfully!")
        print("="*70)
        
    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    # Run for both database locations
    databases = [
        '../database/sla_portal.db',
        './sla_portal.db',
        'sla_portal.db'
    ]
    
    found_db = False
    for db_path in databases:
        try:
            import os
            if not os.path.exists(db_path):
                continue
                
            print(f"\n{'='*70}")
            print(f"Migrating: {db_path}")
            print('='*70)
            
            create_service_monitoring_log_table(db_path)
            found_db = True
            break
            
        except FileNotFoundError:
            continue
    
    if not found_db:
        print("\n✗ No database found! Please ensure sla_portal.db exists.")
        print("Searched in:")
        for db in databases:
            print(f"  - {db}")
        sys.exit(1)
    
    print(f"\n{'='*70}")
    print("Migration complete!")
    print('='*70)
    print("\nTable: service_monitoring_log")
    print("  - Tracks scheduled job executions")
    print("  - Auto-incrementing ID")
    print("  - Unique constraint prevents duplicates")
    print("  - Indexes for performance")
    print("\nNext steps:")
    print("  1. Deploy job_monitoring_service.py")
    print("  2. Integrate with api_service.py")
    print("  3. Monitor logs for scheduled jobs")
