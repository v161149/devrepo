# 📊 ETL BATCH JOB FOR SLA MONITORING PORTAL

## 🎯 **What is an ETL Batch Job?**

**ETL** = **E**xtract, **T**ransform, **L**oad

**Purpose:**
- Extract data from operational database
- Transform/aggregate for analysis
- Load into reporting tables or data warehouse
- Run on schedule (nightly, hourly, etc.)

**Use Cases:**
- Daily SLA compliance summaries
- Historical trend analysis
- Performance metrics rollup
- Data warehouse population
- Executive dashboards

---

## 📋 **EXAMPLE 1: Daily SLA Summary ETL Job**

### **Goal:**
Create a batch job that runs nightly to calculate daily SLA compliance summaries.

### **Step 1: Create ETL Script**

**File:** `backend/etl/daily_sla_summary.py`

```python
#!/usr/bin/env python3
"""
Daily SLA Summary ETL Job
Runs nightly to calculate and store daily SLA compliance summaries
"""

import sys
import os
from datetime import datetime, timedelta
import json
import sqlite3

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database_service import DatabaseService

class DailySLASummaryETL:
    def __init__(self):
        self.db_service = DatabaseService()
        self.extract_date = datetime.now().date()
        self.stats = {
            'extracted': 0,
            'transformed': 0,
            'loaded': 0,
            'errors': 0
        }
    
    def run(self):
        """Main ETL process"""
        print(f"=== Daily SLA Summary ETL Job ===")
        print(f"Start Time: {datetime.now()}")
        print(f"Processing Date: {self.extract_date}")
        print()
        
        try:
            # Step 1: Extract
            print("Step 1: EXTRACT - Getting SLA data...")
            sla_data = self.extract_sla_data()
            self.stats['extracted'] = len(sla_data)
            print(f"  ✓ Extracted {self.stats['extracted']} SLAs")
            
            # Step 2: Transform
            print("\nStep 2: TRANSFORM - Calculating metrics...")
            summaries = self.transform_to_summaries(sla_data)
            self.stats['transformed'] = len(summaries)
            print(f"  ✓ Transformed {self.stats['transformed']} summaries")
            
            # Step 3: Load
            print("\nStep 3: LOAD - Storing summaries...")
            self.load_summaries(summaries)
            self.stats['loaded'] = len(summaries)
            print(f"  ✓ Loaded {self.stats['loaded']} summaries")
            
            # Step 4: Cleanup
            print("\nStep 4: CLEANUP - Archiving old data...")
            self.cleanup_old_data()
            print(f"  ✓ Cleanup complete")
            
            print(f"\n=== Job Completed Successfully ===")
            print(f"End Time: {datetime.now()}")
            print(f"Statistics: {json.dumps(self.stats, indent=2)}")
            
            return True
            
        except Exception as e:
            print(f"\n❌ ERROR: {str(e)}")
            self.stats['errors'] += 1
            import traceback
            traceback.print_exc()
            return False
    
    def extract_sla_data(self):
        """
        EXTRACT: Get all active SLAs with current status
        """
        with self.db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT 
                    s.sla_id,
                    s.org_id,
                    s.service_id,
                    s.name,
                    s.sla_type,
                    s.target_value,
                    s.measurement_window,
                    srv.name as service_name,
                    -- Get latest health check
                    (SELECT status FROM service_health_checks 
                     WHERE service_id = s.service_id 
                     ORDER BY checked_at DESC LIMIT 1) as health_status,
                    -- Calculate current compliance
                    CASE 
                        WHEN (SELECT status FROM service_health_checks 
                              WHERE service_id = s.service_id 
                              ORDER BY checked_at DESC LIMIT 1) = 'healthy'
                        THEN 99.95
                        ELSE 0.0
                    END as current_compliance
                FROM slas s
                LEFT JOIN services srv ON s.service_id = srv.service_id
                WHERE s.is_active = 1
                ORDER BY s.org_id, s.service_id
            """)
            
            return [dict(row) for row in cursor.fetchall()]
    
    def transform_to_summaries(self, sla_data):
        """
        TRANSFORM: Calculate daily summaries
        """
        summaries = []
        
        # Group by organization
        orgs = {}
        for sla in sla_data:
            org_id = sla['org_id']
            if org_id not in orgs:
                orgs[org_id] = []
            orgs[org_id].append(sla)
        
        # Calculate summary for each org
        for org_id, slas in orgs.items():
            total_slas = len(slas)
            compliant = sum(1 for sla in slas if sla['current_compliance'] >= sla['target_value'])
            breached = total_slas - compliant
            avg_compliance = sum(sla['current_compliance'] for sla in slas) / total_slas if total_slas > 0 else 0
            
            summary = {
                'summary_id': f"sum-{org_id}-{self.extract_date.strftime('%Y%m%d')}",
                'org_id': org_id,
                'summary_date': self.extract_date.isoformat(),
                'total_slas': total_slas,
                'compliant_slas': compliant,
                'breached_slas': breached,
                'avg_compliance': round(avg_compliance, 2),
                'compliance_rate': round((compliant / total_slas * 100) if total_slas > 0 else 0, 2),
                'created_at': datetime.now().isoformat()
            }
            
            summaries.append(summary)
        
        return summaries
    
    def load_summaries(self, summaries):
        """
        LOAD: Store summaries in database
        """
        with self.db_service.get_connection() as conn:
            for summary in summaries:
                # Check if summary already exists
                existing = conn.execute("""
                    SELECT summary_id FROM daily_sla_summaries
                    WHERE org_id = ? AND summary_date = ?
                """, (summary['org_id'], summary['summary_date'])).fetchone()
                
                if existing:
                    # Update existing
                    conn.execute("""
                        UPDATE daily_sla_summaries
                        SET total_slas = ?,
                            compliant_slas = ?,
                            breached_slas = ?,
                            avg_compliance = ?,
                            compliance_rate = ?,
                            updated_at = ?
                        WHERE org_id = ? AND summary_date = ?
                    """, (
                        summary['total_slas'],
                        summary['compliant_slas'],
                        summary['breached_slas'],
                        summary['avg_compliance'],
                        summary['compliance_rate'],
                        datetime.now().isoformat(),
                        summary['org_id'],
                        summary['summary_date']
                    ))
                else:
                    # Insert new
                    conn.execute("""
                        INSERT INTO daily_sla_summaries (
                            summary_id, org_id, summary_date,
                            total_slas, compliant_slas, breached_slas,
                            avg_compliance, compliance_rate, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        summary['summary_id'],
                        summary['org_id'],
                        summary['summary_date'],
                        summary['total_slas'],
                        summary['compliant_slas'],
                        summary['breached_slas'],
                        summary['avg_compliance'],
                        summary['compliance_rate'],
                        summary['created_at']
                    ))
    
    def cleanup_old_data(self):
        """
        CLEANUP: Archive data older than 90 days
        """
        cutoff_date = (datetime.now() - timedelta(days=90)).date().isoformat()
        
        with self.db_service.get_connection() as conn:
            # Delete old summaries (older than 90 days)
            result = conn.execute("""
                DELETE FROM daily_sla_summaries
                WHERE summary_date < ?
            """, (cutoff_date,))
            
            deleted_count = result.rowcount
            print(f"  ✓ Deleted {deleted_count} old summaries")

if __name__ == '__main__':
    etl = DailySLASummaryETL()
    success = etl.run()
    sys.exit(0 if success else 1)
```

---

### **Step 2: Create Summary Table**

**File:** `database/migrations/add_daily_summaries_table.sql`

```sql
-- Daily SLA Summaries Table
CREATE TABLE IF NOT EXISTS daily_sla_summaries (
    summary_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    summary_date DATE NOT NULL,
    total_slas INTEGER NOT NULL,
    compliant_slas INTEGER NOT NULL,
    breached_slas INTEGER NOT NULL,
    avg_compliance REAL NOT NULL,
    compliance_rate REAL NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    UNIQUE(org_id, summary_date)
);

CREATE INDEX idx_summaries_org_date ON daily_sla_summaries(org_id, summary_date);
CREATE INDEX idx_summaries_date ON daily_sla_summaries(summary_date);
```

**Run migration:**
```bash
cd backend
sqlite3 database/sla_portal.db < ../database/migrations/add_daily_summaries_table.sql
```

---

### **Step 3: Schedule the Job**

**Option A: Using Cron (Linux/Mac)**

```bash
# Edit crontab
crontab -e

# Add line to run daily at 1:00 AM
0 1 * * * cd /path/to/backend && python3 etl/daily_sla_summary.py >> /var/log/sla_etl.log 2>&1
```

**Option B: Using Windows Task Scheduler**

```powershell
# Create scheduled task
$action = New-ScheduledTaskAction -Execute "python" -Argument "etl/daily_sla_summary.py" -WorkingDirectory "C:\path\to\backend"
$trigger = New-ScheduledTaskTrigger -Daily -At 1am
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "SLA-Daily-Summary" -Description "Daily SLA summary ETL job"
```

**Option C: Using Python Scheduler (APScheduler)**

**File:** `backend/scheduler.py`

```python
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from etl.daily_sla_summary import DailySLASummaryETL

def run_daily_summary():
    """Run daily summary ETL job"""
    print("Starting Daily SLA Summary ETL Job...")
    etl = DailySLASummaryETL()
    etl.run()

# Create scheduler
scheduler = BackgroundScheduler()

# Schedule daily at 1:00 AM
scheduler.add_job(
    run_daily_summary,
    CronTrigger(hour=1, minute=0),
    id='daily_sla_summary',
    name='Daily SLA Summary ETL',
    replace_existing=True
)

# Start scheduler
scheduler.start()

print("Scheduler started. ETL jobs will run on schedule.")

# Keep the script running
try:
    import time
    while True:
        time.sleep(1)
except (KeyboardInterrupt, SystemExit):
    scheduler.shutdown()
```

**Install dependencies:**
```bash
pip install apscheduler
```

**Run scheduler:**
```bash
python scheduler.py
```

---

### **Step 4: Test the Job Manually**

```bash
# Run ETL job manually
cd backend
python etl/daily_sla_summary.py
```

**Expected output:**
```
=== Daily SLA Summary ETL Job ===
Start Time: 2025-11-27 01:00:00
Processing Date: 2025-11-27

Step 1: EXTRACT - Getting SLA data...
  ✓ Extracted 2 SLAs

Step 2: TRANSFORM - Calculating metrics...
  ✓ Transformed 1 summaries

Step 3: LOAD - Storing summaries...
  ✓ Loaded 1 summaries

Step 4: CLEANUP - Archiving old data...
  ✓ Deleted 0 old summaries
  ✓ Cleanup complete

=== Job Completed Successfully ===
End Time: 2025-11-27 01:00:05
Statistics: {
  "extracted": 2,
  "transformed": 1,
  "loaded": 1,
  "errors": 0
}
```

---

## 📋 **EXAMPLE 2: Hourly Metrics Aggregation ETL**

### **Goal:**
Aggregate hourly SLA metrics for real-time dashboards.

**File:** `backend/etl/hourly_metrics.py`

```python
#!/usr/bin/env python3
"""
Hourly Metrics ETL Job
Aggregates metrics every hour for real-time reporting
"""

import sys
import os
from datetime import datetime, timedelta
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database_service import DatabaseService

class HourlyMetricsETL:
    def __init__(self):
        self.db_service = DatabaseService()
        self.extract_hour = datetime.now().replace(minute=0, second=0, microsecond=0)
    
    def run(self):
        """Main ETL process"""
        print(f"=== Hourly Metrics ETL Job ===")
        print(f"Processing Hour: {self.extract_hour}")
        
        try:
            # Extract health checks from the last hour
            health_checks = self.extract_health_checks()
            print(f"Extracted {len(health_checks)} health checks")
            
            # Transform to metrics
            metrics = self.transform_to_metrics(health_checks)
            print(f"Calculated metrics for {len(metrics)} services")
            
            # Load metrics
            self.load_metrics(metrics)
            print(f"Loaded {len(metrics)} hourly metrics")
            
            print("Job completed successfully")
            return True
            
        except Exception as e:
            print(f"ERROR: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def extract_health_checks(self):
        """Extract health checks from last hour"""
        hour_ago = self.extract_hour - timedelta(hours=1)
        
        with self.db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT 
                    h.*,
                    s.name as service_name,
                    s.org_id
                FROM service_health_checks h
                JOIN services s ON h.service_id = s.service_id
                WHERE h.checked_at >= ? AND h.checked_at < ?
                ORDER BY h.checked_at
            """, (hour_ago.isoformat(), self.extract_hour.isoformat()))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def transform_to_metrics(self, health_checks):
        """Calculate hourly metrics per service"""
        metrics = {}
        
        for check in health_checks:
            service_id = check['service_id']
            
            if service_id not in metrics:
                metrics[service_id] = {
                    'service_id': service_id,
                    'service_name': check['service_name'],
                    'org_id': check['org_id'],
                    'hour': self.extract_hour.isoformat(),
                    'total_checks': 0,
                    'healthy_checks': 0,
                    'unhealthy_checks': 0,
                    'avg_response_time': 0,
                    'max_response_time': 0,
                    'min_response_time': float('inf')
                }
            
            m = metrics[service_id]
            m['total_checks'] += 1
            
            if check['status'] == 'healthy':
                m['healthy_checks'] += 1
            else:
                m['unhealthy_checks'] += 1
            
            if check['response_time']:
                m['avg_response_time'] += check['response_time']
                m['max_response_time'] = max(m['max_response_time'], check['response_time'])
                m['min_response_time'] = min(m['min_response_time'], check['response_time'])
        
        # Calculate averages
        for service_id, m in metrics.items():
            if m['total_checks'] > 0:
                m['avg_response_time'] = m['avg_response_time'] / m['total_checks']
                m['availability'] = (m['healthy_checks'] / m['total_checks']) * 100
            
            if m['min_response_time'] == float('inf'):
                m['min_response_time'] = 0
        
        return list(metrics.values())
    
    def load_metrics(self, metrics):
        """Store hourly metrics"""
        with self.db_service.get_connection() as conn:
            for metric in metrics:
                conn.execute("""
                    INSERT OR REPLACE INTO hourly_service_metrics (
                        metric_id, org_id, service_id, hour,
                        total_checks, healthy_checks, unhealthy_checks,
                        availability, avg_response_time, max_response_time, min_response_time,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    f"metric-{metric['service_id']}-{self.extract_hour.strftime('%Y%m%d%H')}",
                    metric['org_id'],
                    metric['service_id'],
                    metric['hour'],
                    metric['total_checks'],
                    metric['healthy_checks'],
                    metric['unhealthy_checks'],
                    metric['availability'],
                    metric['avg_response_time'],
                    metric['max_response_time'],
                    metric['min_response_time'],
                    datetime.now().isoformat()
                ))

if __name__ == '__main__':
    etl = HourlyMetricsETL()
    success = etl.run()
    sys.exit(0 if success else 1)
```

**Schedule hourly:**
```bash
# Cron - run every hour at minute 5
5 * * * * cd /path/to/backend && python3 etl/hourly_metrics.py
```

---

## 📋 **EXAMPLE 3: Data Warehouse Export ETL**

### **Goal:**
Export SLA data to external data warehouse (e.g., Snowflake, BigQuery, Redshift).

**File:** `backend/etl/export_to_warehouse.py`

```python
#!/usr/bin/env python3
"""
Data Warehouse Export ETL Job
Exports SLA data to external data warehouse
"""

import sys
import os
from datetime import datetime
import pandas as pd
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database_service import DatabaseService

class DataWarehouseExportETL:
    def __init__(self):
        self.db_service = DatabaseService()
        self.export_timestamp = datetime.now()
    
    def run(self):
        """Main ETL process"""
        print(f"=== Data Warehouse Export ETL ===")
        print(f"Export Time: {self.export_timestamp}")
        
        try:
            # Extract all tables
            print("\n1. Extracting data from operational database...")
            data = self.extract_all_data()
            
            # Transform to warehouse schema
            print("\n2. Transforming to warehouse schema...")
            warehouse_data = self.transform_for_warehouse(data)
            
            # Load to warehouse
            print("\n3. Loading to data warehouse...")
            self.load_to_warehouse(warehouse_data)
            
            print("\nExport completed successfully!")
            return True
            
        except Exception as e:
            print(f"\nERROR: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def extract_all_data(self):
        """Extract data from all relevant tables"""
        data = {}
        
        with self.db_service.get_connection() as conn:
            # Organizations
            print("  - Extracting organizations...")
            data['organizations'] = pd.read_sql_query(
                "SELECT * FROM organizations WHERE is_active = 1",
                conn
            )
            
            # Services
            print("  - Extracting services...")
            data['services'] = pd.read_sql_query(
                "SELECT * FROM services WHERE is_active = 1",
                conn
            )
            
            # SLAs
            print("  - Extracting SLAs...")
            data['slas'] = pd.read_sql_query("""
                SELECT 
                    s.*,
                    srv.name as service_name,
                    o.name as org_name
                FROM slas s
                LEFT JOIN services srv ON s.service_id = srv.service_id
                LEFT JOIN organizations o ON s.org_id = o.org_id
                WHERE s.is_active = 1
            """, conn)
            
            # Alerts
            print("  - Extracting alerts...")
            data['alerts'] = pd.read_sql_query("""
                SELECT * FROM alerts
                WHERE created_at >= date('now', '-30 days')
            """, conn)
            
            # Daily summaries
            print("  - Extracting daily summaries...")
            data['daily_summaries'] = pd.read_sql_query("""
                SELECT * FROM daily_sla_summaries
                WHERE summary_date >= date('now', '-90 days')
            """, conn)
        
        print(f"\nExtraction complete:")
        for table, df in data.items():
            print(f"  - {table}: {len(df)} rows")
        
        return data
    
    def transform_for_warehouse(self, data):
        """Transform data to warehouse schema"""
        warehouse_data = {}
        
        # Add metadata
        for table_name, df in data.items():
            df['etl_timestamp'] = self.export_timestamp
            df['etl_source'] = 'sla_portal'
            warehouse_data[table_name] = df
        
        return warehouse_data
    
    def load_to_warehouse(self, warehouse_data):
        """Load data to warehouse"""
        # Example: Export to CSV files for warehouse loading
        export_dir = os.path.join(os.path.dirname(__file__), 'exports')
        os.makedirs(export_dir, exist_ok=True)
        
        timestamp_str = self.export_timestamp.strftime('%Y%m%d_%H%M%S')
        
        for table_name, df in warehouse_data.items():
            filename = f"{table_name}_{timestamp_str}.csv"
            filepath = os.path.join(export_dir, filename)
            
            df.to_csv(filepath, index=False)
            print(f"  ✓ Exported {table_name} to {filename}")
        
        # TODO: Upload to actual warehouse
        # Example integrations:
        # - Snowflake: Use snowflake-connector-python
        # - BigQuery: Use google-cloud-bigquery
        # - Redshift: Use psycopg2
        # - S3: Use boto3
        
        print(f"\n  Files ready for warehouse ingestion in: {export_dir}")

if __name__ == '__main__':
    etl = DataWarehouseExportETL()
    success = etl.run()
    sys.exit(0 if success else 1)
```

---

## 📊 **MONITORING ETL JOBS**

### **Create ETL Job Log Table**

```sql
CREATE TABLE IF NOT EXISTS etl_job_logs (
    log_id TEXT PRIMARY KEY,
    job_name TEXT NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    status TEXT CHECK(status IN ('running', 'success', 'failed')),
    records_processed INTEGER,
    error_message TEXT,
    details TEXT
);

CREATE INDEX idx_etl_logs_job_time ON etl_job_logs(job_name, start_time);
```

### **Add Logging to ETL Jobs**

```python
def log_job_start(job_name):
    """Log job start"""
    log_id = f"log-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    with db_service.get_connection() as conn:
        conn.execute("""
            INSERT INTO etl_job_logs (log_id, job_name, start_time, status)
            VALUES (?, ?, ?, 'running')
        """, (log_id, job_name, datetime.now().isoformat()))
    return log_id

def log_job_end(log_id, status, records, error=None, details=None):
    """Log job completion"""
    with db_service.get_connection() as conn:
        conn.execute("""
            UPDATE etl_job_logs
            SET end_time = ?, status = ?, records_processed = ?,
                error_message = ?, details = ?
            WHERE log_id = ?
        """, (datetime.now().isoformat(), status, records, error, 
              json.dumps(details) if details else None, log_id))
```

---

## 📈 **VIEWING ETL RESULTS**

### **Query Daily Summaries**

```sql
-- Get last 30 days of summaries
SELECT 
    summary_date,
    total_slas,
    compliant_slas,
    breached_slas,
    compliance_rate
FROM daily_sla_summaries
WHERE org_id = 'org-xxx'
ORDER BY summary_date DESC
LIMIT 30;
```

### **Create API Endpoint for Summaries**

**File:** `backend/api_service.py`

```python
@app.route('/api/v1/reports/daily-summaries', methods=['GET'])
@require_auth
def get_daily_summaries():
    """Get daily SLA summaries"""
    org_id = get_user_org()
    days = int(request.args.get('days', 30))
    
    with db_service.get_connection() as conn:
        cursor = conn.execute("""
            SELECT * FROM daily_sla_summaries
            WHERE org_id = ?
            AND summary_date >= date('now', '-' || ? || ' days')
            ORDER BY summary_date DESC
        """, (org_id, days))
        
        summaries = [dict(row) for row in cursor.fetchall()]
    
    return jsonify({
        'data': summaries,
        'count': len(summaries)
    })
```

---

## ✅ **BEST PRACTICES**

### **1. Error Handling**
```python
try:
    # ETL logic
    pass
except Exception as e:
    # Log error
    log_job_end(log_id, 'failed', 0, str(e))
    # Send alert
    send_alert(f"ETL job failed: {str(e)}")
    raise
```

### **2. Idempotency**
```python
# Check if data already processed
existing = conn.execute("""
    SELECT * FROM summaries WHERE date = ?
""", (process_date,)).fetchone()

if existing:
    # Update instead of insert
    update_summary()
else:
    # Insert new
    insert_summary()
```

### **3. Incremental Loading**
```python
# Get last processed timestamp
last_processed = get_last_processed_time()

# Only process new data
new_data = extract_data(since=last_processed)
```

### **4. Data Quality Checks**
```python
# Validate data
assert len(summaries) > 0, "No summaries generated"
assert all(s['total_slas'] >= 0 for s in summaries), "Invalid counts"
```

### **5. Notifications**
```python
if stats['errors'] > 0:
    send_email(
        to='admin@example.com',
        subject='ETL Job Failed',
        body=f"Job had {stats['errors']} errors"
    )
```

---

## 🎯 **COMPLETE IMPLEMENTATION CHECKLIST**

- [ ] Create ETL script(s)
- [ ] Create summary/aggregate tables
- [ ] Run database migrations
- [ ] Test ETL manually
- [ ] Schedule ETL jobs
- [ ] Add logging and monitoring
- [ ] Create API endpoints for results
- [ ] Update UI to show ETL data
- [ ] Set up alerting for failures
- [ ] Document ETL process

---

## 📚 **SUMMARY**

**ETL Jobs Created:**
1. ✅ Daily SLA Summary - Runs nightly
2. ✅ Hourly Metrics - Runs every hour  
3. ✅ Data Warehouse Export - Runs weekly

**Benefits:**
- 📊 Historical trend analysis
- 📈 Performance reporting
- 🎯 Executive dashboards
- 💾 Data warehouse integration
- ⚡ Faster query performance

**Next Steps:**
1. Implement ETL scripts
2. Schedule jobs
3. Monitor execution
4. Build reports from ETL data

---

This gives you a complete ETL framework for the SLA monitoring portal! 🚀
