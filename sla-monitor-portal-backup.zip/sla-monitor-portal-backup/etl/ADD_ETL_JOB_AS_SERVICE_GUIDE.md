# 🔧 HOW TO ADD ETL BATCH JOB AS A MONITORED SERVICE

## 🎯 **Understanding the Setup**

**Your Current Setup:**
- ✅ ETL job: `daily_sla_summary.py` running on **remote Linux edge node**
- ✅ Schedule: Daily at 1 AM (via cron)
- ✅ SLA Portal: Running on **local Windows server** (localhost:3010)

**What You Want:**
- Monitor the ETL job's health/execution from the SLA portal
- Get alerts if the ETL job fails
- Track ETL job compliance with SLA

---

## 🔑 **KEY CONCEPT**

The SLA Portal **monitors** services, it doesn't **run** them.

**You need to:**
1. Make your ETL job expose a health check endpoint
2. Add that endpoint as a service in the portal
3. Portal will monitor if the job is running successfully

---

## 📋 **SOLUTION: Two Approaches**

---

## ✅ **APPROACH 1: Health Check Endpoint (Recommended)**

### **How It Works:**

```
Remote Linux Node               Local Windows Server
┌─────────────────┐            ┌──────────────────┐
│ daily_sla_      │            │  SLA Portal      │
│ summary.py      │            │  (localhost:3010)│
│ (runs at 1 AM)  │            │                  │
│                 │            │  Monitors via    │
│ Writes status   │            │  HTTP health     │
│ to file/API     │◄───────────┤  check endpoint  │
│                 │            │                  │
│ Flask API       │            │  Every 5 minutes │
│ /health endpoint│            │                  │
└─────────────────┘            └──────────────────┘
```

---

### **Step 1: Add Health Endpoint to Remote Node**

**On your remote Linux edge node**, create a simple Flask API that serves the ETL job status:

**File:** `backend/etl/health_api.py` (on Linux node)

```python
#!/usr/bin/env python3
"""
ETL Job Health Check API
Runs on remote node to expose ETL job status
"""

from flask import Flask, jsonify
from datetime import datetime, timedelta
import os
import json

app = Flask(__name__)

# Path to status file (written by ETL job)
STATUS_FILE = '/var/log/etl/daily_sla_summary_status.json'

@app.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint
    Returns 200 if last job ran successfully within expected window
    Returns 503 if job failed or didn't run
    """
    try:
        # Read status file
        if not os.path.exists(STATUS_FILE):
            return jsonify({
                'status': 'unhealthy',
                'message': 'Status file not found',
                'last_run': None
            }), 503
        
        with open(STATUS_FILE, 'r') as f:
            status = json.load(f)
        
        # Check if job ran recently (within last 25 hours)
        last_run = datetime.fromisoformat(status['end_time'])
        hours_since_run = (datetime.now() - last_run).total_seconds() / 3600
        
        if hours_since_run > 25:
            return jsonify({
                'status': 'unhealthy',
                'message': f'Job has not run in {hours_since_run:.1f} hours',
                'last_run': status['end_time'],
                'last_status': status['status']
            }), 503
        
        # Check if last run was successful
        if status['status'] != 'success':
            return jsonify({
                'status': 'unhealthy',
                'message': f"Last job failed: {status.get('error', 'Unknown error')}",
                'last_run': status['end_time'],
                'last_status': status['status']
            }), 503
        
        # All good!
        return jsonify({
            'status': 'healthy',
            'message': 'ETL job running successfully',
            'last_run': status['end_time'],
            'records_processed': status.get('records_processed', 0)
        }), 200
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'message': f'Health check error: {str(e)}'
        }), 503

@app.route('/status', methods=['GET'])
def detailed_status():
    """Detailed status endpoint (optional)"""
    try:
        with open(STATUS_FILE, 'r') as f:
            status = json.load(f)
        return jsonify(status), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Run on port 5001
    app.run(host='0.0.0.0', port=5001)
```

---

### **Step 2: Update ETL Job to Write Status**

**Modify your `daily_sla_summary.py`** to write status after each run:

**Add to your ETL job:**

```python
import json
from datetime import datetime

STATUS_FILE = '/var/log/etl/daily_sla_summary_status.json'

class DailySLASummaryETL:
    def run(self):
        start_time = datetime.now()
        
        try:
            # Your existing ETL logic
            print(f"=== Daily SLA Summary ETL Job ===")
            
            # Extract, Transform, Load...
            # ... your existing code ...
            
            # Write success status
            self.write_status({
                'status': 'success',
                'start_time': start_time.isoformat(),
                'end_time': datetime.now().isoformat(),
                'records_processed': self.stats['loaded'],
                'errors': 0
            })
            
            return True
            
        except Exception as e:
            # Write failure status
            self.write_status({
                'status': 'failed',
                'start_time': start_time.isoformat(),
                'end_time': datetime.now().isoformat(),
                'records_processed': 0,
                'error': str(e)
            })
            return False
    
    def write_status(self, status):
        """Write status to file for health check"""
        import os
        os.makedirs(os.path.dirname(STATUS_FILE), exist_ok=True)
        
        with open(STATUS_FILE, 'w') as f:
            json.dump(status, f, indent=2)
        
        print(f"Status written to {STATUS_FILE}")
```

---

### **Step 3: Run Health API on Remote Node**

**On your remote Linux edge node:**

```bash
# Install Flask
pip install flask

# Create systemd service for health API
sudo nano /etc/systemd/system/etl-health-api.service
```

**Content:**
```ini
[Unit]
Description=ETL Health Check API
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/backend/etl
ExecStart=/usr/bin/python3 /path/to/backend/etl/health_api.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**Start the service:**
```bash
sudo systemctl daemon-reload
sudo systemctl enable etl-health-api
sudo systemctl start etl-health-api
sudo systemctl status etl-health-api
```

**Test it:**
```bash
curl http://localhost:5001/health
# Should return: {"status": "healthy", ...}
```

---

### **Step 4: Fill Out "Add New Service" Modal**

**Now in your SLA Portal** (http://localhost:3010/services), click "+ Add Service":

**Fill out the modal:**

```
┌─ Add New Service ──────────────────────────────┐
│                                                 │
│ Service Name: *                                 │
│ ┌─────────────────────────────────────────────┐│
│ │ Daily SLA Summary ETL Job                   ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Description:                                    │
│ ┌─────────────────────────────────────────────┐│
│ │ Batch job that runs nightly to calculate   ││
│ │ daily SLA compliance summaries              ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Service Type: *                                 │
│ ┌─────────────────────────────────────────────┐│
│ │ API Gateway                    [▼]          ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Health Check Endpoint: *                        │
│ ┌─────────────────────────────────────────────┐│
│ │ http://your-linux-node-ip:5001/health      ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Health Check Interval (seconds): *              │
│ ┌─────────────────────────────────────────────┐│
│ │ 300                                         ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Owner/Team:                                     │
│ ┌─────────────────────────────────────────────┐│
│ │ Data Engineering Team                       ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Tags: (comma-separated)                         │
│ ┌─────────────────────────────────────────────┐│
│ │ etl, batch-job, daily                       ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│         [Cancel]              [Add Service]     │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Field Values:**

| Field | Value | Notes |
|-------|-------|-------|
| **Service Name** | `Daily SLA Summary ETL Job` | Descriptive name |
| **Description** | `Batch job that runs nightly to calculate daily SLA compliance summaries` | What it does |
| **Service Type** | `API Gateway` | Select from dropdown |
| **Health Check Endpoint** | `http://192.168.1.100:5001/health` | Replace with actual Linux node IP |
| **Health Check Interval** | `300` | Check every 5 minutes |
| **Owner/Team** | `Data Engineering Team` | Your team name |
| **Tags** | `etl, batch-job, daily` | For filtering |

---

### **Step 5: Create SLA for the ETL Job**

After adding the service, go to **SLAs** page and create an SLA:

```
┌─ Create SLA ───────────────────────────────────┐
│                                                 │
│ SLA Name: *                                     │
│ ┌─────────────────────────────────────────────┐│
│ │ Daily ETL Job Availability                  ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Service: *                                      │
│ ┌─────────────────────────────────────────────┐│
│ │ Daily SLA Summary ETL Job         [▼]      ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ SLA Type: *                                     │
│ ┌─────────────────────────────────────────────┐│
│ │ Availability                       [▼]      ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Target Value (%): *                             │
│ ┌─────────────────────────────────────────────┐│
│ │ 95.0                                        ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Measurement Window: *                           │
│ ┌─────────────────────────────────────────────┐│
│ │ 30 days                            [▼]      ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│         [Cancel]              [Create SLA]      │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Field Values:**

| Field | Value | Why |
|-------|-------|-----|
| **SLA Name** | `Daily ETL Job Availability` | Clear name |
| **Service** | `Daily SLA Summary ETL Job` | The service you just added |
| **SLA Type** | `Availability` | Job should run successfully |
| **Target Value** | `95.0` | Job should succeed 95% of time |
| **Measurement Window** | `30 days` | Over last 30 days |

---

## ✅ **APPROACH 2: Status File on Shared Network Drive (Alternative)**

If you can't run a Flask API on the remote node, use a shared network drive:

### **Step 1: ETL Job Writes Status to Network Share**

```python
# In your daily_sla_summary.py
STATUS_FILE = '//network-share/etl-status/daily_sla_summary_status.json'

def write_status(status):
    with open(STATUS_FILE, 'w') as f:
        json.dump(status, f)
```

### **Step 2: Create Health Check Endpoint on Windows Server**

**File:** `backend/etl_monitor.py` (on your Windows server)

```python
from flask import Flask, jsonify
from datetime import datetime
import json
import os

app = Flask(__name__)

STATUS_FILE = r'\\network-share\etl-status\daily_sla_summary_status.json'

@app.route('/health/etl-job', methods=['GET'])
def etl_health():
    try:
        if not os.path.exists(STATUS_FILE):
            return jsonify({'status': 'unhealthy', 'message': 'Status file not found'}), 503
        
        with open(STATUS_FILE, 'r') as f:
            status = json.load(f)
        
        last_run = datetime.fromisoformat(status['end_time'])
        hours_ago = (datetime.now() - last_run).total_seconds() / 3600
        
        if hours_ago > 25 or status['status'] != 'success':
            return jsonify({'status': 'unhealthy', **status}), 503
        
        return jsonify({'status': 'healthy', **status}), 200
    except Exception as e:
        return jsonify({'status': 'unhealthy', 'error': str(e)}), 503

if __name__ == '__main__':
    app.run(port=5002)
```

**Run it:**
```powershell
python backend/etl_monitor.py
```

**Then in the modal, use:**
```
Health Check Endpoint: http://localhost:5002/health/etl-job
```

---

## 🧪 **TESTING THE SETUP**

### **Test 1: Health Check Works**

```bash
# From your Windows machine, test the health endpoint
curl http://your-linux-node-ip:5001/health

# Expected response:
{
  "status": "healthy",
  "message": "ETL job running successfully",
  "last_run": "2025-11-27T01:05:23",
  "records_processed": 2
}
```

---

### **Test 2: Service Added Successfully**

1. Go to http://localhost:3010/services
2. Should see "Daily SLA Summary ETL Job" in the list
3. Status should show "● Healthy" (green)

---

### **Test 3: Health Checks Running**

```bash
# Check backend logs
cd backend
tail -f logs/api.log

# Should see health checks every 5 minutes:
INFO:health_check: Checking service: Daily SLA Summary ETL Job
INFO:health_check: URL: http://192.168.1.100:5001/health
INFO:health_check: Response: 200 OK - healthy
```

---

### **Test 4: Dashboard Shows ETL Job**

1. Go to http://localhost:3010/dashboard
2. Should see ETL job in "Service Health" section
3. Should show status and SLA count

---

### **Test 5: Simulate Job Failure**

**On Linux node, create a failed status:**

```bash
cat > /var/log/etl/daily_sla_summary_status.json << EOF
{
  "status": "failed",
  "start_time": "2025-11-27T01:00:00",
  "end_time": "2025-11-27T01:02:15",
  "error": "Database connection timeout",
  "records_processed": 0
}
EOF
```

**Then check:**
```bash
curl http://localhost:5001/health
# Should return 503 with error message
```

**Portal should:**
- Show service as "● Unhealthy" (red)
- Generate alert
- Show breach in compliance

---

## 📊 **EXAMPLE: Complete Modal Values**

### **Production Example:**

```
Service Name: Daily SLA Summary ETL Job
Description: Nightly batch job that calculates daily SLA compliance summaries and stores them in the data warehouse
Service Type: API Gateway
Health Check Endpoint: http://10.0.1.50:5001/health
Health Check Interval: 300
Owner/Team: Data Engineering
Tags: etl, batch, nightly, production
```

### **Test/Dev Example:**

```
Service Name: Daily ETL Job (Test)
Description: Test instance of daily SLA summary ETL
Service Type: API Gateway
Health Check Endpoint: http://localhost:5001/health
Health Check Interval: 60
Owner/Team: Data Eng - Dev
Tags: etl, batch, test
```

---

## 🔧 **TROUBLESHOOTING**

### **Issue: Can't reach health endpoint**

**Error:** Connection refused

**Check:**
1. Health API running on Linux node?
   ```bash
   systemctl status etl-health-api
   ```

2. Port 5001 open?
   ```bash
   sudo firewall-cmd --add-port=5001/tcp --permanent
   sudo firewall-cmd --reload
   ```

3. Can ping from Windows to Linux?
   ```powershell
   ping your-linux-node-ip
   ```

4. Test locally on Linux first:
   ```bash
   curl http://localhost:5001/health
   ```

---

### **Issue: Status file not found**

**Check:**
1. ETL job ran at least once?
2. Status file path correct?
3. Permissions correct?
   ```bash
   ls -la /var/log/etl/
   ```

---

### **Issue: Always shows unhealthy**

**Check status file:**
```bash
cat /var/log/etl/daily_sla_summary_status.json
```

**Check timestamps:**
- If job runs at 1 AM but it's now 3 PM, that's only 14 hours ago (should be healthy)
- If job runs at 1 AM and it's now 3 AM next day (26 hours), should be unhealthy

---

## 📋 **SUMMARY CHECKLIST**

**Setup:**
- [ ] Create health_api.py on Linux node
- [ ] Update ETL job to write status file
- [ ] Start health API service
- [ ] Test health endpoint locally
- [ ] Test health endpoint from Windows

**Portal:**
- [ ] Add ETL job as service
- [ ] Fill out all required fields
- [ ] Use correct IP:port for health endpoint
- [ ] Set check interval (300 seconds)
- [ ] Create SLA for the ETL job

**Testing:**
- [ ] Verify service appears in services list
- [ ] Verify health checks running
- [ ] Check dashboard shows service
- [ ] Simulate failure to test alerting

---

## 🎯 **FINAL MODAL VALUES (Copy-Paste Ready)**

```
Service Name:
Daily SLA Summary ETL Job

Description:
Nightly batch job that extracts SLA data, transforms compliance metrics, and loads daily summaries. Runs at 1:00 AM via cron on remote Linux edge node.

Service Type:
API Gateway

Health Check Endpoint:
http://192.168.1.100:5001/health
(Replace 192.168.1.100 with your actual Linux node IP)

Health Check Interval (seconds):
300

Owner/Team:
Data Engineering Team

Tags:
etl, batch-job, nightly, data-pipeline
```

---

**You're monitoring the job!** ✅

**Not running it through portal!** 💡

**Health checks every 5 min!** ⏰

**Alerts on failure!** 🚨

**SLA tracking works!** 📊

**Complete setup guide!** 📚

This is how you monitor remote batch jobs! 🚀
