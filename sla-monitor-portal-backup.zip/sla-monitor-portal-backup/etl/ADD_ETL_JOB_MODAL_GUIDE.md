# 📝 STEP-BY-STEP: Add Daily ETL Cron Job to Portal

## 🎯 **Your Scenario**

- **Job:** `daily_sla_summary.py`
- **Location:** Remote Linux edge node
- **Schedule:** Daily at 1:00 AM (via cron)
- **Goal:** Monitor from SLA portal on Windows server

---

## 📋 **COMPLETE MODAL WALKTHROUGH**

### **STEP 1: Basic Information**

**Click:** "+ Add Service" button on `/services` page

**You'll see a 3-step wizard:**

```
┌─────────────────────────────────────────────┐
│  Add New Service               Step 1 of 3  │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│  [████████████████] [          ] [        ] │
│   Basic Info        Service Type  Config    │
└─────────────────────────────────────────────┘
```

---

### **STEP 1: BASIC INFO (Page 1)**

Fill in these fields:

```
┌─────────────────────────────────────────────┐
│ Service Name: *                             │
│ ┌─────────────────────────────────────────┐│
│ │ Daily SLA Summary ETL Job               ││ ← TYPE THIS
│ └─────────────────────────────────────────┘│
│                                             │
│ Description:                                │
│ ┌─────────────────────────────────────────┐│
│ │ Nightly batch job that runs at 1 AM to ││ ← TYPE THIS
│ │ calculate daily SLA compliance summaries││
│ └─────────────────────────────────────────┘│
│                                             │
│ Owner Team:                                 │
│ ┌─────────────────────────────────────────┐│
│ │ Data Engineering Team                   ││ ← TYPE THIS
│ └─────────────────────────────────────────┘│
│                                             │
│              [Cancel]         [Next]        │
└─────────────────────────────────────────────┘
```

**Field Values:**

| Field | Value | Notes |
|-------|-------|-------|
| **Service Name*** | `Daily SLA Summary ETL Job` | Required - any descriptive name |
| **Description** | `Nightly batch job that runs at 1 AM to calculate daily SLA compliance summaries` | Optional - what the job does |
| **Owner Team** | `Data Engineering Team` | Optional - your team name |

**Click:** [Next] button

---

### **STEP 2: SERVICE TYPE (Page 2)**

**You'll see service categories:**

```
┌─────────────────────────────────────────────┐
│  Add New Service               Step 2 of 3  │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│  [████████] [████████████████] [          ] │
│   Basic Info   Service Type        Config   │
│                                             │
│  Select the type of service to monitor:     │
│                                             │
│  Data Management                            │
│  ┌─────────────┬─────────────┐             │
│  │ MySQL       │ PostgreSQL  │             │
│  │ MongoDB     │ Oracle      │             │
│  └─────────────┴─────────────┘             │
│                                             │
│  Application & Integration                  │
│  ┌─────────────┬─────────────┐             │
│  │ API Gateway │ Microservice│             │
│  │ NGINX       │ Apache      │             │
│  └─────────────┴─────────────┘             │
│                                             │
│  Data Processing                            │
│  ┌─────────────┬─────────────┐             │
│  │ETL Batch Job│ Spark Stream│ ← CLICK HERE│
│  │ Flink       │             │             │
│  └─────────────┴─────────────┘             │
│                                             │
│  Messaging Systems                          │
│  ┌─────────────┬─────────────┐             │
│  │ Kafka       │ IBM MQ      │             │
│  └─────────────┴─────────────┘             │
│                                             │
│              [Back]           [Next]        │
└─────────────────────────────────────────────┘
```

**Action:**
1. Scroll to **"Data Processing"** category
2. Click on **"ETL Batch Job"** box
3. Box will highlight in blue (selected)

**Click:** [Next] button

---

### **STEP 3: CONFIGURATION (Page 3)**

**Now you'll see the ETL-specific fields:**

```
┌─────────────────────────────────────────────┐
│  Add New Service               Step 3 of 3  │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│  [████████] [████████] [████████████████]   │
│   Basic Info Service Type     Config        │
│                                             │
│  ℹ️ Service Type: ETL Batch Job             │
│                                             │
│  Job Name: *                                │
│  ┌─────────────────────────────────────────┐│
│  │ daily_sla_summary                       ││ ← TYPE THIS
│  └─────────────────────────────────────────┘│
│                                             │
│  Schedule: *                                │
│  ┌─────────────────────────────────────────┐│
│  │ 0 1 * * *                               ││ ← TYPE THIS
│  └─────────────────────────────────────────┘│
│                                             │
│  Endpoint: *                                │
│  ┌─────────────────────────────────────────┐│
│  │ http://192.168.1.100:5001/health       ││ ← TYPE THIS
│  └─────────────────────────────────────────┘│
│  ⚠️ Enter only the path (e.g., /health)...  │
│                                             │
│  Api Key:                                   │
│  ┌─────────────────────────────────────────┐│
│  │                                         ││ ← LEAVE BLANK
│  └─────────────────────────────────────────┘│
│                                             │
│  [Test Connection]                          │
│                                             │
│              [Back]      [Create Service]   │
└─────────────────────────────────────────────┘
```

---

## 🔑 **FIELD-BY-FIELD VALUES**

### **Field 1: Job Name** *

**What to enter:**
```
daily_sla_summary
```

**Explanation:**
- Identifier for your ETL job
- Should match your Python script name (without .py)
- Used for logging and display

**Valid alternatives:**
- `daily_sla_summary` ✅ (recommended)
- `prod-daily-etl` ✅
- `nightly_sla_job` ✅

---

### **Field 2: Schedule** *

**What to enter:**
```
0 1 * * *
```

**Explanation:**
- Cron expression for "daily at 1 AM"
- Format: `minute hour day month weekday`
- `0 1 * * *` = minute 0, hour 1, every day

**Breaking it down:**
```
0 1 * * *
│ │ │ │ │
│ │ │ │ └─ Every day of week (0-6, where 0=Sunday)
│ │ │ └─── Every month (1-12)
│ │ └───── Every day of month (1-31)
│ └─────── Hour 1 (1 AM in 24-hour format)
└───────── Minute 0
```

**Valid alternatives:**
- `0 1 * * *` ✅ (cron format - recommended)
- `Daily at 1:00 AM` ✅ (human readable)
- `1:00 AM daily` ✅ (descriptive)

**Other cron examples (for reference):**
```
0 */6 * * *     = Every 6 hours
0 2 * * *       = Daily at 2 AM
*/30 * * * *    = Every 30 minutes
0 0 * * 0       = Weekly on Sundays at midnight
```

---

### **Field 3: Endpoint** *

**What to enter:**
```
http://192.168.1.100:5001/health
```

**⚠️ CRITICAL: Replace `192.168.1.100` with YOUR Linux node's actual IP address!**

**How to find your Linux IP:**

```bash
# On your Linux edge node, run:
ip addr show | grep "inet "
# Or
hostname -I
```

**Format:**
```
http://[YOUR_LINUX_IP]:5001/health
```

**Examples:**
```
✅ http://192.168.1.100:5001/health     (internal IP)
✅ http://10.0.50.25:5001/health        (internal IP)
✅ http://etl-server.local:5001/health  (hostname)
✅ https://etl.company.com/health       (domain)

❌ localhost:5001/health                (missing http://)
❌ /health                              (not a full URL)
❌ http://localhost:5001/health         (localhost won't work from Windows)
```

**Note about the warning message:**
- You may see: "⚠️ Enter only the path (e.g., /health)..."
- **IGNORE THIS for ETL Batch Job type**
- For ETL jobs, enter the **FULL URL** including `http://`
- That warning is for other service types

---

### **Field 4: Api Key**

**What to enter:**
```
(leave blank)
```

**Explanation:**
- Optional field
- Only needed if your health endpoint requires authentication
- For testing/internal networks, leave blank

**When to use:**
- ✅ **Leave blank** - Testing, development, internal network
- ✅ **Set a value** - Production with security requirements

**If you need auth, example value:**
```
sk-etl-health-abc123xyz789
```

---

## ✅ **COMPLETE VALUES SUMMARY**

**Copy these exact values:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1: BASIC INFO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Service Name:
Daily SLA Summary ETL Job

Description:
Nightly batch job that runs at 1 AM to calculate daily SLA compliance summaries

Owner Team:
Data Engineering Team

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 2: SERVICE TYPE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Category: Data Processing
Type: ETL Batch Job ← (Click this box)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 3: CONFIGURATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Job Name:
daily_sla_summary

Schedule:
0 1 * * *

Endpoint:
http://YOUR_LINUX_IP:5001/health
(⚠️ Replace YOUR_LINUX_IP with actual IP like 192.168.1.100)

Api Key:
(leave blank)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 🧪 **TEST CONNECTION (Optional but Recommended)**

**Before clicking "Create Service":**

1. Click **[Test Connection]** button

**What it does:**
- Portal tries to call your health endpoint
- Verifies it can reach your Linux node
- Checks if health API is responding

**Expected results:**

✅ **Success:**
```
┌─────────────────────────────────────────┐
│ ✓ Connection successful                │
│   Health endpoint responded             │
└─────────────────────────────────────────┘
```

❌ **Failure:**
```
┌─────────────────────────────────────────┐
│ ✗ Connection failed                     │
│   Could not reach health endpoint       │
│   Check endpoint URL and network        │
└─────────────────────────────────────────┘
```

**If test fails:**
- Verify Linux IP address is correct
- Check health API is running on Linux node
- Test manually: `curl http://192.168.1.100:5001/health`
- Check firewall allows port 5001
- Verify Windows can ping Linux node

---

## 📸 **VISUAL GUIDE**

### **Step 2 - Selecting Service Type:**

```
Look for this section:

Data Processing
┌──────────────────┬──────────────────┐
│ ETL Batch Job    │ Spark Streaming  │ ← Click "ETL Batch Job"
│                  │                  │
│  [Selected:      │                  │
│   Blue border]   │                  │
└──────────────────┴──────────────────┘
```

---

### **Step 3 - After Filling All Fields:**

```
Before:
┌─────────────────────────────────────────┐
│ Job Name: *                             │
│ ┌─────────────────────────────────────┐│
│ │                                     ││ ← Empty
│ └─────────────────────────────────────┘│

After:
┌─────────────────────────────────────────┐
│ Job Name: *                             │
│ ┌─────────────────────────────────────┐│
│ │ daily_sla_summary                   ││ ← Filled
│ └─────────────────────────────────────┘│

[Create Service] button becomes enabled
```

---

## 🚀 **FINAL STEPS**

**After filling all fields:**

1. **Optional:** Click [Test Connection]
2. **Click:** [Create Service] button
3. **Wait:** Service is being created...
4. **Success:** Modal closes, you're back on `/services` page
5. **Verify:** New service appears in the list

**You should see:**

```
Services Page

┌──────────────────────────────────────────────┐
│ Service Name              Status    SLA Count│
├──────────────────────────────────────────────┤
│ Daily SLA Summary ETL Job ● Pending    0    │ ← New service
├──────────────────────────────────────────────┤
│ Grafana Service           ● Unhealthy  1    │
│ Prometheus Service        ● Unhealthy  1    │
└──────────────────────────────────────────────┘
```

**Initial Status:**
- May show "Pending" or "Unknown"
- After first health check (5 min), will show "Healthy" or "Unhealthy"

---

## ⚠️ **COMMON MISTAKES TO AVOID**

### **Mistake 1: Wrong Endpoint Format**

❌ **Wrong:**
```
Endpoint: localhost:5001/health
Endpoint: /health
Endpoint: 192.168.1.100:5001/health
```

✅ **Correct:**
```
Endpoint: http://192.168.1.100:5001/health
```

---

### **Mistake 2: Using localhost**

❌ **Wrong:**
```
Endpoint: http://localhost:5001/health
```
**Why:** Portal runs on Windows, job runs on Linux - localhost won't work!

✅ **Correct:**
```
Endpoint: http://192.168.1.100:5001/health
```
**Why:** Uses actual Linux node IP reachable from Windows

---

### **Mistake 3: Wrong Service Type**

❌ **Wrong:**
- Selecting "API Gateway" instead of "ETL Batch Job"
- Different fields will appear!

✅ **Correct:**
- Data Processing → **ETL Batch Job**

---

### **Mistake 4: Invalid Cron Schedule**

❌ **Wrong:**
```
Schedule: 1:00 AM
Schedule: 1 AM
Schedule: at 1am
```

✅ **Correct:**
```
Schedule: 0 1 * * *
```
**Or human-readable:**
```
Schedule: Daily at 1:00 AM
```

---

## 🔍 **VERIFICATION CHECKLIST**

**After creating service:**

- [ ] Service appears in `/services` list
- [ ] Service name is correct
- [ ] Click service to view details
- [ ] Details show correct endpoint
- [ ] Details show correct schedule
- [ ] Wait 5 minutes for first health check
- [ ] Status changes from "Pending" to "Healthy" or "Unhealthy"
- [ ] Dashboard shows the service
- [ ] Can create SLA for this service

---

## 🎯 **QUICK REFERENCE CARD**

**Print this and keep handy:**

```
┌─────────────────────────────────────────┐
│ ETL CRON JOB - MODAL VALUES             │
├─────────────────────────────────────────┤
│ STEP 1: Basic Info                      │
│   Service Name: Daily SLA Summary ETL   │
│   Description: Nightly batch job...     │
│   Owner: Data Engineering Team          │
│                                         │
│ STEP 2: Service Type                    │
│   Category: Data Processing             │
│   Type: ETL Batch Job ← CLICK THIS      │
│                                         │
│ STEP 3: Configuration                   │
│   Job Name: daily_sla_summary           │
│   Schedule: 0 1 * * *                   │
│   Endpoint: http://[LINUX_IP]:5001/health│
│   Api Key: (blank)                      │
│                                         │
│ MUST DO FIRST:                          │
│   1. Set up health API on Linux         │
│   2. Get Linux node IP address          │
│   3. Test: curl http://IP:5001/health   │
└─────────────────────────────────────────┘
```

---

## 📋 **PRE-REQUISITES**

**Before using the modal, ensure:**

✅ **On Linux Node:**
- [ ] Health API script created (`health_api.py`)
- [ ] Health API running on port 5001
- [ ] ETL job writes status file
- [ ] Firewall allows port 5001
- [ ] Know the Linux node's IP address

✅ **On Windows Server:**
- [ ] Portal running (http://localhost:3010)
- [ ] Can ping Linux node
- [ ] Can reach health endpoint from Windows
- [ ] Logged into portal

**Test from Windows:**
```powershell
# Test connectivity
ping 192.168.1.100

# Test port
Test-NetConnection -ComputerName 192.168.1.100 -Port 5001

# Test health endpoint
curl http://192.168.1.100:5001/health
```

---

## ✅ **SUCCESS CRITERIA**

**You'll know it worked when:**

1. ✅ Modal closes without errors
2. ✅ Service appears in services list
3. ✅ Can click service to see details
4. ✅ After 5 minutes, status updates to Healthy/Unhealthy
5. ✅ Dashboard shows the service
6. ✅ Can create SLA for the service

---

## 🎓 **SUMMARY**

**Service Type to Use:**
```
Data Processing → ETL Batch Job
```

**Field Values:**
```
Job Name:    daily_sla_summary
Schedule:    0 1 * * *
Endpoint:    http://YOUR_LINUX_IP:5001/health
Api Key:     (leave blank)
```

**Critical Points:**
- ⚠️ Use **full URL** with `http://` in Endpoint
- ⚠️ Replace **YOUR_LINUX_IP** with actual IP
- ⚠️ Schedule is **cron format**: `0 1 * * *`
- ⚠️ Test connection before creating

---

**Now you're ready to add your ETL job!** 🚀
