# 📋 ETL BATCH JOB - FIELD VALUES GUIDE

## 🎯 **Your Use Case**

**Setup:**
- ETL Job: `daily_sla_summary.py` on remote Linux node
- Schedule: Daily at 1:00 AM (cron)
- Portal: Windows server (localhost:3010)
- Service Type: **ETL Batch Job**

---

## 📝 **REQUIRED FIELDS & VALUES**

When you select "ETL Batch Job" service type, you'll see these 4 fields in Step 3:

---

### **1. Job Name** ✅

**What it is:**
- A unique identifier for your ETL job
- Used for logging and identification

**Valid Values:**
- Any alphanumeric string
- Can include underscores, hyphens, spaces
- Should be descriptive

**Recommended for Your Case:**
```
daily_sla_summary
```

**Other Examples:**
```
daily_sla_summary
nightly-etl-job
SLA_Summary_ETL_v1
prod-daily-sla-job
```

**What Portal Does:**
- Stores this in service metadata
- Uses for display and logging
- No validation rules (just text storage)

---

### **2. Schedule** ⏰

**What it is:**
- Describes when your ETL job runs
- **IMPORTANT:** This is for DOCUMENTATION only!
- Portal does **NOT** use this to trigger your job
- Your cron is what actually runs the job

**Valid Values:**
- Cron expression format (recommended)
- Human-readable format
- Any text that describes the schedule

**Recommended for Your Case:**
```
0 1 * * *
```
(This is the cron expression for "daily at 1 AM")

**Alternative Formats:**

**Cron Expression:**
```
0 1 * * *
```

**Human Readable:**
```
Daily at 1:00 AM
```

**Verbose:**
```
Runs daily at 1:00 AM UTC via cron
```

**ISO Format:**
```
Daily 01:00
```

---

### **🔍 CRON EXPRESSION GUIDE**

**Format:** `minute hour day month weekday`

**Your Case:** `0 1 * * *`
- `0` = minute 0 (on the hour)
- `1` = hour 1 (1 AM)
- `*` = every day
- `*` = every month
- `*` = every weekday

**Other Examples:**

| Schedule | Cron Expression | Description |
|----------|----------------|-------------|
| Every hour | `0 * * * *` | At minute 0 of every hour |
| Every 30 min | `*/30 * * * *` | Every 30 minutes |
| Daily 2 AM | `0 2 * * *` | Daily at 2 AM |
| Weekdays 6 AM | `0 6 * * 1-5` | Mon-Fri at 6 AM |
| 1st of month | `0 0 1 * *` | Midnight on 1st day |
| Every 6 hours | `0 */6 * * *` | 12 AM, 6 AM, 12 PM, 6 PM |

**Testing Cron:**
```bash
# Validate cron expression online:
# https://crontab.guru/

# Or test locally:
echo "0 1 * * * /path/to/job.py" | crontab -l
```

---

### **How Schedule Works in Your Case:**

```
YOUR CRON                           SLA PORTAL
┌────────────────┐                 ┌────────────────┐
│ Linux Edge Node│                 │ Windows Server │
│                │                 │                │
│ crontab:       │                 │ Service:       │
│ 0 1 * * *      │                 │ Schedule field │
│ job.py         │                 │ "0 1 * * *"    │
│                │                 │                │
│ ✓ Runs job     │                 │ ✓ Documents    │
│ ✓ Executes     │                 │   when job runs│
│ ✓ Triggers     │                 │ ✓ Shows in UI  │
│                │                 │ ✗ Doesn't run  │
└────────────────┘                 └────────────────┘
```

**Important Points:**

1. **Portal does NOT run your job**
   - Your cron on Linux runs it
   - Portal only monitors it

2. **Schedule field is for documentation**
   - Helps you know when job should run
   - Displayed in service details
   - Used for reports/dashboards

3. **Portal checks if job ran successfully**
   - Via health endpoint
   - Based on status file
   - Not based on schedule field

---

### **3. Endpoint** 🌐

**What it is:**
- Health check endpoint to monitor job status
- **Must be an HTTP/HTTPS URL**
- Portal calls this to check if job is healthy

**Valid Values:**
- Must start with `http://` or `https://`
- Can be IP address or hostname
- Must include port if not 80/443
- Path is optional

**Recommended for Your Case:**

**If you set up health API on Linux node:**
```
http://192.168.1.100:5001/health
```
(Replace `192.168.1.100` with your actual Linux node IP)

**Format:**
```
http://[IP or hostname]:[port]/[path]
```

**Examples:**

| Scenario | Endpoint Value |
|----------|---------------|
| Linux node IP with Flask API | `http://10.0.1.50:5001/health` |
| Linux node hostname | `http://etl-server.local:5001/health` |
| Localhost (testing) | `http://localhost:5001/health` |
| HTTPS with domain | `https://etl.company.com/api/health` |
| Custom port | `http://192.168.1.100:8080/etl/status` |

**What Portal Does:**
1. Calls this endpoint every N minutes (configurable)
2. Expects HTTP 200 = healthy, 503 = unhealthy
3. Records result in database
4. Updates service health status
5. Triggers alerts if unhealthy

**IMPORTANT Notes:**

❌ **Don't put:**
- Just a path: `/health` (missing protocol and host)
- File path: `C:\logs\status.json`
- Localhost if portal can't reach it

✅ **Do put:**
- Full URL with protocol
- Reachable from Windows server
- Endpoint that returns health status

---

### **4. API Key** 🔑

**What it is:**
- Optional authentication key for health endpoint
- Sent in request header
- Protects your health endpoint

**Valid Values:**
- Any string
- Can be left blank if not needed
- Typically alphanumeric token

**For Your Case:**

**Option 1: Leave Blank (No Auth)**
```
(leave empty)
```
Use this if:
- Health endpoint doesn't require auth
- Running on internal network
- Testing/development

**Option 2: Set an API Key**
```
sk-etl-health-check-abc123xyz789
```
Use this if:
- Health endpoint requires authentication
- Production environment
- Security requirement

---

### **How API Key Works:**

**If you provide an API key:**

```
Portal sends request:
GET http://192.168.1.100:5001/health
Headers:
  X-API-Key: sk-etl-health-check-abc123xyz789
  Authorization: Bearer sk-etl-health-check-abc123xyz789
```

**Your health API must check for this key:**

```python
@app.route('/health', methods=['GET'])
def health():
    # Check API key
    api_key = request.headers.get('X-API-Key') or \
              request.headers.get('Authorization', '').replace('Bearer ', '')
    
    if api_key != 'sk-etl-health-check-abc123xyz789':
        return jsonify({'error': 'Unauthorized'}), 401
    
    # Return health status
    return jsonify({'status': 'healthy'}), 200
```

**If you leave it blank:**

```
Portal sends request:
GET http://192.168.1.100:5001/health
(No auth headers)
```

**Your health API doesn't check:**

```python
@app.route('/health', methods=['GET'])
def health():
    # No auth check needed
    return jsonify({'status': 'healthy'}), 200
```

---

## 📋 **COMPLETE EXAMPLE FOR YOUR CASE**

### **Scenario: Daily SLA Summary ETL Job**

**Step 1: Basic Info**
```
Service Name: Daily SLA Summary ETL
Description: Batch job that runs nightly to calculate daily SLA compliance summaries
Owner Team: Data Engineering
```

**Step 2: Service Type**
```
Select: Data Processing → ETL Batch Job
```

**Step 3: Configuration**

```
┌─────────────────────────────────────────────────┐
│ Job Name: *                                     │
│ ┌─────────────────────────────────────────────┐│
│ │ daily_sla_summary                           ││
│ └─────────────────────────────────────────────┘│
│                                                 │
│ Schedule: *                                     │
│ ┌─────────────────────────────────────────────┐│
│ │ 0 1 * * *                                   ││
│ └─────────────────────────────────────────────┘│
│   ℹ️ Cron expression for daily at 1 AM         │
│                                                 │
│ Endpoint: *                                     │
│ ┌─────────────────────────────────────────────┐│
│ │ http://192.168.1.100:5001/health           ││
│ └─────────────────────────────────────────────┘│
│   ⚠️ Replace with your Linux node IP           │
│                                                 │
│ Api Key:                                        │
│ ┌─────────────────────────────────────────────┐│
│ │ (leave blank for no auth)                   ││
│ └─────────────────────────────────────────────┘│
│   ℹ️ Optional - only if health endpoint needs  │
│      authentication                             │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 🔧 **SETUP CHECKLIST**

**Before filling out the form:**

1. **Set up health API on Linux node**
   ```bash
   # Create health_api.py
   # Start Flask app on port 5001
   python health_api.py
   ```

2. **Test health endpoint**
   ```bash
   # From Linux node
   curl http://localhost:5001/health
   
   # From Windows server
   curl http://192.168.1.100:5001/health
   ```

3. **Get your Linux node IP**
   ```bash
   # On Linux node
   ip addr show
   # Or
   hostname -I
   ```

4. **Decide on authentication**
   - No auth: Leave API key blank
   - With auth: Generate key and update health API

**Then fill out form with values above.**

---

## ✅ **VALIDATION RULES**

**What Portal Accepts:**

| Field | Required | Format | Example |
|-------|----------|--------|---------|
| Job Name | Yes | Any text | `daily_sla_summary` |
| Schedule | Yes | Any text | `0 1 * * *` or `Daily at 1 AM` |
| Endpoint | Yes | Valid URL | `http://10.0.1.50:5001/health` |
| API Key | No | Any text | `sk-abc123` or blank |

**What Portal Validates:**

✅ **Accepts:**
- Job Name: Any non-empty string
- Schedule: Any text (no validation)
- Endpoint: Must be valid URL format
- API Key: Any string or blank

❌ **Rejects:**
- Empty required fields
- Invalid URL format in endpoint
- Non-string values

---

## 🎯 **DIFFERENT SCENARIOS**

### **Scenario 1: Testing Locally**
```
Job Name: test_etl_job
Schedule: */5 * * * * (every 5 minutes)
Endpoint: http://localhost:5001/health
Api Key: (blank)
```

### **Scenario 2: Production with Auth**
```
Job Name: prod_daily_sla_summary
Schedule: 0 1 * * *
Endpoint: https://etl.company.com/health
Api Key: sk-prod-etl-check-xyz789abc123
```

### **Scenario 3: Multiple Jobs**
```
Job 1:
  Job Name: daily_sla_summary
  Schedule: 0 1 * * *
  Endpoint: http://etl-node-1:5001/health

Job 2:
  Job Name: hourly_metrics_rollup
  Schedule: 0 * * * *
  Endpoint: http://etl-node-2:5002/health
```

---

## 🐛 **TROUBLESHOOTING**

### **Issue: "Invalid endpoint"**

**Error:** Field validation fails

**Fix:**
- Must start with `http://` or `https://`
- Check for typos
- Test URL in browser first

**Before:**
```
❌ localhost:5001/health
❌ 192.168.1.100:5001/health
❌ /health
```

**After:**
```
✅ http://localhost:5001/health
✅ http://192.168.1.100:5001/health
```

---

### **Issue: "Connection test failed"**

**Error:** Can't reach endpoint

**Check:**
1. Health API running?
   ```bash
   ps aux | grep health_api
   ```

2. Port accessible?
   ```bash
   nc -zv 192.168.1.100 5001
   ```

3. Firewall open?
   ```bash
   sudo firewall-cmd --list-ports
   ```

4. Can Windows reach Linux?
   ```powershell
   Test-NetConnection -ComputerName 192.168.1.100 -Port 5001
   ```

---

## 📊 **SUMMARY TABLE**

| Field | Your Value | Why | Portal Uses For |
|-------|-----------|-----|-----------------|
| **Job Name** | `daily_sla_summary` | Identifies your job | Display, logging |
| **Schedule** | `0 1 * * *` | Documents when it runs | Display only |
| **Endpoint** | `http://192.168.1.100:5001/health` | Where to check health | Health monitoring |
| **API Key** | `(blank)` | No auth needed | Auth header (optional) |

---

## 🎓 **KEY TAKEAWAYS**

1. **Job Name** = Any descriptive text identifier
   - `daily_sla_summary` ✅

2. **Schedule** = Documentation only (not used to run job)
   - Use cron format: `0 1 * * *` ✅
   - Or human readable: `Daily at 1 AM` ✅

3. **Endpoint** = Full URL to health check
   - Must include protocol: `http://` ✅
   - Must be reachable from Windows ✅

4. **API Key** = Optional authentication
   - Leave blank if no auth ✅
   - Set if health endpoint requires it ✅

---

## 🚀 **READY TO GO**

**Copy-paste these values:**

```
Job Name:
daily_sla_summary

Schedule:
0 1 * * *

Endpoint:
http://192.168.1.100:5001/health
(⚠️ Replace 192.168.1.100 with your Linux node IP)

Api Key:
(leave blank)
```

**That's it!** 🎉

The portal will:
- Store these values
- Check the endpoint every 5 minutes
- Show health status on dashboard
- Alert if job fails

Your cron will:
- Continue running as scheduled
- Write status file
- Health API serves status
- Portal monitors result

---

**Schedule is documentation!** 📝

**Endpoint must be reachable!** 🌐

**API Key is optional!** 🔑

**Portal monitors, doesn't run!** 👁️

**Values validated on submit!** ✅

**Test connection before saving!** 🧪
