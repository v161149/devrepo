# ⏰ ETL JOB SCHEDULE ADHERENCE MONITORING

## 🎯 **Your Requirement**

**Goal:** Ensure ETL job starts on time (1:00 AM daily)

**SLA:** "Meet Schedule" - Job must start within acceptable window

**Breach Condition:** If job doesn't start at 1:00 AM, breach the SLA

---

## 🔍 **THE CHALLENGE**

**Current System:**
- Portal checks if job is **healthy** (succeeded)
- Portal does **NOT** check if job started **on time**
- Schedule field is **documentation only**

**What You Need:**
- Portal checks **when** job last ran
- Compare to **expected schedule**
- Alert if job **missed schedule**

---

## ✅ **SOLUTION: Implement Schedule Validation**

### **Approach Overview:**

```
1. ETL job writes start_time to status file
2. Health endpoint returns last_run_time
3. Portal compares to expected schedule
4. If too late or too early → Unhealthy
5. SLA breach triggered
```

---

## 🔧 **IMPLEMENTATION**

### **Step 1: Update ETL Job to Track Start Time**

**Modify your `daily_sla_summary.py`:**

```python
#!/usr/bin/env python3
"""
Daily SLA Summary ETL Job with Schedule Tracking
"""

import json
import os
from datetime import datetime, timedelta

STATUS_FILE = '/var/log/etl/daily_sla_summary_status.json'

class DailySLASummaryETL:
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.expected_schedule = "0 1 * * *"  # Daily at 1 AM
    
    def run(self):
        """Main ETL process with schedule tracking"""
        self.start_time = datetime.now()
        
        print(f"=== Daily SLA Summary ETL Job ===")
        print(f"Start Time: {self.start_time}")
        print(f"Expected Schedule: {self.expected_schedule}")
        
        try:
            # Your existing ETL logic
            print("Step 1: EXTRACT...")
            # ... extract logic ...
            
            print("Step 2: TRANSFORM...")
            # ... transform logic ...
            
            print("Step 3: LOAD...")
            # ... load logic ...
            
            self.end_time = datetime.now()
            
            # Write success status with timing
            self.write_status({
                'status': 'success',
                'start_time': self.start_time.isoformat(),
                'end_time': self.end_time.isoformat(),
                'duration_seconds': (self.end_time - self.start_time).total_seconds(),
                'expected_schedule': self.expected_schedule,
                'records_processed': 100,  # Your actual count
                'message': 'ETL job completed successfully'
            })
            
            print(f"✓ Job completed successfully")
            print(f"Duration: {(self.end_time - self.start_time).total_seconds():.2f} seconds")
            
            return True
            
        except Exception as e:
            self.end_time = datetime.now()
            
            # Write failure status
            self.write_status({
                'status': 'failed',
                'start_time': self.start_time.isoformat(),
                'end_time': self.end_time.isoformat(),
                'duration_seconds': (self.end_time - self.start_time).total_seconds(),
                'expected_schedule': self.expected_schedule,
                'error': str(e),
                'message': f'ETL job failed: {str(e)}'
            })
            
            print(f"✗ Job failed: {str(e)}")
            return False
    
    def write_status(self, status):
        """Write status to file for health check"""
        os.makedirs(os.path.dirname(STATUS_FILE), exist_ok=True)
        
        with open(STATUS_FILE, 'w') as f:
            json.dump(status, f, indent=2)
        
        print(f"Status written to {STATUS_FILE}")

if __name__ == '__main__':
    import sys
    etl = DailySLASummaryETL()
    success = etl.run()
    sys.exit(0 if success else 1)
```

**Example status file output:**
```json
{
  "status": "success",
  "start_time": "2025-11-27T01:02:15",
  "end_time": "2025-11-27T01:05:23",
  "duration_seconds": 188.5,
  "expected_schedule": "0 1 * * *",
  "records_processed": 100,
  "message": "ETL job completed successfully"
}
```

---

### **Step 2: Create Schedule-Aware Health Endpoint**

**Update your `health_api.py` on Linux node:**

```python
#!/usr/bin/env python3
"""
ETL Job Health Check API with Schedule Validation
"""

from flask import Flask, jsonify, request
from datetime import datetime, timedelta
import json
import os

app = Flask(__name__)

STATUS_FILE = '/var/log/etl/daily_sla_summary_status.json'

def parse_cron_schedule(cron_expression):
    """
    Parse cron expression to get expected run times
    For now, supports daily schedules
    """
    parts = cron_expression.split()
    if len(parts) != 5:
        return None
    
    minute = int(parts[0])
    hour = int(parts[1])
    
    return {'hour': hour, 'minute': minute}

def get_expected_run_time(schedule_dict, reference_time=None):
    """
    Get the most recent expected run time based on schedule
    """
    if not schedule_dict:
        return None
    
    if reference_time is None:
        reference_time = datetime.now()
    
    # For daily schedule, get today's expected run time
    expected = reference_time.replace(
        hour=schedule_dict['hour'],
        minute=schedule_dict['minute'],
        second=0,
        microsecond=0
    )
    
    # If expected time is in the future, use yesterday's run time
    if expected > reference_time:
        expected = expected - timedelta(days=1)
    
    return expected

def check_schedule_adherence(last_run_str, cron_schedule, tolerance_minutes=30):
    """
    Check if job ran within acceptable time window
    
    Args:
        last_run_str: ISO format timestamp of last run
        cron_schedule: Cron expression (e.g., "0 1 * * *")
        tolerance_minutes: Acceptable deviation from schedule
    
    Returns:
        dict: {
            'on_schedule': bool,
            'minutes_late': int,
            'expected_time': str,
            'actual_time': str,
            'message': str
        }
    """
    try:
        # Parse cron schedule
        schedule = parse_cron_schedule(cron_schedule)
        if not schedule:
            return {
                'on_schedule': False,
                'error': 'Invalid cron schedule format'
            }
        
        # Get expected run time
        expected_time = get_expected_run_time(schedule)
        
        # Parse actual run time
        actual_time = datetime.fromisoformat(last_run_str)
        
        # Calculate difference
        time_diff = actual_time - expected_time
        minutes_diff = time_diff.total_seconds() / 60
        
        # Check if within tolerance
        on_schedule = abs(minutes_diff) <= tolerance_minutes
        
        return {
            'on_schedule': on_schedule,
            'minutes_late': int(minutes_diff),
            'expected_time': expected_time.isoformat(),
            'actual_time': actual_time,
            'message': (
                f"Job ran {int(abs(minutes_diff))} minutes "
                f"{'late' if minutes_diff > 0 else 'early'}"
                if not on_schedule else
                "Job ran on schedule"
            )
        }
        
    except Exception as e:
        return {
            'on_schedule': False,
            'error': str(e)
        }

@app.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint with schedule validation
    """
    try:
        # Read status file
        if not os.path.exists(STATUS_FILE):
            return jsonify({
                'status': 'unhealthy',
                'message': 'Status file not found - job may not have run yet',
                'last_run': None
            }), 503
        
        with open(STATUS_FILE, 'r') as f:
            status = json.load(f)
        
        # Check if job ran recently (within last 25 hours for daily job)
        last_run = datetime.fromisoformat(status['start_time'])
        hours_since_run = (datetime.now() - last_run).total_seconds() / 3600
        
        if hours_since_run > 25:
            return jsonify({
                'status': 'unhealthy',
                'message': f'Job has not run in {hours_since_run:.1f} hours',
                'last_run': status['start_time'],
                'expected_schedule': status.get('expected_schedule', 'Unknown')
            }), 503
        
        # Check schedule adherence
        schedule_check = check_schedule_adherence(
            status['start_time'],
            status.get('expected_schedule', '0 1 * * *'),
            tolerance_minutes=30  # Accept ±30 minutes
        )
        
        # Check if last run was successful
        if status['status'] != 'success':
            return jsonify({
                'status': 'unhealthy',
                'message': f"Last job failed: {status.get('error', 'Unknown error')}",
                'last_run': status['start_time'],
                'job_status': status['status'],
                'schedule_adherence': schedule_check
            }), 503
        
        # Check schedule adherence
        if not schedule_check.get('on_schedule', True):
            return jsonify({
                'status': 'unhealthy',
                'message': f"Job ran off-schedule: {schedule_check['message']}",
                'last_run': status['start_time'],
                'job_status': status['status'],
                'schedule_adherence': schedule_check
            }), 503
        
        # All checks passed - healthy
        return jsonify({
            'status': 'healthy',
            'message': 'ETL job running successfully and on schedule',
            'last_run': status['start_time'],
            'job_status': status['status'],
            'duration_seconds': status.get('duration_seconds'),
            'records_processed': status.get('records_processed'),
            'schedule_adherence': schedule_check
        }), 200
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'message': f'Health check error: {str(e)}'
        }), 503

@app.route('/schedule-status', methods=['GET'])
def schedule_status():
    """
    Detailed schedule adherence endpoint
    """
    try:
        with open(STATUS_FILE, 'r') as f:
            status = json.load(f)
        
        schedule_check = check_schedule_adherence(
            status['start_time'],
            status.get('expected_schedule', '0 1 * * *'),
            tolerance_minutes=30
        )
        
        return jsonify({
            'job_name': 'daily_sla_summary',
            'expected_schedule': status.get('expected_schedule'),
            'last_run': status['start_time'],
            'adherence': schedule_check
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=False)
```

---

### **Step 3: Test Schedule Validation**

**Create test status files:**

**✅ On Schedule (1:02 AM - within tolerance):**
```bash
cat > /var/log/etl/daily_sla_summary_status.json << 'EOF'
{
  "status": "success",
  "start_time": "2025-11-27T01:02:15",
  "end_time": "2025-11-27T01:05:23",
  "expected_schedule": "0 1 * * *",
  "records_processed": 100
}
EOF

curl http://localhost:5001/health
```

**Expected Response:**
```json
{
  "status": "healthy",
  "message": "ETL job running successfully and on schedule",
  "schedule_adherence": {
    "on_schedule": true,
    "minutes_late": 2,
    "message": "Job ran on schedule"
  }
}
```

---

**❌ Late (1:45 AM - outside tolerance):**
```bash
cat > /var/log/etl/daily_sla_summary_status.json << 'EOF'
{
  "status": "success",
  "start_time": "2025-11-27T01:45:00",
  "end_time": "2025-11-27T01:48:00",
  "expected_schedule": "0 1 * * *"
}
EOF

curl http://localhost:5001/health
```

**Expected Response:**
```json
{
  "status": "unhealthy",
  "message": "Job ran off-schedule: Job ran 45 minutes late",
  "schedule_adherence": {
    "on_schedule": false,
    "minutes_late": 45,
    "message": "Job ran 45 minutes late"
  }
}
```
**HTTP Status: 503** → Portal marks as unhealthy → SLA breach!

---

### **Step 4: Configure Tolerance**

**Adjust acceptable deviation:**

```python
# In health_api.py, line ~XXX:

# Strict: Only accept ±5 minutes
tolerance_minutes=5

# Moderate: Accept ±30 minutes (default)
tolerance_minutes=30

# Relaxed: Accept ±60 minutes
tolerance_minutes=60
```

**Examples:**

| Scheduled | Started | Tolerance | On Schedule? |
|-----------|---------|-----------|--------------|
| 1:00 AM | 1:02 AM | ±30 min | ✅ Yes (2 min late) |
| 1:00 AM | 1:45 AM | ±30 min | ❌ No (45 min late) |
| 1:00 AM | 12:50 AM | ±30 min | ✅ Yes (10 min early) |
| 1:00 AM | 1:06 AM | ±5 min | ❌ No (6 min late) |
| 1:00 AM | 2:00 AM | ±60 min | ❌ No (60 min late) |

---

### **Step 5: Add Service in Portal**

**Fill out the modal:**

```
Step 1: Basic Info
  Service Name: Daily SLA Summary ETL
  Description: Nightly batch job - must run at 1:00 AM
  Owner Team: Data Engineering

Step 2: Service Type
  Data Processing → ETL Batch Job

Step 3: Configuration
  Job Name: daily_sla_summary
  Schedule: 0 1 * * *
  Endpoint: http://192.168.1.100:5001/health
  API Key: (blank)
```

**Portal will now:**
1. Call health endpoint every 5 minutes
2. Health endpoint checks schedule adherence
3. Returns 503 if job ran off-schedule
4. Portal marks service as unhealthy
5. SLA breach recorded

---

### **Step 6: Create "Meet Schedule" SLA**

**Go to SLAs page → Create SLA:**

```
┌─ Create SLA ───────────────────────────────┐
│                                             │
│ SLA Name: *                                 │
│ ┌─────────────────────────────────────────┐│
│ │ ETL Job Schedule Adherence              ││
│ └─────────────────────────────────────────┘│
│                                             │
│ Service: *                                  │
│ ┌─────────────────────────────────────────┐│
│ │ Daily SLA Summary ETL         [▼]      ││
│ └─────────────────────────────────────────┘│
│                                             │
│ SLA Type: *                                 │
│ ┌─────────────────────────────────────────┐│
│ │ Availability                   [▼]      ││
│ └─────────────────────────────────────────┘│
│                                             │
│ Target Value (%): *                         │
│ ┌─────────────────────────────────────────┐│
│ │ 99.0                                    ││
│ └─────────────────────────────────────────┘│
│                                             │
│ Measurement Window: *                       │
│ ┌─────────────────────────────────────────┐│
│ │ 30 days                        [▼]      ││
│ └─────────────────────────────────────────┘│
│                                             │
│ Description:                                │
│ ┌─────────────────────────────────────────┐│
│ │ ETL job must start within ±30 minutes  ││
│ │ of scheduled time (1:00 AM daily)      ││
│ └─────────────────────────────────────────┘│
│                                             │
└─────────────────────────────────────────────┘
```

**SLA Explanation:**

- **Name:** ETL Job Schedule Adherence
- **Type:** Availability (job must be "healthy" = on schedule)
- **Target:** 99% availability over 30 days
- **Means:** Job can miss schedule ~7 hours/month (0.3 days)

---

## 📊 **HOW IT WORKS**

### **Timeline Example:**

```
Day 1: November 27
─────────────────────────────────────────────

12:55 AM - Portal health check
  ↓ Calls: http://192.168.1.100:5001/health
  ↓ Health API: "Last run was yesterday 1:02 AM - OK"
  ↓ Returns: 200 OK
  ✓ Service: Healthy

1:00 AM - Cron triggers ETL job
  ↓ Job starts: 1:00:03 AM (3 seconds late - normal)
  ✓ Within tolerance

1:05 AM - ETL job completes
  ↓ Writes status file:
  ↓   start_time: 2025-11-27T01:00:03
  ↓   status: success
  ✓ Status updated

1:10 AM - Portal health check
  ↓ Calls: http://192.168.1.100:5001/health
  ↓ Health API reads status file
  ↓ Checks: start_time vs expected (1:00 AM)
  ↓ Difference: 3 seconds (0.05 minutes)
  ↓ Tolerance: ±30 minutes
  ✓ On schedule!
  ↓ Returns: 200 OK
  ✓ Service: Healthy
  ✓ SLA: Compliant

─────────────────────────────────────────────

Day 2: November 28 (DELAYED START)
─────────────────────────────────────────────

1:00 AM - Cron triggers... but job delayed
  ↓ Server busy, job waits in queue
  ⚠️ Job doesn't start

1:40 AM - Job finally starts
  ↓ Job starts: 1:40:00 AM (40 minutes late!)
  ❌ Outside tolerance

1:45 AM - ETL job completes
  ↓ Writes status file:
  ↓   start_time: 2025-11-28T01:40:00
  ↓   status: success
  ✓ Status updated

1:50 AM - Portal health check
  ↓ Calls: http://192.168.1.100:5001/health
  ↓ Health API reads status file
  ↓ Checks: start_time vs expected (1:00 AM)
  ↓ Difference: 40 minutes late
  ↓ Tolerance: ±30 minutes
  ❌ OFF SCHEDULE!
  ↓ Returns: 503 Service Unavailable
  ❌ Service: Unhealthy
  ❌ SLA: BREACHED
  ↓ Portal generates alert
  📧 Email sent to team
```

---

## 🎯 **BREACH SCENARIOS**

### **Scenario 1: Job Starts Late**

```
Expected: 1:00 AM
Actual:   1:45 AM (45 min late)
Tolerance: ±30 min
Result: ❌ BREACH
Reason: Outside tolerance window
```

### **Scenario 2: Job Starts Early**

```
Expected: 1:00 AM
Actual:   12:20 AM (40 min early)
Tolerance: ±30 min
Result: ❌ BREACH
Reason: Started too early
```

### **Scenario 3: Job Doesn't Run**

```
Expected: 1:00 AM
Actual:   (no run)
Last Run: Yesterday 1:02 AM (25 hours ago)
Result: ❌ BREACH
Reason: Job didn't run at all
```

### **Scenario 4: Job On Time**

```
Expected: 1:00 AM
Actual:   1:02 AM (2 min late)
Tolerance: ±30 min
Result: ✅ COMPLIANT
Reason: Within tolerance window
```

---

## 📈 **COMPLIANCE CALCULATION**

**Over 30 days:**

```
Total Expected Runs: 30
Runs On Schedule: 28
Runs Off Schedule: 2

Compliance = (28 / 30) × 100 = 93.33%

SLA Target: 99%
Result: ❌ BREACH (93.33% < 99%)
```

**Alert Generated:**
- SLA Name: ETL Job Schedule Adherence
- Service: Daily SLA Summary ETL
- Current Compliance: 93.33%
- Target: 99%
- Status: BREACHED

---

## 🔧 **CONFIGURATION OPTIONS**

### **Option 1: Strict Schedule (±5 minutes)**

```python
tolerance_minutes=5
```

**Use when:**
- Critical timing requirements
- Downstream dependencies
- Precise scheduling needed

**Example:**
- 1:00 AM scheduled
- 1:06 AM actual
- Result: ❌ BREACH (6 min > 5 min tolerance)

---

### **Option 2: Moderate (±30 minutes) - Recommended**

```python
tolerance_minutes=30
```

**Use when:**
- Normal ETL operations
- Some flexibility acceptable
- Standard SLA requirements

**Example:**
- 1:00 AM scheduled
- 1:25 AM actual
- Result: ✅ COMPLIANT (25 min < 30 min tolerance)

---

### **Option 3: Relaxed (±60 minutes)**

```python
tolerance_minutes=60
```

**Use when:**
- Non-critical jobs
- High server load expected
- Flexible deadlines

**Example:**
- 1:00 AM scheduled
- 1:55 AM actual
- Result: ✅ COMPLIANT (55 min < 60 min tolerance)

---

## 🧪 **TESTING GUIDE**

### **Test 1: Simulate On-Time Run**

```bash
# Set start time to 1:02 AM today
cat > /var/log/etl/daily_sla_summary_status.json << EOF
{
  "status": "success",
  "start_time": "$(date -d '1:02 AM today' -Iseconds)",
  "end_time": "$(date -d '1:05 AM today' -Iseconds)",
  "expected_schedule": "0 1 * * *"
}
EOF

# Test health endpoint
curl http://localhost:5001/health | jq
```

**Expected:** HTTP 200, status "healthy"

---

### **Test 2: Simulate Late Run**

```bash
# Set start time to 1:45 AM today (45 min late)
cat > /var/log/etl/daily_sla_summary_status.json << EOF
{
  "status": "success",
  "start_time": "$(date -d '1:45 AM today' -Iseconds)",
  "end_time": "$(date -d '1:48 AM today' -Iseconds)",
  "expected_schedule": "0 1 * * *"
}
EOF

# Test health endpoint
curl http://localhost:5001/health | jq
```

**Expected:** HTTP 503, status "unhealthy", message about being late

---

### **Test 3: Simulate Missed Run**

```bash
# Set start time to yesterday
cat > /var/log/etl/daily_sla_summary_status.json << EOF
{
  "status": "success",
  "start_time": "$(date -d 'yesterday 1:02 AM' -Iseconds)",
  "end_time": "$(date -d 'yesterday 1:05 AM' -Iseconds)",
  "expected_schedule": "0 1 * * *"
}
EOF

# Test health endpoint
curl http://localhost:5001/health | jq
```

**Expected:** HTTP 503, status "unhealthy", message about not running in 25 hours

---

### **Test 4: Check Schedule Status Endpoint**

```bash
curl http://localhost:5001/schedule-status | jq
```

**Expected Response:**
```json
{
  "job_name": "daily_sla_summary",
  "expected_schedule": "0 1 * * *",
  "last_run": "2025-11-27T01:02:15",
  "adherence": {
    "on_schedule": true,
    "minutes_late": 2,
    "expected_time": "2025-11-27T01:00:00",
    "actual_time": "2025-11-27T01:02:15",
    "message": "Job ran on schedule"
  }
}
```

---

## 📊 **DASHBOARD VIEW**

**After implementing, you'll see:**

```
Dashboard → Service Health

┌─────────────────────────────────────────────┐
│ Daily SLA Summary ETL                       │
│ ● Healthy                                   │
│ Last Run: 2025-11-27 01:02 AM              │
│ Schedule: 0 1 * * * (Daily at 1 AM)        │
│ Adherence: On schedule (2 min late)        │
│ SLA: ✓ Compliant (99.5%)                   │
└─────────────────────────────────────────────┘

If late:
┌─────────────────────────────────────────────┐
│ Daily SLA Summary ETL                       │
│ ● Unhealthy                                 │
│ Last Run: 2025-11-27 01:45 AM              │
│ Schedule: 0 1 * * * (Daily at 1 AM)        │
│ Adherence: ⚠️ 45 minutes late               │
│ SLA: ✗ BREACHED (93.3%)                    │
└─────────────────────────────────────────────┘
```

---

## ✅ **COMPLETE IMPLEMENTATION CHECKLIST**

**Linux Node:**
- [ ] Update ETL job to write start_time
- [ ] Update health_api.py with schedule validation
- [ ] Set tolerance_minutes (30 recommended)
- [ ] Restart health API
- [ ] Test with on-time status file
- [ ] Test with late status file

**Portal:**
- [ ] Add service with schedule field
- [ ] Create "Schedule Adherence" SLA
- [ ] Set target (99% recommended)
- [ ] Set measurement window (30 days)
- [ ] Verify health checks running
- [ ] Check dashboard shows schedule status

**Testing:**
- [ ] Simulate on-time run → Should be healthy
- [ ] Simulate late run → Should be unhealthy
- [ ] Simulate missed run → Should be unhealthy
- [ ] Verify SLA breach recorded
- [ ] Verify alerts generated

---

## 🎯 **SUMMARY**

**What You Asked:**
> "How to validate job starts on time from SLA portal?"

**Answer:**
1. ✅ ETL job writes `start_time` to status file
2. ✅ Health API compares to expected schedule
3. ✅ Returns unhealthy if outside tolerance
4. ✅ Portal records as SLA breach
5. ✅ Create "Schedule Adherence" SLA

**Key Points:**
- Schedule field now has meaning (not just documentation)
- Portal validates timing, not just success
- Configurable tolerance (±30 min recommended)
- SLA tracks schedule compliance
- Alerts triggered on missed schedule

**Result:**
✅ Job must start at 1:00 AM ±30 minutes  
✅ SLA breach if starts at 1:45 AM  
✅ Dashboard shows schedule adherence  
✅ Alerts sent when off-schedule  
✅ Full tracking and reporting  

---

**Now your SLA portal truly validates schedule adherence!** ⏰✅
