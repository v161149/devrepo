/**
 * AssetDetail Page Component
 * View, create, update, delete asset
 * Manage associated services
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { FiServer, FiSave, FiTrash2, FiArrowLeft, FiPlus, FiEdit2 } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import AddServiceModal from '../components/AddServiceModal';
import apiService from '../services/api';
import SERVICE_TYPES from '../constants/serviceTypes';

const AssetDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';

  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [editMode, setEditMode] = useState(isNew);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    asset_name: '',
    asset_type: 'Server',
    asset_owner: '',
    description: '',
    onboarded_date: new Date().toISOString().split('T')[0],
    status: 'active'
  });

  const [services, setServices] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);

  // Helper function to get service type display name
  const getServiceTypeName = (service) => {
    const serviceTypeId = service.metadata?.service_type;
    if (!serviceTypeId) return 'N/A';
    
    // Find the service type in SERVICE_TYPES
    for (const category of SERVICE_TYPES) {
      const type = category.types.find(t => t.id === serviceTypeId);
      if (type) return type.name;
    }
    
    // If not found, return the ID with capitalization
    return serviceTypeId.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  useEffect(() => {
    if (!isNew) {
      fetchAssetDetails();
    }
  }, [id, isNew]);

  const fetchAssetDetails = async () => {
    try {
      setLoading(true);
      const response = await apiService.assets.get(id);
      const asset = response.data;

      setFormData({
        asset_name: asset.asset_name || '',
        asset_type: asset.asset_type || 'Server',
        asset_owner: asset.asset_owner || '',
        description: asset.description || '',
        onboarded_date: asset.onboarded_date ? asset.onboarded_date.split('T')[0] : '',
        status: asset.status || 'active'
      });

      // Set services from asset data (these are asset-specific services)
      // Parse metadata if it's a string (SQLite returns JSON columns as strings)
      const servicesWithParsedMetadata = (asset.services || []).map(service => ({
        ...service,
        metadata: typeof service.metadata === 'string' 
          ? JSON.parse(service.metadata) 
          : service.metadata
      }));
      setServices(servicesWithParsedMetadata);
    } catch (error) {
      console.error('Error fetching asset:', error);
      setError('Failed to load asset details');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!formData.asset_name.trim()) {
      setError('Asset name is required');
      return;
    }

    if (!formData.asset_type) {
      setError('Asset type is required');
      return;
    }

    try {
      setSaving(true);

      if (isNew) {
        // Create new asset
        const response = await apiService.assets.create(formData);
        navigate('/assets');
      } else {
        // Update existing asset
        await apiService.assets.update(id, formData);
        setEditMode(false);
        fetchAssetDetails();
      }
    } catch (error) {
      console.error('Error saving asset:', error);
      setError(error.response?.data?.error || 'Failed to save asset');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this asset? This action cannot be undone.')) {
      return;
    }

    try {
      setDeleting(true);
      await apiService.assets.delete(id);
      navigate('/assets');
    } catch (error) {
      console.error('Error deleting asset:', error);
      setError(error.response?.data?.error || 'Failed to delete asset');
      setDeleting(false);
    }
  };

  const handleServiceAdded = () => {
    // Reload asset details to get updated services list
    fetchAssetDetails();
    setShowAddModal(false);
  };

  const assetTypes = [
    'Server',
    'Database',
    'Application',
    'Network',
    'Storage',
    'Container',
    'VM',
    'Cloud Service',
    'Other'
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600">Loading asset...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/assets">
            <Button variant="outline" icon={<FiArrowLeft />}>
              Back to Assets
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {isNew ? 'Add New Asset' : editMode ? 'Edit Asset' : formData.asset_name}
            </h1>
            {!isNew && !editMode && (
              <p className="text-gray-600 mt-1">
                Asset ID: {id}
              </p>
            )}
          </div>
        </div>

        {!isNew && !editMode && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              icon={<FiEdit2 />}
              onClick={() => setEditMode(true)}
            >
              Edit
            </Button>
            <Button
              variant="danger"
              icon={<FiTrash2 />}
              onClick={handleDelete}
              loading={deleting}
            >
              Delete
            </Button>
          </div>
        )}
      </div>

      {/* Error Message */}
      {error && (
        <Card className="bg-red-50 border-red-200">
          <div className="text-red-700">{error}</div>
        </Card>
      )}

      {/* Asset Form */}
      <Card>
        <h2 className="text-xl font-semibold mb-4">Asset Information</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Asset Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asset Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.asset_name}
                onChange={(e) => setFormData({ ...formData, asset_name: e.target.value })}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
                placeholder="e.g., Production Database Server"
              />
            </div>

            {/* Asset Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asset Type <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.asset_type}
                onChange={(e) => setFormData({ ...formData, asset_type: e.target.value })}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
              >
                {assetTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Asset Owner */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asset Owner
              </label>
              <input
                type="text"
                value={formData.asset_owner}
                onChange={(e) => setFormData({ ...formData, asset_owner: e.target.value })}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
                placeholder="e.g., IT Operations Team"
              />
            </div>

            {/* Onboarded Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Onboarded Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={formData.onboarded_date}
                onChange={(e) => setFormData({ ...formData, onboarded_date: e.target.value })}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
              />
            </div>

            {/* Status */}
            {!isNew && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  disabled={!editMode}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="decommissioned">Decommissioned</option>
                </select>
              </div>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              disabled={!editMode && !isNew}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
              placeholder="Describe this asset..."
            />
          </div>

          {/* Action Buttons */}
          {(editMode || isNew) && (
            <div className="flex gap-2 pt-4 border-t">
              <Button
                type="submit"
                icon={<FiSave />}
                loading={saving}
              >
                {isNew ? 'Create Asset' : 'Save Changes'}
              </Button>
              {!isNew && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setEditMode(false);
                    fetchAssetDetails();
                  }}
                >
                  Cancel
                </Button>
              )}
            </div>
          )}
        </form>
      </Card>

      {/* Associated Services */}
      {!isNew && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Associated Services</h2>
            <Button 
              icon={<FiPlus />} 
              size="sm"
              onClick={() => setShowAddModal(true)}
            >
              Add Service
            </Button>
          </div>

          {services.length === 0 ? (
            <div className="text-center py-8 text-gray-600">
              <p>No services associated with this asset yet.</p>
              <Button 
                icon={<FiPlus />} 
                className="mt-4"
                onClick={() => setShowAddModal(true)}
              >
                Add First Service
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Service
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Owner Team
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {services.map((service) => (
                    <tr 
                      key={service.service_id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigate(`/services/${service.service_id}`)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {service.name || service.service_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {getServiceTypeName(service)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          service.health_status === 'healthy'
                            ? 'bg-green-100 text-green-800'
                            : service.health_status === 'unhealthy'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {service.health_status === 'healthy' && '● Healthy'}
                          {service.health_status === 'unhealthy' && '● Unhealthy'}
                          {(!service.health_status || service.health_status === 'unknown') && '● Unknown'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {service.owner_team || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-primary-600">
                        View Details →
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {/* Add Service Modal */}
      <AddServiceModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={handleServiceAdded}
        assetId={id}
      />
    </div>
  );
};

export default AssetDetail;
