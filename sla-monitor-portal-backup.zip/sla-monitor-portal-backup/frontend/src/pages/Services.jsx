/**
 * Services Page
 * Manage and monitor services in table view
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiPlus, FiSearch, FiServer, FiFilter } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import AddServiceModal from '../components/AddServiceModal';
import apiService from '../services/api';
import SERVICE_TYPES from '../constants/serviceTypes';

const Services = () => {
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterAsset, setFilterAsset] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [filterDeployment, setFilterDeployment] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    loadServices();
    loadAssets();
  }, []);

  const loadServices = async () => {
    try {
      setLoading(true);
      const response = await apiService.services.getAll();
      console.log('Services response:', response.data);
      
      // Parse metadata if it's a string
      const servicesWithParsedMetadata = (response.data.data || []).map(service => ({
        ...service,
        metadata: typeof service.metadata === 'string' 
          ? JSON.parse(service.metadata) 
          : service.metadata
      }));
      
      setServices(servicesWithParsedMetadata);
    } catch (err) {
      console.error('Error loading services:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadAssets = async () => {
    try {
      const response = await apiService.assets.list();
      setAssets(response.data?.data || []);
    } catch (err) {
      console.error('Error loading assets:', err);
    }
  };

  // Helper function to get asset name by ID
  const getAssetName = (assetId) => {
    if (!assetId) return null;
    const asset = assets.find(a => a.asset_id === assetId);
    return asset ? asset.asset_name : assetId;
  };

  // Get unique deployment locations for filter
  const uniqueDeploymentLocations = [...new Set(services.map(s => s.deployment_location).filter(Boolean))];

  const filteredServices = services.filter(service => {
    // Search filter
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Status filter (Enabled/Disabled based on is_active)
    const matchesStatus = filterStatus === 'all' || 
      (filterStatus === 'enabled' && service.is_active !== false) ||
      (filterStatus === 'disabled' && service.is_active === false);
    
    // Asset filter
    const matchesAsset = filterAsset === 'all' || service.asset_id === filterAsset;
    
    // Type filter (based on service_type in metadata)
    const serviceTypeId = service.metadata?.service_type;
    const matchesType = filterType === 'all' || serviceTypeId === filterType;
    
    // Deployment location filter
    const matchesDeployment = filterDeployment === 'all' || service.deployment_location === filterDeployment;
    
    return matchesSearch && matchesStatus && matchesAsset && matchesType && matchesDeployment;
  });

  const handleServiceClick = (serviceId) => {
    navigate(`/services/${serviceId}`);
  };

  // Helper function to get service type display name
  const getServiceTypeName = (service) => {
    const serviceTypeId = service.metadata?.service_type;
    if (!serviceTypeId) return 'N/A';
    
    // Find the service type in SERVICE_TYPES
    for (const category of SERVICE_TYPES) {
      const type = category.types.find(t => t.id === serviceTypeId);
      if (type) return type.name;
    }
    
    // If not found, return the ID with capitalization
    return serviceTypeId.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Services</h1>
          <p className="text-gray-600 mt-1">Manage and monitor all your services</p>
        </div>
        <Button 
          icon={<FiPlus />}
          onClick={() => setShowAddModal(true)}
        >
          Add Service
        </Button>
      </div>

      {/* Search and Filters */}
      <Card className="mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search services..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              />
            </div>
          </div>

          {/* Filters */}
          <div className="flex gap-2">
            <div className="flex items-center gap-2">
              <FiFilter className="text-gray-400" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              >
                <option value="all">All Status</option>
                <option value="enabled">Enabled</option>
                <option value="disabled">Disabled</option>
              </select>
            </div>

            {/* Asset Filter */}
            <select
              value={filterAsset}
              onChange={(e) => setFilterAsset(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="all">All Assets</option>
              {assets.map(asset => (
                <option key={asset.asset_id} value={asset.asset_id}>
                  {asset.asset_name}
                </option>
              ))}
            </select>

            {/* Deployment Location Filter */}
            <select
              value={filterDeployment}
              onChange={(e) => setFilterDeployment(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="all">All Deployments</option>
              {uniqueDeploymentLocations.map(location => (
                <option key={location} value={location}>
                  {location === 'autosys' ? 'Autosys' : 
                   location === 'airflow' ? 'Airflow' : 
                   location === 'ansible_tower' ? 'Ansible Tower' : location}
                </option>
              ))}
            </select>

            {/* Type Filter */}
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="all">All Types</option>
              <option value="etl_batch">ETL Batch Job</option>
              <option value="api_gateway">API Gateway</option>
              <option value="microservice">Microservice</option>
              <option value="mysql">MySQL Database</option>
              <option value="postgresql">PostgreSQL Database</option>
              <option value="mongodb">MongoDB Database</option>
              <option value="oracle">Oracle Database</option>
              <option value="mssql">Microsoft SQL Server</option>
              <option value="kafka">Kafka</option>
              <option value="ibm_mq">IBM MQ</option>
              <option value="rabbitmq">RabbitMQ</option>
              <option value="spark_streaming">Spark Streaming</option>
              <option value="flink">Apache Flink</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Services Table */}
      <Card>
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
          </div>
        ) : filteredServices.length === 0 ? (
          <div className="text-center py-12">
            <FiServer className="mx-auto text-6xl text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No services found</h3>
            <p className="text-gray-500 mb-6">Get started by creating your first service</p>
            <Button 
              icon={<FiPlus />}
              onClick={() => setShowAddModal(true)}
            >
              Add Service
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Health
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Owner Team
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Asset
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Deployment Location
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredServices.map((service) => (
                  <tr 
                    key={service.service_id}
                    className="hover:bg-gray-50 cursor-pointer"
                    onClick={() => handleServiceClick(service.service_id)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center bg-primary-100 rounded-lg">
                          <FiServer className="text-primary-600" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {service.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {service.service_id}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {getServiceTypeName(service)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        service.is_active !== false 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {service.is_active !== false ? 'Enabled' : 'Disabled'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        service.health_status === 'healthy'
                          ? 'bg-green-100 text-green-800'
                          : service.health_status === 'unhealthy'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {service.health_status === 'healthy' && '● Healthy'}
                        {service.health_status === 'unhealthy' && '● Unhealthy'}
                        {(!service.health_status || service.health_status === 'unknown') && '● Unknown'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {service.owner_team || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {service.asset_id ? (
                        <span 
                          className="text-primary-600 hover:text-primary-800 cursor-pointer underline"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/assets/${service.asset_id}`);
                          }}
                        >
                          {getAssetName(service.asset_id) || 'View Asset →'}
                        </span>
                      ) : (
                        '-'
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {service.deployment_location === 'autosys' 
                        ? 'Autosys' 
                        : service.deployment_location === 'airflow' 
                        ? 'Airflow' 
                        : service.deployment_location === 'ansible_tower' 
                        ? 'Ansible Tower' 
                        : service.deployment_location || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-primary-600">
                      View Details →
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Add Service Modal */}
      <AddServiceModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={loadServices}
      />
    </div>
  );
};

export default Services;
