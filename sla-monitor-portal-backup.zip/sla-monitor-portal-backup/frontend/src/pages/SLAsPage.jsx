/**
 * SLAs Overview Page
 * Shows all SLAs across all services with filtering, View/Edit modals, Deactivate and Delete
 */

import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { FiFilter, FiPlus, FiEye, FiEdit, FiTrash2, FiServer, FiX } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import CreateSLAModal from '../components/CreateSLAModal';
import apiService from '../services/api';

const SLAsPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const filterParam = searchParams.get('filter');
  
  const [slas, setSlas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState(filterParam || 'all');
  const [error, setError] = useState(null);
  
  // Modal states
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedSLA, setSelectedSLA] = useState(null);

  useEffect(() => {
    loadAllSLAs();
  }, []);

  const loadAllSLAs = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get all SLAs directly from the API
      const response = await apiService.slas.getAll();
      const allSLAs = response.data?.data || response.data || [];
      
      console.log('Loaded SLAs:', allSLAs);
      setSlas(allSLAs);
      
    } catch (err) {
      console.error('Error loading SLAs:', err);
      setError(err.response?.data?.error || err.message || 'Failed to load SLAs');
    } finally {
      setLoading(false);
    }
  };

  const handleView = (sla) => {
    setSelectedSLA(sla);
    setShowViewModal(true);
  };

  const handleEdit = (sla) => {
    setSelectedSLA(sla);
    setShowEditModal(true);
  };

  const handleDeactivate = async (slaId) => {
    if (!window.confirm('Are you sure you want to deactivate this SLA? It will no longer be monitored.')) return;

    try {
      await apiService.slas.delete(slaId);
      alert('SLA deactivated successfully');
      loadAllSLAs();
    } catch (err) {
      console.error('Error deactivating SLA:', err);
      alert('Failed to deactivate SLA: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDelete = async (slaId, slaName) => {
    const confirmed = window.confirm(
      `Are you sure you want to PERMANENTLY DELETE the SLA "${slaName}"?\n\n` +
      `This action CANNOT be undone and will remove all historical data.\n\n` +
      `Consider using "Deactivate" instead to preserve data.`
    );
    
    if (!confirmed) return;

    // Double confirmation for delete
    const doubleConfirm = window.confirm(
      `FINAL CONFIRMATION\n\n` +
      `Type YES in the next prompt to permanently delete "${slaName}"`
    );

    if (!doubleConfirm) return;

    try {
      // Call a hard delete endpoint (we'll need to create this)
      await apiService.slas.hardDelete(slaId);
      alert('SLA permanently deleted');
      loadAllSLAs();
    } catch (err) {
      console.error('Error deleting SLA:', err);
      alert('Failed to delete SLA: ' + (err.response?.data?.error || err.message));
    }
  };

  const getFilteredSLAs = () => {
    if (filter === 'all') return slas;
    if (filter === 'active') return slas.filter(sla => sla.is_active);
    if (filter === 'inactive') return slas.filter(sla => !sla.is_active);
    if (filter === 'breached') {
      return slas.filter(sla => {
        const compliance = sla.current_compliance || 0;
        const target = sla.target_value || 0;
        return compliance < target;
      });
    }
    if (filter === 'compliant') {
      return slas.filter(sla => {
        const compliance = sla.current_compliance || 0;
        const target = sla.target_value || 0;
        return compliance >= target;
      });
    }
    return slas;
  };

  const getStatusBadge = (sla) => {
    if (!sla.is_active) {
      return <span className="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-800">Inactive</span>;
    }

    const compliance = sla.current_compliance || 0;
    const target = sla.target_value || 0;

    if (compliance >= target) {
      return <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">✓ Compliant</span>;
    } else if (compliance >= target * 0.95) {
      return <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">⚠ At Risk</span>;
    } else {
      return <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800">✗ Breached</span>;
    }
  };

  const filteredSLAs = getFilteredSLAs();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading SLAs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">All SLAs</h1>
          <p className="text-gray-600 mt-1">
            Showing {filteredSLAs.length} of {slas.length} SLAs
          </p>
        </div>
        <Button onClick={() => navigate('/services')} icon={<FiPlus />}>
          Create SLA
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex items-center gap-2 flex-wrap">
          <FiFilter className="text-gray-400" />
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'all'
                ? 'bg-primary-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All ({slas.length})
          </button>
          <button
            onClick={() => setFilter('active')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'active'
                ? 'bg-primary-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Active ({slas.filter(s => s.is_active).length})
          </button>
          <button
            onClick={() => setFilter('breached')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'breached'
                ? 'bg-red-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Breached ({slas.filter(s => {
              const compliance = s.current_compliance || 0;
              const target = s.target_value || 0;
              return compliance < target;
            }).length})
          </button>
          <button
            onClick={() => setFilter('compliant')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'compliant'
                ? 'bg-green-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Compliant ({slas.filter(s => {
              const compliance = s.current_compliance || 0;
              const target = s.target_value || 0;
              return compliance >= target;
            }).length})
          </button>
          <button
            onClick={() => setFilter('inactive')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filter === 'inactive'
                ? 'bg-gray-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Inactive ({slas.filter(s => !s.is_active).length})
          </button>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      {/* SLAs List */}
      {filteredSLAs.length === 0 ? (
        <Card>
          <div className="text-center py-12">
            <FiFilter className="mx-auto text-gray-400 text-5xl mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {filter === 'all' ? 'No SLAs Found' : `No ${filter} SLAs`}
            </h3>
            <p className="text-gray-600 mb-4">
              {filter === 'all'
                ? 'Get started by creating your first SLA'
                : `There are no ${filter} SLAs at the moment`}
            </p>
            {filter === 'all' && (
              <Button onClick={() => navigate('/services')}>
                Go to Services
              </Button>
            )}
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredSLAs.map((sla) => (
            <Card key={sla.sla_id}>
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {sla.name}
                    </h3>
                    {getStatusBadge(sla)}
                    <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                      {sla.priority}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <FiServer className="text-gray-400" />
                      <span>{sla.service_name || 'Unknown Service'}</span>
                    </div>
                    <div>
                      <span className="font-medium">Target:</span> {sla.target_value} {sla.target_unit}
                    </div>
                    <div>
                      <span className="font-medium">Current:</span>{' '}
                      {sla.current_compliance !== null && sla.current_compliance !== undefined
                        ? sla.current_compliance.toFixed(2)
                        : 'N/A'}{' '}
                      {sla.target_unit}
                    </div>
                    <div className="capitalize">
                      <span className="font-medium">Type:</span> {sla.metric_type?.replace('_', ' ')}
                    </div>
                  </div>

                  {sla.description && (
                    <p className="text-sm text-gray-500 mt-2">{sla.description}</p>
                  )}
                </div>

                <div className="flex items-center gap-2 ml-4">
                  <Button
                    size="sm"
                    variant="ghost"
                    icon={<FiEye />}
                    onClick={() => handleView(sla)}
                  >
                    View
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    icon={<FiEdit />}
                    onClick={() => handleEdit(sla)}
                  >
                    Edit
                  </Button>
                  {sla.is_active && (
                    <Button
                      size="sm"
                      variant="ghost"
                      icon={<FiTrash2 />}
                      onClick={() => handleDeactivate(sla.sla_id)}
                      className="text-orange-600 hover:text-orange-700"
                    >
                      Deactivate
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    icon={<FiTrash2 />}
                    onClick={() => handleDelete(sla.sla_id, sla.name)}
                    className="text-red-600 hover:text-red-700"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* View Modal */}
      {showViewModal && selectedSLA && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">SLA Details</h2>
              <button
                onClick={() => setShowViewModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <FiX className="text-2xl" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6">
              {/* Basic Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Basic Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Name</label>
                    <p className="text-gray-900">{selectedSLA.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Status</label>
                    <p>{getStatusBadge(selectedSLA)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Priority</label>
                    <p className="text-gray-900">{selectedSLA.priority}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Metric Type</label>
                    <p className="text-gray-900 capitalize">{selectedSLA.metric_type?.replace('_', ' ')}</p>
                  </div>
                </div>
                {selectedSLA.description && (
                  <div className="mt-4">
                    <label className="text-sm font-medium text-gray-600">Description</label>
                    <p className="text-gray-900">{selectedSLA.description}</p>
                  </div>
                )}
              </div>

              {/* Performance Target */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Performance Target</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Target Value</label>
                    <p className="text-gray-900">{selectedSLA.target_value} {selectedSLA.target_unit}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Current Compliance</label>
                    <p className="text-gray-900">
                      {selectedSLA.current_compliance !== null && selectedSLA.current_compliance !== undefined
                        ? `${selectedSLA.current_compliance.toFixed(2)} ${selectedSLA.target_unit}`
                        : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Thresholds */}
              {selectedSLA.metadata?.thresholds && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Performance Thresholds</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <span className="font-medium text-red-900">Critical</span>
                      <span className="text-red-900">{selectedSLA.metadata.thresholds.critical}%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                      <span className="font-medium text-yellow-900">Warning</span>
                      <span className="text-yellow-900">{selectedSLA.metadata.thresholds.warning}%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <span className="font-medium text-green-900">Target</span>
                      <span className="text-green-900">{selectedSLA.metadata.thresholds.target}%</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Escalation */}
              {selectedSLA.metadata?.escalationSteps && selectedSLA.metadata.escalationSteps.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Escalation Procedure</h3>
                  <div className="space-y-3">
                    {selectedSLA.metadata.escalationSteps.map((step, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900">Level {step.level}</span>
                          <span className="text-sm text-gray-600">{step.timeframe} minutes</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p><span className="font-medium">Contact:</span> {step.contact}</p>
                          <p><span className="font-medium">Action:</span> {step.action}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Effective Period */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Effective Period</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">From</label>
                    <p className="text-gray-900">{selectedSLA.effective_from || 'Not set'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Until</label>
                    <p className="text-gray-900">{selectedSLA.effective_until || 'No end date'}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex justify-between">
              <Button
                variant="outline"
                onClick={() => {
                  setShowViewModal(false);
                  handleEdit(selectedSLA);
                }}
              >
                Edit SLA
              </Button>
              <Button onClick={() => setShowViewModal(false)}>
                Close
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedSLA && (
        <CreateSLAModal
          isOpen={showEditModal}
          serviceId={selectedSLA.service_id}
          serviceName={selectedSLA.service_name}
          onClose={() => {
            setShowEditModal(false);
            setSelectedSLA(null);
          }}
          onSuccess={() => {
            setShowEditModal(false);
            setSelectedSLA(null);
            loadAllSLAs();
          }}
          editMode={true}
          initialData={selectedSLA}
        />
      )}
    </div>
  );
};

export default SLAsPage;
