/**
 * ServiceDetails Page
 * View and edit service configuration
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiEdit2, FiSave, FiX, FiCheck, FiAlertCircle, FiTrash2 } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import SLAList from '../components/SLAList';
import apiService from '../services/api';

const ServiceDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [service, setService] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [error, setError] = useState('');

  const [editData, setEditData] = useState({
    name: '',
    description: '',
    owner_team: '',
    is_active: true,
    monitoring_method: 'direct',
    deployment_location: '',
    execution_time: '00:30:00',
    config: {}
  });

  useEffect(() => {
    loadService();
  }, [id]);

  const loadService = async () => {
    try {
      setLoading(true);
      const response = await apiService.services.getById(id);
      const serviceData = response.data;
      
      setService(serviceData);
      setEditData({
        name: serviceData.name || '',
        description: serviceData.description || '',
        owner_team: serviceData.owner_team || '',
        is_active: serviceData.is_active !== false,
        monitoring_method: serviceData.monitoring_method || serviceData.metadata?.monitoring_method || 'direct',
        deployment_location: serviceData.deployment_location || serviceData.metadata?.deployment_location || '',
        execution_time: serviceData.metadata?.execution_time || '00:30:00', // Read from metadata only
        config: serviceData.metadata?.config || {}
      });
    } catch (err) {
      console.error('Error loading service:', err);
      setError('Failed to load service details');
    } finally {
      setLoading(false);
    }
  };

  // Validation function for execution time
  const validateExecutionTime = (value) => {
    if (!value) return true; // Allow empty
    // Regex: HH:MM:SS or HH:MM:SS.SSS
    const regex = /^([0-9]{2}):([0-5][0-9]):([0-5][0-9])(\.[0-9]{1,3})?$/;
    return regex.test(value);
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');

    // Validate execution time if it's an ETL job
    const isETLJob = service.metadata?.service_type === 'etl_batch';
    if (isETLJob && !validateExecutionTime(editData.execution_time)) {
      setError('Invalid execution time format. Please use HH:MM:SS or HH:MM:SS.SSS format');
      setSaving(false);
      return;
    }

    try {
      await apiService.services.update(id, {
        name: editData.name,
        description: editData.description,
        owner_team: editData.owner_team,
        is_active: editData.is_active,
        monitoring_method: editData.monitoring_method,
        deployment_location: editData.deployment_location,
        metadata: JSON.stringify({
          ...service.metadata,
          monitoring_method: editData.monitoring_method,
          deployment_location: editData.deployment_location,
          execution_time: isETLJob ? editData.execution_time : null, // Store in metadata only
          config: editData.config
        })
      });

      await loadService();
      setEditing(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to update service');
    } finally {
      setSaving(false);
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);

    try {
      const result = await apiService.services.testConnection({
        service_id: id,
        type: service.metadata?.service_type,
        config: editData.config
      });
      
      setTestResult({ 
        success: result.data.success === true,  // Read from API response
        message: result.data.message || 'Connection test completed.' 
      });
    } catch (err) {
      setTestResult({ 
        success: false, 
        message: err.response?.data?.message || err.response?.data?.error || 'Connection failed.' 
      });
    } finally {
      setTesting(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this service? This action cannot be undone.')) {
      return;
    }

    try {
      await apiService.services.delete(id);
      navigate('/services');
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to delete service');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading service details...</p>
        </div>
      </div>
    );
  }

  if (!service) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <FiAlertCircle className="text-red-500 text-5xl mx-auto mb-4" />
          <p className="text-gray-600 mb-4">Service not found</p>
          <Button onClick={() => navigate('/services')}>Back to Services</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/services')}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <FiArrowLeft className="text-xl" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{service.name}</h1>
            <p className="text-gray-600 mt-1">{service.service_id}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {!editing ? (
            <>
              <Button
                variant="outline"
                icon={<FiEdit2 />}
                onClick={() => setEditing(true)}
              >
                Edit
              </Button>
              <Button
                variant="danger"
                icon={<FiTrash2 />}
                onClick={handleDelete}
              >
                Delete
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                icon={<FiX />}
                onClick={() => {
                  setEditing(false);
                  setError('');
                }}
              >
                Cancel
              </Button>
              <Button
                icon={<FiSave />}
                onClick={handleSave}
                loading={saving}
              >
                Save Changes
              </Button>
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-800">
          {error}
        </div>
      )}

      {/* Basic Information */}
      <Card title="Basic Information">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Service Name</label>
            {editing ? (
              <input
                type="text"
                value={editData.name}
                onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              />
            ) : (
              <p className="text-gray-900">{service.name}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Owner Team</label>
            {editing ? (
              <input
                type="text"
                value={editData.owner_team}
                onChange={(e) => setEditData({ ...editData, owner_team: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              />
            ) : (
              <p className="text-gray-900">{service.owner_team || 'Not assigned'}</p>
            )}
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            {editing ? (
              <textarea
                value={editData.description}
                onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                rows="3"
              />
            ) : (
              <p className="text-gray-900">{service.description || 'No description'}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Health Status</label>
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                service.health_status === 'healthy' 
                  ? 'bg-green-100 text-green-800' 
                  : service.health_status === 'unhealthy'
                  ? 'bg-red-100 text-red-800'
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {service.health_status === 'healthy' && '● Healthy'}
                {service.health_status === 'unhealthy' && '● Unhealthy'}
                {(!service.health_status || service.health_status === 'unknown') && '● Unknown'}
              </span>
              {service.health_message && (
                <span className="text-sm text-gray-600">
                  {service.health_message}
                </span>
              )}
            </div>
            {service.health_checked_at && (
              <p className="text-xs text-gray-500 mt-1">
                Last checked: {new Date(service.health_checked_at).toLocaleString()}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Enabled</label>
            {editing ? (
              <select
                value={editData.is_active ? 'active' : 'inactive'}
                onChange={(e) => setEditData({ ...editData, is_active: e.target.value === 'active' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              >
                <option value="active">Enabled</option>
                <option value="inactive">Disabled</option>
              </select>
            ) : (
              <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                service.is_active !== false ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
              }`}>
                {service.is_active !== false ? 'Enabled' : 'Disabled'}
              </span>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Service Type</label>
            <p className="text-gray-900">{service.metadata?.service_type || 'Unknown'}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Monitoring Method</label>
            {editing ? (
              <select
                value={editData.monitoring_method}
                onChange={(e) => setEditData({ ...editData, monitoring_method: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              >
                <option value="direct">Direct Monitoring</option>
                <option value="indirect">Indirect Monitoring</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {service.monitoring_method === 'direct' || !service.monitoring_method 
                  ? 'Direct Monitoring' 
                  : service.monitoring_method === 'indirect' 
                  ? 'Indirect Monitoring' 
                  : service.monitoring_method}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Deployment Location</label>
            {editing ? (
              <select
                value={editData.deployment_location}
                onChange={(e) => setEditData({ ...editData, deployment_location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              >
                <option value="">-- Select --</option>
                <option value="autosys">Autosys</option>
                <option value="airflow">Airflow</option>
                <option value="ansible_tower">Ansible Tower</option>
              </select>
            ) : (
              <p className="text-gray-900">
                {service.deployment_location === 'autosys' 
                  ? 'Autosys' 
                  : service.deployment_location === 'airflow' 
                  ? 'Airflow' 
                  : service.deployment_location === 'ansible_tower' 
                  ? 'Ansible Tower' 
                  : service.deployment_location || 'Not specified'}
              </p>
            )}
          </div>

          {/* Execution Time - Only for ETL Jobs */}
          {service.metadata?.service_type === 'etl_batch' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Execution Time</label>
              {editing ? (
                <>
                  <input
                    type="text"
                    value={editData.execution_time}
                    onChange={(e) => setEditData({ ...editData, execution_time: e.target.value })}
                    onBlur={(e) => {
                      if (!validateExecutionTime(e.target.value)) {
                        alert('Invalid execution time format. Please use HH:MM:SS or HH:MM:SS.SSS format');
                      }
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono"
                    placeholder="00:30:00"
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Format: HH:MM:SS or HH:MM:SS.SSS (e.g., 00:30:00 for 30 minutes)
                  </p>
                </>
              ) : (
                <p className="text-gray-900 font-mono">
                  {service.metadata?.execution_time || '00:30:00'}
                </p>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* Configuration */}
      <Card title="Configuration">
        <div className="space-y-4">
          {service.metadata?.config && Object.keys(service.metadata.config).length > 0 ? (
            Object.entries(service.metadata.config).map(([key, value]) => (
              <div key={key}>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {key.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </label>
                {editing ? (
                  key.includes('password') || key.includes('secret') || key.includes('key') ? (
                    <input
                      type="password"
                      value={editData.config[key] || ''}
                      onChange={(e) => setEditData({
                        ...editData,
                        config: { ...editData.config, [key]: e.target.value }
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    />
                  ) : (
                    <input
                      type="text"
                      value={editData.config[key] || ''}
                      onChange={(e) => setEditData({
                        ...editData,
                        config: { ...editData.config, [key]: e.target.value }
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    />
                  )
                ) : (
                  <p className="text-gray-900 font-mono text-sm">
                    {key.includes('password') || key.includes('secret') || key.includes('key')
                      ? '••••••••'
                      : value}
                  </p>
                )}
              </div>
            ))
          ) : (
            <p className="text-gray-500">No configuration available</p>
          )}

          {editing && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <Button
                variant="outline"
                onClick={handleTestConnection}
                loading={testing}
                fullWidth
              >
                {testing ? 'Testing Connection...' : 'Test Connection'}
              </Button>

              {testResult && (
                <div className={`mt-3 p-3 rounded-lg flex items-center ${
                  testResult.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
                }`}>
                  {testResult.success ? <FiCheck className="mr-2" /> : <FiAlertCircle className="mr-2" />}
                  <span className="text-sm">{testResult.message}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* SLAs */}
      <Card>
        <SLAList 
          serviceId={service.service_id} 
          serviceName={service.name}
        />
      </Card>
    </div>
  );
};

export default ServiceDetails;
