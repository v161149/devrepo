/**
 * AddServiceModal Component
 * Modal for adding new services with type selection and configuration
 * Now includes Asset selection as required field
 */

import React, { useState, useEffect } from 'react';
import { FiX, FiCheck, FiAlertCircle } from 'react-icons/fi';
import Button from './Button';
import apiService from '../services/api';
import SERVICE_TYPES from '../constants/serviceTypes';

const AddServiceModal = ({ isOpen, onClose, onSuccess, assetId }) => {
  const [step, setStep] = useState(1); // 1: Basic Info, 2: Type Selection, 3: Configuration
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [error, setError] = useState('');
  const [assets, setAssets] = useState([]);
  const [loadingAssets, setLoadingAssets] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    owner_team: '',
    asset_id: assetId || '', // Pre-fill if provided
    service_type: '',
    service_category: '',
    monitoring_method: '', // Monitoring method field
    deployment_location: '', // Deployment location field
    execution_time: '00:30:00', // Default 30 minutes for ETL jobs
    tags: [],
    config: {}
  });

  const selectedServiceType = SERVICE_TYPES
    .flatMap(cat => cat.types)
    .find(type => type.id === formData.service_type);

  // Load assets when modal opens
  useEffect(() => {
    if (isOpen && !assetId) { // Only load if no assetId provided
      loadAssets();
    }
  }, [isOpen, assetId]);

  const loadAssets = async () => {
    try {
      setLoadingAssets(true);
      const response = await apiService.assets.list();
      const assetsList = response.data?.data || [];
      setAssets(assetsList);
      
      if (assetsList.length === 0) {
        setError('No assets found. Please create an asset first.');
      }
    } catch (err) {
      console.error('Error loading assets:', err);
      setError('Failed to load assets');
    } finally {
      setLoadingAssets(false);
    }
  };

  if (!isOpen) return null;

  // Validation function for execution time
  const validateExecutionTime = (value) => {
    if (!value) return true; // Allow empty for non-ETL services
    // Regex: HH:MM:SS or HH:MM:SS.SSS
    const regex = /^([0-9]{2}):([0-5][0-9]):([0-5][0-9])(\.[0-9]{1,3})?$/;
    return regex.test(value);
  };

  const handleClose = () => {
    // Reset form state
    setFormData({
      name: '',
      description: '',
      owner_team: '',
      asset_id: assetId || '',
      service_type: '',
      service_category: '',
      monitoring_method: '',
      deployment_location: '',
      execution_time: '00:30:00', // Reset to default
      config: {}
    });
    setStep(1);
    setError('');
    setTestResult(null);
    setAssets([]);
    onClose();
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleConfigChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      config: { ...prev.config, [field]: value }
    }));
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    setError('');

    try {
      // Call actual test endpoint
      const result = await apiService.services.testConnection({
        type: formData.service_type,
        config: formData.config
      });
      
      setTestResult({ 
        success: result.data.success === true,
        message: result.data.message || 'Connection test completed.' 
      });
    } catch (err) {
      setTestResult({ 
        success: false, 
        message: err.response?.data?.message || 'Connection failed. Please check your configuration.' 
      });
    } finally {
      setTesting(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (step < 3) {
      // Validate execution_time before moving to step 3
      if (step === 2 && formData.service_type === 'etl_batch') {
        if (!validateExecutionTime(formData.execution_time)) {
          setError('Invalid execution time format. Please use HH:MM:SS or HH:MM:SS.SSS format');
          return;
        }
      }
      setStep(step + 1);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const serviceData = {
        name: formData.name,
        description: formData.description,
        owner_team: formData.owner_team,
        asset_id: formData.asset_id, // Include asset_id
        monitoring_method: formData.monitoring_method, // Include monitoring_method
        deployment_location: formData.deployment_location, // Include deployment_location
        tags: [formData.service_category, formData.service_type],
        metadata: {
          service_type: formData.service_type,
          service_category: formData.service_category,
          monitoring_method: formData.monitoring_method,
          deployment_location: formData.deployment_location,
          execution_time: formData.service_type === 'etl_batch' ? formData.execution_time : null, // Store in metadata
          config: formData.config
        }
      };

      await apiService.services.create(serviceData);
      
      // Reset form
      setFormData({
        name: '',
        description: '',
        owner_team: '',
        asset_id: assetId || '',
        service_type: '',
        service_category: '',
        monitoring_method: '',
        deployment_location: '',
        execution_time: '00:30:00',
        config: {}
      });
      setStep(1);
      setTestResult(null);
      
      // Call success callback and close modal
      onSuccess();
      onClose();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create service');
    } finally {
      setLoading(false);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Service Name *</label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          placeholder="e.g., Production API Gateway"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
        <textarea
          value={formData.description}
          onChange={(e) => handleInputChange('description', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          rows="3"
          placeholder="Brief description of the service"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Owner Team</label>
        <input
          type="text"
          value={formData.owner_team}
          onChange={(e) => handleInputChange('owner_team', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          placeholder="e.g., Platform Team"
        />
      </div>

      {/* Asset Selection - Only show if not pre-filled */}
      {!assetId && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Asset Name *</label>
          {loadingAssets ? (
            <div className="flex items-center justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary-600"></div>
              <span className="ml-2 text-sm text-gray-600">Loading assets...</span>
            </div>
          ) : assets.length === 0 ? (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                No assets available. Please create an asset first before adding services.
              </p>
            </div>
          ) : (
            <select
              value={formData.asset_id}
              onChange={(e) => handleInputChange('asset_id', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              required
            >
              <option value="">-- Select an Asset --</option>
              {assets.map((asset) => (
                <option key={asset.asset_id} value={asset.asset_id}>
                  {asset.asset_name} ({asset.asset_type})
                </option>
              ))}
            </select>
          )}
          <p className="mt-1 text-xs text-gray-500">
            Each service must be linked to an asset
          </p>
        </div>
      )}

      {/* Show selected asset if pre-filled */}
      {assetId && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Asset:</strong> This service will be linked to the current asset
          </p>
        </div>
      )}
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <p className="text-sm text-gray-600 mb-4">Select the type of service you want to monitor:</p>
      
      {SERVICE_TYPES.map((category) => (
        <div key={category.category} className="mb-6">
          <h3 className="font-semibold text-gray-800 mb-3">{category.category}</h3>
          <div className="grid grid-cols-2 gap-3">
            {category.types.map((type) => (
              <button
                key={type.id}
                type="button"
                onClick={() => {
                  handleInputChange('service_type', type.id);
                  handleInputChange('service_category', category.category);
                }}
                className={`p-3 text-left border-2 rounded-lg transition ${
                  formData.service_type === type.id
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-200 hover:border-primary-300'
                }`}
              >
                <div className="font-medium text-sm">{type.name}</div>
              </button>
            ))}
          </div>
        </div>
      ))}

      {/* Monitoring Method Dropdown */}
      <div className="mt-6 pt-6 border-t border-gray-200">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Monitoring Method *
        </label>
        <select
          value={formData.monitoring_method}
          onChange={(e) => handleInputChange('monitoring_method', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          required
        >
          <option value="">-- Select Monitoring Method --</option>
          <option value="direct">Direct Monitoring</option>
          <option value="indirect">Indirect Monitoring</option>
        </select>
        <p className="mt-2 text-xs text-gray-500">
          <strong>Direct:</strong> Service can be monitored directly (e.g., API health check, database query)
          <br />
          <strong>Indirect:</strong> Service cannot be monitored directly (e.g., mainframe systems, legacy applications)
        </p>
      </div>

      {/* Deployment Location Dropdown */}
      <div className="mt-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Deployment Location *
        </label>
        <select
          value={formData.deployment_location}
          onChange={(e) => handleInputChange('deployment_location', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          required
        >
          <option value="">-- Select Deployment Location --</option>
          <option value="autosys">Autosys</option>
          <option value="airflow">Airflow</option>
          <option value="ansible_tower">Ansible Tower</option>
        </select>
        <p className="mt-2 text-xs text-gray-500">
          Select where this service will be deployed and orchestrated
        </p>
      </div>

      {/* Execution Time Field - Only for ETL Job */}
      {formData.service_type === 'etl_batch' && (
        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Execution Time *
          </label>
          <input
            type="text"
            value={formData.execution_time}
            onChange={(e) => {
              const value = e.target.value;
              // Allow typing, validate on blur
              handleInputChange('execution_time', value);
            }}
            onBlur={(e) => {
              const value = e.target.value;
              if (!validateExecutionTime(value)) {
                alert('Invalid execution time format. Please use HH:MM:SS or HH:MM:SS.SSS format (e.g., 00:30:00 for 30 minutes)');
              }
            }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono"
            placeholder="00:30:00"
            pattern="^([0-9]{2}):([0-5][0-9]):([0-5][0-9])(\.[0-9]{1,3})?$"
            required
          />
          <p className="mt-2 text-xs text-gray-500">
            <strong>Format:</strong> HH:MM:SS or HH:MM:SS.SSS
            <br />
            <strong>Examples:</strong> 00:03:15 (3 min 15 sec), 01:30:00 (1 hr 30 min), 00:00:00.500 (500 ms)
          </p>
        </div>
      )}
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
        <p className="text-sm text-blue-800">
          <strong>Service Type:</strong> {selectedServiceType?.name}
        </p>
      </div>

      {selectedServiceType?.fields.map((field) => (
        <div key={field}>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {field.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} *
          </label>
          {field.includes('password') || field.includes('secret') || field.includes('key') ? (
            <input
              type="password"
              value={formData.config[field] || ''}
              onChange={(e) => handleConfigChange(field, e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder={`Enter ${field}`}
              required
            />
          ) : field.includes('json') ? (
            <textarea
              value={formData.config[field] || ''}
              onChange={(e) => handleConfigChange(field, e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
              rows="4"
              placeholder='{"key": "value"}'
              required
            />
          ) : (
            <>
              <input
                type="text"
                value={formData.config[field] || ''}
                onChange={(e) => handleConfigChange(field, e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder={
                  field === 'url' ? 'e.g., http://localhost:3000' :
                  field.includes('endpoint') ? 'e.g., /health or /api/v1/health' :
                  `Enter ${field}`
                }
                required
              />
              {field.includes('endpoint') && (
                <p className="mt-1 text-xs text-gray-500">
                  ⚠️ Enter only the path (e.g., /health), not a full URL
                </p>
              )}
            </>
          )}
        </div>
      ))}

      <div className="mt-6">
        <Button
          type="button"
          variant="outline"
          onClick={handleTestConnection}
          loading={testing}
          fullWidth
        >
          {testing ? 'Testing Connection...' : 'Test Connection'}
        </Button>

        {testResult && (
          <div className={`mt-3 p-3 rounded-lg flex items-center ${
            testResult.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}>
            {testResult.success ? <FiCheck className="mr-2" /> : <FiAlertCircle className="mr-2" />}
            <span className="text-sm">{testResult.message}</span>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Add New Service</h2>
            <p className="text-sm text-gray-600 mt-1">Step {step} of 3</p>
          </div>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <FiX className="text-xl" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="px-6 pt-4">
          <div className="flex items-center">
            {[1, 2, 3].map((s) => (
              <React.Fragment key={s}>
                <div className={`flex-1 h-2 rounded-full ${s <= step ? 'bg-primary-500' : 'bg-gray-200'}`} />
                {s < 3 && <div className="w-4" />}
              </React.Fragment>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-xs text-gray-600">
            <span>Basic Info</span>
            <span>Service Type</span>
            <span>Configuration</span>
          </div>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6">
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}

          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
              {error}
            </div>
          )}
        </form>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
          <Button
            type="button"
            variant="outline"
            onClick={() => step === 1 ? handleClose() : setStep(step - 1)}
          >
            {step === 1 ? 'Cancel' : 'Back'}
          </Button>

          <Button
            type="button"
            onClick={handleSubmit}
            loading={loading}
            disabled={
              (step === 1 && (!formData.name || (!assetId && !formData.asset_id) || (!assetId && assets.length === 0))) ||
              (step === 2 && (!formData.service_type || !formData.monitoring_method || !formData.deployment_location)) ||
              (step === 3 && loading)
            }
          >
            {step === 3 ? (loading ? 'Creating...' : 'Create Service') : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddServiceModal;
