/**
 * MetricCard Component
 * Displays a metric with icon, value, and trend
 */

import React from 'react';
import { FiTrendingUp, FiTrendingDown } from 'react-icons/fi';

const MetricCard = ({
  title,
  value,
  icon: Icon,
  color = 'blue',
  trend,
  trendLabel,
  subtitle,
  loading = false,
  onClick,  // Add onClick prop
}) => {
  const colorClasses = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    red: 'bg-red-500',
    yellow: 'bg-yellow-500',
    purple: 'bg-purple-500',
    indigo: 'bg-indigo-500',
  };

  const trendColor = trend > 0 ? 'text-green-600' : trend < 0 ? 'text-red-600' : 'text-gray-600';
  const TrendIcon = trend > 0 ? FiTrendingUp : FiTrendingDown;

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6 animate-pulse">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
            <div className="h-8 bg-gray-200 rounded w-32"></div>
          </div>
          <div className={`${colorClasses[color]} p-4 rounded-full h-16 w-16`}></div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`bg-white rounded-xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${onClick ? 'cursor-pointer' : ''}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-gray-500 text-sm font-medium uppercase tracking-wide">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
          
          {(trend !== undefined || subtitle) && (
            <div className="mt-2 flex items-center">
              {trend !== undefined && (
                <div className={`flex items-center ${trendColor} text-sm font-medium`}>
                  <TrendIcon className="mr-1" />
                  <span>{Math.abs(trend)}%</span>
                  {trendLabel && <span className="ml-1 text-gray-500">{trendLabel}</span>}
                </div>
              )}
              {subtitle && !trend && (
                <p className="text-sm text-gray-600">{subtitle}</p>
              )}
            </div>
          )}
        </div>
        
        {Icon && (
          <div className={`${colorClasses[color]} p-4 rounded-full`}>
            <Icon className="text-white text-2xl" />
          </div>
        )}
      </div>
    </div>
  );
};

export default MetricCard;
