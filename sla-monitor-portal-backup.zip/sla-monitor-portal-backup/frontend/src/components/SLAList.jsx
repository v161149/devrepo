/**
 * SLAList Component
 * Displays all SLAs associated with a service
 */

import React, { useState, useEffect } from 'react';
import { FiPlus, FiCheck, FiAlertTriangle, FiEdit, FiTrash2, FiEye, FiX } from 'react-icons/fi';
import Button from './Button';
import Card from './Card';
import CreateSLAModal from './CreateSLAModal';
import apiService from '../services/api';

const SLAList = ({ serviceId, serviceName }) => {
  const [slas, setSlas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedSLA, setSelectedSLA] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadSLAs();
  }, [serviceId]);

  const loadSLAs = async () => {
    try {
      setLoading(true);
      const response = await apiService.slas.getByService(serviceId);
      // API returns { data: { data: [...], count: ... } }
      // We need response.data.data
      setSlas(response.data?.data || []);
    } catch (err) {
      console.error('Error loading SLAs:', err);
      setError('Failed to load SLAs');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleActivation = async (sla) => {
    const newStatus = !sla.is_active;
    const action = newStatus ? 'activate' : 'deactivate';
    
    if (!window.confirm(`Are you sure you want to ${action} this SLA?`)) {
      return;
    }

    try {
      await apiService.slas.update(sla.sla_id, {
        is_active: newStatus
      });
      loadSLAs();
    } catch (err) {
      console.error(`Error ${action}ing SLA:`, err);
      alert(`Failed to ${action} SLA`);
    }
  };

  const handleDelete = async (slaId, slaName) => {
    const confirmed = window.confirm(
      `Are you sure you want to PERMANENTLY DELETE the SLA "${slaName}"?\n\n` +
      `This action CANNOT be undone and will remove all historical data.\n\n` +
      `Consider using "Deactivate" instead to preserve data.`
    );
    
    if (!confirmed) return;

    // Double confirmation for delete
    const doubleConfirm = window.confirm(
      `FINAL CONFIRMATION\n\n` +
      `This will permanently delete "${slaName}". Click OK to confirm.`
    );

    if (!doubleConfirm) return;

    try {
      await apiService.slas.hardDelete(slaId);
      alert('SLA permanently deleted');
      loadSLAs();
    } catch (err) {
      console.error('Error deleting SLA:', err);
      alert('Failed to delete SLA: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleView = (sla) => {
    setSelectedSLA(sla);
    setShowViewModal(true);
  };

  const handleEdit = (sla) => {
    setSelectedSLA(sla);
    setShowCreateModal(true);
  };

  const getStatusBadge = (sla) => {
    if (!sla.is_active) {
      return <span className="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-800">Inactive</span>;
    }

    const compliance = sla.current_compliance || 0;
    const target = sla.target_value || 0;
    const warning = sla.warning_threshold || (target * 0.98);
    const critical = sla.critical_threshold || (target * 0.95);

    if (compliance >= target) {
      return (
        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 flex items-center gap-1">
          <FiCheck className="text-sm" />
          Compliant ({compliance.toFixed(2)}{sla.target_unit})
        </span>
      );
    } else if (compliance >= warning) {
      return (
        <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800 flex items-center gap-1">
          <FiAlertTriangle className="text-sm" />
          Warning ({compliance.toFixed(2)}{sla.target_unit})
        </span>
      );
    } else {
      return (
        <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800 flex items-center gap-1">
          <FiAlertTriangle className="text-sm" />
          Breach ({compliance.toFixed(2)}{sla.target_unit})
        </span>
      );
    }
  };

  const getMetricLabel = (metricType) => {
    const labels = {
      uptime: 'Uptime',
      response_time: 'Response Time',
      resolution_time: 'Resolution Time',
      error_rate: 'Error Rate',
      custom: 'Custom Metric'
    };
    return labels[metricType] || metricType;
  };

  if (loading) {
    return (
      <Card>
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading SLAs...</p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Associated SLAs</h3>
          <p className="text-sm text-gray-600">Service Level Agreements for {serviceName}</p>
        </div>
        <Button
          onClick={() => setShowCreateModal(true)}
          icon={<FiPlus />}
        >
          Create SLA
        </Button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {slas.length === 0 ? (
        <Card>
          <div className="text-center py-8">
            <FiAlertTriangle className="text-gray-400 text-5xl mx-auto mb-4" />
            <p className="text-gray-600 mb-4">No SLAs configured for this service</p>
            <Button
              onClick={() => setShowCreateModal(true)}
              icon={<FiPlus />}
            >
              Create Your First SLA
            </Button>
          </div>
        </Card>
      ) : (
        <div className="space-y-3">
          {slas.map((sla) => (
            <Card key={sla.sla_id} className="hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-semibold text-gray-900">{sla.name}</h4>
                    {getStatusBadge(sla)}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                    <div>
                      <div className="text-xs text-gray-500">Metric Type</div>
                      <div className="text-sm font-medium">{getMetricLabel(sla.metric_type)}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">Target</div>
                      <div className="text-sm font-medium">
                        {sla.target_value} {sla.target_unit}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">Priority</div>
                      <div className="text-sm font-medium">{sla.priority || 'N/A'}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">Current Performance</div>
                      <div className="text-sm font-medium">
                        {sla.current_compliance?.toFixed(2) || 'N/A'} {sla.target_unit}
                      </div>
                    </div>
                  </div>

                  {sla.description && (
                    <p className="text-sm text-gray-600 mb-2">{sla.description}</p>
                  )}

                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span>Effective from: {new Date(sla.effective_from).toLocaleDateString()}</span>
                    {sla.effective_until && (
                      <>
                        <span>•</span>
                        <span>Until: {new Date(sla.effective_until).toLocaleDateString()}</span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 ml-4">
                  <Button
                    size="sm"
                    variant="ghost"
                    icon={<FiEye />}
                    onClick={() => handleView(sla)}
                  >
                    View
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    icon={<FiEdit />}
                    onClick={() => handleEdit(sla)}
                  >
                    Edit
                  </Button>
                  {sla.is_active ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      icon={<FiX />}
                      onClick={() => handleToggleActivation(sla)}
                      className="text-orange-600 hover:text-orange-700"
                    >
                      Deactivate
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      icon={<FiCheck />}
                      onClick={() => handleToggleActivation(sla)}
                      className="text-green-600 hover:text-green-700"
                    >
                      Activate
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    icon={<FiTrash2 />}
                    onClick={() => handleDelete(sla.sla_id, sla.name)}
                    className="text-red-600 hover:text-red-700"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <CreateSLAModal
        isOpen={showCreateModal}
        onClose={() => {
          setShowCreateModal(false);
          setSelectedSLA(null);
        }}
        serviceId={serviceId}
        serviceName={serviceName}
        onSuccess={loadSLAs}
        editMode={!!selectedSLA}
        initialData={selectedSLA}
      />

      {/* View SLA Modal */}
      {showViewModal && selectedSLA && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{selectedSLA.name}</h2>
                <p className="text-sm text-gray-600">SLA Details</p>
              </div>
              <button
                onClick={() => {
                  setShowViewModal(false);
                  setSelectedSLA(null);
                }}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <FiEye className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              {/* Basic Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Basic Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">SLA Name</label>
                    <p className="mt-1 text-gray-900">{selectedSLA.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Status</label>
                    <p className="mt-1">{getStatusBadge(selectedSLA)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Priority</label>
                    <p className="mt-1 text-gray-900">{selectedSLA.priority}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Metric Type</label>
                    <p className="mt-1 text-gray-900 capitalize">{selectedSLA.metric_type}</p>
                  </div>
                </div>
              </div>

              {/* Description */}
              {selectedSLA.description && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Description</h3>
                  <p className="text-gray-700">{selectedSLA.description}</p>
                </div>
              )}

              {/* Performance Target */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Performance Target</h3>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="text-3xl font-bold text-blue-600">
                    {selectedSLA.target_value} {selectedSLA.target_unit}
                  </div>
                  <div className="text-sm text-blue-800 mt-1">Target Goal</div>
                  {selectedSLA.current_compliance !== null && selectedSLA.current_compliance !== undefined && (
                    <div className="mt-3 pt-3 border-t border-blue-200">
                      <div className="text-sm text-blue-800">Current Performance</div>
                      <div className="text-2xl font-semibold text-blue-700">
                        {selectedSLA.current_compliance?.toFixed(2)}%
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Thresholds */}
              {selectedSLA.metadata?.thresholds && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Performance Thresholds</h3>
                  <div className="grid grid-cols-3 gap-4">
                    {selectedSLA.metadata.thresholds.critical && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <div className="text-sm font-medium text-red-800">Critical</div>
                        <div className="text-xl font-bold text-red-600 mt-1">
                          {selectedSLA.metadata.thresholds.critical.value}%
                        </div>
                        <div className="text-xs text-red-700 mt-1">
                          {selectedSLA.metadata.thresholds.critical.action}
                        </div>
                      </div>
                    )}
                    {selectedSLA.metadata.thresholds.warning && (
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                        <div className="text-sm font-medium text-yellow-800">Warning</div>
                        <div className="text-xl font-bold text-yellow-600 mt-1">
                          {selectedSLA.metadata.thresholds.warning.value}%
                        </div>
                        <div className="text-xs text-yellow-700 mt-1">
                          {selectedSLA.metadata.thresholds.warning.action}
                        </div>
                      </div>
                    )}
                    {selectedSLA.metadata.thresholds.target && (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                        <div className="text-sm font-medium text-green-800">Target</div>
                        <div className="text-xl font-bold text-green-600 mt-1">
                          {selectedSLA.metadata.thresholds.target.value}%
                        </div>
                        <div className="text-xs text-green-700 mt-1">
                          {selectedSLA.metadata.thresholds.target.action}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Escalation Steps */}
              {selectedSLA.metadata?.escalationSteps && selectedSLA.metadata.escalationSteps.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Escalation Procedure</h3>
                  <div className="space-y-2">
                    {selectedSLA.metadata.escalationSteps.map((step, index) => (
                      <div key={index} className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="font-medium text-gray-900">Level {step.level}</div>
                            <div className="text-sm text-gray-600 mt-1">{step.action}</div>
                            {step.contact && (
                              <div className="text-sm text-gray-500 mt-1">Contact: {step.contact}</div>
                            )}
                          </div>
                          <div className="text-sm font-medium text-primary-600">
                            After {step.timeMinutes} min
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Effective Dates */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Effective Period</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Effective From</label>
                    <p className="mt-1 text-gray-900">
                      {selectedSLA.effective_from 
                        ? new Date(selectedSLA.effective_from).toLocaleDateString()
                        : 'Not set'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Effective Until</label>
                    <p className="mt-1 text-gray-900">
                      {selectedSLA.effective_until 
                        ? new Date(selectedSLA.effective_until).toLocaleDateString()
                        : 'Ongoing'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex justify-between">
              <Button
                variant="outline"
                onClick={() => {
                  setShowViewModal(false);
                  handleEdit(selectedSLA);
                }}
              >
                Edit SLA
              </Button>
              <Button
                variant="primary"
                onClick={() => {
                  setShowViewModal(false);
                  setSelectedSLA(null);
                }}
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SLAList;
