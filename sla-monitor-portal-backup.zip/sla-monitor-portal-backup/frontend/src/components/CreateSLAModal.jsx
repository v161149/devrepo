/**
 * CreateSLAModal Component
 * Comprehensive SLA/SLO creation and configuration
 */

import React, { useState, useEffect } from 'react';
import { FiX, FiSave, FiClock, FiTarget, FiTrendingUp, FiAlertTriangle } from 'react-icons/fi';
import Button from './Button';
import Card from './Card';
import apiService from '../services/api';

const CreateSLAModal = ({ isOpen, onClose, serviceId, serviceName, onSuccess, editMode = false, initialData = null }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    // Basic Information
    name: '',
    description: '',
    
    // Performance Metrics (Step 2)
    metricType: 'uptime',
    targetValue: '',
    targetUnit: 'percentage',
    priority: 'P2',
    
    // Performance Standards (Step 3)
    thresholds: {
      critical: { value: 95, action: 'immediate_escalation' },
      warning: { value: 97, action: 'notify_team' },
      target: { value: 99.9, action: 'normal_operation' }
    },
    
    // Resolution Procedures (Step 4)
    escalationSteps: [
      { level: 1, timeMinutes: 15, contact: '', action: 'Notify team lead' },
      { level: 2, timeMinutes: 30, contact: '', action: 'Escalate to manager' },
      { level: 3, timeMinutes: 60, contact: '', action: 'Notify executives' }
    ],
    
    // Penalties and Incentives (Step 5)
    penalties: {
      enabled: false,
      breachPenalty: '',
      penaltyType: 'service_credits',
      details: ''
    },
    incentives: {
      enabled: false,
      exceedBonus: '',
      bonusType: 'recognition',
      details: ''
    },
    
    // Start/Pause/Stop Conditions (Step 6)
    startCondition: {
      type: 'event',
      trigger: 'incident_created',
      field: 'status',
      value: 'open'
    },
    pauseCondition: {
      enabled: false,
      trigger: 'status_change',
      field: 'status',
      value: 'waiting_on_customer'
    },
    stopCondition: {
      type: 'event',
      trigger: 'incident_resolved',
      field: 'status',
      value: 'resolved'
    },
    
    // Business Hours Calendar (Step 7)
    businessHoursId: 'default_24_7',
    customCalendar: {
      enabled: false,
      timezone: 'America/Chicago',
      workdays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
      startTime: '09:00',
      endTime: '17:00',
      holidays: []
    },
    
    // Activation (Step 8)
    effectiveFrom: new Date().toISOString().split('T')[0],
    effectiveUntil: '',
    autoActivate: true
  });

  // Pre-fill form when in edit mode
  useEffect(() => {
    if (editMode && initialData) {
      // Parse metadata if it's a string
      const metadata = typeof initialData.metadata === 'string' 
        ? JSON.parse(initialData.metadata) 
        : initialData.metadata || {};

      setFormData({
        name: initialData.name || '',
        description: initialData.description || '',
        metricType: initialData.metric_type || 'uptime',
        targetValue: initialData.target_value || '',
        targetUnit: initialData.target_unit || 'percentage',
        priority: initialData.priority || 'P2',
        thresholds: metadata.thresholds || {
          critical: { value: 95, action: 'immediate_escalation' },
          warning: { value: 97, action: 'notify_team' },
          target: { value: 99.9, action: 'normal_operation' }
        },
        escalationSteps: metadata.escalationSteps || [
          { level: 1, timeMinutes: 15, contact: '', action: 'Notify team lead' },
          { level: 2, timeMinutes: 30, contact: '', action: 'Escalate to manager' },
          { level: 3, timeMinutes: 60, contact: '', action: 'Notify executives' }
        ],
        penalties: metadata.penalties || {
          enabled: false,
          breachPenalty: '',
          penaltyType: 'service_credits',
          details: ''
        },
        incentives: metadata.incentives || {
          enabled: false,
          exceedBonus: '',
          bonusType: 'recognition',
          details: ''
        },
        startCondition: initialData.start_condition || {
          type: 'event',
          trigger: 'incident_created',
          field: 'status',
          value: 'open'
        },
        pauseCondition: metadata.pauseCondition || {
          enabled: false,
          trigger: 'status_change',
          field: 'status',
          value: 'waiting_on_customer'
        },
        stopCondition: initialData.stop_condition || {
          type: 'event',
          trigger: 'incident_resolved',
          field: 'status',
          value: 'resolved'
        },
        businessHoursId: initialData.business_hours_id || 'default_24_7',
        customCalendar: metadata.customCalendar || {
          enabled: false,
          timezone: 'America/Chicago',
          workdays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
          startTime: '09:00',
          endTime: '17:00',
          holidays: []
        },
        effectiveFrom: initialData.effective_from 
          ? new Date(initialData.effective_from).toISOString().split('T')[0]
          : new Date().toISOString().split('T')[0],
        effectiveUntil: initialData.effective_until 
          ? new Date(initialData.effective_until).toISOString().split('T')[0]
          : '',
        autoActivate: initialData.is_active !== undefined ? initialData.is_active : true
      });
    } else if (!editMode) {
      // Reset form for create mode
      setFormData({
        name: '',
        description: '',
        metricType: 'uptime',
        targetValue: '',
        targetUnit: 'percentage',
        priority: 'P2',
        thresholds: {
          critical: { value: 95, action: 'immediate_escalation' },
          warning: { value: 97, action: 'notify_team' },
          target: { value: 99.9, action: 'normal_operation' }
        },
        escalationSteps: [
          { level: 1, timeMinutes: 15, contact: '', action: 'Notify team lead' },
          { level: 2, timeMinutes: 30, contact: '', action: 'Escalate to manager' },
          { level: 3, timeMinutes: 60, contact: '', action: 'Notify executives' }
        ],
        penalties: {
          enabled: false,
          breachPenalty: '',
          penaltyType: 'service_credits',
          details: ''
        },
        incentives: {
          enabled: false,
          exceedBonus: '',
          bonusType: 'recognition',
          details: ''
        },
        startCondition: {
          type: 'event',
          trigger: 'incident_created',
          field: 'status',
          value: 'open'
        },
        pauseCondition: {
          enabled: false,
          trigger: 'status_change',
          field: 'status',
          value: 'waiting_on_customer'
        },
        stopCondition: {
          type: 'event',
          trigger: 'incident_resolved',
          field: 'status',
          value: 'resolved'
        },
        businessHoursId: 'default_24_7',
        customCalendar: {
          enabled: false,
          timezone: 'America/Chicago',
          workdays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
          startTime: '09:00',
          endTime: '17:00',
          holidays: []
        },
        effectiveFrom: new Date().toISOString().split('T')[0],
        effectiveUntil: '',
        autoActivate: true
      });
      setStep(1);
    }
  }, [editMode, initialData, isOpen]);

  const METRIC_TYPES = [
    { id: 'uptime', name: 'Service Availability/Uptime', unit: 'percentage', description: 'Percentage of time service is available' },
    { id: 'response_time', name: 'Response Time', unit: 'minutes', description: 'Time to acknowledge an issue' },
    { id: 'resolution_time', name: 'Resolution Time', unit: 'hours', description: 'Time to resolve an issue' },
    { id: 'error_rate', name: 'Error/Defect Rate', unit: 'percentage', description: 'Percentage of errors or defects' },
    { id: 'custom', name: 'Custom Metric', unit: 'custom', description: 'Define your own metric' }
  ];

  const PRIORITY_LEVELS = [
    { id: 'P1', name: 'P1 - Critical', description: 'Immediate response required', slaTime: '15 minutes' },
    { id: 'P2', name: 'P2 - High', description: 'Urgent attention needed', slaTime: '1 hour' },
    { id: 'P3', name: 'P3 - Medium', description: 'Standard priority', slaTime: '4 hours' },
    { id: 'P4', name: 'P4 - Low', description: 'Low priority', slaTime: '24 hours' }
  ];

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);

    try {
      // Validate required fields
      if (!formData.name || formData.name.trim() === '') {
        setError('Please enter an SLA name');
        setLoading(false);
        return;
      }

      if (!formData.targetValue || formData.targetValue === '') {
        setError('Please enter a target value (e.g., 99.9)');
        setLoading(false);
        return;
      }

      // Validate target value is a number
      const targetNum = parseFloat(formData.targetValue);
      if (isNaN(targetNum) || targetNum <= 0) {
        setError('Target value must be a positive number');
        setLoading(false);
        return;
      }

      // Validate custom metric unit is provided
      if (formData.metricType === 'custom' && (!formData.targetUnit || formData.targetUnit.trim() === '' || formData.targetUnit === 'custom')) {
        setError('Please enter a unit for your custom metric (e.g., "jobs/day", "on-time completion rate")');
        setLoading(false);
        return;
      }

      // Transform camelCase to snake_case for backend
      const payload = {
        service_id: serviceId,
        name: formData.name,
        description: formData.description,
        metric_type: formData.metricType,
        target_value: formData.targetValue,
        target_unit: formData.targetUnit,
        priority: formData.priority,
        businessHoursId: formData.businessHoursId,
        startCondition: formData.startCondition,
        stopCondition: formData.stopCondition,
        pauseCondition: formData.pauseCondition,
        effectiveFrom: formData.effectiveFrom,
        effectiveUntil: formData.effectiveUntil,
        autoActivate: formData.autoActivate,
        thresholds: formData.thresholds,
        escalationSteps: formData.escalationSteps,
        penalties: formData.penalties,
        incentives: formData.incentives,
        customCalendar: formData.customCalendar
      };

      // Call appropriate API method based on mode
      if (editMode && initialData) {
        // Update existing SLA
        await apiService.slas.update(initialData.sla_id, payload);
      } else {
        // Create new SLA
        await apiService.slas.create(payload);
      }

      // Success! Reset and close
      setLoading(false);
      setStep(1);
      setError(null);
      
      if (onSuccess) {
        onSuccess();
      }
      
      onClose();
      
    } catch (err) {
      setLoading(false);
      setError(err.response?.data?.error || err.message || `Failed to ${editMode ? 'update' : 'create'} SLA`);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiTarget className="text-primary-500" />
          Basic Information
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Create an SLA for <strong>{serviceName}</strong>
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          SLA Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g., MySQL Database Uptime SLA"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Description
        </label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Describe the purpose and scope of this SLA..."
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        />
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiTrendingUp className="text-primary-500" />
          Performance Metrics (SMART KPIs)
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Define Specific, Measurable, Achievable, Relevant, and Time-bound Key Performance Indicators
        </p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Metric Type <span className="text-red-500">*</span>
        </label>
        <div className="grid grid-cols-1 gap-2">
          {METRIC_TYPES.map(metric => (
            <button
              key={metric.id}
              onClick={() => setFormData({ 
                ...formData, 
                metricType: metric.id, 
                targetUnit: metric.id === 'custom' ? '' : metric.unit  // Clear unit for custom metrics
              })}
              className={`p-3 text-left border-2 rounded-lg transition-all ${
                formData.metricType === metric.id
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="font-medium">{metric.name}</div>
              <div className="text-sm text-gray-600">{metric.description}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Target Value <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            step="0.01"
            value={formData.targetValue}
            onChange={(e) => setFormData({ ...formData, targetValue: e.target.value })}
            placeholder="99.9"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Unit {formData.metricType === 'custom' && <span className="text-red-500">*</span>}
          </label>
          <input
            type="text"
            value={formData.targetUnit}
            onChange={(e) => setFormData({ ...formData, targetUnit: e.target.value })}
            readOnly={formData.metricType !== 'custom'}
            placeholder={formData.metricType === 'custom' ? 'e.g., jobs/day, requests/sec, %, etc.' : ''}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              formData.metricType === 'custom' 
                ? 'focus:ring-2 focus:ring-primary-500 bg-white' 
                : 'bg-gray-50 cursor-not-allowed'
            }`}
          />
          {formData.metricType === 'custom' && (
            <p className="mt-1 text-xs text-gray-500">
              Enter the unit for your custom metric (e.g., "jobs/day", "on-time completion rate", "requests/second")
            </p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Priority Level <span className="text-red-500">*</span>
        </label>
        <div className="grid grid-cols-2 gap-2">
          {PRIORITY_LEVELS.map(priority => (
            <button
              key={priority.id}
              onClick={() => setFormData({ ...formData, priority: priority.id })}
              className={`p-3 text-left border-2 rounded-lg transition-all ${
                formData.priority === priority.id
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="font-medium">{priority.name}</div>
              <div className="text-xs text-gray-600">{priority.description}</div>
              <div className="text-xs text-primary-600 mt-1">Target: {priority.slaTime}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiTarget className="text-primary-500" />
          Performance Standards & Goals
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Set tiered performance targets based on business needs
        </p>
      </div>

      <Card>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-red-600">Critical Threshold</div>
              <div className="text-sm text-gray-600">Below this triggers immediate escalation</div>
            </div>
            <input
              type="number"
              step="0.1"
              value={formData.thresholds.critical.value}
              onChange={(e) => setFormData({
                ...formData,
                thresholds: { ...formData.thresholds, critical: { ...formData.thresholds.critical, value: parseFloat(e.target.value) }}
              })}
              className="w-24 px-3 py-2 border border-gray-300 rounded-lg"
            />
            <span className="text-sm text-gray-500">{formData.targetUnit}</span>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-yellow-600">Warning Threshold</div>
              <div className="text-sm text-gray-600">Below this triggers team notification</div>
            </div>
            <input
              type="number"
              step="0.1"
              value={formData.thresholds.warning.value}
              onChange={(e) => setFormData({
                ...formData,
                thresholds: { ...formData.thresholds, warning: { ...formData.thresholds.warning, value: parseFloat(e.target.value) }}
              })}
              className="w-24 px-3 py-2 border border-gray-300 rounded-lg"
            />
            <span className="text-sm text-gray-500">{formData.targetUnit}</span>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-green-600">Target Goal</div>
              <div className="text-sm text-gray-600">Normal operation target</div>
            </div>
            <input
              type="number"
              step="0.1"
              value={formData.thresholds.target.value}
              onChange={(e) => setFormData({
                ...formData,
                thresholds: { ...formData.thresholds, target: { ...formData.thresholds.target, value: parseFloat(e.target.value) }}
              })}
              className="w-24 px-3 py-2 border border-gray-300 rounded-lg"
            />
            <span className="text-sm text-gray-500">{formData.targetUnit}</span>
          </div>
        </div>
      </Card>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiAlertTriangle className="text-primary-500" />
          Escalation Procedures
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Define escalation matrix for when service levels are not met
        </p>
      </div>

      {formData.escalationSteps.map((step, index) => (
        <Card key={index}>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-semibold text-lg">Level {step.level}</div>
              <button
                onClick={() => {
                  const steps = formData.escalationSteps.filter((_, i) => i !== index);
                  setFormData({ ...formData, escalationSteps: steps });
                }}
                className="text-red-500 hover:text-red-700"
              >
                Remove
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Time (minutes)
                </label>
                <input
                  type="number"
                  value={step.timeMinutes}
                  onChange={(e) => {
                    const steps = [...formData.escalationSteps];
                    steps[index].timeMinutes = parseInt(e.target.value);
                    setFormData({ ...formData, escalationSteps: steps });
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contact
                </label>
                <input
                  type="text"
                  value={step.contact}
                  onChange={(e) => {
                    const steps = [...formData.escalationSteps];
                    steps[index].contact = e.target.value;
                    setFormData({ ...formData, escalationSteps: steps });
                  }}
                  placeholder="email@example.com"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Action to Take
              </label>
              <input
                type="text"
                value={step.action}
                onChange={(e) => {
                  const steps = [...formData.escalationSteps];
                  steps[index].action = e.target.value;
                  setFormData({ ...formData, escalationSteps: steps });
                }}
                placeholder="Notify team lead"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>
        </Card>
      ))}

      <Button
        onClick={() => {
          const newLevel = formData.escalationSteps.length + 1;
          setFormData({
            ...formData,
            escalationSteps: [
              ...formData.escalationSteps,
              { level: newLevel, timeMinutes: 0, contact: '', action: '' }
            ]
          });
        }}
        variant="outline"
      >
        + Add Escalation Level
      </Button>
    </div>
  );

  const renderStep5 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiTarget className="text-primary-500" />
          Penalties & Incentives
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Define consequences and rewards to motivate service provider
        </p>
      </div>

      <Card>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="font-semibold text-red-600">Penalties for Underperformance</div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.penalties.enabled}
                  onChange={(e) => setFormData({
                    ...formData,
                    penalties: { ...formData.penalties, enabled: e.target.checked }
                  })}
                  className="rounded"
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>

            {formData.penalties.enabled && (
              <div className="space-y-3 pl-4 border-l-2 border-red-200">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Penalty Type
                  </label>
                  <select
                    value={formData.penalties.penaltyType}
                    onChange={(e) => setFormData({
                      ...formData,
                      penalties: { ...formData.penalties, penaltyType: e.target.value }
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="service_credits">Service Credits</option>
                    <option value="financial_penalty">Financial Penalty</option>
                    <option value="contract_adjustment">Contract Adjustment</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Breach Penalty
                  </label>
                  <input
                    type="text"
                    value={formData.penalties.breachPenalty}
                    onChange={(e) => setFormData({
                      ...formData,
                      penalties: { ...formData.penalties, breachPenalty: e.target.value }
                    })}
                    placeholder="e.g., 10% credit per 0.1% below target"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Details
                  </label>
                  <textarea
                    value={formData.penalties.details}
                    onChange={(e) => setFormData({
                      ...formData,
                      penalties: { ...formData.penalties, details: e.target.value }
                    })}
                    rows={2}
                    placeholder="Additional penalty details..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="font-semibold text-green-600">Incentives for Exceeding Targets</div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.incentives.enabled}
                  onChange={(e) => setFormData({
                    ...formData,
                    incentives: { ...formData.incentives, enabled: e.target.checked }
                  })}
                  className="rounded"
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>

            {formData.incentives.enabled && (
              <div className="space-y-3 pl-4 border-l-2 border-green-200">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Incentive Type
                  </label>
                  <select
                    value={formData.incentives.bonusType}
                    onChange={(e) => setFormData({
                      ...formData,
                      incentives: { ...formData.incentives, bonusType: e.target.value }
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="recognition">Recognition Award</option>
                    <option value="performance_bonus">Performance Bonus</option>
                    <option value="extended_contract">Extended Contract</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Exceed Bonus
                  </label>
                  <input
                    type="text"
                    value={formData.incentives.exceedBonus}
                    onChange={(e) => setFormData({
                      ...formData,
                      incentives: { ...formData.incentives, exceedBonus: e.target.value }
                    })}
                    placeholder="e.g., Recognition + priority support"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Details
                  </label>
                  <textarea
                    value={formData.incentives.details}
                    onChange={(e) => setFormData({
                      ...formData,
                      incentives: { ...formData.incentives, details: e.target.value }
                    })}
                    rows={2}
                    placeholder="Additional incentive details..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );

  const renderStep6 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiClock className="text-primary-500" />
          Start, Pause & Stop Conditions
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Define when SLA time tracking should begin, pause, and stop
        </p>
      </div>

      <Card>
        <div className="space-y-4">
          <div>
            <div className="font-semibold text-green-600 mb-2">Start Condition</div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Trigger Event
                </label>
                <select
                  value={formData.startCondition.trigger}
                  onChange={(e) => setFormData({
                    ...formData,
                    startCondition: { ...formData.startCondition, trigger: e.target.value }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="incident_created">Incident Created</option>
                  <option value="ticket_opened">Ticket Opened</option>
                  <option value="service_unavailable">Service Unavailable</option>
                  <option value="alert_triggered">Alert Triggered</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Field Value
                </label>
                <input
                  type="text"
                  value={formData.startCondition.value}
                  onChange={(e) => setFormData({
                    ...formData,
                    startCondition: { ...formData.startCondition, value: e.target.value }
                  })}
                  placeholder="e.g., open"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="font-semibold text-yellow-600">Pause Condition</div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.pauseCondition.enabled}
                  onChange={(e) => setFormData({
                    ...formData,
                    pauseCondition: { ...formData.pauseCondition, enabled: e.target.checked }
                  })}
                  className="rounded"
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>

            {formData.pauseCondition.enabled && (
              <div className="grid grid-cols-2 gap-3 pl-4 border-l-2 border-yellow-200">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Trigger Event
                  </label>
                  <select
                    value={formData.pauseCondition.trigger}
                    onChange={(e) => setFormData({
                      ...formData,
                      pauseCondition: { ...formData.pauseCondition, trigger: e.target.value }
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="status_change">Status Change</option>
                    <option value="waiting_on_customer">Waiting on Customer</option>
                    <option value="scheduled_maintenance">Scheduled Maintenance</option>
                    <option value="third_party_dependency">Third Party Issue</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Field Value
                  </label>
                  <input
                    type="text"
                    value={formData.pauseCondition.value}
                    onChange={(e) => setFormData({
                      ...formData,
                      pauseCondition: { ...formData.pauseCondition, value: e.target.value }
                    })}
                    placeholder="e.g., waiting_on_customer"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <div className="font-semibold text-red-600 mb-2">Stop Condition</div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Trigger Event
                </label>
                <select
                  value={formData.stopCondition.trigger}
                  onChange={(e) => setFormData({
                    ...formData,
                    stopCondition: { ...formData.stopCondition, trigger: e.target.value }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="incident_resolved">Incident Resolved</option>
                  <option value="ticket_closed">Ticket Closed</option>
                  <option value="service_restored">Service Restored</option>
                  <option value="confirmed_fix">Fix Confirmed</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Field Value
                </label>
                <input
                  type="text"
                  value={formData.stopCondition.value}
                  onChange={(e) => setFormData({
                    ...formData,
                    stopCondition: { ...formData.stopCondition, value: e.target.value }
                  })}
                  placeholder="e.g., resolved"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );

  const renderStep7 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiClock className="text-primary-500" />
          Business Hours Calendar
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          SLA clock only runs during configured business hours
        </p>
      </div>

      <Card>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Calendar Template
            </label>
            <select
              value={formData.businessHoursId}
              onChange={(e) => setFormData({ ...formData, businessHoursId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            >
              <option value="default_24_7">24/7 - Always Running</option>
              <option value="default_business">Business Hours (Mon-Fri, 9-5)</option>
              <option value="custom">Custom Calendar</option>
            </select>
          </div>

          {formData.businessHoursId === 'custom' && (
            <div className="space-y-4 pl-4 border-l-2 border-primary-200">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Timezone
                  </label>
                  <select
                    value={formData.customCalendar.timezone}
                    onChange={(e) => setFormData({
                      ...formData,
                      customCalendar: { ...formData.customCalendar, timezone: e.target.value }
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="America/New_York">Eastern Time</option>
                    <option value="America/Chicago">Central Time</option>
                    <option value="America/Denver">Mountain Time</option>
                    <option value="America/Los_Angeles">Pacific Time</option>
                    <option value="UTC">UTC</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Work Days
                  </label>
                  <div className="flex gap-1">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
                      <button
                        key={day}
                        onClick={() => {
                          const dayNames = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
                          const dayName = dayNames[i];
                          const workdays = formData.customCalendar.workdays.includes(dayName)
                            ? formData.customCalendar.workdays.filter(d => d !== dayName)
                            : [...formData.customCalendar.workdays, dayName];
                          setFormData({
                            ...formData,
                            customCalendar: { ...formData.customCalendar, workdays }
                          });
                        }}
                        className={`px-2 py-1 text-xs rounded ${
                          formData.customCalendar.workdays.includes(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][i])
                            ? 'bg-primary-500 text-white'
                            : 'bg-gray-200'
                        }`}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={formData.customCalendar.startTime}
                    onChange={(e) => setFormData({
                      ...formData,
                      customCalendar: { ...formData.customCalendar, startTime: e.target.value }
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={formData.customCalendar.endTime}
                    onChange={(e) => setFormData({
                      ...formData,
                      customCalendar: { ...formData.customCalendar, endTime: e.target.value }
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Holidays (comma-separated dates: YYYY-MM-DD)
                </label>
                <input
                  type="text"
                  value={formData.customCalendar.holidays.join(', ')}
                  onChange={(e) => setFormData({
                    ...formData,
                    customCalendar: { 
                      ...formData.customCalendar, 
                      holidays: e.target.value.split(',').map(d => d.trim()).filter(d => d)
                    }
                  })}
                  placeholder="2025-12-25, 2026-01-01, 2026-07-04"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>
          )}
        </div>
      </Card>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <FiClock className="text-blue-600 mt-1" />
          <div className="text-sm text-blue-800">
            <strong>Note:</strong> SLA timer will pause outside business hours, on holidays, and during maintenance windows.
            Only time within business hours counts toward SLA targets.
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep8 = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FiTarget className="text-primary-500" />
          Activate & Monitor
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Set effective dates and monitoring preferences
        </p>
      </div>

      <Card>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Effective From <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={formData.effectiveFrom}
                onChange={(e) => setFormData({ ...formData, effectiveFrom: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Effective Until (Optional)
              </label>
              <input
                type="date"
                value={formData.effectiveUntil}
                onChange={(e) => setFormData({ ...formData, effectiveUntil: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.autoActivate}
                onChange={(e) => setFormData({ ...formData, autoActivate: e.target.checked })}
                className="rounded"
              />
              <span className="text-sm font-medium">Auto-activate this SLA immediately</span>
            </label>
            <p className="text-xs text-gray-500 ml-6">
              If unchecked, SLA will be created in draft mode and require manual activation
            </p>
          </div>
        </div>
      </Card>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="font-semibold text-green-800 mb-2">What happens after creation:</div>
        <ul className="text-sm text-green-700 space-y-1 ml-4 list-disc">
          <li>SLA will be linked to the service</li>
          <li>Real-time monitoring will begin</li>
          <li>Automated alerts will be configured</li>
          <li>Compliance tracking will start</li>
          <li>Performance dashboards will be available</li>
        </ul>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="font-semibold text-yellow-800 mb-2">Review Your SLA:</div>
        <div className="text-sm text-yellow-700 space-y-1">
          <div><strong>Name:</strong> {formData.name || 'Not set'}</div>
          <div><strong>Metric:</strong> {METRIC_TYPES.find(m => m.id === formData.metricType)?.name || 'Not set'}</div>
          <div><strong>Target:</strong> {formData.targetValue} {formData.targetUnit}</div>
          <div><strong>Priority:</strong> {formData.priority}</div>
          <div><strong>Business Hours:</strong> {formData.businessHoursId === 'default_24_7' ? '24/7' : formData.businessHoursId === 'default_business' ? 'Business Hours' : 'Custom'}</div>
        </div>
      </div>
    </div>
  );

  const renderStepIndicator = () => (
    <div className="flex items-center justify-between mb-6">
      {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
        <React.Fragment key={num}>
          <div className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold ${
            step === num
              ? 'bg-primary-500 text-white'
              : step > num
              ? 'bg-green-500 text-white'
              : 'bg-gray-200 text-gray-600'
          }`}>
            {num}
          </div>
          {num < 8 && (
            <div className={`flex-1 h-1 mx-2 ${step > num ? 'bg-green-500' : 'bg-gray-200'}`} />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between z-10">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {editMode ? 'Edit SLA' : 'Create SLA'}
            </h2>
            <p className="text-sm text-gray-600">
              {editMode ? `Editing: ${initialData?.name || 'SLA'}` : `Step ${step} of 8`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <FiX className="text-2xl" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-4">
          {renderStepIndicator()}
        </div>

        {/* Content */}
        <div className="px-6 py-4">
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <FiAlertTriangle />
              {error}
            </div>
          )}

          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}
          {step === 4 && renderStep4()}
          {step === 5 && renderStep5()}
          {step === 6 && renderStep6()}
          {step === 7 && renderStep7()}
          {step === 8 && renderStep8()}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex items-center justify-between">
          <Button
            onClick={() => setStep(Math.max(1, step - 1))}
            variant="outline"
            disabled={step === 1}
          >
            Previous
          </Button>

          <div className="flex gap-2">
            <Button onClick={onClose} variant="outline">
              Cancel
            </Button>
            
            {step < 8 ? (
              <Button onClick={() => setStep(step + 1)}>
                Next
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                loading={loading}
                icon={<FiSave />}
              >
                {editMode ? 'Update SLA' : 'Create SLA'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateSLAModal;
