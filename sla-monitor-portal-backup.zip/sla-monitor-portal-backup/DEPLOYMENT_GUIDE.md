# SLA Monitoring Portal - Complete Setup & Deployment Guide

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Local Development Setup](#local-development-setup)
3. [Database Configuration](#database-configuration)
4. [Backend Setup](#backend-setup)
5. [Frontend Setup](#frontend-setup)
6. [Production Deployment](#production-deployment)
7. [Configuration Options](#configuration-options)
8. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements
- **CPU**: 2 cores
- **RAM**: 4 GB
- **Storage**: 20 GB
- **OS**: Linux (Ubuntu 20.04+), macOS, or Windows 10+
- **Python**: 3.8 or higher
- **Node.js**: 16.x or higher (for development)
- **Browser**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

### Recommended for Production
- **CPU**: 4+ cores
- **RAM**: 8+ GB
- **Storage**: 50+ GB SSD
- **OS**: Ubuntu 22.04 LTS
- **Load Balancer**: Nginx or HAProxy
- **Container Platform**: Docker + Kubernetes

---

## Local Development Setup

### Step 1: Clone or Extract Project

```bash
# If from Git
git clone <repository-url>
cd sla-monitoring-portal

# If from zip
unzip sla-monitoring-portal.zip
cd sla-monitoring-portal
```

### Step 2: Project Structure Verification

Ensure you have the following structure:

```
sla-monitoring-portal/
├── database/
│   ├── schema.sql
│   └── init_db.py
├── backend/
│   ├── database_service.py
│   ├── sla_evaluation_engine.py
│   ├── alerting_service.py
│   └── api_service.py
├── frontend/
│   └── (React application files)
├── requirements.txt
└── README.md
```

---

## Database Configuration

### Step 1: Initialize Database

```bash
cd database

# Run the initialization script
python3 init_db.py
```

**Expected Output:**
```
✓ Database schema created successfully
✓ Inserted sample data:
  - 1 Organization
  - 1 Admin User
  - 3 Customers
  - 9 Services
  - Multiple SLAs
  - 20 Sample Events
✓ Database initialized successfully
```

### Step 2: Verify Database

```bash
# Check if database file was created
ls -lh sla_portal.db

# Optional: Inspect database
sqlite3 sla_portal.db "SELECT name FROM sqlite_master WHERE type='table';"
```

### Step 3: Backup Database (Recommended)

```bash
# Create backup
cp sla_portal.db sla_portal.db.backup

# Or use SQLite backup
sqlite3 sla_portal.db ".backup sla_portal_backup.db"
```

---

## Backend Setup

### Step 1: Install Python Dependencies

```bash
cd ../backend

# Install all required packages
pip install -r ../requirements.txt --break-system-packages

# Or use virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r ../requirements.txt
```

### Step 2: Configure Environment

Create `.env` file in backend directory:

```bash
cat > .env << EOF
# Database
DATABASE_PATH=../database/sla_portal.db

# API Configuration
API_HOST=0.0.0.0
API_PORT=5000
API_DEBUG=True
SECRET_KEY=your-secret-key-change-in-production

# CORS Origins (comma-separated)
CORS_ORIGINS=http://localhost:3000,http://localhost:5000

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/api.log

# Email (Optional - configure if using email alerts)
EMAIL_PROVIDER=sendgrid
EMAIL_API_KEY=
EMAIL_FROM=noreply@yourdomain.com

# Slack (Optional)
SLACK_WEBHOOK_URL=

# PagerDuty (Optional)
PAGERDUTY_API_KEY=
PAGERDUTY_SERVICE_ID=

# Datadog (Optional)
DATADOG_API_KEY=
DATADOG_APP_KEY=
EOF
```

### Step 3: Start Backend Server

```bash
# Development mode
python3 api_service.py

# Production mode (with Gunicorn)
gunicorn -w 4 -b 0.0.0.0:5000 api_service:app
```

**Expected Output:**
```
 * Serving Flask app 'api_service'
 * Debug mode: on
WARNING: This is a development server. Do not use it in production.
 * Running on http://0.0.0.0:5000
Press CTRL+C to quit
```

### Step 4: Verify Backend

```bash
# Test health endpoint
curl http://localhost:5000/health

# Expected response:
# {"status":"healthy","timestamp":"2025-11-21T10:00:00Z"}

# Test API info
curl http://localhost:5000/api/v1/info
```

---

## Frontend Setup

### Option 1: Standalone HTML (Quickest)

```bash
# Simply open the HTML file in browser
open sla-monitoring-portal.html

# Or with a simple HTTP server
cd frontend
python3 -m http.server 8080
# Then open http://localhost:8080/sla-monitoring-portal.html
```

### Option 2: Full React Development Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm start
```

The application will open at `http://localhost:3000`

### Step 3: Login

Use the default credentials:
- **Email**: admin@demo.com
- **Password**: admin123

---

## Production Deployment

### Option 1: Docker Deployment

#### Create Dockerfile

```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    sqlite3 \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY database/ ./database/
COPY backend/ ./backend/

# Initialize database
RUN cd database && python init_db.py

# Expose port
EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=3s \
  CMD curl -f http://localhost:5000/health || exit 1

# Run application
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "--chdir", "backend", "api_service:app"]
```

#### Build and Run

```bash
# Build image
docker build -t sla-monitoring-portal:latest .

# Run container
docker run -d \
  --name sla-portal \
  -p 5000:5000 \
  -v $(pwd)/database:/app/database \
  -e API_DEBUG=False \
  sla-monitoring-portal:latest

# Check logs
docker logs -f sla-portal
```

### Option 2: Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  api:
    build: .
    container_name: sla-portal-api
    ports:
      - "5000:5000"
    volumes:
      - ./database:/app/database
      - ./logs:/app/logs
    environment:
      - DATABASE_PATH=/app/database/sla_portal.db
      - API_DEBUG=False
      - SECRET_KEY=${SECRET_KEY}
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  nginx:
    image: nginx:alpine
    container_name: sla-portal-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./frontend/build:/usr/share/nginx/html
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - api
    restart: unless-stopped

volumes:
  database:
  logs:
```

Run with:
```bash
docker-compose up -d
```

### Option 3: Kubernetes Deployment

#### Create Kubernetes Manifests

**deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sla-portal-api
  labels:
    app: sla-portal
    component: api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: sla-portal
      component: api
  template:
    metadata:
      labels:
        app: sla-portal
        component: api
    spec:
      containers:
      - name: api
        image: sla-monitoring-portal:latest
        ports:
        - containerPort: 5000
        env:
        - name: DATABASE_PATH
          value: "/data/sla_portal.db"
        - name: API_DEBUG
          value: "False"
        volumeMounts:
        - name: database
          mountPath: /data
        livenessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
      volumes:
      - name: database
        persistentVolumeClaim:
          claimName: sla-portal-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: sla-portal-api-service
spec:
  selector:
    app: sla-portal
    component: api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 5000
  type: LoadBalancer
```

Deploy:
```bash
kubectl apply -f deployment.yaml
```

### Option 4: Traditional Server Deployment

#### On Ubuntu Server

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and dependencies
sudo apt install -y python3 python3-pip python3-venv nginx

# Create application user
sudo useradd -m -s /bin/bash slamonitor
sudo su - slamonitor

# Clone or copy application
cd /home/slamonitor
# ... copy application files ...

# Setup virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Initialize database
cd database && python3 init_db.py

# Setup systemd service
sudo cat > /etc/systemd/system/sla-portal.service << EOF
[Unit]
Description=SLA Monitoring Portal API
After=network.target

[Service]
User=slamonitor
Group=slamonitor
WorkingDirectory=/home/slamonitor/backend
Environment="PATH=/home/slamonitor/venv/bin"
ExecStart=/home/slamonitor/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 api_service:app

[Install]
WantedBy=multi-user.target
EOF

# Start service
sudo systemctl daemon-reload
sudo systemctl enable sla-portal
sudo systemctl start sla-portal

# Configure Nginx
sudo cat > /etc/nginx/sites-available/sla-portal << EOF
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/sla-portal /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## Configuration Options

### Database Configuration

**Location**: `database/init_db.py`

Modify sample data:
- Number of organizations
- Users and roles
- Sample customers
- Services
- SLAs
- Events

### API Configuration

**Location**: `backend/.env`

Key settings:
- `DATABASE_PATH`: Path to SQLite database
- `API_PORT`: Port for API server
- `SECRET_KEY`: JWT signing key (MUST change in production)
- `CORS_ORIGINS`: Allowed origins for CORS

### Frontend Configuration

**Location**: `frontend/sla-monitoring-portal.html`

Update `API_BASE_URL`:
```javascript
const API_BASE_URL = 'http://your-backend-url:5000/api/v1';
```

---

## Troubleshooting

### Issue: Database not found

**Solution:**
```bash
# Verify database path
ls -l database/sla_portal.db

# Re-initialize if needed
cd database && python3 init_db.py
```

### Issue: Port already in use

**Solution:**
```bash
# Find process using port 5000
lsof -i :5000
# or
netstat -tulpn | grep 5000

# Kill process or change port in .env
```

### Issue: CORS errors

**Solution:**
Update `CORS_ORIGINS` in `.env`:
```
CORS_ORIGINS=http://localhost:3000,http://yourdomain.com
```

### Issue: Authentication fails

**Solution:**
```bash
# Reset admin password
sqlite3 database/sla_portal.db
> UPDATE users SET password_hash = '<new-hash>' WHERE email = 'admin@demo.com';
```

### Issue: High memory usage

**Solution:**
```bash
# Reduce Gunicorn workers
gunicorn -w 2 -b 0.0.0.0:5000 api_service:app

# Or use gevent workers
gunicorn -k gevent -w 4 -b 0.0.0.0:5000 api_service:app
```

---

## Performance Optimization

### Database Optimization

```sql
-- Add additional indexes if needed
CREATE INDEX idx_events_service_timestamp ON events(service_id, timestamp DESC);
CREATE INDEX idx_evaluations_service_breach ON evaluations(service_id, is_breach);

-- Analyze and optimize
ANALYZE;
VACUUM;
```

### API Optimization

```python
# Enable caching (add to api_service.py)
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@cache.cached(timeout=60)
def get_dashboard_metrics():
    # ... existing code ...
```

### Frontend Optimization

- Enable gzip compression in Nginx
- Use CDN for static assets
- Implement service worker for caching
- Lazy load components

---

## Monitoring & Maintenance

### Log Management

```bash
# View API logs
tail -f backend/logs/api.log

# Rotate logs (add to crontab)
0 0 * * * find /path/to/logs -name "*.log" -mtime +30 -delete
```

### Database Maintenance

```bash
# Weekly backup script
#!/bin/bash
DATE=$(date +%Y%m%d)
sqlite3 database/sla_portal.db ".backup backups/sla_portal_$DATE.db"
find backups/ -name "*.db" -mtime +30 -delete
```

### Health Checks

```bash
# Add to monitoring system
curl -f http://localhost:5000/health || alert_admin
```

---

## Security Checklist

- [ ] Change default admin password
- [ ] Update SECRET_KEY in production
- [ ] Enable HTTPS/TLS
- [ ] Configure firewall rules
- [ ] Enable rate limiting
- [ ] Set up intrusion detection
- [ ] Regular security updates
- [ ] Database encryption at rest
- [ ] Secure API keys management
- [ ] Enable audit logging

---

## Support & Resources

- **Documentation**: See README.md
- **API Reference**: See API_DOCUMENTATION.md
- **Issues**: GitHub Issues
- **Email**: support@slamonitor.com

---

**Setup complete! Your SLA Monitoring Portal is ready to use.**
