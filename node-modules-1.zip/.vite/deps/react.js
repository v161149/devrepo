import {
  require_react
} from "./chunk-WGQ442SR.js";
export default require_react();
