import {
  require_react_dom
} from "./chunk-5OEL3WWE.js";
import "./chunk-WGQ442SR.js";
export default require_react_dom();
