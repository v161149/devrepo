package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Collection;
import java.util.LinkedList;

public class Dummy
{
    Dummy selfInst = null;
    int year = 2003;
    boolean status = true;
    String name = "Dummy";
    Map properties = null;
    Collection children = null;

    public Dummy getSelfInst() { return selfInst; }
    public void setSelfInst(Dummy value) { selfInst = value; }

    public int getYear() { return year; }
    public void setYear(int value) { year = value; }

    public boolean getStatus() { return status; }
    public void setStatus(boolean value) { status = value; }

    public String getName() { return name; }
    public void setName(String value) { name = value; }

    public Map getProperties() { return properties; }
    public void setProperties(Map value) { properties = value; }

    public Collection getChildren() { return children; }
    public void setChildren(Collection value) { children = value; }

    public boolean equalsTo(Object another)
    {
        boolean same = false;

        if (another == null || !(another instanceof Dummy))
            return false;

        Dummy value = (Dummy)another;
        if (selfInst == null)
        {
            if (value.getSelfInst() != null)
            {
                System.out.println("selfInst not the same, null");
                return false;
            }
        }
        else
        {
            if (!selfInst.equalsTo(value.getSelfInst()))
            {
                System.out.println("selfInst not the same");
                return false;
            }
        }

        if (year != value.getYear())
        {
            System.out.println("year not the same");
            return false;
        }

        if (status != value.getStatus())
        {
            System.out.println("status not the same");
            return false;
        }

        if (name == null)
        {
            if (value.getName() != null)
            {
                System.out.println("name not the same, null");
                return false;
            }
        }
        else
        {
            if (!name.equals(value.getName()))
            {
                System.out.println("name not the same");
                return false;
            }
        }

        if (properties == null)
        {
            if (value.getProperties() != null)
            {
                System.out.println("properties not the same, null");
                return false;
            }
        }
        else
        {
            if (properties.size() != value.getProperties().size())
            {
                System.out.println("properties not the same");
                return false;
            }
        }

        if (children == null)
        {
            if (value.getChildren() != null)
            {
                System.out.println("children not the same, null");
                return false;
            }
        }
        else
        {
            if (children.size() != value.getChildren().size())
            {
                System.out.println("children not the same.");
                return false;
            }
        }

        if (properties != null && !properties.equals(value.getProperties()))
        {
            System.out.println("properties not the same. compare");
            return false;
        }

        if (children != null && !children.equals(value.getChildren()))
        {
            System.out.println("children not the same. compare");
            return false;
        }

        return true;
    }
}