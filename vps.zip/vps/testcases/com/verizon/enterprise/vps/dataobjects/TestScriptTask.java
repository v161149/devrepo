package com.verizon.enterprise.vps.dataobjects;

import junit.framework.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

import com.verizon.enterprise.vps.middleware.ScheduleAdmin;
import com.verizon.enterprise.vps.middleware.ScheduleAdminHome;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.core.BeanXmlFactory;
import com.verizon.enterprise.vps.util.ScriptUtil;
import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.common.datalayer.ecp.JobScheduleDefObject;

public class TestScriptTask
{
    // Constants.
    public static final String JNDI_SCHEDULE_ADMIN = "enterprise.ScheduleAdmin";
    public static final Long TEST_UID = new Long(123);

    public static Context sm_rootContext = null;
    public static ScheduleAdmin sm_adminBean = null;

    public TestScriptTask()
    {
        try {
            getAdminBean();
        }
        catch (Exception ex) {}
    }

    /**
     * Get bean
     */
    public ScheduleAdmin getAdminBean() throws Exception {
        if (sm_adminBean != null) return sm_adminBean;

        if (sm_rootContext==null) sm_rootContext = new InitialContext();
        Context ctx = sm_rootContext;

        ScheduleAdminHome home = (ScheduleAdminHome)ctx.lookup(JNDI_SCHEDULE_ADMIN);
        ScheduleAdmin bean = (ScheduleAdmin)PortableRemoteObject.narrow(home.create(), ScheduleAdmin.class);

        sm_adminBean = bean;
        return bean;
    }

    public void scheduleScriptTask(String scriptName, HashMap map) throws Exception
    {
        OnceSchedule schedule = new OnceSchedule();
        ScriptTask scriptTask = new ScriptTask(scriptName);
        scriptTask.setRegistry(map);

        ScheduleManager sm = new ScheduleManager();
        sm.scheduleTransientJob(scriptTask, schedule);
    }

    public void scheduleScriptTaskPersist(String scriptName, HashMap map, boolean bRemoveAfterCreate) throws Exception
    {
        System.out.println("ENTER: scheduleScriptTaskPersist");
        OnceSchedule schedule = new OnceSchedule();
        ScriptTask scriptTask = new ScriptTask(scriptName);
        Assert.assertNotNull(map);
        scriptTask.setRegistry(map);
        schedule.setName("zc53");

        TestRam.result = null;

        ScheduleAdmin adminBean = getAdminBean();
        Assert.assertNotNull(adminBean);
        System.out.println("got schedule bean");
        JobScheduleDefObject jsdo = adminBean.schedulePersistentJob(scriptTask, schedule, TEST_UID);
        System.out.println("schedule task");
        Thread.sleep(5000);
        System.out.println("Result1 = " + TestRam.result);

        if (bRemoveAfterCreate) {
            adminBean.unschedulePersistentJob(jsdo, TEST_UID, true);
            System.out.println("Schedule def object removed: " + jsdo.getJobScheduleDefOid());
        }
        Assert.assertNotNull(jsdo);
        Assert.assertNotNull(TestRam.result);
    }


    public void testScriptTask(String scriptName, HashMap map) throws Exception
    {
        System.out.println("ENTER: testScriptTask");
        OnceSchedule schedule = new OnceSchedule();
        ScriptTask scriptTask = new ScriptTask(scriptName);
        Assert.assertNotNull(map);
        scriptTask.setRegistry(map);
        schedule.setName("zc53");

        TestRam.result = null;

        System.out.println("XML script: " + scriptTask.writeTaskInfo());
    }

    public void testBeanXml() throws Exception
    {
        Dummy dummy = new Dummy();

        Dummy dummy1 = new Dummy();

        dummy.setSelfInst(dummy1);

        ArrayList list = new ArrayList();
        list.add("Test");
        list.add(new Boolean(true));
        list.add(new Integer(15));
        System.out.println(BeanXmlFactory.buildXmlFromCollection(list, BeanXmlFactory.TAG_ARG, "dummyList"));

        HashMap map = new HashMap();
        map.put("String", "Test");
        map.put("Boolean", new Boolean(true));
        map.put("Integer", new Integer(15));

        dummy.setProperties(map);
        dummy.setChildren(list);

        String xml = BeanXmlFactory.buildXmlFromObject(dummy, BeanXmlFactory.TAG_ARG, "dummyObject", 0);
        System.out.println("xml  = " + xml);

        dummy1 = null;
        dummy1 = (Dummy)BeanXmlFactory.buildJavaBeanFromXml(xml);

        Assert.assertNotNull("Object is null.", dummy1);
        Assert.assertTrue("Object is not the same.", dummy.equalsTo(dummy1));
        System.out.println("dummy = " + dummy1);
    }
}
