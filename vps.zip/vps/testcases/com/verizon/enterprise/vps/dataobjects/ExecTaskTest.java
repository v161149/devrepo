package com.verizon.enterprise.vps.dataobjects;

import junit.framework.*;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class ExecTaskTest extends TestCase
{
    String source;
    public void testSyntax() throws Exception {
        source = "<exec dir=\".\" executable=\"dir\" os=\"Windows 2000\" "+
                 "output=\"out.log\" append=\"true\" timeout=\"3600\" "+
                 "newenvironment=\"false\" vmlauncher=\"true\">"+
                 "<env name=\"ORA_HOME\">/apps/opt/oracle/product/9.2.0</env>"+
                 "<arg></arg>"+
                 "</exec>";
        ExecTask task = (ExecTask) XmlPersistentTask.parse(source);
        task.run();
    }
    public void testExec(String sExec) throws Exception {
        source = sExec;
        ExecTask task = (ExecTask) XmlPersistentTask.parse(source);
        task.run();
    }
    public static void main(String[] args) throws Exception {
        new ExecTaskTest().testSyntax();
    }
}
