package com.verizon.enterprise.vps.ui.tag;

import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.enterprise.vps.dataobjects.*;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class UITimeoutTest implements IVpsInteractiveTask
{
  private int sec;
  private boolean success;
  private String result;

  public UITimeoutTest(int _sec) {
    sec = _sec;
  }

  public void run() throws Exception {
    success = false;
    sleep(sec);
    success = true;
    result = "test slept "+sec+" seconds";
  }

  public String getDescription() {
    return "sleep "+sec+" seconds";
  }

  public Object getResult() {
    return result;
  }

  public boolean isSuccessful() {
    return success;
  }

  public void sleep(int sec) throws Exception
  {
    for (int i = 1; i <= sec; i++) {
      synchronized (this) {
        this.wait(1000);
      }
      double percent = i*100.0/sec;
      LogHelper.info("...... Task finished " + percent + "% ......");
    }
  }
}