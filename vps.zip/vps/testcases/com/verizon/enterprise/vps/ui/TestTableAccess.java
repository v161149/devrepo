package com.verizon.enterprise.vps.ui;

import java.util.*;
import java.sql.Timestamp;
import com.verizon.enterprise.vps.ui.dataobjects.TaskInstance;
import com.verizon.enterprise.vps.ui.datalayer.TaskInstanceTableAccess;
import com.verizon.enterprise.vps.ui.helper.Util;

import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.kernel.exception.DatalayerException;
import org.apache.log4j.Logger;

import com.verizon.kernel.jdbc.CursorResult;
import com.verizon.kernel.jdbc.CursorId;


public class TestTableAccess {

    private static Logger logger = Logger.getLogger(TestTableAccess.class);

    public TestTableAccess () {
    }

    public void selectTaskInstance(String sCondition) throws Exception {
        List qTIs = TaskInstanceTable.search(sCondition);
        System.out.println("Got " + qTIs.size() + " task instances from database by condition " + sCondition);
    }

    public static void cursorTest (int pageSize, int pageNumber,
				   int action, String condition) throws Exception{
	CursorId myCursor = Util.getNewCursorId (pageSize);
	myCursor.setPosition (pageSize*pageNumber+1);
	System.out.println (myCursor.getCursorId());
	TaskInstanceTableAccess ti = new TaskInstanceTableAccess();
	List list = ti.getInstancesByDefOidWithPagination(condition, myCursor);

	log (myCursor, list);

	System.out.println ("starting the second....");
	myCursor.setPageSize(40);
	myCursor.setPageNumber(1);
	myCursor.setAction(CursorId.GOTO_PAGE);
	list = ti.getInstancesByDefOidWithPagination(condition, myCursor);

	log (myCursor, list);
    }

    public static void log (CursorId returnedCursor, Collection objects){
	System.out.println ("Returned cursor with id = " + returnedCursor.getCursorId());
	System.out.println ("Total number of rows = " + returnedCursor.getTotalRows());
	System.out.println ("Current page number = " + returnedCursor.getPageNumber());
	System.out.println ("Current position = " + returnedCursor.getPosition());
	System.out.println ("Returned number of objects = " + objects.size());

	Iterator iterator = objects.iterator();

	while (iterator.hasNext()) {
	    Object object = iterator.next();

	    if (object instanceof TaskInstance)
		System.out.println (((TaskInstance)object).getStartTime());
	    else
		System.out.println ("Return object is NOT type of TaskInstanceObject..");
	}

	System.out.println ("-------------------------------------------------");
    }

    public static void main (String[] args) throws Exception {
	String condition = "where job_ref_oid = 24398 order by start_time DESC";
	TaskInstanceTableAccess.cursorTest(10, 1, CursorId.GOTO_PAGE, condition);
    }
}