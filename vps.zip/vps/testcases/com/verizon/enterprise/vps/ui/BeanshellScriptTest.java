package com.verizon.enterprise.vps.ui;

import java.util.List;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.schedule.ScheduleParser;

import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.common.datalayer.ecp.PendingTaskObject;

public class BeanshellScriptTest {

    public void testAPMPendingTaskExam () throws Exception {
	
	int MAXIMUM_EXECUTING_HOURS = 8;
	String search_condition = "where status = '" + String.valueOf(IVpsTask.EXECUTING) + "'";
	List executingTasks = PendingTaskTable.search (search_condition);
	int size = executingTasks.size();

	PendingTaskObject pendingTaskObject = null;
	JobScheduleDefObject jobScheduleDefObject = null;
	Long jobScheduleDefOid = null;
	String taskInfoXml = null;
	String scheduleInfo = null;
	XmlPersistentTask xpt = null;
	ISchedule schedule = null;
	ScheduleManager sm = new ScheduleManager();
	long executeTime, systemTime;

	for (int i = 0; i< size; i++) {
	    pendingTaskObject = (PendingTaskObject)executingTasks.get(i);
	    executeTime = pendingTaskObject.getExecuteTime().getTime();
	    systemTime = System.currentTimeMillis();

	    //if executing time is longer than 8 hours, cancel it and reschedule it
	    if ((systemTime-executeTime) > 8*60*60*1000) {

		jobScheduleDefOid = pendingTaskObject.getJobScheduleDefOid();
		jobScheduleDefObject = JobScheduleDefTable.retrieve(jobScheduleDefOid);
		sm.unschedulePersistentJob (jobScheduleDefObject, false);

		taskInfoXml = jobScheduleDefObject.getTaskInfo();
		scheduleInfo = jobScheduleDefObject.getScheduleInfo();
		
		xpt = new XmlPersistentTask(taskInfoXml);
		schedule = ScheduleParser.parseSchedule(scheduleInfo);
		schedule.setName(jobScheduleDefObject.getName());
		sm.updatePersistentJob (xpt, schedule, jobScheduleDefObject);
	    }
	}
    }
}
