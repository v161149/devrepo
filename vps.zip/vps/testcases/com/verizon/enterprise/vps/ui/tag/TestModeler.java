package com.verizon.enterprise.vps.ui.tag;

import com.sapient.framework.presentation.servlet.page.*;
import com.sapient.framework.presentation.servlet.event.*;
import java.util.*;
import com.sapient.framework.presentation.servlet.state.*;

import com.verizon.enterprise.common.VerizonStateManager;
import com.verizon.enterprise.common.VerizonModeler;

import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.IVpsInteractiveTask;
import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.OnceSchedule;


/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class TestModeler extends VerizonModeler
{
  public void process(Event event,
                      Map displayObjects,
                      VerizonStateManager stateManager)
      throws java.lang.Exception
  {
    SapientHelper helper = new SapientHelper(stateManager, displayObjects);

    helper.scheduleUIJob("T3", new UITimeoutTest(20));
    helper.scheduleUIJob("T4", new UITimeoutTest(60));
  }
}