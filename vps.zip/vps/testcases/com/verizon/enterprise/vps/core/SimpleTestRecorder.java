package com.verizon.enterprise.vps.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.util.LogHelper;

public class SimpleTestRecorder implements IVpsTask {
  //private static SimpleDateFormat sm_dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
  private List m_qRunTimes = Collections.synchronizedList(new ArrayList());
  private String m_sGlobalKey = null;
  private static HashMap sm_qGlobalCouters = new HashMap();

  /**
   * Constructor
   * 
   * @param sGlobalKey if null, use local one.
   */
  public SimpleTestRecorder(String sGlobalKey) {
    m_sGlobalKey = sGlobalKey != null && sGlobalKey.length() > 0 ? sGlobalKey: null;
  }

  public SimpleTestRecorder() {
    this(null);
  }

  /** Get desc */
  public String getDescription() {
    return "SimpleTestRecorder-" + (m_sGlobalKey == null ? new Integer(m_qRunTimes.size()) : sm_qGlobalCouters.get(m_sGlobalKey));
  }

  /** external run */
  public void externalRun(String sKey) throws Exception {
    m_sGlobalKey = sKey;
    run();
  }

  /** Run impl */
  public void run() throws Exception {
    LogHelper.info("SimpleTestRecorder(" + m_sGlobalKey + ") running in " + Thread.currentThread());
    if (m_sGlobalKey == null) {
      m_qRunTimes.add(new Long(System.currentTimeMillis()));
    } else {
      synchronized (sm_qGlobalCouters) {
        Integer ct = (Integer)sm_qGlobalCouters.get(m_sGlobalKey);
        sm_qGlobalCouters.put(m_sGlobalKey, new Integer(ct == null ? 1 : ct.intValue() + 1));
      }
    }
  }

  /** Reset */
  public void reset() {
    if (m_sGlobalKey == null) {
      m_qRunTimes.clear();
    } else {
      synchronized (sm_qGlobalCouters) {
        sm_qGlobalCouters.put(m_sGlobalKey, new Integer(0));
      }
    }
  }

  /** Get count */
  public int getRunTimeNumber() {
    if (m_sGlobalKey == null) {
      return m_qRunTimes.size();
    } else {
      synchronized (sm_qGlobalCouters) {
        Integer ct = (Integer)sm_qGlobalCouters.get(m_sGlobalKey);
        return ct == null ? 0 : ct.intValue();
      }
    }
  }

  /** Get running time */
  public long getRunTime(int i) {
    Long time = (Long)m_qRunTimes.get(i);
    return time == null ? -1 : time.longValue();
  }
}
