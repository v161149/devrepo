package com.verizon.enterprise.vps.core;

import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.util.LogHelper;

public class TestExecutionTask extends ExecutionTask {
  public ISchedule getSchedule() throws java.lang.Exception {
    return null;
  }

  public IVpsTask getTask() {
    return runnable;
  }

  public void deliver() throws Exception {
    this.setTimestamp(new java.sql.Timestamp(System.currentTimeMillis()));
    super.deliver();
  }

  private long getTime(java.sql.Timestamp time) {
    return time.getTime() + time.getNanos() / 1000000;
  }

  public void execute() {
    long durationMs = System.currentTimeMillis() - getTime(getTimestamp());
    LogHelper.info("TestTaskExecution: task received in " + durationMs + "ms: " + this);
    long timesRan = this.getUserId().longValue();
    average = (average * timesRan + durationMs) / (timesRan + 1);
    this.setUserId(new Long(timesRan + 1));
    long retryCounter = this.getRetryCounter().longValue() - 1;
    if (retryCounter > 0) {
      this.setRetryCounter(new Long(retryCounter));
      try {
        if (delay > 0)
          Thread.sleep(delay * 1000); // in sec
        deliver();
      } catch (Throwable t) {
        LogHelper.logStacktrace(t);
      }
    } else {
      // report average
      LogHelper.info("##### TestTaskExecution: task average takes " + average + "ms: " + this);
    }
  }

  public String toString() {
    return "TestExecutionTask[oid=" + getPendingTaskOid() + ",retry=" + this.getRetryCounter() + "]";
  }

  private double average = 0;
  private long delay = 0;

  public static void testMDB(long oid, long retry) throws Exception {
    testMDB(oid, retry, 0);
  }

  public static void testMDB(long oid, long retry, long delay) throws Exception {
    Long Oid = new Long(oid);
    Long Retry = new Long(retry);
    TestExecutionTask t = new TestExecutionTask();
    t.setPendingTaskOid(Oid);
    t.setJobScheduleDefOid(Oid);
    t.setRetryCounter(Retry);
    t.setUserId(new Long(0));
    t.delay = delay;
    t.deliver();
  }

  public static void main(String[] args) throws Exception {
    // using vzunit to achieve multi-threading behavior
    TestExecutionTask.testMDB(31415921, 1000);
    TestExecutionTask.testMDB(31415922, 1000);
    TestExecutionTask.testMDB(31415923, 1000);
    TestExecutionTask.testMDB(31415924, 1000);
    TestExecutionTask.testMDB(31415925, 1000);
    TestExecutionTask.testMDB(31415926, 1000);
    TestExecutionTask.testMDB(31415927, 1000);
    TestExecutionTask.testMDB(31415928, 1000);
    TestExecutionTask.testMDB(31415929, 1000);
  }

  private static IVpsTask runnable = new IVpsTask() {
    public void run() throws Exception {
      LogHelper.info("TestExecutionMDB running task");
    }

    public String getDescription() {
      return "Test Execution MDB";
    }
  };
}
