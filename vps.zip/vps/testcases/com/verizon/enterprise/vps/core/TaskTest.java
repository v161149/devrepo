package com.verizon.enterprise.vps.core;

import junit.framework.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Hashtable;
import java.lang.reflect.Method;

import com.verizon.kernel.exception.DatalayerException;
import com.verizon.enterprise.vps.util.*;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.dataobjects.TaskParsingException;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.dataobjects.ReflectionTask;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: Test classes in schedule package.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */
public class TaskTest extends TestCase {
    private static Hashtable sm_qResults = new Hashtable();

    public TaskTest() {
    }

    public TaskTest(String s) {
        super(s);
    }

    /**
     * Test XML persistent task
     */
    public void runXmlPersistTask(String sTaskXML) throws Exception {
        XmlPersistentTask xpt = new XmlPersistentTask(sTaskXML);
        xpt.run();
    }

    /**
     * Test XML persistent task.
     * Not thread-safe.
     */
    public void testXmlPersistTask() throws Exception {
        boolean bException;
        String sTaskXML =
            "<invoke class=\"com.verizon.enterprise.vps.core.TaskTest\" method=\"add\">" +
            "<arg>12</arg><arg>23</arg></invoke>";
        XmlPersistentTask xpt = new XmlPersistentTask(sTaskXML);
        xpt.run();
        Assert.assertEquals(new Integer(35), sm_qResults.get("add"));

        sTaskXML =
            "<invoke class=\"com.verizon.enterprise.vps.core.TaskTest\" method=\"sadd\">" +
            "<arg>12</arg><arg>23</arg></invoke>";
        xpt = new XmlPersistentTask(sTaskXML);
        xpt.run();
        Assert.assertEquals(new Integer(36), sm_qResults.get("sadd"));


        bException = false;
        sTaskXML =
            "<invoke class=\"com.verizon.enterprise.vps.core.TaskTest_no\" method=\"add\">" +
            "<arg>12</arg><arg>23</arg></invoke>";
        try {
            xpt = new XmlPersistentTask(sTaskXML);
        }
        catch (TaskParsingException tpe) {
            bException = true;
            System.out.println("Got exception (expected): " + tpe);
        }
        Assert.assertTrue(bException);

        // Test reflection task
        Method method = TaskTest.class.getMethod("add", new Class[]{int.class, int.class});
        Assert.assertNotNull(method);
        ReflectionTask rt = new ReflectionTask(new TaskTest(),
                                               method,
                                               new Object[]{new Integer(22), new Integer(33)});
        rt.run();
        Assert.assertEquals(new Integer(55), sm_qResults.get("add"));


        method = TaskTest.class.getMethod("sadd", new Class[]{int.class, int.class});
        Assert.assertNotNull(method);
        ArrayList qArgs = new ArrayList();
        qArgs.add(new Integer(1));
        qArgs.add(new Integer(2));
        rt = new ReflectionTask(null,
                                method,
                                qArgs);
        rt.run();
        Assert.assertEquals(new Integer(4), sm_qResults.get("sadd"));

    }

    /**
     * Test XML persistent task.
     * Not thread-safe.
     */
    public void testScriptPersistTask() throws Exception {
        // BeanShell
        String sTaskXML =
            "<script language=\"beanshell\">" +
            "import com.verizon.enterprise.vps.core.TaskTest;\n" +
            "TaskTest tt = new TaskTest();\n" +
            "tt.add(1, 34);" +
            "</script>";
        XmlPersistentTask xpt = new XmlPersistentTask(sTaskXML);
        xpt.run();
        Assert.assertEquals(new Integer(35), sm_qResults.get("add"));

        // JavaScript
        sTaskXML =
            "<script language=\"javascript\">" +
            "importClass(Packages.com.verizon.enterprise.vps.core.TaskTest);\n" +
            "var tt = new TaskTest();\n" +
            "tt.sadd(1, 34);" +
            "</script>";
        xpt = new XmlPersistentTask(sTaskXML);
        xpt.run();
        Assert.assertEquals(new Integer(36), sm_qResults.get("sadd"));

        // Error handling
        boolean bPass = false;
        sTaskXML =
            "<script x=\"\">" +
            "importClass(Packages.com.verizon.enterprise.vps.core.TaskTest);\n" +
            "var tt = new TaskTest();\n" +
            "tt.sadd(1, 34);" +
            "</script>";
        try {
            xpt = new XmlPersistentTask(sTaskXML);
        }
        catch (TaskParsingException tpe) {
            bPass = true;
        }

        Assert.assertTrue(bPass);
    }

    // Some test methods
    public void add(int i, int j) {
        sm_qResults.put("add", new Integer(i+j));
    }

    // Some test methods
    public static void sadd(int i, int j) {
        sm_qResults.put("sadd", new Integer(i+j+1));
    }

    // Some test methods
    public void hello(String who) {
        System.out.println(new java.sql.Timestamp(System.currentTimeMillis()) + " - Hello, " + who + "!");
    }

}