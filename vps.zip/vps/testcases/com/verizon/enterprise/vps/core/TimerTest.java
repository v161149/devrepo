/*
 * @(#) TimerTest.java	1.1, 06/23/03
 *
 * Copyright 2003 Verizon Communications, Inc. All rights reserved.
 */

package com.verizon.enterprise.vps.core;

import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.enterprise.vps.schedule.*;

/**
 * test
 *
 * @author  Chunsheng Chen
 * @version 1.1, 06/23/03
 * @since   1.0
 */

public class TimerTest {
    public static final long ONE_SECOND  = 1000;
    public static final long ONE_MINUTE  = 60*ONE_SECOND;
    public static final long ONE_HOUR    = 60*ONE_MINUTE;

    public void test1() throws Exception {
        IVpsTask task1 = new TestTask(1);
        //non-recurrent task executing now
        ISchedule s1 = new OnceSchedule();
//        Dispatcher.submit(task1, s1);
    }

    public void test2() throws Exception {
        IVpsTask task2 = new TestTask(2);
        long now = System.currentTimeMillis();
        //non-recurrent task executing 30 seconds later
        ISchedule s2 = new OnceSchedule(new java.util.Date(now+30*ONE_SECOND));
//        Dispatcher.submit(task2, s2);
    }

    public void test3() throws Exception {
        IVpsTask task3 = new TestTask(3);
        long now = System.currentTimeMillis();
        //recurrent task starts now, recurs every minute for an hour.
        ISchedule s3 = new FixedRateSchedule(ONE_MINUTE/ONE_SECOND);
        s3.setStartEffectiveTime(new java.util.Date(now));
        s3.setEndEffectiveTime(new java.util.Date(now+ONE_HOUR));
//        Dispatcher.submit(task3, s3);
    }

    public void test4() throws Exception
    {
        IVpsTask task4 = new TestTask(4);
        long now = System.currentTimeMillis();
        //recurrent task starts after 2 minutes, recur every minute for an hour.
        ISchedule s4 = new FixedRateSchedule(ONE_MINUTE/ONE_SECOND);
        s4.setStartEffectiveTime(new java.util.Date(now+30*ONE_SECOND));
        s4.setEndEffectiveTime(new java.util.Date(now+ONE_HOUR));

//        Dispatcher.submit(task4, s4);
    }

    public void test() throws Exception {
        test1();
        test2();
        test3();
        test4();
    }

    public static void main(String args) throws Exception
    {
        new TimerTest().test();
    }

    class TestTask
        implements IVpsTask
    {
        private int id;
        public TestTask(int id) {
            this.id = id;
        }
        public void run()
            throws Exception
        {
            //a job that takes 2 minutes to finish
            for (int i = 1; i <= 20; i++)
            {
                Thread.currentThread().sleep(6000);
                LogHelper.info("Task "+id +" finished " + (i*5)+"%");
            }
        }
        public String getDescription() {return "core.TestTask";}
    }
}
