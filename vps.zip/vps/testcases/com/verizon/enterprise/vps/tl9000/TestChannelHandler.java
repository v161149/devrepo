package com.verizon.enterprise.vps.tl9000;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Map;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;

import junit.framework.TestCase;

import com.verizon.enterprise.vps.tl9000.ChannelRegistry;
import com.verizon.enterprise.vps.tl9000.MessageDataUtil;
import com.verizon.kernel.jdbc.ConnectionFactory;

public class TestChannelHandler extends TestCase {

	public void testGetNextMessageBatch() throws Exception {
		Connection conn = ConnectionFactory.getConnection(
			MessageDataConstants.DB_SCHEMA).getConnection();
		conn.setAutoCommit(false);
		Map channelToOid = MessageDataUtil.getNextNewMessageBatch(conn, 2,
			ChannelRegistry.getInstance().getAllChannels());
		System.out.println("sleep for 2 seconds.");
		Thread.sleep(2000L);
		conn.commit();
		conn.close();
		System.out.println("channelToOid: " + channelToOid);
	}

	public void testGetMessage() throws Exception {
		Connection conn = ConnectionFactory.getConnection(
			MessageDataConstants.DB_SCHEMA).getConnection();
		conn.setAutoCommit(false);
		Map channelToOid = MessageDataUtil.getNextNewMessageBatch(conn, 2,
			ChannelRegistry.getInstance().getAllChannels());

		long[] oids = new long[channelToOid.size()];
		int index = 0;
		for (Iterator iter = channelToOid.entrySet().iterator(); iter.hasNext(); index++) {
			Map.Entry entry = (Map.Entry) iter.next();
			Long msgOid = (Long) entry.getKey();
			String channel = (String) entry.getValue();
			System.out.print("\t channel: " + channel);
			System.out.print("\t oid: " + msgOid);
			System.out.println();
			printMessage(MessageDataUtil.getMessage(msgOid.longValue(), null));
			System.out.println(" ****************************************** ");
			oids[index] = msgOid.longValue();
		}
		MessageDataUtil.updateMessageStatus(conn, oids, 'P');
		conn.commit();
		conn.close();
	}

	/**
	 * @throws MessagingException
	 * @throws IOException
	 */
	private void printMessage(MimeMessage localMessage)
			throws MessagingException, IOException {
		Address[] recipients = localMessage.getAllRecipients();
		StringBuffer addressBuffer = new StringBuffer();
		for (int i = 0; i < recipients.length; i++) {
			if (i != 0) {
				addressBuffer.append(',');
			}
			addressBuffer
					.append(((InternetAddress) recipients[i]).getAddress());
		}
		final String toAddress = addressBuffer.toString();
		final String subject = localMessage.getSubject();
		final Timestamp sentDate = new Timestamp(localMessage.getSentDate()
				.getTime());

		Part msgPart = null;

		System.out.println("localMessage contentType:       "
				+ localMessage.getContentType());
		if (localMessage.getContent() instanceof Multipart) {
			Object multipartContent = localMessage.getContent();

			BodyPart firstBodyPart;
			do {
				// catch the case where content type is "multipart/alternative;"
				firstBodyPart = ((Multipart) multipartContent).getBodyPart(0);
				System.out.println("firstBodyPart contentType:       "
						+ firstBodyPart.getContentType());
				if (firstBodyPart instanceof MimeBodyPart) {
					multipartContent = ((MimeBodyPart) firstBodyPart)
							.getContent();
				}
				else {
					break;
				}
			} while (multipartContent instanceof Multipart);
			msgPart = firstBodyPart;
		}
		else {
			msgPart = localMessage;
		}

		// create a 4k charactor buffer for read in the inputstream
		char[] fourKBuffer = new char[4096];
		StringBuffer contentBuffer = new StringBuffer();
		if (msgPart.getContentType().startsWith("text/plain")
				|| msgPart.getContentType().startsWith("text/html")) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					msgPart.getInputStream()));
			int numCharRead = 0;
			for (numCharRead = reader.read(fourKBuffer, 0, 4096); numCharRead != -1; numCharRead = reader
					.read(fourKBuffer, 0, 4096)) {
				contentBuffer.append(fourKBuffer, 0, numCharRead);
			}
		}
		final String msgContent = contentBuffer.toString();

		System.out.println("to:       " + toAddress);
		System.out.println("subject:  " + subject);
		System.out.println("sent:     " + sentDate);
		System.out.println("content:  " + msgContent);
	}
}
