package com.verizon.enterprise.vps.db;

import junit.framework.*;

import com.verizon.common.datalayer.ecp.JetsScriptObject;
import org.apache.log4j.Logger;

public class TestScriptDatalayer
{
    private ScriptDatalayer scriptDatalayer = null;
    private static Logger log = Logger.getLogger(TestScriptDatalayer.class);

    public TestScriptDatalayer()
    {
        scriptDatalayer = new ScriptDatalayer();
    }

    public void getScript(String name) throws Exception
    {
        JetsScriptObject script = scriptDatalayer.getJetsScript(name);
        log.info("script = " + script);
        Assert.assertNotNull("No script with name " + name, script);
    }
}
