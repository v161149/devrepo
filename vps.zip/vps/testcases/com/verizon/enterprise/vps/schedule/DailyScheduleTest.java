/*
 * @(#)DailyScheduleTest.java   1.0     Feb 7, 2008
 *
 * Copyright 2007 Verizon eBusiness, Inc. All rights reserved.
 * VERIZON PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.verizon.enterprise.vps.schedule;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * This class ...
 *
 * @author Hong-qi Jia
 * @version 1.0    Feb 7, 2008
 */
public class DailyScheduleTest {

  /**
   * @param args
   */
  public static void main(String[] args) {
    String scStr = "DAILY|00:10:00";
    try {
      DailySchedule ds = (DailySchedule)ScheduleParser.parseSchedule(scStr);
      ds.parse(scStr);
      //Date t = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z").parse("2007-11-05 00:10:00 EST");
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      Date t = sdf.parse("2007-12-31 00:10:00");
      long l = t.getTime();
      //System.out.print("After add up: " + c.setTime(t).add(Calendar.DAY_OF_YEAR, 1));
      System.out.println("Old Next scheduled time:" + ds.getTimeForNextSchedule(t));
      System.out.println("New Next scheduled time:" + getNextAvailableDay(l));     
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  private static final Date getNextAvailableDay(long nCurrentTime) {
    Calendar c = Calendar.getInstance();
    c.setTimeInMillis(nCurrentTime);
    c.add(Calendar.DAY_OF_YEAR, 1);
    return c.getTime();
  }
}
