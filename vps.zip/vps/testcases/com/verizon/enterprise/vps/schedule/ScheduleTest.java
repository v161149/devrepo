package com.verizon.enterprise.vps.schedule;

import junit.framework.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

import com.verizon.kernel.exception.DatalayerException;
import com.verizon.enterprise.vps.util.*;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: Test classes in schedule package.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */
public class ScheduleTest extends TestCase {
    public static final int DAY_TIME_SAVE_OFFSET = 3600;

    public ScheduleTest() {
    }
    public ScheduleTest(String s) {
        super(s);
    }

    /** test schedule calculation */
    public void testScheduleCalculation() throws Exception {
        testFixedRateSchedule();
        testOnceSchedule();
        testDailySchedule();
        testWeeklySchedule();
        testMonthlySchedule2();
    }

    /** test schedule parsing */
    public void testScheduleParser() throws Exception {
        Date schTime;
        long now;
        boolean bException;

        try {
            bException = false;
            ScheduleParser.parseSchedule("NOTHING");
        }
        catch (Exception ex) {bException = true;}
        Assert.assertTrue(bException);

        // Fixed rate
        FixedRateSchedule frs = (FixedRateSchedule)ScheduleParser.parseSchedule("FIXED_RATE|1800");
        now = System.currentTimeMillis();
        schTime = frs.getTimeForNextSchedule();
        Assert.assertEquals(0.0, (now+1800*1000-schTime.getTime())/1000.0, 0.01);
        Assert.assertEquals("FIXED_RATE|1800", frs.getScheduleInfoString());

        // Failures
        try {
            frs = (FixedRateSchedule)ScheduleParser.parseSchedule("FIXED_RATE|0");
            Assert.fail();
        }
        catch (VpsScheduleException vse) {
            Assert.assertEquals(VpsScheduleException.INVALID_FIX_RATE_INTERVAL, vse.getErrorCode());
        }

        try {
            bException = false;
            ScheduleParser.parseSchedule("FIXED_RATE");
        }
        catch (Exception ex) {bException = true;}
        Assert.assertTrue(bException);

        try {
            bException = false;
            ScheduleParser.parseSchedule("FIXED_RATE|abc");
        }
        catch (Exception ex) {bException = true;}
        Assert.assertTrue(bException);

        // Once
        // Right away
        OnceSchedule os = (OnceSchedule)ScheduleParser.parseSchedule("ONCE");
        now = System.currentTimeMillis();
        schTime = os.getTimeForNextSchedule();
        Assert.assertEquals(0.0, (schTime.getTime()-now)/1000.0, 0.05);
        Assert.assertEquals("ONCE", os.getScheduleInfoString());

        // One specific time
        os = (OnceSchedule)ScheduleParser.parseSchedule("ONCE|2010-12-31 15:30:45");
        schTime = os.getTimeForNextSchedule();
        Assert.assertEquals("2010-12-31 15:30:45", ISchedule.DATE_FORMAT.format(schTime));
        Assert.assertEquals("ONCE|2010-12-31 15:30:45", os.getScheduleInfoString());

        try {
            bException = false;
            ScheduleParser.parseSchedule("ONCE|2/3/2002 3:4");
        }
        catch (Exception ex) {bException = true;}
        Assert.assertTrue(bException);

        // Daily
        DailySchedule ds = (DailySchedule)ScheduleParser.parseSchedule("DAILY|02:20:35");
        Calendar cal = ds.getDailyTime();
        Assert.assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(20, cal.get(Calendar.MINUTE));
        Assert.assertEquals(35, cal.get(Calendar.SECOND));

        schTime = ds.getTimeForNextSchedule();
        Calendar result = Calendar.getInstance();
        result.add(Calendar.DATE, 1);
        result.set(Calendar.HOUR_OF_DAY, 2);
        result.set(Calendar.MINUTE, 20);
        result.set(Calendar.SECOND, 35);
        Assert.assertEquals(0.0, (result.getTime().getTime()-schTime.getTime())/1000.0, 1);
//        System.out.println("Schedule info: " + ds.getScheduleInfoString());
        Assert.assertEquals("DAILY|02:20:35", ds.getScheduleInfoString());

        // Weekly
        WeeklySchedule ws = (WeeklySchedule)ScheduleParser.parseSchedule("WEEKLY|SUN|15:45:21");
        cal = ws.getDailyTime();
        Assert.assertNotNull(cal);
        Assert.assertEquals(15, cal.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(45, cal.get(Calendar.MINUTE));
        Assert.assertEquals(21, cal.get(Calendar.SECOND));

        schTime = ws.getTimeForNextSchedule();
        result = Calendar.getInstance();
        while (result.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            result.add(Calendar.DATE, 1);
        }
        result.set(Calendar.HOUR_OF_DAY, 15);
        result.set(Calendar.MINUTE, 45);
        result.set(Calendar.SECOND, 21);
        Assert.assertEquals(0.0, (result.getTime().getTime()-schTime.getTime())/1000.0, 1);
        Assert.assertEquals("WEEKLY|SUN|15:45:21", ws.getScheduleInfoString());

        try {
            bException = false;
            ScheduleParser.parseSchedule("WEEKLY|abc|2:2:2");
        }
        catch (Exception ex) {bException = true;}
        Assert.assertTrue(bException);

    }

    /** Test fix rate */
    public void testFixedRateSchedule() throws Exception {
        Date schTime;
        // Fixed rate
        FixedRateSchedule frs = new FixedRateSchedule(1234);
        Assert.assertEquals(1234, (frs.getTimeForNextSchedule().getTime()-System.currentTimeMillis())/1000.0, 0.1);
        frs.setStartEffectiveTime(new Date(System.currentTimeMillis()-3333000));
        frs.setEndEffectiveTime(new Date(System.currentTimeMillis()+3333000));
        Assert.assertEquals(1234, (frs.getTimeForNextSchedule().getTime()-System.currentTimeMillis())/1000);

        frs.setStartEffectiveTime(new Date(System.currentTimeMillis()+3334000));
        Assert.assertNull(frs.getTimeForNextSchedule());
        frs.setStartEffectiveTime(null);
        Assert.assertEquals(1234, (frs.getTimeForNextSchedule().getTime()-System.currentTimeMillis())/1000);

        frs.setEndEffectiveTime(new Date(System.currentTimeMillis()+1111000));
        Assert.assertNull(frs.getTimeForNextSchedule());
        frs.setEndEffectiveTime(null);
        Assert.assertEquals(1234, (frs.getTimeForNextSchedule().getTime()-System.currentTimeMillis())/1000);

        // For the future
        frs = new FixedRateSchedule(2*60);
        frs.setStartEffectiveTime(ISchedule.DATE_FORMAT.parse("2025-12-01 00:00:00"));
        frs.setEndEffectiveTime(ISchedule.DATE_FORMAT.parse("2025-12-02 00:00:00"));
        schTime = frs.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        Assert.assertEquals("2025-12-01 00:02:00", ISchedule.DATE_FORMAT.format(frs.getTimeForNextSchedule()));

    }

    /** Test fixed rate */
    public void testFixRateSchedule2() throws Exception {
        // Fixed rate
        FixedRateSchedule frs = new FixedRateSchedule(1);
        long now = System.currentTimeMillis();
        frs.setEndEffectiveTime(new Date(now+3500));

        for (int i=1; i<=3; i++) {
            Assert.assertEquals(1.0,
                                (frs.getTimeForNextSchedule().getTime()-now)/1000.0/i, 0.1);
            Thread.sleep(1000);
        }

        Assert.assertNull(frs.getTimeForNextSchedule());
    }

    /** Test once */
    public void testOnceSchedule() throws Exception {
        Date schTime;

        // Once
        OnceSchedule once = new OnceSchedule(ISchedule.DATE_FORMAT.parse("2002-05-24 15:30:45"));
        Assert.assertNull(once.getTimeForNextSchedule());

        once = new OnceSchedule(ISchedule.DATE_FORMAT.parse("2010-05-24 15:30:45"));
        schTime = once.getTimeForNextSchedule();
        Assert.assertEquals(ISchedule.DATE_FORMAT.format(schTime), "2010-05-24 15:30:45");

        // Start right away
        long now = System.currentTimeMillis();
        once = new OnceSchedule();
        schTime = once.getTimeForNextSchedule();
        Assert.assertEquals(0, (schTime.getTime()-now)/100.0, 0.5);
    }

    /** Test daily */
    public void testDailySchedule() throws Exception {
        Date schTime;

        // Daily
        Calendar cal = Calendar.getInstance();
        Calendar now = Calendar.getInstance();

        // later today
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, 1);
        cal.add(Calendar.MINUTE, 12);
        cal.add(Calendar.SECOND, 45);
        DailySchedule daily = new DailySchedule(cal);
        schTime = daily.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        Assert.assertEquals(0, 1*3600+12*60+45 - (schTime.getTime()-System.currentTimeMillis())/1000.0, 0.5);

        // tomorrow
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, -1);
        daily = new DailySchedule(cal);
        schTime = daily.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        Assert.assertEquals(0, 23*3600 - (schTime.getTime()-System.currentTimeMillis())/1000.0, 0.5);

        // empty
        daily.setEndEffectiveTime(new Date(System.currentTimeMillis()+1000));
        Assert.assertNull(daily.getTimeForNextSchedule());

        // future day: 5day + 1hour
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, 2);
        daily.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*5));
        daily.setEndEffectiveTime(new Date(System.currentTimeMillis()+1000));
        schTime = daily.getTimeForNextSchedule();
        Assert.assertNull(schTime);

        daily.setEndEffectiveTime(null);
        schTime = daily.getTimeForNextSchedule();
//        System.out.println("Scheduled time = " + schTime);
        Assert.assertNotNull(schTime);
        Assert.assertEquals(
            0,
            (schTime.getTime()-System.currentTimeMillis())/1000.0 - (5*ISchedule.MS_FOR_DAY + 2*ISchedule.MS_FOR_HOUR)/1000.,
            DAY_TIME_SAVE_OFFSET+.5);

        // future date: 5day - 1hour -> 6day - 1hour
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, -2);
        daily.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*5));
        daily.setEndEffectiveTime(null);
        schTime = daily.getTimeForNextSchedule();
//        System.out.println("Scheduled time = " + schTime);
        Assert.assertNotNull(schTime);
        Assert.assertEquals(
            0,
            (schTime.getTime()-System.currentTimeMillis())/1000.0 - (6*ISchedule.MS_FOR_DAY - 2*ISchedule.MS_FOR_HOUR)/1000.,
            DAY_TIME_SAVE_OFFSET+.5);

        // Go further
        Date nextTime = daily.getTimeForNextSchedule(schTime);
        Assert.assertEquals(0, (nextTime.getTime()-schTime.getTime()-ISchedule.MS_FOR_DAY)/1000.0, 0.5);

        schTime = nextTime;
        nextTime = daily.getTimeForNextSchedule(schTime);
        Assert.assertEquals(0, (nextTime.getTime()-schTime.getTime()-ISchedule.MS_FOR_DAY)/1000.0, 0.5);
    }

    /** Test weekly */
    public void testWeeklySchedule() throws Exception {
        Date schTime;

        // Daily
        Calendar cal = Calendar.getInstance();
        Calendar now = Calendar.getInstance();
        Calendar result = Calendar.getInstance();

        // Today
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, 1);
        cal.add(Calendar.MINUTE, 12);
        WeeklySchedule weekly = new WeeklySchedule(cal, cal.get(Calendar.DAY_OF_WEEK));
        schTime = weekly.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        result.setTime(schTime);
        Assert.assertTrue(result.equals(cal));

        // this week
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, 1);
        cal.add(Calendar.MINUTE, 12);
        weekly = new WeeklySchedule(cal, Calendar.SATURDAY);
        schTime = weekly.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        result.setTime(schTime);
        Assert.assertTrue(result.after(cal));
        cal.add(Calendar.DATE, 7);
        Assert.assertTrue(result.before(cal));

        Assert.assertEquals(Calendar.SATURDAY, result.get(Calendar.DAY_OF_WEEK));
        Assert.assertEquals(cal.get(Calendar.HOUR_OF_DAY), result.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(cal.get(Calendar.MINUTE), result.get(Calendar.MINUTE));

        // next week
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, -1);
        weekly = new WeeklySchedule(cal, cal.get(Calendar.DAY_OF_WEEK));
        schTime = weekly.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        result.setTime(schTime);
//System.out.println("result time: " + schTime);
        Assert.assertEquals(
            0,
            (schTime.getTime()-System.currentTimeMillis())/1000.0 - (7*ISchedule.MS_FOR_DAY - ISchedule.MS_FOR_HOUR)/1000.,
            DAY_TIME_SAVE_OFFSET+.5);

        Assert.assertEquals(cal.get(Calendar.DAY_OF_WEEK), result.get(Calendar.DAY_OF_WEEK));
        Assert.assertEquals(cal.get(Calendar.HOUR_OF_DAY), result.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(cal.get(Calendar.MINUTE), result.get(Calendar.MINUTE));

        // empty
        weekly.setEndEffectiveTime(new Date(System.currentTimeMillis()+1000));
        Assert.assertNull(weekly.getTimeForNextSchedule());

        // future day: 2wks + 1hour
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, 1);
        weekly = new WeeklySchedule(cal, cal.get(Calendar.DAY_OF_WEEK));
        weekly.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*10));
        weekly.setEndEffectiveTime(new Date(System.currentTimeMillis()+1000));
        schTime = weekly.getTimeForNextSchedule();
        Assert.assertNull(schTime);

        weekly.setEndEffectiveTime(null);
        schTime = weekly.getTimeForNextSchedule();
//        System.out.println("Scheduled time = " + schTime);
        Assert.assertNotNull(schTime);
        Assert.assertEquals(
            0,
            (schTime.getTime()-System.currentTimeMillis())/1000.0 - (14*ISchedule.MS_FOR_DAY + ISchedule.MS_FOR_HOUR)/1000.,
            DAY_TIME_SAVE_OFFSET+.5);

        // future date: 5day - 1hour -> 1wk - 1hour
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, -1);
        weekly.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*5));
        weekly.setEndEffectiveTime(null);
        schTime = weekly.getTimeForNextSchedule();
//        System.out.println("Scheduled time = " + schTime);
        Assert.assertNotNull(schTime);
        Assert.assertEquals(
            0,
            (schTime.getTime()-System.currentTimeMillis())/1000.0 - (7*ISchedule.MS_FOR_DAY - ISchedule.MS_FOR_HOUR)/1000.,
            DAY_TIME_SAVE_OFFSET + .5);

        // future date: 7day - 1hour -> 2wk - 1hour
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, -2);
        weekly.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*7));
        weekly.setEndEffectiveTime(null);
        schTime = weekly.getTimeForNextSchedule();
//        System.out.println("Scheduled time = " + schTime);
        Assert.assertNotNull(schTime);
        Assert.assertEquals(
            0,
            (schTime.getTime()-System.currentTimeMillis())/1000.0 - (14*ISchedule.MS_FOR_DAY - 2*ISchedule.MS_FOR_HOUR)/1000.,
            DAY_TIME_SAVE_OFFSET + .5);

        // Go further
        Date nextTime = weekly.getTimeForNextSchedule(schTime);
        // For day time saving issue, let's be more tolerant.
        Assert.assertEquals(0, (nextTime.getTime()-schTime.getTime()-ISchedule.MS_FOR_DAY*7)/1000.0, DAY_TIME_SAVE_OFFSET+.5);

        schTime = nextTime;
        nextTime = weekly.getTimeForNextSchedule((Date)schTime.clone());
        Assert.assertEquals(0, (nextTime.getTime()-schTime.getTime()-ISchedule.MS_FOR_DAY*7)/1000.0, DAY_TIME_SAVE_OFFSET+.5);
    }

    public void testMonthlySchedule() throws Exception {
        Date schTime;

        // Daily
        Calendar cal = Calendar.getInstance();
        Calendar result = Calendar.getInstance();

        // Today
        cal.add(Calendar.DATE,18);
        System.out.println(cal.getTime().toString());
        MonthlyScheduleByWeekday mn = new MonthlyScheduleByWeekday(cal, Calendar.SATURDAY, 1, 2);
        schTime = mn.getTimeForNextSchedule(cal.getTime());
        Assert.assertNotNull(schTime);
        System.out.println(schTime.toString());

        MonthlyScheduleByWeekday ms = (MonthlyScheduleByWeekday)ScheduleParser.parseSchedule("MON_N_WD|1|2|SUN|15:45:21");
        cal = ms.getDailyTime();
        Assert.assertNotNull(cal);
        Assert.assertEquals(15, cal.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(45, cal.get(Calendar.MINUTE));
        Assert.assertEquals(21, cal.get(Calendar.SECOND));

        schTime = ms.getTimeForNextSchedule();
        result = Calendar.getInstance();
        result.add(Calendar.DATE,8);
        while (result.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
            result.add(Calendar.DATE, 1);
        }
        result.set(Calendar.HOUR_OF_DAY, 15);
        result.set(Calendar.MINUTE, 45);
        result.set(Calendar.SECOND, 21);
        Assert.assertEquals(0.0, (result.getTime().getTime()-schTime.getTime())/1000.0, 1);
        Assert.assertEquals("MON_N_WD|1|2|SUN|15:45:21", ms.getScheduleInfoString());

        ms.setEndEffectiveTime(new Date(System.currentTimeMillis()+1000));
        Assert.assertNull(ms.getTimeForNextSchedule());

        ms.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*7));
        ms.setEndEffectiveTime(null);
        Assert.assertNotNull(ms.getTimeForNextSchedule());
    }

    /**
     * Test by Zhong
     * @throws Exception
     */
    public void testMonthlySchedule2() throws Exception {
        Date schTime;
        int nWeekIndex;

        // Daily
        Calendar cal = Calendar.getInstance();
        Calendar result = Calendar.getInstance();

        // Later this month.
        String sInfo = "MONTHLY_NTH_WEEKDAY|4|0|SAT|12:34:56";
        MonthlyScheduleByWeekday ms = (MonthlyScheduleByWeekday)ScheduleParser.parseSchedule(sInfo);
        Assert.assertEquals(sInfo, ms.getScheduleInfoString());
        System.out.println("Monthly schedule: " + ms);
        schTime = ms.getTimeForNextSchedule();
        Assert.assertNotNull(schTime);
        /* This test is actually sensitive to running time
        result = Calendar.getInstance();
        result.set(Calendar.DAY_OF_MONTH, 1);
        for (nWeekIndex=0; nWeekIndex < 4; ) {
            if (result.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
                nWeekIndex++;
            }

            if (nWeekIndex < 4) {
                result.add(Calendar.DATE, 1);
            }
        }
        result.set(Calendar.HOUR_OF_DAY, 12);
        result.set(Calendar.MINUTE, 34);
        result.set(Calendar.SECOND, 56);
        System.out.println("Schedule: " + schTime);
        System.out.println("Expected: " + result.getTime());
        Assert.assertEquals(0.0, (result.getTime().getTime()-schTime.getTime())/1000.0, 1);
*/
        // Move to 5 month away
        cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, 5);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        ms.setStartEffectiveTime(cal.getTime());
        schTime = ms.getTimeForNextSchedule();

        result.set(Calendar.YEAR, cal.get(Calendar.YEAR));
        result.set(Calendar.MONTH, cal.get(Calendar.MONTH));
        result.set(Calendar.DAY_OF_MONTH, 1);
        result.set(Calendar.HOUR_OF_DAY, 12);
        result.set(Calendar.MINUTE, 34);
        result.set(Calendar.SECOND, 56);
        for (nWeekIndex=0; nWeekIndex < 4; ) {
            if (result.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
                nWeekIndex++;
            }

            if (nWeekIndex < 4) {
                result.add(Calendar.DATE, 1);
            }
        }

        System.out.println("Schedule: " + schTime);
        System.out.println("Expected: " + result.getTime());
        Assert.assertEquals(0.0, (result.getTime().getTime()-schTime.getTime())/1000.0, 1);

    }

    /**
     * Display schedule.
     */
    public void displaySchedule(String sScheduleInfo,
                                String sExpected) throws Exception {
        ISchedule schedule = ScheduleParser.parseSchedule(sScheduleInfo);
        Assert.assertEquals(sScheduleInfo, schedule.getScheduleInfoString());
        System.out.println("Expected:" + sExpected + ", was:" + schedule.toString());
        Assert.assertEquals(sExpected, schedule.toString());
    }

    /**
     * Get next schedule
     */
    public void getNextSchedule(String sScheduleInfo,
                                String sNow,
                                String sStartEffective,
                                String sEndEffective,
                                String sExpected) throws Exception {
        // Parse schedule
        ISchedule schedule = ScheduleParser.parseSchedule(sScheduleInfo);
        Assert.assertNotNull(schedule);

        // Convert inputs
        Date startEffective = null, endEffective = null, expected = null, now = null;
        if (sNow != null && sNow.length() > 0) {
            now = AbstractSchedule.DATE_FORMAT.parse(sNow);
        }
        if (sStartEffective != null && sStartEffective.length() > 0) {
            startEffective = AbstractSchedule.DATE_FORMAT.parse(sStartEffective);
        }
        if (sEndEffective != null && sEndEffective.length() > 0) {
            endEffective = AbstractSchedule.DATE_FORMAT.parse(sEndEffective);
        }
        if (sExpected != null && sExpected.length() > 0) {
            expected = AbstractSchedule.DATE_FORMAT.parse(sExpected);
        }

        // Get schedule
        Date schTime;
        schedule.setStartEffectiveTime(startEffective);
        schedule.setEndEffectiveTime(endEffective);
        if (now != null) {
            schTime = schedule.getTimeForNextSchedule(now);
        }
        else {
            schTime = schedule.getTimeForNextSchedule();
        }

        // Verify
        if (true) {
            System.out.println("Schedule info   :" + sScheduleInfo);
            System.out.println("Current time    :" + sNow);
            System.out.println("Effective start :" + sStartEffective);
            System.out.println("Effective end   :" + sEndEffective);
            System.out.println("Schedule result :" + schTime);
            System.out.println("Expect   result :" + expected);
        }

        Assert.assertTrue(expected==null ? schTime==null : schTime!=null);
        if((schTime != null) && (expected != null))
          Assert.assertEquals(0.0, (schTime.getTime()-expected.getTime())/1000.0, 1);
    }

    /** Test monthly schedule. */
    public void testMonthlyScheduleByDate() throws Exception
    {
      Date schTime;

      // Daily
      Calendar cal = Calendar.getInstance();
      Calendar result = Calendar.getInstance();

      // Today
      cal.add(Calendar.DATE,-2);
      //System.out.println(cal.getTime().toString());
      MonthlyScheduleByDate mn = new MonthlyScheduleByDate(cal);
      schTime = mn.getTimeForNextSchedule(cal.getTime());
      Assert.assertNotNull(schTime);
      //System.out.println(schTime.toString());
      getNextSchedule("MONTHLY_NTH_DAY|3|21:45:21","2003-07-09 11:45:21",null,null,"2003-08-03 21:45:21");
      getNextSchedule("MONTHLY_NTH_DAY|31|21:45:21","2003-07-09 11:45:21","2003-09-09 15:26:21",null,"2003-10-31 21:45:21");

      MonthlyScheduleByDate ms = (MonthlyScheduleByDate)ScheduleParser.parseSchedule("MONTHLY_NTH_DAY|3|21:45:21");
      ms.setEndEffectiveTime(new Date(System.currentTimeMillis()+1000));
      Assert.assertNull(ms.getTimeForNextSchedule());

      ms.setStartEffectiveTime(new Date(System.currentTimeMillis()+ISchedule.MS_FOR_DAY*7));
      ms.setEndEffectiveTime(null);
      Assert.assertNotNull(ms.getTimeForNextSchedule());

      getNextSchedule("MONTHLY_NTH_DAY|-2|21:45:21","2003-07-09 11:45:21","2003-08-09 11:45:21",null,"2003-08-30 21:45:21");
      getNextSchedule("MONTHLY_NTH_DAY|-2|21:45:21","2003-07-09 11:45:21","2003-08-09 11:45:21","2003-08-30 12:45:21",null);
  }

  /** Test getResource */
  public void getResourceAsStream(String sFile) throws Exception {
      Assert.assertNotNull(ClassLoader.getSystemResourceAsStream(sFile));
  }
}