package com.verizon.enterprise.vps.schedule;

import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.apache.cactus.ServletTestCase;
import org.apache.log4j.Logger;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;
import com.verizon.enterprise.vps.core.SimpleTestRecorder;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.middleware.ScheduleBeanTest;
import com.verizon.enterprise.vps.util.LogHelper;

/**
 * <p>Title: Virtual Process Service</p> <p>Description: Test classes on
 * server side by cactus.</p> <p>Copyright: Copyright (c) 2003</p> <p>Company:
 * Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */
public class ScheduleManagerTest extends ServletTestCase {
  private static final Logger __Logger = Logger.getLogger(ScheduleManagerTest.class);
  public static final Long TEST_UID = new Long(123);

  public ScheduleManagerTest(String s) {
    super(s);
  }

  /**
   * Test in memory dispatcher.
   */
  public void testInMemoryDispatcher(int INTERVAL, double TOLERANCE) throws Exception {
    int i;
    ScheduleManager sm = new ScheduleManager();

    // Error handling
    sm.scheduleTransientJob(new IVpsTask() {
      public void run() {
        LogHelper.info("Runtime exception thrown in " + Thread.currentThread());
        Object o = null;
        // runtime exception
        o.toString();
      }

      public String getDescription() {
        return "testDispatcherRuntimeEx";
      }
    }, new OnceSchedule());

    // Exception handling.
    sm.scheduleTransientJob(new IVpsTask() {
      public void run() throws Exception {
        LogHelper.info("Application exception thrown in " + Thread.currentThread());
        throw new java.io.IOException("Test.");
      }

      public String getDescription() {
        return "testDispatcherAppEx";
      }
    }, new OnceSchedule());

    // Run once
    SimpleTestRecorder str = new SimpleTestRecorder();
    sm.scheduleTransientJob(str, new OnceSchedule());
    Thread.sleep((long)(2000 * (1 + TOLERANCE)));
    Assert.assertEquals(1, str.getRunTimeNumber());

    // Run continuously
    str = new SimpleTestRecorder();
    ISchedule schedule = new FixedRateSchedule(INTERVAL);
    long now = System.currentTimeMillis();
    // Round up to whole second point
    Thread.sleep(now % 1000);
    now = System.currentTimeMillis();
    // __Logger.info("Schedule now time: " + new Date(now));
    schedule.setEndEffectiveTime(new Date(now + (long)(INTERVAL * 3500)));
    sm.scheduleTransientJob(str, schedule);
    Thread.sleep(INTERVAL * 4500);
    Assert.assertEquals(3, str.getRunTimeNumber());

    long nLastTime = 0, nThisTime;
    for (i = 0; i < 3; i++) {
      nThisTime = str.getRunTime(i);
      if (i > 0) {
        Assert.assertEquals(INTERVAL, (nThisTime - nLastTime) / 1000.0, TOLERANCE);
      }
      nLastTime = nThisTime;
    }
  }

  /**
   * Test persistent dispatcher - create Contacted VPS has to enable persistent
   * scheduling.
   */
  public void testCreatePersistentSchedule() throws Exception {
    final int TEST_TIME_INTERVAL = 10;
    // Get server manager
    //ScheduleBeanTest adminTest = new ScheduleBeanTest();
    ScheduleManager sm = new ScheduleManager();
    sm.setUserId(TEST_UID);

    String sName = Thread.currentThread().getName();
    if (sName.length() > 30)
      sName = sName.substring(sName.length() - 30);

    ISchedule schedule = new FixedRateSchedule(TEST_TIME_INTERVAL);
    schedule.setName("tc(" + (sName + ((int)(Math.random() * 100))));

    SimpleTestRecorder verifier = new SimpleTestRecorder(schedule.getName());
    verifier.reset();

    // Create a schedule
    XmlPersistentTask xpt = new XmlPersistentTask("<invoke class=\"com.verizon.enterprise.vps.core.SimpleTestRecorder\" method=\"externalRun\">" + "<arg>"
        + schedule.getName() + "</arg></invoke>");

    JobScheduleDefObject jobDef = sm.schedulePersistentJob(xpt, schedule);
    Assert.assertNotNull(jobDef);
    Assert.assertTrue(jobDef.getJobScheduleDefOid().longValue() > 0);
    __Logger.info("New schedule definition created with oid " + jobDef.getJobScheduleDefOid());

    int i = 0;
    boolean bOK = false;
    try {
      // 6 seconds tolerance
      Thread.sleep(6000);
      while (++i <= 5) {
        Thread.sleep(TEST_TIME_INTERVAL * 1000);
        __Logger.info("verifier.getRunTimeNumber()=" + verifier.getRunTimeNumber());
        //Assert.assertEquals(i, verifier.getRunTimeNumber());
      }

      bOK = true;
    } finally {
      // Cancel it and it should stop immediately.
      sm.unschedulePersistentJob(jobDef, true);
      __Logger.info("Schedule definition removed with oid " + jobDef.getJobScheduleDefOid());

      if (bOK) {
        Thread.sleep(5000);
        Assert.assertEquals(5, verifier.getRunTimeNumber());
        Thread.sleep(TEST_TIME_INTERVAL * 1000);
        Assert.assertEquals(5, verifier.getRunTimeNumber());
      }
    }
  }

  /**
   * Test persistent dispatcher - update Contacted VPS has to enable persistent
   * scheduling.
   */
  public void testUpdatePersistentSchedule() throws Exception {
    final int TEST_TIME_INTERVAL = 10;
    // Get server bean
    ScheduleBeanTest adminTest = new ScheduleBeanTest();
    ScheduleManager sm = new ScheduleManager();
    sm.setUserId(TEST_UID);

    String sName = Thread.currentThread().getName();
    if (sName.length() > 30)
      sName = sName.substring(sName.length() - 30);

    FixedRateSchedule schedule = new FixedRateSchedule(TEST_TIME_INTERVAL);
    schedule.setName("tu(" + (sName + ((int)(Math.random() * 1000))));

    SimpleTestRecorder verifier = new SimpleTestRecorder(schedule.getName());
    verifier.reset();

    // Create a schedule
    XmlPersistentTask xpt = new XmlPersistentTask("<invoke class=\"com.verizon.enterprise.vps.core.SimpleTestRecorder\" method=\"externalRun\">" + "<arg>"
        + schedule.getName() + "</arg></invoke>");

    JobScheduleDefObject jobDef = sm.schedulePersistentJob(xpt, schedule);
    Assert.assertNotNull(jobDef);
    Assert.assertTrue(jobDef.getJobScheduleDefOid().longValue() > 0);
    LogHelper.info("New schedule definition created with oid " + jobDef.getJobScheduleDefOid());

    int i = 0;
    boolean bOK = false;
    try {
      Thread.sleep(1000 * TEST_TIME_INTERVAL / 2);
      while (++i <= 1) {
        Thread.sleep(TEST_TIME_INTERVAL * 1000);
        Assert.assertEquals(i, verifier.getRunTimeNumber());
      }

      // recover one
      i--;

      // update
      schedule.setInternalInSeconds(5);
      LogHelper.info("Before schedule update with oid " + jobDef.getJobScheduleDefOid());
      sm.updatePersistentJob(xpt, schedule, jobDef);
      LogHelper.info("After schedule update with oid " + jobDef.getJobScheduleDefOid());
      Thread.sleep(2000);
      while (++i <= 5) {
        Thread.sleep(5000);
        Assert.assertEquals(i, verifier.getRunTimeNumber());
      }

      bOK = true;
    } finally {
      // Cancel it and it should stop immediately.
      sm.unschedulePersistentJob(jobDef, true);
      __Logger.info("Schedule definition removed with oid " + jobDef.getJobScheduleDefOid());

      if (bOK) {
        Thread.sleep(5000);
        Assert.assertEquals(5, verifier.getRunTimeNumber());
        Thread.sleep(TEST_TIME_INTERVAL * 1000);
        Assert.assertEquals(5, verifier.getRunTimeNumber());
      }
    }
  }

  /**
   * Test persistent dispatcher - update Contacted VPS has to enable persistent
   * scheduling.
   */
  public void testUpdateExpiredSchedule() throws Exception {
    final int TEST_TIME_INTERVAL = 10;
    // Get server bean
    ScheduleBeanTest adminTest = new ScheduleBeanTest();
    ScheduleManager sm = new ScheduleManager();
    sm.setUserId(TEST_UID);

    String sName = Thread.currentThread().getName();
    if (sName.length() > 30)
      sName = sName.substring(sName.length() - 30);

    ISchedule schedule = new OnceSchedule();
    schedule.setName("tuex(" + (sName + ((int)(Math.random() * 1000))));

    SimpleTestRecorder verifier = new SimpleTestRecorder(schedule.getName());
    verifier.reset();

    // Create a schedule
    XmlPersistentTask xpt = new XmlPersistentTask("<invoke class=\"com.verizon.enterprise.vps.core.SimpleTestRecorder\" method=\"externalRun\">" + "<arg>"
        + schedule.getName() + "</arg></invoke>");

    JobScheduleDefObject jobDef = sm.schedulePersistentJob(xpt, schedule);
    Assert.assertNotNull(jobDef);
    Assert.assertTrue(jobDef.getJobScheduleDefOid().longValue() > 0);
    LogHelper.info("New schedule definition created with oid " + jobDef.getJobScheduleDefOid());

    boolean bOK = false;
    try {
      Thread.sleep(1000 * TEST_TIME_INTERVAL);
      Assert.assertEquals(1, verifier.getRunTimeNumber());

      // Make sure pending task is gone
      List qPTs = PendingTaskTable.search("where job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals("Finished pending task is not removed.", 0, qPTs.size());

      // update
      LogHelper.info("Before schedule update with oid " + jobDef.getJobScheduleDefOid());
      sm.updatePersistentJob(xpt, schedule, jobDef);
      LogHelper.info("After schedule update with oid " + jobDef.getJobScheduleDefOid());
      Thread.sleep(5000);

      // Schedule should be cancelled automatically
      // Verify pending task gone
      qPTs = PendingTaskTable.search("WHERE job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals(0, qPTs.size());
      // Verify job schedule def status update.
      jobDef = JobScheduleDefTable.retrieve(jobDef);
      Assert.assertEquals(ISchedule.STATUS_INACTIVE, jobDef.getStatus().charAt(0));

      bOK = true;
    } finally {
      // Cancel it and it should stop immediately.
      sm.unschedulePersistentJob(jobDef, true);
      __Logger.info("Schedule definition removed with oid " + jobDef.getJobScheduleDefOid());

      if (bOK) {
        Thread.sleep(5000);
        Assert.assertEquals(1, verifier.getRunTimeNumber());
        Thread.sleep(TEST_TIME_INTERVAL * 1000);
        Assert.assertEquals(1, verifier.getRunTimeNumber());
      }
    }
  }

  /**
   * Cancel a schedule
   */
  public void cancelPersistentSchedule(String sName) throws Exception {
    ScheduleManager sm = new ScheduleManager();

    List qSDs = JobScheduleDefTable.search(" where name='" + sName + "'");
    Assert.assertEquals(1, qSDs.size());

    JobScheduleDefObject jobDef = (JobScheduleDefObject)qSDs.get(0);
    sm.unschedulePersistentJob(jobDef, false);

    // Pending task should be removed
    List qPTs = PendingTaskTable.search("WHERE job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
    Assert.assertEquals(0, qPTs.size());

    // Job def should still be there with different status
    List qJDs = JobScheduleDefTable.search("WHERE status='" + ISchedule.STATUS_INACTIVE + "' AND job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
    Assert.assertEquals(1, qJDs.size());
  }

  /**
   * Test task instance generation.
   */
  public void testScheduleManagement() throws Exception {
    final int TEST_TIME_INTERVAL = 10;
    // Get server bean
    ScheduleManager sm = new ScheduleManager();
    sm.setUserId(TEST_UID);

    String sName = Thread.currentThread().getName();
    if (sName.length() > 30)
      sName = sName.substring(sName.length() - 30);

    FixedRateSchedule schedule = new FixedRateSchedule(TEST_TIME_INTERVAL);
    schedule.setName("tic(" + (sName + ((int)(Math.random() * 1000))) + ")");

    // Create a schedule
    XmlPersistentTask xpt = new XmlPersistentTask("<script language=\"beanshell\">"
        + "throw new java.io.IOException(\"IOException from testTaskInstanceCreation\");</script>");

    JobScheduleDefObject jobDef = sm.schedulePersistentJob(xpt, schedule);
    Assert.assertNotNull(jobDef);
    Assert.assertTrue(jobDef.getJobScheduleDefOid().longValue() > 0);
    LogHelper.info("New schedule definition created with oid " + jobDef.getJobScheduleDefOid());

    boolean bOK = false;
    try {
      Thread.sleep(1500 * TEST_TIME_INTERVAL);

      // Verify pending task
      List qPTs = PendingTaskTable.search("WHERE job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals(1, qPTs.size());
      PendingTaskObject pt = (PendingTaskObject)qPTs.get(0);
      Assert.assertEquals(IVpsTask.PENDING, pt.getStatus().charAt(0));

      // Verify task instance
      List qTIs = TaskInstanceTable.search("WHERE job_ref_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals(1, qTIs.size());
      TaskInstanceObject ti = (TaskInstanceObject)qTIs.get(0);
      Assert.assertEquals(IVpsTask.FAILED, ti.getStatus().charAt(0));
      Assert
          .assertTrue("Task instance message should contain exception information.", ti.getMessage().indexOf("IOException from testTaskInstanceCreation") > 0);

    } finally {
      // unschedule but keep the schedule def
      sm.unschedulePersistentJob(jobDef, false);

      // Job def should still be there with different status
      List qJDs = JobScheduleDefTable.search("WHERE status='" + ISchedule.STATUS_INACTIVE + "' AND job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals(1, qJDs.size());

      // Verify pending task gone
      List qPTs = PendingTaskTable.search("WHERE job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals(0, qPTs.size());

      // unschedule and remove the schedule def
      sm.unschedulePersistentJob(jobDef, true);

      // Job def should still be gone now
      qJDs = JobScheduleDefTable.search("WHERE job_schedule_def_oid=" + jobDef.getJobScheduleDefOid());
      Assert.assertEquals(0, qJDs.size());
    }
  }
}