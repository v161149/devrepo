package com.verizon.enterprise.vps.middleware;

import java.io.*;
import java.util.*;
import java.sql.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

import org.jdom.*;
import junit.framework.*;
import com.verizon.enterprise.zunit.util.*;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.enterprise.vps.dataobjects.*;
import com.verizon.enterprise.vps.schedule.*;
import com.verizon.enterprise.vps.middleware.*;

/**
 * Runtime environment.
 * @author Zhong Chen
 */
public class ScheduleBeanTest {
    // Constants.
    public static final String JNDI_SCHEDULE_ADMIN = "enterprise.ScheduleAdmin";
    public static final Long TEST_UID = new Long(123);

    public static Context sm_rootContext = null;
    public static ScheduleAdmin sm_adminBean = null;

    /** Constructor */
    public ScheduleBeanTest() {
        try {
            getAdminBean();
        }
        catch (Exception ex) {}
    }

    /**
     * Get bean
     */
    public ScheduleAdmin getAdminBean() throws Exception {
        if (sm_adminBean != null) return sm_adminBean;

        if (sm_rootContext==null) sm_rootContext = new InitialContext();
        Context ctx = sm_rootContext;

        ScheduleAdminHome home = (ScheduleAdminHome)ctx.lookup(JNDI_SCHEDULE_ADMIN);
        ScheduleAdmin bean = (ScheduleAdmin)PortableRemoteObject.narrow(home.create(), ScheduleAdmin.class);

        sm_adminBean = bean;
        return bean;
    }

    /**
     * Test creating schedule in database.
     */
    public void createSchedule(String sName,
                               String sScheduleInfo,
                               String sTaskInfo,
                               boolean bRemoveAfterCreate) throws Exception {
        ScheduleAdmin adminBean = getAdminBean();

        ISchedule schedule = ScheduleParser.parseSchedule(sScheduleInfo);
        Assert.assertNotNull(schedule);
        schedule.setName(bRemoveAfterCreate
                         ?
                         sName+"("+(Thread.currentThread().getName()+"/"+((int)(Math.random()*1000))) + ")"
                         :
                         sName);

        XmlPersistentTask xpt = new XmlPersistentTask(sTaskInfo);

        JobScheduleDefObject jsdo = adminBean.schedulePersistentJob(xpt, schedule, TEST_UID);
        System.out.println("Schedule def object created: " + jsdo);

        if (bRemoveAfterCreate) {
            adminBean.unschedulePersistentJob(jsdo, TEST_UID, true);
            System.out.println("Schedule def object removed: " + jsdo.getJobScheduleDefOid());
        }
    }

    /**
     * Test creating schedule in database.
     */
    public JobScheduleDefObject createNewSchedule(String sName,
                               String sScheduleInfo,
                               String sTaskInfo) throws Exception {
        ScheduleAdmin adminBean = getAdminBean();

        ISchedule schedule = ScheduleParser.parseSchedule(sScheduleInfo);
        Assert.assertNotNull(schedule);
        schedule.setName(sName);

        XmlPersistentTask xpt = new XmlPersistentTask(sTaskInfo);

        JobScheduleDefObject jsdo = adminBean.schedulePersistentJob(xpt, schedule, TEST_UID);
        System.out.println("Schedule def object created: " + jsdo);
        return jsdo;
    }

    /**
     * Test creating schedule in database.
     */
    public void updateSchedule(String sName,
                               String sScheduleInfo,
                               String sTaskInfo,
                               String newScheduleInfo, String newTaskInfo,
                               boolean bRemoveAfterCreate) throws Exception {
        ScheduleAdmin adminBean = getAdminBean();

        ISchedule schedule = ScheduleParser.parseSchedule(sScheduleInfo);
        ISchedule newSchedule = ScheduleParser.parseSchedule(newScheduleInfo);
        Assert.assertNotNull(schedule);
        schedule.setName(sName);
        newSchedule.setName(sName);
        XmlPersistentTask xpt = new XmlPersistentTask(sTaskInfo);
        XmlPersistentTask newXpt = new XmlPersistentTask(newTaskInfo);
        JobScheduleDefObject jsdo = adminBean.schedulePersistentJob(xpt, schedule, TEST_UID);
        System.out.println("Schedule def object created: " + jsdo);
        jsdo = adminBean.updatePersistentJob(newXpt, newSchedule, jsdo, TEST_UID);
        System.out.println("Schedule def object updated: " + jsdo);

        if (bRemoveAfterCreate) {
            adminBean.unschedulePersistentJob(jsdo, TEST_UID, true);
            System.out.println("Schedule def object removed: " + jsdo.getJobScheduleDefOid());
        }
    }

    public void getSchedule(String condition) throws Exception {
        ScheduleAdmin adminBean = getAdminBean();
        Set list = adminBean.getScheduleList(condition);
        for(Iterator it = list.iterator();it.hasNext();)
        {
          ScheduleJobInfo info = (ScheduleJobInfo)it.next();
          System.out.println("schedule =" + info.getSchedule().getScheduleInfoString());
          System.out.println("task =" + ((XmlPersistentTask)info.getTask()).writeTaskInfo());
          System.out.println();
        }
    }

}