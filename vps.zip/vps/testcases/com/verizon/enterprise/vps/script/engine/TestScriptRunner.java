package com.verizon.enterprise.vps.script.engine;

import junit.framework.*;
import java.util.Map;
import java.util.HashMap;
import com.verizon.enterprise.vps.core.BeanXmlFactory;
import com.verizon.enterprise.vps.dataobjects.Registry;
import com.verizon.enterprise.vps.dataobjects.ScriptLanguage;
import com.verizon.enterprise.vps.util.ScriptUtil;

public class TestScriptRunner
{
    private ScriptRunner scriptRunner = null;

    public TestScriptRunner()
    {
        scriptRunner = new ScriptRunner();
    }

    /**
     * Run script from db.
     * @param scriptName
     * @param map
     * @throws Exception
     */
    public void runByName(String scriptName, Map map) throws Exception
    {
        System.out.println("START:\n" + ScriptUtil.mapToString(map));
        System.out.println("START:\n" + BeanXmlFactory.buildXmlFromMap(map, null, null));
        Map result = scriptRunner.runByName(scriptName, map);
        System.out.println("END:\n" + ScriptUtil.mapToString(result));
        System.out.println("END:\n" + BeanXmlFactory.buildXmlFromMap(result, null, null));
    }

    /**
     * Run script from db.
     * @param scriptName
     * @param map
     * @param resultStr
     */
    public void testBshEngineFromDB(String scriptName, Map map, String resultStr) throws Exception
    {
        Map result = scriptRunner.runByName(scriptName, map);

        Assert.assertNotNull("Result Registry is null.", result);
        Assert.assertEquals("Result is not the same.", resultStr, (String)result.get("result"));
        System.out.println(ScriptUtil.mapToString(result));
    }

    /**
     * Test BeanShell script.
     */
    public void testBshEngine() throws Exception {
        StringBuffer sbScript = new StringBuffer();
        sbScript.append("result = registry.lookupObject(\"hello\");");
        sbScript.append("if (result == null) result = \"\";");
        sbScript.append("result += registry.lookupObject(\"lastName\");");
        sbScript.append("result += \", \";");
        sbScript.append("result += registry.lookupObject(\"firstName\");");
        sbScript.append("registry.put(\"result\", result);");

        Map mapInput = new HashMap();
        mapInput.put("lastName", "CHEN");
        mapInput.put("firstName", "ZHONG");

        Map result = scriptRunner.runByContent(sbScript.toString(), mapInput, ScriptLanguage.BEANSHELL);
        Assert.assertEquals("CHEN, ZHONG", (String)result.get("result"));

        mapInput.put("hello", "Hello! ");

        result = scriptRunner.runByContent(sbScript.toString(), mapInput, ScriptLanguage.BEANSHELL);
        Assert.assertEquals("Hello! CHEN, ZHONG", (String)result.get("result"));

        // Test exception
        boolean bPass = false;
        sbScript = new StringBuffer();
        sbScript.append("throw new java.io.IOException(\"Test IO.\");");
        try {
            result = scriptRunner.runByContent(sbScript.toString(), mapInput, ScriptLanguage.BEANSHELL);
        }
        catch (Exception ioe) {
            bPass = ioe instanceof java.io.IOException;
        }

        Assert.assertTrue("IOException expected.", bPass);
    }

    /**
     * Test JavaScript script.
     */
    public void testJsEngine() throws Exception {
        StringBuffer sbScript = new StringBuffer();
        sbScript.append("result = registry.lookupObject(\"hello\");");
        sbScript.append("if (result == null) result = \"\";");
        sbScript.append("result += registry.lookupObject(\"lastName\");");
        sbScript.append("result += \", \";");
        sbScript.append("result += registry.lookupObject(\"firstName\");");
        sbScript.append("registry.registerObject(\"result1\", result);");

        Map mapInput = new HashMap();
        mapInput.put("lastName", "CHEN");
        mapInput.put("firstName", "ZHONG");

        Map result = scriptRunner.runByContent(sbScript.toString(), mapInput, ScriptLanguage.BEANSHELL);
        Assert.assertEquals("CHEN, ZHONG", (String)result.get("result1"));

        mapInput.put("hello", "Hello! ");

        result = scriptRunner.runByContent(sbScript.toString(), mapInput, ScriptLanguage.BEANSHELL);
        Assert.assertEquals("Hello! CHEN, ZHONG", (String)result.get("result1"));
    }

    /**
     * Run BeanShell script.
     */
    public Map runScriptByContent(String scriptContent, Map map, String sLanguage) throws Exception
    {
        Map result = scriptRunner.runByContent(scriptContent, map, sLanguage);
//        System.out.println(ScriptUtil.mapToString(result));
        return result;
    }

}
