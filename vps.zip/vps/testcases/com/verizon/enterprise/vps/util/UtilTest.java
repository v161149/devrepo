package com.verizon.enterprise.vps.util;

import junit.framework.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.io.*;

import com.verizon.kernel.exception.DatalayerException;
import com.verizon.enterprise.vps.schedule.*;
import com.verizon.kernel.config.Config;

public class UtilTest extends TestCase {
    private static SimpleDateFormat sm_dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public UtilTest() {
    }
    public UtilTest(String s) {
        super(s);
    }

    public static Test suite() {
        TestSuite suite = new TestSuite();
        return suite;
    }

    /** test logger */
    public void testLog() throws Exception {
        System.out.println("System out.");
        LogHelper.debug("Debug message.");
        LogHelper.info("Info message.");
        LogHelper.warn("Warning message.");
        LogHelper.error("Error message.");
    }

    /** test db connection */
    public void testDbConnect() throws Exception {
        Connection dbc = null;
        PreparedStatement pstmt = null;

        try {
            dbc = DbHelper.getDbConnection();
            pstmt = dbc.prepareStatement("SELECT count(*) FROM job_schedule_def");
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                LogHelper.info("There are " + rs.getInt(1) + " schedule defs.");
            }
        }
        finally {
            if (pstmt != null) pstmt.close();
            if (dbc != null) dbc.close();
        }
    }

    /** Test config file refresh */
    public void testConfigRefresh() throws Exception {
        try {
            // Write config
            writeConfig("/main/vz/build/domains/ops/config/vps/test.xml",
                        "<vps><persistent><enabled>origValue</enabled></persistent></vps>");
            // Read
            Assert.assertEquals("origValue", Config.getProperty("vps.test", "vps.persistent.enabled"));

            // Change config
            writeConfig("/main/vz/build/domains/ops/config/vps/test.xml",
                        "<vps><persistent><enabled>newValue</enabled></persistent></vps>");

            // Wait for refresh
            Thread.sleep(65000);
            // Verify change
            Assert.assertEquals("newValue", Config.getProperty("vps.test", "vps.persistent.enabled"));

        }
        finally {
            // Remove file
            File f = new File("/main/vz/build/domains/ops/config/vps/test.xml");
            f.delete();
        }
    }

    /** Write config file */
    private void writeConfig(String sFilePath, String sContent) throws IOException {
        FileWriter fw = new FileWriter(sFilePath);
        fw.write(sContent);
        fw.close();
    }

    /** Read config file */
    private String readConfig(String sFilePath) throws IOException {
        FileReader fr = new FileReader(sFilePath);

        return null;
    }

}
