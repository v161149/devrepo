/*
 * @(#)TestThreadPool.java   1.0     Mar 19, 2008
 *
 * Copyright 2007 Verizon eBusiness, Inc. All rights reserved.
 * VERIZON PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.verizon.enterprise.vps.util;

import java.util.LinkedList;

/**
 * This class ...
 * 
 * @author Hong-qi Jia
 * @version 1.0 Mar 19, 2008
 */
class ThreadTask extends Thread {
  private TestThreadPool pool;

  public ThreadTask(TestThreadPool thePool) {
    pool = thePool;
  }

  public void run() {
    while (true) {
      // blocks until job
      Runnable job = pool.getNext();
      try {
        job.run();
      } catch (Exception e) {
        // Ignore exceptions thrown from jobs
        System.err.println("Job exception: " + e);
      }
    }
  }
}

public class TestThreadPool {
  private LinkedList tasks = new LinkedList();

  public TestThreadPool(int size) {
    for (int i = 0; i < size; i++) {
      Thread thread = new ThreadTask(this);
      thread.start();
    }
  }

  public void run(Runnable task) {
    synchronized (tasks) {
      tasks.addLast(task);
      tasks.notify();
    }
  }

  public Runnable getNext() {
    Runnable returnVal = null;
    synchronized (tasks) {
      while (tasks.isEmpty()) {
        try {
          tasks.wait();
        } catch (InterruptedException ex) {
          System.err.println("Interrupted");
        }
      }
      returnVal = (Runnable)tasks.removeFirst();
    }
    return returnVal;
  }

  public static void main(String args[]) {
    final String message[] = {"Java", "Source", "and", "Support"};
    TestThreadPool pool = new TestThreadPool(message.length / 2);
    for (int i = message.length - 1; i >= 0; i--) {
      final int innerI = i;
      Runnable runner = new Runnable() {
        public void run() {
          for (int j = 24; j >= 0; j--) {
            System.out.println("j: " + j + ": " + message[innerI]);
          }
        }
      };
      pool.run(runner);
    }
  }
}