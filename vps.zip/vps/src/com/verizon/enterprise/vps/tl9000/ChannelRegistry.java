package com.verizon.enterprise.vps.tl9000;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.digester.Digester;
import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

public final class ChannelRegistry {

	private final static Logger log = Logger.getLogger(ChannelRegistry.class);

	private static final String REGISTRY_FILE = "james/nsp_channels.xml";
	private static Boolean registryLoaded = Boolean.FALSE;
	private static ChannelRegistry singleton;

	private Map channelLookupMap;

	/**
	 * Constructor
	 */
	private ChannelRegistry() {
		channelLookupMap = new HashMap();
		URL resource = Thread.currentThread().getContextClassLoader()
				.getResource(REGISTRY_FILE);
		Digester digester = new Digester();
		digester.push(this);
		digester.addCallMethod("channels/channel", "addChannel", 2);
		digester.addCallParam("channels/channel/address", 0);
		digester.addCallParam("channels/channel/handler", 1);
		try {
			digester.parse(resource.openStream());
		} catch (IOException ex) {
			log.error("EXCEPTION!", ex);
		} catch (SAXException ex) {
			log.error("EXCEPTION!", ex);
		}
	}

	/**
	 * Add the a new channel with the input address and handler class, if the
	 * handler class does not implement IChannelHandler, then it will not be
	 * added.
	 * 
	 * @param address
	 * @param handlerClazz
	 */
	public void addChannel(String address, String handlerClazz) {
		try {
			Class clazz = Class.forName(handlerClazz);
			if (IChannelHandler.class.isAssignableFrom(clazz)) {
				channelLookupMap.put(address, clazz);
			}
			else {
				log
						.warn("Registering "
								+ handlerClazz
								+ " failed! It does not implement IChannelHandler interface.");
			}
		} catch (ClassNotFoundException ex) {
			log.error("Class " + handlerClazz
					+ " is not loaded in registry for channel " + address);
			log.error("EXCEPTION!", ex);
		}
	}

	/**
	 * If there's a handler class registered with the given address, return it.
	 * Otherwise, return null.
	 * 
	 * @param address
	 * @return
	 */
	public IChannelHandler getHandler(String address) {
		IChannelHandler handler = null;
		if (channelLookupMap.containsKey(address)) {
			try {
				handler = (IChannelHandler) ((Class) channelLookupMap
						.get(address)).newInstance();
			} catch (InstantiationException ex) {
				log.error("EXCEPTION!", ex);
			} catch (IllegalAccessException ex) {
				log.error("EXCEPTION!", ex);
			}
		}
		return handler;
	}
	
	public String[] getAllChannels() {
		Set channelSet = channelLookupMap.keySet();
		String[] channels = new String[channelSet.size()];
		channelSet.toArray(channels);
		return channels;
	}

	/**
	 * Get the singleton Object
	 * 
	 * @return
	 */
	public static ChannelRegistry getInstance() {
		if (!registryLoaded.booleanValue()) {
			synchronized (registryLoaded) {
				if (!registryLoaded.booleanValue()) {
					singleton = new ChannelRegistry();
					registryLoaded = Boolean.TRUE;
				}
			}
		}
		return singleton;
	}
}
