package com.verizon.enterprise.vps.tl9000;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import com.verizon.kernel.exception.DatalayerException;
import com.verizon.kernel.jdbc.ConnectionFactory;

public class MessageDataUtil {

	private static final Logger logger = Logger
			.getLogger(MessageDataUtil.class);

	private MessageDataUtil() {
	}

	/**
	 * This will call select for update with maximum maxBatchSize number of
	 * rows.
	 * 
	 * @param conn
	 * @param maxBatchSize
	 *            Maximum number of rows to retrieve
	 * @param channels
	 *            A array of channels to filter, so the return result will only
	 *            include those matches with the input channels. You can pass
	 *            null in to ignore the filter. An empty array will always
	 *            return a empty map.
	 * @return A map with key being the channel of type String, and key being
	 *         the message_data_oid of type Long
	 */
	public static Map getNextNewMessageBatch(Connection conn, int maxBatchSize,
			String[] channels) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Map oidToChannel = new HashMap(maxBatchSize);
		if (channels == null || channels.length > 0) {
			try {
				StringBuffer sql = new StringBuffer(
						"SELECT MESSAGE_DATA_OID, CHANNEL FROM MESSAGE_DATA WHERE STATUS='N' AND ROWNUM<"
								+ (maxBatchSize + 1));
				if (channels != null) {
					sql.append(" AND (");
					for (int i = 0; i < channels.length; i++) {
						if (i > 0)
							sql.append(" OR ");
						sql.append(" CHANNEL='" + channels[i].toLowerCase()
								+ "'");

					}
					sql.append(")");
				}
				sql.append(" ORDER BY MESSAGE_DATA_OID FOR UPDATE");
				if (logger.isDebugEnabled())
					logger.debug("sql: " + sql);
				pstmt = conn.prepareStatement(sql.toString());
				rs = pstmt.executeQuery();
				while (rs.next()) {
					oidToChannel.put(new Long(rs.getLong(1)), rs.getString(2));
				}
			} catch (SQLException ex) {
				logger.error("EXCETPION!", ex);
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException ex) {
					logger.error("EXCETPION!", ex);
				}
			}
		}
		return oidToChannel;
	}

	public static void updateMessageStatus(Connection conn, long[] oids,
			char status) {
		if (oids.length > 0) {
			StringBuffer oidCondition = new StringBuffer("MESSAGE_DATA_OID=?");
			for (int i = 1; i < oids.length; i++) {
				oidCondition.append(" OR MESSAGE_DATA_OID=?");
			}
			PreparedStatement pstmt = null;
			try {
				pstmt = conn
						.prepareStatement("UPDATE MESSAGE_DATA SET STATUS='"
								+ status + "' WHERE " + oidCondition.toString());
				for (int i = 0; i < oids.length; i++) {
					pstmt.setLong(i + 1, oids[i]);
				}
				pstmt.executeUpdate();
			} catch (SQLException ex) {
				logger.error("EXCETPION!", ex);
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException ex) {
					logger.error("EXCETPION!", ex);
				}
			}
		}
	}

	public static MimeMessage getMessage(long oid, Session session) {
		MimeMessage msg = null;
		Connection conn = null;
		try {
			conn = ConnectionFactory.getConnection(
					MessageDataConstants.DB_SCHEMA).getConnection();
			conn.setAutoCommit(false);
			msg = getMessage(conn, oid, session);
			conn.commit();
		} catch (DatalayerException ex) {
			logger.error("EXCETPION!", ex);
		} catch (SQLException ex) {
			logger.error("EXCETPION!", ex);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				logger.error("EXCETPION!", ex);
			}
		}
		return msg;
	}

	public static MimeMessage getMessage(Connection conn, long oid,
			Session session) {
		Collection messages = getMessages(conn, new long[] { oid }, session);
		if (messages.isEmpty()) {
			return null;
		} else {
			return (MimeMessage) messages.toArray()[0];
		}
	}

	public static Collection getMessages(Connection conn, long[] oids,
			Session session) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Collection messages = new ArrayList();
		try {
			StringBuffer sql = new StringBuffer();

			for (int i = 0; i < oids.length; i++) {
				if (sql.length() > 0) {
					sql.append(" OR ");
				}
				sql.append("MESSAGE_DATA_OID=" + oids[i]);
			}
			sql.insert(0, "SELECT ATTACHMENT FROM MESSAGE_DATA WHERE ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				messages.add(new MimeMessage(session, rs.getBlob(1)
						.getBinaryStream()));

			}
		} catch (SQLException ex) {
			logger.error("EXCETPION!", ex);
		} catch (MessagingException ex) {
			logger.error("EXCETPION!", ex);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException ex) {
				logger.error("EXCETPION!", ex);
			}
		}
		return messages;
	}
}
