package com.verizon.enterprise.vps.tl9000;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.kernel.config.Config;
import com.verizon.kernel.jdbc.ConnectionFactory;

public class ChannelDispatchTask implements IVpsTask {

	private static final Logger logger = Logger
			.getLogger(ChannelDispatchTask.class);

	public String getDescription() {
		return "ChannelDispatchTask: task that dipatch the ChannelHandlerInvocationTask";
	}

	public void run() throws Exception {
		Connection conn = null;
		try {
			int batchSize = Config.getIntProperty("james.nsp_config",
				"config.batchSize", 5);
			conn = ConnectionFactory
					.getSqlConnection(MessageDataConstants.DB_SCHEMA);
			conn.setAutoCommit(false);
			Map oidToChannelMap = MessageDataUtil.getNextNewMessageBatch(conn,
				batchSize, ChannelRegistry.getInstance().getAllChannels());

			if (logger.isDebugEnabled()) {
				logger.debug("oidToChannelMap: " + oidToChannelMap);
			}

			if (!oidToChannelMap.isEmpty()) {
				ScheduleManager sm = new ScheduleManager();
				long[] oids = new long[oidToChannelMap.entrySet().size()];
				int idx = 0;
				for (Iterator iter = oidToChannelMap.entrySet().iterator(); iter
						.hasNext(); idx++) {
					Map.Entry entry = (Map.Entry) iter.next();
					Long oid = (Long) entry.getKey();
					String channel = (String) entry.getValue();
					sm.scheduleTransientJob(new ChannelHandlerInvocationTask(
							channel, oid), new OnceSchedule());
					oids[idx] = oid.longValue();
				}
				MessageDataUtil.updateMessageStatus(conn, oids,
					MessageDataConstants.PROCESSED_STATUS);
			}
			conn.commit();
		} catch (Exception ex) {
			logger.error("EXCETPION!", ex);
			conn.rollback();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				logger.error("EXCETPION!", ex);
			}
		}
	}
}
