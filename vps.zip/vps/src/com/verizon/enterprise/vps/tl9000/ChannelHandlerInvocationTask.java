package com.verizon.enterprise.vps.tl9000;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.verizon.common.datalayer.ecp.MessageDataObject;
import com.verizon.common.datalayer.ecp.MessageDataTable;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;

public class ChannelHandlerInvocationTask implements IVpsTask {

	private final static Logger log = Logger
			.getLogger(ChannelHandlerInvocationTask.class);

	private String channel;
	private Long oid;

	/**
	 * @param channel
	 * @param oid
	 */
	public ChannelHandlerInvocationTask(String channel, Long oid) {
		this.channel = channel;
		this.oid = oid;
	}

	public String getDescription() {
		return "ChannelHandlerInvocationTask: task that invoke the TL9000 channel handler that's found in the registry";
	}

	public void run() throws Exception {
		IChannelHandler channelHandler = ChannelRegistry.getInstance()
				.getHandler(channel);
		if (channelHandler != null) {
			if (log.isDebugEnabled()) {
				log.debug("Invoking handler " + channelHandler.getClass()
						+ " with param: (" + channel + "," + oid + ")");
			}

			try {
				channelHandler.process(channel, oid);
			} catch (Exception ex) {
				if (log.isEnabledFor(Level.ERROR)) {
					log.error(channel + " handler got exception: ", ex);
					log.error("Update message_data status to error!");
				}
				MessageDataObject mdo = MessageDataTable.retrieve(oid);
				mdo
						.setStatus(String
								.valueOf(MessageDataConstants.ERROR_STATUS));
				MessageDataTable.update(mdo);
			}
		}
		else if (log.isEnabledFor(Level.ERROR)) {
			log.error("No handler found for channel " + channel);
		}
	}
}
