package com.verizon.enterprise.vps.tl9000;

import com.verizon.common.datalayer.ecp.MessageDataObject;
import com.verizon.common.datalayer.ecp.MessageDataTable;

public class SampleChannelHandler implements IChannelHandler {

	public void process(String channel, Long oid) throws Exception {
		if (oid.longValue() % 2 == 0) {
			MessageDataObject mdo = MessageDataTable.retrieve(oid);
			mdo.setStatus("Z");
			MessageDataTable.update(mdo);
		}
		else {
			throw new RuntimeException("odd oid found!");
		}
	}
}
