package com.verizon.enterprise.vps.tl9000;

public interface MessageDataConstants {

	static final String DB_SCHEMA = "ECP";
	static final char PROCESSED_STATUS = 'P';
	static final char ERROR_STATUS = 'E';
}
