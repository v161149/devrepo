package com.verizon.enterprise.vps.tl9000;


public interface IChannelHandler {
	public void process(String channel, Long oid) throws Exception;
}
