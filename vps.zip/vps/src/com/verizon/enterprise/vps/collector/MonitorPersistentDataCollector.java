package com.verizon.enterprise.vps.collector;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import com.verizon.enterprise.vps.util.VpsLocalCache;
import com.verizon.enterprise.vps.middleware.ejb.dataAccess.ApsDataAccessHome;
import com.verizon.enterprise.vps.middleware.ejb.dataAccess.ApsDataAccess;
import com.verizon.enterprise.vps.middleware.ejb.dataAccess.ApsDataAccessBean;
import com.verizon.enterprise.vps.ui.dataobjects.MonitorSummary;

import java.util.Collection;

import org.apache.log4j.Logger;

public class MonitorPersistentDataCollector
{
    private static Logger log = Logger.getLogger(MonitorPersistentDataCollector.class);

    public static MonitorSummary getSummary() throws Exception
    {
        final String METHOD_NAME = "getSummary()";
        log.debug("enter: " + METHOD_NAME);

        ApsDataAccessHome home = VpsLocalCache.getApsDataAccessHome();
        log.info("home = " + home);
        ApsDataAccess access = home.create();
        log.info("access = " + access);
        MonitorSummary summary = access.getMonitorSummary();
        log.info("summary = " + summary);

        log.debug("exit: " + METHOD_NAME);
        return summary;
    }

    public static Collection getHistory(int num) throws Exception
    {
        final String METHOD_NAME = "getHistory()";
        log.debug("enter: " + METHOD_NAME);
        ApsDataAccessHome home = VpsLocalCache.getApsDataAccessHome();
        ApsDataAccess access = home.create();
        Collection history = access.getHistory(num);

        log.debug("exit: " + METHOD_NAME);
        return history;
    }

    public static Collection getCurrent(int num) throws Exception
    {
        final String METHOD_NAME = "getCurrent()";
        log.debug("enter: " + METHOD_NAME);
        ApsDataAccessHome home = VpsLocalCache.getApsDataAccessHome();
        ApsDataAccess access = home.create();
        Collection current = access.getCurrent(num);

        log.debug("exit: " + METHOD_NAME);
        return current;
    }
}