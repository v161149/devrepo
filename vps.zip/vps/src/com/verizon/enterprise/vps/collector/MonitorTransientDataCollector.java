package com.verizon.enterprise.vps.collector;

import javax.management.AttributeList;
import javax.management.Attribute;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import java.util.Iterator;

import weblogic.management.MBeanHome;

import com.verizon.enterprise.vps.util.JmxHelper;

import org.apache.log4j.Logger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MonitorTransientDataCollector
{
    private static Logger log = Logger.getLogger(MonitorTransientDataCollector.class);

    static final String ADMIN_USER   = "system";
    static final String ADMIN_PW     = "weblogic";

    public static String[] attrNames = new String[] {
        "TransientTimerThreadStatus",
        "PendingTransientTaskCount",
        "RunningTransientTaskCount",
        "FinishedTransientTaskCount",
        "TaskHistory",
        "CurrentTasks"
    };

    static MBeanHome getMBeanHome(String server) throws Exception
    {
        log.debug("Enter:");
        JmxHelper helper = new JmxHelper(ADMIN_USER, ADMIN_PW);
        MBeanHome home;
        if ( (null == server) || (server.length() <= 0))
        {
            home = helper.getLocalMBeanHome();
            server = home.getMBeanServer().getServerName();
        }
        else
        {
            home = helper.getMBeanHome(server);
        }

        if (null == home)
        {
            log.error("Cannot find WebLogic MBeanHome for " + server);
        }

        log.debug("Exit:");
        return home;
    }

    static MBeanServer getMBeanServer(String server) throws Exception
    {
        log.debug("Enter:");
        MBeanHome home = getMBeanHome(server);
        MBeanServer mbeanServer = null;

        if (home != null)
            mbeanServer =  home.getMBeanServer();
        log.debug("Exit:");
        return mbeanServer;
    }

    public static AttributeList getData(String server) throws Exception
    {
        log.debug("Enter:");
        MBeanServer mbeanServer = getMBeanServer(server);
        ObjectName objectname = new ObjectName("operations:name=VpsRuntime");
        AttributeList attribList = null;

        if (mbeanServer != null)
            attribList = mbeanServer.getAttributes(objectname, attrNames);

        log.debug("Exit:");
        return attribList;
    }

    public static void main(String[] argv) throws Exception
    {
        log.debug("Enter:");
        AttributeList list = getData("t3://localhost:2042");
        log.debug("JMX getting attributes");

        if (list == null || list.size() == 0)
        {
            log.error("Attribute List is empty.");
            log.debug("Exit:");
            return;
        }

        Iterator iter = list.iterator();
        while (iter.hasNext())
        {
            Attribute attr = (Attribute) iter.next();
            log.debug("name = " + attr.getName() + ", value = " + attr.getValue());
        }

        log.debug("Exit:");
    }
}