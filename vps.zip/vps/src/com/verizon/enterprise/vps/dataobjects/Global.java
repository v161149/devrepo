package com.verizon.enterprise.vps.dataobjects;

import java.io.PrintStream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Global
{
    PrintStream outStream = null;
    PrintStream errStream = null;
    
    public static final String GLOBAL_INSTANCE_NAME = "global";
    
    public Global()
    {
    }
    
    public PrintStream getOut()
    {
        return outStream == null ? System.out : outStream;
    }

    public void setOut(PrintStream out)
    {
        outStream = out;
    }

    public PrintStream getErr()
    {
        return errStream == null ? System.err : errStream;
    }

    public void setErr(PrintStream err)
    {
        errStream = err;
    }
    
    public void print(Object[] argv)
    {
        PrintStream out = getOut();
        String tmpStr;
        
        for (int i = 0; i < argv.length; i++)
        {
            if (i > 0) 
                out.print(" ");
                
            out.print("" + argv[i]);
        }
        out.println();
    }
    
    public void sleep(long nMS)
    {
        /* 2 mins max */
        long max = 120000;
        if (nMS > max)
            nMS = max;
        try
        {
            if (nMS > 0)
                Thread.sleep(nMS);
        }
        catch (InterruptedException e)
        {
        }
    }
}