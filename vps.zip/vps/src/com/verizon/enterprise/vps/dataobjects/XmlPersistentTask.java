package com.verizon.enterprise.vps.dataobjects;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.jdom.Element;
import org.jdom.JDOMException;

import com.verizon.enterprise.vps.core.BeanXmlFactory;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.xml.JDomUtil;
import com.verizon.kernel.xml.XmlHelper;

/**
 * <p>Title: Virtual Process Service</p> <p>Description: </p> <p>Copyright:
 * Copyright (c) 2003</p> <p>Company: Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */

public class XmlPersistentTask implements IVpsPersistentTask, Serializable {
  private static final long serialVersionUID = 3966085410249852928L;

  // XML constants.
  public static final String TAG_INVOKE = "invoke";
  public static final String TAG_SCRIPT = "script";
  public static final String TAG_EXEC = "exec";
  public static final String TAG_ARG = "arg";
  public static final String ATTR_CLASS = "class";
  public static final String ATTR_METHOD = "method";
  public static final String ATTR_NAME = "name";
  public static final String ATTR_TYPE = "type";
  public static final String ATTR_LANGUAGE = "language";

  // Simplied way to invoke script.
  public static final String SCRIPT_RUNNER_CLASS = "com.verizon.enterprise.vps.script.engine.ScriptRunner";
  public static final String SCRIPT_RUNNER_METHOD_BY_CONTENT = "runByContent";
  public static final String SCRIPT_RUNNER_METHOD_BY_NAME = "runByName";
  public static final String EXEC_RUNNER_CLASS = "com.verizon.enterprise.vps.dataobjects.ExecTask";
  public static final String EXEC_RUNNER_METHOD = "run";

  // Task info in XML
  // <invoke class="abc" method="def">
  // <arg name="a1" type="b1">value1</arg>
  // </invoke>
  // or
  // <script name="enterprise.test.1"/>
  // or
  // <script
  // language="BeanShell">System.out.println("Hello, BeanShell");</script>
  //
  protected String m_sClassName, m_sMethodName;
  transient protected Constructor m_constructor;
  transient protected Method m_method;
  transient protected Object[] m_qArgObjects = null;
  transient protected boolean m_bTaskParsed = false;
  protected List m_qArgStrings = new LinkedList();
  protected List m_qCmdAttributes;
  protected String m_sTaskXML;
  protected String m_sRunningMessage = null;

  public XmlPersistentTask() {
  }

  /**
   * Constructor.
   * 
   * @param sTaskXML
   */
  public XmlPersistentTask(String sTaskXML) throws TaskParsingException {
    readTaskInfo(sTaskXML);
  }

  /** Get description */
  public String getDescription() {
    return m_sRunningMessage == null ? "XML:" + m_sClassName + ":" + m_sMethodName : m_sRunningMessage;
  }

  /**
   * Execute this task.
   * 
   * @throws Exception
   */
  public void run() throws Exception {
    try {
      if (!m_bTaskParsed) {
        readTaskInfo(m_sTaskXML);
      }

      Object tgtObject = null;
      // Create an instance
      try {
        tgtObject = m_constructor.newInstance(new Object[] {});
      } catch (InstantiationException e) {
        e.fillInStackTrace();
        throw e;
      } catch (IllegalAccessException e) {
        e.fillInStackTrace();
        throw e;
      }

      // invoke method on instance.
      Object[] qArgs = (m_qArgObjects == null ? m_qArgObjects = convertArgs() : m_qArgObjects);
      LogHelper.info("Starting to execute PersistentTask=" + this.getDescription());
      m_method.invoke(tgtObject, qArgs);
      LogHelper.info("Finished executing PersistentTask=" + this.getDescription());
      // m_method.invoke(tgtObject, convertArgs());
    } finally {
      ;
    }
  }

  public static IVpsTask parse(String sTaskInfo) throws TaskParsingException {
    try {
      return parse(JDomUtil.parseXmlString(sTaskInfo));
    } catch (JDOMException e) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, e.getMessage());
    }
  }

  public static IVpsTask parse(Element elem) throws TaskParsingException {
    XmlPersistentTask task;
    if (elem.getName().equalsIgnoreCase(TAG_SCRIPT)) {
      task = new ScriptTask();
      task.readScriptXML(elem);
    } else if (elem.getName().equalsIgnoreCase(TAG_INVOKE)) {
      task = new XmlPersistentTask();
      task.readFromXML(elem);
    } else if (elem.getName().equalsIgnoreCase(TAG_EXEC)) {
      task = new ExecTask();
      task.readFromXML(elem);
    } else {// (!elem.getName().equalsIgnoreCase(TAG_INVOKE)) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Missing invoke/script XML tag.");
    }
    return task;
  }

  /**
   * Read task information.
   * 
   * @param sTaskInfo
   * @throws VpsScheduleException
   */
  public void readTaskInfo(String sTaskInfo) throws TaskParsingException {
    m_sTaskXML = sTaskInfo;
    try {
      Element elem = JDomUtil.parseXmlString(sTaskInfo);
      readTaskInfo(elem);
    } catch (JDOMException jde) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Invalid XML for task: " + jde.getMessage());
    }
  }

  /**
   * Read task information.
   * 
   * @param sTaskInfo
   * @throws VpsScheduleException
   */
  public void readTaskInfo(Element eTask) throws TaskParsingException {
    readFromXML(eTask);
    m_bTaskParsed = true;
  }

  /**
   * Output task information.
   * 
   * @param sTaskInfo
   * @throws VpsScheduleException
   */
  public String writeTaskInfo() throws VpsException {
    if (m_sTaskXML != null)
      return m_sTaskXML;

    // Construct
    Element elem = new Element(TAG_INVOKE);
    // class
    if (m_sClassName != null) {
      elem.setAttribute(ATTR_CLASS, m_sClassName);
    } else {
      throw new TaskParsingException(TaskParsingException.MISSING_CLASS);
    }

    // method
    if (m_sMethodName != null) {
      elem.setAttribute(ATTR_METHOD, m_sMethodName);
    } else {
      throw new TaskParsingException(TaskParsingException.MISSING_METHOD);
    }

    // args
    Element elemArg;
    Iterator iter = m_qArgStrings.iterator();
    while (iter.hasNext()) {
      elemArg = new Element(TAG_ARG);
      elemArg.addContent((String)iter.next());
      elem.addContent(elemArg);
    }

    return JDomUtil.getElementString(elem);
  }

  /**
   * Populate from XML
   */
  void readScriptXML(Element elem) throws TaskParsingException {
    // Populate: class name, method name & arguments string
    m_sClassName = SCRIPT_RUNNER_CLASS;
    String sName = elem.getAttributeValue(ATTR_NAME);
    if (sName != null && sName.length() > 0) {
      m_sMethodName = SCRIPT_RUNNER_METHOD_BY_NAME;
      m_qArgStrings.add(sName); // script name
      m_qArgStrings.add(""); // input map
    } else {
      String sLanguage = elem.getAttributeValue(ATTR_LANGUAGE);
      if (sLanguage == null || sLanguage.length() <= 0) {
        // No default language?
        throw new TaskParsingException(TaskParsingException.MISSING_SCRIPT_LANGUAGE);
      }

      m_sMethodName = SCRIPT_RUNNER_METHOD_BY_CONTENT;
      m_qArgStrings.add(elem.getTextTrim()); // Script content
      m_qArgStrings.add(""); // Input map
      m_qArgStrings.add(sLanguage); // Language
    }
  }

  /**
   * Populate from XML
   */
  void readFromXML(Element elem) throws TaskParsingException {
    if (elem.getName().equalsIgnoreCase(TAG_SCRIPT)) {
      readScriptXML(elem);
    } else if (elem.getName().equalsIgnoreCase(TAG_INVOKE)) {
      // Read common attributes.
      m_sMethodName = elem.getAttributeValue(ATTR_METHOD);
      if (null == m_sMethodName) {
        throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Missing method attribute.");
      }

      // Parse argument in string format.
      extractStringArgument(elem);
      m_sClassName = elem.getAttributeValue(ATTR_CLASS);
    } else if (elem.getName().equalsIgnoreCase(this.TAG_EXEC)) {
      m_sMethodName = EXEC_RUNNER_METHOD;
      m_sClassName = EXEC_RUNNER_CLASS;
    } else {// (!elem.getName().equalsIgnoreCase(TAG_INVOKE)) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Missing invoke/script XML tag.");
    }

    // Get class and constructor w/o argument.
    Class theClass = null;
    try {
      if (m_sClassName == null) {
        throw new TaskParsingException(TaskParsingException.MISSING_CLASS);
      } else {
        theClass = Class.forName(m_sClassName);
        m_constructor = theClass.getConstructor(new Class[0]);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, ex.toString());
    }

    // Get method
    int nCount = 0;
    Method[] qMethods = theClass.getMethods();
    for (int i = 0; i < qMethods.length; i++) {
      Method mtd = qMethods[i];
      if (mtd.getName().equals(m_sMethodName) && Modifier.isPublic(mtd.getModifiers()) && mtd.getParameterTypes().length == m_qArgStrings.size()) {
        m_method = mtd;
        nCount++;
        if (nCount > 1) {
          throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "There are multiple methods with the same name '" + m_sMethodName + "'.");
        }
      }
    }

    if (m_method == null) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Cannot find proper method '" + m_sMethodName + "' in class '" + m_sClassName + "'.");
    }

  }

  /**
   * Save argument in string format.
   */
  protected void extractStringArgument(Element elem) {
    // We only extract argument in string format now.
    // Some value might be context-sensitive.
    List qChildren = elem.getChildren();
    Iterator iter = qChildren.iterator();
    while (iter.hasNext()) {
      Element e = (Element)iter.next();
      if (!e.getName().equals(this.TAG_ARG)) {

      } // maybe sent out a warning

      // String sArgType = e.getAttribute(this.ATTR_TAG_TYPE);
      if (XmlHelper.hasChildren(e)) {
        m_qArgStrings.add(com.verizon.kernel.xml.JDomUtil.getElementString(e));
      } else {
        m_qArgStrings.add(e.getTextTrim());
      }
    }
  }

  /**
   * Convert string args to objects.
   */
  protected Object[] convertArgs() throws TaskParsingException {
    // prepare arguments.
    ArrayList qArgs = new ArrayList(m_qArgStrings.size());
    Class[] qArgTypes = m_method.getParameterTypes();
    Class c = null;
    String sVal = null;
    for (int i = 0; i < qArgTypes.length; i++) {
      c = qArgTypes[i];

      // Support only primitives now.
      sVal = (String)m_qArgStrings.get(i);
      if (sVal == null || sVal.length() == 0) {
        qArgs.add(null);
      } else if (c.equals(short.class) || c.equals(Short.class)) {
        qArgs.add(new Short(sVal));
      } else if (c.equals(int.class) || c.equals(Integer.class)) {
        qArgs.add(new Integer(sVal));
      } else if (c.equals(long.class) || c.equals(Long.class)) {
        qArgs.add(new Long(sVal));
      } else if (c.equals(float.class) || c.equals(Float.class)) {
        qArgs.add(new Float(sVal));
      } else if (c.equals(double.class) || c.equals(Double.class)) {
        qArgs.add(new Double(sVal));
      } else if (c.equals(boolean.class) || c.equals(Boolean.class)) {
        qArgs.add(new Boolean(sVal));
      } else if (c.equals(char.class) || c.equals(Character.class)) {
        qArgs.add(new Character(sVal.charAt(0)));
      } else if (c.equals(String.class)) {
        qArgs.add(sVal);
      } else {
        // Assume it is java bean
        try {
          qArgs.add(BeanXmlFactory.buildJavaBeanFromXml(sVal));
        } catch (Exception ex) {
          throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Cannot handle argument type '" + ex.toString() + "'.");
        }
      }
    }

    return qArgs.toArray();
  }

}