package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class ScriptException extends VpsException {
    // Error codes
    public static final int SCRIPT_NOT_FOUND          = 1;
    public static final int UNKNOWN_SCRIPT_LANGUAGE   = 2;
    public static final int LAST_ERROR                = 3;

    // Error messages
    private static String[] ms_qErrMsg = null;

    // Init error messages
    static {
        ms_qErrMsg = new String[LAST_ERROR];
        ms_qErrMsg[NO_ERROR] = "Success.";
        ms_qErrMsg[SCRIPT_NOT_FOUND] = "Script '?' is not found in database.";
        ms_qErrMsg[UNKNOWN_SCRIPT_LANGUAGE] = "Unsupported language '?'.";
    }

    /**
     * Contractor.
     */
    protected String[] getAllErrorMessages() {return ms_qErrMsg;}

    /** Constructor */
    public ScriptException(int nErrCode) {
        super(nErrCode, null, null, null);
    }

    /** Constructor */
    public ScriptException(int nErrCode, String sMsg1) {
        super(nErrCode, sMsg1, null, null);
    }

    /** Constructor */
    public ScriptException(int nErrCode, String sMsg1, String sMsg2) {
        super(nErrCode, sMsg1, sMsg2, null);
    }

    /** Constructor */
    public ScriptException(int nErrCode, String sMsg1, String sMsg2, String sMsg3) {
        super(nErrCode, sMsg1, sMsg2, sMsg3);
    }

}
