package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public interface IVpsInteractiveTask extends IVpsTask {
    /**
     * Communicate the result back. It is task's responsibility to
     * implement this method and VPS engine will
     * send result back to <code>IVpsTaskListener</code>.
     */
    public Object getResult();

    /**
     * Return whether the task is done successfully.
     */
    public boolean isSuccessful();

}