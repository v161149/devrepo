package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class TimeoutTaskListener implements IVpsTaskListener
{
  private Object m_result;

  public void taskStarted() {}

  public void taskFailed(Object result)
  {
    taskSucceeded(result);
  }
  public void taskSucceeded(Object result)
  {
    m_result = result;
    synchronized (this) {
      this.notify();
    }
    m_bIsDone=true;
  }

  public Object getResult() {
    return m_result;
  }

  /**
   * @return true if task is finished, false otherwise
   */
  public boolean isDone() {
    return m_bIsDone;
  }

  /**
   * @return the time that the task has run so far
   */
  public long getTimeExecuted() {
    return System.currentTimeMillis() - m_lTaskStartTime;
  }

  private long m_lTaskStartTime = System.currentTimeMillis();
  private boolean m_bIsDone = false;
}
