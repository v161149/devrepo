/*
 * @(#) IVpsTask.java	1.1, 06/23/03
 *
 * Copyright 2003 Verizon Communications, Inc. All rights reserved.
 */

package com.verizon.enterprise.vps.dataobjects;

/**
 * User submitted task. A raw task has no schedule information, it
 * only defines how to execute itself. <p>
 *
 * @author  Chunsheng Chen
 * @version 1.1, 06/23/03
 * @since   1.0
 */

public interface IVpsTask {
    public static final char PHANTOM     = 'O';   //task does not exist
    public static final char INITIAL     = 'I';   //task is created
    public static final char PENDING     = 'A';   //task is submitted but pending in the pending task queue
    public static final char EXECUTING   = 'E';   //task is delivered to execution queue and is ready for execution
    public static final char FINISHED    = 'F';   //task is finished
    public static final char CANCELED    = 'C';   //task is canceled, this task will not execute if it has not executed and will not recur
    public static final char FAILED      = 'L';   //task is canceled, this task will not execute if it has not executed and will not recur

    /**
     * Execute this task.
     *
     * @throws Exception
     */
    void run() throws Exception;

    /**
     * Get the description of task.
     */
    String getDescription();
}
