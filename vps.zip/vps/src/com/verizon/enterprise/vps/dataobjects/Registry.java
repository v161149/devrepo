package com.verizon.enterprise.vps.dataobjects;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;

import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptRuntime;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.NativeString;
import org.mozilla.javascript.NativeError;
import org.mozilla.javascript.NativeNumber;
import org.mozilla.javascript.NativeBoolean;
import org.mozilla.javascript.NativeDate;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.Wrapper;

import com.verizon.enterprise.rules.engine.JDOMElement;
//import com.verizon.enterprise.report.util.JavaUtil;
import java.io.IOException;

/**
 * <p>Title: Registry for data transfer between java and javascript
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Gang Fu
 * @version 1.0
 */
public class Registry extends ScriptableObject
{
    public static String GLOBAL_INSTANCE_NAME = "registry";
    public static String CLASS_NAME = "Registry";

    // Data members
    private HashMap m_qObjects = new HashMap();
    private Registry m_prototypeInstance = null;
    private transient Scriptable m_scope = null;

    public static void defineClass(ScriptableObject scope)
    {
        try
        {
            ScriptableObject.defineClass(scope, Registry.class);
        }
        catch (Exception e)
        {
            throw new Error(e.getMessage());
        }
    }

    public Registry() {
        if (m_prototypeInstance == null)
            m_prototypeInstance = this;
    }

    public Registry(ScriptableObject scope)
    {
        setParentScope(scope);
        Object ctor = ScriptRuntime.getTopLevelProp(scope, CLASS_NAME);
        if (ctor != null && ctor instanceof Scriptable)
        {
            Scriptable s = (Scriptable) ctor;
            setPrototype((Scriptable) s.get("prototype", s));
        }
    }

    public void transfer(Registry template)
    {
        m_qObjects = (HashMap)(template.m_qObjects.clone());
    }

    public HashMap getHashMap()
    {
        return (HashMap)m_qObjects.clone();
    }

    public void setHashMap(HashMap map)
    {
        if (map != null)
            m_qObjects = (HashMap)map.clone();
    }

    public HashMap getExternalHashMap() throws java.io.IOException
    {
        // Convert script object
        Set kvs = m_qObjects.entrySet();

        HashMap qResultHashMap = new HashMap();
        Map.Entry entry;
        Iterator iter = kvs.iterator();
        while (iter.hasNext())
        {
            entry = (Map.Entry)iter.next();
            //System.out.println("****Interfaces = " + JavaUtil.printInterfaces(entry.getValue()));
            qResultHashMap.put(entry.getKey(), unscript(entry.getValue()));
        }

        return qResultHashMap;
    }

    public String getClassName()
    {
        return CLASS_NAME;
    }

    /**
     * Register object from script.
     */
    public void registerObject(String sVarName, Object obj)
        throws JavaScriptException
    {
        put(sVarName, obj);
    }

    /**
     * UnRegister object from script.
     */
    public void unregisterObject(String sVarName)
        throws JavaScriptException
    {
        remove(sVarName);
    }


    /**
     * Look up object from script.
     */
    public Object lookupObject(String sVarName)
        throws JavaScriptException
    {
        return get(sVarName);
    }

    /**
     * Set up variable. Application can use this to send information
     * to script.
     */
    public void put(String sVarName, Object oVar)
    {
        m_qObjects.put(sVarName, oVar);
    }

    /**
     * Remove variable. Application can use this to send information
     * to script.
     */
    public void remove(String sVarName)
    {
        m_qObjects.remove(sVarName);
    }

    /**
     * Look up a variable from script environment.
     * The variable must be registered by script or application.
     */
    public Object get(String sVarName)
    {
        return m_qObjects.get(sVarName);
    }

    /**
     * Set scope.
     */
    protected void setScope(Scriptable scope)
    {
        m_scope = scope;
    }

    /**
     * Un-script object so object from script can be used by a regular Java program.
     */
    public Object unscript(Object jso)
    {
        if (jso == null) return jso;
        else if (jso instanceof Scriptable)
        {
            if (jso instanceof NativeString)
            {
                return ((NativeString)jso).toString();
            }
            else if (jso instanceof NativeNumber)
            {
                try
                {
                    return new Double(((NativeNumber)jso).toString());
                }
                catch (NumberFormatException nfe)
                {
                    return new Double(Double.NaN);
                }
            }
            else if (jso instanceof NativeError)
            {
                return "ERROR: " + ((NativeError)jso).getMessage();
            }
            else if (jso instanceof NativeBoolean)
            {
                return ((NativeBoolean)jso).getDefaultValue(ScriptRuntime.BooleanClass);
            }
            else if (jso instanceof NativeDate)
            {
                return ((NativeDate)jso).getDefaultValue(null);
            }
            else if (jso instanceof NativeArray)
            {
                NativeArray array = (NativeArray)jso;
                long len = array.jsGet_length();
                Object[] jarray = new Object[(int)len];
                for (int i=0; i<len; i++)
                {
                    jarray[i] = unscript(array.get(i, m_scope));
                }

                return jarray;
            }
            else if (jso instanceof JDOMElement)
            {
                return ((JDOMElement)jso).getElement();
            }
            else if (jso instanceof Wrapper)
            {
                return ((Wrapper)jso).unwrap();
            }
            else
            {
                // We might need more handling here.
                return jso;
            }
        }
        else if (jso.getClass().equals(Object.class))
        {
            return null;
        }
        else
        {
            return jso;
        }
    }

    public void setAll(Map value)
    {
        if (value == null || value.size() == 0) return;

        m_qObjects.putAll(value);
    }
}