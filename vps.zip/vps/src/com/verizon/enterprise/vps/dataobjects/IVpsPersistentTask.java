package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public interface IVpsPersistentTask extends IVpsTask, java.io.Serializable {
    /**
     * Read task information.
     * @param sTaskInfo
     * @throws VpsScheduleException
     */
    public void readTaskInfo(String sTaskInfo) throws VpsException;

    /**
     * Output task information.
     * @param sTaskInfo
     * @throws VpsScheduleException
     */
    public String writeTaskInfo() throws VpsException;

}
