package com.verizon.enterprise.vps.dataobjects;

import java.lang.reflect.Method;
import java.util.*;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class ReflectionTask implements IVpsTask {
    private Object m_targetObject;
    private Method m_method;
    private Object[]   m_qArguments = null;
    private String m_sDesc = null;

    /**
     * Constructor.
     * @param obj
     * @param m
     * @param qArgs
     */
    public ReflectionTask(Object obj, Method m, Object[] qArgs) {
        m_targetObject = obj;
        m_method = m;
        m_qArguments = (Object[])qArgs.clone();
        if (m_method != null) {
            setDescription(m_method.getDeclaringClass() + ":" + m_method.getName());
        }
    }

    /**
     * Constructor.
     * @param obj
     * @param m
     * @param qArgs
     */
    public ReflectionTask(Object obj, Method m, List qArgs) {
        this(obj, m, qArgs.toArray());
    }

    /**
     * Execute this task.
     *
     * @throws Exception
     */
    public void run() throws Exception {
        m_method.invoke(m_targetObject, m_qArguments);
    }

    /**
     * Get the description of task.
     */
    public String getDescription() {
        return m_sDesc;
    }

    /**
     * Set the description of task.
     */
    public void setDescription(String sDesc) {
        m_sDesc = sDesc;
    }

    /**
     * toString for description
     */
    public String toString() {
    	return getDescription();
    }
}