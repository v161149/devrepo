package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: Virtual Process Service a.k.a APM</p>
 * <p>Description: Used by application that cares the status of running tasks.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public interface IVpsTaskListener {
    /**
     * Event for task starting. It will invoked before task runs.
     */
    public void taskStarted();

    /**
     * Event for task failure.
     * @param result Any result task wants to send back.
     */
    public void taskFailed(Object result);

    /**
     * Event for task success.
     * @param result Any result task wants to send back.
     */
    public void taskSucceeded(Object result);

}