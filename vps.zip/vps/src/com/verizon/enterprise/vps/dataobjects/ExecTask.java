package com.verizon.enterprise.vps.dataobjects;

import java.io.File;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;

import com.verizon.enterprise.vps.util.Execute;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.xml.XmlHelper;

/**
 * <exec dir="." executable="batch_job.sh" os="unix" out="true" err="true"
 * timeout="0" newenvironment="false" vmlauncher="true"> <env
 * name="ORACLE_HOME">/apps/opt/oracle/product/9.2.0</env> <arg>1</arg> </exec>
 * 
 * @refer http://ant.apache.org/manual/CoreTasks/exec.html <p>Title: vps</p>
 *        <p>Description: vps</p> <p>Copyright: Copyright (c) 2003</p>
 *        <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class ExecTask extends XmlPersistentTask {
  private static final long serialVersionUID = -5130419121313062445L;
  private Long m_task_oid;

  public ExecTask() {
    this.m_sClassName = EXEC_RUNNER_CLASS;
    this.m_sMethodName = EXEC_RUNNER_METHOD;
  }

  public ExecTask(String executable) {
    this();
    setExecutable(executable);
  }

  public ExecTask(String executable, String[] args) {
    this(executable);
    m_qArgStrings = Arrays.asList(args);
  }

  public void setTaskContext(Long task_oid) {
    m_task_oid = task_oid;
  }

  /**
   * Execute this task.
   * 
   * @throws Exception
   */
  public void run() throws Exception {
    checkConfiguration();

    String[] cmdl = new String[m_qArgStrings.size() + 1];
    int j = 0;
    cmdl[j++] = m_executable;
    for (Object s : m_qArgStrings)
      cmdl[j++] = (String)s;

    Execute exe = null;
    if (m_timeout > 0) {
      exe = new Execute(cmdl, (long)m_timeout * 1000);
    } else {
      exe = new Execute(cmdl);
      if (m_timeout < 0)
        exe.setTerminateIfVMExit(true);
    }
    exe.setTaskContext(m_task_oid);
    exe.setWorkingDirectory(new File(m_dir));
    exe.setVMLauncher(m_vmlauncher);

    if (m_environment != null) {
      for (int i = 0; i < m_environment.length; i++)
        LogHelper.debug("Setting environment variable: " + m_environment[i]);
    }
    exe.setNewenvironment(m_newenvironment);
    exe.setEnvironment(m_environment);

    int err = -1; // assume the worst

    // exe.setWorkingDirectory(new File(m_dir));
    err = exe.execute();
    // test for and handle a forced process death
    if (exe.killedProcess()) {
      LogHelper.warn("Timeout: killed the sub-process");
    }
    if (err != 0) {
      throw new Exception(m_executable + " returned: " + err);
    }
  }

  /**
   * Has the user set all necessary attributes?
   */
  protected void checkConfiguration() throws VpsException {
    if (null == m_executable) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "no executable specified");
    }
    // default directory to the project's base directory
    if (null == m_dir) {
      m_dir = System.getProperty("user.dir");
    }
    File dir = null;
    if (m_dir != null) {
      dir = new File(m_dir);
    }
    if (dir != null && !dir.exists()) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "The directory you specified does not exist");
    }
    if (dir != null && !dir.isDirectory()) {
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "The directory you specified is not a directory");
    }
    // test if os match
    String myos = System.getProperty("os.name");
    // log("Current OS is " + myos, Project.MSG_VERBOSE);
    if ((m_os != null) && (m_os.indexOf(myos) < 0)) {
      // this command will be executed only on the specified OS
      throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "This OS, " + myos + " was not found in the specified list of valid OSes: " + m_os);
    }
  }

  void readFromXML(Element elem) {
    extractAttributes(elem);
    // Parse argument in string format.
    extractStringArgument(elem);
    extractEnvironment(elem);
  }

  protected void extractStringArgument(org.jdom.Element elem) {
    // We only extract argument in string format now.
    // Some value might be context-sensitive.
    List qChildren = elem.getChildren(TAG_ARG);
    Iterator iter = qChildren.iterator();
    while (iter.hasNext()) {
      Element e = (Element)iter.next();
      // String sArgType = e.getAttribute(this.ATTR_TAG_TYPE);
      if (XmlHelper.hasChildren(e)) {
        m_qArgStrings.add(com.verizon.kernel.xml.JDomUtil.getElementString(e));
      } else {
        m_qArgStrings.add(e.getTextTrim());
      }
    }
  }

  void extractEnvironment(Element elem) {
    List qChildren = elem.getChildren(TAG_EXEC_ENV);
    if (qChildren.size() > 0) {
      m_environment = new String[qChildren.size()];
    }
    Iterator iter = qChildren.iterator();
    int i = 0;
    while (iter.hasNext()) {
      Element e = (Element)iter.next();
      String value = e.getTextTrim();
      org.jdom.Attribute ename = e.getAttribute("name");
      String name = ename == null ? "" : ename.getValue();
      m_environment[i++] = name + "=" + e.getTextTrim();
    }
  }

  void extractAttributes(org.jdom.Element elem) {
    org.jdom.Attribute attr = null;

    attr = elem.getAttribute(ATTR_EXEC_DIR);
    if (null != attr) {
      m_dir = attr.getValue();
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_EXECUTABLE);
    if (null != attr) {
      m_executable = attr.getValue();
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_OS);
    if (null != attr) {
      m_os = attr.getValue();
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_OUT);
    if (null != attr) {
      try {
        m_out = attr.getBooleanValue();
      } catch (Exception ignore) {
      }
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_ERR);
    if (null != attr) {
      try {
        m_err = attr.getBooleanValue();
      } catch (Exception ignore) {
      }
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_TIMEOUT);
    if (null != attr) {
      try {
        m_timeout = attr.getIntValue();
      } catch (Exception ignore) {
      }
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_NEWENVIRONMENT);
    if (null != attr) {
      try {
        m_newenvironment = attr.getBooleanValue();
      } catch (Exception ignore) {
      }
      attr = null;
    }

    attr = elem.getAttribute(ATTR_EXEC_VMLAUNCHER);
    if (null != attr) {
      try {
        m_vmlauncher = attr.getBooleanValue();
      } catch (Exception ignore) {
      }
      attr = null;
    }
  }

  /**
   * Timeout in seconds after which the process will be killed.
   */
  public void setTimeout(int timeout) {
    m_timeout = timeout;
  }

  public int getTimeout() {
    return m_timeout;
  }

  /**
   * the directory in which the command should be executed.
   */
  public void setDir(String dir) {
    m_dir = dir;
  }

  public String getDir() {
    return m_dir;
  }

  /**
   * the command to execute.
   */
  public void setExecutable(String executable) {
    m_executable = executable;
  }

  public String getExecutable() {
    return m_executable;
  }

  /**
   * list of Operating Systems on which the command may be executed. If the
   * current OS's name is contained in this list, the command will be executed.
   * The OS's name is determined by the Java Virtual machine and is set in the
   * "os.name" system property.
   */
  public void setOs(String os) {
    m_os = os;
  }

  public String getOs() {
    return m_os;
  }

  /**
   * output for the task execution.
   * 
   * @param output the file to which the output of the command should be
   *        redirected. Defaults to System.out, System.err.
   * @param append whether output should be appended to or overwrite an existing
   *        file. Defaults to false.
   */
  public void setOut(boolean out) {
    m_out = out;
  }

  public void setErr(boolean err) {
    m_err = err;
  }

  public boolean getOut() {
    return m_out;
  }

  public boolean getErr() {
    return m_err;
  }

  public void setNewenvironment(boolean newenvironment) {
    m_newenvironment = newenvironment;
  }

  public boolean getNewenvironment() {
    return m_newenvironment;
  }

  public void setVmlauncher(boolean vmlauncher) {
    m_vmlauncher = vmlauncher;
  }

  public boolean getVmlauncher() {
    return m_vmlauncher;
  }

  private String[] m_environment;
  private String m_dir;
  private String m_executable;
  private String m_os;
  private boolean m_out = false;
  private boolean m_err = false;
  private int m_timeout;
  private boolean m_newenvironment = false;
  private boolean m_vmlauncher;

  public static final String TAG_EXEC_ENV = "env";
  public static final String ATTR_EXEC_DIR = "dir";
  public static final String ATTR_EXEC_EXECUTABLE = "executable";
  public static final String ATTR_EXEC_OS = "os";
  public static final String ATTR_EXEC_OUT = "out";
  public static final String ATTR_EXEC_ERR = "err";
  public static final String ATTR_EXEC_TIMEOUT = "timeout";
  public static final String ATTR_EXEC_FAILONERROR = "failonerror";
  public static final String ATTR_EXEC_NEWENVIRONMENT = "newenvironment";
  public static final String ATTR_EXEC_VMLAUNCHER = "vmlaucher";
}