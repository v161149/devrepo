package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class TaskParsingException extends VpsException {
    // Error codes
    public static final int PARSING_ERROR             = 1;
    public static final int MISSING_CLASS             = 2;
    public static final int MISSING_METHOD            = 3;
    public static final int MISSING_SCRIPT_LANGUAGE   = 4;
    public static final int LAST_ERROR                = 5;

    // Error messages
    private static String[] ms_qErrMsg = null;

    // Init error messages
    static {
        ms_qErrMsg = new String[LAST_ERROR];
        ms_qErrMsg[NO_ERROR] = "Success.";
        ms_qErrMsg[PARSING_ERROR] = "Task parsing error: ?";
        ms_qErrMsg[MISSING_CLASS] = "Missing class.";
        ms_qErrMsg[MISSING_METHOD] = "Missing method.";
        ms_qErrMsg[MISSING_SCRIPT_LANGUAGE] = "Missing script language.";
    }

    /**
     * Contractor.
     */
    protected String[] getAllErrorMessages() {return ms_qErrMsg;}

    /** Constructor */
    public TaskParsingException(int nErrCode) {
        super(nErrCode, null, null, null);
    }

    /** Constructor */
    public TaskParsingException(int nErrCode, String sMsg1) {
        super(nErrCode, sMsg1, null, null);
    }

    /** Constructor */
    public TaskParsingException(int nErrCode, String sMsg1, String sMsg2) {
        super(nErrCode, sMsg1, sMsg2, null);
    }

    /** Constructor */
    public TaskParsingException(int nErrCode, String sMsg1, String sMsg2, String sMsg3) {
        super(nErrCode, sMsg1, sMsg2, sMsg3);
    }

}