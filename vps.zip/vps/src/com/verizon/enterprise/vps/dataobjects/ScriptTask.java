package com.verizon.enterprise.vps.dataobjects;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jdom.Attribute;
import org.jdom.Element;

import com.verizon.enterprise.vps.core.BeanXmlFactory;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;
import com.verizon.enterprise.vps.script.engine.ScriptRunner;

/**
 * <p>Title: </p> <p>Description: </p> <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * 
 * @author not attributable
 * @version 1.0
 */

public class ScriptTask extends XmlPersistentTask {
  private static Logger log = Logger.getLogger(ScriptTask.class);

  HashMap map;
  String scriptName;
  String description;

  public ScriptTask() {
    this.m_sClassName = "com.verizon.enterprise.vps.script.engine.ScriptRunner";
    this.m_sMethodName = "run";
  }

  public ScriptTask(String scriptName) {
    this.m_sClassName = "com.verizon.enterprise.vps.script.engine.ScriptRunner";
    this.m_sMethodName = "run";
    this.scriptName = scriptName;
  }

  public void setRegistry(HashMap value) {
    if (value != null)
      map = (HashMap)value.clone();
    else
      map = new HashMap();
  }

  /**
   * Execute this task.
   * 
   * @throws Exception
   */
  public void run() throws Exception {
    ScriptRunner scriptRunner = new ScriptRunner();
    log.info("Begin to run script=" + scriptName + " with map=" + map);
    Map result = scriptRunner.runByName(scriptName, map);
    log.info("Finished running script=" + scriptName + " with result=" + result);
  }

  /**
   * Output task information.
   * 
   * @param sTaskInfo
   * @throws VpsScheduleException
   */
  public String writeTaskInfo() throws VpsException {
    if (m_sTaskXML != null)
      return m_sTaskXML;

    StringBuilder buf = new StringBuilder();

    buf.append("<");
    buf.append(TAG_INVOKE);
    buf.append(" ");
    buf.append(ATTR_CLASS);
    buf.append("=\"");
    buf.append(m_sClassName);
    buf.append("\" ");
    buf.append(ATTR_METHOD);
    buf.append("=\"");
    buf.append(m_sMethodName);
    buf.append("\">");
    buf.append(BeanXmlFactory.buildXmlFromPrimitiveType(scriptName, TAG_ARG, "ScriptName"));
    buf.append(BeanXmlFactory.buildXmlFromMap(map, TAG_ARG, "ScriptArg"));
    buf.append(BeanXmlFactory.getEndTag(TAG_INVOKE));

    return buf.toString();
  }

  /**
   * Save argument in string format.
   */
  protected void extractStringArgument(Element elem) {
    // We only extract argument in string format now.
    // Some value might be context-sensitive.
    List qChildren = elem.getChildren();
    Iterator iter = qChildren.iterator();
    String value, type;
    Attribute typeAttr;
    Map aMap = new HashMap();

    while (iter.hasNext()) {
      Element e = (Element)iter.next();
      if (!e.getName().equals(this.TAG_ARG)) {

      } // maybe sent out a warning

      typeAttr = e.getAttribute(ATTR_TYPE);

      if (typeAttr == null) {
        scriptName = e.getText();
        System.out.println("scriptName = " + scriptName);
        m_qArgStrings.add(scriptName);
      } else if ("java.lang.String".equals(typeAttr.getValue())) {
        scriptName = e.getText();
        System.out.println("scriptName = " + scriptName);
        m_qArgStrings.add(scriptName);
      } else {
        System.out.println(typeAttr.getValue());
        try {
          map = (HashMap)BeanXmlFactory.buildMapFromXmlElem(e, aMap.getClass());
          m_qArgStrings.add(map);
        } catch (Exception ex) {
          ex.printStackTrace();
        }
      }
    }
  }
}