package com.verizon.enterprise.vps.dataobjects;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public abstract class VpsException extends Exception {
    // Error codes
    public static final int NO_ERROR = 0;

    // Error code
    private int m_nErrCode = NO_ERROR;
    private String m_sMsg1, m_sMsg2, m_sMsg3;

    /** Constructor */
    public VpsException(int nErrCode) {
        this(nErrCode, null, null, null);
    }

    /** Constructor */
    public VpsException(int nErrCode, String sMsg1) {
        this(nErrCode, sMsg1, null, null);
    }

    /** Constructor */
    public VpsException(int nErrCode, String sMsg1, String sMsg2) {
        this(nErrCode, sMsg1, sMsg2, null);
    }

    /** Constructor */
    public VpsException(int nErrCode, String sMsg1, String sMsg2, String sMsg3) {
        m_sMsg1 = sMsg1;
        m_sMsg2 = sMsg2;
        m_sMsg3 = sMsg3;
        m_nErrCode = nErrCode;
    }

    /** Error code */
    public int getErrorCode() {return m_nErrCode;}

    /**
     * Get error message
     */
    public String getMessage() {return expandMessage();}

    /**
     * Contractor.
     */
    protected abstract String[] getAllErrorMessages();

    /** Expand message */
    protected String expandMessage() {
        String[] qErrMsg = getAllErrorMessages();
        String sDesc = qErrMsg[m_nErrCode];
        if (sDesc.indexOf('?') < 0 || m_sMsg1 == null) {
            return sDesc;
        }

        String sRep;
        int qpos;
        for (int i=0; i<3; i++) {
            if (i == 0) sRep = m_sMsg1;
            else if (i == 1) sRep = m_sMsg2;
            else sRep = m_sMsg3;
            if (sRep == null) break;

            qpos = sDesc.indexOf('?');
            if (qpos >= 0) {
                if (qpos < sDesc.length()) {
                    sDesc = sDesc.substring(0, qpos) + sRep + sDesc.substring(qpos+1);
                }
                else {
                    sDesc = sDesc.substring(0, qpos) + sRep;
                }
            }
            else break;
        } // for i

        return sDesc;
    }
}