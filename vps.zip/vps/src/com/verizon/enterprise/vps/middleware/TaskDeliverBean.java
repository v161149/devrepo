package com.verizon.enterprise.vps.middleware;

import java.rmi.RemoteException;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.transaction.UserTransaction;

import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.core.ITaskQueue;
import com.verizon.enterprise.vps.core.ScheduledTask;
import com.verizon.enterprise.vps.core.SubmitException;
import com.verizon.enterprise.vps.core.TaskDBQueue;
import com.verizon.enterprise.vps.core.TaskQueue;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.config.Config;
import com.verizon.kernel.ejb.EJBLocalHomeFactory;
import com.verizon.kernel.jdbc.ConnectionInterface;

public class TaskDeliverBean implements SessionBean {
  private static final long serialVersionUID = 2983274940301679353L;

  // When pending task has no available task, here is the table to force a peek.
  // 5+-0.5 minutes
  public static final long IDLE_WAITING_TIME = Config.getLongProperty("vps.vps", "vps.timer_max_idle_millis", (long)(4.5 + Math.random()) * 60 * 1000);

  private SessionContext m_ctx;

  public long deliverPersistentTask(TaskDBQueue queue) throws VpsException {
    if (!Config.getBooleanProperty("vps.vps", "vps.persistent.enabled", Boolean.FALSE)) {
      LogHelper.info("---persistent scheduler is DISABLED---");
      return IDLE_WAITING_TIME;
    }

    UserTransaction trans = m_ctx.getUserTransaction();;
    try {
      trans.begin();
      ConnectionInterface con = DbHelper.getConnection();
      long wait_time = deliverOneTask(queue, con);
      // con.commit();
      trans.commit();
      return wait_time;
    } catch (VpsException e) {
      try {
        trans.rollback();
      } catch (Exception e2) {
      }
      throw e;
    } catch (Exception e) {
      try {
        trans.rollback();
      } catch (Exception e2) {
      }
      throw new SubmitException(e);
    }
  }

  public long deliverTransientTask(TaskQueue queue) throws VpsException {
    if (!Config.getBooleanProperty("vps.vps", "vps.transient.enabled", Boolean.TRUE)) {
      return IDLE_WAITING_TIME;
    }

    if (Dispatcher.isWLSBusy()) {
      LogHelper.warn("Warning: VPS WebLogic execution pool is busy");
      return IDLE_WAITING_TIME;
    }

    return deliverOneTask(queue, null);
  }

  private long deliverOneTask(ITaskQueue queue, ConnectionInterface con) throws VpsException {
    try {
      ScheduledTask task = null;
      if ((task = queue.peek(con)) == null)
        return IDLE_WAITING_TIME;

      long timeToExecuteFirstTask = task.scheduledExecutionTime - System.currentTimeMillis();
      if (timeToExecuteFirstTask <= 0) {
        LogHelper.info("TaskDeliver: remove from pending queue: " + task.m_task);
        if (queue.remove(con))
          task.m_task.deliver();
      }
      return (timeToExecuteFirstTask > IDLE_WAITING_TIME ? IDLE_WAITING_TIME : timeToExecuteFirstTask);
    } catch (Exception e) {
      throw new SubmitException(e);
    }
  }

  public void initLocalHome() throws RemoteException {
    String TASK_DELIVER_JNDI = "enterprise.TaskDeliverLocal";
    EJBLocalHomeFactory.getFactory().lookUpHome(TASK_DELIVER_JNDI, TASK_DELIVER_JNDI);
  }

  public void setSessionContext(SessionContext ctx) throws javax.ejb.EJBException {
    m_ctx = ctx;
  }

  public void ejbCreate() throws javax.ejb.EJBException {
  }

  public void ejbRemove() throws javax.ejb.EJBException {
  }

  public void ejbActivate() throws javax.ejb.EJBException {
  }

  public void ejbPassivate() throws javax.ejb.EJBException {
  }
}
