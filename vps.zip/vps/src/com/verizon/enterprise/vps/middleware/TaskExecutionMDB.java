package com.verizon.enterprise.vps.middleware;

import javax.ejb.EJBException;
import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import com.verizon.enterprise.vps.core.ExecutionTask;
import com.verizon.enterprise.vps.util.LogHelper;

public class TaskExecutionMDB implements MessageDrivenBean, MessageListener {
  private static final long serialVersionUID = 2821516552281564435L;
  private MessageDrivenContext mdc;

  public void onMessage(Message inMessage) {
    ExecutionTask msg = null;

    try {
      if (inMessage instanceof ObjectMessage) {
        msg = (ExecutionTask)((ObjectMessage)inMessage).getObject();
        LogHelper.info("TaskExecutionMDB: task received: " + msg);
        if (msg != null)
          msg.execute();
      } else {
        LogHelper.info("TaskExecutionMDB: Message of wrong type: " + inMessage.getClass().getName());
      }
    } catch (JMSException e) {
      LogHelper.error("Error in MDB Execution, rollback transaction.", e);
      mdc.setRollbackOnly();
    } catch (Exception e) {
      // exception from execution should have already been loged.
      LogHelper.info(e);
    } catch (Throwable e) {
      LogHelper.error("Error in MDB Execution.", e);
    }
  }

  public void ejbCreate() {
  }

  public void ejbRemove() {
  }

  public void setMessageDrivenContext(MessageDrivenContext ctx) throws EJBException {
    mdc = ctx;
  }
}
