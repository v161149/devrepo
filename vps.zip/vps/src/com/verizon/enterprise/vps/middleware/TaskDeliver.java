package com.verizon.enterprise.vps.middleware;

import javax.ejb.EJBObject;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.RemoveException;
import javax.ejb.Handle;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import com.verizon.enterprise.vps.core.ITaskQueue;
import com.verizon.enterprise.vps.core.TaskDBQueue;
import com.verizon.enterprise.vps.core.TaskQueue;
import com.verizon.enterprise.vps.dataobjects.VpsException;

public interface TaskDeliver extends EJBObject
{
  /**
   * A hack to resolve that JDNI lookup for local interface from Startup class
   * failing in WLS 7.
   *
   * @throws RemoteException
   */
    public void initLocalHome() throws RemoteException;
}
