package  com.verizon.enterprise.vps.middleware.ejb.dataAccess;

// Java imports
import java.rmi.RemoteException;
import java.util.Collection;
import javax.ejb.EJBObject;

// verizon imports
import com.verizon.enterprise.vps.ui.dataobjects.MonitorSummary;

/**
 * Description : define ApsDataAccess sessionBean Remote Interface
 *
 * Modificaions: 09/17/2003 - Gang Fu - Created
 * Copyright (C) Verizon Communications 2003
 */

public interface ApsDataAccess extends EJBObject
{
    /**
     * @return monitor summary info
     * @author Gang Fu
     */
    public MonitorSummary getMonitorSummary()
        throws RemoteException;

    /**
     * @param num is the num of record to retrieve
     *        if num <= 0, retrieve all records
     * @return num of most recent history
     * @author Gang Fu
     */
	public Collection getHistory(int num)
        throws RemoteException;

    /**
     * @param num is the num of record to retrieve
     *        if num <= 0, retrieve all records
     * @return num of most recent current jobs
     * @author Gang Fu
     */
	public Collection getCurrent(int num)
        throws RemoteException;
}
