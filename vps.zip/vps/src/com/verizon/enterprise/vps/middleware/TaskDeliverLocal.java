package com.verizon.enterprise.vps.middleware;

import javax.ejb.EJBLocalObject;

import com.verizon.enterprise.vps.core.TaskDBQueue;
import com.verizon.enterprise.vps.core.TaskQueue;
import com.verizon.enterprise.vps.dataobjects.VpsException;

public interface TaskDeliverLocal extends EJBLocalObject {
  public long deliverPersistentTask(TaskDBQueue queue) throws VpsException;

  public long deliverTransientTask(TaskQueue queue) throws VpsException;
}
