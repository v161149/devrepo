package  com.verizon.enterprise.vps.middleware.ejb.dataAccess;

// Java imports
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
import javax.sql.DataSource;

// Framework imports
import com.sapient.framework.ejb.SessionBeanAdapter;

// verizon imports
import com.verizon.enterprise.vps.ui.dataobjects.MonitorSummary;
import com.verizon.enterprise.vps.util.VpsLocalCache;
import com.verizon.enterprise.vps.middleware.jdbc.DataAccessWrapper;

import org.apache.log4j.Logger;

/**
 * Description : implement ApsDataAccess sessionBean Remote Interface
 *
 * Modificaions: 09/17/2003 - Gang Fu - Created
 * Copyright (C) Verizon Communications 2003
 */

public class ApsDataAccessBean extends SessionBeanAdapter
{
    private static Logger log = Logger.getLogger(ApsDataAccessBean.class);

    /**
     *  ejb creation
     *  @author Gang Fu
     */
    public void ejbCreate()
    {
    }

    /**
     * empty body for session bean
     * @author Gang Fu
     */
    public void ejbRemove()
    {
    }


    /**
     * @return monitor summary info
     * @author Gang Fu
     */
    public MonitorSummary getMonitorSummary()
        throws RemoteException
    {
        final String METHOD_NAME = "getMonitorSummary()";
        log.debug("enter: " + METHOD_NAME);

        MonitorSummary summary = null;

        Statement stmt = null;
        Connection con = null;
        try
        {
            DataSource ds = VpsLocalCache.getDataSource();
            if (ds != null)
            {
                con = ds.getConnection();
                if (con != null)
                    stmt = con.createStatement();
            }

            log.info("stmt = " + stmt);
            summary = DataAccessWrapper.getSummary(stmt);
        }
        catch (Exception e)
        {
            throw new RemoteException("Unable to get summary data", e);
        }
        finally
        {
            try
            {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            }
            catch (SQLException e1)
            {
                log.error("Unable to close connection: " + e1);
            }
        }

        log.debug("exit: " + METHOD_NAME);
        return summary;
    }

    /**
     * @param num is the num of record to retrieve
     *        if num <= 0, retrieve all records
     * @return num of most recent history
     * @author Gang Fu
     */
    public Collection getHistory(int num)
        throws RemoteException
    {
        final String METHOD_NAME = "getHistory()";
        log.debug("enter: " + METHOD_NAME);
        Collection history = new ArrayList();

        Statement stmt = null;
        Connection con = null;
        try
        {
            DataSource ds = VpsLocalCache.getDataSource();
            if (ds != null)
            {
                con = ds.getConnection();
                if (con != null)
                    stmt = con.createStatement();
            }

            log.info("stmt = " + stmt);
            history.addAll(DataAccessWrapper.getHistory(stmt, num));
        }
        catch (Exception e)
        {
            throw new RemoteException("Unable to get history data.", e);
        }
        finally
        {
            try
            {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            }
            catch (SQLException e1)
            {
                log.error("Unable to close connection: " + e1);
            }
        }

        log.debug("exit: " + METHOD_NAME);
        return history;
    }

    /**
     * @param num is the num of record to retrieve
     *        if num <= 0, retrieve all records
     * @return num of most recent current jobs
     * @author Gang Fu
     */
    public Collection getCurrent(int num)
        throws RemoteException
    {
        final String METHOD_NAME = "getCurrent()";
        log.debug("enter: " + METHOD_NAME);

        Collection current = new ArrayList();

        Statement stmt = null;
        Connection con = null;
        try
        {
            DataSource ds = VpsLocalCache.getDataSource();
            if (ds != null)
            {
                con = ds.getConnection();
                if (con != null)
                    stmt = con.createStatement();
            }

            log.info("stmt = " + stmt);
            current.addAll(DataAccessWrapper.getCurrent(stmt, num));
        }
        catch (Exception e)
        {
            throw new RemoteException("Unable to get current data.", e);
        }
        finally
        {
            try
            {
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            }
            catch (SQLException e1)
            {
                log.error("Unable to close connection: " + e1);
            }
        }

        log.debug("exit: " + METHOD_NAME);
        return current;
    }
}
