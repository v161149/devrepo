package  com.verizon.enterprise.vps.middleware.ejb.dataAccess;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import java.rmi.RemoteException;

/**
 * <p>Simple Home interface for the ApsDataAccessHome stateless
 * session bean. Implements the one required create method with no
 * parameters.</p>
 *
 * Modificaions: 09/17/2003 - Gang Fu - Created
 * Copyright (C) Verizon Communications 2003
 */

public interface ApsDataAccessHome extends EJBHome
{
    /**
     * Standard stateless session EJB create method.
     */
    ApsDataAccess create() throws RemoteException, CreateException;
}
