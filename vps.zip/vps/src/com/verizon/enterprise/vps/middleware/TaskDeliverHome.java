package com.verizon.enterprise.vps.middleware;

import javax.ejb.EJBHome;
import javax.ejb.RemoveException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import java.rmi.RemoteException;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

public interface TaskDeliverHome extends EJBHome
{
    public TaskDeliver create() throws CreateException, RemoteException;
}
