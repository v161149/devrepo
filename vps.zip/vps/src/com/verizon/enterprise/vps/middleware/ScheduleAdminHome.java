package com.verizon.enterprise.vps.middleware;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * Simple home interface for session beans
 */
public interface ScheduleAdminHome extends EJBHome {
    /**
     * Create
     */
    ScheduleAdmin create() throws CreateException, RemoteException;
}
