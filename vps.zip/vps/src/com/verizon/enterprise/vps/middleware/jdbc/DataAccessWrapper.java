package com.verizon.enterprise.vps.middleware.jdbc;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Hashtable;
import java.text.SimpleDateFormat;

import com.verizon.enterprise.vps.ui.dataobjects.MonitorSummary;
import com.verizon.enterprise.vps.ui.dataobjects.MonitorTaskItem;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;

import org.apache.log4j.Logger;

public class DataAccessWrapper
{
    private static Logger log = Logger.getLogger(DataAccessWrapper.class);
    static SimpleDateFormat dateFormater
        = new SimpleDateFormat ("yyyy-MM-dd hh:MI:ss.zzz");
    static final int ROW_NUM = 100;
    /**
     * get summary data
     * @author Gang Fu
     */
    public static MonitorSummary getSummary(Statement stmt) throws SQLException
    {
        final String METHOD_NAME = "getSummary()";
        log.debug("enter: " + METHOD_NAME);

        MonitorSummary summary = new MonitorSummary();

        String sql = "select count(*) from esg.pending_task where status = '" +
            IVpsTask.EXECUTING + "'" + dateFilterAnd("");
        log.info(" get running task count, sql = " + sql);
        ResultSet rs = stmt.executeQuery(sql);
        if (rs.next())
            summary.setRunningTaskCount(rs.getString(1));

        sql = "select count(*) from esg.pending_task where status = '" +
            IVpsTask.PENDING + "'" + dateFilterAnd("");
        log.info(" get pending task count, sql = " + sql);
        rs = stmt.executeQuery(sql);
        if (rs.next())
            summary.setPendingTaskCount(rs.getString(1));

        sql = "select count(*) from esg.task_instance where " + dateFilter("");
        log.info(" get finished task count, sql = " + sql);
        rs = stmt.executeQuery(sql);
        if (rs.next())
            summary.setFinishedTaskCount(rs.getString(1));

        log.debug("exit: " + METHOD_NAME);
        return summary;
    }

    /**
     * get current data
     * @author Gang Fu
     */
    public static Collection getCurrent(Statement stmt, int num) throws SQLException
    {
        final String METHOD_NAME = "getCurrent()";
        log.debug("enter: " + METHOD_NAME);

        StringBuffer sqlBuf = new StringBuffer();

        sqlBuf.append("select jobid, taskdescription, schedulestart, scheduleend, ");
        sqlBuf.append("status, starttime, endtime, userid  from (");
        sqlBuf.append("select j.name as taskdescription, ");
        sqlBuf.append("j.job_schedule_def_oid as jobid, ");
        sqlBuf.append("to_char(j.effective_start_time,'YYYY-MM-DD HH24:MI:SS') as schedulestart, ");
        sqlBuf.append("to_char(j.effective_stop_time,'YYYY-MM-DD HH24:MI:SS') as scheduleend, ");
        sqlBuf.append("p.status as status, ");
        sqlBuf.append("' ' as endtime, ");
        sqlBuf.append("to_char(p.execute_time,'YYYY-MM-DD HH24:MI:SS') as starttime, ");
        sqlBuf.append("p.user_id as userid ");
        sqlBuf.append("from esg.job_schedule_def j, esg.pending_task p ");
        sqlBuf.append("where j.job_schedule_def_oid = p.job_schedule_def_oid ");
        sqlBuf.append(dateFilterAnd("p."));
        sqlBuf.append(" order by p.execute_time desc) where rownum <= " + ROW_NUM);

        log.info("sql = " + sqlBuf);

        //Hashtable currentTasks = new Hashtable();
        Collection current = new ArrayList();

        ResultSet rs = stmt.executeQuery(sqlBuf.toString());
        MonitorTaskItem task, temp;
        int executionCount;
        while (rs.next())
        {
            task = getTaskItem(rs);
            /*
            if (currentTasks.containsKey(task.getJobId()))
            {
                temp = (MonitorTaskItem)currentTasks.get(task.getJobId());
                executionCount = Integer.parseInt(temp.getExecutionCount());
                executionCount++;
                log.info("executionCount increamented, executionCount = " + executionCount);
                temp.setExecutionCount("" + executionCount);
            }
            else
                currentTasks.put(task.getJobId(), task);
            */
           current.add(task);
        }

        log.debug("exit: " + METHOD_NAME);
        //return currentTasks.values();
        return current;
    }

    /**
     * get current data
     * @author Gang Fu
     */
    public static Collection getHistory(Statement stmt, int num) throws SQLException
    {
        final String METHOD_NAME = "getHistory()";
        log.debug("enter: " + METHOD_NAME);

        StringBuffer sqlBuf = new StringBuffer();

        sqlBuf.append("select jobid, taskdescription, schedulestart, scheduleend, ");
        sqlBuf.append("status, starttime, endtime, userid  from (");
        sqlBuf.append("select j.job_schedule_def_oid as jobid, ");
        sqlBuf.append("j.name as taskdescription, ");
        sqlBuf.append("to_char(j.effective_start_time,'YYYY-MM-DD HH24:MI:SS') as schedulestart, ");
        sqlBuf.append("to_char(j.effective_stop_time,'YYYY-MM-DD HH24:MI:SS') as scheduleend, ");
        sqlBuf.append("t.status as status, ");
        sqlBuf.append("to_char(t.start_time,'YYYY-MM-DD HH24:MI:SS') as starttime, ");
        sqlBuf.append("to_char(t.end_time,'YYYY-MM-DD HH24:MI:SS') as endtime, ");
        sqlBuf.append("t.user_id as userid ");
        sqlBuf.append("from esg.job_schedule_def j, esg.task_instance t ");
        sqlBuf.append("where j.job_schedule_def_oid = t.job_ref_oid ");
        sqlBuf.append(dateFilterAnd("t."));
        sqlBuf.append(" order by t.start_time desc) where rownum <= " + ROW_NUM);

        log.info("sql = " + sqlBuf);

        Hashtable historyTasks = new Hashtable();
        Collection history = new ArrayList();

        ResultSet rs = stmt.executeQuery(sqlBuf.toString());
        MonitorTaskItem task, temp;
        int executionCount;
        while (rs.next())
        {
            task = getTaskItem(rs);
            /*
            if (historyTasks.containsKey(task.getJobId()))
            {
                temp = (MonitorTaskItem)historyTasks.get(task.getJobId());
                executionCount = Integer.parseInt(temp.getExecutionCount());
                executionCount++;
                log.info("executionCount increamented, executionCount = " + executionCount);
                temp.setExecutionCount("" + executionCount);
            }
            else
                historyTasks.put(task.getJobId(), task);
            */
            history.add(task);

        }

        log.debug("exit: " + METHOD_NAME);
        //return historyTasks.values();
        return history;
    }

    static String dateFilter(String tablePrefix)
    {
        StringBuffer buf = new StringBuffer();
        buf.append(" trunc(");
        buf.append(tablePrefix);
        buf.append("timestamp) between trunc(sysdate-7) and trunc(sysdate) ");
        log.info("dateFilter = " + buf);

        return buf.toString();
    }

    static String dateFilterAnd(String tablePrefix)
    {
        StringBuffer buf = new StringBuffer();
        buf.append(" and ");
        buf.append(dateFilter(tablePrefix));
        log.info("dateFilter = " + buf);

        return buf.toString();
    }

    static MonitorTaskItem getTaskItem(ResultSet rs) throws SQLException
    {
        MonitorTaskItem task = new MonitorTaskItem();
        Date date;

        task.setJobId(rs.getString("JobId"));
        task.setTaskDescription(rs.getString("TaskDescription"));
        task.setUserId(rs.getString("UserId"));
        task.setStatus(rs.getString("Status"));
        task.setScheduleStart(rs.getString("ScheduleStart"));
        task.setScheduleEnd(rs.getString("ScheduleEnd"));
        task.setStartTime(rs.getString("StartTime"));
        task.setEndTime(rs.getString("EndTime"));

        return task;
    }
}