package com.verizon.enterprise.vps.middleware;

import java.util.*;
import java.rmi.RemoteException;
import javax.ejb.EJBObject;

import com.verizon.enterprise.vps.dataobjects.IVpsPersistentTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;

/**
 * Remote schedule admin interface of EJB.
 * @author Zhong Chen
 */
public interface ScheduleAdmin extends EJBObject {
    /**
     * Create a job schedule in memory only. Job will not surrive JVM shutdown.
     * @param task Task information.
     * @param schedule Schedule information.
     * @param nUserId User OID.
     * @return Newly created database object.
     */
    public void scheduleTransientTask(
        IVpsPersistentTask task,
        ISchedule schedule,
        Long nUserId)
            throws VpsException, RemoteException;

    /**
     * Create a job schedule in database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @param nUserId User OID.
     * @return Newly created database object.
     */
    public JobScheduleDefObject schedulePersistentJob(
        IVpsPersistentTask task,
        ISchedule schedule,
        Long nUserId)
        throws VpsScheduleException, RemoteException;

    /**
     * Remove a job schedule (and its pending tasks) from database.
     * @param scheduleObject Schedule information.
     * @param nUserId User OID.
     * @return Newly created database object.
     */
    public void unschedulePersistentJob(JobScheduleDefObject scheduleObject,
                                        Long nUserId,
                                        boolean bRemoveScheduleFromDB)
        throws VpsScheduleException, RemoteException;

    /**
     * Update a job schedule (and its pending tasks) from database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @param scheduleObject JobScheduleDefObject object.
     * @param nUserId User OID.
     * @return updated database object.
     */
    public JobScheduleDefObject updatePersistentJob(IVpsPersistentTask task,
        ISchedule schedule,
        JobScheduleDefObject scheduleObject,
        Long nUserId)
        throws VpsScheduleException, RemoteException;

    /**
     * Retrieves the List of ScheduleJobInfo objects corresponding to this condition
     * @param ScheduleName
     * @return List - List of ScheduleJobInfo objects
     * @throws VpsScheduleException
     * @throws RemoteException
     */
    public Set getScheduleList(String condition) throws VpsScheduleException, RemoteException;

    /**
     * Retrieves the List of JobScheduleDefObject objects corresponding to this condition
     * @param ScheduleName
     * @return List - List of JobScheduleDefObject objects
     * @throws VpsScheduleException
     * @throws RemoteException
     */
    public List getSchedules(String condition) throws VpsScheduleException, RemoteException;

    /**
     * Retrieves the List of TaskInstance objects corresponding to this condition
     * @param condition
     * @return List - List of TaskInstance objects
     * @throws VpsScheduleException
     * @throws RemoteException
     */
    public List getTaskInstanceList(String condition) throws VpsScheduleException, RemoteException;

    /**
     * Deletes TaskInstance object
     * @param taskObject
     * @throws VpsScheduleException
     * @throws RemoteException
     */
    public void deleteTaskInstance(TaskInstanceObject taskObject) throws VpsScheduleException, RemoteException;
	
}
