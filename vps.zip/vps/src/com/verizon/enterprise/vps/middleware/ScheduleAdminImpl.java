package com.verizon.enterprise.vps.middleware;

import java.sql.Connection;

import com.verizon.kernel.jdbc.ConnectionInterface;
import com.verizon.kernel.exception.DatalayerException;

import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.IVpsPersistentTask;
import com.verizon.enterprise.vps.dataobjects.VpsException;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.enterprise.vps.dataobjects.VpsException;

import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.enterprise.vps.util.LogHelper;

import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.db.SchedulePersister;
import com.verizon.enterprise.vps.schedule.*;

import java.util.Set;
import java.util.List;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: Wrapper class for application to access all scheduling functions.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

class ScheduleAdminImpl {
    // Database schema source
    private Long   m_nUserId = null;

    /**
     * Constructor.
     */
    public ScheduleAdminImpl() {
        setUserId(null);
    }

    /**
     * Constructor.
     * @param sSchema Database schema for job schedule persistence.
     * @param nUserId Id of user who is managing the schedule.
     */
    public ScheduleAdminImpl(Long nUserId) {
        setUserId(nUserId);
    }

    /**
     * Get user id.
     */
    public Long getUserId() {return m_nUserId;}

    /**
     * Set user id.
     */
    public void setUserId(Long uid) {
        m_nUserId = (uid==null ? new Long(0) : uid);
    }

    /**
     * Submit an in-memory schedule.
     * Schedule will be cancelled when current JVM exits.
     */
    public void scheduleTransientJob(IVpsTask task, ISchedule schedule) throws VpsException {
        ScheduleManager.scheduleTransientJob(task, schedule, getUserId());
    }

    /**
     * Submit a persistent schedule.
     * Job schedule is saved in database and will be active whenever
     * server is up.
     */
    public JobScheduleDefObject schedulePersistentJob(ConnectionInterface conn,
                                                      IVpsPersistentTask task,
                                                      ISchedule schedule) throws VpsScheduleException {
        SchedulePersister sp = new SchedulePersister(getUserId());
        return sp.createSchedule(conn, task, schedule);
    }

    /**
     * Remove a job schedule (and its pending tasks) from database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @return Newly created database object.
     */
    public void unschedulePersistentTask(ConnectionInterface conn,
                                         JobScheduleDefObject scheduleObject,
                                         boolean bRemoveScheduleFromDB) throws VpsScheduleException {
        SchedulePersister sp = new SchedulePersister(getUserId());
        sp.removeSchedule(conn, scheduleObject, bRemoveScheduleFromDB);
    }

    /**
     * Update a persistent schedule (and its pending tasks) in the database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @param jsdo Existing JobScheduleDefObject object.
     * @return Updated database object.
     */
    public JobScheduleDefObject updatePersistentJob(ConnectionInterface conn,
						    IVpsPersistentTask task,
						    ISchedule schedule, JobScheduleDefObject jsdo) throws VpsScheduleException {
        SchedulePersister sp = new SchedulePersister(getUserId());
        return sp.updateSchedule(conn, task, schedule, jsdo);
    }

    /**
     * Retrieves the List of ScheduleJobInfo objects corresponding to this condition
     * @param ScheduleName
     * @return List - List of ScheduleJobInfo objects
     * @throws VpsScheduleException
     * @throws RemoteException
     */
    public Set getScheduleList(ConnectionInterface conn,String condition) throws VpsScheduleException
    {
      SchedulePersister sp = new SchedulePersister(getUserId());
      return sp.getScheduleList(conn, condition);

    }

    public List getSchedules(ConnectionInterface conn,String condition) throws VpsScheduleException
    {
      SchedulePersister sp = new SchedulePersister(getUserId());
      return sp.getSchedules(conn, condition);

    }

    public List getTaskInstanceList(ConnectionInterface conn, 
			       String condition) throws VpsScheduleException {
	SchedulePersister sp = new SchedulePersister(getUserId());
	return sp.getTaskInstanceList(conn, condition);

    }

    public void deleteTaskInstance(ConnectionInterface conn,
				   TaskInstanceObject taskObject) throws VpsScheduleException {

        SchedulePersister sp = new SchedulePersister(getUserId());
        sp.deleteTaskInstance(conn, taskObject);
    }
}



