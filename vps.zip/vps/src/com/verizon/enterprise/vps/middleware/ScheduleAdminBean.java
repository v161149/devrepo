package com.verizon.enterprise.vps.middleware;

import java.util.*;
import java.sql.*;
import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.verizon.kernel.jdbc.ConnectionInterface;
import com.verizon.kernel.exception.DatalayerException;

import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.enterprise.vps.util.LogHelper;

import com.verizon.enterprise.vps.db.SchedulePersister;
import com.verizon.enterprise.vps.dataobjects.IVpsPersistentTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;
import com.verizon.enterprise.vps.dataobjects.VpsException;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;

/**
 * Schedule admin session beans
 * @author Zhong Chen
 */
public class ScheduleAdminBean implements SessionBean {
    // Data members
    private static final String BEAN_NAME = "ScheduleAdmin";
    private SessionContext m_ctx;
    private long m_nStartTime = 0;

    /** error */
    private void error(String sMsg) {
        LogHelper.error(BEAN_NAME + ": " + sMsg);
    }

    /** info*/
    private void info(String sMsg) {
        LogHelper.info(BEAN_NAME + ": " + sMsg);
    }

    /** debug */
    private void debug(String sMsg) {
        LogHelper.debug(BEAN_NAME + ": " + sMsg);
    }

    /** start timing */
    private void startTime() {
        m_nStartTime = System.currentTimeMillis();
    }

    /** stop timing */
    private void stopTime(String sRequest) {
        long nStopTime = System.currentTimeMillis();
        info("Request " + sRequest + " took " + (nStopTime - m_nStartTime) +
             " ms.");
    }

    //------------------------ EJB OBLIGATIONS --------------------------------

    /**
     * EJB create
     */
    public void ejbCreate() throws CreateException {
        debug("ejbCreate called");
    }

    /**
     * This method is required by the EJB Specification,
     * but is not used by this example.
     *
     */
    public void ejbActivate() {
        debug("ejbActivate called");
    }

    /**
     * This method is required by the EJB Specification,
     * but is not used by this example.
     *
     */
    public void ejbRemove() {
        debug("ejbRemove called");
    }

    /**
     * This method is required by the EJB Specification,
     * but is not used by this example.
     *
     */
    public void ejbPassivate() {
        debug("ejbPassivate called");
    }

    /**
     * Sets the session context.
     *
     * @param ctx               SessionContext Context for session
     */
    public void setSessionContext(SessionContext ctx) {
        debug("setSessionContext called");
        m_ctx = ctx;
    }

    //-------------------------------------------------------------------------

    /**
     * Create a job schedule in memory only. Job will not surrive JVM shutdown.
     * @param task Task information.
     * @param schedule Schedule information.
     * @param nUserId User OID.
     * @return Newly created database object.
     */
    public void scheduleTransientTask(
        IVpsPersistentTask task,
        ISchedule schedule,
        Long nUserId)
            throws VpsException {
        debug("scheduleTransientTask is called in bean.");
        startTime();

        try {
            ScheduleAdminImpl sm = new ScheduleAdminImpl();
            sm.setUserId(nUserId);
            sm.scheduleTransientJob(task, schedule);
        }
        finally {
            stopTime("scheduleTransientTask");
        }

        return;
    }

    /**
     * Create a job schedule in database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @return Newly created database object.
     */
    public JobScheduleDefObject schedulePersistentJob(IVpsPersistentTask task,
                                                      ISchedule schedule,
                                                      Long nUserId)
        throws VpsScheduleException {
        debug("schedulePersistentJob is called in bean.");
        startTime();

        JobScheduleDefObject jsdo = null;
        ConnectionInterface conn = null;
        boolean bCommit = false;

        try {
            conn = DbHelper.getConnection();

            ScheduleAdminImpl sm = new ScheduleAdminImpl();
            sm.setUserId(nUserId);
            jsdo = sm.schedulePersistentJob(conn, task, schedule);
            bCommit = true;
        }
        catch (DatalayerException de) {
            throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
        }
        finally {
            if (conn != null) {
                try {
                    if (bCommit)
                        conn.commit();
                    else
                        conn.rollback();
                    conn.close();
                }
                catch (Exception ex) {
                    error("SQL error: " + ex);
                }
            }
            stopTime("schedulePersistentJob");
        }

        return jsdo;
    }

    /**
     * Remove a job schedule (and its pending tasks) from database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @return Newly created database object.
     */
    public void unschedulePersistentJob(JobScheduleDefObject scheduleObject,
                                        Long nUserId,
                                        boolean bRemoveScheduleFromDB)
        throws VpsScheduleException {
        debug("unschedulePersistentJob is called in bean.");
        startTime();

        ConnectionInterface conn = null;
        boolean bCommit = false;

        try {
            conn = DbHelper.getConnection();

            ScheduleAdminImpl sm = new ScheduleAdminImpl();
            sm.setUserId(nUserId);
            sm.unschedulePersistentTask(conn, scheduleObject, bRemoveScheduleFromDB);
            bCommit = true;
        }
        catch (DatalayerException de) {
            throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
        }
        finally {
            if (conn != null) {
                try {
                    if (bCommit)
                        conn.commit();
                    else
                        conn.rollback();
                    conn.close();
                }
                catch (Exception ex) {
                    error("SQL error: " + ex);
                }
            }
            stopTime("unschedulePersistentJob");
        }

        return;
    }

    /**
     * Update a job schedule (and its pending tasks) from database.
     * @param task Task information.
     * @param schedule Schedule information.
     * @param jsd JobScheduleDefObject object.
     * @return Updated database object.
     */
    public JobScheduleDefObject updatePersistentJob(IVpsPersistentTask task,
                                                    ISchedule schedule,
                                                    JobScheduleDefObject jsd,
                                                    Long nUserId)
                                                    throws VpsScheduleException {
        debug("updatePersistentJob is called in bean.");
        startTime();

        JobScheduleDefObject jsdo = null;
        ConnectionInterface conn = null;
        boolean bCommit = false;

        try {
            conn = DbHelper.getConnection();

            ScheduleAdminImpl sm = new ScheduleAdminImpl();
            sm.setUserId(nUserId);
            jsdo = sm.updatePersistentJob(conn, task, schedule, jsd);
            bCommit = true;
        }
        catch (DatalayerException de) {
            throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
        }
        finally {
            if (conn != null) {
                try {
                    if (bCommit)
                        conn.commit();
                    else
                        conn.rollback();
                    conn.close();
                }
                catch (Exception ex) {
                    error("SQL error: " + ex);
                }
            }
            stopTime("updatePersistentJob");
        }

        return jsdo;
    }

    /**
     * Retrieves the List of ScheduleJobInfo objects corresponding  to this condition
     * @param ScheduleName
     * @return List - List of ScheduleJobInfo objects
     * @throws VpsScheduleException
     */
    public Set getScheduleList(String condition) throws VpsScheduleException
    {
      debug("getScheduleList is called in bean.");
      startTime();

      Set list =null;
      ConnectionInterface conn = null;
      boolean bCommit = false;

      try {
          conn = DbHelper.getConnection();

          ScheduleAdminImpl sm = new ScheduleAdminImpl();
          list = sm.getScheduleList(conn, condition);
          bCommit = true;
      }
      catch (DatalayerException de) {
          throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
      }
      finally {
          if (conn != null) {
              try {
                  if (bCommit)
                      conn.commit();
                  else
                      conn.rollback();
                  conn.close();
              }
              catch (Exception ex) {
                  error("SQL error: " + ex);
              }
          }
          stopTime("getScheduleList");
      }
      return list;

    }


    /**
     * Retrieves the List of ScheduleJobInfo objects corresponding  to this condition
     * @param ScheduleName
     * @return List - List of ScheduleJobInfo objects
     * @throws VpsScheduleException
     */
    public List getSchedules(String condition) throws VpsScheduleException
    {
      debug("getSchedules is called in bean.");
      startTime();

      List list = null;
      ConnectionInterface conn = null;
      boolean bCommit = false;

      try {
          conn = DbHelper.getConnection();

          ScheduleAdminImpl sm = new ScheduleAdminImpl();
          list = sm.getSchedules(conn, condition);
          bCommit = true;
      }
      catch (DatalayerException de) {
          throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
      }
      finally {
          if (conn != null) {
              try {
                  if (bCommit)
                      conn.commit();
                  else
                      conn.rollback();
                  conn.close();
              }
              catch (Exception ex) {
                  error("SQL error: " + ex);
              }
          }
          stopTime("getSchedules");
      }
      return list;

    }




    public List getTaskInstanceList(String condition) throws VpsScheduleException {
	debug("getTaskInstanceList is called in bean.");
	startTime();

	List list =null;
	ConnectionInterface conn = null;
	boolean bCommit = false;

	try {
	    conn = DbHelper.getConnection();
	    ScheduleAdminImpl sm = new ScheduleAdminImpl();
	    list = sm.getTaskInstanceList(conn, condition);
	    bCommit = true;
	}
	catch (DatalayerException de) {
	    throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
	}
	finally {
	    if (conn != null) {
		try {
		    if (bCommit)
			conn.commit();
		    else
			conn.rollback();
		    conn.close();
		}
		catch (Exception ex) {
		    error("SQL error: " + ex);
		}
	    }
	    stopTime("getTaskInstanceList");
	}
	return list;

    }

    public void deleteTaskInstance(TaskInstanceObject taskObject) throws VpsScheduleException{

	debug("deleteTaskInstance is called in bean.");
	startTime();

	ConnectionInterface conn = null;
	boolean bCommit = false;

	try {
	    conn = DbHelper.getConnection();
	    ScheduleAdminImpl sm = new ScheduleAdminImpl();
	    sm.deleteTaskInstance(conn, taskObject);
	    bCommit = true;
	}
	catch (DatalayerException de) {
	    throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, de.getMessage());
	}
	finally {
	    if (conn != null) {
		try {
		    if (bCommit)
			conn.commit();
		    else
			conn.rollback();
		    conn.close();
		}
		catch (Exception ex) {
		    error("SQL error: " + ex);
		}
	    }
	    stopTime("getTaskInstanceList");
	}

    }


}
