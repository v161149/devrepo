package com.verizon.enterprise.vps.schedule;

import java.util.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Amanjot Khaira
 * @version 1.0
 */

public class MonthlyScheduleByDate extends TimeOfDaySchedule
{
  /**
   * variable to store the date information fot this job
   * it can be specified as negative also for relative end of month dates e.g
   * last day of month, date = -1
   * second last day of month ,date = -2
   */
  private int date;

  public MonthlyScheduleByDate()
  {
  }

  public MonthlyScheduleByDate(Calendar date)
  {
    super(date);
    //this way you cannot specify relative end of month dates. e.g date = -1
    this.date = date.get(Calendar.DATE);
  }

  public Date getFirstAvailableDay(Date now, Date start, Date end)
  {
    long nNow = now.getTime();
    long nStartEffective = (start == null ? -1 : start.getTime());
    long nEndEffective = (end == null ? -1 : end.getTime());

    if (nEndEffective < nNow && nEndEffective > 0)
    {
      // No longer needed.
      return null;
    }

    // find the date in range first.
    Date firstDay;
    if (nStartEffective < nNow)
    {
      firstDay = new Date(nNow);
    }
    else
    {
      firstDay = new Date(nStartEffective);
    }

    Calendar cal = Calendar.getInstance();
    cal.setTime(firstDay);
    return findDate(cal);
  }

  public Date getNextAvailableDay(long nCurrentTime)
  {
    Calendar cal = Calendar.getInstance();
    cal.setTime(new Date(nCurrentTime));
    // Today is not the day.
    cal.add(Calendar.DATE, 1);
    return findDate(cal);
  }

  private Date findDate(Calendar cal)
  {
    if(this.date < 0) //for relative end of month dates
    {
      Calendar temp = Calendar.getInstance();
      temp.setTime(cal.getTime());
      while (true)
      {
        if (cal.get(Calendar.DATE) == 1)
        {
          cal.add(Calendar.DATE, this.date);
          //check if new date is earlier than the original date. e.g we could have current date as
          // 31 july and having date = -2 might make it july 30 instead of aug 30
          if(cal.before(temp))
          {
            cal.add(Calendar.DATE,-(this.date) + 1);
          }
          else
          {
            break;
          }
        }
        cal.add(Calendar.DATE, 1);
      }
    }
    else//for dates. e.g 15, 27 etc
    {
      while (true)
      {
        if (cal.get(Calendar.DATE) == this.date)
        {
          break;
        }
        cal.add(Calendar.DATE, 1);
      }
    }
    return cal.getTime();
  }

  public void parse(String sScheduleInfo) throws VpsScheduleException
    {
      try {
          if (!sScheduleInfo.startsWith(ScheduleParser.PNAME_MONTHLY_NTH_DAY)) {
              throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sScheduleInfo);
          }
          else if (sScheduleInfo.length() <= ScheduleParser.PNAME_MONTHLY_NTH_DAY.length()) {
              throw new VpsScheduleException(VpsScheduleException.INCOMPLETE_PATTERN_NAME, sScheduleInfo);
          }

          // Pattern should only have MON_N_DAY|date|HH:mm:ss info.
          String sPattern = sScheduleInfo.substring(ScheduleParser.PNAME_MONTHLY_NTH_DAY.length()+1);
          // Pattern should only have date|HH:mm:ss info.
          StringTokenizer st = new StringTokenizer(sPattern,ScheduleParser.PNAME_SEPARATOR);
          if(st.countTokens()!=2)
          {
            throw new VpsScheduleException(VpsScheduleException.INCOMPLETE_PATTERN_NAME, sScheduleInfo);
          }
          //store the date for this monthly job
          setDate(st.nextToken(),sScheduleInfo);

          Date time = ISchedule.DATE_FORMAT.parse("2000-01-01 " + st.nextToken());
          Calendar dailyTime = Calendar.getInstance();
          dailyTime.setTime(time);
          setDailyTime(dailyTime);
      }
      catch(VpsScheduleException v)
      {
        throw v;
      }
      catch(Exception e)
      {
        throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, e.getMessage() + sScheduleInfo);
      }
    }

    private void setDate (String date,String scheduleInfo) throws VpsScheduleException
    {
      try
      {
        this.date = Integer.parseInt(date);
        if(this.date > 31)
        {
          throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR,
                                         " Invalid date " + scheduleInfo);
        }
      }
      catch(NumberFormatException e)
      {
        throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR," Invalid date " + scheduleInfo);
      }
    }

    /**
     * Get schedule string.
     */
    public String getScheduleInfoString() throws VpsScheduleException {
        if (getDailyTime() != null) {
          Date time = getDailyTime().getTime();
          return ScheduleParser.PNAME_MONTHLY_NTH_DAY + ScheduleParser.PNAME_SEPARATOR
                + this.date + ScheduleParser.PNAME_SEPARATOR + ISchedule.DATE_FORMAT.format(time).substring(11);
        }
        else {
            return null;
        }
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("At ").append(getDailyTimeString());
        sb.append(" of every ");
        sb.append(this.date);
        sb.append(" day for each month");
        return sb.toString();
    }

}