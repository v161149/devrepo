package com.verizon.enterprise.vps.schedule;


/**
 * <p>Title: Virtual Process Service</p> <p>Description: </p> <p>Copyright:
 * Copyright (c) 2003</p> <p>Company: Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */

public class ScheduleParser {
  // Pattern
  public static final String PNAME_FIXED_RATE = "FIXED_RATE";
  public static final String PNAME_ONCE = "ONCE";
  public static final String PNAME_DAILY = "DAILY";
  public static final String PNAME_WEEKLY = "WEEKLY";
  public static final String PNAME_MONTHLY_NTH_DAY = "MONTHLY_NTH_DAY";
  public static final String PNAME_MONTHLY_NTH_WEEKDAY = "MONTHLY_NTH_WEEKDAY";
  public static final String PNAME_CRON_STYLE = "CRON";

  public static final String PNAME_SEPARATOR = "|";

  /** parse schedule string into ISchedule object */
  public static ISchedule parseSchedule(String sSchInfo) throws VpsScheduleException {
    if (sSchInfo == null || sSchInfo.length() <= 0) {
      throw new IllegalArgumentException("Invalid schedule infomation.");
    }

    int nPos = sSchInfo.indexOf(PNAME_SEPARATOR);
    if (nPos <= 0)
      nPos = sSchInfo.length();

    ISchedule schedule = null;
    String sPatternName = sSchInfo.substring(0, nPos);
    if (PNAME_DAILY.equalsIgnoreCase(sPatternName)) {
      schedule = new DailySchedule();
    } else if (PNAME_FIXED_RATE.equalsIgnoreCase(sPatternName)) {
      schedule = new FixedRateSchedule();
    } else if (PNAME_ONCE.equalsIgnoreCase(sPatternName)) {
      schedule = new OnceSchedule();
    } else if (PNAME_WEEKLY.equalsIgnoreCase(sPatternName)) {
      schedule = new WeeklySchedule();
    } else if (PNAME_MONTHLY_NTH_WEEKDAY.equalsIgnoreCase(sPatternName)) {
      schedule = new MonthlyScheduleByWeekday();
    } else if (PNAME_MONTHLY_NTH_DAY.equalsIgnoreCase(sPatternName)) {
      schedule = new MonthlyScheduleByDate();
    }

    // Delegate parsing to individual classes
    if (schedule != null) {
      schedule.parse(sSchInfo);
    } else {
      throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sSchInfo);
    }

    return schedule;
  }

}