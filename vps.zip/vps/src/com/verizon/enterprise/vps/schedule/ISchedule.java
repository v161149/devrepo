package com.verizon.enterprise.vps.schedule;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public interface ISchedule extends java.io.Serializable {
    public static final long MS_FOR_WEEK   = 7*24*3600000L;
    public static final long MS_FOR_DAY    = 24*3600000L;
    public static final long MS_FOR_HOUR   = 3600000L;
    public static final long MS_FOR_MINUTE = 60000L;

    // Name for week days
    public static final String WEEK_SUNDAY    = "SUN";
    public static final String WEEK_MONDAY    = "MON";
    public static final String WEEK_TUESDAY   = "TUE";
    public static final String WEEK_WEDNESDAY = "WED";
    public static final String WEEK_THURSDAY  = "THU";
    public static final String WEEK_FRIDAY    = "FRI";
    public static final String WEEK_SATURDAY  = "SAT";

    // Status
    public static final char STATUS_ACTIVE    = 'A';
    public static final char STATUS_INACTIVE  = 'I';

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * Get next running time in schedule.
     * @return Next running time. Null if not schedule is available any more.
     */
    public Date getTimeForNextSchedule();

    /**
     * Get next running time in schedule assuming current time as input.
     * @return Next running time. Null if not schedule is available any more.
     */
    public Date getTimeForNextSchedule(Date now);

    /**
     * Get the effective start time.
     */
    public Date getStartEffectiveTime();

    /**
     * Get the effective end time.
     */
    public Date getEndEffectiveTime();

    /**
     * Set the effective start time.
     */
    public void setStartEffectiveTime(Date st);

    /**
     * Set the effective end time.
     */
    public void setEndEffectiveTime(Date et);

    /**
     * Get the description.
     */
    public String getDescription();

    /**
     * Set the description.
     */
    public void setDescription(String sDesc);

    /**
     * Get name
     */
    public String getName();

    /**
     * Set name
     */
    public void setName(String sDesc);

    /**
     * Populate schedule info with string.
     */
    public void parse(String sScheduleInfo) throws VpsScheduleException;

    /**
     * Get schedule string.
     */
    public String getScheduleInfoString() throws VpsScheduleException;
}