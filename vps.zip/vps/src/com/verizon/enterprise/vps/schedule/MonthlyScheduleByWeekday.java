package com.verizon.enterprise.vps.schedule;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Calendar;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Amanjot Khaira
 * @version 1.0
 */

public class MonthlyScheduleByWeekday extends TimeOfDaySchedule
{
  /**
   *  The first week to start the job from.
   *  1 - first week of the month
   *  2 - second week of the month
   *  3 - third week of the month
   *  4 - fourth week of the month
   *  5 - fifth week of the month
   */
  int weekNumber;

  //The day of the week to perform the job. e.g ISchedule.WEEK_SUNDAY for Sunday
  int weekDay;

  /**
   * The occurrence of the job.
   * 0 - once a month.
   * 1 - once every week.
   * 2 - once every 2 weeks.
   */
  int reOccurrence;

  //starting week of month according to Calendar
  static int startingWeekNumber = 1;
  //max week number according to Calendar
  static int endWeekNumber = startingWeekNumber + 4;

  public MonthlyScheduleByWeekday()
  {
  }

  public MonthlyScheduleByWeekday(Calendar dailyTime, int weekDy, int weekNum)
  {
      this(dailyTime, weekDy, weekNum, 0);
  }

  public MonthlyScheduleByWeekday(Calendar dailyTime, int weekDy, int weekNum, int reOccur)
  {
    super(dailyTime);
    this.weekDay = weekDy;
    //weeks are 0,1,2,3,4 according to Calendar. user inputs 1,2,3,4,5 as weeks. to remove incosistency
    //we reduce the week number by 1.
    this.weekNumber = weekNum;
    this.reOccurrence = reOccur;
  }

  /** Get first available day */
  public Date getFirstAvailableDay(Date now, Date start, Date end)
  {
    long nNow = now.getTime();
    long nStartEffective = (start == null ? -1 : start.getTime());
    long nEndEffective = (end == null ? -1 : end.getTime());

    if (nEndEffective < nNow && nEndEffective > 0)
    {
      // No longer needed.
      return null;
    }

    // find the date in range first.
    Date firstDay;
    if (nStartEffective < nNow)
    {
      firstDay = new Date(nNow);
    }
    else
    {
      firstDay = new Date(nStartEffective);
    }

    Calendar cal = Calendar.getInstance();
    cal.setMinimalDaysInFirstWeek(7);
    cal.setTime(firstDay);
    return findDate(cal);
  }

  private Date findDate(Calendar cal)
  {
    if(reOccurrence == 0)//just once a month
    {
      while (true)
      {
        if( (getWeekOfMonth(cal) == weekNumber ) &&
             (cal.get(Calendar.DAY_OF_WEEK) == weekDay))
         {
           break;
         }
        cal.add(Calendar.DATE, 1);
      }
    }
    else if(reOccurrence == 1)//weekly
    {
      while (cal.get(Calendar.DAY_OF_WEEK) != weekDay)
      {
        cal.add(Calendar.DATE, 1);
      }
    }
    else if(reOccurrence == 2)//every 2 weeks
    {
      if(getWeekOfMonth(cal) < weekNumber)//first occurrence
      {
        while (true)
        {
          if ( (getWeekOfMonth(cal) == weekNumber) &&
              (cal.get(Calendar.DAY_OF_WEEK) == weekDay))
          {
            break;
          }
          cal.add(Calendar.DATE, 1);
        }
      }
      else //first occurrence has already passed. need to find next occurrence
      {
        int copyWeekNumber = weekNumber;
         if (getWeekOfMonth(cal) == weekNumber)
        {
          //week is same. check if day has not already passed
          //ASSUMPTION- that week starts on sun and sun has lower value than mon etc
          if (checkDayPassed(cal))
          {
            copyWeekNumber = weekNumber + 2;
          }
        }
        else
        /**
          * for week combinations (4,3) (3,2) (2,1)
          */
        if ( (getWeekOfMonth(cal) - weekNumber) == 1)
        {
          copyWeekNumber = weekNumber + 2;
        }
        else

        /**
         * for week combinations (5,3) (4,2) (3,1)
         */
        if ( (getWeekOfMonth(cal) - weekNumber) == 2)
        {
          copyWeekNumber = weekNumber + 2;
        }
        else

        /**
         * for week combinations (5,2) (4,1)
         */
        if ( (getWeekOfMonth(cal) - weekNumber) == 3)
        {
          copyWeekNumber = (weekNumber == startingWeekNumber ? endWeekNumber : weekNumber);
        }
        else

        /**
         * for week combinations (5,1)
         */
        if ( (getWeekOfMonth(cal) - weekNumber) == 4)
        {
          //before assigning week 5, check if day has not already passed
          if (checkDayPassed(cal))
          {
            copyWeekNumber = weekNumber;
          }
          else
          {
            copyWeekNumber = endWeekNumber;
          }
        }

        while (true)
        {
          if ( (getWeekOfMonth(cal) == copyWeekNumber) &&
              (cal.get(Calendar.DAY_OF_WEEK) == weekDay))
          {
            break;
          }
          else
          {
            if ( (getWeekOfMonth(cal) == endWeekNumber) && (copyWeekNumber == endWeekNumber))
            {
              //what if the 5th week of this month even has this weekday. check if last day of month
              //has been reached
              if (cal.get(Calendar.DAY_OF_MONTH) == cal.getActualMaximum(Calendar.DAY_OF_MONTH))
              {
                copyWeekNumber = weekNumber;
              }
            }
            cal.add(Calendar.DATE, 1);
          }
        }
      }
   }

   return cal.getTime();

  }

  /** Get next available day */
  public Date getNextAvailableDay(long nCurrentTime)
  {
    Calendar cal = Calendar.getInstance();
    cal.setTime(new Date(nCurrentTime));
    // Today is not the day.
    cal.add(Calendar.DATE, 1);
    return findDate(cal);
  }

  public void parse(String sScheduleInfo) throws VpsScheduleException
  {
    try {
        if (!sScheduleInfo.startsWith(ScheduleParser.PNAME_MONTHLY_NTH_WEEKDAY)) {
            throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sScheduleInfo);
        }
        else if (sScheduleInfo.length() <= ScheduleParser.PNAME_MONTHLY_NTH_WEEKDAY.length()) {
            throw new VpsScheduleException(VpsScheduleException.INCOMPLETE_PATTERN_NAME, sScheduleInfo);
        }

        // Pattern should only have MON_N_WD|n|m|WKD|HH:mm:ss info.
        String sPattern = sScheduleInfo.substring(ScheduleParser.PNAME_MONTHLY_NTH_WEEKDAY.length()+1);
        // Pattern should only have n|m|WKD|HH:mm:ss info.
        StringTokenizer st = new StringTokenizer(sPattern,ScheduleParser.PNAME_SEPARATOR);
        if(st.countTokens()!=4)
        {
          throw new VpsScheduleException(VpsScheduleException.INCOMPLETE_PATTERN_NAME, sScheduleInfo);
        }

        setWeekNumber(st.nextToken(),sScheduleInfo);
        setReoccurrence(st.nextToken(),sScheduleInfo);
        setDayOfWeek(convertDayOfWeek(st.nextToken()),sScheduleInfo);
        //Fake a date for parsing
        String sDate = "2000-01-01 " + st.nextToken();
        Date time = ISchedule.DATE_FORMAT.parse(sDate);
        Calendar dailyTime = Calendar.getInstance();
        dailyTime.setTime(time);
        setDailyTime(dailyTime);
    }
    catch(VpsScheduleException v)
    {
      throw v;
    }
    catch(Exception e)
    {
      throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, sScheduleInfo);
    }

  }

  private void setWeekNumber(String wNumber, String scheduleInfo) throws VpsScheduleException
  {
    try
    {
      weekNumber = Integer.parseInt(wNumber);
      if(weekNumber == 1 || weekNumber == 2 || weekNumber == 3 || weekNumber == 4)
      {
      }
      else
      {
        throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR," Invalid week number " + scheduleInfo);
      }
    }
    catch(NumberFormatException e)
    {
      throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR," Invalid week number " + scheduleInfo);
    }
  }

  private void setReoccurrence(String rNumber,String scheduleInfo) throws VpsScheduleException
  {
    try
    {
      reOccurrence = Integer.parseInt(rNumber);
      if(reOccurrence == 0 || reOccurrence == 1)
      {
      }
      else
      if(reOccurrence == 2)
      {
        if((weekNumber == 3) ||(weekNumber == 4) || (weekNumber == 5))
        {
          throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR," Invalid reoccurrence/weeknumber combination " + scheduleInfo);
        }
      }
      else
      {
        throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR," Invalid value for reoccurrence " + scheduleInfo);
      }
    }
    catch(NumberFormatException e)
    {
      throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR," Invalid argument for reoccurrence " + scheduleInfo);
    }
  }

  public int getDayOfWeek() { return weekDay; }

  private void setDayOfWeek(int nWeekday,String scheduleInfo) throws VpsScheduleException
  {
      if (nWeekday == Calendar.SUNDAY ||
          nWeekday == Calendar.MONDAY ||
          nWeekday == Calendar.TUESDAY ||
          nWeekday == Calendar.WEDNESDAY||
          nWeekday == Calendar.THURSDAY ||
          nWeekday == Calendar.FRIDAY ||
          nWeekday == Calendar.SATURDAY) {
          weekDay = nWeekday;
      }
      else {
          throw new VpsScheduleException(VpsScheduleException.INVALID_DAY_OF_WEEK,scheduleInfo);
      }
  }

  /**
   * Get schedule string.
   */
  public String getScheduleInfoString() throws VpsScheduleException {
      if (getDailyTime() != null) {
          Date time = getDailyTime().getTime();
          return ScheduleParser.PNAME_MONTHLY_NTH_WEEKDAY + ScheduleParser.PNAME_SEPARATOR
              + weekNumber + ScheduleParser.PNAME_SEPARATOR + reOccurrence + ScheduleParser.PNAME_SEPARATOR
              + convertDayOfWeek(getDayOfWeek()) + ScheduleParser.PNAME_SEPARATOR
              + ISchedule.DATE_FORMAT.format(time).substring(11);
      }
      else {
          return null;
      }
  }

  private int getWeekOfMonth(Calendar cal)
  {
    if((cal.get(Calendar.DATE) >=1)&&(cal.get(Calendar.DATE) <=7))
    {
      return 1;
    }
    if((cal.get(Calendar.DATE) >=8)&&(cal.get(Calendar.DATE) <=14))
    {
      return 2;
    }
    if((cal.get(Calendar.DATE) >=15)&&(cal.get(Calendar.DATE) <=21))
    {
      return 3;
    }
    if((cal.get(Calendar.DATE) >=22)&&(cal.get(Calendar.DATE) <=28))
    {
      return 4;
    }
    if((cal.get(Calendar.DATE) >=29)&&(cal.get(Calendar.DATE) <=31))
    {
      return 5;
    }
    return -1;
}

  private boolean checkDayPassed(Calendar cal)
  {
    Calendar temp = Calendar.getInstance();
    temp.setTime(cal.getTime());
    int week = getWeekOfMonth(temp);
    while(week == getWeekOfMonth(temp))
    {
      if(temp.get(Calendar.DAY_OF_WEEK) == weekDay)
      {
        return false;
      }
      temp.add(Calendar.DATE,1);
    }
    return true;
  }

  public String toString() {
      try {
          StringBuffer sb = new StringBuffer();
          sb.append("At ").append(getDailyTimeString());
          sb.append(" of every ");
          sb.append(this.weekNumber==1 ? "1st" :
                    (this.weekNumber==2 ? "2nd" :
                     (this.weekNumber==3 ? "3rd" :
                      (this.weekNumber==4 ? "4th" :
                       (this.weekNumber==5 ? "5th" : this.weekNumber+"th")))));
          sb.append(" ").append(convertDayOfWeek(this.weekDay)).append(
              " for each month");
          return sb.toString();
      }
      catch (VpsScheduleException vse) {
          return vse.getMessage();
      }
  }
}
