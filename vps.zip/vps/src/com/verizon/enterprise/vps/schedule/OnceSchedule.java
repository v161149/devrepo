package com.verizon.enterprise.vps.schedule;

import java.util.Date;
import java.text.SimpleDateFormat;
import com.verizon.enterprise.vps.dataobjects.VpsException;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class OnceSchedule extends AbstractSchedule {
    private boolean m_bScheduled = false;

    /**
     * Constructor.
     */
    public OnceSchedule() {
        setStartEffectiveTime(null);
    }

    /**
     * Constructor.
     */
    public OnceSchedule(Date time) {
        setStartEffectiveTime(time);
    }

    /**
     * Reset schedule flag.
     */
    public void resetScheduleFlag() {m_bScheduled = false;}

    /**
     * Get next running time in schedule.
     * @return Next running time. Null if not schedule is available any more.
     */
    public Date getTimeForNextSchedule(Date now) {
        if (m_bScheduled) return null;
        m_bScheduled = true;

        Date schTime = getStartEffectiveTime();
        if (schTime == null) {
            return now;
        }
        else return (schTime.after(now) ? schTime : null);
    }


    /**
     * Populate schedule info with string.
     */
    public void parse(String sScheduleInfo) throws VpsScheduleException {
        // String has to start with ONCE
        try {
            if (!sScheduleInfo.startsWith(ScheduleParser.PNAME_ONCE)) {
                throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sScheduleInfo);
            }

            String sDate = null;
            if (sScheduleInfo.length() > ScheduleParser.PNAME_ONCE.length()) {
                sDate = sScheduleInfo.substring(ScheduleParser.PNAME_ONCE.length()+1);
            }

            Date time = null;
            if (sDate != null) {
                time = ISchedule.DATE_FORMAT.parse(sDate);
            }

            setStartEffectiveTime(time);
        }
        catch (Exception ex) {
            throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, ex.getMessage());
        }
    }

    /**
     * Get schedule string.
     */
    public String getScheduleInfoString() throws VpsScheduleException {
        StringBuffer sb = new StringBuffer();
        sb.append(ScheduleParser.PNAME_ONCE);
        if (getStartEffectiveTime() != null) {
            sb.append(ScheduleParser.PNAME_SEPARATOR);
            sb.append(ISchedule.DATE_FORMAT.format(getStartEffectiveTime()));
        }

        return sb.toString();
    }

    /** To string */
    public String toString() {
        return "Once" + (getStartEffectiveTime() != null ?
                         " at " + ISchedule.DATE_FORMAT.format(getStartEffectiveTime()) : "");
    }
}
