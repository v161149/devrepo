package com.verizon.enterprise.vps.schedule;

import java.util.Date;
import java.util.Calendar;

import com.verizon.enterprise.vps.dataobjects.VpsException;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class FixedRateSchedule extends AbstractSchedule {
    private long m_nIntervalInSecs = 0;

    /**
     * Constructor.
     */
    FixedRateSchedule() {
    }

    /**
     * Constructor.
     * @param nPeriodInSecs
     */
    public FixedRateSchedule(long nInternalInSecs) {
        m_nIntervalInSecs = nInternalInSecs;
    }

    /**
     * Get time internal in seconds.
     */
    public long getInternalInSeconds() {return m_nIntervalInSecs;}

    /**
     * Set time internal in seconds.
     */
    public void setInternalInSeconds(long iis) {m_nIntervalInSecs = iis;}

    /**
     * Get next running time in schedule.
     * @return Next running time. Null if not schedule is available any more.
     */
    public Date getTimeForNextSchedule(Date now) {
        long nNow = now.getTime() + m_nIntervalInSecs*1000;
        Date stTime = getStartEffectiveTime(), endTime = getEndEffectiveTime();
        long nInitStartTime = nNow;

        // Check start time
        if (stTime != null && stTime.after(now)) {
            nInitStartTime = stTime.getTime() + m_nIntervalInSecs*1000;
        }

        // Check end time
        if (endTime != null && endTime.getTime() < nInitStartTime) {
            nInitStartTime = -1;
        }

        return (nInitStartTime > 0 ? new Date(nInitStartTime) : null);
    }

    /**
     * Populate schedule info with string.
     */
    public void parse(String sScheduleInfo) throws VpsScheduleException {
        // String has to start with
        try {
            if (!sScheduleInfo.startsWith(ScheduleParser.PNAME_FIXED_RATE)) {
                throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sScheduleInfo);
            }

            String sSecs = null;
            if (sScheduleInfo.length() > ScheduleParser.PNAME_FIXED_RATE.length()) {
                sSecs = sScheduleInfo.substring(ScheduleParser.PNAME_FIXED_RATE.length()+1);
            }

            // Time internal in number of seconds
            if (sSecs != null) {
                long nSecs = Long.parseLong(sSecs);
                if (nSecs <= 0) {
                    throw new VpsScheduleException(VpsScheduleException.INVALID_FIX_RATE_INTERVAL, sSecs);
                }
                setInternalInSeconds(nSecs);
            }
            else {
                throw new VpsScheduleException(VpsScheduleException.MISSING_FIX_RATE_INTERVAL);
            }
        }
        catch (NumberFormatException ex) {
            throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, ex.getMessage());
        }
    }

    /**
     * Get schedule string.
     */
    public String getScheduleInfoString() throws VpsScheduleException {
        return ScheduleParser.PNAME_FIXED_RATE + ScheduleParser.PNAME_SEPARATOR
            + getInternalInSeconds();
    }

    /**
     * toString
     */
    public String toString() {
        long nHour = m_nIntervalInSecs/3600;
        long nMin  = (m_nIntervalInSecs%3600)/60;
        long nSec  = m_nIntervalInSecs%60;
        return "Every"
            + (nHour == 0 ? "" : " " + nHour + " hour" + (nHour > 1 ? "s" : ""))
            + (nMin  == 0 ? "" : " " + nMin + " minute" + (nMin > 1? "s" : ""))
            + (nSec  == 0 ? "" : " " + nSec + " second" + (nSec > 1 ? "s" : ""));
    }
}