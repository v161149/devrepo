package com.verizon.enterprise.vps.schedule;

import java.util.*;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public abstract class TimeOfDaySchedule extends AbstractSchedule {
    // Time of the day for running scheduled job
    protected Calendar m_dailyTime;

    protected TimeOfDaySchedule() {}

    /**
     * Constructor
     * @param dailyTime Only the units up to hour will be used.
     */
    public TimeOfDaySchedule(Calendar dailyTime) {
        m_dailyTime = dailyTime;
    }

    /**
     * Access daily time. Only hour/minute/second information are valid.
     */
    public Calendar getDailyTime() {return m_dailyTime;}

    /**
     * Access daily time. Only hour/minute/second information are valid.
     */
    public void setDailyTime(Calendar dt) {m_dailyTime = dt;}

    /**
     * Get next running time in schedule.
     * @return Next running time. Null if not schedule is available any more.
     */
    public Date getTimeForNextSchedule(Date now) {
        long nStartEffective = (getStartEffectiveTime()==null ? -1 : getStartEffectiveTime().getTime());
        long nEndEffective = (getEndEffectiveTime()==null ? -1 : getEndEffectiveTime().getTime());
        long nNow = now.getTime()+1/**for continuous scheduling*/;

        if (nEndEffective < nNow && nEndEffective > 0) {
            // No longer needed.
            return null;
        }

        // find the date in range first.
        Date firstDay = getFirstAvailableDay(now, getStartEffectiveTime(), getEndEffectiveTime());
        if (firstDay == null) return null;

        Calendar cal = Calendar.getInstance();
        cal.setTime(firstDay);
        cal.set(Calendar.HOUR_OF_DAY, m_dailyTime.get(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, m_dailyTime.get(Calendar.MINUTE));
        cal.set(Calendar.SECOND, m_dailyTime.get(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, m_dailyTime.get(Calendar.MILLISECOND));

        long nTrySchedule = cal.getTime().getTime();
        if (nTrySchedule < nNow || nTrySchedule < nStartEffective) {
            nTrySchedule = getNextAvailableDay(nTrySchedule).getTime();
        }

        if (nStartEffective <= nTrySchedule && (nTrySchedule <= nEndEffective || nEndEffective <= 0)) {
            return new Date(nTrySchedule);
        }
        else {
            return null;
        }
    }

    /**
     * Get daily time string: strip off year/month/day.
     */
    protected String getDailyTimeString() {
        return getDailyTimeString(getDailyTime());
    }

    /**
     * Get daily time string: strip off year/month/day.
     */
    protected String getDailyTimeString(Calendar cal) {
        Date time = cal.getTime();
        return ISchedule.DATE_FORMAT.format(time).substring(11);
    }

    /** Get next available day */
    public abstract Date getFirstAvailableDay(Date now, Date start, Date end);

    /** Get next available day */
    public abstract Date getNextAvailableDay(long nCurrentTime);
}
