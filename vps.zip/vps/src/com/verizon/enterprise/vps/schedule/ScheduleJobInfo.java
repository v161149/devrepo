package com.verizon.enterprise.vps.schedule;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.dataobjects.TaskParsingException;
/**
 * <p>Description: Class that stores information about a particular job</p>
 * <p>Company: Verizon</p>
 * @author Amanjot Singh Khaira
 */

public class ScheduleJobInfo
{
  private ISchedule schedule;
  private IVpsTask task;

  public ScheduleJobInfo()
  {
  }

  public void setSchedule (String schedule) throws VpsScheduleException
  {
      this.schedule = ScheduleParser.parseSchedule(schedule);
  }

  public ISchedule getSchedule()
  {
    return this.schedule;
  }

  public void setTask(String task) throws TaskParsingException
  {
      this.task = new XmlPersistentTask(task);
  }

  public IVpsTask getTask()
  {
    return this.task;
  }
}