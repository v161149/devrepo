package com.verizon.enterprise.vps.schedule;

import com.verizon.enterprise.vps.dataobjects.VpsException;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class VpsScheduleException extends VpsException {
    private static final long serialVersionUID = 3849454647678105390L;

    // Error codes
    public static final int PARSING_ERROR             = 1;
    public static final int INVALID_DAY_OF_WEEK       = 2;
    public static final int INVALID_PATTERN_NAME      = 3;
    public static final int INCOMPLETE_PATTERN_NAME   = 4;
    public static final int MISSING_DAY_OF_WEEK       = 5;
    public static final int MISSING_TIME_OF_DAY       = 6;
    public static final int MISSING_FIX_RATE_INTERVAL = 7;
    public static final int NO_MORE_SCHEDULE          = 8;
    public static final int MISSING_SCHEDULE_INFO     = 9;
    public static final int DATABASE_EXCEPTION        = 10;
    public static final int MISSING_TASK_INFO         = 11;
    public static final int INVALID_TASK_INFO         = 12;
    public static final int DISPATCHER_ERROR          = 13;
    public static final int ADMIN_LOOKUP_ERROR        = 14;
    public static final int ADMIN_SERVER_ERROR        = 15;
    public static final int INVALID_FIX_RATE_INTERVAL = 16;
    public static final int LAST_ERROR                = 17;

    // Error messages
    private static String[] ms_qErrMsg = null;

    // Init error messages
    static {
        ms_qErrMsg = new String[LAST_ERROR];
        ms_qErrMsg[NO_ERROR] = "Success.";
        ms_qErrMsg[PARSING_ERROR] = "Schedule parsing error: ?";
        ms_qErrMsg[INVALID_DAY_OF_WEEK] = "Invalid day of week: ?";
        ms_qErrMsg[INVALID_PATTERN_NAME] = "Invalid time pattern name: '?'";
        ms_qErrMsg[INCOMPLETE_PATTERN_NAME] = "Invalid time pattern: '?'";
        ms_qErrMsg[MISSING_DAY_OF_WEEK] = "Missing information for day of week.";
        ms_qErrMsg[MISSING_TIME_OF_DAY] = "Missing information for time of day.";
        ms_qErrMsg[MISSING_FIX_RATE_INTERVAL] = "Missing fix rate interval.";
        ms_qErrMsg[NO_MORE_SCHEDULE] = "No more schedule available to run.";
        ms_qErrMsg[MISSING_SCHEDULE_INFO] = "Missing schedule information.";
        ms_qErrMsg[DATABASE_EXCEPTION] = "Datalayer exception: ?.";
        ms_qErrMsg[MISSING_TASK_INFO] = "Missing task information.";
        ms_qErrMsg[INVALID_TASK_INFO] = "Invalid task information: ?";
        ms_qErrMsg[DISPATCHER_ERROR] = "Dispatcher error: ?";
        ms_qErrMsg[ADMIN_LOOKUP_ERROR] = "Cannot find schedule admin server: ?";
        ms_qErrMsg[ADMIN_SERVER_ERROR] = "Schedule admin server error: ?";
        ms_qErrMsg[INVALID_FIX_RATE_INTERVAL] = "Invalid fix rate interval: ?";
    }

    /**
     * Contractor.
     */
    protected String[] getAllErrorMessages() {return ms_qErrMsg;}

    /** Constructor */
    public VpsScheduleException(int nErrCode) {
        super(nErrCode, null, null, null);
    }

    /** Constructor */
    public VpsScheduleException(int nErrCode, String sMsg1) {
        super(nErrCode, sMsg1, null, null);
    }

    /** Constructor */
    public VpsScheduleException(int nErrCode, String sMsg1, String sMsg2) {
        super(nErrCode, sMsg1, sMsg2, null);
    }

    /** Constructor */
    public VpsScheduleException(int nErrCode, String sMsg1, String sMsg2, String sMsg3) {
        super(nErrCode, sMsg1, sMsg2, sMsg3);
    }

}