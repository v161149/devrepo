package com.verizon.enterprise.vps.schedule;

import java.util.*;
import com.verizon.enterprise.vps.dataobjects.VpsException;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public class WeeklySchedule extends TimeOfDaySchedule {
    private int m_nWeekday;

    /**
     * For use by factory/parser.
     */
    WeeklySchedule() {
    }

    public int getDayOfWeek() {return m_nWeekday;}

    /**
     *
     * @param nWeekday Value from java.util.Calendar class.
     * @see java.util.Calendar
     */
    public void setDayOfWeek(int nWeekday) {
        if (nWeekday == Calendar.SUNDAY ||
            nWeekday == Calendar.MONDAY ||
            nWeekday == Calendar.TUESDAY ||
            nWeekday == Calendar.WEDNESDAY||
            nWeekday == Calendar.THURSDAY ||
            nWeekday == Calendar.FRIDAY ||
            nWeekday == Calendar.SATURDAY) {
            m_nWeekday = nWeekday;
        }
        else {
            throw new IllegalArgumentException("Invalid index for day of week: " + nWeekday);
        }
    }

    /**
     * Constructor
     * @param dailyTime Only the units up to hour will be used.
     * @param nWeekday Day index value in [Calendar.MONDAY - Calendar.SUNDAY]
     */
    public WeeklySchedule(Calendar dailyTime, int nWeekday) {
        super(dailyTime);

        if (!(nWeekday == Calendar.SUNDAY ||
              (nWeekday >= Calendar.MONDAY && nWeekday <= Calendar.SATURDAY))) {
            throw new IllegalArgumentException("Week day index has to be from Monday to Sunday.");
        }

        m_nWeekday = nWeekday;
    }

    /** Get next available day */
    public Date getFirstAvailableDay(Date now, Date start, Date end) {
        long nNow = now.getTime();
        long nStartEffective = (start == null ? -1 : start.getTime());
        long nEndEffective   = (end == null ? -1 : end.getTime());

        if (nEndEffective < nNow && nEndEffective > 0) {
            // No longer needed.
            return null;
        }

        // find the date in range first.
        Date firstDay;
        if (nStartEffective < nNow) {
            firstDay = new Date(nNow);
        }
        else {
            firstDay = new Date(nStartEffective);
        }

        Calendar cal = Calendar.getInstance();
        cal.setTime(firstDay);
        if (cal.get(Calendar.DAY_OF_WEEK) != m_nWeekday) {
            // Move to next
            for (int i=0; i<6; i++) {
                cal.add(Calendar.DATE, 1);
                if (cal.get(Calendar.DAY_OF_WEEK) == m_nWeekday) {
                    break;
                }
            }
        }

        return cal.getTime();
    }

    /** Get next available day */
    public Date getNextAvailableDay(long nCurrentTime) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(nCurrentTime));
        // Today is not the day.
        cal.add(Calendar.DATE, 1);
        if (cal.get(Calendar.DAY_OF_WEEK) != m_nWeekday) {
            // Move to next
            for (int i=0; i<6; i++) {
                cal.add(Calendar.DATE, 1);
                if (cal.get(Calendar.DAY_OF_WEEK) == m_nWeekday) {
                    break;
                }
            }
        }

        return cal.getTime();
    }


    /**
     * Populate schedule info with string.
     */
    public void parse(String sScheduleInfo) throws VpsScheduleException {
        // String has to start with weekly
        try {
            if (!sScheduleInfo.startsWith(ScheduleParser.PNAME_WEEKLY)) {
                throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sScheduleInfo);
            }
            else if (sScheduleInfo.length() <= ScheduleParser.PNAME_WEEKLY.length()) {
                throw new VpsScheduleException(VpsScheduleException.INCOMPLETE_PATTERN_NAME, sScheduleInfo);
            }

            // Fake a date for parsing. Pattern should only have WKD|HH:mm:ss info.
            String sPattern = sScheduleInfo.substring(ScheduleParser.PNAME_WEEKLY.length()+1);
            int nPos = sPattern.indexOf(ScheduleParser.PNAME_SEPARATOR);
            if (nPos <= 0) {
                throw new VpsScheduleException(VpsScheduleException.MISSING_DAY_OF_WEEK);
            }
            else if (nPos == sPattern.length()) {
                throw new VpsScheduleException(VpsScheduleException.MISSING_TIME_OF_DAY);
            }

            String sWeekDay = sPattern.substring(0, nPos);
            String sDate = "2000-01-01 " + sPattern.substring(nPos+1);
            Date time = ISchedule.DATE_FORMAT.parse(sDate);
            Calendar dailyTime = Calendar.getInstance();
            dailyTime.setTime(time);
            setDailyTime(dailyTime);

            setDayOfWeek(convertDayOfWeek(sWeekDay));
        }
        catch (VpsScheduleException vse) {
            throw vse;
        }
        catch (Exception ex) {
            throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, ex.getMessage());
        }
    }

    /**
     * Get schedule string.
     */
    public String getScheduleInfoString() throws VpsScheduleException {
        if (getDailyTime() != null) {
            Date time = getDailyTime().getTime();
            return ScheduleParser.PNAME_WEEKLY + ScheduleParser.PNAME_SEPARATOR
                + convertDayOfWeek(getDayOfWeek()) + ScheduleParser.PNAME_SEPARATOR
                + ISchedule.DATE_FORMAT.format(time).substring(11);
        }
        else {
            return null;
        }
    }

    /** toString */
    public String toString() {
        try {
            return "At " + getDailyTimeString() + " on every " +
                convertDayOfWeek(this.getDayOfWeek());
        }
        catch (VpsScheduleException vse) {
            return vse.getMessage();
        }
    }
}