package com.verizon.enterprise.vps.schedule;

import java.util.Date;
import java.util.Calendar;
import com.verizon.enterprise.vps.dataobjects.VpsException;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

public abstract class AbstractSchedule implements ISchedule, java.io.Serializable, java.lang.Cloneable {
    private Date m_startTime, m_endTime;
    private String m_sName, m_sDescription;

    /**
     * Constructor.
     */
    protected AbstractSchedule() {
    }

    /**
     * Get next running time in schedule starting from now.
     * @return Next running time. Null if not schedule is available any more.
     */
    public Date getTimeForNextSchedule() {
        return getTimeForNextSchedule(new Date());
    }

    /**
     * Get the effective start time.
     */
    public Date getStartEffectiveTime() {return m_startTime;}

    /**
     * Get the effective end time.
     */
    public Date getEndEffectiveTime() {return m_endTime;}

    /**
     * Set the effective start time.
     */
    public void setStartEffectiveTime(Date st) {m_startTime = st;}

    /**
     * Set the effective end time.
     */
    public void setEndEffectiveTime(Date et) {m_endTime = et;}

    /**
     * Get the description.
     */
    public String getDescription() {return m_sDescription;}

    /**
     * Set the description.
     */
    public void setDescription(String sDesc) {m_sDescription = sDesc;}

    /**
     * Get name
     */
    public String getName() {return m_sName;}

    /**
     * Set name
     */
    public void setName(String sName) {m_sName = sName;}


    /**
     * Convert week string to calendar index.
     * @param sDayOfWeek
     * @return
     */
    public static int convertDayOfWeek(String sDayOfWeek) throws VpsScheduleException {
        if (sDayOfWeek != null) sDayOfWeek = sDayOfWeek.toUpperCase();

        if (ISchedule.WEEK_SUNDAY.equals(sDayOfWeek)) {
            return Calendar.SUNDAY;
        }
        else if (ISchedule.WEEK_MONDAY.equals(sDayOfWeek)) {
            return Calendar.MONDAY;
        }
        else if (ISchedule.WEEK_TUESDAY.equals(sDayOfWeek)) {
            return Calendar.TUESDAY;
        }
        else if (ISchedule.WEEK_WEDNESDAY.equals(sDayOfWeek)) {
            return Calendar.WEDNESDAY;
        }
        else if (ISchedule.WEEK_THURSDAY.equals(sDayOfWeek)) {
            return Calendar.THURSDAY;
        }
        else if (ISchedule.WEEK_FRIDAY.equals(sDayOfWeek)) {
            return Calendar.FRIDAY;
        }
        else if (ISchedule.WEEK_SATURDAY.equals(sDayOfWeek)) {
            return Calendar.SATURDAY;
        }

        throw new VpsScheduleException(VpsScheduleException.INVALID_DAY_OF_WEEK, sDayOfWeek);
    }

    /**
     * Convert week string to calendar index.
     * @param nDayOfWeek
     * @return String representation.
     */
    public static String convertDayOfWeek(int nDayOfWeek) throws VpsScheduleException {
        String sDayOfWeek;
        switch (nDayOfWeek) {
            case Calendar.SUNDAY: sDayOfWeek = ISchedule.WEEK_SUNDAY; break;
            case Calendar.MONDAY: sDayOfWeek = ISchedule.WEEK_MONDAY; break;
            case Calendar.TUESDAY: sDayOfWeek = ISchedule.WEEK_TUESDAY; break;
            case Calendar.WEDNESDAY: sDayOfWeek = ISchedule.WEEK_WEDNESDAY; break;
            case Calendar.THURSDAY: sDayOfWeek = ISchedule.WEEK_THURSDAY; break;
            case Calendar.FRIDAY: sDayOfWeek = ISchedule.WEEK_FRIDAY; break;
            case Calendar.SATURDAY: sDayOfWeek = ISchedule.WEEK_SATURDAY; break;
            default:
                throw new VpsScheduleException(VpsScheduleException.INVALID_DAY_OF_WEEK, Integer.toString(nDayOfWeek));
        }

        return sDayOfWeek;
    }

    /**
     * Populate schedule info with string.
     */
    public void parse(String sScheduleInfo) throws VpsScheduleException {
        throw new UnsupportedOperationException("Current schedule doesn't support string parsing.");
    }

    /**
     * Get schedule string.
     */
    public String getScheduleInfoString() throws VpsScheduleException {
        return toString();
    }

    /**
     * Clone
     */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}