package com.verizon.enterprise.vps.schedule;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.StringTokenizer;

/**
 * <p>Title: Virtual Process Service</p> <p>Description: </p> <p>Copyright:
 * Copyright (c) 2003</p> <p>Company: Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */

public class DailySchedule extends TimeOfDaySchedule {
  private static final long serialVersionUID = -8421103380607930515L;
  // List of Calendors.
  private List m_qDailyTimes = new LinkedList();

  protected DailySchedule() {
  }

  /**
   * Constructor
   * 
   * @param dailyTime Only the units up to hour will be used.
   */
  public DailySchedule(Calendar dailyTime) {
    m_qDailyTimes.add(dailyTime);
  }

  /** Get next available day */
  public Date getFirstAvailableDay(Date now, Date start, Date end) {
    long nNow = now.getTime();
    long nStartEffective = (start == null ? -1 : start.getTime());
    long nEndEffective = (end == null ? -1 : end.getTime());

    if (nEndEffective < nNow && nEndEffective > 0) {
      // No longer needed.
      return null;
    }

    // find the date in range first.
    Date firstDay;
    if (nStartEffective < nNow) {
      firstDay = new Date(nNow);
    } else {
      firstDay = new Date(nStartEffective);
    }

    return firstDay;
  }

  /** Get next available day */
  public Date getNextAvailableDay(long nCurrentTime) {
    Calendar c = Calendar.getInstance();
    c.setTimeInMillis(nCurrentTime);
    c.add(Calendar.DAY_OF_YEAR, 1);
    return c.getTime();
  }

  /**
   * Populate schedule info with string.
   */
  public void parse(String sScheduleInfo) throws VpsScheduleException {
    // String has to start with daily
    try {
      if (!sScheduleInfo.startsWith(ScheduleParser.PNAME_DAILY)) {
        throw new VpsScheduleException(VpsScheduleException.INVALID_PATTERN_NAME, sScheduleInfo);
      }

      String sDate = null;
      // Fake a date for parsing. Pattern should only have HH:mm:ss info.
      String sPattern = sScheduleInfo.substring(ScheduleParser.PNAME_DAILY.length() + 1);
      StringTokenizer st = new StringTokenizer(sPattern, ScheduleParser.PNAME_SEPARATOR);
      while (st.hasMoreTokens()) {
        sDate = "2000-01-01 " + st.nextToken();

        Date time = null;
        if (sDate != null) {
          time = ISchedule.DATE_FORMAT.parse(sDate);
        }

        if (time != null) {
          Calendar cal = Calendar.getInstance();
          cal.setTime(time);
          m_qDailyTimes.add(cal);
        }
      }

      if (m_qDailyTimes.size() == 0) {
        throw new VpsScheduleException(VpsScheduleException.MISSING_TIME_OF_DAY);
      }
    } catch (VpsScheduleException ve) {
      throw ve;
    } catch (Exception ex) {
      throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, ex.getMessage());
    }
  }

  /**
   * Get schedule string.
   */
  public String getScheduleInfoString() throws VpsScheduleException {
    // System.out.println("Date: " + getDailyTime());
    if (getDailyTime() != null) {
      StringBuffer sb = new StringBuffer();
      sb.append(ScheduleParser.PNAME_DAILY);

      Iterator iter = m_qDailyTimes.iterator();
      while (iter.hasNext()) {
        Calendar cal = (Calendar)iter.next();
        //Date time = cal.getTime();
        sb.append(ScheduleParser.PNAME_SEPARATOR).append(getDailyTimeString(cal));
      }
      return sb.toString();
    } else {
      return null;
    }
  }

  /**
   * Access daily time. Only hour/minute/second information are valid.
   */
  public Calendar getDailyTime(int i) {
    return (Calendar)m_qDailyTimes.get(i);
  }

  public Calendar getDailyTime() {
    return getDailyTime(0);
  }

  /**
   * Get next running time in schedule.
   * 
   * @return Next running time. Null if no schedule is available any more.
   */
  public Date getTimeForNextSchedule(Date now) {
    Date closeDate = null, nextDate;
    Iterator iter = m_qDailyTimes.iterator();
    while (iter.hasNext()) {
      Calendar cal = (Calendar)iter.next();
      setDailyTime(cal);
      nextDate = super.getTimeForNextSchedule(now);
      if (closeDate == null || closeDate.after(nextDate)) {
        closeDate = nextDate;
      }
    }

    return closeDate;
  }

  /**
   * toString
   */
  public String toString() {
    Calendar cal = null;
    StringBuffer sb = new StringBuffer("At ");
    ListIterator iter = m_qDailyTimes.listIterator(0);

    while (iter.hasNext()) {
      cal = (Calendar)iter.next();
      sb.append(getDailyTimeString(cal));
      sb.append(", ");
    }
    sb.append("daily");

    return sb.toString();

    // return "At " + getDailyTimeString() + " daily";
  }

}
