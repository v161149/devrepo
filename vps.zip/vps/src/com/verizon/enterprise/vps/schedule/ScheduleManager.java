package com.verizon.enterprise.vps.schedule;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;

import javax.ejb.CreateException;
import javax.rmi.PortableRemoteObject;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.core.InteractiveExecutionTask;
import com.verizon.enterprise.vps.core.TransientExecutionTask;
import com.verizon.enterprise.vps.dataobjects.IVpsInteractiveTask;
import com.verizon.enterprise.vps.dataobjects.IVpsPersistentTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTaskListener;
import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.middleware.ScheduleAdmin;
import com.verizon.enterprise.vps.middleware.ScheduleAdminHome;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.ejb.EJBHomeFactory;

/**
 * <p>Title: Virtual Process Service</p> <p>Description: Wrapper class for
 * application to access all scheduling functions.</p> <p>Copyright: Copyright
 * (c) 2003</p> <p>Company: Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */

public class ScheduleManager {
  public static final String SCHEDULE_ADMIN_ALIAS = "VPSAdmin";

  // Database schema source
  private Long m_nUserId = new Long(0);

  /**
   * Constructor.
   */
  public ScheduleManager() {
    setUserId(null);
  }

  /**
   * Constructor.
   * 
   * @param sSchema Database schema for job schedule persistence.
   * @param nUserId Id of user who is managing the schedule.
   */
  public ScheduleManager(Long nUserId) {
    setUserId(nUserId);
  }

  /**
   * Get user id.
   */
  public Long getUserId() {
    return m_nUserId;
  }

  /**
   * Set user id.
   */
  public void setUserId(Long uid) {
    m_nUserId = (uid == null ? new Long(0) : uid);
  }

  /**
   * Submit an in-memory schedule. Schedule will be cancelled when current JVM
   * exits.
   */
  public static Long scheduleUIJob(IVpsInteractiveTask task, IVpsTaskListener listener, Long uid) throws VpsException {
    InteractiveExecutionTask task1 = new InteractiveExecutionTask(task, listener);
    task1.setUserId(uid);
    return Dispatcher.submit(task1, new OnceSchedule(new Date(System.currentTimeMillis() + 1000)));
  }

  /**
   * Submit an in-memory schedule. Schedule will be cancelled when current JVM
   * exits.
   */
  public Long scheduleUIJob(IVpsInteractiveTask task, IVpsTaskListener listener) throws VpsException {
    return scheduleUIJob(task, listener, getUserId());
  }

  /**
   * Submit an in-memory schedule. Schedule will be cancelled when current JVM
   * exits.
   */
  public Long scheduleUIJob(IVpsInteractiveTask task, Long uid) throws VpsException {
    return scheduleUIJob(task, new TimeoutTaskListener(), uid);
  }

  /**
   * Submit an in-memory schedule. Schedule will be cancelled when current JVM
   * exits.
   */
  public Long scheduleUIJob(IVpsInteractiveTask task) throws VpsException {
    return scheduleUIJob(task, getUserId());
  }

  /**
   * Submit an in-memory schedule. Schedule will be cancelled when current JVM
   * exits.
   */
  public static void scheduleTransientJob(IVpsTask task, ISchedule schedule, Long uid) throws VpsException {
    TransientExecutionTask task1 = new TransientExecutionTask(task);
    task1.setUserId(uid);
    Dispatcher.submit(task1, schedule);

  }

  /**
   * Submit an in-memory schedule. Schedule will be cancelled when current JVM
   * exits.
   */
  public void scheduleTransientJob(IVpsTask task, ISchedule schedule) throws VpsException {
    scheduleTransientJob(task, schedule, getUserId());
  }

  /**
   * Submit a persistent schedule. Job schedule is saved in database and will be
   * active whenever server is up.
   */
  public JobScheduleDefObject schedulePersistentJob(IVpsPersistentTask task, ISchedule schedule) throws VpsScheduleException {
    // Call EJB
    ScheduleAdmin admin = getScheduleAdmin();
    try {
      return admin.schedulePersistentJob(task, schedule, getUserId());
    } catch (RemoteException re) {
      throw new VpsScheduleException(VpsScheduleException.ADMIN_SERVER_ERROR, re.getMessage());
    }
  }

  /**
   * Remove a job schedule (and its pending tasks) from database.
   * 
   * @param task Task information.
   * @param schedule Schedule information.
   * @return Newly created database object.
   */
  public void unschedulePersistentJob(JobScheduleDefObject scheduleObject, boolean bRemoveSchedule) throws VpsScheduleException {
    // Call EJB
    ScheduleAdmin admin = getScheduleAdmin();
    try {
      admin.unschedulePersistentJob(scheduleObject, getUserId(), bRemoveSchedule);
    } catch (RemoteException re) {
      throw new VpsScheduleException(VpsScheduleException.ADMIN_SERVER_ERROR, re.getMessage());
    }
  }

  /**
   * Update a persistent schedule (and its pending tasks) in the database.
   * 
   * @param task Task information.
   * @param schedule Schedule information.
   * @param jsdo Existing JobScheduleDefObject object.
   * @return Updated database object.
   */
  public JobScheduleDefObject updatePersistentJob(IVpsPersistentTask task, ISchedule schedule, JobScheduleDefObject jsdo) throws VpsScheduleException {
    // Call EJB
    ScheduleAdmin admin = getScheduleAdmin();
    try {
      return admin.updatePersistentJob(task, schedule, jsdo, getUserId());
    } catch (RemoteException re) {
      throw new VpsScheduleException(VpsScheduleException.ADMIN_SERVER_ERROR, re.getMessage());
    }
  }

  public List getSchedules(String condition) throws VpsScheduleException {
    ScheduleAdmin admin = getScheduleAdmin();
    try {
      return admin.getSchedules(condition);
    } catch (RemoteException re) {
      throw new VpsScheduleException(VpsScheduleException.ADMIN_SERVER_ERROR, re.getMessage());
    }
  }

  public List getTaskInstanceList(String condition) throws VpsScheduleException {
    ScheduleAdmin admin = getScheduleAdmin();
    try {
      return admin.getTaskInstanceList(condition);
    } catch (RemoteException re) {
      throw new VpsScheduleException(VpsScheduleException.ADMIN_SERVER_ERROR, re.getMessage());
    }
  }

  public void deleteTaskInstance(TaskInstanceObject taskObject) throws VpsScheduleException {
    ScheduleAdmin admin = getScheduleAdmin();
    try {
      admin.deleteTaskInstance(taskObject);
    } catch (RemoteException re) {
      throw new VpsScheduleException(VpsScheduleException.ADMIN_SERVER_ERROR, re.getMessage());
    }
  }

  /** Get remote interface of schedule admin */
  public ScheduleAdmin getScheduleAdmin() throws VpsScheduleException {
    try {
      ScheduleAdminHome home = (ScheduleAdminHome)EJBHomeFactory.getFactory().lookUpHome(SCHEDULE_ADMIN_ALIAS);
      ScheduleAdmin bean = (ScheduleAdmin)PortableRemoteObject.narrow(home.create(), ScheduleAdmin.class);
      return bean;
    } catch (RemoteException re) {
      LogHelper.error(re);
      throw new VpsScheduleException(VpsScheduleException.ADMIN_LOOKUP_ERROR, re.getMessage());
    } catch (CreateException ce) {
      LogHelper.error(ce);
      throw new VpsScheduleException(VpsScheduleException.ADMIN_LOOKUP_ERROR, ce.getMessage());
    } finally {
    }
  }
}
