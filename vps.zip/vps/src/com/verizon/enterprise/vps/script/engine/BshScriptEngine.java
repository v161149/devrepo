package com.verizon.enterprise.vps.script.engine;

import java.util.Map;
import bsh.Interpreter;
import bsh.EvalError;

import org.apache.log4j.Logger;

import com.verizon.enterprise.vps.dataobjects.Registry;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class BshScriptEngine implements IScriptEngine
{
    private static Logger log = Logger.getLogger(BshScriptEngine.class);

    public Map runScript(String script, Map map) throws Exception
    {
        final String METHOD_NAME = "runScript(name, map)";
        log.debug("ENTER: " + METHOD_NAME);

        Interpreter interpreter = new Interpreter();

        Registry registry = new Registry();
        registry.setAll(map);

        Map result = null;
        try
        {
            interpreter.set("registry", registry);
            interpreter.eval(script);
            result = ((Registry)interpreter.get("registry")).getHashMap();
        }
        catch (EvalError e)
        {
            log.info("Script running exception: " + e.getMessage());
            throw e;
        }

        log.debug("EXIT: " + METHOD_NAME);
        return result;
    }

    public static void main(String [] argv)
    {
        //Interpreter i = new Interpreter();
    }
}