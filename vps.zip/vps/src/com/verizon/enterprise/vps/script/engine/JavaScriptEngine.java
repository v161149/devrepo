package com.verizon.enterprise.vps.script.engine;

import java.util.Map;
import java.util.HashMap;
import java.io.StringReader;

import com.verizon.enterprise.rules.app.DbJetsEngine;
import com.verizon.enterprise.rules.engine.RuleEngineException;

import org.apache.log4j.Logger;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class JavaScriptEngine implements IScriptEngine
{
    private static Logger log = Logger.getLogger(JavaScriptEngine.class);

    public Map runScript(String script, Map map) throws Exception
    {
        final String METHOD_NAME = "runScript(name, map)";
        log.debug("ENTER: " + METHOD_NAME);

        DbJetsEngine engine = new DbJetsEngine();
        StringReader scriptReader = new StringReader(script);
        Map result = engine.runScript(scriptReader, METHOD_NAME, (HashMap)map);

        log.debug("EXIT: " + METHOD_NAME);
        return result;
    }
}