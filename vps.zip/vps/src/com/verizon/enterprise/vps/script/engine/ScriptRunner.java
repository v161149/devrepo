package com.verizon.enterprise.vps.script.engine;

import java.util.Map;
import com.verizon.enterprise.vps.dataobjects.Registry;
import com.verizon.enterprise.vps.util.ScriptUtil;
import com.verizon.enterprise.rules.engine.ScriptResult;
import com.verizon.enterprise.rules.engine.RuleEngineException;
import com.verizon.kernel.exception.DatalayerException;

import org.apache.log4j.Logger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ScriptRunner implements IScriptRunner
{
    private static Logger log = Logger.getLogger(ScriptRunner.class);
    private ScriptEngine scriptEngine = null;

    public ScriptRunner()
    {
        scriptEngine = new ScriptEngine();
    }

    public Map runByName(String scriptName, Map map) throws Exception
    {
        final String METHOD_NAME = "ScriptRunner:runByName()";
        log.debug("ENTER: " + METHOD_NAME);
        Map result = null;

        try
        {
            result = scriptEngine.runScriptByName(scriptName, map);
        }
        catch (bsh.TargetError bste) {
            log.error("BeanShell script '" + scriptName + "' execution error at line " + bste.getErrorLineNumber()
                      + " '" + bste.getErrorText() + "': " + bste.getTarget());
            log.debug(bste);
            Throwable re = bste.getTarget();
            if (re instanceof Exception) throw (Exception)re;
            else throw bste;
        }
        catch (Exception oe)
        {
            log.error("Exception when running script '" + scriptName + "': " + oe);
            throw oe;
        }

        log.debug("result = \n" + ScriptUtil.mapToString(map));
        log.debug("EXIT: " + METHOD_NAME);

        return result;
    }

    public Map runByContent(String scriptContent, Map map, String sLanguage) throws Exception {
        final String METHOD_NAME = "ScriptRunner:runByContent()";
        log.debug("ENTER: " + METHOD_NAME);
        Map result = null;

        try
        {
            result = scriptEngine.runScriptByContent(scriptContent, map, sLanguage);
        }
        catch (bsh.TargetError bste) {
            log.error("BeanShell execution error at line " + bste.getErrorLineNumber()
                      + " '" + bste.getErrorText() + "': " + bste.getTarget());
            log.debug(bste);
            Throwable re = bste.getTarget();
            if (re instanceof Exception) throw (Exception)re;
            else throw bste;
        }
        catch (Exception oe)
        {
            log.error("Exception when running script:" + oe);
            throw oe;
        }

        log.debug("result = \n" + ScriptUtil.mapToString(map));
        log.debug("EXIT: " + METHOD_NAME);

        return result;
    }

}