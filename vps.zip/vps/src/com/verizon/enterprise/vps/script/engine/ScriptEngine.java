package com.verizon.enterprise.vps.script.engine;

//import org.apache.bsf.BSFManager;
//import org.apache.bsf.BSFEngine;
//import org.apache.bsf.BSFException;

import java.util.HashMap;
import java.util.Map;

import com.verizon.enterprise.vps.dataobjects.ScriptException;
import com.verizon.enterprise.vps.dataobjects.Registry;
import com.verizon.enterprise.vps.dataobjects.ScriptLanguage;
import com.verizon.enterprise.vps.db.ScriptDatalayer;
import com.verizon.common.datalayer.ecp.JetsScriptObject;
import com.verizon.kernel.exception.DatalayerException;

import org.apache.log4j.Logger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Gang Fu
 * @version 1.0
 */

public class ScriptEngine
{
    private static Logger log = Logger.getLogger(ScriptEngine.class);

    Registry registry = null;

    public ScriptEngine()
    {
    }

    public void setValue(String name, Object value)
    {
        registry.put(name, value);
    }

    public Object getValue(String name)
    {
        return registry.get(name);
    }

    public void removeValue(String name)
    {
        registry.remove(name);
    }

    public Registry getRegistry()
    {
        return registry;
    }

    public Map runScriptByName(String scriptName, Map map) throws Exception
    {
        final String METHOD_NAME = "runScriptByName(name, map)";
        log.debug("ENTER: " + METHOD_NAME);

        JetsScriptObject script = ScriptDatalayer.getJetsScript(scriptName);
        IScriptEngine engine = null;
        Map result = null;

        if (ScriptLanguage.JAVASCRIPT.equalsIgnoreCase(script.getLanguage())) {
            engine = new JavaScriptEngine();
        }
        else if (ScriptLanguage.BEANSHELL.equalsIgnoreCase(script.getLanguage())) {
            engine = new BshScriptEngine();
        }
        else {
            throw new ScriptException(ScriptException.UNKNOWN_SCRIPT_LANGUAGE, script.getLanguage());
        }

        if (engine != null) {
            result = engine.runScript(script.getScript(), map);
        }

        log.debug("EXIT: " + METHOD_NAME);
        return result;
    }

    public Map runScriptByContent(String scriptContent, Map map, String sLanguage) throws Exception
    {
        final String METHOD_NAME = "runScriptByContent(name, map, lang)";
        log.debug("ENTER: " + METHOD_NAME);

        IScriptEngine engine = null;
        Map result = null;

        if (ScriptLanguage.JAVASCRIPT.equalsIgnoreCase(sLanguage))
            engine = new JavaScriptEngine();
        else if (ScriptLanguage.BEANSHELL.equalsIgnoreCase(sLanguage))
            engine = new BshScriptEngine();

        if (engine != null)
            result = engine.runScript(scriptContent, map);

        log.debug("EXIT: " + METHOD_NAME);
        return result;
    }

}