package com.verizon.enterprise.vps.script.engine;

import java.util.Map;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public interface IScriptEngine
{
    public Map runScript(String script, Map map) throws Exception;
}