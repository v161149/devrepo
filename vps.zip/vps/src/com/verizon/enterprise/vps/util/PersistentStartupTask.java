package com.verizon.enterprise.vps.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.enterprise.vps.core.PersistentExecutionTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.ScheduleParser;

/**
 * <p>Title: vps</p> <p>Description: vps</p> <p>Copyright: Copyright (c)
 * 2003</p> <p>Company: Verizon</p>
 * 
 * @author cc00
 * @version 1.1
 */

public class PersistentStartupTask implements IVpsTask {
  public void run() throws Exception {
    try {
      recoverCrashedTasks();
    } catch (Exception e) {
      LogHelper.warn(e);
    }

    preparePendingTasks();
  }

  public void recoverCrashedTasks() throws Exception {
    String domain = Domain.getDomainId();
    if (domain == null || domain.trim().length() <= 0) {
      throw new Exception("cannot find my APM domain, exiting recovering crashed tasks");
    }
    LogHelper.info("recovering crashed tasks for domain " + domain);
    String sql = "update pending_task set status = '" + IVpsTask.PENDING + "', timestamp = sysdate where status != '" + IVpsTask.PENDING
        + "' and apm_domain = '" + Domain.getDomainId() + "'";
    Connection con = DbHelper.getDbConnection();
    if (con == null) {
      throw new Exception("cannot get db connection");
    }
    LogHelper.debug("running query: " + sql);
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      int res = ps.executeUpdate();
      con.commit();
      LogHelper.info(res + " crashed jobs are recovered");
    } finally {
      con.close();
    }
  }

  public void preparePendingTasks() throws Exception {
    String sql1 = "select Job_Schedule_Def_Oid from Job_Schedule_Def " + "where Job_Schedule_Def_Oid not in "
        + "(select Job_Schedule_Def_Oid from Pending_Task) ";
    String search = "where status = 'A' and Job_Schedule_Def_Oid not in " + "(select Job_Schedule_Def_Oid from Pending_Task) ";
    List list = JobScheduleDefTable.search(search);
    for (Iterator it = list.iterator(); it.hasNext();) {
      JobScheduleDefObject jsdo = (JobScheduleDefObject)it.next();
      ISchedule schedule = ScheduleParser.parseSchedule(jsdo.getScheduleInfo());
      Date execTime = null;
      if (schedule != null) {
        execTime = schedule.getTimeForNextSchedule();
      }
      if (execTime != null) {
        PersistentExecutionTask pdo = new PersistentExecutionTask();
        pdo.setTimestamp(new Timestamp(System.currentTimeMillis()));
        pdo.setUserId(jsdo.getUserId());
        pdo.setRetryCounter(new Long(0));
        TimeZone.setDefault(TimeZone.getTimeZone("US/Eastern"));
        System.setProperty("user.timezone", "US/Eastern");
        pdo.setExecuteTime(new Timestamp(execTime.getTime()));
        pdo.setJobScheduleDefOid(jsdo.getJobScheduleDefOid());
        pdo.setJobScheduleDefOidObject(jsdo);
        pdo.setStatus(IVpsTask.PENDING);
        pdo.setTaskInfo(jsdo.getTaskInfo());
        try {
          PendingTaskTable.create(pdo);
        } catch (Exception e) {
          // maybe inserted by other JVMs during the same time
          LogHelper.warn(e);
        }
      }
    }
  }

  public String getDescription() {
    return "Refreshing PendingTask Table";
  }

}
