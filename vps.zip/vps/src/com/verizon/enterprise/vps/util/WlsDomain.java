package com.verizon.enterprise.vps.util;

import weblogic.management.configuration.ServerMBean;
import weblogic.management.MBeanHome;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class WlsDomain
{
  private static int port;
  private static String listen_address;
  private static boolean isDev = false;

  private static boolean initialized = false;

  private static void init() throws Exception {
    //ServerMBean sb = (ServerMBean) JmxHelper.getLocalMBeanHome().getMBean("ServerConfig",ServerMBean.class);
    MBeanHome localhome = JmxHelper.getLocalMBeanHome();
    String serverName = localhome.getMBeanServer().getServerName();
    LogHelper.info("serverName="+serverName);

    java.util.Set servers = localhome.getMBeansByType("ServerConfig");
    java.util.Set clusters = localhome.getMBeansByType("ClusterConfig");

    if ((servers == null) || servers.isEmpty()) {
      throw new Exception("cannot find MBean ServerConfig or there are multiples");
    }
    isDev = (clusters == null || clusters.size() <= 0);
    for (java.util.Iterator it = servers.iterator(); it.hasNext();) {
      ServerMBean sb = (ServerMBean) it.next();
      if (sb.getName().equals("adminserver")) {
        isDev = false;
      }
      else {
        port = sb.getListenPort();
      }
      listen_address = sb.getListenAddress();
    }
    initialized = true;
    LogHelper.info("port="+port);
    LogHelper.info("listen_address="+listen_address);
    LogHelper.info("isDev="+isDev);
  }

  public static boolean isDevEnvironment() {
    if (! initialized) {
      try {
        init();
      }
      catch (Exception e) {
        LogHelper.error("error initialize apm domain info. ",e);
      }
    }
    return isDev;
  }

  public static String getDomainId() {
    if (! initialized) {
      try {
        init();
      }
      catch (Exception e) {
        LogHelper.error("error initialize apm domain info. ",e);
      }
    }
    return Integer.toString(port);
  }
}
