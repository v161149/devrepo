package com.verizon.enterprise.vps.util;

import java.sql.Timestamp;
import java.util.Date;

import com.verizon.enterprise.vps.schedule.ISchedule;

/**
 * <p>Title: vps</p> <p>Description: vps</p> <p>Copyright: Copyright (c)
 * 2003</p> <p>Company: Verizon</p>
 * 
 * @author Chunsheng Chen
 * @version 1.0
 */

public class TimeHelper {
  public static long getTime(Timestamp t) {
    return t == null ? 0 : t.getTime();
  }

  public static long getTime(Date t) {
    return t == null ? 0 : t.getTime();
  }

  public static long getTime(java.sql.Date t) {
    return t == null ? 0 : t.getTime();
  }

  public static long getTime(ISchedule t) {
    return t == null ? 0 : getTime(t.getTimeForNextSchedule());
  }
}