package com.verizon.enterprise.vps.util;

/**
 * Interface for classes that want to be notified by Watchdog.
 *
 * @see Watchdog
 */
public interface TimeoutObserver {
    void timeoutOccured(Watchdog w);
}
