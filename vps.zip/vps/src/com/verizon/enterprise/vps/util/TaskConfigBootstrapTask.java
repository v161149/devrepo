package com.verizon.enterprise.vps.util;

import com.verizon.kernel.config.Config;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.dataobjects.TaskParsingException;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.schedule.ISchedule;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

public class TaskConfigBootstrapTask implements IVpsTask
{
    public static final String CONFIG_FILE = "vps/vps_bootstrap.xml";
    public static final String XML_TAG_BOOTSTRAP = "bootstrap";
    public static final String XML_TAG_FILE = "file";

    /**
     * <vps>
     *   <file>bosi_vps.xml</file>
     *   <file>repair_vps.xml</file>
     * </vps>
     * @throws Exception
     */

    public void run() throws Exception
    {
        LogHelper.info("Loading vps main config bootstrap");
        java.net.URL config = Thread.currentThread().getContextClassLoader().getResource(CONFIG_FILE);
        if (null==config) {
            throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Cannot load resource: "+CONFIG_FILE);
        }

        java.io.InputStream is = config.openStream();
        org.jdom.Element elem = JDomUtil.parseXmlStream(is);
        is.close();
        LogHelper.info("Parsing bootstrap sub components");
        if (!elem.getName().equals(XML_TAG_BOOTSTRAP)) {
            throw new TaskParsingException(TaskParsingException.PARSING_ERROR, elem.getName()+"!="+XML_TAG_BOOTSTRAP);
        }
        java.util.List lst = elem.getChildren(XML_TAG_FILE);
        LogHelper.info(lst.size()+" sub components found.");
        for (java.util.Iterator it = lst.iterator(); it.hasNext();) {
            String sub_config = ((org.jdom.Element)it.next()).getTextTrim();
            TaskConfigReader reader = new TaskConfigReader(sub_config);
            while (reader.next()) {
                try {
                    IVpsTask task = reader.getTask();
                    ISchedule schedule = reader.getSchedule();

                    if (task != null)
                    {
                        LogHelper.info("Task found from "+sub_config);
                        if (schedule != null)
                        {
                            new ScheduleManager().scheduleTransientJob(task, schedule);
                        }
                        else
                        {
                            new ScheduleManager().scheduleTransientJob(task, new OnceSchedule());
                        }
                    }
                }
                catch (Exception e) {
                    LogHelper.error(e.getMessage());
                }
            }
        }
    }
    public String getDescription()
    {
        return getClass().getName();
    }
    public static void main(String[] args) throws Exception {
        new TaskConfigBootstrapTask().run();
    }
}