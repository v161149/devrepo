package com.verizon.enterprise.vps.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;

/**
 * <p>Title: Virtual Process Service</p> <p>Description: </p> <p>Copyright:
 * Copyright (c) 2003</p> <p>Company: Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */
public class LogHelper {
  private static Logger sm_log = Logger.getLogger("com.verizon.enterprise.vps");

  /** error */
  public static void error(Object msg) {
    sm_log.error(msg);
  }

  /** error */
  public static void error(Object msg, Throwable t) {
    sm_log.error(msg, t);
  }

  /** warning */
  public static void warn(Object msg) {
    sm_log.warn(msg);
  }

  /** warning */
  public static void warn(Object msg, Throwable t) {
    sm_log.warn(msg, t);
  }

  /** info */
  public static void info(Object msg) {
    sm_log.info(msg);
  }

  /** info */
  public static void info(Object msg, Throwable t) {
    sm_log.info(msg, t);
  }

  /** debug */
  public static void debug(Object msg) {
    sm_log.debug(msg);
  }

  /** debug */
  public static void debug(Object msg, Throwable t) {
    sm_log.debug(msg, t);
  }

  public static void logStacktrace(Throwable t) {
    StringWriter sw = new StringWriter();
    t.printStackTrace(new PrintWriter(sw));
    error(sw.toString());
  }
}