package com.verizon.enterprise.vps.util;

import com.verizon.kernel.config.Config;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class Domain
{
  public static String getDomainId() {
    String serverUrl = Config.getProperty("local_config.local_verizon", "verizon.local.serverURL",null);
    if ((serverUrl != null)&&(serverUrl.length()>0)) {
      return serverUrl;
    }
    return WlsDomain.isDevEnvironment() ? WlsDomain.getDomainId() : null;
  }
}
