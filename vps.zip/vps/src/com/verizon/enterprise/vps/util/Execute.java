/**
 * Code repackaged/modified from org.apache.tools.ant.taskdefs.Execute,
 * @version $Revision: 1.43.2.7,
 * to handle Verizon's logging requirement with log4j, and to remove the
 * dependency on ant.jar.
 */
package com.verizon.enterprise.vps.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import com.verizon.enterprise.vps.dataobjects.VpsException;

/**
 * Runs an external program.
 * 
 * @author chunsheng.chen@verizon.com
 */
public class Execute {

  /** Invalid exit code. * */
  public static final int INVALID = Integer.MAX_VALUE;

  private String[] cmdl = null;
  private String[] env = null;
  private int exitValue = INVALID;
  private ExecuteWatchdog watchdog;
  private File workingDirectory = null;

  private boolean newEnvironment = false;

  /** Controls whether the VM is used to launch commands, where possible */
  private boolean useVMLauncher = true;

  private boolean m_out = true;
  private boolean m_err = true;
  private boolean m_terminateifvmexit = false;
  private StreamHandler m_errorStreamHandler;
  private StreamHandler m_outputStreamHandler;
  private Process m_process;

  private static String antWorkingDirectory = System.getProperty("user.dir");
  private static CommandLauncher vmLauncher = null;
  private static CommandLauncher shellLauncher = null;
  private static Vector procEnvironment = null;

  /** Used to destroy processes when the VM exits. */
  private static ProcessDestroyer processDestroyer = new ProcessDestroyer();

  /**
   * Builds a command launcher for the OS and JVM we are running under
   */
  static {
    // Try using a JDK 1.3 launcher
    try {
      vmLauncher = new Java13CommandLauncher();
    } catch (NoSuchMethodException exc) {
      // Ignore and keep trying
    }

    if (Os.isFamily("mac")) {
      // Mac
      shellLauncher = new MacCommandLauncher(new CommandLauncher());
    } else if (Os.isFamily("os/2")) {
      // OS/2
      shellLauncher = new OS2CommandLauncher(new CommandLauncher());
    } else if (Os.isFamily("windows")) {
      // Windows. Need to determine which JDK we're running in

      CommandLauncher baseLauncher;
      if (System.getProperty("java.version").startsWith("1.1")) {
        // JDK 1.1
        baseLauncher = new Java11CommandLauncher();
      } else {
        // JDK 1.2
        baseLauncher = new CommandLauncher();
      }

      if (!Os.isFamily("win9x")) {
        // Windows XP/2000/NT
        shellLauncher = new WinNTCommandLauncher(baseLauncher);
      } else {
        // Windows 98/95 - need to use an auxiliary script
        shellLauncher = new ScriptCommandLauncher("bin/antRun.bat", baseLauncher);
      }
    } else if (Os.isFamily("netware")) {
      // NetWare. Need to determine which JDK we're running in
      CommandLauncher baseLauncher;
      if (System.getProperty("java.version").startsWith("1.1")) {
        // JDK 1.1
        baseLauncher = new Java11CommandLauncher();
      } else {
        // JDK 1.2
        baseLauncher = new CommandLauncher();
      }

      shellLauncher = new PerlScriptCommandLauncher("bin/antRun.pl", baseLauncher);
    } else {
      // Generic
      shellLauncher = new ScriptCommandLauncher("bin/antRun", new CommandLauncher());
    }
    getProcEnvironment();
  }

  /**
   * Find the list of environment variables for this process.
   */
  public static synchronized Vector getProcEnvironment() {
    if (procEnvironment != null) {
      return procEnvironment;
    }

    procEnvironment = new Vector();
    try {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      Execute exe = new Execute(getProcEnvCommand());
      // Make sure we do not recurse forever
      exe.setNewenvironment(true);
      exe.setOutputStreamHandler(new PipeStreamHandler(out));
      int retval = exe.execute();
      if (retval != 0) {
        // Just try to use what we got
      }
      BufferedReader in = new BufferedReader(new StringReader(toString(out)));

      String var = null;
      String line, lineSep = System.getProperty("line.separator");
      while ((line = in.readLine()) != null) {
        if (line.indexOf('=') == -1) {
          // Chunk part of previous env var (UNIX env vars can
          // contain embedded new lines).
          if (var == null) {
            var = lineSep + line;
          } else {
            var += lineSep + line;
          }
        } else {
          // New env var...append the previous one if we have it.
          if (var != null) {
            procEnvironment.addElement(var);
          }
          var = line;
        }
      }
      // Since we "look ahead" before adding, there's one last env var.
      if (var != null) {
        procEnvironment.addElement(var);
      }
    } catch (IOException e) {
      LogHelper.warn(e);
    } catch (VpsException e) {
      LogHelper.warn(e);
    }
    return procEnvironment;
  }

  private static String[] getProcEnvCommand() {
    if (Os.isFamily("os/2")) {
      // OS/2 - use same mechanism as Windows 2000
      String[] cmd = {"cmd", "/c", "set"};
      return cmd;
    } else if (Os.isFamily("windows")) {
      // Determine if we're running under XP/2000/NT or 98/95
      if (!Os.isFamily("win9x")) {
        // Windows XP/2000/NT
        String[] cmd = {"cmd", "/c", "set"};
        return cmd;
      } else {
        // Windows 98/95
        String[] cmd = {"command.com", "/c", "set"};
        return cmd;
      }
    } else if (Os.isFamily("z/os")) {
      String[] cmd = {"/bin/env"};
      return cmd;
    } else if (Os.isFamily("unix")) {
      // Generic UNIX
      // Alternatively one could use: /bin/sh -c env
      String[] cmd = {"/usr/bin/env"};
      return cmd;
    } else if (Os.isFamily("netware")) {
      String[] cmd = {"env"};
      return cmd;
    } else {
      // MAC OS 9 and previous
      // TODO: I have no idea how to get it, someone must fix it
      String[] cmd = null;
      return cmd;
    }
  }

  /**
   * ByteArrayOutputStream#toString doesn't seem to work reliably on OS/390, at
   * least not the way we use it in the execution context.
   * 
   * @since Ant 1.5
   */
  public static String toString(ByteArrayOutputStream bos) {
    if (Os.isFamily("z/os")) {
      try {
        return bos.toString("Cp1047");
      } catch (java.io.UnsupportedEncodingException e) {
      }
    }
    return bos.toString();
  }

  public Execute(String[] cmd) {
    this.setCommandline(cmd);
  }

  public Execute(String[] cmd, long timeout_ms) {
    this.setCommandline(cmd);
    this.watchdog = new ExecuteWatchdog(timeout_ms);
  }

  /**
   * Returns the commandline used to create a subprocess.
   * 
   * @return the commandline used to create a subprocess
   */
  public String[] getCommandline() {
    return cmdl;
  }

  /**
   * Sets the commandline of the subprocess to launch.
   * 
   * @param commandline the commandline of the subprocess to launch
   */
  protected void setCommandline(String[] commandline) {
    cmdl = commandline;
  }

  /**
   * Set whether to propagate the default environment or not.
   * 
   * @param newenv whether to propagate the process environment.
   */
  public void setNewenvironment(boolean newenv) {
    newEnvironment = newenv;
  }

  /**
   * Returns the environment used to create a subprocess.
   * 
   * @return the environment used to create a subprocess
   */
  public String[] getEnvironment() {
    if (newEnvironment) {
      return env;
    }
    return patchEnvironment();
  }

  /**
   * Sets the environment variables for the subprocess to launch.
   * 
   * @param env array of Strings, each element of which has an environment
   *        variable settings in format <em>key=value</em>
   */
  public void setEnvironment(String[] env) {
    this.env = env;
  }

  /**
   * Sets the working directory of the process to execute. <p>This is emulated
   * using the antRun scripts unless the OS is Windows NT in which case a
   * cmd.exe is spawned, or MRJ and setting user.dir works, or JDK 1.3 and there
   * is official support in java.lang.Runtime.
   * 
   * @param wd the working directory of the process.
   */
  public void setWorkingDirectory(File wd) {
    // cc00-patch: for windows, we need spawn cmd.exe
    if ((shellLauncher != null) && (shellLauncher instanceof WinNTCommandLauncher)) {
      workingDirectory = wd;
      return;
    }
    // cc00-patch: end of patch
    if (wd == null || wd.getAbsolutePath().equals(antWorkingDirectory)) {
      workingDirectory = null;
    } else {
      workingDirectory = wd;
    }
  }

  /**
   * Launch this execution through the VM, where possible, rather than through
   * the OS's shell. In some cases and operating systems using the shell will
   * allow the shell to perform additional processing such as associating an
   * executable with a script, etc
   * 
   * @param useVMLauncher true if exec should launch through thge VM, false if
   *        the shell should be used to launch the command.
   */
  public void setVMLauncher(boolean useVMLauncher) {
    this.useVMLauncher = useVMLauncher;
  }

  public void setOut(boolean out) {
    m_out = out;
  }

  public void setErr(boolean err) {
    m_err = err;
  }

  public void setTerminateIfVMExit(boolean kill) {
    m_terminateifvmexit = kill;
  }

  public boolean getTerminateIfVMExit() {
    return m_terminateifvmexit;
  }

  /**
   * Creates a process that runs a command.
   * 
   * @param command the command to run
   * @param env the environment for the command
   * @param dir the working directory for the command
   * @param useVM use the built-in exec command for JDK 1.3 if available.
   */
  public static Process launch(String[] command, String[] env, File dir, boolean useVM) throws VpsException {
    CommandLauncher launcher = vmLauncher != null ? vmLauncher : shellLauncher;
    if (!useVM) {
      launcher = shellLauncher;
    }

    return launcher.exec(command, env, dir);
  }

  private void setOutputStreamHandler(StreamHandler handler) {
    this.m_outputStreamHandler = handler;
  }

  /**
   * Runs a process defined by the command line and returns its exit status.
   * 
   * @return the exit status of the subprocess or <code>INVALID</code>
   * @exception java.io.IOException The exception is thrown, if launching of the
   *            subprocess failed
   */
  public int execute() throws VpsException {
    String[] cmd = getCommandline();
    logCommand(cmd);
    m_out = true;
    m_err = true;
    if (m_out) {
      if (null == m_outputStreamHandler)
        m_outputStreamHandler = new LogStreamHandler(false);
    }
    if (m_err) {
      if (null == m_errorStreamHandler)
        m_errorStreamHandler = new LogStreamHandler(true);
    }

    m_process = launch(cmd, getEnvironment(), workingDirectory, useVMLauncher);

    try {
      // We cann't determine whether the invoked process has output or
      // not, play safety here.
      if (m_out) {
        m_outputStreamHandler.handleStream(m_process.getInputStream());
      }
      if (m_err) {
        m_errorStreamHandler.handleStream(m_process.getErrorStream());
      }
    } catch (Exception e) {
      m_process.destroy();
      throw new ExecException(cmd[0], e);
    }

    // if (m_terminateifvmexit) {
    // add the process to the list of those to destroy if the VM exits
    processDestroyer.add(m_task_oid, this);
    // }

    if (watchdog != null) {
      watchdog.start(m_process);
    }

    waitFor(m_process);

    // if (m_terminateifvmexit) {
    // remove the process to the list of those to destroy if the VM exits
    processDestroyer.remove(m_task_oid, this);
    // }

    if (watchdog != null) {
      watchdog.stop();
      watchdog.checkException();
    }
    return getExitValue();
  }

  private Long m_task_oid;

  public void setTaskContext(Long task_oid) {
    m_task_oid = task_oid;
  }

  /**
   * stop the current execution.
   */
  public void stop() {
    if (m_process != null) {
      m_process.destroy();
      processDestroyer.remove(m_task_oid, this);
    }
  }

  /**
   * stop execution of exec task with task_oid.
   */
  public static void stop(Long task_oid) {
    processDestroyer.stop(task_oid);
  }

  protected void waitFor(Process process) {
    try {
      process.waitFor();
      setExitValue(process.exitValue());
    } catch (InterruptedException e) {
      process.destroy();
    }
  }

  protected void setExitValue(int value) {
    exitValue = value;
  }

  /**
   * query the exit value of the process.
   * 
   * @return the exit value, 1 if the process was killed, or Project.INVALID if
   *         no exit value has been received
   */
  public int getExitValue() {
    return exitValue;
  }

  /**
   * test for an untimely death of the process
   * 
   * @return true iff a watchdog had to kill the process.
   */
  public boolean killedProcess() {
    return watchdog != null && watchdog.killedProcess();
  }

  /**
   * Patch the current environment with the new values from the user.
   * 
   * @return the patched environment
   */
  private String[] patchEnvironment() {
    Vector osEnv = (Vector)getProcEnvironment().clone();
    if (env != null) {
      for (int i = 0; i < env.length; i++) {
        int pos = env[i].indexOf('=');
        // Get key including "="
        String key = env[i].substring(0, pos + 1);
        int size = osEnv.size();
        for (int j = 0; j < size; j++) {
          if (((String)osEnv.elementAt(j)).startsWith(key)) {
            osEnv.removeElementAt(j);
            break;
          }
        }
        osEnv.addElement(env[i]);
      }
    }
    String[] result = new String[osEnv.size()];
    osEnv.copyInto(result);
    return result;
  }

  /**
   * A utility method that runs an external command. Writes the output and error
   * streams of the command to the project log.
   * 
   * @param task The task that the command is part of. Used for logging
   * @param cmdline The command to execute.
   * @throws BuildException if the command does not return 0.
   */
  public static void runCommand(String[] cmdline) throws VpsException {
    Execute exe = new Execute(cmdline);
    int retval = exe.execute();
    if (retval != 0) {
      throw new ExecException(cmdline[0] + " failed with return code " + retval);
    }
  }

  private static void logCommand(String[] cmdline) {
    if (cmdline == null || cmdline.length == 0) {
      return;
    }

    StringBuffer buf = new StringBuffer("Executing \'").append(cmdline[0]).append("\'");
    if (cmdline.length > 0) {
      String LINE_SEP = System.getProperty("line.separator");
      buf.append(" with ");
      if (cmdline.length > 1) {
        buf.append("argument");
        if (cmdline.length > 2) {
          buf.append("s");
        }
        buf.append(":").append(LINE_SEP);
        for (int i = 1; i < cmdline.length; i++) {
          buf.append("\'").append(cmdline[i]).append("\'").append(LINE_SEP);
        }
      }
    }
    LogHelper.info(buf.toString());
  }

  class LogStreamHandler extends StreamHandler {
    private boolean err; // is this an error stream;

    public LogStreamHandler(boolean err) {
      this.err = err;
    }

    public void run() {
      finished = false;

      try {
        String line = null;
        while ((line = reader.readLine()) != null) {
          if (err) {
            LogHelper.error("[" + getCommandline()[0] + "] " + line);
          } else {
            LogHelper.info("[" + getCommandline()[0] + "] " + line);
          }
          line = null;
        }
      } catch (Exception warning) {
        LogHelper.warn(warning);
      } finally {
        finished = true;
      }
    }
  }

  /**
   * A command launcher for a particular JVM/OS platform. This class is a
   * general purpose command launcher which can only launch commands in the
   * current working directory.
   */
  private static class CommandLauncher {
    /**
     * Launches the given command in a new process.
     * 
     * @param project The project that the command is part of
     * @param cmd The command to execute
     * @param env The environment for the new process. If null, the environment
     *        of the current proccess is used.
     */
    public Process exec(String[] cmd, String[] env) throws VpsException {
      try {
        return Runtime.getRuntime().exec(cmd, env);
      } catch (IOException e) {
        throw new ExecException(cmd[0], e);
      }
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory.
     * 
     * @param cmd The command to execute
     * @param env The environment for the new process. If null, the environment
     *        of the current proccess is used.
     * @param workingDir The directory to start the command in. If null, the
     *        current directory is used
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      if (workingDir == null) {
        return exec(cmd, env);
      }
      throw new ExecException("Cannot execute a process " + cmd[0] + " in different directory under this JVM");
    }
  }

  /**
   * A command launcher for JDK/JRE 1.1 under Windows. Fixes quoting problems in
   * Runtime.exec(). Can only launch commands in the current working directory
   */
  private static class Java11CommandLauncher extends CommandLauncher {
    /**
     * Launches the given command in a new process. Needs to quote arguments
     */
    public Process exec(String[] cmd, String[] env) throws VpsException {
      // Need to quote arguments with spaces, and to escape
      // quote characters
      String[] newcmd = new String[cmd.length];
      for (int i = 0; i < cmd.length; i++) {
        newcmd[i] = quoteArgument(cmd[i]);
      }
      try {
        return Runtime.getRuntime().exec(newcmd, env);
      } catch (IOException e) {
        throw new ExecException(newcmd[0], e);
      }
    }

    public String quoteArgument(String argument) throws VpsException {
      if (argument.indexOf("\"") > -1) {
        if (argument.indexOf("\'") > -1) {
          throw new ExecException("Can\'t handle single and double quotes in same argument");
        } else {
          return '\'' + argument + '\'';
        }
      } else if (argument.indexOf("\'") > -1 || argument.indexOf(" ") > -1) {
        return '\"' + argument + '\"';
      } else {
        return argument;
      }
    }
  }

  /**
   * A command launcher for JDK/JRE 1.3 (and higher). Uses the built-in
   * Runtime.exec() command
   */
  private static class Java13CommandLauncher extends CommandLauncher {
    public Java13CommandLauncher() throws NoSuchMethodException {
      // Locate method Runtime.exec(String[] cmdarray,
      // String[] envp, File dir)
      _execWithCWD = Runtime.class.getMethod("exec", new Class[] {String[].class, String[].class, File.class});
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      try {
        Object[] arguments = {cmd, env, workingDir};
        return (Process)_execWithCWD.invoke(Runtime.getRuntime(), arguments);
      } catch (InvocationTargetException exc) {
        Throwable realexc = exc.getTargetException();
        if (realexc instanceof ThreadDeath) {
          throw (ThreadDeath)realexc;
        } else if (realexc instanceof IOException) {
          throw new ExecException(cmd[0], realexc);
        } else {
          throw new ExecException(cmd[0], realexc);
        }
      } catch (Exception exc) {
        // IllegalAccess, IllegalArgument, ClassCast
        throw new ExecException(cmd[0], exc);
      }
    }

    private Method _execWithCWD;
  }

  /**
   * A command launcher that proxies another command launcher. Sub-classes
   * override exec(args, env, workdir)
   */
  private static class CommandLauncherProxy extends CommandLauncher {
    CommandLauncherProxy(CommandLauncher launcher) {
      _launcher = launcher;
    }

    /**
     * Launches the given command in a new process. Delegates this method to the
     * proxied launcher
     */
    public Process exec(String[] cmd, String[] env) throws VpsException {
      return _launcher.exec(cmd, env);
    }

    private CommandLauncher _launcher;
  }

  /**
   * A command launcher for OS/2 that uses 'cmd.exe' when launching commands in
   * directories other than the current working directory. <p>Unlike Windows NT
   * and friends, OS/2's cd doesn't support the /d switch to change drives and
   * directories in one go.</p>
   */
  private static class OS2CommandLauncher extends CommandLauncherProxy {
    OS2CommandLauncher(CommandLauncher launcher) {
      super(launcher);
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory.
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      File commandDir = workingDir;
      if (workingDir == null) {
        return exec(cmd, env);
      }

      // Use cmd.exe to change to the specified drive and
      // directory before running the command
      final int preCmdLength = 7;
      final String cmdDir = commandDir.getAbsolutePath();
      String[] newcmd = new String[cmd.length + preCmdLength];
      newcmd[0] = "cmd";
      newcmd[1] = "/c";
      newcmd[2] = cmdDir.substring(0, 2);
      newcmd[3] = "&&";
      newcmd[4] = "cd";
      newcmd[5] = cmdDir.substring(2);
      newcmd[6] = "&&";
      System.arraycopy(cmd, 0, newcmd, preCmdLength, cmd.length);

      return exec(newcmd, env);
    }
  }

  /**
   * A command launcher for Windows XP/2000/NT that uses 'cmd.exe' when
   * launching commands in directories other than the current working directory.
   */
  private static class WinNTCommandLauncher extends CommandLauncherProxy {
    WinNTCommandLauncher(CommandLauncher launcher) {
      super(launcher);
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory.
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      File commandDir = workingDir;
      if (workingDir == null) {
        return exec(cmd, env);
      }

      // Use cmd.exe to change to the specified directory before running
      // the command
      final int preCmdLength = 6;
      String[] newcmd = new String[cmd.length + preCmdLength];
      newcmd[0] = "cmd";
      newcmd[1] = "/c";
      newcmd[2] = "cd";
      newcmd[3] = "/d";
      newcmd[4] = commandDir.getAbsolutePath();
      newcmd[5] = "&&";
      System.arraycopy(cmd, 0, newcmd, preCmdLength, cmd.length);

      return exec(newcmd, env);
    }
  }

  /**
   * A command launcher for Mac that uses a dodgy mechanism to change working
   * directory before launching commands.
   */
  private static class MacCommandLauncher extends CommandLauncherProxy {
    MacCommandLauncher(CommandLauncher launcher) {
      super(launcher);
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      if (workingDir == null) {
        return exec(cmd, env);
      }

      System.getProperties().put("user.dir", workingDir.getAbsolutePath());
      try {
        return exec(cmd, env);
      } finally {
        System.getProperties().put("user.dir", antWorkingDirectory);
      }
    }
  }

  /**
   * A command launcher that uses an auxiliary script to launch commands in
   * directories other than the current working directory.
   */
  private static class ScriptCommandLauncher extends CommandLauncherProxy {
    ScriptCommandLauncher(String script, CommandLauncher launcher) {
      super(launcher);
      _script = script;
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      // if (workingDir == null) {
      return exec(cmd, env);
      // }
      // throw new ExecException("Cannot locate antRun script: "
      // + "No project provided");
    }

    private String _script;
  }

  /**
   * A command launcher that uses an auxiliary perl script to launch commands in
   * directories other than the current working directory.
   */
  private static class PerlScriptCommandLauncher extends CommandLauncherProxy {
    PerlScriptCommandLauncher(String script, CommandLauncher launcher) {
      super(launcher);
      _script = script;
    }

    /**
     * Launches the given command in a new process, in the given working
     * directory
     */
    public Process exec(String[] cmd, String[] env, File workingDir) throws VpsException {
      if (workingDir == null) {
        return exec(cmd, env);
      }
      throw new ExecException("Cannot locate antRun script: No project provided");
    }

    private String _script;
  }
}

class ExecException extends VpsException {
  private String[] m_qAllErrorMessages = new String[] {"Unable to execute command."};

  public ExecException(String msg) {
    super(0, msg);
    m_qAllErrorMessages[0] += "\n" + msg;
  }

  public ExecException(Throwable cause) {
    super(0, cause.getMessage());
    m_qAllErrorMessages[0] += "\n" + cause.getMessage();
  }

  public ExecException(String msg, Throwable cause) {
    super(0, msg, cause.getMessage());
    m_qAllErrorMessages[0] += "\n" + msg + "\n" + cause.getMessage();
  }

  protected String[] getAllErrorMessages() {
    return m_qAllErrorMessages;
  }
}

class ProcessDestroyer extends Thread {

  private Hashtable processes = new Hashtable();

  /**
   * Constructs a <code>ProcessDestroyer</code> and registers it as a shutdown
   * hook.
   */
  public ProcessDestroyer() {
    Runtime.getRuntime().addShutdownHook(this);
  }

  /**
   * Returns <code>true</code> if the specified <code>Process</code> was
   * successfully added to the list of processes to destroy upon VM exit.
   * 
   * @param process the process to add
   * @return <code>true</code> if the specified <code>Process</code> was
   *         successfully added
   */
  public boolean add(Long task_oid, Execute process) {
    if (task_oid == null) {
      return false;
    }
    processes.put(task_oid, process);
    return processes.contains(process);
  }

  /**
   * Returns <code>true</code> if the specified <code>Process</code> was
   * successfully removed from the list of processes to destroy upon VM exit.
   * 
   * @param process the process to remove
   * @return <code>true</code> if the specified <code>Process</code> was
   *         successfully removed
   */
  public boolean remove(Long task_oid, Execute process) {
    return (task_oid != null) && (processes.remove(task_oid) != null);
  }

  void stop(Long task_oid) {
    if (task_oid != null) {
      Execute p = (Execute)processes.get(task_oid);
      if (p != null) {
        p.stop();
      }
    }
  }

  /**
   * Invoked by the VM when it is exiting.
   */
  public void run() {
    synchronized (processes) {
      for (Iterator it = processes.values().iterator(); it.hasNext();) {
        Execute exe = (Execute)it.next();
        if (exe.getTerminateIfVMExit())
          exe.stop();
      }
    }
  }
}

class StreamHandler implements Runnable {
  protected InputStream is;
  protected java.io.BufferedReader reader;
  protected boolean finished;

  public void handleStream(InputStream is) {
    this.is = is;
    reader = new java.io.BufferedReader(new java.io.InputStreamReader(is));
    new Thread(this).start();
  }

  /**
   * dummy implementation Terminates as soon as the input stream is closed or an
   * error occurs.
   */
  public void run() {
    finished = false;

    try {
      String line = null;
      while ((line = reader.readLine()) != null) {
        LogHelper.info("0: " + line);
        line = null;
      }
    } catch (Exception warning) {
      LogHelper.warn(warning);
    } finally {
      finished = true;
    }
  }

  /**
   * Tells whether the end of the stream has been reached.
   * 
   * @return true is the stream has been exhausted.
   */
  public synchronized boolean isFinished() {
    return finished;
  }

  /**
   * This method blocks until the stream pumper finishes.
   * 
   * @see #isFinished()
   */
  public synchronized void waitFor() throws InterruptedException {
    while (!isFinished()) {
      wait();
    }
  }
}

class PipeStreamHandler extends StreamHandler {
  private OutputStream os;

  public PipeStreamHandler(OutputStream os) {
    this.os = os;
  }

  public void run() {
    finished = false;
    final byte[] buf = new byte[128];
    int length;
    try {
      while ((length = is.read(buf)) > 0) {
        os.write(buf, 0, length);
      }
    } catch (Exception e) {
      LogHelper.warn(e);
    } finally {
      finished = true;
    }
  }
}

class ExecuteWatchdog implements TimeoutObserver {

  /** the process to execute and watch for duration */
  private Process process;

  /** say whether or not the watchog is currently monitoring a process */
  private boolean watch = false;

  /** exception that might be thrown during the process execution */
  private Exception caught = null;

  /** say whether or not the process was killed due to running overtime */
  private boolean killedProcess = false;

  /** will tell us whether timeout has occured */
  private Watchdog watchdog;

  /**
   * Creates a new watchdog with a given timeout.
   * 
   * @param timeout the timeout for the process in milliseconds. It must be
   *        greather than 0.
   */
  public ExecuteWatchdog(long timeout) {
    watchdog = new Watchdog(timeout);
    watchdog.addTimeoutObserver(this);
  }

  /**
   * @see #ExecuteWatchdog(long)
   * @deprecated Use constructor with a long type instead. (1.4.x compatibility)
   */
  public ExecuteWatchdog(int timeout) {
    this((long)timeout);
  }

  /**
   * Watches the given process and terminates it, if it runs for too long. All
   * information from the previous run are reset.
   * 
   * @param process the process to monitor. It cannot be <tt>null</tt>
   * @throws IllegalStateException if a process is still being monitored.
   */
  public synchronized void start(Process process) {
    if (process == null) {
      throw new NullPointerException("process is null.");
    }
    if (this.process != null) {
      throw new IllegalStateException("Already running.");
    }
    this.caught = null;
    this.killedProcess = false;
    this.watch = true;
    this.process = process;
    watchdog.start();
  }

  /**
   * Stops the watcher. It will notify all threads possibly waiting on this
   * object.
   */
  public synchronized void stop() {
    watchdog.stop();
    watch = false;
    process = null;
  }

  /**
   * Called after watchdog has finished.
   */
  public void timeoutOccured(Watchdog w) {
    try {
      try {
        // We must check if the process was not stopped
        // before being here
        process.exitValue();
      } catch (IllegalThreadStateException itse) {
        // the process is not terminated, if this is really
        // a timeout and not a manual stop then kill it.
        if (watch) {
          killedProcess = true;
          process.destroy();
        }
      }
    } catch (Exception e) {
      caught = e;
    } finally {
      cleanUp();
    }
  }

  /**
   * reset the monitor flag and the process.
   */
  protected void cleanUp() {
    watch = false;
    process = null;
  }

  /**
   * This method will rethrow the exception that was possibly caught during the
   * run of the process. It will only remains valid once the process has been
   * terminated either by 'error', timeout or manual intervention. Information
   * will be discarded once a new process is ran.
   * 
   * @throws BuildException a wrapped exception over the one that was silently
   *         swallowed and stored during the process run.
   */
  public void checkException() throws VpsException {
    if (caught != null) {
      throw new ExecException("Exception in ExecuteWatchdog.run: " + caught.getMessage(), caught);
    }
  }

  /**
   * Indicates whether or not the watchdog is still monitoring the process.
   * 
   * @return <tt>true</tt> if the process is still running, otherwise
   *         <tt>false</tt>.
   */
  public boolean isWatching() {
    return watch;
  }

  /**
   * Indicates whether the last process run was killed on timeout or not.
   * 
   * @return <tt>true</tt> if the process was killed otherwise <tt>false</tt>.
   */
  public boolean killedProcess() {
    return killedProcess;
  }
}
