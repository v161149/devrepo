package com.verizon.enterprise.vps.util;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.verizon.enterprise.vps.core.ExecutionTask;

/**
 * <p>Title: vps</p> <p>Description: vps</p> <p>Copyright: Copyright (c)
 * 2003</p> <p>Company: Verizon</p>
 * 
 * @author Chunsheng Chen
 * @version 1.0
 */

public class JmsHelper {
  private static Queue persistent_queue;
  private static Queue non_persistent_queue;
  private static QueueConnectionFactory queueConnectionFactory;

  public static final String CONNECTION_FACTORY = "weblogic.jms.ConnectionFactory";
  public static final String PERSISTENT_EXECUTION_QUEUE_NAME = "PERSISTENT_EXECUTION_QUEUE";
  public static final String NON_PERSISTENT_EXECUTION_QUEUE_NAME = "NON_PERSISTENT_EXECUTION_QUEUE";

  public static void postPersistentMessage(ExecutionTask msg) throws JMSException, NamingException {
    if (null == persistent_queue) {
      Context jndiContext = new InitialContext();
      persistent_queue = (Queue)jndiContext.lookup(PERSISTENT_EXECUTION_QUEUE_NAME);
    }
    postMessage(persistent_queue, msg);
  }

  public static void postNonPersistentMessage(ExecutionTask msg) throws JMSException, NamingException {
    if (null == non_persistent_queue) {
      Context jndiContext = new InitialContext();
      non_persistent_queue = (Queue)jndiContext.lookup(NON_PERSISTENT_EXECUTION_QUEUE_NAME);
    }
    postMessage(non_persistent_queue, msg);
  }

  public static void postMessage(Queue queue, ExecutionTask msg) throws JMSException, NamingException {
    if (null == queueConnectionFactory) {
      Context jndiContext = new InitialContext();
      queueConnectionFactory = (QueueConnectionFactory)jndiContext.lookup(CONNECTION_FACTORY);
    }

    QueueConnection queueConnection = null;
    QueueSession queueSession = null;
    QueueSender queueSender = null;

    try {
      queueConnection = queueConnectionFactory.createQueueConnection();
      queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
      queueSender = queueSession.createSender(queue);
      Message message = queueSession.createObjectMessage(msg);

      LogHelper.info("Sending message: " + message);
      queueSender.send(message);
      // queueSession.commit();
    } finally {
      if (null != queueSender)
        queueSender.close();
      if (null != queueSession)
        queueSession.close();
      if (null != queueConnection)
        queueConnection.close();
    }
  }

}