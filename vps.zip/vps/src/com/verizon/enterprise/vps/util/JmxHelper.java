package com.verizon.enterprise.vps.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import javax.management.ObjectName;

import weblogic.management.Helper;
import weblogic.management.MBeanHome;
import weblogic.management.WebLogicObjectName;
import weblogic.management.runtime.ServerRuntimeMBean;

/**
 * <p>Title: vps</p> <p>Description: vps</p> <p>Copyright: Copyright (c)
 * 2003</p> <p>Company: Verizon</p>
 * 
 * @author cc00
 * @version 1.1
 */

public class JmxHelper {
  private String ADMIN_URL;
  private String ADMIN_USER;
  private String ADMIN_PW;

  public JmxHelper(String adminuser, String adminpasswd) throws Exception {
    ADMIN_USER = adminuser;
    ADMIN_PW = adminpasswd;
    ADMIN_URL = probeAdminUrl();
  }

  public JmxHelper(String adminserver, int adminport, String adminuser, String adminpasswd) {
    ADMIN_USER = adminuser;
    ADMIN_PW = adminpasswd;
    ADMIN_URL = "t3://" + adminserver + ":" + adminport;
  }

  public MBeanHome getAdminMBeanHome() {
    return Helper.getAdminMBeanHome(ADMIN_USER, ADMIN_PW, ADMIN_URL);
  }

  public MBeanHome getMBeanHome() {
    return getMBeanHome("localhome");
  }

  public MBeanHome getMBeanHome(String server_name) {
    return Helper.getMBeanHome(ADMIN_USER, ADMIN_PW, ADMIN_URL, server_name);
  }

  public MBeanHome[] getLiveApplicationMBeanHomes() {
    MBeanHome[] homes;
    MBeanHome adminhome = getAdminMBeanHome();
    Set servers = adminhome.getMBeansByType("ServerRuntime");

    ArrayList lst = new ArrayList(servers.size());
    for (Iterator it = servers.iterator(); it.hasNext();) {
      ServerRuntimeMBean b = (ServerRuntimeMBean)it.next();
      LogHelper.debug("###" + b.getName() + " is up since " + new Date(b.getActivationTime()));
      if (isApplicationServer(b)) {
        LogHelper.debug("###" + b.getName() + " is adminserver");
      } else {
        MBeanHome h = getMBeanHome(b.getName());
        lst.add(h);
        LogHelper.debug("###" + h.getMBeanServer().getServerName() + " MBeanHome found");
      }
    }
    homes = new MBeanHome[lst.size()];
    lst.toArray(homes);
    return homes;
  }

  public MBeanHome[] getLiveManagedMBeanHomes() {
    MBeanHome[] homes;
    MBeanHome adminhome = getAdminMBeanHome();
    Set servers = adminhome.getMBeansByType("ServerRuntime");

    ArrayList lst = new ArrayList(servers.size());
    for (Iterator it = servers.iterator(); it.hasNext();) {
      ServerRuntimeMBean b = (ServerRuntimeMBean)it.next();
      LogHelper.debug("###" + b.getName() + " is up since " + new Date(b.getActivationTime()));
      if (isAdminServer(b)) {
        LogHelper.debug("###" + b.getName() + " is adminserver");
      } else {
        MBeanHome h = getMBeanHome(b.getName());
        lst.add(h);
        LogHelper.debug("###" + h.getMBeanServer().getServerName() + " MBeanHome found");
      }
    }
    homes = new MBeanHome[lst.size()];
    lst.toArray(homes);
    return homes;
  }

  public static MBeanHome getLocalMBeanHome() throws Exception {
    javax.naming.Context ctx = new javax.naming.InitialContext();
    MBeanHome home = null;
    try {
      home = (MBeanHome)ctx.lookup(MBeanHome.LOCAL_JNDI_NAME);
    } finally {
      if (null != ctx)
        ctx.close();
      ctx = null;
    }
    if (null == home)
      throw new Exception("failed lookup JNDI name " + MBeanHome.LOCAL_JNDI_NAME);
    return home;
  }

  public static String probeAdminUrl() throws Exception {
    MBeanHome home = getLocalMBeanHome();

    weblogic.management.configuration.ServerMBean[] b2 = home.getActiveDomain().getServers();
    for (int i = 0; i < b2.length; i++) {
      if (b2[i].getCluster() == null) {
        LogHelper.debug("$$$" + b2[i].getName());
        LogHelper.debug(b2[i].getName() + " is admin server");
        String adminserver = b2[i].getListenAddress();
        if (null == adminserver)
          adminserver = "localhost";
        int adminport = b2[i].getListenPort();
        return "t3://" + adminserver + ":" + adminport;
      }
    }

    throw new Exception("Cannot find admin server address or port");
  }

  public static ObjectName getVpsObjectName(String server) throws Exception {
    return new WebLogicObjectName("VpsRuntime", "VpsRuntimeMBean", "operations", server);
  }

  // for developer port, the application is running inside admin server, except
  // the name is myserver (CVS) or 10888 (port number in Continuus).
  private boolean isApplicationServer(ServerRuntimeMBean b) {
    return b.getName().equals("adminserver");
  }

  private boolean isAdminServer(ServerRuntimeMBean b) {
    if (getWLSVersion(b.getWeblogicVersion()) >= 7.0) {
      return b.isAdminServer();
    } else {
      return b.getName().equals("adminserver");
    }
  }

  private double getWLSVersion(String version) {
    if (version.indexOf("WebLogic Server 6.1") >= 0) {
      return 6.1;
    } else {
      return 7.0;
    }
  }
}