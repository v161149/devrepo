package com.verizon.enterprise.vps.util;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import org.apache.log4j.Logger;

public class StringUtil
{
    private static Logger log = Logger.getLogger(StringUtil.class);
    static String SPACE_60 =
        "                                                              ";

    /**
     *  Replace String src by String trg within originStr
     *  Author: Gang Fu
     */
    public static String replace(String sourceStr, String src, String trg)
    {
        final String METHOD_NAME = "replace()";
        int startIndex, endIndex;
        String targetStr = "";

        log.info("ENTRY: " + METHOD_NAME);

        if (sourceStr == null || src == null || trg == null)
        {
            log.debug(METHOD_NAME +
                      ": one of the string is null. No replacement needed.");

            log.info("EXIT: " + METHOD_NAME);

            return sourceStr;
        }

        startIndex = 0;

        while (true)
        {
            endIndex = sourceStr.indexOf(src, startIndex);

            log.debug(METHOD_NAME + ": startIndex = " + startIndex);
            log.debug(METHOD_NAME + ": endIndex = " + endIndex);

            // not found
            if (endIndex < 0)
            {
                //log.debug1(METHOD_NAME + ": No more " + src + " is found in str = /" + sourceStr + "/");
                targetStr += sourceStr.substring(startIndex);
                break;
            }
            else
            {
                log.debug(METHOD_NAME +
                          ": one " + src + " is found in str = /" + sourceStr + "/ at index = " + endIndex);

                targetStr += sourceStr.substring(startIndex, endIndex);
                targetStr += trg;
                startIndex = endIndex + src.length();
            }
        }  // while(true)

        log.info("EXIT: " + METHOD_NAME);

        return targetStr;
    }

    /**
     *  Trim head space
     *  Author: Gang Fu
     */
    public static String trimHead(String sourceStr)
    {
        final String METHOD_NAME = "StringUtil.trimHead()";
        int startIndex;
        String targetStr = "";

        log.info(" ENTRY: " + METHOD_NAME);

        log.debug(METHOD_NAME + ": sourceStr = " + sourceStr);

        if (sourceStr == null)
        {
            log.debug(METHOD_NAME +
                      ": sourceStr is null. No trim needed.");

            log.info(" EXIT: " + METHOD_NAME);
            return sourceStr;
        }

        if (sourceStr.trim().length() == 0)
        {
            log.debug(METHOD_NAME +
                      ": sourceStr is empty or contains only space.");

            log.info(" EXIT: " + METHOD_NAME);
            return sourceStr;
        }

        for (startIndex = 0; startIndex < sourceStr.length(); startIndex++)
        {
            if (!Character.isSpaceChar(sourceStr.charAt(startIndex)))
                break;
        }

        log.debug(METHOD_NAME +
                  ": startIndex = " + startIndex);

        targetStr = sourceStr.substring(startIndex);

        log.debug(METHOD_NAME +
                  ": targetStr = " + targetStr);

        log.info(" EXIT: " + METHOD_NAME);

        return targetStr;
      }

      /**
       *  Trim both head space and tail space
       *  Author: Gang Fu
       */
      public static String trimAll(String sourceStr)
      {
          final String METHOD_NAME = "StringUtil.trimHead()";
          int startIndex;
          String targetStr = "";

          targetStr = trimHead(sourceStr);
          if (targetStr == null)
              return null;
          return targetStr.trim();
      }

      /**
       *  Convert Xml reserved char to predefined entity reference
       *  Author: Gang Fu
       */
      public static String XmlValidate(String sourceStr)
      {
          final String METHOD_NAME = "StringUtil.xmlValidate()";

          if (sourceStr == null || sourceStr.trim().length() == 0)
              return sourceStr;

          String targetStr;

          sourceStr = StringUtil.replace(sourceStr, "&", "&amp;");
          sourceStr = StringUtil.replace(sourceStr, "<", "&lt;");
          sourceStr = StringUtil.replace(sourceStr, ">", "&gt;");
          sourceStr = StringUtil.replace(sourceStr, "\"", "&qout;");
          targetStr = StringUtil.replace(sourceStr, "'", "&apos;");
          return targetStr;
      }

      /**
       *  Generate String of space char
       *  Author Gang Fu
       */
      public static String indent(int value)
      {
          if (value <= 0)
              return "";

          if (value > 60)
              value = 60;

          return SPACE_60.substring(0, value);
      }

      public static String decode(String src)
      {
          if (src == null) return null;

          src = replace(src, "%20", " ");
          src = replace(src, "%21", "!");
          src = replace(src, "%22", "\"");
          src = replace(src, "%23", "#");
          src = replace(src, "%24", "$");
          src = replace(src, "%26", "&");
          src = replace(src, "%27", "'");
          src = replace(src, "%28", "(");
          src = replace(src, "%29", ")");
          src = replace(src, "%2A", "*");
          src = replace(src, "%2B", "+");
          src = replace(src, "%2C", ",");
          src = replace(src, "%2D", "-");
          src = replace(src, "%2E", ".");
          src = replace(src, "%2F", "/");
          src = replace(src, "%3A", ":");
          src = replace(src, "%3B", ";");
          src = replace(src, "%3C", "<");
          src = replace(src, "%3D", "=");
          src = replace(src, "%3E", ">");
          src = replace(src, "%3F", "?");

          return src;
      }

      public static void main(String argv[])
      {
          String str = "xsi%3Atype%3D%22CrystalReports.PropertyBag%22" +
              "%20version%3D%222%22%3E%3CProperty%3E%3CName%3EReportViewState%3C" +
              "%2FName%3E%3CValue%20VariantType%3D%22Object%22%20xsi%3Atype%3D" +
              "%22CrystalReports.PropertyBag%22%20id%3D%221%22%3E%3CProperty%3E" +
              "%3CName%3EAdvRptSrcState%3C%2FName%3E%3CValue%20VariantType%3D" +
              "%22String%22%3E13%3C%2FValue%3E%3C%2FProperty%3E%3CProperty%3E" +
              "%3CName%3ELogOnInfo%3C%2FName%3E%3CValue%20VariantType%3D%22Object%22" +
              "%20xsi%3Atype%3D%22CrystalReports.ConnectionInfos%22%20id%3D%222%22" +
              "%3E%3CConnectionInfo%20xsi%3Atype%3D%22CrystalReports.ConnectionInfo%22" +
              "%20id%3D%223%22%3E%3CUserName%3Eesgapp%3C%2FUserName%3E%3CPassword%20EncrAlgo%3D" +
              "%22CE8-EncryptPasswordDB%22%3Ez0006AL%5CPM%5EB4%3C%2FPassword%3E%3CAttributes%20" +
              "xsi%3Atype%3D%22CrystalReports.PropertyBag%22%20id%3D%224%22%3E%3CProperty%3E" +
              "%3CName%3EDatabase%20Name%3C%2FName%3E%3CValue%20VariantType%3D%22String%22" +
              "%3E%3C%2FValue%3E%3C%2FProperty%3E%3CProperty%3E%3CName%3EServer%20Name%3C" +
              "%2FName%3E%3CValue%20VariantType%3D%22String%22%3EeCPDataSource%3C%2FValue%3E" +
              "%3C%2FProperty%3E%3C%2FAttributes%3E%3CKind%3ESQL%3C%2FKind%3E%3C" +
              "%2FConnectionInfo%3E%3C%2FValue%3E%3C%2FProperty%3E%3CProperty%3E%3CName%3E" +
              "PageRequestContext%3C%2FName%3E%3CValue%20VariantType%3D%22Object%22%20xsi%3Atype%3D" +
              "%22CrystalReports.PropertyBag%22%20id%3D%225%22%3E%3CProperty%3E%3CName" +
              "%3ELastPageNumber%3C%2FName%3E%3CValue%20VariantType%3D%22Integer%22" +
              "%3E0%3C%2FValue%3E%3C%2FProperty%3E%3C%2FValue%3E%3C%2FProperty%3E%3CProperty%3E" +
              "%3CName%3EParameterInfo%3C%2FName%3E%3CValue%20VariantType%3D%22Object%22" +
              "%20xsi%3Atype%3D%22CrystalReports.Fields%22%20id%3D%226%22%3E%3CField%20xsi" +
              "%3Atype%3D%22CrystalReports.ParameterField%22%20id%3D%227%22%3E%3CName%3E" +
              "pDisplayOrdersColumn%3C%2FName%3E%3CDescription%3EDisplay%20Orders%20Column%3F" +
              "%3C%2FDescription%3E%3CType%3Exsd%3Aboolean%3C%2FType%3E%3CLength%3E0%3C%2FLength%3E" +
              "%3CHeadingText%3E%3C%2FHeadingText%3E%3CBrowseField%2F%3E%3CAllowMultiValue%3Efalse%3C" +
              "%2FAllowMultiValue%3E%3CDefaultValues%20xsi%3Atype%3D%22CrystalReports.Values%22" +
              "%20id%3D%228%22%3E%3CValue%20xsi%3Atype%3D%22CrystalReports.ParameterFieldDiscreteValue%22" +
              "%20id%3D%229%22%3E%3CDescription%3E%3C%2FDescription%3E%3CValue%20VariantType%3D" +
              "%22Boolean%22%3E0%3C%2FValue%3E%3C%2FValue%3E%3CValue%20xsi%3Atype%3D" +
              "%22CrystalReports.ParameterFieldDiscreteValue%22%20id%3D%2210%22%3E" +
              "%3CDescription%3E%3C%2FDescription%3E%3CValue%20VariantType%3D%22Boolean%22" +
              "%3E-1%3C%2FValue%3E%3C%2FValue%3E%3C%2FDefaultValues%3E%3CCurrentValues%20" +
              "xsi%3Atype%3D%22CrystalReports.Values%22%20id%3D%2211%22%2F%3E%3CReportName%3E" +
              "%3C%2FReportName%3E%3CParameterType%3EReportParameter%3C%2FParameterType%3E" +
              "%3CAllowCustomCurrentValues%3Etrue%3C%2FAllowCustomCurrentValues%3E%3" +
              "CAllowNullValue%3Efalse%3C%2FAllowNullValue%3E%3CEditMask%3E%3C%2FEditMask%3E" +
              "%3CMinimumValue%2F%3E%3CMaximumValue%2F%3E%3CDefaultValueSortOrder%3ENoSort%3C" +
              "%2FDefaultValueSortOrder%3E%3CDefaultValueSortMethod%3EBasedOnValue%3C" +
              "%2FDefaultValueSortMethod%3E%3CValueRangeKind%3EDiscrete%3C%2FValueRangeKind%3E" +
              "%3CUsage%3EUnknown%3C%2FUsage%3E%3CDefaultValueDisplayType%3EDescriptionAndValue%3C" +
              "%2FDefaultValueDisplayType%3E%3C%2FField%3E%3CField%20xsi%3Atype%3D%22" +
              "CrystalReports.ParameterField%22%20id%3D%2212%22%3E%3CName%3EpDisplayDirectorCount%3C" +
              "%2FName%3E%3CDescription%3EDisplay%20Counts%20by%20Director%3C%2FDescription%3E" +
              "%3CType%3Exsd%3Aboolean%3C%2FType%3E%3CLength%3E0%3C%2FLength%3E%3CHeadingText%3E%3C" +
              "%2FHeadingText%3E%3CBrowseField%2F%3E%3CAllowMultiValue%3Efalse%3C%2FAllowMultiValue%3E" +
              "%3CDefaultValues%20xsi%3Atype%3D%22CrystalReports.Values%22%20id%3D%2213%22%3E%3CValue%20" +
              "xsi%3Atype%3D%22CrystalReports.ParameterFieldDiscreteValue%22%20id%3D%2214%22%3E" +
              "%3CDescription%3E%3C%2FDescription%3E%3CValue%20VariantType%3D%22Boolean%22%3E0%3C" +
              "%2FValue%3E%3C%2FValue%3E%3CValue%20xsi%3Atype%3D%22CrystalReports.ParameterFieldDiscreteValue" +
              "%22%20id%3D%2215%22%3E%3CDescription%3E%3C%2FDescription%3E%3CValue%20VariantType%3D" +
              "%22Boolean%22%3E-1%3C%2FValue%3E%3C%2FValue%3E%3C%2FDefaultValues%3E%3CCurrentValues%20" +
              "xsi%3Atype%3D%22CrystalReports.Values%22%20id%3D%2216%22%2F%3E%3CReportName%3E%3C" +
              "%2FReportName%3E%3CParameterType%3EReportParameter%3C%2FParameterType%3E" +
              "%3CAllowCustomCurrentValues%3Etrue%3C%2FAllowCustomCurrentValues%3E%3CAllowNullValue%3E" +
              "false%3C%2FAllowNullValue%3E%3CEditMask%3E%3C%2FEditMask%3E%3CMinimumValue%2F%3E" +
              "%3CMaximumValue%2F%3E%3CDefaultValueSortOrder%3ENoSort%3C%2FDefaultValueSortOrder%3E" +
              "%3CDefaultValueSortMethod%3EBasedOnValue%3C%2FDefaultValueSortMethod%3E%3CValueRangeKind" +
              "%3EDiscrete%3C%2FValueRangeKind%3E%3CUsage%3EUnknown%3C%2FUsage%3E" +
              "%3CDefaultValueDisplayType%3EDescriptionAndValue%3C%2FDefaultValueDisplayType%3E%3C" +
              "%2FField%3E%3C%2FValue%3E%3C%2FProperty%3E%3CProperty%3E%3CName%3EUnsureConnsNum%3C" +
              "%2FName%3E%3CValue%20VariantType%3D%22Integer%22%3E1%3C%2FValue%3E%3C%2FProperty%3E" +
              "%3C%2FValue%3E%3C%2FProperty%3E%3C%2FCrystalReports.PropertyBag%3E";

          str = StringUtil.decode(str);

          System.out.println(str);
      }
  }