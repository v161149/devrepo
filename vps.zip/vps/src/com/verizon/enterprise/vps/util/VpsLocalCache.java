package com.verizon.enterprise.vps.util;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import com.verizon.enterprise.vps.middleware.ejb.dataAccess.ApsDataAccessHome;

import javax.rmi.PortableRemoteObject;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.sapient.framework.config.Config;
import org.apache.log4j.Logger;

public class VpsLocalCache
{
    private static Logger log = Logger.getLogger(VpsLocalCache.class);
    private static final Object _lock = new Object();

    /** weblogic server initial context */
    static ApsDataAccessHome apsDataAccessHome = null;

    /** weblogic server initial context */
    protected static InitialContext initialContext = null;

    /** weblogic server datasorce  */
    protected static DataSource ds = null;

    /**
     * Getter initial contect for ejb's
     * @author Gang Fu
     * modified Lynn Chen
     */
    public static InitialContext getInitialContext() throws Exception
    {
        if (initialContext == null)
        {
            synchronized (_lock)
            {
                if (initialContext == null)
                    initialContext = new InitialContext();
            }
        }
        return initialContext;
    }

    /**
     * get weblogic data source
     * @author Gang Fu
     */
    public static DataSource getDataSource() throws Exception
    {
        final String METHOD_NAME = "getDataSource()";

        log.debug("enter: " + METHOD_NAME);

        if( ds == null)
        {
            if (initialContext == null)
            {
                initialContext = getInitialContext();
            }

            if (initialContext == null)
            {
                log.info("initialContext is null.");
            }
            else
            {
                String dataSourceName = Config.getProperty("verizon.local.jdbc.eCPDataSource");
                log.info("dataSourceName = " + dataSourceName);

                synchronized (_lock)
                {
                    if(ds == null)
                        ds = (DataSource)initialContext.lookup(dataSourceName);
                }
            }
        }

        log.debug("exit: " + METHOD_NAME);

        return ds;
    }

    /**
     * Getter for aps data access EJB Home
     * @author Gang Fu
     */
    public static ApsDataAccessHome getApsDataAccessHome()
        throws Exception
    {
        if (apsDataAccessHome == null)
        {
            getInitialContext();
            Object apsDataAccessRef = initialContext.lookup("ApsDataAccess");
            apsDataAccessHome =
                (ApsDataAccessHome)PortableRemoteObject.narrow(apsDataAccessRef, ApsDataAccessHome.class);
        }
        return apsDataAccessHome;
    }
}
