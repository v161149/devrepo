package com.verizon.enterprise.vps.util;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

/**
 * The contents of this file is confidential and proprietary.
 * Copyright 2002 Verizon
 *
 * @version   1.0
 * @history
 *      Zhong Chen
 *
 */

import java.util.*;
import java.io.*;

import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.input.DOMBuilder;
import org.jdom.output.*;

/**
 * JDOM utilities.
 */
public class JDomUtil {
  /**
   * Parse file.
   */
  public static org.jdom.Element parseXmlFile(String sFile) throws JDOMException, IOException {
    org.jdom.input.SAXBuilder saxBuilder = new SAXBuilder();
    org.jdom.Document doc = null;
    //System.out.println("Parsing XML file: " + sFile);

    // start parsing...
    try {
      doc = saxBuilder.build(new File(sFile));
    } catch (IOException ex) {
      new JDOMException("IO exception catched", ex);
    }

    return (doc == null ? null : doc.getRootElement());
  }

  /**
   * Parse resource.
   */
  public static org.jdom.Element parseXmlResource(String sResource) throws JDOMException, IOException {
    org.jdom.input.SAXBuilder saxBuilder = new SAXBuilder();
    org.jdom.Document doc = null;

    // start parsing...
    try {
      doc = saxBuilder.build(JDomUtil.class.getClassLoader().getResourceAsStream (sResource));
    } catch (IOException ex) {
      new JDOMException("IO exception catched", ex);
    }

    return (doc == null ? null : doc.getRootElement());
  }

  /**
   * Parse resource.
   */
  public static org.jdom.Element parseXmlString(String sXML) throws JDOMException, IOException {
    org.jdom.input.SAXBuilder saxBuilder = new SAXBuilder();
    org.jdom.Document doc = null;

    // start parsing...
    try {
      doc = saxBuilder.build(new StringReader (sXML));
    } catch (IOException ex) {
      new JDOMException("IO exception catched", ex);
    }

    return (doc == null ? null : doc.getRootElement());
  }

  /**
   * Parse stream
   */
  public static org.jdom.Element parseXmlStream(InputStream stream) throws JDOMException, IOException {
    org.jdom.input.SAXBuilder saxBuilder = new SAXBuilder();
    org.jdom.Document doc = null;

    // start parsing...
    try {
      doc = saxBuilder.build(new InputStreamReader (stream));
    } catch (IOException ex) {
      new JDOMException("IO exception catched", ex);
    }

    return (doc == null ? null : doc.getRootElement());
  }

  /**
   * Find XML element type path.
   * @param sPath XPATH-like syntax "a/b/c".
   */
  public static org.jdom.Element findFirstElementByPath(org.jdom.Element eTop, String sPath) {
    List ll = findElementsByPath(eTop, sPath, true);
    return (ll.size() > 0 ? (org.jdom.Element)ll.get(0) : null);
  }

  /**
   * Find XML element type path.
   * @param sPath XPATH-like syntax "a/b/c".
   */
  public static List findElementsByPath(org.jdom.Element eTop, String sPath) {
    return findElementsByPath(eTop, sPath, false);
  }

  /**
   * Find XML element type path.
   * @param sPath XPATH-like syntax "a/b/c".
   */
  private static List findElementsByPath(org.jdom.Element eTop, String sPath, boolean bFirstOnly) {
    int i = 0;
    ArrayList qRetElems = new ArrayList();
    List qChildren = null;
    ArrayList qToBeSearched = null;
    StringTokenizer st = new StringTokenizer(sPath, "/");
    Namespace ns = eTop.getNamespace();
    qToBeSearched = new ArrayList();
    qToBeSearched.add(eTop);

    while (st.hasMoreTokens()) {
      String sNextKey = st.nextToken();
      if (sNextKey.length() <= 0 || qToBeSearched.size() <= 0) break;

      ArrayList qSearchList = (ArrayList)qToBeSearched.clone();
      Element eSearch = null;
      qToBeSearched.clear(); // prepare for next round.
      for (i=0; i<qSearchList.size(); i++) {
        eSearch = (Element)qSearchList.get(i);
        qChildren = eSearch.getChildren(sNextKey, ns);
        // Last step?
        if (!st.hasMoreTokens()) {
          qRetElems.addAll(qChildren);
        }
        else {
          qToBeSearched.addAll(qChildren);
        }

        if (bFirstOnly && !qRetElems.isEmpty()) break;
      }
    }

    return qRetElems;
  }

  /**
   * Print element.
   */
  public static void printlnElement(org.jdom.Element elem, java.io.OutputStream os) {
    printElement(elem, os);

    // Shouldn't call this function if os is not a PrintStream instance.
    try {
      os.write('\n');
    }
    catch (java.io.IOException ioe) {}
  }

  /**
   * Print element.
   */
  public static void printElement(org.jdom.Element elem, java.io.OutputStream os) {
    try {
      Format format = Format.getPrettyFormat();
      format.setIndent("  ");
      XMLOutputter outputter = new XMLOutputter(format);
      outputter.output(elem, os);
    }
    catch (java.io.IOException ioe) {
      System.err.println("Cannot print XML element: " + ioe);
    }
  }

  /**
   * Print element.
   */
  public static void printlnElement(org.jdom.Element elem, java.io.Writer os) {
    printElement(elem, os);

    // Shouldn't call this function if os is not a PrintStream instance.
    try {
      os.write('\n');
    }
    catch (java.io.IOException ioe) {}
  }

  /**
   * Print element.
   */
  public static void printElement(org.jdom.Element elem, java.io.Writer os) {
    try {
      Format format = Format.getPrettyFormat();
      format.setIndent("  ");
      XMLOutputter outputter = new XMLOutputter(format);
      outputter.output(elem, os);
    }
    catch (java.io.IOException ioe) {
      System.err.println("Cannot print XML element: " + ioe);
    }
  }

  /**
   * Get the string format of Element.
   */
  public static String getElementString(org.jdom.Element elem){
    String s;
    s = ms_xmlStringOutputter.outputString(elem);
    return s;
  }

  // XML outputter for string.
  private static XMLOutputter ms_xmlStringOutputter = new XMLOutputter();
}
