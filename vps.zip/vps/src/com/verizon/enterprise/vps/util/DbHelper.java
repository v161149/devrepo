package com.verizon.enterprise.vps.util;

import com.verizon.kernel.jdbc.ConnectionFactory;
import com.verizon.kernel.jdbc.ConnectionInterface;
import com.verizon.kernel.jdbc.ConnectionImp;
import com.verizon.kernel.exception.DatalayerException;

/**
 * <p>Title: Virtual Process Service</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */
public class DbHelper {
    public static final String DEFAULT_DB_SCHEMA = "ECP_tx"; // Schema name actually

    /** Get connection */
    public static ConnectionInterface getConnection(String sSchemaName) throws DatalayerException {
        return ConnectionFactory.getConnection(sSchemaName);
    }

    /** Get db connection */
    public static java.sql.Connection getDbConnection(String sSchemaName) throws DatalayerException {
        ConnectionInterface ci = ConnectionFactory.getConnection(sSchemaName);
        return ci == null ? null : ci.getConnection();
    }

    /** Get connection */
    public static ConnectionInterface getConnection() throws DatalayerException {
        return ConnectionFactory.getConnection(DEFAULT_DB_SCHEMA);
    }

    /** Get db connection */
    public static java.sql.Connection getDbConnection() throws DatalayerException {
        ConnectionInterface ci = ConnectionFactory.getConnection(DEFAULT_DB_SCHEMA);
        return ci == null ? null : ci.getConnection();
    }

    public static int getNumTasksOfStatus(char status) {
      int size = -1;
      String sql;
      if (com.verizon.enterprise.vps.dataobjects.IVpsTask.FINISHED == status) {
        sql = "select count(*) from task_instance where status = ? or status = "+com.verizon.enterprise.vps.dataobjects.IVpsTask.FAILED;
      }
      else {
        sql = "select count(*) from pending_task where status = ?";
      }
      java.sql.PreparedStatement ps = null;
      java.sql.Connection con = null;
      try {
        con = DbHelper.getDbConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, new String(new char[] {status}));
        java.sql.ResultSet rs = ps.executeQuery();
        if (rs.next()) {
          size = rs.getInt(1);
        }
      }
      catch (DatalayerException e) {
      }
      catch (java.sql.SQLException e) {
      }
      finally {
        if (ps != null) {
          try { ps.close(); } catch (java.sql.SQLException warning) {}
          ps = null;
        }
        if (con != null) {
          try { con.close(); } catch (java.sql.SQLException warning) {}
          con = null;
        }
      }
      return size;
    }

}