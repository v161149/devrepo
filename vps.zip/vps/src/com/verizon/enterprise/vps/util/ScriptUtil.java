package com.verizon.enterprise.vps.util;

import java.util.Map;
import java.util.Set;
import java.util.Iterator;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ScriptUtil
{
    public static String mapToString(Map map)
    {
        StringBuffer buf = new StringBuffer();

        if (map == null) return null;

        Set keySet = map.keySet();
        Iterator keyIter = keySet.iterator();
        Object key;
        Object value;
        while (keyIter.hasNext())
        {
            key = (String)keyIter.next();
            value = map.get(key);
            buf.append(objToString(key));
            buf.append(" = ");
            buf.append(objToString(value));
            buf.append("\n");
        }
        return buf.toString();
    }

    public static String objToString(Object obj)
    {
        if (obj == null)
            return null;
        else if (obj instanceof String)
            return (String)obj;
        else
            return obj.toString();
    }

}