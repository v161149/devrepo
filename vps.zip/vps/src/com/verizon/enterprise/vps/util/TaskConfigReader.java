package com.verizon.enterprise.vps.util;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.ScheduleParser;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.dataobjects.TaskParsingException;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;

/**
 * <tasks>
 *   <task schedule="WEEKLY|WED|11:30:00">
 *     <invoke class="com.verizon.enterprise.vps.core.TaskTest" method="hello"><arg>Tester 66</arg></invoke>
 *   </task>
 * </tasks>
 */
public class TaskConfigReader
{
    private String m_config_filename;
    private java.util.Iterator m_tasks_iterator;
    private org.jdom.Element m_task;
    private boolean m_bParsed;

    public TaskConfigReader(String config_filename)
    {
        m_config_filename = config_filename;
        m_bParsed = false;
    }

    //move to next task/schedule pair
    public boolean next()
    {
        if (! m_bParsed)
        {
            try
            {
                LogHelper.info("Loading vps bootstrap: "+m_config_filename);
                java.net.URL config = Thread.currentThread().getContextClassLoader().getResource(m_config_filename);
                if (null==config) {
                    LogHelper.error("Cannot load resource: "+m_config_filename);
                }
                else {
                    java.io.InputStream is = config.openStream();
                    org.jdom.Element elem = JDomUtil.parseXmlStream(is);
                    m_tasks_iterator = elem.getChildren().iterator();
                    is.close();
                }
            }
            catch (Exception e)
            {
                LogHelper.error(e);
            }
            finally {
                m_bParsed = true;
            }
        }

        if (null == m_tasks_iterator) {
            return false;
        }

        m_task = null;

        while (m_tasks_iterator.hasNext() &&
               ((m_task = (org.jdom.Element) m_tasks_iterator.next()) != null) &&
               (!m_task.getName().equals(XML_TAG_TASK))) {
            LogHelper.error("Node name "+m_task.getName()+" is expected to be "+XML_TAG_TASK);
        }

        return m_task != null;
    }

    public ISchedule getSchedule() throws VpsScheduleException {
        return ScheduleParser.parseSchedule(m_task.getAttribute(XML_ATTR_SCHEDULE).getValue());
    }

    public IVpsTask getTask() throws TaskParsingException {
        java.util.List lst = m_task.getChildren();
        if (lst.size() != 1)
            throw new TaskParsingException(TaskParsingException.PARSING_ERROR,
                                           "must have exactly 1 child under task node");

        //XmlPersistentTask task = new XmlPersistentTask();
        //task.readTaskInfo((org.jdom.Element) lst.get(0));
        org.jdom.Element taskInfo = (org.jdom.Element) lst.get(0);
        IVpsTask task = XmlPersistentTask.parse(taskInfo);
        if (task instanceof XmlPersistentTask) {
          ((XmlPersistentTask)task).readTaskInfo(taskInfo);
        }
        return task;
    }
    public static final String XML_TAG_TASKS = "tasks";
    public static final String XML_TAG_TASK = "task";
    public static final String XML_ATTR_SCHEDULE = "schedule";
}
