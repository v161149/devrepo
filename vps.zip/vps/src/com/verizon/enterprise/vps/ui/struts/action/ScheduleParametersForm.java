package com.verizon.enterprise.vps.ui.struts.action;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import java.util.*;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;

/**
 * Form bean for the scheduling page.
 * This form has the following fields,
 * with default values in square brackets:
 * <ul>
 * </ul>
 *
 * @author
 * @version
 */
public final class ScheduleParametersForm extends ActionForm {

    private String className = null;
    private String jobScheduleDefName;
    private String scheduleInfo;
    private String startTime;
    private String stopTime;
    private String taskInfo;
    private String origin;
    private String methodName = null;
    private String actionName = VpsConstants.ACTION_INIT;
    private String isScript = "FALSE";
    private String osParam = "";
    private String osCommand = "";

    //used in multibox display of the form
    private String[] selectedParams = { };
    public String[] getSelectedParams()
    {
      return this.selectedParams;
    }
    public void setSelectedParams(String[] selectedParams)
    {
      this.selectedParams = selectedParams;
    }
    private ArrayList osCommandParams = new ArrayList();

    public ArrayList getOsCommandParams()
    {
      return this.osCommandParams;
    }
    public void setOsCommandParams(ArrayList osCommandParams)
    {
      this.osCommandParams = osCommandParams;
    }
    //
    public String getOsCommand()
    {
      return this.osCommand;
    }
    public void setOsCommand(String osCommand)
    {
      this.osCommand = osCommand;
    }
    public String getOsParam()
    {
      return this.osParam;
    }
    public void setOsParam(String osParam)
    {
      this.osParam = osParam;
    }
    public String getIsScript()
    {
      return this.isScript;
    }
    public void setIsScript(String isScript)
    {
      this.isScript = isScript;
    }

    public String getClassName() {
	return (this.className);
    }
    public String getJobScheduleDefName() {
	return jobScheduleDefName;
    }
    public String getScheduleInfo() {
	return scheduleInfo;
    }
    public String getStartTime() {
	return startTime;
    }
    public String getStopTime() {
	return stopTime;
    }
    public String getTaskInfo() {
	return taskInfo;
    }
    public String getOrigin () {
	return origin;
    }

    public void setClassName(String className) {
        this.className = className;
    }
    public void setJobScheduleDefName(String jobScheduleDefName) {
        this.jobScheduleDefName = jobScheduleDefName;
    }
    public void setScheduleInfo(String scheduleInfo) {
        this.scheduleInfo = scheduleInfo;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public void setStopTime(String stopTime) {
        this.stopTime = stopTime;
    }
    public void setTaskInfo(String taskInfo) {
        this.taskInfo = taskInfo;
    }
    public void setOrigin (String origin) {
	this.origin = origin;
    }

    public String getMethodName() {
	return (this.methodName);
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getActionName() {
	return (this.actionName);
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }


    /**
     * Reset all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping,
        HttpServletRequest request) {
        setClassName(null);
        setMethodName(null);
        setActionName(null);
        setActionName(VpsConstants.ACTION_INIT);
        jobScheduleDefName=null;
        scheduleInfo=null;
        taskInfo=null;
        methodName = null;
        actionName = null;
        isScript = "FALSE";
        selectedParams = new String[0];
    }
    public void resetAll(ActionMapping mapping,
                         HttpServletRequest request) {
      reset(mapping, request);
      startTime=null;
      stopTime=null;
      osCommandParams.clear();
    }


    /**
     * Ensure that both fields have been input.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */

    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();

        //if ((className == null) || (className.length() < 1))
        //    errors.add("className",new ActionError("errors.className.required"));

        //return errors;
        //System.out.println("*******Class Name=" + className+" ************");
	return null;
    }

    public void removeParams()
    {
      for(int i = 0; i < selectedParams.length; i++)
      {
        osCommandParams.remove(selectedParams[i]);
      }
    }
    public void addParam()
    {
      //first remove the unwanted parameters, then add the new parameter
      removeParams();
      if(osParam != null)
      {
        osParam.trim();
      }
      if(osParam != null && !osParam.equals(""))
      {
        osCommandParams.add(osParam);
        osParam = "";
      }
    }

}
