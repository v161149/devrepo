package com.verizon.enterprise.vps.ui.struts.form;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;

public class ClassParameterForm extends ActionForm {

    private String className;
    private String methodName;
    private String shortMethodName;

    private static Logger logger = Logger.getLogger(ClassParameterForm.class);
    public String getClassName() {
	return this.className;
    }

    public String getMethodName() {
	return this.methodName;
    }

    public String getShortMethodName() {
	return this.shortMethodName;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
	if (methodName != null && methodName.trim().length() != 0) {
	    
	    if (methodName.indexOf('(')>0){
		String temp = methodName.substring (0, methodName.indexOf('(')).trim();
		this.setShortMethodName(temp);
	    }
	}
    }

    public void setShortMethodName(String shortMethodName) {
        this.shortMethodName = shortMethodName;
    }

    public ActionErrors validate(ActionMapping mapping,
				 HttpServletRequest request) {
	final String METHOD_NAME = "ClassParameterForm:validate()";
	logger.debug("ENTER: " + METHOD_NAME );
	ActionErrors errors = new ActionErrors();

	try{
	    Class c = Class.forName(className);
	}catch (Exception e){
	    errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("Invalid class name."));
	}

	logger.debug("EXIT: " + METHOD_NAME );
	return errors;
    }
}


