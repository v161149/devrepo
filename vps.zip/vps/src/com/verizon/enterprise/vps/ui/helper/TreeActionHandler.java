package com.verizon.enterprise.vps.ui.helper;

import java.util.*;
import com.verizon.enterprise.preslet.tag.tree.AbstractWTreeActionHandler;
import com.verizon.enterprise.preslet.tag.tree.WTreeModel;
import com.verizon.enterprise.preslet.tag.tree.WTree;
import javax.servlet.http.HttpSession;

public class TreeActionHandler extends AbstractWTreeActionHandler {

    HttpSession session = null;
    /**
     * Give action handler a chance to prepare itself to handle actions.
     * Set the page context information in case action handler needs it.
     */
    public void initializeHandler(javax.servlet.jsp.PageContext pgCtx,
				  String sFormName) {
	session = pgCtx.getSession();
    }

    /** 
     * Will be invoked when model cannot be found from ID.
     * Application could implement this function to initialize data model.
     */
    public WTreeModel createTreeModel(String sFormName,
                                      int nInitPagePos,
                                      int nInitPageSize) {
	System.out.println ("sFormName = " + sFormName 
			    + "\nnInitPagePos = " + nInitPagePos 
			    + "\nnInitPageSize = " + nInitPageSize);

	return new VpsTree();
    }

    // Event to expand a node
    public WTreeModel nodeExpansion(WTreeModel currentModel,
                                    boolean bExpand,
                                    int nPagePos,
                                    int nPageSize,
                                    Object nodeToExpand) {
        System.out.println("nodeExpansion event: " + bExpand
                           + "," + nPagePos + "/" + nPageSize + " for " + nodeToExpand);
        return currentModel;
    }

    // Event to browse cursor
    public WTreeModel paging(WTreeModel currentModel,
                             int nNewPagePos,
                             int nNewPageSize,
                             Object parentNode) {
        System.out.println("paging event: "
                   + nNewPagePos + "/" + nNewPageSize + " for " + parentNode);

        return currentModel;
    }

    /**
     * Will be invoked before the tree is rendered (after paging/expansion
     * event is processed).
     * @param tree WTree The view controller. WTreeModel and WTreeState can 
     * be retrieved from WTree
     * One example of using this method is to set proper initial expansion
     * state of tree. When tree is first created, by default only the first
     * level of child nodes are expanded.
     */
    public void prepareDisplay(WTree tree) {
        // Always expand 0.13
	/*
	WTreeModel wTreeModel = tree.getModel();
	WTreeState wTreeState = tree.getTreeState();
	tree.setModel(wTreeModel);
	tree.setTreeState(wTreeState);
	*/
    }

}











