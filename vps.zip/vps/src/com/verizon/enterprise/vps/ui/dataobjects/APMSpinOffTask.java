package com.verizon.enterprise.vps.ui.dataobjects;

public class APMSpinOffTask implements java.io.Serializable {

    private String taskName;
    private String maxWaitingSec;
    private String secLeft;
    
    public APMSpinOffTask(String taskName, String maxWaitingSec) {
	setTaskName(taskName);
	setMaxWaitingSec(maxWaitingSec);
    }

    public String getTaskName() {
	return this.taskName;
    }

    public String getMaxWaitingSec() {
	return this.maxWaitingSec;
    }

    public void setTaskName(String taskName) {
	this.taskName = taskName;
    }

    public void setMaxWaitingSec(String maxWaitingSec) {
	
	this.maxWaitingSec=maxWaitingSec;
    }

    public String toString () {

	return "taskName="+taskName + ", maxWaitingSec="+maxWaitingSec;
    }

}


