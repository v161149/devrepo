package com.verizon.enterprise.vps.ui.tag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.Tag;

import org.apache.taglibs.standard.tag.common.core.WhenTagSupport;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class TimeoutIsTrueTag extends WhenTagSupport
{
  public int doStartTag() throws JspException
  {
    Tag parent = (Tag) getParent();

    if ((null == parent) || (!(parent instanceof TimeoutTag)))
    {
      throw new JspTagException("TimeoutIsTrueTag must be nested within TimeoutTag");
    }

    return super.doStartTag();
  }

  protected boolean condition() throws JspTagException
  {
    return ((TimeoutTag)getParent()).isTimedOut();
  }
}