package com.verizon.enterprise.vps.ui.datalayer;

import java.util.List;

import org.apache.log4j.Logger;

import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.enterprise.vps.ui.dataobjects.PendingTask;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.kernel.exception.DatalayerException;

public class PendingTaskTableAccess {

  private static Logger logger = Logger.getLogger(PendingTaskTableAccess.class);

  public PendingTaskTableAccess() {
  }

  public PendingTask getPendingTaskByOid(String oid) throws Exception {
    final String METHOD_NAME = "PendingTaskTableAccess:getPendingTaskByOid(String)";
    logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
    logger.debug("oid: " + oid);

    PendingTask task = null;
    List pendingTasks = null;

    try {
      Long OID = new Long(oid);
      PendingTaskObject pendingTaskObject = PendingTaskTable.retrieve(OID);
      task = this.populatePendingTask(pendingTaskObject);
    } catch (DatalayerException dle) {
      logger.error(METHOD_NAME + " DatalayerException " + dle.getMessage());
      logger.error(Util.getStackTrace(dle));
      throw new Exception(dle.getMessage());
    } catch (Exception e) {
      logger.error(METHOD_NAME + " Exception " + e.getMessage());
      logger.error(Util.getStackTrace(e));
      throw new Exception(e.getMessage());
    }

    logger.debug("EXIT: " + METHOD_NAME);
    return task;
  }

  public PendingTask getPendingTaskByJobScheduleDefOid(String oid) throws Exception {
    final String METHOD_NAME = "PendingTaskTableAccess:getPendTaskByJobScheduleDefOid(String)";
    logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
    logger.debug("oid: " + oid);

    PendingTask task = null;
    PendingTaskObject pendingTaskObject = this.getPendingTaskObjectByJobScheduleDefOid(oid);
    if (pendingTaskObject != null)
      task = this.populatePendingTask(pendingTaskObject);

    logger.debug("EXIT: " + METHOD_NAME);
    return task;
  }

  public PendingTaskObject getPendingTaskObjectByJobScheduleDefOid(String oid) throws Exception {
    final String METHOD_NAME = "PendingTaskTableAccess:getPendingTaskObjectByJobScheduleDefOid(String)";
    logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
    logger.debug("oid: " + oid);

    PendingTaskObject task = null;

    try {
      List pendingTaskObjects = PendingTaskTable.search(" where job_schedule_def_oid = " + oid);
      if (pendingTaskObjects != null && !pendingTaskObjects.isEmpty()) {
        int size = pendingTaskObjects.size();
        if (size > 1)
          throw new Exception("Multiple PendingTasks found for a single job_schedule_def_oid = " + oid);
        else if (size == 1) {
          task = (PendingTaskObject)pendingTaskObjects.get(0);
          logger.debug("found one pending task.");
        } else {
          task = null;
          logger.debug("found 0 pending tasks.");
        }
      } else
        logger.debug("found 0 pending tasks.");
    } catch (DatalayerException dle) {
      logger.error(METHOD_NAME + " DatalayerException " + dle.getMessage());
      logger.error(Util.getStackTrace(dle));
      throw new Exception(dle.getMessage());
    } catch (Exception e) {
      logger.error(METHOD_NAME + " Exception " + e.getMessage());
      logger.error(Util.getStackTrace(e));
      throw new Exception(e.getMessage());
    }

    logger.debug("EXIT: " + METHOD_NAME);
    return task;
  }

  private PendingTask populatePendingTask(PendingTaskObject pendingTaskObject) throws Exception {

    String oid = pendingTaskObject.getPendingTaskOid().toString();
    String status = pendingTaskObject.getStatus();
    String executeTime = Util.convertTimestampToUIStd(pendingTaskObject.getExecuteTime());
    String taskInfo = pendingTaskObject.getTaskInfo();
    String retryCounter = pendingTaskObject.getRetryCounter() == null ? null : pendingTaskObject.getRetryCounter().toString();
    Long jobScheduleDefOidLong = pendingTaskObject.getJobScheduleDefOid();
    String jobScheduleDefOid = null;
    if (jobScheduleDefOidLong != null)
      jobScheduleDefOid = jobScheduleDefOidLong.toString();

    String timestamp = Util.convertTimestampToUIStd(pendingTaskObject.getTimestamp());
    String userOid = pendingTaskObject.getUserId().toString();

    PendingTask task = new PendingTask(oid, status, executeTime, taskInfo, retryCounter, jobScheduleDefOid, timestamp, userOid);
    return task;
  }

}
