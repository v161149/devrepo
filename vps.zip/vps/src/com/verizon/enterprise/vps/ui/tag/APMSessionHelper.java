package com.verizon.enterprise.vps.ui.tag;

import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;
import javax.servlet.http.HttpSession;
import com.verizon.enterprise.common.VerizonStateManager;
import java.util.Hashtable;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class APMSessionHelper
{
  public static TimeoutTaskListener getTimeoutListener(Long taskid,
      HttpSession session)
  {
    Hashtable t = (Hashtable) session.getAttribute(VerizonStateManager.APM_KEY);
    return (TimeoutTaskListener) t.get(taskid);
  }
}