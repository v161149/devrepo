package com.verizon.enterprise.vps.ui.helper;

import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.verizon.enterprise.preslet.tag.tree.AbstractWTreeActionHandler;
import com.verizon.enterprise.preslet.tag.tree.WTreeModel;
import com.verizon.enterprise.preslet.tag.tree.WTree;
import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeNode;
import com.verizon.kernel.jdbc.CursorId;
import com.verizon.enterprise.vps.ui.struts.action.ActionHelper;
import com.verizon.enterprise.vps.ui.helper.Util;

public class VpsTreeActionHandler extends AbstractWTreeActionHandler {

    HttpSession session = null;
    HttpServletRequest request = null;
    HashMap cursorMap = null;
    String userOid = null;
    String permission = null;
    private static Logger logger = Logger.getLogger(VpsTreeActionHandler.class);

    /**
     * Give action handler a chance to prepare itself to handle actions.
     * Set the page context information in case action handler needs it.
     */
    public void initializeHandler(javax.servlet.jsp.PageContext pgCtx,  
				  String sFormName) {
	final String METHOD_NAME = "VpsTreeActionHandler.initializeHandler()";
	logger.debug(METHOD_NAME + " ENTERING..."); 

	session = pgCtx.getSession();
	cursorMap = (HashMap)session.getAttribute(VpsConstants.VPS_DATA_CURSOR);
	request = (HttpServletRequest)pgCtx.getRequest();
	try {
	    userOid = ActionHelper.getUserOidFromRequest(request);
	    if (permission == null)
		permission = ActionHelper.getUserPermissions(userOid, request);
	}
	catch (Exception e) {
	    logger.error(Util.getStackTrace(e));
	}

	logger.debug(METHOD_NAME + " EXITING..."); 
    }

    /** 
     * Will be invoked when model cannot be found from ID.
     * Application could implement this function to initialize data model.
     */
    public WTreeModel createTreeModel(String sFormName,
                                      int nInitPagePos,
                                      int nInitPageSize) {
	
	final String METHOD_NAME = "VpsTreeActionHandler.createTreeModel(String, int, int)";
	logger.debug(METHOD_NAME + " ENTERING..."); 
	logger.debug(METHOD_NAME + "sFormName = " + sFormName 
		     + "\nnInitPagePos = " + nInitPagePos 
		     + "\nnInitPageSize = " + nInitPageSize);

	session.removeAttribute(VpsConstants.VPS_DATA_CURSOR);
	VpsTreeModel vpsTreeModel = new VpsTreeModel();
	Object root = vpsTreeModel.getRoot();

	DefaultWTreeNode rootNode = (DefaultWTreeNode)root;
	CursorId cursor = null;
	List childList = VpsTreeNodeHelper.getChildNodeList(rootNode, nInitPagePos, 
							    nInitPageSize, cursor, 
							    userOid, permission);
	int totalChildCount = childList.size();
	int startPosi = nInitPagePos*nInitPageSize;
	VpsTreeNodeHelper.populateNodeWithChild(rootNode, startPosi, -1, childList, totalChildCount);

	cursorMap = new HashMap();
	session.setAttribute(VpsConstants.VPS_DATA_CURSOR, cursorMap);

	/*
	cursorMap = new HashMap();
	CursorId cursor = Util.getNewCursorId(nInitPageSize);
	cursorMap.put(root, cursor);

	DefaultWTreeNode rootNode = (DefaultWTreeNode)root;
	List childList = VpsTreeNodeHelper.getChildNodeList(rootNode, nInitPagePos, nInitPageSize, cursor);
	int totalChildCount = (int)cursor.getTotalRows();
	int startPosi = nInitPagePos*nInitPageSize;

	VpsTreeNodeHelper.populateNodeWithChild(rootNode, startPosi, -1, childList, totalChildCount);
	session.setAttribute(VpsConstants.VPS_DATA_CURSOR, cursorMap);
	*/
	logger.debug(METHOD_NAME + " EXITING...");
	return vpsTreeModel;
    }

    // Event to expand a node
    public WTreeModel nodeExpansion(WTreeModel currentModel,
                                    boolean bExpand,
                                    int nPagePos,
                                    int nPageSize,
                                    Object nodeToExpand) {
	final String METHOD_NAME = "VpsTreeActionHandler.nodeExpansion(WTreeModel, boolean, int, int, Object)";
	logger.debug(METHOD_NAME + " ENTERING..."); 
	logger.debug(METHOD_NAME +" nodeExpansion event: " 
		     + bExpand + "," + nPagePos + "/" 
		     + nPageSize + " for " + nodeToExpand);

	if (bExpand) {
	    CursorId cursor = (CursorId)cursorMap.get(nodeToExpand);
	    if (cursor == null)
		cursor = Util.getNewCursorId(nPageSize);
		    
	    DefaultWTreeNode parent = (DefaultWTreeNode)nodeToExpand;
	    int startPosi = nPagePos*nPageSize;
	    List childList = VpsTreeNodeHelper.getChildNodeList(parent, nPagePos, 
								nPageSize, cursor, 
								userOid, permission);
	    int totalChildCount = (int)cursor.getTotalRows();
	    
	    //if parent is job schedule def, check if pending task exists to get correct figure 
	    //on the number of children.
	    //if parent is schedule info type, do nothing.
	    if (!Util.getTypePrefix(parent.toString()).equals (VpsConstants.SCHEDULE_TYPE_PREFIX)){
		boolean pendingExist = VpsTreeNodeHelper.hasPendingTask(parent);
		if (pendingExist)
		    totalChildCount++;
	    }

	    VpsTreeNodeHelper.populateNodeWithChild(parent, startPosi, -1, childList, totalChildCount);
	    cursorMap.put(nodeToExpand, cursor);
	}

	logger.debug(METHOD_NAME + " EXITING...");
        return currentModel;
    }

    // Event to browse cursor
    public WTreeModel paging(WTreeModel currentModel,
                             int nNewPagePos,
                             int nNewPageSize,
                             Object parentNode) {
	final String METHOD_NAME = "VpsTreeActionHandler.paging(WTreeModel, int, int, Object)";
	logger.debug(METHOD_NAME + " ENTERING..."); 
	logger.debug(METHOD_NAME + " paging event: " 
		     + nNewPagePos + "/" + nNewPageSize 
		     + " for " + parentNode);

	CursorId cursor = (CursorId)cursorMap.get(parentNode);
	DefaultWTreeNode parent = (DefaultWTreeNode)parentNode;
	
	List childList = VpsTreeNodeHelper.getChildNodeList(parent, nNewPagePos, 
							    nNewPageSize, cursor, 
							    userOid, permission);
	int totalChildCount = (int)cursor.getTotalRows();

	//if parent is job schedule def, check if pending task exists to get correct figure 
	//on the number of children.
	//if parent is schedule info type, do nothing.
	if (!Util.getTypePrefix(parent.toString()).equals (VpsConstants.SCHEDULE_TYPE_PREFIX)){
	    boolean pendingExist = VpsTreeNodeHelper.hasPendingTask(parent);
	    if (pendingExist)
		totalChildCount++;
	}

	int startPosi = nNewPagePos*nNewPageSize;
	VpsTreeNodeHelper.populateNodeWithChild(parent, startPosi, -1, childList, totalChildCount);
	cursorMap.put(parentNode, cursor);

	logger.debug(METHOD_NAME + " EXITING...");
        return currentModel;
    }

    /**
     * Will be invoked before the tree is rendered (after paging/expansion
     * event is processed).
     * @param tree WTree The view controller. WTreeModel and WTreeState can 
     * be retrieved from WTree
     * One example of using this method is to set proper initial expansion
     * state of tree. When tree is first created, by default only the first
     * level of child nodes are expanded.
     */
    public void prepareDisplay(WTree tree) {
        // Always expand 0.13
	/*
	WTreeModel wTreeModel = tree.getModel();
	WTreeState wTreeState = tree.getTreeState();
	tree.setModel(wTreeModel);
	tree.setTreeState(wTreeState);
	*/
    }

}











