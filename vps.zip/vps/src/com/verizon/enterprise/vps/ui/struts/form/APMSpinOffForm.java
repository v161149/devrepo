package com.verizon.enterprise.vps.ui.struts.form;

import org.apache.struts.action.ActionForm;
import org.apache.log4j.Logger;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.dataobjects.APMSpinOffTask;
import java.util.*;

public class APMSpinOffForm extends ActionForm {

    private String taskNames;
    private String maxWaitingSecs;
    private String finishedTaskName;

    public String getTaskNames() {
	return this.taskNames;
    } 

    public String getMaxWaitingSecs() {
	return this.maxWaitingSecs;
    }
    
    public String getFinishedTaskName() {
	return this.finishedTaskName;
    }

    public void setTaskNames (String t) {
	this.taskNames = t;
    }

    public void setMaxWaitingSecs (String m) {
	this.maxWaitingSecs = m;
    }

    public void setFinishedTaskName (String f) {
	this.finishedTaskName = f;
    }
    
    public Collection getSpinOffTasks () {
	StringTokenizer st1 = new StringTokenizer (taskNames, VpsConstants.DELIMITER);
	StringTokenizer st2 = new StringTokenizer (maxWaitingSecs, VpsConstants.DELIMITER);

	if (st1.countTokens() != st2.countTokens())
	    return null;

	String tName = null;
	String mSec = null;
	APMSpinOffTask task = null;
	ArrayList a = new ArrayList();
	while (st1.hasMoreTokens() && st2.hasMoreTokens()) {
	    tName = (String)st1.nextToken();
	    mSec =  (String)st2.nextToken();
	    
	    if (mSec == null || mSec.trim().length() == 0)
		mSec = "-1"; //set to infinite

	    task = new APMSpinOffTask(tName, mSec);
	    a.add(task);
	}
	
	return a;
    }

}


