package com.verizon.enterprise.vps.ui.struts.action;

import java.util.Date;
import java.util.Collection;
import java.util.ArrayList;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.ui.helper.DataValidator;
import com.verizon.enterprise.vps.ui.datalayer.JobScheduleDefTableAccess;
import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.schedule.ScheduleParser;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.ui.struts.action.ActionHelper;

public class JobScheduleDefSubmitAction extends Action {

    private static Logger logger = Logger.getLogger(JobScheduleDefSubmitAction.class);
    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse) throws Exception{
	final String METHOD_NAME = "ScheduleParametersAction:execute()";
	logger.debug("ENTER: " + METHOD_NAME );
	
	JobScheduleDef jForm = (JobScheduleDef)aForm;
	HttpSession session = aRequest.getSession();
	session.setAttribute ("scheduleDef", jForm);
	ActionForward forward = null;

	String name = jForm.getName ();
	String scheduleInfo = jForm.getScheduleInfo ();
	String startTime = jForm.getEffectiveStartTime ();
	String stopTime = jForm.getEffectiveStopTime ();
	String taskInfo = jForm.getTaskInfo ();

	try {
	    Date startDate = null;
	    Date stopDate = null;
	    if (startTime != null && startTime.trim().length() != 0)
		startDate = Util.convertToDateObject(startTime);
	    
	    if (stopTime != null && stopTime.trim().length() != 0)
		stopDate = Util.convertToDateObject(stopTime);

	    String userOid = null;

	    try {
		userOid =  ActionHelper.getUserOidFromRequest(aRequest);
		logger.debug ("userOid = " + userOid);
	    }
	    catch (Exception ex) {
		logger.error (Util.getStackTrace(ex));
	    }

	    ActionHelper.newJobScheduleDelegate (name,
						 taskInfo, 
						 scheduleInfo, 
						 startDate,
						 stopDate,
						 userOid);
	    /*
	    DataValidator.nameInfoValidate (name);
	    DataValidator.taskInfoValidate (taskInfo);
	    DataValidator.scheduleInfoValidate (scheduleInfo);

	    Date startDate = null;
	    Date stopDate = null;
	    if (startTime != null && startTime.trim().length() != 0)
		startDate = Util.convertToDateObject(startTime);
	    
	    if (stopTime != null && stopTime.trim().length() != 0)
		stopDate = Util.convertToDateObject(stopTime);
	    
	    XmlPersistentTask xpt = new XmlPersistentTask(taskInfo);
	    ISchedule schedule = ScheduleParser.parseSchedule(scheduleInfo);
	    schedule.setName(name);

	    if (startDate != null)
		schedule.setStartEffectiveTime(startDate);
	    if (stopDate != null)
		schedule.setEndEffectiveTime(stopDate);
	    
	    String userOid = null;

	    try {
		userOid =  ActionHelper.getUserOidFromRequest(aRequest);
		logger.debug ("userOid = " + userOid);
	    }
	    catch (Exception ex) {
		logger.error (Util.getStackTrace(ex));
	    }

	    JobScheduleDefTableAccess jAccess = new JobScheduleDefTableAccess();
	    jAccess.createJobScheduleDef (xpt, schedule, userOid);
	    */
	    session.removeAttribute (VpsConstants.TREE_MODEL_NAME_IN_SESSION);
	    session.removeAttribute ("oldJobDef");
	    forward = aMapping.findForward("success");
	    session.removeAttribute("vpsCreateErrors");
	    jForm =  new JobScheduleDef ();
	    session.setAttribute ("scheduleDef", jForm);
	}
	catch (Exception e) {
	    e.printStackTrace();
	    String errorMsg = null;
	    if (e instanceof VpsException)
		errorMsg = ((VpsException)e).getMessage();
	    else {
		errorMsg = e.toString();
		int index = errorMsg.indexOf (':');
		if (index > 0 && index < errorMsg.length()) {
		    //This will exlude "java.lang.Exception:" from showing up as part of the error message.
		    //The message will consist of the exception message only, if any.
		    String temp = errorMsg.substring(index+1); 
		    if (temp.trim().length() != 0)
			errorMsg = temp;
		}
	    }
	    Collection errors = new ArrayList();
	    errors.add(errorMsg);
	    session.setAttribute("vpsCreateErrors", errors);
	    session.setAttribute("oldJobDef", jForm);
	    forward = aMapping.findForward("failure");
	}

	forward = ActionHelper.findForwardBasedOnPermission (aRequest,
							     forward,
							     aMapping.findForward("noPermission"));
	logger.debug ("EXIT: " + METHOD_NAME);
	return forward;
    }
}




