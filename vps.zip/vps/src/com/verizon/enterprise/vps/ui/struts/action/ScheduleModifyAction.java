package com.verizon.enterprise.vps.ui.struts.action;

import java.util.Enumeration;
import java.util.Date;
import java.util.Collection;
import java.util.ArrayList;
import java.sql.Timestamp;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.datalayer.JobScheduleDefTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.TaskInstanceTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.PendingTaskTableAccess;
import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.ui.dataobjects.TaskInstance;
import com.verizon.enterprise.vps.ui.dataobjects.PendingTask;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.ui.helper.DataValidator;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ScheduleParser;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.ui.struts.action.ActionHelper;
import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.enterprise.vps.dataobjects.VpsException;


public class ScheduleModifyAction extends Action {
    private static Logger logger = Logger.getLogger(ScheduleModifyAction.class);

    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse){
	final String METHOD_NAME = "ScheduleModifyAction:execute()";
	logger.debug("ENTER: " + METHOD_NAME );
	
	JobScheduleDef jobScheduleDef = (JobScheduleDef)aForm;
	HttpSession session = aRequest.getSession();

	ActionForward forward = null;
	try {
	    String taskInfoXml = jobScheduleDef.getTaskInfo();
	    String scheduleInfo = jobScheduleDef.getScheduleInfo();
	    String effectiveStartTime = jobScheduleDef.getEffectiveStartTime();
	    String effectiveStopTime = jobScheduleDef.getEffectiveStopTime();
	    String name = jobScheduleDef.getName();

	    logger.info ("taskInfoXml = " + taskInfoXml);

	    DataValidator.nameInfoValidate (name);
	    DataValidator.taskInfoValidate (taskInfoXml);
	    DataValidator.scheduleInfoValidate (scheduleInfo);

	    Date startDate = null;
	    Date stopDate = null;
	    
	    if (effectiveStartTime != null && effectiveStartTime.trim().length() != 0)
		startDate = Util.convertToDateObject(effectiveStartTime);
	
	    if (effectiveStopTime != null && effectiveStopTime.trim().length() != 0)
		stopDate = Util.convertToDateObject(effectiveStopTime);
	    
	    XmlPersistentTask xpt = new XmlPersistentTask(taskInfoXml);
	    ISchedule schedule = ScheduleParser.parseSchedule(scheduleInfo);
	    schedule.setName(name); //schedule name has to be set before updating it.

	    if (startDate != null)
		schedule.setStartEffectiveTime(startDate);
	    if (stopDate != null)
		schedule.setEndEffectiveTime(stopDate);
	    
	    JobScheduleDefTableAccess jAccess = new JobScheduleDefTableAccess();
	    jobScheduleDef.setStatus(VpsConstants.JOB_SCHEDULE_DEF_ACTIVE);

	    String userId = null;
	    try {
		userId =  ActionHelper.getUserOidFromRequest(aRequest);
		logger.debug ("userOid = " + userId);
	    }
	    catch (Exception ex) {
		logger.error (Util.getStackTrace(ex));
	    }

	    JobScheduleDef updatedJobScheduleDef = jAccess.updateJobScheduleDef (xpt, schedule, jobScheduleDef, userId);
	    session.setAttribute ("scheduleDef", updatedJobScheduleDef);
	    session.removeAttribute (VpsConstants.TREE_MODEL_NAME_IN_SESSION); //to refresh the tree
	    session.removeAttribute("vpsCreateErrors");
	    forward = aMapping.findForward("display");
	}
	catch (Exception e){
	    e.printStackTrace();
	    String errorMsg = null;
	    if (e instanceof VpsException)
		errorMsg = ((VpsException)e).getMessage();
	    else {
		errorMsg = e.toString();
		int index = errorMsg.indexOf (':');
		if (index > 0 && index < errorMsg.length()) {
		    //This will exlude "java.lang.Exception:" from showing up as part of the error message.
		    //The message will consist of the exception message only, if any.
		    String temp = errorMsg.substring(index+1); 
		    if (temp.trim().length() != 0)
			errorMsg = temp;
		}
	    }
	    Collection errors = new ArrayList();
	    errors.add(errorMsg);
	    session.setAttribute("vpsCreateErrors", errors);

	    forward = aMapping.findForward("failure");
	}

	forward = ActionHelper.findForwardBasedOnPermission (aRequest,
							     forward,
							     aMapping.findForward("noPermission"));
	logger.debug("EXIT: " + METHOD_NAME );
	return forward;
    }
}



