package com.verizon.enterprise.vps.ui.helper;

import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeNode;
import org.apache.log4j.Logger;


public class VpsTreeModel extends TreeModel  {
    private static Logger logger = Logger.getLogger(VpsTreeModel.class);
    
    public VpsTreeModel() {
	final String METHOD_NAME = "VpsTreeModel.VpsTreeModel()";
	logger.debug(METHOD_NAME + " ENTERING..."); 
	m_root = new DefaultWTreeNode("root", true);
	logger.debug(METHOD_NAME + " EXITING..."); 	
    }

    /*
    public DefaultWTreeNode getRoot () {
	return m_root;
    }

    
    public VpsTreeModel(int pagePosi, int pageSize) {
	final String METHOD_NAME = "VpsTreeModel.VpsTreeModel(int, int)";
	logger.debug(METHOD_NAME + " ENTERING..."); 

        // Build tree.
	m_root = new DefaultWTreeNode("root", true);
	try {
	    DefaultWTreeNode parent = (DefaultWTreeNode)getRoot();
	    int startPosi = pagePosi*pageSize;
	    List childList = VpsTreeNodeHelper.getChildNodeList(parent, pagePosi, pageSize);
	    int totalChildCount = VpsTreeNodeHelper.tempGetTotalChildCount(parent);
	    VpsTreeNodeHelper.populateNodeWithChild(parent, startPosi, -1, childList, totalChildCount);
	}
	catch (Exception e) {
	    logger.error (Util.getStackTrace(e));
	}
	logger.debug(METHOD_NAME + " EXITING..."); 	
    }
    */
}










