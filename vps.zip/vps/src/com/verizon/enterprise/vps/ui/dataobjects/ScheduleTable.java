package com.verizon.enterprise.vps.ui.dataobjects;

import java.io.Serializable;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import java.lang.*;
import java.lang.reflect.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ScheduleTable implements Serializable {
  private String scheduleInputRow=null;
  private String messageRow=null;
  private String isScript = "FALSE";

  private String className = null;
  private String methodName = null;
  private int paramCount = 0;

  private String msg = null;

  public ScheduleTable() {
    className = null;
    methodName=null;
    populateHtml(VpsConstants.ACTION_INIT);
  }

  public void reset()
  {
    className=null;
    methodName=null;
    populateHtml(VpsConstants.ACTION_INIT);
  }

  public String getIsScript()
  {
    return this.isScript;
  }
  public void setIsScript(String isScript)
  {
    this.isScript = isScript;
  }

  public void setMessageRow(String message){
    this.messageRow=message;
  }
  public String getMessageRow(){
    return this.messageRow;
  }

  public void setScheduleInputRow(String inputRow){
    this.scheduleInputRow = inputRow;
  }
  public String getScheduleInputRow(){
    return this.scheduleInputRow;
  }

  public void setParamCount(int count)
  {
    this.paramCount=count;
  }
  public int getParamCount()
  {
    return this.paramCount;
  }

  public void setClassName(String className)
  {
    this.className = className;
  }
  public String getClassName()
  {
    return this.className;
  }

  public void setMethodName(String methodName)
  {
    this.methodName = methodName;
  }
  public String getMethodName()
  {
    return this.methodName;
  }

  public boolean validateClassName()
  {
    try{
      Class c = Class.forName(className);
    }catch (Exception e)
    {
      return false;
    }
    return true;
  }

  public String[] getClassMethods()
  {
    try{
      Class c = Class.forName(className);
      Method[] m = c.getMethods();
      String[] methodStrings = new String[m.length];
      for(int i = 0; i< m.length; i ++)
      {
        String oneMethodString = m[i].getName()+"(";
        Class[] parameterTypes = m[i].getParameterTypes();
        for(int k = 0; k < parameterTypes.length; k++)
        {
          oneMethodString = oneMethodString + " " + parameterTypes[k].getName();
        }
        oneMethodString += ")";
        methodStrings[i] = oneMethodString;
      }
      return methodStrings;
    }catch (Exception e)
    {
      //shouldn't happen because it's already validated
      return null;
    }
  }

  public void setMethodParamCount()
  {
    paramCount = 0; //reset to 0
    try{
      //Class c = Class.forName(className);
      //Method[] m = c.getMethods();
      String[] m = getClassMethods();
      for(int i =0; i < m.length; i++)
      {
        if(m[i].equals(methodName))
        {//count how many space char to determine the parameter count
          int index = 0;
          while(index < m[i].length())
          {
            index = m[i].indexOf(' ', index+1);
            if(index == -1)
            {
              break;
            }
            paramCount++;
          }
          break;
        }
      }
    }catch (Exception e)
    {
      //shouldn't happen because it's already validated
    }
  }

  public void populateHtml(String action){
    if(action.equals(VpsConstants.ACTION_INIT))
    {
      className = null;
      methodName = null;
      msg="";
      //scheduleInputRow="<TR class=\"subnavLink\">"
      //    +"<TD ALIGN=\"left\" width=\"4\"><IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
      //    +"<TD colspan=\"3\"><a href='javascript:schedule_next(\""
      //+com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_CLASSNAME
      //    +"\");'>Schedule a Job</a></TD><TD width=\"4\"/></TR>";
      scheduleInputRow="<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
          +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
          +"<TD width=\"260\" colspan=\"2\"><INPUT TYPE=RADIO NAME=\"isScriptInput\" VALUE=\"TRUE\">"
          +"Schedule Script<br/><INPUT TYPE=RADIO NAME=\"isScriptInput\" VALUE=\"FALSE\">Schedule Class"
          +"<br/><INPUT TYPE=RADIO NAME=\"isScriptInput\" VALUE=\"FALSE\">OS Command</TD>"
          +"<TD valign=bottom><a href='javascript:schedule_type();'><img border=\"0\" src=\"/operations/images/buttons/next.gif\" alt=\"next\">"
          +"</a></TD><TD width=\"4\"/></TR>";
    }
    else if(action.equals(VpsConstants.ACTION_SCRIPT))
    {
      className = null;
      methodName = null;
      //msg="Input the parameters for the script";
      msg="";
      //TODO
      scheduleInputRow=
      "<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
      +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
      +"<TD width=\"260\" colspan=\"3\"><INPUT TYPE=RADIO NAME=\"scriptType\" VALUE=\"beanshell\" checked>beanshell"
      +"<INPUT TYPE=RADIO NAME=\"scriptType\" VALUE=\"javascript\">javascript"
      +"<INPUT TYPE=RADIO NAME=\"scriptType\" VALUE=\"scriptfile\">script file"
      +"</TD><TD width=\"4\"/></TR><TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
      +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
      +"<TD colspan=\"3\">Input script or the name of the script here</TD><TD width=\"4\"></TR>"
      +"<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
      +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
      +"<TD colspan=\"3\"><TEXTAREA NAME=\"script\" COLS=45 ROWS=8></TEXTAREA></TD><TD width=\"4\">"
      +"</TR><TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
      +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
      +"<TD colspan=\"3\" align=right><a href='javascript:schedule_next(\""
      + com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_SUBMITSCRIPT
      +"\");'>"
      +"<img border=\"0\" src=\"/operations/images/buttons/submit.gif\" alt=\"submit\"></a></TD><TD width=\"4\"></TR>";
    }

    else if(action.equals(VpsConstants.ACTION_CLASSNAME))
    {
      msg = "Input class name";
      scheduleInputRow ="<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
          +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
          +"<TD width=\"80\">Class Name:</TD><TD width=\"180\"><input type=\"text\" name=\"classNameInput\" size=\"24\"/></TD><TD>"
          +"<a href='javascript:schedule_next(\""
          +com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_METHODNAME
          +"\");'><img border=\"0\" src=\"/operations/images/buttons/next.gif\" alt=\"next\"></a>"
          +"</TD><TD width=\"4\"/></TR>";
    }

    else if(action.equals(VpsConstants.ACTION_METHODNAME))
    {
      if(validateClassName() == false)
      {
        msg = "The class name you entered could not be found!";
        scheduleInputRow ="<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
            +"<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
            +"<TD width=\"80\">Class Name:</TD><TD width=\"180\"><input type=\"text\" name=\"classNameInput\" size=\"24\"/></TD><TD>"
            +"<a href='javascript:schedule_next(\""
            +com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_METHODNAME
            +"\");'><img border=\"0\" src=\"/operations/images/buttons/next.gif\" alt=\"next\"></a>"
            +"</TD><TD width=\"4\"/></TR>";

      }else
      {
        String[] m = getClassMethods();
        msg = "Input method name";
        scheduleInputRow =
            "<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\">"
            + "<IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\"></TD>"
            + "<TD width=\"80\">Method Name:</TD><TD width=\"180\">"
            +"<SELECT NAME=\"methodNameInput\">";

        for(int i =0; i < m.length; i++)
        {
          scheduleInputRow+="<OPTION VALUE=\"" + m[i] +"\">" + m[i];
        }
        scheduleInputRow+="</SELECT></TD><TD><a href='javascript:schedule_next(\""
            + com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_CLASSNAME
            + "\");'><img border=\"0\" src=\"/operations/images/buttons/previous.gif\" alt=\"previous\"></a>"
            + "<a href='javascript:schedule_next(\""
            + com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_PARAMLIST
            + "\");'><img border=\"0\" src=\"/operations/images/buttons/next.gif\" alt=\"next\"></a>"
            + "</TD><TD width=\"4\"/></TR>";
      }
    }
    else if(action.equals(VpsConstants.ACTION_PARAMLIST))
    {
      setMethodParamCount(); //obtain the method parameter number from class name and method name
      msg = "Input parameters";
      scheduleInputRow =
          "<TR class=\"bodycopy\"><TD ALIGN=\"left\" width=\"4\"><IMG src=\"/operations/images/s.gif\" height=\"1\" width=\"1\" alt=\"\">"
          +"</TD><TD colspan=\"2\" width=\"260\"><TABLE cellSpacing=\"0\" cellPadding=\"0\" border=\"0\">";


      for(int i = 1; i <= paramCount; i++)
      {
        scheduleInputRow += "<TR class=\"bodycopy\"><TD width=\"80\">Parameter ";
        scheduleInputRow += i;
        scheduleInputRow += ":</TD><TD width=180><input type=\"text\" size=\"24\" name=\"param\" value=\"\"/></TD></TR>";
      }


      scheduleInputRow +=
          "</TABLE></TD><TD valign=\"bottom\">"
          +"<a href='javascript:schedule_next(\""
          +com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_METHODNAME
          +"\");'><img border=\"0\" src=\"/operations/images/buttons/previous.gif\" alt=\"previous\"></a>"
          +"<a href='javascript:schedule_next(\""
          +com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_SUBMITCLASS
          +"\");'><img border=\"0\" src=\"/operations/images/buttons/submit.gif\" alt=\"submit\"></a>"
          +"</TD><TD width=\"4\"/></TR>";
    }
    else if(action.equals(VpsConstants.ACTION_OSCOMMAND))
    {
      msg="Input OS Command and Parameters";
      scheduleInputRow = "<TR class=\"bodycopy\"><TD width=\"4\"></TD><TD width=\"80\">OS Command</TD>"
          +"<TD width=\"180\"><input type=text name=\"osCommand\" size=\"20\"/></TD>"
          +"<TD><a href='javascript:schedule_next(\""
          +com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_SUBMITCOMMAND
          +"\");'><img border=\"0\" src=\"/operations/images/buttons/submit.gif\" alt=\"Schedule OS Command\"></a>"
          +"</TD><TD width=\"4\"></TD></TR><TR class=\"bodycopy\"><TD width=\"4\"></TD><TD width=\"80\">"
          +"Parameters</TD><TD width=\"180\"><input type=text name=\"osParam\" size=\"20\"/></TD>"
          +"<TD><a href='javascript:schedule_next(\""
          +com.verizon.enterprise.vps.ui.helper.VpsConstants.ACTION_ADDPARAM
          +"\");'><img border=\"0\" src=\"/operations/images/buttons/add.gif\" alt=\"add a parameter\">"
          +"</a></TD><TD width=\"4\"></TD></TR>";
    }
    else if(action.equals(VpsConstants.ACTION_ADDPARAM))
    {
      msg="Input OS Command and Parameters";
      scheduleInputRow = "";
    }

    messageRow="<TR class=\"bodycopy\"><TD width=\"4\"/><TD ALIGN=\"left\" colspan=\"3\">"
          + msg + "</TD><TD width=\"4\"/></TR><TR><TD height=\"6\"/></TR>";

  }

  public void setMessageRowWarning(String msg)
  {
    messageRow="<TR class=\"error\"><TD width=\"4\"/><TD ALIGN=\"left\" colspan=\"3\">"
          + msg + "</TD><TD width=\"4\"/></TR><TR><TD height=\"6\"/></TR>";
  }

}