package com.verizon.enterprise.vps.ui.tag;

import java.io.IOException;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspWriter;

import org.apache.log4j.Logger;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.kernel.config.Config;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author v434518
 * @version 1.1
 */

public class APMDisplayResultTagHandler extends BodyTagSupport {
    private static Logger logger = Logger.getLogger(APMDisplayResultTagHandler.class);
    private static final String CONFIG_PREFIX = "vps.vps";

    private String taskId; //this.taskId is different from the taskId read from tag attribute
                           //this.taskId is "fully qualified" taskId
    private int initWaitingSec;
    private String jsCallBackName;
    //private String framework;
    private int maxWaitingSec;
    //private String fullyQualifiedTaskId;
 
    public void setTaskId(String taskId) {
	this.taskId = taskId;
    }

    public void setInitWaitingSec (int initWaitingSec) {
	this.initWaitingSec = initWaitingSec;
    }
    
    public void setJsCallBackName (String jsCallBackName) {
	this.jsCallBackName = jsCallBackName;
    }
    /*
    public void setFramework (String framework) {
	if (framework == null || framework.length() == 0)
	    this.framework = VpsConstants.FRAMEWORKS[0];
	else
	    this.framework = framework;
    }
    */
    public void setMaxWaitingSec (int maxWaitingSec) {
	this.maxWaitingSec = maxWaitingSec;
    }

    public String getTaskId() {
	return this.taskId;
    }

    public int getInitWaitingtSec() {
	return this.initWaitingSec;
    }

    public String getJsCallBackName() {
	return this.jsCallBackName;
    }
    /*
    public String getFramework() {
	return this.framework;
    }
    */
    public int getMaxWaitingSec() {
	return this.maxWaitingSec;
    }

    private String getServletURL() {
	String servletURL = null;
	try {
	    String serverURL = com.sapient.framework.config.Config.getProperty("verizon.local.webServerURL", " https://iweb.verizon.com");
	    if (serverURL.indexOf("https://@WEBSERVER_HOST@") >= 0) { //local env
		String protocol = Config.getProperty(CONFIG_PREFIX, "vps.apm.servlet.protocol");
		String server = Config.getProperty(CONFIG_PREFIX, "vps.apm.servlet.server");
		String port = Config.getProperty(CONFIG_PREFIX, "vps.apm.servlet.port");
		serverURL = protocol + server + ":" + port;
	    }
	    String path = VpsConstants.APM_SERVLET_PATH;
	    servletURL = serverURL + path;
	}
	catch (Exception e) {
	    logger.error ("unable to read vps servlet info from vps.xml");
	}
	return servletURL;
    }

    public int doStartTag () throws JspException {
	logger.debug ("HanTest: do start tag of apm:displayResult tag, ID = " + taskId + "...");
	int returnValue;

	//if (framework.equals(VpsConstants.FRAMEWORKS[0])){ //sapient framework

	    //if (initWaitingSec > maxWaitingSec)
	    //throw new JspTagException ("initWaitingSec shall have a value smaller than that of maxWaitingSec.");
	    
	//boolean taskFinished = InitWaiting(initWaitingSec*1000, taskId, pageContext);
	    
	    if (initWaitingSec > 0)
		InitWaiting(initWaitingSec*1000, taskId, pageContext);

	    Tag parent = getParent();
	    
	    while (parent != null && !(parent instanceof APMRegisteredTasksTagHandler)) {
		parent = parent.getParent();
	    }

	    if (parent instanceof APMRegisteredTasksTagHandler){
		((APMRegisteredTasksTagHandler)parent).register (getTaskId(), 
								 String.valueOf(getMaxWaitingSec()), 
								 getJsCallBackName(),
								 getServletURL());
	    }
	    else 
		throw new JspTagException ("One of the ancestor tags of <apm:displayResult/> has to be <apm:registeredTasks/>.");

	    returnValue = EVAL_BODY_INCLUDE;
	    /*
	    if (taskFinished) {
		returnValue = EVAL_BODY_INCLUDE;
	    }
	    else {
		returnValue = EVAL_BODY_INCLUDE;
	    }
	    */

	    /*
	}
	else {
	    throw new JspTagException ("the value of framework attribute has to be specified as \"sapient\".");
	}
	    */
	return returnValue;
    }

    protected boolean InitWaiting(long waitingMillSec, 
				  String taskId, 
				  PageContext pageContext) throws JspException{
	TimeoutTaskListener listener = null;
	try {
	    logger.debug("taskId in InitWaiting = " + taskId);
	    listener = new SapientHelper(pageContext).getTimeoutListener(new Long(taskId));
	}
	catch (Exception e) {
	    logger.error (e.toString());
	    logger.error (Util.getStackTrace(e));
	    throw new JspTagException("Unable to find listener: "+e.getMessage());
	}

	if (listener == null)
	    throw new JspTagException(" listener is null for taskId=" + taskId);

	synchronized (listener) {
	    long t = waitingMillSec - listener.getTimeExecuted();
	    if (t > 0) {
		try {
		    listener.wait(t);   //block on the task
		}
		catch (java.lang.InterruptedException wakeup) { }
	    }
	}

	return listener.isDone();
    }

    public int doEndTag() throws JspException  {
	logger.debug ("HanTest: do end tag of apm:displayResult tag, ID = " + taskId + "...");
	return super.doEndTag();//EVAL_PAGE; //super.doEndTag();
    }
}







