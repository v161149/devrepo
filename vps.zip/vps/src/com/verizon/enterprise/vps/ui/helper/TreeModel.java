package com.verizon.enterprise.vps.ui.helper;

import java.util.Random;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Collection;
import java.util.Iterator;
import com.verizon.enterprise.preslet.tag.tree.WTree;
import com.verizon.enterprise.preslet.tag.tree.WTreeModel;
import com.verizon.enterprise.preslet.tag.tree.WTreeNode;
import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeModel;
import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeNode;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Verizon</p>
 * @author Zhong Chen
 * @version 1.0
 */

//public class TreeModel extends ActionForm implements WTreeModel  {
public class TreeModel implements WTreeModel  {

    protected WTreeNode m_root = null;
    protected boolean   m_bAsksAllowsChildren = false;

    /** Constructor */
    public TreeModel() {  
    }  
    
    /**
     * Creates a tree in which any node can have children.
     *
     * @param root a TreeNode object that is the root of the tree
     */
    public TreeModel(WTreeNode root) {
        this(root, false);
    }

    /**
     * Creates a tree specifying whether any node can have children,
     * or whether only certain nodes can have children.
     *
     * @param root a WTreeNode object that is the root of the tree
     * @param bAskAllowsChildren a boolean, false if any node can
     *        have children, true if each node is asked to see if
     *        it can have children
     * @see #asksAllowsChildren
     */
    public TreeModel(WTreeNode root, boolean bAsksAllowsChildren) {
        if (root == null) {
            throw new IllegalArgumentException("root is null");
        }
        m_root = root;
        m_bAsksAllowsChildren = bAsksAllowsChildren;
    }

    /**
     * Sets whether or not to test leafness by asking getAllowsChildren()
     * or isLeaf() to the TreeNodes.  If newvalue is true, getAllowsChildren()
     * is messaged, otherwise isLeaf() is messaged.
     */
    public void setAsksAllowsChildren(boolean newValue) {
        m_bAsksAllowsChildren = newValue;
    }

    /**
     * Tells how leaf nodes are determined.
     *
     * @return true if only nodes which do not allow children are
     *         leaf nodes, false if nodes which have no children
     *         (even if allowed) are leaf nodes
     * @see #asksAllowsChildren
     */
    public boolean asksAllowsChildren() {
        return m_bAsksAllowsChildren;
    }

    /**
     * @return The root node.
     */
    public Object getRoot() {
        return m_root;
    }

    /**
     * Sets the root to <code>root</code>. This will throw an
     * IllegalArgumentException if <code>root</code> is null.
     */
    public void setRoot(WTreeNode root) {
        if(root == null) {
            throw new IllegalArgumentException("Root of tree is not allowed to be null");
        }

        m_root = root;
    }

    /**
     * Check whether child data is available. If not, no child will be displayed.
     */
    public boolean isChildDataAvailable(Object parent) {
        return parent != null && ((WTreeNode)parent).isChildDataAvailable();
    }

    /**
     * Get total number of child for a parent node.
     */
    public int getChildCount(Object parent) {
        return parent==null ? 0 : ((WTreeNode)parent).getChildCount();
    }

    /**
     * Get child node by index.
     * @param parent Parent node.
     * @param index Child index.
     * @return child node.
     */
    public Object getChild(Object parent, int index) {
        return parent == null ? null : ((WTreeNode)parent).getChildAt(index);
    }

    /**
     * Check whether a node is leaf.
     * @param node Node to check.
     * @return true for leaf node; false o.w.
     */
    public boolean isLeaf(Object node) {
        if (node == null) return true;
        return m_bAsksAllowsChildren
                ? !((WTreeNode)node).getAllowsChildren()
                : ((WTreeNode)node).isLeaf();
    }

    /**
     * Invoked this to insert newChild at location index in parents children.
     */
    public void setChild(WTreeNode newChild,
                         WTreeNode parent, int index){
        parent.setChildAt(newChild, index);
    }

    /**
     * Find node in tree by row/path id.
     * @return null if not found.
     */
    public WTreeNode findNodeByPathId(String sPathId) {
        return (WTreeNode)findNodeByPathId(this, sPathId);
    }

    /**
     * Find node in tree by row/path id.
     * @return null if not found.
     */
    public static Object findNodeByPathId(WTreeModel model, String sPathId) {
        if (sPathId==null || sPathId.length() <= 1 || model == null) return null;

        sPathId = sPathId.substring(1);
        String sChildId;
        int nPrevIndex=0, nSepIndex, nChildId;
        Object currentParent = null;
        try {
            do {
                nSepIndex = sPathId.indexOf(WTree.PATH_SEPARATOR, nPrevIndex+1);
                if (currentParent == null) {
                    currentParent = model.getRoot();
                    nPrevIndex = nSepIndex;
                    continue;
                }
                else if (nSepIndex > 0) {
                    sChildId = sPathId.substring(nPrevIndex+1, nSepIndex);
                }
                else {
                    sChildId = sPathId.substring(nPrevIndex+1);
                }

                nChildId = Integer.parseInt(sChildId);
                if (currentParent != null) currentParent = model.getChild(currentParent, nChildId);
                nPrevIndex = nSepIndex;
            }
            while (nSepIndex > 0);
        }
        catch (NumberFormatException nfe) {
            currentParent = null;
        }
        catch (ArrayIndexOutOfBoundsException abe) {
            currentParent = null;
        }

        return currentParent;
    }

    /**
     * Find node by user object.
     * This method uses equals() defined in user object for equality test.
     */
    public WTreeNode findNodeByUserObject(Object uo) {
        if (uo == null) return null;

        DefaultWTreeNode uoNode = new DefaultWTreeNode(uo);
        LinkedList qSearchList = new LinkedList();
        WTreeNode node, searchNode;
        Iterator iter;

        // Check root first.
        node = (WTreeNode)this.getRoot();
        if (uoNode.equals(node)) return node;

        // tranverse tree
        // Avoid inserting too many nodes into list. All the nodes
        // in the list are verified already before the insertion.
        qSearchList.add(node);
        while (!qSearchList.isEmpty()) {
            searchNode = (WTreeNode)qSearchList.removeFirst();
            Collection qChildren = searchNode.getAvailableChildren();
            if (qChildren == null || qChildren.isEmpty()) continue;
            iter = qChildren.iterator();
            while (iter.hasNext()) {
                node = (WTreeNode)iter.next();
                if (uoNode.equals(node)) {
                    return node;
                }
                else if (node != null) {
                    qSearchList.addLast(node);
                }
            }
        }

        return null;
    }


}
