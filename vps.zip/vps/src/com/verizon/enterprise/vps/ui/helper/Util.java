package com.verizon.enterprise.vps.ui.helper;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import java.util.Enumeration;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import com.verizon.kernel.jdbc.CursorId;
import java.lang.reflect.Method;
import org.apache.log4j.Logger; 


public class Util { 

    private static Logger logger = Logger.getLogger(Util.class);

    //@param time takes format of MM-DD-YYYY HH[24]:MM:SS    MM/DD/YYYY HH[24]:MM:SS
    //                            MM-DD-YYYY HH:MM:SS AM[PM] MM/DD/YYYY HH:MM:SS AM[PM]
    //                            YYYY-MM-DD HH[24]:MM:SS    YYYY/MM/DD HH[24]:MM:SS
    //                            YYYY-MM-DD HH:MM:SS AM[PM] YYYY/MM/DD HH:MM:SS AM[PM]
    //                            MM-DD-YYYY                 MM/DD/YYYY
    //                            YYYY-MM-DD                 YYYY/MM/DD
    public static Date convertToDateObject(String time) throws Exception {
	int year, month, date, hour, minute, second;
	String ampm = null;
	Calendar calendar = null;
	try {
	    StringTokenizer st = new StringTokenizer(time);

	    String datePart = null;
	    String hourPart = null;

	    if (st.countTokens() == 3) {
		datePart = st.nextToken();
		hourPart = st.nextToken();
		ampm = st.nextToken();

	    }else if (st.countTokens() == 2) {
		datePart = st.nextToken();
		hourPart = st.nextToken();
	    }
	    else  if (st.countTokens() == 1) {
		datePart = st.nextToken();
		hourPart = null;
	    }
	    else
		throw new Exception ("unrecognized time format");
	    
	    st = new StringTokenizer(datePart, "/-");
	    String m, d, y;

	    m = st.nextToken();
	    if (m.length() == 2) {
		m = m;
		d = st.nextToken();
		y = st.nextToken();
	    }
	    else {
		y = m;
		m = st.nextToken();
		d = st.nextToken();
	    }

	    year = Integer.parseInt(y);
	    month = Integer.parseInt(m);
	    date = Integer.parseInt (d);
	    
	    if (hourPart != null) {
		st = new StringTokenizer (hourPart, ":");
		String ho, mi, se, temp;
		
		int compensatePM = 0;
		if (ampm!=null && ampm.equals("PM"))
		    compensatePM = 12;
		
		ho = (temp = st.nextToken()) == null ? "0":Integer.toString((Integer.parseInt(temp)+compensatePM));
		mi = (temp = st.nextToken()) == null ? "0":temp;
		se = (temp = st.nextToken()) == null ? "0":temp;
		
		if (se.indexOf('.')>0)
		    se = se.substring(0, se.indexOf('.'));
		
		hour = Integer.parseInt(ho);
		minute = Integer.parseInt(mi);
		second = Integer.parseInt(se);
	    }
	    else {
		hour = 0;
		minute = 0;
		second = 0;
	    }
	    
	    calendar = new GregorianCalendar(year, month-1, date, hour, minute, second);
	}
	catch (Exception e) {
	    throw new Exception ("APM exception. There is a format problem with input date, " + time);
	}
	
	return calendar.getTime();
    }

    public static String convertTimestampToUIStd(Timestamp time) {
	
	String returnString = null;
	if (time != null) {
	    SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aaa");
	    returnString = format.format(time);
	}
	return returnString;
    }

    public static String convertStatusToUIFormat(String backendStatus) {
	
	String returnString = null;
	if (backendStatus.equals (String.valueOf(IVpsTask.PHANTOM)))
	    returnString = "PHANTOM";
	else if (backendStatus.equals (String.valueOf(IVpsTask.INITIAL)))
	    returnString = "INITIAL";
	else if (backendStatus.equals (String.valueOf(IVpsTask.PENDING)))
	    returnString = "PENDING";
	else if (backendStatus.equals (String.valueOf(IVpsTask.EXECUTING)))
	    returnString = "EXECUTING";
	else if (backendStatus.equals (String.valueOf(IVpsTask.FINISHED)))
	    returnString = "FINISHED";
	else if (backendStatus.equals (String.valueOf(IVpsTask.CANCELED)))
	    returnString = "CANCELED";
	else if (backendStatus.equals (String.valueOf(IVpsTask.FAILED)))
	    returnString = "FAILED";
	else
	    returnString = "UNDEFINED";

	return returnString;
    }


    //it follows the format of DISPLAY$STATUS$PREFIX$OID
    public static String getTypePrefix (String link) {
	String prefix = null;
	if (link != null) {
	    int lastIndex = link.lastIndexOf(VpsConstants.DELIMITER);
	    int secLastIndex = link.lastIndexOf(VpsConstants.DELIMITER, lastIndex-1); //find the second to last DELIMITER
	    prefix = link.substring(secLastIndex+1, lastIndex);
	}
	return prefix;
    }

    //it follows the format of DISPLAY$STATUS$PREFIX$OID
    public static String getDisplayName (String link) {
	String displayName = null;
	if (link != null) {
	    int lastIndex = link.lastIndexOf(VpsConstants.DELIMITER);
	    int secLastIndex = link.lastIndexOf(VpsConstants.DELIMITER, lastIndex-1); //find the second to last DELIMITER
	    int thirdLastIndex = link.lastIndexOf(VpsConstants.DELIMITER, secLastIndex-1); //find the third to last DELIMITER

	    displayName = link.substring(0, thirdLastIndex);
	}
	return displayName;
    }

    //it follows the format of DISPLAY$STATUS$PREFIX$OID
    public static String getTaskStatus (String link){
	String status = null;
	if (link != null) {
	    int lastIndex = link.lastIndexOf(VpsConstants.DELIMITER);
	    int secLastIndex = link.lastIndexOf(VpsConstants.DELIMITER, lastIndex-1); //find the second to last DELIMITER
	    int thirdLastIndex = link.lastIndexOf(VpsConstants.DELIMITER, secLastIndex-1); //find the third to last DELIMITER

	    status = link.substring(thirdLastIndex+1, secLastIndex);
	}
	return status;
    }

    //it follows the format of DISPLAY$STATUS$PREFIX$OID
    public static String getOid (String link){
	String oid = null;
	if (link != null) {
	    int lastIndex = link.lastIndexOf(VpsConstants.DELIMITER);
	    oid = link.substring(lastIndex+1);
	}
	return oid;
    }

    public static String getStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        pw.close();

        return sw.toString();
    }
    /**
     * @param pageSize, pageNumber, int variables for pagination purposes
     * @param action, int, takes one of pagination actions, i.e., CursorId.FIRST_PAGE, 
     *                 CursorId.PREVIOUS_PAGE, CursorId.NEXT_PAGE, CursorId.LAST_PAGE, CursorId.GOTO_PAGE
     * @param id, String cursor id
     */
    public static CursorId getNewCursorId (int pageSize, int pageNumber, 
					   int action) { 
        CursorId cursorId = new CursorId(pageSize);
        cursorId.setPageNumber(pageNumber);
        cursorId.setAction(action);
        return cursorId;
    } 

    public static CursorId getNewCursorId(int pageSize) {
	return Util.getNewCursorId(pageSize, 1, CursorId.FIRST_PAGE);
    }

    //it returns a list of method names with the class
    public static List getMethodNames(String className) throws Exception{
  
	Class c = Class.forName(className);
	Method[] m = c.getMethods();
	List methodNames = new ArrayList();
	String oneMethodString = null;

	for(int i = 0; i< m.length; i ++) {
	    StringBuffer sb = new StringBuffer();
	    sb.append(m[i].getName());
	    sb.append('(');
	    
	    Class[] parameterTypes = m[i].getParameterTypes();
	    
	    for(int k = 0; k < parameterTypes.length; k++){
		sb.append(' ');
		sb.append(parameterTypes[k].toString());
	    }
	    sb.append(')');

	    oneMethodString = sb.toString();
	    methodNames.add(oneMethodString);
	}
	return methodNames;
    }

    //this will replace array representation in the method/arguement list.
    public static List beautifyMethodNamesForUI(List methodList) throws Exception{
  
	List returnList = new ArrayList();
	if (methodList != null) {
	    int size = methodList.size();
	    String methodName;

	    for (int i=0; i<size; i++) {
		methodName = (String)methodList.get(i);
		methodName = Util.beautifyMethodNameForUI(methodName);
		returnList.add(methodName);
	    }
	}
	return returnList;
    }
    
    public static String beautifyMethodNameForUI(String methodName) throws Exception {

	char [] cArray = methodName.toCharArray();
	StringBuffer sb = new StringBuffer();

	for (int i=0; i<cArray.length; i++) {
	    if (cArray[i] != '[')
		sb.append(cArray[i]);
	    else{
		
		if (cArray[i+1]=='B') {
		    sb.append("byte[]");
		}
		else if (cArray[i+1]=='C') {
		    sb.append("char[]");
		}
		else if (cArray[i+1]=='D') {
		    sb.append("double[]");
		}
		else if (cArray[i+1]=='F') {
		    sb.append("float[]");
		}
		else if (cArray[i+1]=='I') {
		    sb.append("int[]");
		}
		else if (cArray[i+1]=='J') {
		    sb.append("long[]");
		}
		else if (cArray[i+1]=='S') {
		    sb.append("short[]");
		}
		else if (cArray[i+1]=='Z') {
		    sb.append("boolean[]");
		}
		else if (cArray[i+1]=='L') {
		    i++;
		    char ch = cArray[++i];
		    while (ch != ';' && ch!=')') {
			sb.append(ch);
			ch = cArray[++i];
		    }
		    
		    if (ch == ';'){
			if ( i+1<cArray.length && cArray[i+1]==')')
			    sb.append("[])");
			else
			    sb.append("[] ");
		    }
		    else
			sb.append("[])");
		}
		i++;
	    }
	}
	
	return sb.toString();
    }

    public static  List getMethodArgs(String className, 
				      String methodName) throws Exception {
	int index1 = methodName.indexOf('(');
	int index2 = methodName.indexOf(')');
	int numberOfArgs = 0;
	String arguementString;

	try {
	    String temp = methodName.substring(index1+1, index2);
	    arguementString = temp.trim();
	}
	catch (Exception e) {
	    arguementString = null;
	}

	if (arguementString != null 
	    && arguementString.length() != 0){
	    
	    StringTokenizer st = new StringTokenizer (arguementString);
	    numberOfArgs = st.countTokens();

	    while (st.hasMoreTokens()) {
		String temp = (String)st.nextToken();
		if (temp.equalsIgnoreCase("class"))
		    numberOfArgs--;
	    }
	}
	else
	    numberOfArgs = 0;
	
	Class c = Class.forName(className);
	Method[] m = c.getMethods();

	Class[] parameterTypes = null;
	List args = null;

	int index = methodName.indexOf("("); //method name may include '(' and arguements. need to ignore them.

	if (index >0)
	    methodName = methodName.substring(0,index).trim();

	for(int i = 0; i< m.length; i ++) {
	    if (m[i].getName().equals (methodName)) {
		parameterTypes = m[i].getParameterTypes(); //it returns an array of length 0 if method does not take arguement.
		if (parameterTypes.length == numberOfArgs)
		    break;
	    }
	}

	if (parameterTypes == null)
	    throw new Exception ("method, " + methodName + ", does NOT exist in class " + className + ".");
	
	args = new ArrayList();
	for (int i=0; i<parameterTypes.length; i++)
	    args.add (parameterTypes[i].toString());

	return args;
    }


    public static void main (String [] args ) throws Exception {
	Util.convertTimestampToUIStd(new Timestamp(System.currentTimeMillis()));
    }

}






