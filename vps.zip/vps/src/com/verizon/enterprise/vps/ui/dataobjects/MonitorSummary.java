package com.verizon.enterprise.vps.ui.dataobjects;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MonitorSummary implements java.io.Serializable
{
    String environment = null;
    String status = null;
    String pendingTaskCount = "0";
    String runningTaskCount = "0";
    String finishedTaskCount = "0";

    public MonitorSummary()
    {
    }

    public void setEnvironment(String value)
    {
        environment = value;
    }

    public String getEnvironment()
    {
        return environment;
    }

    public void setStatus(String value)
    {
        status = value;
    }

    public String getStatus()
    {
        return status;
    }

    public void setPendingTaskCount(String value)
    {
        pendingTaskCount = value;
    }

    public String getPendingTaskCount()
    {
        return pendingTaskCount;
    }

    public void setRunningTaskCount(String value)
    {
        runningTaskCount = value;
    }

    public String getRunningTaskCount()
    {
        return runningTaskCount;
    }

    public void setFinishedTaskCount(String value)
    {
        finishedTaskCount = value;
    }

    public String getFinishedTaskCount()
    {
        return finishedTaskCount;
    }

    public String toString()
    {
        StringBuffer buf = new StringBuffer();

        buf.append("environment = " + environment + "\n");
        buf.append("status = " + status + "\n");
        buf.append("pendingTaskCount = " + pendingTaskCount + "\n");
        buf.append("runningTaskCount = " + runningTaskCount + "\n");
        buf.append("finishedTaskCount = " + finishedTaskCount + "\n");

        return buf.toString();
    }
}