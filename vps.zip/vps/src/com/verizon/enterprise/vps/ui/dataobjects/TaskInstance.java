package com.verizon.enterprise.vps.ui.dataobjects;

import java.util.StringTokenizer;
import java.sql.Timestamp;
import com.verizon.enterprise.vps.ui.helper.Util;

public class TaskInstance {

    private String taskInstanceOid; 
    private String status;
    private String startTime;
    private String endTime;
    private String message;
    private String jobRefCid;
    private String jobRefOid;
    private String userId;
    private String timestamp;
    private String uiStatus;
    private String uiMessage;

    public TaskInstance () {
    } 

    public TaskInstance (String oid, String message) {
	this.taskInstanceOid = oid;
	this.message = message;
    }

    public TaskInstance (String taskInstaceOid, String status, String startTime, 
			 String endTime, String message, String jobRefCid, 
			 String jobRefOid, String timestamp, String userOid) {
	this.setTaskInstanceOid (taskInstaceOid);
	this.setStatus(status);
	this.setStartTime(startTime);
	this.setEndTime(endTime);
	this.setMessage(message);
	this.setJobRefCid(jobRefCid);
	this.setJobRefOid(jobRefOid);
	this.setTimestamp(timestamp);
	this.setUserId(userOid);
    }

    public void setTaskInstanceOid(String oid) {
	this.taskInstanceOid = oid;
    }

    public void setStatus(String status) {
	this.status = status;
    }

    public void setStartTime(String startTime) {
	this.startTime = startTime;
    } 

    public void setEndTime(String endTime) {
	this.endTime = endTime;
    }

    public void setMessage(String message) {
	this.message = message;
    }

    public void setJobRefCid(String jobRefCid) {
	this.jobRefCid = jobRefCid;
    }

    public void setJobRefOid(String jobRefOid) {
	this.jobRefOid = jobRefOid;
    }
    
    public void setUserId (String userId) {
	this.userId = userId;
    }
    
    public void setTimestamp (String timestamp) {
	this.timestamp = timestamp;
    }

    public String getTaskInstanceOid() {
	return taskInstanceOid;
    }

    public String getStatus() {
	return status;
    }

    public String getStartTime() {
	return startTime;
    }

    public String getEndTime() {
	return endTime;
    }
 
    public String getMessage() {
	return message;
    }

    public String getJobRefCid() {
	return jobRefCid;
    }

    public String getJobRefOid() {
	return jobRefOid;
    }

    public String getUserId() {
	return userId;
    }

    public String getTimestamp() {
	return timestamp;
    }

    public String getUiStatus() {
	return Util.convertStatusToUIFormat(this.getStatus());
    }

    public String getUiMessage() {
	
	String returnString = null;
	if (this.message != null) {
	    StringTokenizer st = new StringTokenizer(message, ":");
	    StringBuffer sb = new StringBuffer();
	    sb.append("<TABLE>");
	    
	    while(st.hasMoreTokens()) {
		sb.append("<TR><TD CLASS=\"tableBodyCopy\">");
		sb.append(st.nextToken());
		sb.append("</TD></TR>");
	    }
	    sb.append("</TABLE>");
	    returnString = sb.toString();
	}
	return returnString;
    }
}

