package com.verizon.enterprise.vps.ui.tag;

import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.jdom.input.SAXBuilder;
import org.jdom.Document;
import org.jdom.Element;

import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.IVpsInteractiveTask;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;
import com.verizon.enterprise.vps.core.InteractiveExecutionTask;
import com.verizon.enterprise.vps.core.Dispatcher;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class APMTag extends BodyTagSupport
{
   public int doEndTag() throws JspException
   {
     try {
       String xml = getBodyContent().getString().trim();
       if (xml.length() > 0) {
         parse(xml);
       }
       Class taskClass = Class.forName(m_sClassName);
       java.lang.reflect.Constructor ctor
           = taskClass.getConstructor(m_ctor_param_types);
       IVpsInteractiveTask task
           = (IVpsInteractiveTask) ctor.newInstance(m_ctor_params);

       new SapientHelper(pageContext).scheduleUIJob(m_sTaskName, task);
     }
     catch (org.jdom.JDOMException e) {
       throw new JspException("unable to parse APM task", e);
     }
     catch (java.io.IOException e) {
       throw new JspException("unable to parse APM task", e);
     }
     catch (ClassNotFoundException e) {
       throw new JspException("unable to create APM task", e);
     }
     catch (NoSuchMethodException e) {
       throw new JspException("unable to create APM task", e);
     }
     catch (InstantiationException e) {
       throw new JspException("unable to create APM task", e);
     }
     catch (IllegalAccessException e) {
       throw new JspException("unable to create APM task", e);
     }
     catch (java.lang.reflect.InvocationTargetException e) {
       throw new JspException("unable to create APM task", e);
     }
     catch (VpsException e) {
       throw new JspException("unable to schedule APM task", e);
     }
     catch (Exception e) {
       e.printStackTrace();
       throw new JspException("unexpected APM task exception", e);
     }

     return super.doEndTag();
   }

   public void setTaskName(String taskName) {
     m_sTaskName = taskName;
   }

   public String getTaskName() {
     return m_sTaskName;
   }

   public String getClassname() {
     return m_sClassName;
   }

   public void setClassname(String classname) {
     m_sClassName = classname;
   }

   /**
    * parse constructor arguments
    */
   private void parse(String s) throws Exception {
     SAXBuilder builder = new SAXBuilder();
     Document doc = builder.build(new java.io.StringReader(s));
     Element root = doc.getRootElement();
     java.util.List list = root.getChildren("argument");
     m_ctor_param_types = new Class[list.size()];
     m_ctor_params = new Object[list.size()];
     int i = 0;
     for (java.util.Iterator it = list.iterator(); it.hasNext();) {
       Element elem = (Element) it.next();
       String type = elem.getAttributeValue("type");
       String value = elem.getTextTrim();
       Object[] pair = getArgument(value, type);
       m_ctor_param_types[i] = (Class) pair[0];
       m_ctor_params[i++] = pair[1];
     }
   }

   private Object[] getArgument(String value, String type) throws Exception {
     if ((type == null) || (type.length() <= 0))
     {
       return new Object[] {String.class, value};
     }
     if (type.equals(Boolean.TYPE.getName()))
     {
       return new Object[] {Boolean.TYPE, Boolean.valueOf(value)};
     }
     if (type.equals(Character.TYPE.getName())) {
       char c = value.length()<1?' ':value.charAt(0);
       return new Object[] {Character.TYPE, new Character(c)};
     }
     if (type.equals(Byte.TYPE.getName()))
     {
       return new Object[] {Byte.TYPE, Byte.valueOf(value)};
     }
     if(type.equals(Short.TYPE.getName()))
     {
       return new Object[] {Short.TYPE, Short.valueOf(value)};
     }
     if (type.equals(Integer.TYPE.getName()))
     {
       return new Object[] {Integer.TYPE, Integer.valueOf(value)};
     }
     if (type.equals(Long.TYPE.getName()))
     {
       return new Object[] {Long.TYPE, Long.valueOf(value)};
     }
     if (type.equals(Double.TYPE.getName()))
     {
       return new Object[] {Double.TYPE, Double.valueOf(value)};
     }
     if (type.equals(Float.TYPE.getName()))
     {
       return new Object[] {Float.TYPE, Float.valueOf(value)};
     }

     Class clz =  Class.forName(type);
     Object obj = clz.getConstructor(new Class[] {String.class}).newInstance(new Object[] {value});
     return new Object[] {clz,obj};
   }

   private String m_sTaskName;
   private String m_sClassName;

   private Class[] m_ctor_param_types;
   private Object[] m_ctor_params;

   public static void main(String[] args) throws Exception {
     APMTag t = new APMTag();
     t.setClassname("java.util.Hashtable");

     String s = "<constructor-arguments>"
                + "<argument type='int'>10</argument>"
                + "<argument type='float'>0.75</argument>"
                + "</constructor-arguments>";
     t.parse(s);
     Class taskClass = Class.forName(t.m_sClassName);
     java.lang.reflect.Constructor ctor
         = taskClass.getConstructor(t.m_ctor_param_types);
     java.util.Hashtable b
         = (java.util.Hashtable) ctor.newInstance(t.m_ctor_params);
     System.out.println(b);

     //empty constructor
     APMTag t2 = new APMTag();
     t2.setClassname("java.util.Hashtable");
     java.lang.reflect.Constructor ctor2
         = taskClass.getConstructor(t.m_ctor_param_types);
     java.util.Hashtable b2
         = (java.util.Hashtable) ctor.newInstance(t.m_ctor_params);
     System.out.println(b2);
   }
 }