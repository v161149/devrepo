package com.verizon.enterprise.vps.ui.tag;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import com.sapient.framework.presentation.servlet.page.*;
import com.sapient.framework.presentation.servlet.event.*;
import java.util.*;
import com.sapient.framework.presentation.servlet.state.*;
import com.sapient.framework.util.ReflectionException;

import com.verizon.enterprise.common.VerizonStateManager;
import com.verizon.enterprise.common.VerizonModeler;

import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.dataobjects.IVpsInteractiveTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTaskListener;
import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.core.InteractiveExecutionTask;
import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.util.LogHelper;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class SapientHelper
{
  private VerizonStateManager m_state_manager;
  private Map m_displayObjects;
  private Long m_userId;
  private ScheduleManager m_schedule_manager;

  public SapientHelper(VerizonStateManager stateManager,
                       Map displayObjects)
  {
    m_state_manager = stateManager;
    m_displayObjects = displayObjects;

    try {
      m_userId = Long.valueOf(stateManager.getUserInfo().getUserOid());
    } catch (Exception e) {
      LogHelper.warn("SapientHelper cannot find user oid from session user info.");
    }

    m_schedule_manager = new ScheduleManager(m_userId);
  }

  public SapientHelper(PageContext pc)
  {
    this(new VerizonStateManager((HttpServletRequest)pc.getRequest()),
         getDisplayObjects(pc));
  }

  public SapientHelper(HttpServletRequest request)
  {
    this(new VerizonStateManager(request),
         getDisplayObjects(request));
  }

  private static DisplayObjects getDisplayObjects(PageContext pc) {
    DisplayObjects d
        = (DisplayObjects)pc.getAttribute(JspPage.DISPLAY_OBJECTS_PAGE_ATTRIBUTE_NAME);
    if (null == d) {
      d = new DisplayObjects();
      pc.setAttribute(JspPage.DISPLAY_OBJECTS_PAGE_ATTRIBUTE_NAME, d);
    }
    return d;
  }

  private static DisplayObjects getDisplayObjects(HttpServletRequest req) {
   DisplayObjects d
       = (DisplayObjects)req.getAttribute(DisplayObjects.REQUEST_ATTRIBUTE_NAME);
   if (null == d) {
     d = new DisplayObjects();
     req.setAttribute(DisplayObjects.REQUEST_ATTRIBUTE_NAME, d);
   }
   return d;
 }

  public void scheduleUIJob(String taskname, IVpsInteractiveTask task)
      throws com.verizon.enterprise.vps.dataobjects.VpsException
  {
    Long taskid = scheduleUIJob(task);
    m_displayObjects.put(taskname, taskid);
  }

  public TimeoutTaskListener getTimeoutListener(String taskname)
  {
    Long taskid = (Long) m_displayObjects.get(taskname);
    if (null == taskid)
      return null;
    else
      return (TimeoutTaskListener) m_state_manager.getAPMSession().get(taskid);
  }

  public Long scheduleUIJob(IVpsInteractiveTask task)
      throws com.verizon.enterprise.vps.dataobjects.VpsException
  {
    TimeoutTaskListener listener = new TimeoutTaskListener();
    Long taskid = m_schedule_manager.scheduleUIJob(task, listener);
    //no need ip address so session replication won't mess up, since Hashtable is not replicatable.
    m_state_manager.getAPMSession().put(taskid, listener);
    return taskid;
  }

  public TimeoutTaskListener getTimeoutListener(Long taskid)
  {
    return (TimeoutTaskListener) m_state_manager.getAPMSession().get(taskid);
  }

}


