package com.verizon.enterprise.vps.ui.datalayer;

import java.util.*;
import java.sql.Timestamp;
import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.enterprise.vps.ui.dataobjects.TaskInstance;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.kernel.exception.DatalayerException;
import com.verizon.kernel.jdbc.ConnectionInterface;
import org.apache.log4j.Logger;

import com.verizon.kernel.jdbc.CursorResult;
import com.verizon.kernel.jdbc.CursorId;

public class TaskInstanceTableAccess {

    private static Logger logger = Logger.getLogger(TaskInstanceTableAccess.class);

    public TaskInstanceTableAccess () {
    }

    public TaskInstance getTaskInstanceByOid(String oid) throws Exception{
	final String METHOD_NAME = "TaskInstanceTableAccess:getTaskInstanceByOid(String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("oid: " + oid);
	TaskInstance task = null;

	try {
	    Long OID = new Long (oid);
	    TaskInstanceObject tio = TaskInstanceTable.retrieve(OID);
	    task = this.populateTaskInstance(tio);
	    logger.debug ("task_instance, oid = " + oid + ", successfully retrieved from task_instance table.");
	}
	catch (DatalayerException dle) {
	    logger.error (METHOD_NAME + " DatalayerException " + dle.getMessage());
	    logger.error (Util.getStackTrace(dle));
	    throw new Exception (dle.getMessage());
	}
	catch (Exception e) {
	    logger.error (METHOD_NAME + " Exception " + e.getMessage());
	    logger.error (Util.getStackTrace(e));
	    throw new Exception(e.getMessage());
	}

	logger.debug("EXIT: " + METHOD_NAME);
	return task;
    }

    public List getInstancesByDefOidWithPagination(String condition,
						   CursorId cursor) throws Exception {
	final String METHOD_NAME = "TaskInstanceTableAccess:getInstancesByDefOidWithPagination(String, CursorId)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("condition: " + condition);
	logger.debug("cursor: " + cursor);

	ArrayList instances = null;
	Iterator iterator = null;
	TaskInstanceObject taskInstanceObject = null;
	TaskInstance taskInstance = null;
        //ConnectionInterface conn = DbHelper.getConnection();

	if (cursor != null) {
            // Temporary soluation before datalayer's cursor is fixed
            List list = this.getTaskInstancesBySearchCondition (condition);
            cursor.setTotalRows(list.size());
            if (list != null) {
                iterator = list.iterator();
                for (int i=1; i<cursor.getPosition(); i++) iterator.next();
            }
            /* real cursor call
	    CursorResult result = TaskInstanceTable.searchByCursor(condition, cursor);
	    cursor = result.getCursor();
	    Collection objects = result.getObjects();
	    if (objects != null) {
		iterator = objects.iterator();
	    }
                */
	}
	else {
	    List list = this.getTaskInstancesBySearchCondition (condition);
	    if (list != null)
		iterator = list.iterator();
	}

	if (iterator != null) {
	    instances = new ArrayList();
	    while (iterator.hasNext()) {
		taskInstanceObject = (TaskInstanceObject)iterator.next();
		taskInstance = this.populateTaskInstance(taskInstanceObject);
		instances.add(taskInstance);
	    }
	}
	else {
	    instances = new ArrayList ();
	}

	logger.debug("retrived back " +instances.size() + "TaskInstance objects.");
	logger.debug("EXIT: " + METHOD_NAME);
	return instances;
    }

    public List getInstancesByDefOid(String oid) throws Exception{
	final String METHOD_NAME = "TaskInstanceTableAccess:getInstancesByDefOid(String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("oid: " + oid);
	List returnList = new ArrayList();

	Long OID = new Long (oid);
	TaskInstance task = null;
	TaskInstanceObject tio = null;
	List list = this.getTaskInstancesBySearchCondition("where job_ref_oid = " + oid + " order by start_time DESC");
	if (list !=null) {
	    int size = list.size();
	    for (int i=0; i<size; i++) {
		tio = (TaskInstanceObject)list.get(i);
		if(tio != null) {
		    task = this.populateTaskInstance(tio);
		    returnList.add(task);
		}
	    }
	    logger.debug (size + " task_instances are successfully retrieved from task_instance table" +
			  " with job_ref_oid = " + oid);
	}

	logger.debug("EXIT: " + METHOD_NAME);
	return returnList;
    }

    public List getTaskInstancesBySearchCondition (String condition) throws Exception {

	final String METHOD_NAME = "TaskInstanceTableAccess:getTaskInstancesBySearchCondition(String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("condition: " + condition);
	List list = null;
	try {
	    list = TaskInstanceTable.search(condition);
	}
	catch (DatalayerException dle) {
	    logger.error (METHOD_NAME + " DatalayerException " + dle.getMessage());
	    logger.error (Util.getStackTrace(dle));
	    throw new Exception (dle.getMessage());
	}
	catch (Exception e) {
	    logger.error (METHOD_NAME + " Exception " + e.getMessage());
	    logger.error (Util.getStackTrace(e));
	    throw new Exception(e.getMessage());
	}
	logger.debug("EXIT: " + METHOD_NAME);
	return list;
    }

    private TaskInstance populateTaskInstance(TaskInstanceObject tio) {
	String taskInstaceOid = tio.getTaskInstanceOid().toString();
	String status = tio.getStatus();
	String startTime = Util.convertTimestampToUIStd(tio.getStartTime());
	String endTime = Util.convertTimestampToUIStd(tio.getEndTime());
	String message = tio.getMessage();
	String jobRefCid = tio.getJobRefCid()==null? null:tio.getJobRefCid().toString();
	String jobRefOid = tio.getJobRefOid()==null? null:tio.getJobRefOid().toString();
	String timestamp = Util.convertTimestampToUIStd(tio.getTimestamp());
	String userOid = tio.getUserId().toString();

	TaskInstance instance = new TaskInstance (taskInstaceOid, status, startTime,
						  endTime, message, jobRefCid,
						  jobRefOid, timestamp, userOid);
	return instance;
    }

    public static void cursorTest (int pageSize, int pageNumber,
				   int action, String condition) throws Exception{
	CursorId myCursor = Util.getNewCursorId (pageSize);
	myCursor.setPosition (pageSize*pageNumber+1);
	System.out.println (myCursor.getCursorId());
	TaskInstanceTableAccess ti = new TaskInstanceTableAccess();
	List list = ti.getInstancesByDefOidWithPagination(condition, myCursor);

	log (myCursor, list);

	System.out.println ("starting the second....");
	myCursor.setPageSize(40);
	myCursor.setPageNumber(1);
	myCursor.setAction(CursorId.GOTO_PAGE);
	list = ti.getInstancesByDefOidWithPagination(condition, myCursor);

	log (myCursor, list);
    }

    public static void log (CursorId returnedCursor, Collection objects){
	System.out.println ("Returned cursor with id = " + returnedCursor.getCursorId());
	System.out.println ("Total number of rows = " + returnedCursor.getTotalRows());
	System.out.println ("Current page number = " + returnedCursor.getPageNumber());
	System.out.println ("Current position = " + returnedCursor.getPosition());
	System.out.println ("Returned number of objects = " + objects.size());

	Iterator iterator = objects.iterator();

	while (iterator.hasNext()) {
	    Object object = iterator.next();

	    if (object instanceof TaskInstance)
		System.out.println (((TaskInstance)object).getStartTime());
	    else
		System.out.println ("Return object is NOT type of TaskInstanceObject..");
	}

	System.out.println ("-------------------------------------------------");
    }

    public static void main (String[] args) throws Exception {

	String condition = "where job_ref_oid = 24398 order by start_time DESC";
	TaskInstanceTableAccess.cursorTest(10, 1, CursorId.GOTO_PAGE, condition);
    }
}





