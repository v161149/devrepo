package com.verizon.enterprise.vps.ui.dataobjects;

import java.util.TimeZone;

import com.verizon.enterprise.vps.ui.helper.Util;

public class PendingTask {

  private String pendingTaskOid;
  private String status;
  private String executeTime;
  private String taskInfo;
  private String retryCounter;
  private String jobScheduleDefOid;
  private String userId;
  private String timestamp;
  //private String uiStatus;

  public PendingTask() {
  }

  public PendingTask(String oid) {
    this.pendingTaskOid = oid;
  }

  public PendingTask(String pendingTaskOid, String status, String executeTime, String taskInfo, String retryCounter, String jobScheduleDefOid,
      String timestamp, String userOid) {
    this.setPendingTaskOid(pendingTaskOid);
    this.setStatus(status);
    TimeZone.setDefault(TimeZone.getTimeZone("US/Eastern"));
    System.setProperty("user.timezone", "US/Eastern");
    this.setExecuteTime(executeTime);
    this.setTaskInfo(taskInfo);
    this.setRetryCounter(retryCounter);
    this.setJobScheduleDefOid(jobScheduleDefOid);
    this.setTimestamp(timestamp);
    this.setUserId(userOid);
  }

  public void setPendingTaskOid(String oid) {
    this.pendingTaskOid = oid;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public void setExecuteTime(String executeTime) {
    this.executeTime = executeTime;
  }

  public void setTaskInfo(String taskInfo) {
    this.taskInfo = taskInfo;
  }

  public void setRetryCounter(String retryCounter) {
    this.retryCounter = retryCounter;
  }

  public void setJobScheduleDefOid(String jobScheduleDefOid) {
    this.jobScheduleDefOid = jobScheduleDefOid;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public String getPendingTaskOid() {
    return pendingTaskOid;
  }

  public String getStatus() {
    return status;
  }

  public String getExecuteTime() {
    return executeTime;
  }

  public String getTaskInfo() {
    return taskInfo;
  }

  public String getRetryCounter() {
    return retryCounter;
  }

  public String getJobScheduleDefOid() {
    return jobScheduleDefOid;
  }

  public String getUserId() {
    return userId;
  }

  public String getTimestamp() {
    return timestamp;
  }

  public String getUiStatus() {
    return Util.convertStatusToUIFormat(this.getStatus());
  }
}
