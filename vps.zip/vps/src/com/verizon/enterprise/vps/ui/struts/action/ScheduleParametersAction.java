package com.verizon.enterprise.vps.ui.struts.action;

import java.util.Date;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.ui.struts.action.ActionHelper;

public class ScheduleParametersAction extends Action {

    private static Logger logger = Logger.getLogger(ScheduleParametersAction.class);
    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse) throws Exception{
	final String METHOD_NAME = "ScheduleParametersAction:execute()";
	logger.debug("ENTER: " + METHOD_NAME );

	JobScheduleDef jobScheduleDef = (JobScheduleDef)aForm;
	HttpSession session = aRequest.getSession();
	session.setAttribute ("scheduleDef", jobScheduleDef);
	session.removeAttribute("vpsCreateErrors");

	ActionForward forward = ActionHelper.findForwardBasedOnPermission (aRequest,
									   aMapping.findForward("success"),
									   aMapping.findForward("noPermission"));
	logger.debug ("EXIT: " + METHOD_NAME);
        return forward;
    }
}



