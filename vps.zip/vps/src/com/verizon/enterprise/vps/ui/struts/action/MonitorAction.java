package com.verizon.enterprise.vps.ui.struts.action;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import javax.management.AttributeList;
import javax.management.Attribute;

import com.verizon.enterprise.vps.ui.struts.form.MonitorForm;
import com.verizon.enterprise.vps.ui.dataobjects.MonitorSummary;
import com.verizon.enterprise.vps.ui.dataobjects.MonitorTaskItem;
import com.verizon.enterprise.vps.core.TaskTrackingObject;
import com.verizon.enterprise.vps.jmx.VpsRuntime;
import com.verizon.enterprise.vps.jmx.VpsRuntimeMBean;
import com.verizon.enterprise.vps.collector.MonitorTransientDataCollector;
import com.verizon.enterprise.vps.collector.MonitorPersistentDataCollector;
import com.verizon.enterprise.vps.ui.struts.action.ActionHelper;

import org.apache.log4j.Logger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MonitorAction extends Action
{
    private static Logger log = Logger.getLogger(MonitorAction.class);
    String DEFAULT_ENVIRONMENT = "Transient";
    SimpleDateFormat dateFormater
        = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss.zzz");

    MonitorSummary summary;
    Collection history;
    Collection current;

    public ActionForward execute(ActionMapping aMapping,
                                 ActionForm aForm,
                                 HttpServletRequest aRequest,
                                 HttpServletResponse aResponse)
        throws Exception
    {
        final String METHOD_NAME = "execute()";
        log.debug("ENTER: " + METHOD_NAME);
        MonitorForm form = (MonitorForm) aForm;

        String link = form.getLinkClicked();
        if (link == null || link.trim().length() == 0)
            link = DEFAULT_ENVIRONMENT;
        log.info("linkClicked = " + link);

        HttpSession session = aRequest.getSession();

        session.setAttribute("page", form);
        if ("Transient".equals(link))
            getTransientData();
        else if ("Persistent".equals(link))
            getPersistentData();

        summary.setEnvironment(link);
        session.setAttribute("summary", summary);
        session.setAttribute("history", history);
        session.setAttribute("current", current);

        log.debug("EXIT: " + METHOD_NAME);

	ActionForward forward = ActionHelper.findForwardBasedOnPermission (aRequest,
									   aMapping.findForward("detail"),
									   aMapping.findForward("noPermission"));
        return forward;
    }

    MonitorSummary getSummary(String link)
    {
        MonitorSummary summary = new MonitorSummary();
        summary.setEnvironment(link);
        summary.setStatus("waiting");
        summary.setFinishedTaskCount("250");
        log.info("summary = \n" + summary);

        return summary;
    }

    Collection getHistory(String link)
    {
        Collection history = new ArrayList();
        MonitorTaskItem task = new MonitorTaskItem();

        task.setScheduleEnd(Calendar.getInstance().getTime().toString());
        task.setStartTime(dateFormater.format(Calendar.getInstance().getTime()));
        task.setEndTime(dateFormater.format(Calendar.getInstance().getTime()));
        task.setStatus("F");
        task.setJobId("100");
        history.add(task);

        task = new MonitorTaskItem();
        task.setScheduleEnd(Calendar.getInstance().getTime().toString());
        task.setStartTime(dateFormater.format(Calendar.getInstance().getTime()));
        task.setEndTime(dateFormater.format(Calendar.getInstance().getTime()));
        task.setStatus("L");
        task.setJobId("200");
        history.add(task);

        task = new MonitorTaskItem();
        task.setScheduleEnd(Calendar.getInstance().getTime().toString());
        task.setStartTime(dateFormater.format(Calendar.getInstance().getTime()));
        task.setEndTime(dateFormater.format(Calendar.getInstance().getTime()));
        task.setStatus("L");
        task.setJobId("300");
        history.add(task);

        return history;
    }

    Collection getCurrent(String link)
    {
        Collection current = new ArrayList();
        MonitorTaskItem task = new MonitorTaskItem();

        task.setStartTime(Calendar.getInstance().getTime().toString());
        task.setJobId("400");
        current.add(task);

        task = new MonitorTaskItem();
        task.setStartTime(Calendar.getInstance().getTime().toString());
        task.setJobId("500");
        current.add(task);

        return current;
    }

    void init()
    {
        if (summary == null)
            summary = new MonitorSummary();
        history = new ArrayList();
        current = new ArrayList();
    }

    void getTransientData() throws Exception
    {
        log.info("init");
        init();
        MonitorTaskItem task;

        AttributeList list = MonitorTransientDataCollector.getData(null);
        log.info("JMX getting attributes");
        log.info("summary = " + summary);

        Iterator iter = list.iterator();
        while (iter.hasNext())
        {
            Attribute attr = (Attribute) iter.next();
            log.info("name = " + attr.getName() + ", value = " + attr.getValue());
            if (attr.getName().equals(MonitorTransientDataCollector.attrNames[0]))
            {
                if (attr.getValue() != null)
                    summary.setStatus(attr.getValue().toString());
            }
            else if (attr.getName().equals(MonitorTransientDataCollector.attrNames[1]))
            {
                if (attr.getValue() != null)
                    summary.setPendingTaskCount(attr.getValue().toString());
            }
            else if (attr.getName().equals(MonitorTransientDataCollector.attrNames[2]))
            {
                if (attr.getValue() != null)
                    summary.setRunningTaskCount(attr.getValue().toString());
            }
            else if (attr.getName().equals(MonitorTransientDataCollector.attrNames[3]))
            {
                if (attr.getValue() != null)
                    summary.setFinishedTaskCount(attr.getValue().toString());
            }
            else if (attr.getName().equals(MonitorTransientDataCollector.attrNames[4]))
            {
                log.info("JMX got TaskHistory attribute");
                TaskTrackingObject[] tto = (TaskTrackingObject[]) attr.getValue();
                log.info("JMX got " + tto.length + " TaskHistory attribute");
                if (tto != null)
                {
                    for (int i = 0; i < tto.length; i++)
                    {
                        task = new MonitorTaskItem(tto[i]);
                        history.add(task);
                    }
                }
            }
            else if (attr.getName().equals(MonitorTransientDataCollector.attrNames[5]))
            {
                log.info("JMX got CurrentTask attribute");
                TaskTrackingObject[] tto = (TaskTrackingObject[]) attr.getValue();
                log.info("JMX got " + tto.length + " CurrentTask attribute");
                if (tto != null)
                {
                    for (int i = 0; i < tto.length; i++)
                    {
                        task = new MonitorTaskItem(tto[i]);
                        current.add(task);
                    }
                }
            }
        }
    }

    void getPersistentData() throws Exception
    {
        summary = MonitorPersistentDataCollector.getSummary();
        history = MonitorPersistentDataCollector.getHistory(-1);
        current = MonitorPersistentDataCollector.getCurrent(-1);
    }
}
