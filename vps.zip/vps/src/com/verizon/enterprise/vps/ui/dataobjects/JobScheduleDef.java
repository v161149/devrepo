package com.verizon.enterprise.vps.ui.dataobjects;

import java.util.Date;
import java.sql.Timestamp;
import java.io.*;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.ScheduleParser;
import org.apache.struts.action.ActionForm;
import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import org.jdom.Element;
import com.verizon.kernel.xml.XmlHelper;
import com.verizon.kernel.xml.XmlHelperException;

public class JobScheduleDef extends ActionForm {

    private String jobScheduleDefOid;
    private String name;
    private String scheduleInfo;
    private String taskInfo;
    private String description;
    private String effectiveStartTime;
    private String effectiveStopTime;
    private String userId;
    private String timestamp;
    private String uiScheduleInfo;
    private String status;

    public JobScheduleDef () {
    }

    public JobScheduleDef (String oid, String name, 
			   String taskInfo) {
	this.name = name;
	this.jobScheduleDefOid = oid;
	this.taskInfo = taskInfo;
    }

    public JobScheduleDef (String oid, 
			   String name, 
			   String scheduleInfo, 
			   String taskInfo,
			   String description, 
			   String effectiveStartTime, 
			   String effectiveEndTime, 
			   String userId, 
			   String timestamp, 
			   String status) {

	this.setJobScheduleDefOid(oid);
	this.setName(name);
	this.setScheduleInfo(scheduleInfo);
	this.setTaskInfo(taskInfo);
	this.setDescription(description);
	this.setEffectiveStartTime(effectiveStartTime);
	this.setEffectiveStopTime(effectiveEndTime);
	this.setUserId(userId);
	this.setTimestamp(timestamp);
	this.setStatus(status);
    }

    public void setJobScheduleDefOid(String jobScheduleDefOid) {
	this.jobScheduleDefOid = jobScheduleDefOid;
    }

    public void setName(String name) {
	this.name = name;
    }

    public void setScheduleInfo(String scheduleInfo) {
	this.scheduleInfo = scheduleInfo;
    }

    public void setTaskInfo (String taskInfo) {
	this.taskInfo = taskInfo;
    }

    public void setDescription (String description) {
	this.description = description;
    }

    public void setEffectiveStartTime(String effectiveStartTime) {
	this.effectiveStartTime = effectiveStartTime;
    }

    public void setEffectiveStopTime(String effectiveEndTime) {
	this.effectiveStopTime = effectiveEndTime;
    }
    
    public void setUserId (String userId) {
	this.userId = userId;
    }

    public void setTimestamp (String timestamp) {
	this.timestamp = timestamp;
    }

    public void setStatus (String status) {
	if (status == null || status.trim().length() == 0)
	    this.status = VpsConstants.JOB_SCHEDULE_DEF_ACTIVE;
	else
	    this.status = status;
    }

    public String getJobScheduleDefOid() {
	return jobScheduleDefOid;
    }

    public String getName() {
	return name;
    }

    public String getScheduleInfo () {
	return scheduleInfo;
    }

    public String getTaskInfo() {
	return taskInfo;
    }

    public String getDescription () {
	return description;
    }

    public String getEffectiveStartTime() {
	return effectiveStartTime;
    }

    public String getEffectiveStopTime() {
	return effectiveStopTime;
    }

    public String getUserId () {
	return userId;
    }

    public String getTimestamp() {
	return timestamp;
    }

    public String getStatus() {
	return status;
    }

    public String getUiTaskInfoTXAR (){
	XmlHelper helper = new XmlHelper();
	Element root = helper.parse(taskInfo);
	taskInfo = helper.toString(true, root);
	return taskInfo;
    }

    public String getUiTaskInfo() throws IOException{

	XmlHelper helper = new XmlHelper();
	Element root = helper.parse(taskInfo);
	taskInfo = helper.toString(true, root);
	int indentationSize = 4;
	int lineSize = 40;	
	Reader stringReader = new StringReader(taskInfo);
	BufferedReader br = new BufferedReader(stringReader);
	StringBuffer sb = new StringBuffer();
	String temp = br.readLine();

	while (temp!= null) {

	    if (temp.length() > lineSize) {
		do {
		    sb.append(temp.substring(0, lineSize));
		    sb.append('\n');
		    temp = temp.substring (lineSize);
		}
		while (temp.length() > lineSize);
		sb.append(temp);
	    }
	    else {
		sb.append(temp);
	    }
	    sb.append('\n');	    
	    temp = br.readLine();
	}

	return sb.toString().trim();
    }


    public String getUiScheduleInfo () {
	String returnString = null;
	try {
	    ISchedule iSchedule = ScheduleParser.parseSchedule(this.scheduleInfo);
	    returnString = iSchedule.toString();
	}
	catch (Exception e) {
	    Util.getStackTrace(e);
	    returnString = "N/A";
	}
	return returnString;
    }

    public String getUIStatus() {

	if (status.equals(VpsConstants.JOB_SCHEDULE_DEF_ACTIVE))
	    return "Active";
	else
	    return "Inactive";
    }

    public JobScheduleDefObject getJobScheduleDefObject() throws Exception{

	JobScheduleDefObject jsdo = new JobScheduleDefObject();
	
	if (this.jobScheduleDefOid != null)
	    jsdo.setJobScheduleDefOid(Long.valueOf(this.jobScheduleDefOid));
	jsdo.setName(this.name);
	jsdo.setScheduleInfo(this.scheduleInfo);
	jsdo.setDescription(this.description);
	jsdo.setTaskInfo(this.taskInfo);
	jsdo.setStatus(this.status);
	jsdo.setUserId(this.userId==null||this.userId.trim().length()==0 ? Long.valueOf("0"):Long.valueOf(this.userId));

	if (this.effectiveStartTime != null 
	    && this.effectiveStartTime.trim().length()!=0){
	    Date startTime = Util.convertToDateObject(this.effectiveStartTime);
	    Timestamp ts = new Timestamp(startTime.getTime());
	    jsdo.setEffectiveStartTime(ts);
	}

	if (this.effectiveStopTime != null
	    && this.effectiveStopTime.trim().length() != 0) {
	    Date stopTime = Util.convertToDateObject(this.effectiveStopTime);
	    Timestamp ts = new Timestamp(stopTime.getTime());
	    jsdo.setEffectiveStopTime (ts);
	}
	
	if (this.timestamp != null
	    && this.timestamp.trim().length() != 0) {
	    Date stamp = Util.convertToDateObject(this.timestamp);
	    Timestamp ts = new Timestamp(stamp.getTime());
	    jsdo.setTimestamp(ts);
	}
	    
	return jsdo;
    }

}


