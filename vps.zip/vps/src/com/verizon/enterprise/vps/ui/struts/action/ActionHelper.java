package com.verizon.enterprise.vps.ui.struts.action;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForward;

import com.verizon.ejb.wisegate.dispatcher.dispatchManager;
import com.verizon.enterprise.common.VerizonStateManager;
import com.verizon.enterprise.common.util.ECPWrapper;
import com.verizon.enterprise.dataobjects.SessionUserInfo;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.ScheduleParser;
import com.verizon.enterprise.vps.ui.datalayer.JobScheduleDefTableAccess;
import com.verizon.enterprise.vps.ui.helper.DataValidator;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.wisegate.middleware.dispatcher.DispatchManager;
import com.verizon.kernel.config.Config;


public class ActionHelper {

    private static Logger logger = Logger.getLogger(ActionHelper.class);
    private static final String CONFIG_PREFIX = "vps.vps";

    /** It finds user oid thru http servlet request first. Then it finds permission based on the user oid.
     *  It return ActionForward based on permission. If any exception is thrown, it returns forwardWOP.
     * @param request    HttpServletRequest
     * @param forwardWP  ActionForward when a user has permission
     * @param forwardWOP ActionFormward when a user doesn't have permission
     */
    public static ActionForward findForwardBasedOnPermission(HttpServletRequest request,
							     ActionForward forwardWP,
							     ActionForward forwardWOP) {
	final String METHOD_NAME = "ActionHelper:findForwardBasedOnPermission()";
	ActionForward forward = null;
	try {
	    String userOid = ActionHelper.getUserOidFromRequest(request);
	    if (ActionHelper.getUserPermissions(userOid, request).equals(VpsConstants.USER_PERMISSION_NONE))
		forward = forwardWOP;
	    else{
		HttpSession session = request.getSession(true);
		session.removeAttribute ("superuser");
		if (ActionHelper.getUserPermissions(userOid, request).equals(VpsConstants.USER_PERMISSION_ALL)){
		    session.setAttribute ("superuser", VpsConstants.DUMMY);
		}
		forward = forwardWP;
	    }
	}
	catch (Exception e) {
	    logger.error(METHOD_NAME + " " + Util.getStackTrace(e));
	    forward = forwardWOP;
	}
	return forward;
    }


    public static String getUserPermissions(String userOid, HttpServletRequest request) {
        String managers = null;
        String superusers = null;
        try {
            boolean flag = true;
            try {
                Class adminPageAccessUtilClass = Class.forName("com.verizon.enterprise.useradmin.util.AdminPageAccessUtil");
                Object obj = adminPageAccessUtilClass.newInstance();
                
                Class [] parameterTypes = {Class.forName("java.lang.String"), Class.forName("javax.servlet.http.HttpServletRequest")};
                Method checkAccess = adminPageAccessUtilClass.getMethod("checkAccess", parameterTypes);
                
                Object [] arguements = {VpsConstants.USER_PERMISSION_ID, request};
                flag = ((Boolean)checkAccess.invoke(obj, arguements)).booleanValue();
                
            } catch (Exception e) {
                logger.error(e.toString(), e);
                throw new Exception("class com.verizon.enterprise.useradmin.util.AdminPageAccessUtil not avaiable in JVM at runtime on APM server");
            }
            
            //AdminPageAccessUtil util = AdminPageAccessUtil(); 
            //boolean flag = util.checkAccess(VpsConstants.USER_PERMISSION_ID, request); 
            logger.debug (VpsConstants.USER_PERMISSION_ID + " : Access check returned :"+flag); 
            
            if (flag)
                managers = userOid;
            //managers = Config.getProperty(CONFIG_PREFIX, "vps.permissions.managers");
        }
        catch (Exception e) {
            logger.info ("unable to determine vps/apm access permission from user admin.");
        }
        
        try {
            superusers = Config.getProperty(CONFIG_PREFIX, "vps.permissions.superusers");
        }
        catch (Exception e) {
            logger.info ("unable to read vps superuser info from vps.xml");
        }
        
        StringTokenizer st = null;
        String temp;
        String permission = null;
        if(managers != null && managers.trim().length()>0 ) {
            managers = managers.trim();
            st = new StringTokenizer(managers, ",");
            
            while(st.hasMoreTokens()) {
                temp = ((String)st.nextToken()).trim();
                if (userOid.equals(temp)) {
                    permission =  VpsConstants.USER_PERMISSION_SELF;
                    break;
                }
            }
        }
        
        if (superusers != null && superusers.trim().length()>0) {
            superusers = superusers.trim();
            st = new StringTokenizer(superusers, ",");
            
            while(st.hasMoreTokens()){
                temp = ((String)st.nextToken()).trim();
                if(userOid.equals(temp)) {
                    permission = VpsConstants.USER_PERMISSION_ALL;
                    break;
                }
            }
        }
        
        if (permission == null)
            permission = VpsConstants.USER_PERMISSION_NONE;
        
        logger.info ("returning premission level:" + permission);
        return permission;
    }

    public static String getUserOidFromRequest (HttpServletRequest aRequest) 
	throws Exception {

	String METHOD_NAME = "ActionHelper.getUserOidFromRequest(HttpServletRequest)";
	String USER_LOGIN = null;
	String userOid = null;
	String name = null;
	
	VerizonStateManager stateManager = new VerizonStateManager(aRequest);

	try {
	    SessionUserInfo sessionUser = stateManager.getUserInfo();

	    if(sessionUser != null){
		//String firstName = sessionUser.getFirstName();
		//String lastName =  sessionUser.getLastName();
		USER_LOGIN = sessionUser.getLoginId();
		dispatchManager requestWG = new dispatchManager();
		Object result = null;
		result = DispatchManager.getUserSession ( USER_LOGIN );
		userOid = ECPWrapper.getUserOidFromLdap(USER_LOGIN, requestWG, (String)result);
		logger.info(METHOD_NAME + " userOid = " + userOid); 
	    }
	}
	catch ( Exception e ) {
	    logger.error(Util.getStackTrace(e));
	    throw new Exception ("Unable to get user oid information from http servlet request.");
	}

	return userOid;
    }

    public static void newJobScheduleDelegate (String name,
					       String taskInfo, 
					       String scheduleInfo, 
					       Date effectiveStartTime,
					       Date effectiveStopTime,
					       String userOid) throws Exception {

	DataValidator.nameInfoValidate (name);
	DataValidator.taskInfoValidate (taskInfo);
	DataValidator.scheduleInfoValidate (scheduleInfo);

	XmlPersistentTask xpt = new XmlPersistentTask(taskInfo);
	ISchedule schedule = ScheduleParser.parseSchedule(scheduleInfo);
	schedule.setName(name);
	if (effectiveStartTime != null)
	    schedule.setStartEffectiveTime(effectiveStartTime);
	if (effectiveStopTime != null)
	    schedule.setEndEffectiveTime(effectiveStopTime);

	JobScheduleDefTableAccess jAccess = new JobScheduleDefTableAccess();
	jAccess.createJobScheduleDef (xpt, schedule, userOid);
    }
}



