package com.verizon.enterprise.vps.ui.struts.action;

import java.util.Enumeration;
import java.sql.Timestamp;
import java.util.List;
import java.util.ArrayList;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.verizon.enterprise.vps.ui.struts.form.ClassParameterForm;
import org.apache.log4j.Logger;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.helper.Util;
import java.lang.reflect.Method;

public class ReflectAction extends Action {
    private static Logger logger = Logger.getLogger(ReflectAction.class);

    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse){
	final String METHOD_NAME = "ReflectAction:execute()";
	logger.debug("ENTER: " + METHOD_NAME );

	ClassParameterForm cForm = (ClassParameterForm)aForm;
	HttpSession session = aRequest.getSession();
	session.setAttribute ("classMethodForm", cForm);
	session.removeAttribute("vpsCreateErrors");

	String methodName = null;
	String className = null;
	ActionForward forward = null;

	try {
	    className = cForm.getClassName();
	    methodName = cForm.getMethodName();

	    if (methodName == null || methodName.trim().length() == 0) {
		List methodNames = Util.getMethodNames(className);
		session.setAttribute ("methodNames", methodNames);
		forward = aMapping.findForward("origin");
	    }
	    else {
		session.removeAttribute ("methodNames");
		List methodArgs = Util.getMethodArgs(className,methodName);
		methodArgs = Util.beautifyMethodNamesForUI(methodArgs);
		session.setAttribute ("methodArgs", methodArgs);
		forward = aMapping.findForward("arguement");
	    }
	}
	catch (Exception e) {
	    e.printStackTrace();
	    session.removeAttribute ("methodNames");
	    forward = aMapping.findForward("origin");
	    logger.info("forwarding to \"origin\"...");
	}

	logger.debug("EXIT: " + METHOD_NAME );
        return forward;
    }
}



