package com.verizon.enterprise.vps.ui.helper;

import java.util.Random;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeModel;
import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeNode;
import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.ui.dataobjects.TaskInstance;
import com.verizon.enterprise.vps.ui.dataobjects.PendingTask;
import com.verizon.enterprise.vps.ui.datalayer.JobScheduleDefTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.TaskInstanceTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.PendingTaskTableAccess;
import com.verizon.enterprise.vps.ui.helper.Util;
import org.apache.log4j.Logger;
import com.verizon.kernel.jdbc.CursorId;

public class VpsTreeNodeHelper {
    private static Logger logger = Logger.getLogger(VpsTreeNodeHelper.class);
    
    public static List getChildNodeList(DefaultWTreeNode parent, 
					int              pagePosi, 
					int              pageSize, 
					CursorId         cursor,
					String           userOid,
					String           userPermission){
	List returnList = null;
	if (cursor != null) {
	    cursor.setPageSize(pageSize);
	    cursor.setPosition((long)pagePosi*pageSize+1);
	    cursor.setPageNumber(pagePosi+1);  //in temp tables, page starts with page 1
	                                       //in tree pagination, page starts with page 0
	    cursor.setAction(CursorId.GOTO_PAGE);
	}

	try {
	    if (parent.toString().equals("root")) {
 
		List sTypes = new ArrayList ();
		sTypes.add(VpsConstants.ONCE_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.FIXED_RATE_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.DAILY_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.WEEKLY_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.COMBINED_MONTHLY_SCHEDULE_PREFIX);
		
		List scheduleTypeNodes = VpsTreeNodeHelper.convertToNodes (sTypes);
		returnList = scheduleTypeNodes;
	    }
	    else {
		String oid = Util.getOid(parent.toString());

		if (oid.equals(VpsConstants.DUMMY)){
		    String scheduleName = Util.getDisplayName(parent.toString());
		    StringBuffer condition = new StringBuffer();

		    if (scheduleName.equals(VpsConstants.COMBINED_MONTHLY_SCHEDULE_PREFIX)) {
			condition.append("where schedule_info like '");
			condition.append(VpsConstants.MONTHLY_NTH_DAY_SCHEDULE_PREFIX);
			condition.append("%' or schedule_info like '");
			condition.append(VpsConstants.MONTHLY_NTH_WEEKDAY_SCHEDULE_PREFIX);
			condition.append("%' ");
		    }
		    else if (scheduleName.equals(VpsConstants.FIXED_RATE_SCHEDULE_PREFIX)){
			condition.append("where schedule_info like '");
			condition.append(scheduleName.replace(' ', '_'));
			condition.append("%' ");
		    }
		    else {
			condition.append("where schedule_info like '");
			condition.append(scheduleName);
			condition.append("%' ");
		    }

		    if (userPermission.equals (VpsConstants.USER_PERMISSION_SELF)) {
			condition.append("and user_id = ");
			condition.append(userOid);
		    }

		    condition.append(" order by name");
			
		    JobScheduleDefTableAccess jsdTableAccess  = new JobScheduleDefTableAccess();
		    
		    List returnDefs = jsdTableAccess.getScheduleDefinitionsWithPagination(condition.toString(), cursor);
		    List defNodes = VpsTreeNodeHelper.convertToNodes (returnDefs);
		    returnList = defNodes;
		}
		else {
		    List instancesMix = new ArrayList();
		    TaskInstanceTableAccess tiTableAccess = new TaskInstanceTableAccess();
		    String condition = "where job_ref_oid = " + oid + " order by start_time DESC";
		    List instances = tiTableAccess.getInstancesByDefOidWithPagination(condition, cursor);

		    if (pagePosi == 0) {
			PendingTaskTableAccess ptTableAccess = new PendingTaskTableAccess();
			PendingTask pendingTask = ptTableAccess.getPendingTaskByJobScheduleDefOid(oid);
			if (pendingTask != null) {
			    instancesMix.add(pendingTask);
			    if (instances != null && !instances.isEmpty())
				instancesMix.addAll(instances);
			    int size = instancesMix.size();
			    if (size > pageSize)
				instancesMix.remove (size-1); //remove the last element
			}
			else {
			    if (instances != null && !instances.isEmpty())
				instancesMix.addAll(instances);
			}
		    }
		    else {
			boolean pendingTaskExist = VpsTreeNodeHelper.hasPendingTask (parent);
			if (pendingTaskExist) {
			    cursor.setAction(CursorId.PREVIOUS_PAGE);
			    List extra = tiTableAccess.getInstancesByDefOidWithPagination(condition, cursor);

			    if (extra != null && !extra.isEmpty()){
				int size = extra.size();
				Object lastElement = extra.get(size-1);
				
				instancesMix.add(lastElement);
				if (instances != null && !instances.isEmpty()) 
				    instancesMix.addAll(instances);
				
				size = instancesMix.size();
				if(size > pageSize)
				    instancesMix.remove(size-1); //remove the last element
			    }
			    else { //shall not occur
				if (instances != null && !instances.isEmpty())
				    instancesMix.addAll(instances);
			    }
			}
			else {
			    if (instances != null && !instances.isEmpty())
				instancesMix.addAll(instances);
			}
		    }
		    
		    List mixNodes = VpsTreeNodeHelper.convertToNodes (instancesMix);
		    returnList = mixNodes;
		}
	    }
	}
	catch (Exception e) {
	    logger.error (Util.getStackTrace(e));
	}
	return returnList;
    }

    /*
    public static List getChildNodeList(DefaultWTreeNode parent, 
					int              pagePosi, 
					int              pageSize, 
					CursorId         cursor){
	List returnList = null;
	if (cursor != null) {
	    cursor.setPageSize(pageSize);
	    cursor.setPosition((long)pagePosi*pageSize+1);
	    cursor.setPageNumber(pagePosi+1);  //in temp tables, page starts with page 1
	                                       //in tree pagination, page starts with page 0
	    cursor.setAction(CursorId.GOTO_PAGE);
	}

	try {
	    if (parent.toString().equals("root")) {

		List sTypes = new ArrayList ();
		sTypes.add(VpsConstants.ONCE_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.FIXED_RATE_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.DAILY_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.WEEKLY_SCHEDULE_PREFIX);
		sTypes.add(VpsConstants.COMBINED_MONTHLY_SCHEDULE_PREFIX);
		
		List scheduleTypeNodes = VpsTreeNodeHelper.convertToNodes (sTypes);
		returnList = scheduleTypeNodes;
	    }
	    else {
		String oid = Util.getOid(parent.toString());

		if (oid.equals(VpsConstants.DUMMY)){
		    String scheduleName = Util.getDisplayName(parent.toString());
		    StringBuffer condition = new StringBuffer();

		    if (scheduleName.equals(VpsConstants.COMBINED_MONTHLY_SCHEDULE_PREFIX)) {
			condition.append("where schedule_info like '");
			condition.append(VpsConstants.MONTHLY_NTH_DAY_SCHEDULE_PREFIX);
			condition.append("%' or schedule_info like '");
			condition.append(VpsConstants.MONTHLY_NTH_WEEKDAY_SCHEDULE_PREFIX);
			condition.append("%' order by name");
		    }
		    else if (scheduleName.equals(VpsConstants.FIXED_RATE_SCHEDULE_PREFIX)){
			condition.append("where schedule_info like '");
			condition.append(scheduleName.replace(' ', '_'));
			condition.append("%' order by name");
		    }
		    else {
			condition.append("where schedule_info like '");
			condition.append(scheduleName);
			condition.append("%' order by name");
		    }
			
		    JobScheduleDefTableAccess jsdTableAccess  = new JobScheduleDefTableAccess();
		    
		    List returnDefs = jsdTableAccess.getScheduleDefinitionsWithPagination(condition.toString(), cursor);
		    List defNodes = VpsTreeNodeHelper.convertToNodes (returnDefs);
		    returnList = defNodes;
		}
		else {
		    List instancesMix = new ArrayList();
		    TaskInstanceTableAccess tiTableAccess = new TaskInstanceTableAccess();
		    String condition = "where job_ref_oid = " + oid + " order by start_time DESC";
		    List instances = tiTableAccess.getInstancesByDefOidWithPagination(condition, cursor);

		    if (pagePosi == 0) {
			PendingTaskTableAccess ptTableAccess = new PendingTaskTableAccess();
			PendingTask pendingTask = ptTableAccess.getPendingTaskByJobScheduleDefOid(oid);
			if (pendingTask != null) {
			    instancesMix.add(pendingTask);
			    if (instances != null && !instances.isEmpty())
				instancesMix.addAll(instances);
			    int size = instancesMix.size();
			    if (size > pageSize)
				instancesMix.remove (size-1); //remove the last element
			}
			else {
			    if (instances != null && !instances.isEmpty())
				instancesMix.addAll(instances);
			}
		    }
		    else {
			boolean pendingTaskExist = VpsTreeNodeHelper.hasPendingTask (parent);
			if (pendingTaskExist) {
			    cursor.setAction(CursorId.PREVIOUS_PAGE);
			    List extra = tiTableAccess.getInstancesByDefOidWithPagination(condition, cursor);

			    if (extra != null && !extra.isEmpty()){
				int size = extra.size();
				Object lastElement = extra.get(size-1);
				
				instancesMix.add(lastElement);
				if (instances != null && !instances.isEmpty()) 
				    instancesMix.addAll(instances);
				
				size = instancesMix.size();
				if(size > pageSize)
				    instancesMix.remove(size-1); //remove the last element
			    }
			    else { //shall not occur
				if (instances != null && !instances.isEmpty())
				    instancesMix.addAll(instances);
			    }
			}
			else {
			    if (instances != null && !instances.isEmpty())
				instancesMix.addAll(instances);
			}
		    }
		    
		    List mixNodes = VpsTreeNodeHelper.convertToNodes (instancesMix);
		    returnList = mixNodes;
		}
	    }
	}
	catch (Exception e) {
	    logger.error (Util.getStackTrace(e));
	}
	return returnList;
    }
    */


    public static boolean hasPendingTask(DefaultWTreeNode parent) {
	boolean b = false;
	try {
	    if (parent.toString().equals("root")) {
	    }
	    else {
		String oid = Util.getOid(parent.toString());
		PendingTaskTableAccess ptTableAccess = new PendingTaskTableAccess();
		PendingTask pendingTask = ptTableAccess.getPendingTaskByJobScheduleDefOid(oid);
		if (pendingTask != null)
		    b = true;
	    }
	}
	catch (Exception e) {
	    logger.error (Util.getStackTrace(e));
	}
	return b;
    }

    //if stopPosi < 0, it will populate all children in the childList
    //startPosi, the starting position in the tree of child nodes 
    public static void populateNodeWithChild(DefaultWTreeNode parent, 
					     int startPosi, 
					     int stopPosi, 
					     List childList, 
					     int totalChildCount) {
	if (parent != null)
	    parent.setChildCount(totalChildCount);
	else
	    return;

	if (childList != null && !childList.isEmpty()) {
	    DefaultWTreeNode childNode = null;
	    Iterator childListIterator = childList.iterator();
	    int currentPosi = startPosi;

	    if (stopPosi >= 0)
		while (childListIterator.hasNext() && currentPosi <=stopPosi) {
		    childNode = (DefaultWTreeNode)childListIterator.next();
		    parent.setChildAt(childNode, currentPosi);
		    currentPosi++;
		}
	    else
		while (childListIterator.hasNext()) {
		    childNode = (DefaultWTreeNode)childListIterator.next();
		    parent.setChildAt(childNode, currentPosi);
		    currentPosi++;
		}
	}
    }

    //it converts the object list to DefaultWTreeNode list
    private static List convertToNodes (List objectList) {
	List nodeList = null;
	
	try {
	    if (objectList != null && !objectList.isEmpty()) {
		int size = objectList.size();
		Object object = null;
		DefaultWTreeNode treeNode = null;
		JobScheduleDef jobScheduleDef = null;
		TaskInstance taskInstance = null;
		PendingTask pendingTask = null;
		String scheduleType = null;

		nodeList = new ArrayList();

		for (int i=0; i<size; i++) {
		    object = objectList.get(i);
		    
		    if (object instanceof JobScheduleDef) {
			jobScheduleDef = (JobScheduleDef)object;
			treeNode = new DefaultWTreeNode(jobScheduleDef.getName()
							+ VpsConstants.DELIMITER + VpsConstants.DUMMY  //keep
							+ VpsConstants.DELIMITER + VpsConstants.SCHEDULE_DEFINITION_PREFIX
							+ VpsConstants.DELIMITER + jobScheduleDef.getJobScheduleDefOid());
		    }
		    else if (object instanceof TaskInstance) {
			taskInstance = (TaskInstance)object;
			treeNode = new DefaultWTreeNode(taskInstance.getStartTime() 
							+ VpsConstants.DELIMITER + taskInstance.getStatus()
							+ VpsConstants.DELIMITER + VpsConstants.TASK_INSTANCE_PREFIX
							+ VpsConstants.DELIMITER + taskInstance.getTaskInstanceOid(), false);
		    }
		    else if (object instanceof PendingTask) {
			pendingTask = (PendingTask)object;
			treeNode = new DefaultWTreeNode(pendingTask.getExecuteTime() 
							+ VpsConstants.DELIMITER + pendingTask.getStatus()
							+ VpsConstants.DELIMITER + VpsConstants.PENDING_TASK_PREFIX
							+ VpsConstants.DELIMITER + pendingTask.getPendingTaskOid(), false);
		    }
		    else if (object instanceof String) {
			scheduleType = (String)object;
			treeNode = new DefaultWTreeNode (scheduleType
							 + VpsConstants.DELIMITER + VpsConstants.DUMMY 
							 + VpsConstants.DELIMITER + VpsConstants.SCHEDULE_TYPE_PREFIX
							 + VpsConstants.DELIMITER + VpsConstants.DUMMY);
		    }
		    else {
			throw new Exception ("Unexpected Object type...");
		    }
		    nodeList.add(treeNode);
		}
	    }
	}
	catch (Exception e) {
	    logger.error (Util.getStackTrace(e));
	}
	return nodeList;
    }

}






