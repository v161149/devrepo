package com.verizon.enterprise.vps.ui.helper;

import com.verizon.enterprise.vps.schedule.ScheduleParser;

public class VpsConstants  { 
    public static final String DUMMY                      = "Dummy";
    public static final String TASK_INSTANCE_PREFIX       = "completedInstance";
    public static final String SCHEDULE_DEFINITION_PREFIX = "definition";
    public static final String PENDING_TASK_PREFIX        = "pendingTask";
    public static final String SCHEDULE_TYPE_PREFIX       = "scheduleType";
    public static final String DELIMITER                  = "$";
    public static final String TREE_MODEL_NAME_IN_SESSION = "ScheduleDefNInstanceTreeId";
    public static final String VPS_DATA_CURSOR            = "vpsDataCursors";

    public static final String FIXED_RATE_SCHEDULE_PREFIX          = ScheduleParser.PNAME_FIXED_RATE.replace('_', ' ');
    public static final String FIXED_RATE_SCHEDULE_PREFIX_BKEND    = ScheduleParser.PNAME_FIXED_RATE;

    public static final String ONCE_SCHEDULE_PREFIX                = ScheduleParser.PNAME_ONCE;
    public static final String DAILY_SCHEDULE_PREFIX               = ScheduleParser.PNAME_DAILY;
    public static final String WEEKLY_SCHEDULE_PREFIX              = ScheduleParser.PNAME_WEEKLY;
    public static final String MONTHLY_NTH_DAY_SCHEDULE_PREFIX     = ScheduleParser.PNAME_MONTHLY_NTH_DAY;
    public static final String MONTHLY_NTH_WEEKDAY_SCHEDULE_PREFIX = ScheduleParser.PNAME_MONTHLY_NTH_WEEKDAY;
    public static final String COMBINED_MONTHLY_SCHEDULE_PREFIX    = "MONTHLY";

    public static final String JOB_SCHEDULE_DEF_ACTIVE    = "A";
    public static final String JOB_SCHEDULE_DEF_IINACTIVE = "I";

    public static final String USER_PERMISSION_ALL  = "A";  //able to see everything
    public static final String USER_PERMISSION_SELF = "S";  //able to see self
    public static final String USER_PERMISSION_NONE = "N";  //unable to see anything
    public static final String USER_PERMISSION_ID   = "APMENDUSERADMIN";  //used by useradmin

    public static final String [] FRAMEWORKS             = {"sapient"};
    public static final String APM_SPIN_OFF_JS_FUNC_NAME = "APMSpinOffFunction";
    public static final String APM_SERVLET_PROTOCOL      = "http://";
    public static final String APM_SERVLET_PATH          = "/operations/preslet/apm.do";
    //http://salsa:9052/operations/preslet/apm.do

    //constant for scheduleing job sub page, describe the state of current page
    //and what action will perform next

    //ACTION_INIT state will display the clickable link to add a job and click the link send "ACTION_CLASSNAME" action
    public static final String ACTION_INIT = "action_init";

    //ACTION_CLASSNAME state display input field for class name, click submit send "ACTION_METHODNAME" action
    public static final String ACTION_CLASSNAME = "action_classname";

    //ACTION_METHODNAME state display input field for method name, click submit send "ACTION_PARAMLIST" action
    public static final String ACTION_METHODNAME = "action_methodname";

    //ACTION_PARAMLIST state display input field for each parameter, click submit send "ACTION_INIT" action
    public static final String ACTION_PARAMLIST = "action_paramlist";

    //ACTION_OSCOMMAND state display input field for OS Commands
    public static final String ACTION_OSCOMMAND = "action_oscommand";

    //ACTION_SUBMIT
    public static final String ACTION_SUBMIT = "action_submit";
    public static final String ACTION_SUBMITSCRIPT = "action_submitscript";
    public static final String ACTION_SUBMITCLASS = "action_submitclass";
    public static final String ACTION_SUBMITCOMMAND = "action_submitcommand";
    public static final String ACTION_ADDPARAM = "action_addparam";

    //ACTION_SCRIPT state will display the inputs for scripts
    public static final String ACTION_SCRIPT = "action_script";
}



