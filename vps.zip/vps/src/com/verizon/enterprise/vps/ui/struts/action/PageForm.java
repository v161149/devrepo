package com.verizon.enterprise.vps.ui.struts.action;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


/**
 * Form bean for the user profile page.
 * This form has the following fields,
 * with default values in square brackets:
 * <ul>
 * <li><b></b> - Entered password value
 * <li><b></b> - Entered username value
 * </ul>
 *
 * @author
 * @version 
 */
public final class PageForm extends ActionForm {

    private String linkClicked = null;
    private String jobScheduleDefOid;
    private String tempDisplayMessage = null;
    private String nodeName = null;


    public String getLinkClicked() {
	return linkClicked;
    }
    public String getJobScheduleDefOid() {
	return jobScheduleDefOid;
    }

    public void setLinkClicked(String linkClicked) {
	this.linkClicked = linkClicked;
    }
    public void setJobScheduleDefOid (String jobScheduleDefOid) {
	this.jobScheduleDefOid = jobScheduleDefOid;
    }
    

    public String getNodeName() {
	return (this.nodeName);
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getTempDisplayMessage() {
	return tempDisplayMessage;
    }

    public void setTempDisplayMessage(String tempDisplayMessage) {
	this.tempDisplayMessage = tempDisplayMessage;
    }

    /**
     * Reset all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping,
        HttpServletRequest request) {
        setNodeName(null);
	setLinkClicked (null);
    }


    /**
     * Ensure that both fields have been input.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    /*
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();

        if ((username == null) || (username.length() < 1))
            errors.add("username",
                new ActionError("error.username.required"));

        if ((password == null) || (password.length() < 1))
            errors.add("password",
                new ActionError("error.password.required"));

        return errors;

    }
    */
} // End LogonForm
