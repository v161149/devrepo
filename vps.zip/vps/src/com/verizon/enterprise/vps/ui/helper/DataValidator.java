package com.verizon.enterprise.vps.ui.helper;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

import com.verizon.kernel.xml.XmlWrapper;

public class DataValidator {

    public static boolean taskInfoValidate (String taskInfo) throws Exception {

	XmlWrapper xmlParser = new XmlWrapper ();
	xmlParser.parse (taskInfo);
	String rootName = xmlParser.getNodeName();

	if (rootName.equals ("exec")) {
	    String attributeValue = xmlParser.getAttributeValue("executable");
	    if (attributeValue.indexOf("/VZ/")!= 0)
		throw new Exception ("OS commands have to begin with \"/VZ/\".");

	    if (taskInfo.indexOf(";") > 0 
		|| taskInfo.indexOf("|") > 0
		|| taskInfo.indexOf("..") > 0)
		throw new Exception ("OS commands can not contain ; .. or |.");
	}
	
	return true;
    }

    public static boolean nameInfoValidate (String nameInfo) throws Exception {
	if (nameInfo.indexOf('|') > 0 || nameInfo.indexOf('$') > 0)
	    throw new Exception ("'$' and '|' can not be part of the name.");

	return true;
    }

    public static boolean scheduleInfoValidate (String scheduleInfo) throws Exception {
	
	boolean valid = true;

	if (scheduleInfo.indexOf(VpsConstants.FIXED_RATE_SCHEDULE_PREFIX_BKEND)>=0) {
	    String seconds = null;
	    try {
		seconds = scheduleInfo.substring (scheduleInfo.indexOf('|')+1);
		seconds = seconds.trim();
	    }
	    catch (Exception e) {
		throw new Exception ("Fixed rate misses time info.");
	    }

	    try {
		int s = Integer.parseInt(seconds);
		if ( s<60 )
		    valid = false;
	    }
	    catch (NumberFormatException nfe) {
		throw new Exception ("Fixed rate contains invalid time info. Check numbers.");
	    }
	}
	    
	if (!valid)
	    throw new Exception ("The time interval has to be longer than or equal to 1 minute in fixed rate schedule type.");

	return valid;

    }

}






