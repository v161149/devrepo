package com.verizon.enterprise.vps.ui.helper;

import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeCellRenderer;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;

public class LinkCellRenderer extends DefaultWTreeCellRenderer {
    /**
     * Web presentation of a node/cell icon in tree.
     * @param node Node to display
     * @param bSelected Whether node is selected
     * @param bExpanded Whether node is expanded
     * @param bLeaf Whether node is leaf node.
     * @param nRow Current row number, not used.
     * @return The string presenttation, usually in HTML, of node.
     */
    public String getIconDisplay(Object  objectNode,
                                 boolean bSelected,
                                 boolean bExpanded,
                                 boolean bLeaf,
                                 int     nRow) {
	String node = objectNode.toString();
	node = node.trim();
        StringBuffer sb = new StringBuffer();

	if (node.indexOf(VpsConstants.TASK_INSTANCE_PREFIX)>0 
	    ||node.indexOf(VpsConstants.PENDING_TASK_PREFIX)>0 ){

	    String status = Util.getTaskStatus(node);
	    if (status.equals(String.valueOf(IVpsTask.PHANTOM)) 
		|| status.equals(String.valueOf(IVpsTask.INITIAL)))
		sb.append("<IMG src='/operations/images/Artwork/page.gif'/>");
	    else if (status.equals(String.valueOf(IVpsTask.PENDING)))
		sb.append("<IMG src='/operations/images/Artwork/pending_BTN.gif'/>");
	    else if (status.equals(String.valueOf(IVpsTask.FINISHED)))
		sb.append("<IMG src='/operations/images/Artwork/rptsuccess.gif'/>");
	    else if (status.equals(String.valueOf(IVpsTask.FAILED)))
		sb.append("<IMG src='/operations/images/Artwork/rptfailure.gif'/>");
	    else if (status.equals(String.valueOf(IVpsTask.CANCELED)))
		sb.append("<IMG src='/operations/images/Artwork/noteOff.gif'/>");
	    else if (status.equals(String.valueOf(IVpsTask.EXECUTING)))
		sb.append("<IMG src='/operations/images/Artwork/noteOn.gif'/>");
	    else
		sb.append("<IMG src='/operations/images/Artwork/page.gif'/>");
	} else if (node.indexOf(VpsConstants.SCHEDULE_DEFINITION_PREFIX) > 0) {
	    sb.append("<IMG src='/operations/images/icnHd_orderPinnacle.gif'/>");
	} else {
	    if (bLeaf) {
		sb.append("<IMG src='/operations/images/Artwork/page.gif'/>");
	    }
	    else {
		sb.append("<IMG src='/operations/images/Artwork/"
			  + (bExpanded ? "folderopen.gif" : "folder.gif") + "'/>");
	    }
	}
        return sb.toString();
    }

    public String getNodeDisplay(Object objectNode,
                                 String sNodePath,
                                 boolean bSelected,
                                 boolean bExpanded,
                                 boolean bLeaf,
                                 int nRow) {
        StringBuffer sb = new StringBuffer();

	String node = objectNode.toString();
	node = node.trim();
	String displayNode = Util.getDisplayName(node);

	sb.append("<A class=\"subnavLink\" href=\"javascript:describeNode('");
	sb.append(node);
	sb.append("')\" onMouseOver=\"window.status='click to view detail';return true;\" ");
	sb.append("onMouseOut=\"window.status=''; return true;\">");
	sb.append(displayNode==null?"NULL":displayNode.toString());
	sb.append("</A>");

        return sb.toString();
    }

}






