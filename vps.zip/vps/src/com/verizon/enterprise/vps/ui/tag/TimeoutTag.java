package com.verizon.enterprise.vps.ui.tag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;

import org.apache.taglibs.standard.tag.common.core.ChooseTag;

import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class TimeoutTag extends ChooseTag
{
  private String m_taskName;
  private Long m_taskOid;
  private long m_timeout;

  private boolean m_bIsTimedOut;
  private boolean m_bIsTimedOutInitialized = false;

  public void setTaskName(String taskName) {
    m_taskName = taskName;
  }

  public String getTaskName() {
    return m_taskName;
  }

  public void setTaskOid(Long taskOid) {
    m_taskOid = taskOid;
  }

  public Long getTaskOid() {
    return m_taskOid;
  }

  public void setPeriod(int timeoutSeconds) {
    m_timeout = 1000 * timeoutSeconds;
  }

  public int getPeriod()
  {
    return (int) m_timeout/1000;
  }

  public int doStartTag() throws JspException
  {
    timeout();
    return super.doStartTag();
  }

  protected boolean isTimedOut() throws JspTagException {
    if (! m_bIsTimedOutInitialized) {
      m_bIsTimedOut = timeout();
    }
    return m_bIsTimedOut;
  }

  //this call will block until the timeout period
  private boolean timeout() throws JspTagException
  {
    TimeoutTaskListener listener = null;
    SapientHelper helper = new SapientHelper(pageContext);
    if (null != m_taskOid)
    {
      listener = helper.getTimeoutListener(m_taskOid);
    }
    else if (null != m_taskName)
    {
      listener = helper.getTimeoutListener(m_taskName);
    }
    if (listener == null)
    {
      throw new JspTagException("There is no task for taskName="
                                +m_taskName+"or taskId="+m_taskOid);
    }
    synchronized (listener)
    {
      long t = m_timeout - listener.getTimeExecuted();
      if (t<=0) {
        return true;      //timed out
      }
      else {
        try {
          listener.wait(t);   //block on the task
        }
        catch (java.lang.InterruptedException wakeup) {
        }
        return listener.isDone();
      }
    }
  }
}