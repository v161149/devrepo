package com.verizon.enterprise.vps.ui.struts.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MonitorForm extends ActionForm
{
    private String linkClicked = null;

    public String getLinkClicked() {
        return linkClicked;
    }

    public void setLinkClicked(String linkClicked) {
        this.linkClicked = linkClicked;
    }

    /**
     * Reset all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping,
                      HttpServletRequest request)
    {
        setLinkClicked(null);
    }
}