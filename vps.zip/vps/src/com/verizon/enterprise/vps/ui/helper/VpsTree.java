package com.verizon.enterprise.vps.ui.helper;

import java.util.Random;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import com.verizon.enterprise.preslet.tag.tree.WTree;
import com.verizon.enterprise.preslet.tag.tree.WTreeModel;
import com.verizon.enterprise.preslet.tag.tree.WTreeNode;
import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeModel;
import com.verizon.enterprise.preslet.tag.tree.DefaultWTreeNode;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.ui.dataobjects.TaskInstance;
import com.verizon.enterprise.vps.ui.dataobjects.PendingTask;
import com.verizon.enterprise.vps.ui.datalayer.JobScheduleDefTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.TaskInstanceTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.PendingTaskTableAccess;
import com.verizon.enterprise.vps.ui.helper.Util;
import org.apache.log4j.Logger;


public class VpsTree extends TreeModel  {
    private static Logger logger = Logger.getLogger(VpsTree.class);
    
    /** Constructor */
    public VpsTree() {
        final int NODE_PER_LEVEL = 20;

	//System.out.println("...in VpsTree()");
        // Build tree.
	// m_root = new DefaultWTreeNode("Node 0", true);
	m_root = new DefaultWTreeNode("root", true);
        int l1, l2;
        // Construct the first level children
	
	try {
	    DefaultWTreeNode nodeAtLevelOne = (DefaultWTreeNode)getRoot();
	    JobScheduleDefTableAccess jsdTableAccess  = new JobScheduleDefTableAccess ();
	    List allDef = jsdTableAccess.getAllScheduleDefinitions();
	    int defCount = allDef.size();
	    if (allDef != null)
		nodeAtLevelOne.setChildCount(defCount);
	    else
		nodeAtLevelOne.setChildCount(0);
	    
	    DefaultWTreeNode nodeAtLevelTwo, nodeAtLevelThree;
	    JobScheduleDef def = null;
	    int numberOfIns = 0;
	    int nextChildPosition = 0;
	    TaskInstanceTableAccess tiTableAccess = null;
	    PendingTaskTableAccess ptTableAccess = null;
	    List instances = null;
	    List instancesMix = null;
	    TaskInstance taskInstance = null;
	    PendingTask pendingTask = null;

	    for (l1=0; l1<defCount; l1++) {
		def = (JobScheduleDef)allDef.get(l1);
		nodeAtLevelTwo = new DefaultWTreeNode(def.getName()
						      + VpsConstants.DELIMITER + "Dummy"  //keep
						      + VpsConstants.DELIMITER + VpsConstants.SCHEDULE_DEFINITION_PREFIX
						      + VpsConstants.DELIMITER + def.getJobScheduleDefOid());
		nodeAtLevelOne.setChildAt(nodeAtLevelTwo, l1);
		
		ptTableAccess = new PendingTaskTableAccess();
		instancesMix = new ArrayList();
		pendingTask = ptTableAccess.getPendingTaskByJobScheduleDefOid(def.getJobScheduleDefOid());
		if (pendingTask != null)
		    instancesMix.add(pendingTask);

		tiTableAccess = new TaskInstanceTableAccess();
		instances = tiTableAccess.getInstancesByDefOid(def.getJobScheduleDefOid());
		if (instances != null && !instances.isEmpty())
		    instancesMix.addAll(instances);
		
		numberOfIns = instancesMix.size();
		nodeAtLevelTwo.setChildCount(numberOfIns);

		for (l2=0; l2<numberOfIns; l2++) {
		    Object instance = instancesMix.get(l2);

		    if (instance instanceof TaskInstance) {
			taskInstance = (TaskInstance)instance;
			nodeAtLevelThree =
			    new DefaultWTreeNode(taskInstance.getStartTime() 
						 + VpsConstants.DELIMITER + taskInstance.getStatus()
						 + VpsConstants.DELIMITER + VpsConstants.TASK_INSTANCE_PREFIX
						 + VpsConstants.DELIMITER + taskInstance.getTaskInstanceOid(), false);
			nodeAtLevelTwo.setChildAt(nodeAtLevelThree, l2);
		    }
		    else {
			pendingTask = (PendingTask)instance;
			nodeAtLevelThree =
			    new DefaultWTreeNode(pendingTask.getExecuteTime() 
						 + VpsConstants.DELIMITER + pendingTask.getStatus()
						 + VpsConstants.DELIMITER + VpsConstants.PENDING_TASK_PREFIX
						 + VpsConstants.DELIMITER + pendingTask.getPendingTaskOid(), false);
			nodeAtLevelTwo.setChildAt(nodeAtLevelThree, l2);
		    }

		}
	    }
	}
	catch (Exception e) {
	    logger.error (Util.getStackTrace(e));
	}
    }
}










