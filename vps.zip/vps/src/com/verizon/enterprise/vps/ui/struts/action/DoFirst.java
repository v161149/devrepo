package com.verizon.enterprise.vps.ui.struts.action;

import java.util.*;
import java.sql.Timestamp;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.datalayer.JobScheduleDefTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.TaskInstanceTableAccess;
import com.verizon.enterprise.vps.ui.datalayer.PendingTaskTableAccess;
import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.ui.dataobjects.TaskInstance;
import com.verizon.enterprise.vps.ui.dataobjects.PendingTask;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.ui.struts.action.ActionHelper;
import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import org.apache.log4j.Logger;

public class DoFirst extends Action {
    private static Logger logger = Logger.getLogger(DoFirst.class);

    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse){
	final String METHOD_NAME = "DoFirst:execute()";
	logger.debug("ENTER: " + METHOD_NAME );

	PageForm pForm = (PageForm)aForm;
	HttpSession session = aRequest.getSession();
	session.setAttribute ("page", pForm);
	session.removeAttribute("vpsCreateErrors");
	session.removeAttribute ("scheduleDef");

	String linkClicked = null;
	try {
	    if (pForm != null && (linkClicked = pForm.getLinkClicked()) != null) {
		linkClicked = linkClicked.trim();
		int index = linkClicked.indexOf(VpsConstants.DELIMITER);
		if (index > 0 && index < linkClicked.length() -1) {

		    String prefix = Util.getTypePrefix(linkClicked);
		    String oid = Util.getOid(linkClicked);

		    if (prefix.equals (VpsConstants.SCHEDULE_DEFINITION_PREFIX)) {
			JobScheduleDefTableAccess jsdAccess = new JobScheduleDefTableAccess ();
			JobScheduleDef def = jsdAccess.getJobScheduleDefByOid(oid);
			session.setAttribute ("scheduleDef", def);
			session.removeAttribute ("taskInstance");
			session.removeAttribute ("pendingTask");
		    }
		    else if (prefix.equals (VpsConstants.TASK_INSTANCE_PREFIX)) {
			TaskInstanceTableAccess tiAccess = new TaskInstanceTableAccess();
			TaskInstance instance = tiAccess.getTaskInstanceByOid(oid);
			session.setAttribute ("taskInstance", instance);
			session.removeAttribute ("scheduleDef");
			session.removeAttribute ("pendingTask");
		    }
		    else if (prefix.equals (VpsConstants.PENDING_TASK_PREFIX)){
			PendingTaskTableAccess ptAccess = new PendingTaskTableAccess();
			PendingTask task = ptAccess.getPendingTaskByOid(oid);
			session.setAttribute ("pendingTask", task);
			session.removeAttribute ("scheduleDef");
			session.removeAttribute ("taskInstance");
		    }
		    else{}
		}
		else {
		    if (linkClicked.equals("refresh")) {
			session.removeAttribute (VpsConstants.TREE_MODEL_NAME_IN_SESSION);
		    }
		    else if (linkClicked.equals("cancel")) {
			String oidToStop = pForm.getJobScheduleDefOid();
                        JobScheduleDefTableAccess jsta = new JobScheduleDefTableAccess();

			String userId = null;
			userId =  ActionHelper.getUserOidFromRequest(aRequest);
			logger.debug ("userOid = " + userId);

                        jsta.cancelJobScheduleDef(oidToStop, userId, false);
			JobScheduleDef def = jsta.getJobScheduleDefByOid(oidToStop);

			session.setAttribute ("scheduleDef", def);
                        session.removeAttribute (VpsConstants.TREE_MODEL_NAME_IN_SESSION);
		    }
		    else if( linkClicked.equals("remove")) {
			String oidToRemove = pForm.getJobScheduleDefOid();
                        JobScheduleDefTableAccess jsta = new JobScheduleDefTableAccess();

			String userId = null;
			userId =  ActionHelper.getUserOidFromRequest(aRequest);
			logger.debug ("userOid = " + userId);

                        jsta.cancelJobScheduleDef(oidToRemove, userId, true);

			session.removeAttribute ("scheduleDef");
                        session.removeAttribute (VpsConstants.TREE_MODEL_NAME_IN_SESSION);
		    }
		    else if (linkClicked.equals("modify")) {
			String oidToModify = pForm.getJobScheduleDefOid();
			JobScheduleDefTableAccess jsta = new JobScheduleDefTableAccess();
			JobScheduleDef jsd = jsta.getJobScheduleDefByOid (oidToModify);
			session.setAttribute ("scheduleDef", jsd);
			return aMapping.findForward("modify");
		    }
 		}
	    }
	    else {
		session.removeAttribute ("taskInstance");
		session.removeAttribute ("scheduleDef");
		session.removeAttribute ("pendingTask");
		logger.debug ("not a page link....");
	    }
	}
	catch (Exception e) {
	    String errorMsg = null;
	    if (e instanceof VpsException)
		errorMsg = ((VpsException)e).getMessage();
	    else {
		errorMsg = e.toString();
		int index = errorMsg.indexOf (':');
		if (index > 0 && index < errorMsg.length()) {
		    //This will exlude "java.lang.Exception:" from showing up as part of the error message.
		    //The message will consist of the exception message only, if any.
		    String temp = errorMsg.substring(index+1); 
		    if (temp.trim().length() != 0)
			errorMsg = temp;
		}
	    }
	    Collection errors = new ArrayList();
	    errors.add(errorMsg);
	    session.setAttribute("vpsCreateErrors", errors);
	    e.printStackTrace();
	}
	
	ActionForward forward = ActionHelper.findForwardBasedOnPermission (aRequest,
									   aMapping.findForward("display"),
									   aMapping.findForward("noPermission"));
	logger.debug("EXIT: " + METHOD_NAME );
        return forward;
    }
}



