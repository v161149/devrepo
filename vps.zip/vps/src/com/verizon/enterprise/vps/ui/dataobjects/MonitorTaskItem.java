package com.verizon.enterprise.vps.ui.dataobjects;

import com.verizon.enterprise.vps.core.TaskTrackingObject;
import java.text.SimpleDateFormat;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MonitorTaskItem implements java.io.Serializable
{
    String jobId = "0";
    String userId = "0";
    String scheduleStart = null;
    String scheduleEnd = null;
    String startTime = null;
    String endTime = null;
    String status = null;
    String taskDescription = null;
    String executionCount = "1";

    public MonitorTaskItem()
    {
    }

    public MonitorTaskItem(TaskTrackingObject value)
    {
        jobId = value.getJobScheduleDefOid().toString();
        if (value.getUserId() != null)
            userId = value.getUserId().toString();
        SimpleDateFormat dateFormater
            = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss.zzz");
        if (value.getScheduleStartTime() != null)
            scheduleStart = dateFormater.format(value.getScheduleStartTime());
        if (value.getScheduleEndTime() != null)
            scheduleEnd = dateFormater.format(value.getScheduleEndTime());
        if (value.getStartTime() != null)
            startTime = value.getStartTime().toString();
        if (value.getEndTime() != null)
            endTime = value.getEndTime().toString();
        status = value.getStatus();
        taskDescription = value.getTaskDescription();
        executionCount = "" + value.getExecutionCount();
    }

    public void setJobId(String value)
    {
        jobId = value;
    }

    public String getJobId()
    {
        return jobId;
    }

    public void setUserId(String value)
    {
        userId = value;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setScheduleStart(String value)
    {
        scheduleStart = value;
    }

    public String getScheduleStart()
    {
        return scheduleStart;
    }

    public void setScheduleEnd(String value)
    {
        scheduleEnd = value;
    }

    public String getScheduleEnd()
    {
        return scheduleEnd;
    }

    public void setStartTime(String value)
    {
        startTime = value;
    }

    public String getStartTime()
    {
        return startTime;
    }

    public void setEndTime(String value)
    {
        endTime = value;
    }

    public String getEndTime()
    {
        return endTime;
    }

    public void setStatus(String value)
    {
        status = value;
    }

    public String getStatus()
    {
        return status;
    }

    public void setTaskDescription(String value)
    {
        taskDescription = value;
    }

    public String getTaskDescription()
    {
        return taskDescription;
    }

    public void setExecutionCount(String value)
    {
        executionCount = value;
    }

    public String getExecutionCount()
    {
        return executionCount;
    }
}