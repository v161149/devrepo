package com.verizon.enterprise.vps.ui.struts.action;

import java.util.Enumeration;
import java.sql.Timestamp;
import java.util.List;
import java.util.ArrayList;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.verizon.enterprise.vps.ui.struts.form.ClassParameterForm;
import org.apache.log4j.Logger;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.helper.Util;
import java.lang.reflect.Method;

public class RefreshAction extends Action {
    private static Logger logger = Logger.getLogger(RefreshAction.class);

    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse){
	final String METHOD_NAME = "RefreshAction:execute()";
	logger.debug("ENTER: " + METHOD_NAME );

	ClassParameterForm cForm = (ClassParameterForm)aForm;
	HttpSession session = aRequest.getSession();
	session.setAttribute ("classMethodForm", cForm);
	session.removeAttribute("vpsCreateErrors");

	String methodName = null;
	String className = null;
	ActionForward forward = null;

	try {
	    className = cForm.getClassName();
	    logger.debug("className  = "+cForm.getClassName());
	    session.removeAttribute ("methodNames");

	    List methodNames = Util.getMethodNames(className);
	    methodNames = Util.beautifyMethodNamesForUI(methodNames);
	    session.setAttribute ("methodNames", methodNames);

	    forward = aMapping.findForward("origin");
	}
	catch (Exception e) {
	    e.printStackTrace();
	    forward = aMapping.findForward("origin");
	    logger.debug("forwarding to \"origin\"...");
	}

	logger.debug("EXIT: " + METHOD_NAME );
        return forward;
    }

}



