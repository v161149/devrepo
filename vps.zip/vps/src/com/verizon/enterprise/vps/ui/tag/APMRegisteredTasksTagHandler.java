package com.verizon.enterprise.vps.ui.tag;

import java.io.IOException;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspWriter;
import java.util.*;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.kernel.config.Config;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>  
 * @author v434518
 * @version 1.1
 */

public class APMRegisteredTasksTagHandler extends BodyTagSupport {
    private static Logger logger = Logger.getLogger(APMRegisteredTasksTagHandler.class);
    private static final String CONFIG_PREFIX = "vps.vps";

    private ArrayList tasks;

    protected void register(String taskName, 
			    String maxWaitingSec, 
			    String callBackFunc,
			    String servletURL) {
	if (tasks == null) {
	    tasks = new ArrayList();
	}

	tasks.add(new ChildTagAttributesBundle (taskName, maxWaitingSec, callBackFunc, servletURL));
    }

    public int doStartTag () throws JspException {
	logger.debug ("HanTest: do start tag of apm:registeredTasks tag...");
	tasks = null;
	return EVAL_BODY_INCLUDE;
    }

    public int doEndTag() throws JspException  {
	logger.debug ("HanTest: do end tag of apm:registeredTasks tag...");
	JspWriter out = pageContext.getOut();

	try {
	    StringBuffer sb =  new StringBuffer();
	    sb.append("<script>");
	    
	    if (tasks != null) {

		ChildTagAttributesBundle bundle = null;

		for (int i=0; i<tasks.size(); i++) {

		    bundle = (ChildTagAttributesBundle)tasks.get(i);
		    sb.append("registerTaskInQueue('");
		    sb.append(bundle.getTaskName());
		    sb.append("', '");
		    sb.append(bundle.getMaxWaitingSec());
		    sb.append("', function(resultText) {");
		    sb.append(bundle.getCallBackFunc());
		    sb.append("(resultText);});\n");
		}
		
		sb.append("start('");
		sb.append(bundle.getServletURL());
		sb.append("');");
	    }
	    sb.append("</script>");
	    out.println(sb.toString());
	}
	catch(IOException ioe) {
	    logger.error (Util.getStackTrace(ioe));
	}
	logger.debug ("Successfully finished apm:registeredTasks tag handler.");
	return super.doEndTag();//EVAL_PAGE;
    }

    class ChildTagAttributesBundle implements java.io.Serializable {
	
	private String taskName;
	private String maxWaitingSec;
	private String callBackFunc;
	private String servletURL;

	public ChildTagAttributesBundle (String t, 
					 String m, 
					 String c,
					 String s) {
	    setTaskName(t);
	    setMaxWaitingSec(m);
	    setCallBackFunc(c);
	    setServletURL(s);
	}

	public void setTaskName(String t) {
	    this.taskName = t;
	}

	public void setMaxWaitingSec(String m) {
	    maxWaitingSec = m;
	}

	public void setCallBackFunc(String c) {
	    callBackFunc = c;
	}

	public void setServletURL (String s) {
	    servletURL = s;
	}

	public String getTaskName() {
	    return taskName;
	}
	
	public String getMaxWaitingSec () {
	    return maxWaitingSec;
	}

	public String getCallBackFunc () {
	    return callBackFunc;
	}

	public String getServletURL() {
	    return servletURL;
	}
    }
}






