package com.verizon.enterprise.vps.ui.datalayer;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collection;
import java.sql.Timestamp;
import org.apache.log4j.Logger;
import com.verizon.kernel.exception.DatalayerException;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.enterprise.vps.ui.dataobjects.JobScheduleDef;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;
import com.verizon.enterprise.vps.dataobjects.IVpsPersistentTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.kernel.jdbc.CursorResult;
import com.verizon.kernel.jdbc.CursorId;

public class JobScheduleDefTableAccess {

    private static Logger logger = Logger.getLogger(JobScheduleDefTableAccess.class);

    public JobScheduleDefTableAccess () {
    }

    public JobScheduleDef createJobScheduleDef(IVpsPersistentTask task,
					       ISchedule schedule,
					       String userId) throws VpsScheduleException, Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:createJobScheduleDef(IVpsPersistentTask, ISchedule)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("task: " + task);
	logger.debug("schedule: " + schedule);

	ScheduleManager sm = new ScheduleManager();
	if (userId != null && userId.trim().length() != 0) {
	    sm.setUserId (Long.valueOf(userId));
	}
	JobScheduleDefObject jobScheduleDefObject = sm.schedulePersistentJob (task, schedule);
	JobScheduleDef def = this.populateJobScheduleDef (jobScheduleDefObject);

	logger.debug("EXIT: " + METHOD_NAME);
	return def;
    }

    public void cancelJobScheduleDef(String oid,
				     String userId,
                                     boolean removeDef) throws VpsScheduleException, Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:cancelJobScheduleDef(String, String, boolean)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("oid: " + oid);
	logger.debug("userId: " + userId);
	logger.debug("removeDef: " + removeDef);

        JobScheduleDefObject jsd = null;
        if (!removeDef) {
            // Need to retrieve from db
            jsd = JobScheduleDefTable.retrieve(new Long(oid));
        }
        else {
            jsd = new JobScheduleDefObject();
            jsd.setJobScheduleDefOid(new Long(oid));
        }

	ScheduleManager sm = new ScheduleManager();
	if (userId != null && userId.trim().length() != 0) {
	    sm.setUserId (Long.valueOf(userId));
	}
	sm.unschedulePersistentJob (jsd, removeDef);
	logger.debug("EXIT: " + METHOD_NAME);
    }

    public JobScheduleDef updateJobScheduleDef (IVpsPersistentTask task,
						ISchedule schedule,
						JobScheduleDef jobDef,
						String userId) throws Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:updateJobScheduleAccess(IVpsPersistentTask, ISchedule, JobScheduleDef, String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("IVpsPersistentTask: " + task);
	logger.debug("ISchedule: " + schedule);
	logger.debug("JobScheduleDef: " + jobDef);
	logger.debug("userId " + userId);

	JobScheduleDefObject jobObject = jobDef.getJobScheduleDefObject();
	ScheduleManager sm = new ScheduleManager();
	if (userId != null && userId.trim().length() != 0) {
	    sm.setUserId (Long.valueOf(userId));
	}
	jobObject = sm.updatePersistentJob (task, schedule, jobObject);
	JobScheduleDef def = this.populateJobScheduleDef (jobObject);

	logger.debug("EXIT: " + METHOD_NAME);
	return def;
    }

    public List getAllScheduleDefinitions()  throws Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:getAllScheduleDefinitions()";
	logger.debug("ENTER: " + METHOD_NAME);

	List allDef = new ArrayList();
	List returnList = new ArrayList();
	JobScheduleDef def = null;
	JobScheduleDefObject jsdo = null;

	allDef = this.getJobScheduleDefsBySearchCondition ("order by name");

	if (allDef != null) {
	    int size = allDef.size();
	    for (int i=0; i<size; i++){
		jsdo = (JobScheduleDefObject)allDef.get(i);
		if (jsdo != null) {
		    def = this.populateJobScheduleDef(jsdo);
		    returnList.add(def);
		}
	    }
	}
	logger.debug("EXIT: " + METHOD_NAME);
	return returnList;
    }

    public List getScheduleDefinitionsWithPagination(String condition,
						     CursorId cursor)  throws Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:getScheduleDefinitionsWithPagination(String, CursorId)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("condition: " + condition);
	logger.debug("cursor: " + cursor);

	List definitions = null;
	Iterator iterator =  null;
	JobScheduleDef jobScheduleDef = null;
	JobScheduleDefObject jobScheduleDefObject = null;

	if (cursor != null) {
            // Temporary soluation before datalayer's cursor is fixed
            List list = this.getJobScheduleDefsBySearchCondition(condition);
            cursor.setTotalRows(list.size());
            if (list != null) {
                iterator = list.iterator();
                for (int i=1; i<cursor.getPosition(); i++) iterator.next();
            }
/* real cursor call

	    CursorResult result = JobScheduleDefTable.searchByCursor (condition, cursor);
	    cursor = result.getCursor();
	    Collection objects = result.getObjects();
	    if (objects != null) {
		iterator = objects.iterator();
	    }
*/
	}
	else {
	    List list = this.getJobScheduleDefsBySearchCondition(condition);
	    if (list != null)
		iterator = list.iterator();
	}

	if (iterator != null) {
	    definitions = new ArrayList();
	    while (iterator.hasNext()) {
		jobScheduleDefObject = (JobScheduleDefObject)iterator.next();
		jobScheduleDef = this.populateJobScheduleDef(jobScheduleDefObject);
		definitions.add(jobScheduleDef);
	    }
	}
	else {
	    definitions = new ArrayList();
	}

	logger.debug("retrived back " +definitions.size() + "JobScheduleDef objects.");
	logger.debug("EXIT: " + METHOD_NAME);
	return definitions;
    }

    public List getJobScheduleDefsBySearchCondition (String condition) throws Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:getJobScheduleDefBySearchCondition(String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("condition: " + condition);
	List allDefs = null;

	try {
	    allDefs = JobScheduleDefTable.search(condition);
	}
	catch (DatalayerException dle) {
	    logger.error (METHOD_NAME + " DatalayerException " + dle.getMessage());
	    logger.error (Util.getStackTrace(dle));
	    throw new Exception (dle.getMessage());
	}
	catch (Exception e) {
	    logger.error (METHOD_NAME + " Exception " + e.getMessage());
	    logger.error (Util.getStackTrace(e));
	    throw new Exception(e.getMessage());
	}
	logger.debug("EXIT: " + METHOD_NAME);
	return allDefs;
    }

    public JobScheduleDef getJobScheduleDefByOid (String oid) throws Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:getJobScheduleDefByOid(String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("oid: " + oid);

	JobScheduleDef job = null;
	JobScheduleDefObject jobScheduleDefObject = this.getJobScheduleDefObjectByOid(oid);
	if (jobScheduleDefObject != null)
	    job = this.populateJobScheduleDef (jobScheduleDefObject);

	logger.debug("EXIT: " + METHOD_NAME);
	return job;
    }

    public JobScheduleDefObject getJobScheduleDefObjectByOid (String oid) throws Exception {
	final String METHOD_NAME = "JobScheduleDefTableAccess:getJobScheduleDefObjectByOid(String)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("oid: " + oid);

	JobScheduleDefObject jobScheduleDefObject = null;

	try {
	    Long OID = new Long (oid);
	    jobScheduleDefObject = JobScheduleDefTable.retrieve(OID);
	    logger.debug ("Job_Schedule_Def data, oid = " + oid + ", successfully retrieved from Job_Schedule_De table.");
	}
	catch (DatalayerException dle) {
	    logger.error (METHOD_NAME + " DatalayerException " + dle.getMessage());
	    logger.error (Util.getStackTrace(dle));
	    throw new Exception (dle.getMessage());
	}
	catch (Exception e) {
	    logger.error (METHOD_NAME + " Exception " + e.getMessage());
	    logger.error (Util.getStackTrace(e));
	    throw new Exception(e.getMessage());
	}
	logger.debug("EXIT: " + METHOD_NAME);
	return jobScheduleDefObject;
    }

    /*
    public void updateJobScheduleDef(JobScheduleDefObject jobScheduleDefObject) throws Exception{
	final String METHOD_NAME = "JobScheduleDefTableAccess:updateJobScheduleDef(JobScheduleDefObject)";
	logger.debug("ENTER: " + METHOD_NAME + " with following parameters");
	logger.debug("jobScheduleDefObject: " + jobScheduleDefObject);
	try {
	    JobScheduleDefTable.update(jobScheduleDefObject);
	}
	catch (DatalayerException dle) {
	    logger.error (METHOD_NAME + " DatalayerException " + dle.getMessage());
	    logger.error (Util.getStackTrace(dle));
	    throw new Exception (dle.getMessage());
	}
	catch (Exception e) {
	    logger.error (METHOD_NAME + " Exception " + e.getMessage());
	    logger.error (Util.getStackTrace(e));
	    throw new Exception(e.getMessage());
	}
	logger.debug("EXIT: " + METHOD_NAME);
    }
    */

    private JobScheduleDef populateJobScheduleDef (JobScheduleDefObject jobScheduleDefObject) throws Exception{
	String oid = jobScheduleDefObject.getJobScheduleDefOid().toString();
	String name = jobScheduleDefObject.getName();
	String scheduleInfo = jobScheduleDefObject.getScheduleInfo();
	String taskInfo = jobScheduleDefObject.getTaskInfo();
	String description = jobScheduleDefObject.getDescription();
	String effectiveStartTime = Util.convertTimestampToUIStd(jobScheduleDefObject.getEffectiveStartTime());
	String effectiveStopTime = Util.convertTimestampToUIStd(jobScheduleDefObject.getEffectiveStopTime());
	String timestamp = Util.convertTimestampToUIStd(jobScheduleDefObject.getTimestamp());
	String userOid = jobScheduleDefObject.getUserId().toString();
	String status = jobScheduleDefObject.getStatus();

	JobScheduleDef job = new JobScheduleDef (oid, name, scheduleInfo, taskInfo,
						 description, effectiveStartTime,
						 effectiveStopTime, userOid, timestamp, status);
	return job;
    }
}








