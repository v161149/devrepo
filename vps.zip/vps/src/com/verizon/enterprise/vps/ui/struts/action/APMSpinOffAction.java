package com.verizon.enterprise.vps.ui.struts.action;

import java.util.*;
import java.sql.Timestamp;
import java.io.PrintWriter;
import java.io.IOException;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.verizon.enterprise.vps.ui.helper.VpsConstants;
import com.verizon.enterprise.vps.ui.helper.Util;
import com.verizon.enterprise.vps.ui.dataobjects.APMSpinOffTask;
import com.verizon.enterprise.vps.ui.struts.form.APMSpinOffForm;
import com.verizon.enterprise.vps.ui.tag.SapientHelper;
import com.verizon.enterprise.common.VerizonStateManager;
import com.verizon.enterprise.vps.dataobjects.TimeoutTaskListener;

import org.apache.log4j.Logger;

public class APMSpinOffAction extends Action {
    private static Logger logger = Logger.getLogger(APMSpinOffAction.class);
    private static long MINIMUM_SLEEP_TIME_MILL = 200;

    public ActionForward execute(ActionMapping aMapping,
				 ActionForm aForm,
				 HttpServletRequest aRequest,
				 HttpServletResponse aResponse){
	final String METHOD_NAME = "APMSpinOffAction:execute()";
	logger.debug("ENTER: " + METHOD_NAME);

	APMSpinOffForm apmForm = (APMSpinOffForm)aForm;
	Collection tasks = apmForm.getSpinOffTasks();
	String lastFinishedTaskName = apmForm.getFinishedTaskName();

	if (tasks == null || tasks.isEmpty()) {
	    logger.warn("task request is not correctly passed in from UI side.");
	}

	aResponse.setContentType("text/html");
	aResponse.setBufferSize(8192);

	VerizonStateManager stateManager = new VerizonStateManager(aRequest);
	Hashtable runningTasks = stateManager.getAPMSession();
	
	logger.debug("runningTasks == null" + (runningTasks == null));
	logger.debug("runningTasks.isEmpty()" + (runningTasks.isEmpty()));
	
	if (runningTasks == null ||runningTasks.isEmpty()){
	     logger.warn("APM task was not properly registered with APM session.");
	}

	if (lastFinishedTaskName != null 
	    && lastFinishedTaskName.trim().length() != 0){

	    runningTasks.remove(new Long(lastFinishedTaskName));
	}
	
	boolean taskDone = false;
	Object result = null;
	APMSpinOffTask taskWShortestWaiting = findTaskWShortestWaiting(tasks, runningTasks);
	APMSpinOffTask taskFinished = null;

	if (taskWShortestWaiting == null) {
	     result = "APM task was not properly registered for apm custom tag.";
	}
	else {
	    String maxWaitingSec = taskWShortestWaiting.getMaxWaitingSec();
	    String taskName = taskWShortestWaiting.getTaskName().trim();
	    long sleepMill = 0;
	    long maxWaitingMill = 0;

	    try {
		maxWaitingMill = Long.parseLong(maxWaitingSec)*1000;
	    }
	    catch (NumberFormatException nfe) {
		logger.error ("The following NumberFormatException is properly handled.");
		logger.error (METHOD_NAME + ", " + nfe.toString());
		logger.error (Util.getStackTrace(nfe));
		maxWaitingMill = -1; //infinite
	    }

	    if (maxWaitingMill < 0) { //infinite waiting, breaks only when task is done
		sleepMill = 1000;
		while (!taskDone) {
		    try {
			taskFinished = findFinishedTask(tasks, runningTasks);
						
			if(taskFinished != null) {
			    taskDone = true;
			    break;
			}

			Thread.sleep (sleepMill); 
		    }  
		    catch (InterruptedException ie) {  
			//taskDone = handler.isDone();
		    }
		}
	    }
	    else {
		TimeoutTaskListener handler =  (TimeoutTaskListener) runningTasks.get(new Long(taskWShortestWaiting.getTaskName()));
		maxWaitingMill -=  handler.getTimeExecuted();
		if (maxWaitingMill <=0) {
		    taskDone = handler.isDone();
		    if (taskDone)
			taskFinished = taskWShortestWaiting;
		}
		else {
		    sleepMill = findMax(maxWaitingMill/100, MINIMUM_SLEEP_TIME_MILL);
		    long totalSleepingTime = 0;
		    while (totalSleepingTime < maxWaitingMill) {
			try {
			    totalSleepingTime += sleepMill;
			    taskFinished = findFinishedTask(tasks, runningTasks);
			
			    if(taskFinished != null) {
				taskDone = true;
				break;
			    }
			    Thread.sleep (sleepMill); 
			}  
			catch (InterruptedException ie) {  
			    totalSleepingTime += sleepMill;
			}
		    }
		}
	    }
	}

	try {
	    PrintWriter out = aResponse.getWriter();
	    if (taskDone) {
		logger.debug ("taskFinished.getTaskName() = " + taskFinished.getTaskName());
		TimeoutTaskListener handler =  (TimeoutTaskListener) runningTasks.get(new Long(taskFinished.getTaskName()));
		result = handler.getResult();
		//result = result==null? "null" : result.toString();
		logger.debug ("result from APMSpinOffAction = " + result);
		sendResponse (aResponse, result==null? "server side error" : result.toString(),  taskFinished.getTaskName());
	    }
	    else {
		if (result == null) {
		    sendResponse (aResponse, "timer expired...", taskWShortestWaiting.getTaskName());
		}
		else {
		    Iterator ite = tasks.iterator();
		    while (ite.hasNext()) {
			taskWShortestWaiting = (APMSpinOffTask)ite.next();
		    }
		    sendResponse (aResponse, result.toString(), taskWShortestWaiting.getTaskName());
		}
	    }
	}
	catch (IOException ioe) {
	    logger.error (ioe.toString());
	    logger.error (Util.getStackTrace(ioe));
	    //sendResponse (aResponse,  "server side error",  taskFinished.getTaskName());
	}

	ActionForward forward = null;
	logger.debug("EXIT: " + METHOD_NAME );
        return forward;
    }

    private void sendResponse(HttpServletResponse aResponse,
			      String responseText, 
			      String finishedTaskName) {
	try {
	    aResponse.setHeader("FinishedTaskName", finishedTaskName);
	    PrintWriter out = aResponse.getWriter();
	    out.println(responseText);
	}
	catch (IOException ioe) {
	    logger.error (ioe.toString());
	    logger.error (Util.getStackTrace(ioe));
	}
    }

    private long findMax (long num1, long num2) {
	if (num1 > num2)
	    return num1;
	else
	    return num2;
    }

    private APMSpinOffTask findFinishedTask(Collection tasks, Hashtable runningTasks) {

	Iterator ite = tasks.iterator();
	APMSpinOffTask temp = null;
	APMSpinOffTask finishedTask = null;
	String taskName = null;
	TimeoutTaskListener handler = null;

	while (ite.hasNext()) {
	    temp = (APMSpinOffTask)ite.next();
	    taskName=temp.getTaskName();
	    handler = (TimeoutTaskListener) runningTasks.get(new Long(taskName));
	    
	    if (handler == null) {
		logger.info ("Could not find task '" + taskName + "' in APM session.");
		continue;
	    }
	    else {
		if (handler.isDone()) {
		    finishedTask = temp;
		    break;
		}
	    }
	}

	return finishedTask;
    }

    private APMSpinOffTask findTaskWShortestWaiting(Collection tasks, Hashtable runningTasks) {

	Iterator ite = tasks.iterator();
	boolean firstElement = true;
	long shortestWaiting = -1;
	long waitingSecMill = 0;
	APMSpinOffTask taskWShortestWaiting = null;
	APMSpinOffTask temp = null;
	TimeoutTaskListener handler = null;

	while (ite.hasNext()) {
	    temp = (APMSpinOffTask)ite.next();
	    handler = (TimeoutTaskListener) runningTasks.get(new Long(temp.getTaskName()));

	    if (handler == null)
		continue;
	    
	    try {
		waitingSecMill = Long.parseLong(temp.getMaxWaitingSec())*1000;
	    }
	    catch (NumberFormatException nfe) {
		waitingSecMill = -1;
	    }

	    if (firstElement) {
		taskWShortestWaiting = temp;

		if (waitingSecMill < 0)
		    shortestWaiting = -1;
		else if (waitingSecMill == 0) {
		    return taskWShortestWaiting;
		}
		else {
		    shortestWaiting = waitingSecMill - handler.getTimeExecuted();

		    if (shortestWaiting <=0) 
			return taskWShortestWaiting;
		}
		
		firstElement = false;
	    }
	    else {
		if (waitingSecMill < 0)
		    continue;
		else if (waitingSecMill == 0)
		    return temp;
		else {
		    waitingSecMill -= handler.getTimeExecuted();
		    
		    if (waitingSecMill <=0)
			return temp;
		    else if (waitingSecMill < shortestWaiting) {
			shortestWaiting = waitingSecMill;
			taskWShortestWaiting = temp;
		    }
		}
	    }
	} 

	return taskWShortestWaiting;
    }

}
