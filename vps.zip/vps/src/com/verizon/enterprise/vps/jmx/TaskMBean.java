package com.verizon.enterprise.vps.jmx;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import java.util.Date;

public interface TaskMBean
{
    public Date getScheduleStartTime(Long task_oid);
    public Date getScheduleEndTime(Long task_oid);
    public Date getExecutionStartTime(Long task_oid);
    public Date getExecutionEndTime(Long task_oid);
    public String getStatus(Long task_oid);
    public String getTaskDescription(Long task_oid);
    public int getExecutionCount(Long task_oid);
    public String getUserId(Long task_oid);

    /**
     * Stop a transient task that is currently running.
     *
     * @param task_oid task oid.
     * @param server the location where the task is running, for example,
     * "166.68.137.100:9797" or "166.68.137.100:managedOP1".
     */
    public void stopTransientTask(long task_oid, String server);

    /**
     * Stop a persistent task that is currently running.
     *
     * @param task_oid task oid.
     * @param server the location where the task is running, for example,
     * "166.68.137.100:9797" or "166.68.137.100:managedOP1".
     */
    public void stopPersistentTask(long task_oid, String server);

    /**
     * Stop a persistent task that is currently running. This API broadcasts
     * to all active APM instances.
     *
     * @param task_oid task oid.
     */
    public void stopPersistentTask(long task_oid);

    public void cancelSchedule(long schedule_oid);
    public void resumeSchedule(long schedule_oid);
}
