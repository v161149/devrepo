package com.verizon.enterprise.vps.jmx;

import com.verizon.enterprise.vps.core.TaskTrackingObject;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

public interface VpsRuntimeMBean
{
    public int getPendingTransientTaskCount();
    public int getRunningTransientTaskCount();
    public int getFinishedTransientTaskCount();

    public int getPendingPersistentTaskCount();
    public int getRunningPersistentTaskCount();
    public int getFinishedPersistentTaskCount();

    public String getTransientTimerThreadStatus();
    public String getPersistentTimerThreadStatus();

    public void notifyTransientTimerThread();
    public void notifyPersistentTimerThread();

    public TaskTrackingObject[] getTaskHistory() ;
    public TaskTrackingObject[] getCurrentTasks() ;
}
