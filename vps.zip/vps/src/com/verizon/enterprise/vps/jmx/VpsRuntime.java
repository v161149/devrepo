package com.verizon.enterprise.vps.jmx;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import javax.management.NotificationBroadcasterSupport;
import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.enterprise.vps.core.TaskTrackingObject;

public class VpsRuntime /*extends weblogic.management.internal.DynamicMBeanImpl*/
    implements VpsRuntimeMBean/*, weblogic.management.runtime.RuntimeMBean*/
{
    public int getPendingTransientTaskCount()
    {
      return Dispatcher.getTransientPendingQueueSize();
    }
    public int getRunningTransientTaskCount()
    {
      return Dispatcher.getRunningTransientTaskCount();
    }
    public int getFinishedTransientTaskCount()
    {
      return Dispatcher.getFinishedTransientTaskCount();
    }
    public int getPendingPersistentTaskCount()
    {
      return DbHelper.getNumTasksOfStatus(IVpsTask.PENDING);
    }
    public int getRunningPersistentTaskCount()
    {
      return DbHelper.getNumTasksOfStatus(IVpsTask.EXECUTING);
    }
    public int getFinishedPersistentTaskCount()
    {
      //actually needs to read it from TASK_INSTANCE table
      return DbHelper.getNumTasksOfStatus(IVpsTask.FINISHED);
    }
    public TaskTrackingObject[] getTaskHistory() {
        return Dispatcher.getTransientTaskRepository().getTaskHistory();
    }
    public TaskTrackingObject[] getCurrentTasks() {
        return Dispatcher.getTransientTaskRepository().getCurrentTasks();
    }

    public String getTransientTimerThreadStatus() {
      return Dispatcher.getTransientTimerThreadStatus();
    }
    public String getPersistentTimerThreadStatus() {
      return Dispatcher.getPersistentTimerThreadStatus();
    }
    public void notifyTransientTimerThread() {
      Dispatcher.notifyTransientTimerThread();
    }
    public void notifyPersistentTimerThread() {
      Dispatcher.notifyPersistentTimerThread();
    }
}
