package com.verizon.enterprise.vps.db;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;
import com.verizon.enterprise.vps.core.Dispatcher;
import com.verizon.enterprise.vps.core.PersistentExecutionTask;
import com.verizon.enterprise.vps.dataobjects.IVpsPersistentTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.TaskParsingException;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.schedule.AbstractSchedule;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.schedule.ScheduleJobInfo;
import com.verizon.enterprise.vps.schedule.VpsScheduleException;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.exception.DatalayerException;
import com.verizon.kernel.jdbc.ConnectionInterface;

/**
 * <p>Title: Virtual Process Service</p> <p>Description: </p> <p>Copyright:
 * Copyright (c) 2003</p> <p>Company: Verizon</p>
 * 
 * @author Zhong Chen
 * @version 1.0
 */

public class SchedulePersister {
  private Long m_nUserId = new Long(0);

  /**
   * Constructor with empty user id for db operations.
   */
  public SchedulePersister() {
  }

  /**
   * Constructor with user id.
   * 
   * @param nUserId
   */
  public SchedulePersister(Long nUserId) {
    setUserId(nUserId);
  }

  /**
   * Get user id.
   */
  public Long getUserId() {
    return m_nUserId;
  }

  /**
   * Set user id.
   */
  public void setUserId(Long uid) {
    m_nUserId = (uid == null ? new Long(0) : uid);
  }

  /**
   * Create schedule in database. This method also tries to schedule the first
   * job instance.
   */
  public JobScheduleDefObject createSchedule(ConnectionInterface conn, IVpsPersistentTask task, ISchedule schedule) throws VpsScheduleException {
    if (task == null || schedule == null) {
      throw new IllegalArgumentException();
    }

    Date execTime = null;
    Timestamp dbTime = new Timestamp(System.currentTimeMillis());

    // Double check schedule
    // The clone here is necessary to protect some schedule
    // with internal states (ONCE for example).
    if (schedule instanceof AbstractSchedule) {
      ISchedule cs = null;
      try {
        cs = (ISchedule)((AbstractSchedule)schedule).clone();
      } catch (CloneNotSupportedException cnse) {
        ;
      }

      if (cs != null) {
        execTime = cs.getTimeForNextSchedule();
        if (execTime == null) {
          throw new VpsScheduleException(VpsScheduleException.NO_MORE_SCHEDULE);
        }
      }
    }

    // Create entry in schedule definition first.
    JobScheduleDefObject jsdo = new JobScheduleDefObject();
    jsdo.setTimestamp(dbTime);
    jsdo.setUserId(getUserId());

    jsdo.setTimestamp(new Timestamp(System.currentTimeMillis()));
    jsdo.setDescription(schedule.getDescription());
    jsdo.setName(schedule.getName());
    jsdo.setStatus(String.valueOf(ISchedule.STATUS_ACTIVE));
    if (schedule.getStartEffectiveTime() != null) {
      jsdo.setEffectiveStartTime(new Timestamp(schedule.getStartEffectiveTime().getTime()));
    }
    if (schedule.getEndEffectiveTime() != null) {
      jsdo.setEffectiveStopTime(new Timestamp(schedule.getEndEffectiveTime().getTime()));
    }

    String sTaskInfo = null;
    try {
      sTaskInfo = task.writeTaskInfo();
    } catch (VpsException ve) {
      throw new VpsScheduleException(VpsScheduleException.INVALID_TASK_INFO, ve.getMessage());
    }

    if (sTaskInfo != null) {
      jsdo.setTaskInfo(sTaskInfo);
    } else {
      throw new VpsScheduleException(VpsScheduleException.MISSING_TASK_INFO);
    }

    String sScheduleInfo = schedule.getScheduleInfoString();
    if (sScheduleInfo != null) {
      jsdo.setScheduleInfo(sScheduleInfo);
    } else {
      throw new VpsScheduleException(VpsScheduleException.MISSING_SCHEDULE_INFO);
    }

    /** db create for schedule definition */
    try {
      JobScheduleDefTable.create(jsdo, conn);
    } catch (DatalayerException dle) {
      LogHelper.error("DB exception when create schedule: " + dle.getMessage());
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, dle.getMessage());
    }

    // first schedule instance
    /*
     * PendingTaskObject pdo = new PendingTaskObject();
     * pdo.setTimestamp(dbTime); pdo.setUserId(getUserId());
     * pdo.setRetryCounter(new Long(0)); pdo.setExecuteTime(new
     * Timestamp(execTime.getTime()));
     * pdo.setJobScheduleDefOid(jsdo.getJobScheduleDefOid()); pdo.setStatus(new
     * String(new char[]
     * {com.verizon.enterprise.vps.dataobjects.IVpsTask.PENDING}));
     * pdo.setTaskInfo(jsdo.getTaskInfo()); try { PendingTaskTable.create(pdo,
     * conn); } catch (DatalayerException dle) { throw new
     * VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION,
     * dle.getMessage()); }
     */

    PersistentExecutionTask pdo = new PersistentExecutionTask(task);
    pdo.setTimestamp(dbTime);
    pdo.setUserId(getUserId());
    pdo.setRetryCounter(new Long(0));
    pdo.setExecuteTime(new Timestamp(execTime.getTime()));
    pdo.setJobScheduleDefOid(jsdo.getJobScheduleDefOid());
    pdo.setJobScheduleDefOidObject(jsdo);
    pdo.setStatus(IVpsTask.PENDING);
    pdo.setTaskInfo(jsdo.getTaskInfo());

    try {
      Dispatcher.submit(pdo, schedule, conn);
    } catch (VpsScheduleException vse) {
      throw vse;
    } catch (VpsException ve) {
      throw new VpsScheduleException(VpsScheduleException.DISPATCHER_ERROR, ve.getMessage());
    }

    LogHelper.info("Schedule with OID " + jsdo.getJobScheduleDefOid() + " is added and scheduled to run at " + execTime);
    return jsdo;
  }

  /**
   * Remove schedule from database. This method also tries to remove all pending
   * tasks.
   */
  public void removeSchedule(ConnectionInterface ci, JobScheduleDefObject jsdo, boolean bRemoveScheduleFromDB) throws VpsScheduleException {
    if (jsdo == null || jsdo.getJobScheduleDefOid() == null) {
      throw new IllegalArgumentException();
    }

    PreparedStatement pstmt = null;
    Connection conn = ci.getConnection();

    /** remove pending tasks first */
    try {
      String sDeleteSql = "DELETE FROM pending_task WHERE job_schedule_def_oid=?";
      pstmt = conn.prepareStatement(sDeleteSql);
      pstmt.setLong(1, jsdo.getJobScheduleDefOid().longValue());
      pstmt.executeUpdate();
      LogHelper.info("Pending task for schedule with OID " + jsdo.getJobScheduleDefOid() + " is removed.");
    } catch (SQLException sqle) {
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, sqle.getMessage());
    }

    // remove schedule definition itself.
    try {
      if (bRemoveScheduleFromDB) {
        JobScheduleDefTable.remove(jsdo, ci);
        LogHelper.info("Schedule with OID " + jsdo.getJobScheduleDefOid() + " is removed.");
      } else {
        // Update schedule to be cancelled.
        jsdo.setStatus(String.valueOf(ISchedule.STATUS_INACTIVE));
        JobScheduleDefTable.update(jsdo, ci);
        LogHelper.info("Schedule with OID " + jsdo.getJobScheduleDefOid() + " is updated to inActive.");
      }
    } catch (DatalayerException dle) {
      // dle.printStackTrace();
      LogHelper.error("DB exception when remove schedule: " + dle.getMessage());
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, dle.getMessage());
    }

  }

  /**
   * Update schedule in database. This method also updates the schedule in the
   * pending task table.
   */
  public JobScheduleDefObject updateSchedule(ConnectionInterface conn, IVpsPersistentTask task, ISchedule schedule, JobScheduleDefObject jsdo)
      throws VpsScheduleException {
    if (task == null || schedule == null) {
      throw new IllegalArgumentException();
    }

    Date execTime = schedule.getTimeForNextSchedule();
    if (execTime == null) {
      throw new VpsScheduleException(VpsScheduleException.NO_MORE_SCHEDULE);
    } else if (schedule instanceof OnceSchedule) {
      // Recover
      ((OnceSchedule)schedule).resetScheduleFlag();
    }

    jsdo.setUserId(getUserId());
    TimeZone.setDefault(TimeZone.getTimeZone("US/Eastern"));
    System.setProperty("user.timezone", "US/Eastern");
    Timestamp dbTime = new Timestamp(System.currentTimeMillis());
    jsdo.setTimestamp(dbTime);
    jsdo.setDescription(schedule.getDescription());
    jsdo.setName(schedule.getName());
    if (schedule.getStartEffectiveTime() != null) {
      jsdo.setEffectiveStartTime(new Timestamp(schedule.getStartEffectiveTime().getTime()));
    }
    if (schedule.getEndEffectiveTime() != null) {
      jsdo.setEffectiveStopTime(new Timestamp(schedule.getEndEffectiveTime().getTime()));
    }

    String sTaskInfo = null;
    try {
      sTaskInfo = task.writeTaskInfo();
    } catch (VpsException ve) {
      throw new VpsScheduleException(VpsScheduleException.INVALID_TASK_INFO, ve.getMessage());
    }

    if (sTaskInfo != null) {
      jsdo.setTaskInfo(sTaskInfo);
    } else {
      throw new VpsScheduleException(VpsScheduleException.MISSING_TASK_INFO);
    }

    String sScheduleInfo = schedule.getScheduleInfoString();
    if (sScheduleInfo != null) {
      jsdo.setScheduleInfo(sScheduleInfo);
    } else {
      throw new VpsScheduleException(VpsScheduleException.MISSING_SCHEDULE_INFO);
    }

    /** db update for schedule definition */
    try {
      JobScheduleDefTable.update(jsdo, conn);
    } catch (DatalayerException dle) {
      LogHelper.error("DB exception when update schedule: " + dle.getMessage());
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, dle.getMessage());
    }

    // Retrieve pending task.
    PendingTaskObject pto = null;
    try {
      List qPTOs = PendingTaskTable.search(" WHERE job_schedule_def_oid=" + jsdo.getJobScheduleDefOid());
      if (qPTOs != null && qPTOs.size() > 0) {
        pto = (PendingTaskObject)qPTOs.get(0);
        if (qPTOs.size() > 1) {
          LogHelper.warn("There are more than one pending tasks for job schedule with oid " + jsdo.getJobScheduleDefOid());
        }
      }
    } catch (DatalayerException de) {
      ;
    }

    PersistentExecutionTask pdo = new PersistentExecutionTask(task);
    pdo.setTimestamp(dbTime);
    pdo.setUserId(getUserId());
    pdo.setRetryCounter(pto == null ? new Long(0) : pto.getRetryCounter());
    TimeZone.setDefault(TimeZone.getTimeZone("US/Eastern"));
    System.setProperty("user.timezone", "US/Eastern");
    pdo.setExecuteTime(new Timestamp(execTime.getTime()));
    pdo.setJobScheduleDefOid(jsdo.getJobScheduleDefOid());
    pdo.setJobScheduleDefOidObject(jsdo);
    pdo.setStatus(IVpsTask.PENDING);
    pdo.setTaskInfo(jsdo.getTaskInfo());
    if (pto != null)
      pdo.setPendingTaskOid(pto.getPendingTaskOid());

    try {
      Dispatcher.submit(pdo, schedule, conn);
    } catch (VpsException e) {
      // failed to submit the task, let the TimerThread handle it.
      LogHelper.warn(e);
    }

    LogHelper.info("Schedule with OID " + jsdo.getJobScheduleDefOid() + " is updated and scheduled to run at " + execTime);
    return jsdo;
  }

  /**
   * Retrieves the List of ScheduleJobInfo objects corresponding to this
   * condition
   * 
   * @param ScheduleName
   * @return List - List of ScheduleJobInfo objects
   * @throws VpsScheduleException
   * @throws RemoteException
   */
  public Set getScheduleList(ConnectionInterface ci, String condition) throws VpsScheduleException {
    if (condition == null)
      throw new IllegalArgumentException();

    //Statement stmt = null;
    //Connection conn = ci.getConnection();
    List result = null;
    /** remove pending tasks first */
    String sSelectSql = "WHERE " + condition;

    try {
      result = JobScheduleDefTable.search(sSelectSql, ci);
    } catch (DatalayerException d) {
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, d.getMessage());
    }

    Set list = new HashSet();
    try {
      for (Iterator it = result.iterator(); it.hasNext();) {
        JobScheduleDefObject jsdo = (JobScheduleDefObject)it.next();
        ScheduleJobInfo info = new ScheduleJobInfo();
        info.setSchedule(jsdo.getScheduleInfo());
        info.setTask(jsdo.getTaskInfo());
        list.add(info);
      }
    } catch (TaskParsingException t) {
      throw new VpsScheduleException(VpsScheduleException.PARSING_ERROR, t.getMessage());
    }
    return list;
  }

  public List getSchedules(ConnectionInterface conn, String condition) throws VpsScheduleException {
    if (condition == null)
      throw new IllegalArgumentException();

    List result = null;
    // String sSelectSql = condition=="" ? condition : "WHERE " + condition;

    try {
      if (condition.trim().length() == 0)
        result = JobScheduleDefTable.search("");
      else
        result = JobScheduleDefTable.search("WHERE " + condition, conn);
    } catch (DatalayerException d) {
      d.printStackTrace();
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, d.getMessage());
    }
    return result;
  }

  public List getTaskInstanceList(ConnectionInterface conn, String condition) throws VpsScheduleException {
    if (condition == null)
      throw new IllegalArgumentException();

    List result = null;
    // String sSelectSql = condition=="" ? condition : "WHERE " + condition;

    try {
      if (condition.trim().length() == 0)
        result = TaskInstanceTable.search("");
      else
        result = TaskInstanceTable.search("WHERE " + condition, conn);
    } catch (DatalayerException d) {
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, d.getMessage());
    }
    return result;
  }

  public void deleteTaskInstance(ConnectionInterface conn, TaskInstanceObject taskObject) throws VpsScheduleException {

    if (taskObject == null || conn == null)
      throw new IllegalArgumentException();
    // System.out.println ("deleting task_instance " +
    // taskObject.getTaskInstanceOid().toString());

    try {
      TaskInstanceTable.remove(taskObject, conn);
    } catch (DatalayerException dle) {
      LogHelper.error("DB exception when removing task_instance: " + dle.getMessage());
      throw new VpsScheduleException(VpsScheduleException.DATABASE_EXCEPTION, dle.getMessage());
    }
  }
}
