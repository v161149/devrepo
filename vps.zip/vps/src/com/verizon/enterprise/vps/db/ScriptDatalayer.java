package com.verizon.enterprise.vps.db;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import com.verizon.common.datalayer.ecp.JetsScriptObject;
import com.verizon.common.datalayer.ecp.JetsScriptTable;
import com.verizon.kernel.exception.DatalayerException;

import java.util.List;
import org.apache.log4j.Logger;

public class ScriptDatalayer {

    private static Logger log = Logger.getLogger(ScriptDatalayer.class);

    public ScriptDatalayer()
    {
    }

    public static JetsScriptObject getJetsScript(String name) throws DatalayerException
    {
        final String METHOD_NAME = "getJetsScript()";

        log.debug("ENTER: " + METHOD_NAME);
        log.info(METHOD_NAME + ": name = " + name);

        JetsScriptObject script = null;

        List objList = JetsScriptTable.search("where script_name = '" + name + "'");
        if (objList != null && objList.size() > 0)
        {
            script = (JetsScriptObject) objList.get(0);
            log.info(METHOD_NAME + ": size = " + objList.size());
        }
        else
            log.info(METHOD_NAME + ": objList = null.");

        log.debug("ENTER: " + METHOD_NAME);
        return script;
    }
}