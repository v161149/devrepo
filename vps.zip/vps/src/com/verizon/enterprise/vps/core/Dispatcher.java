/*
 * @(#) Dispatcher.java	1.1, 06/23/03
 *
 * Copyright 2003 Verizon Communications, Inc. All rights reserved.
 */

package com.verizon.enterprise.vps.core;

import java.sql.Timestamp;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.VpsException;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.enterprise.vps.util.TimeHelper;
import com.verizon.kernel.config.Config;
import com.verizon.kernel.exception.DatalayerException;
import com.verizon.kernel.jdbc.ConnectionInterface;

public class Dispatcher {
  private static TaskRepository m_transient_task_repository = new TaskRepository();
  private static long m_transient_job_schedule_def_oid = -1;
  static int m_num_of_exec_threads_used = 0;
  private static final int DEFAULT_EXEC_THREAD_MAX_ALLOWED = 10;
  private static final ExecutorService APM_POOL = Executors.newFixedThreadPool(DEFAULT_EXEC_THREAD_MAX_ALLOWED);

  /**
   * The in memory scheduled/pending task queue. This data structure is shared
   * with the timer thread. The Dispatcher submits tasks with schedules by
   * adding new ScheduledTask to the queue and the timer thread consumes,
   * delivers tasks to execution queue as appropriate.
   */
  private static ITaskQueue queue = new TaskQueue();
  private static ITaskQueue dbqueue = new TaskDBQueue();

  /**
   * The timer thread.
   */
  private static TimerThread thread = new TimerThread(queue);
  private static TimerDBThread dbthread = new TimerDBThread((TaskDBQueue)dbqueue);

  /**
   * initialize and startup timer thread and pending task queue.
   */
  public static void initialize() {
  }

  /**
   * submit transient job to pending task queue.
   * 
   * @param task
   * @param schedule
   * @throws VpsException
   */
  public static Long submit(TransientExecutionTask task, ISchedule schedule) throws VpsException {
    Long joid = null;
    synchronized (Dispatcher.class) {
      joid = new Long(m_transient_job_schedule_def_oid--);
    }
    task.setPendingTaskOid(joid);
    task.setJobScheduleDefOid(joid);
    submit(task, schedule, false, null);
    return joid;
  }

  /**
   * submit persistent job to pending task queue.
   * 
   * @param task
   * @param schedule
   * @param conn
   * @throws VpsException
   */
  public static void submit(PersistentExecutionTask task, ISchedule schedule, ConnectionInterface conn) throws VpsException {
    submit(task, schedule, false, conn);
  }

  /**
   * submit the task to pending queue.
   * 
   * @param task
   * @param schedule
   * @param recurring
   * @param conn
   * @throws VpsException
   */
  static void submit(ExecutionTask task, ISchedule schedule, boolean recurring, ConnectionInterface conn) throws VpsException {
    Long joid = task.getJobScheduleDefOid();
    LogHelper.info("Dispatcher: submit " + task);
    long scheduledExecutionTime = TimeHelper.getTime(schedule);
    if (recurring && (schedule instanceof OnceSchedule)) {
      LogHelper.info("Dispatcher: OnceSchedule has already been executed");
      scheduledExecutionTime = 0; // kinda hack to make this schedule invalid.
    }
    if (scheduledExecutionTime <= 0) {
      LogHelper.info(task + " has no more available schedule, removing from queue permanently.");
      if (task instanceof PersistentExecutionTask) {
        // m_persistent_task_repository.remove(joid);
        try {
          if (task.getPendingTaskOid() != null) {
            if (conn != null) {
              PendingTaskTable.remove(task, conn);
            } else {
              PendingTaskTable.remove(task);
            }
          }
          JobScheduleDefObject jsdo = null;
          if (conn != null) {
            jsdo = JobScheduleDefTable.retrieve(joid, conn);
          } else {
            jsdo = JobScheduleDefTable.retrieve(joid);
          }

          if (jsdo != null) {
            jsdo.setStatus(String.valueOf(ISchedule.STATUS_INACTIVE));
            if (conn != null) {
              JobScheduleDefTable.update(jsdo, conn);
            } else {
              JobScheduleDefTable.update(jsdo);
            }
            LogHelper.info("Job schedule " + joid + " is updated to be inactive.");
          }
        } catch (DatalayerException e) {
          throw new SubmitException(e);
        } catch (Exception ex) {
          LogHelper.error(ex);
          ex.printStackTrace();
        }
      } else {
        m_transient_task_repository.remove(joid);
      }
      return;
    }
    TimeZone.setDefault(TimeZone.getTimeZone("US/Eastern"));
    System.setProperty("user.timezone", "US/Eastern");
    task.setExecuteTime(new Timestamp(scheduledExecutionTime));
    LogHelper.info("Dispatcher: scheduled time is " + task.getExecuteTime() + ", now is " + new Date());
    LogHelper.info("Dispatcher: check if the task is already running");
    try {
      // examing if the same (same pending_task_oid) job is already running,
      // if it is, then don't submit it, let the reschedule process to pick
      // it up. otherwise, cancel the current job if it is still pending,
      // and submit me.
      ScheduledTask task_instance = getActiveTask(joid, task.getPendingTaskOid(), conn);
      char taskStatus = (task_instance == null ? IVpsTask.PHANTOM : task_instance.getStatusChar());
      // LogHelper.info("----------- Check task status " + taskStatus + " on " +
      // task.getPendingTaskOid());
      int recurrence = 0;
      if (joid != null) {
        if (IVpsTask.EXECUTING == taskStatus) {
          LogHelper.info("Task is running, let reschedule process to pick up possible schedule change.");
          return;
        } else if (taskStatus != IVpsTask.PHANTOM) {
          // Adjust recurring status.
          if (task_instance != null) {
            recurrence = task_instance.recurrence + 1;
          } else {
            if (recurring) {
              recurrence = 1;
            }
          }
        }
      }
      ScheduledTask task1 = new ScheduledTask(task);
      task1.scheduledExecutionTime = scheduledExecutionTime; 
      // prevent from precision lost during conversion between Timestamp and Date
      task1.schedule = schedule;
      task1.recurrence = recurrence;
      task1.setStatus(IVpsTask.PENDING);
      LogHelper.info("Dispatcher: adding to the pending queue");
      if (task instanceof PersistentExecutionTask) {
        // m_persistent_task_repository.add(joid, task1);
        boolean addedOk = dbqueue.add(task1, conn);
        LogHelper.info("Dispatcher: adding to dbqueue succeeded? " + addedOk);
        synchronized (dbqueue) {
          dbthread.notified = true;
          dbqueue.notify();
        }
      } else if (task instanceof TransientExecutionTask) {
        LogHelper.info("Dispatcher: adding to transient_task_repository.");
        m_transient_task_repository.add(joid, task1);
        synchronized (queue) {
          queue.add(task1);
          queue.notify();
        }
      } else {
        throw new SubmitException(100, "System error: this is not happening");
      }
    } catch (DatalayerException e) {
      LogHelper.logStacktrace(e);
      throw new SubmitException(e);
    }
  }

  static ScheduledTask getActiveTask(Long job_schedule_def_oid, Long pending_task_oid, ConnectionInterface conn) {
    if (null == job_schedule_def_oid) {
      return null;
    }
    // else if (job_schedule_def_oid.longValue() >= 0) {
    // return m_persistent_task_repository.getActiveTask(job_schedule_def_oid);
    // }
    ScheduledTask activeTask = m_transient_task_repository.getActiveTask(job_schedule_def_oid);
    if (activeTask == null) {
      // if it is in memory, trust it.
      if (pending_task_oid == null) {
        // Must in memory
        return null;
      }
      if (job_schedule_def_oid.longValue() >= 0) {
        // Check db
        try {
          ExecutionTask et = new PersistentExecutionTask();
          et.setPendingTaskOid(pending_task_oid);
          if (conn != null) {
            PendingTaskTable.retrieve(et, conn);
          } else {
            PendingTaskTable.retrieve(et);
          }
          // LogHelper.info("++++++++++++++++++ retrieve for " +
          // et.getPendingTaskOid() + " returns " + et);
          activeTask = new ScheduledTask(et);
        } catch (DatalayerException de) {
        }
      }
    }

    return activeTask;
  }

  /**
   * get schedule info for the pending task. <p>
   * 
   * @param pending_task_oid
   * @return
   */
  static ISchedule getTransientTaskSchedule(Long job_schedule_def_oid) {
    ScheduledTask task = (ScheduledTask)getActiveTask(job_schedule_def_oid, null, null);
    if (task != null) {
      return task.schedule;
    } else {
      return null;
    }
  }

  /**
   * get job status. <p>
   * 
   * @param pending_task_oid
   * @return
   */
  public static char getTaskStatus(Long pending_task_oid, Long job_schedule_def_oid, ConnectionInterface conn) {
    if (pending_task_oid == null) {
      return IVpsTask.PHANTOM;
    }
    ScheduledTask task = (ScheduledTask)getActiveTask(job_schedule_def_oid, pending_task_oid, conn);
    // if it is in memory, trust it.
    if (task != null) {
      return task.getStatusChar();
    } else {
      return IVpsTask.PHANTOM;
    }
  }

  public static boolean isWLSBusy() {
    return m_num_of_exec_threads_used >= Config.getIntProperty("vps.vps", "vps.transient.execution.pool.size", DEFAULT_EXEC_THREAD_MAX_ALLOWED);
  }

  public static int getRunningTransientTaskCount() {
    return m_num_of_exec_threads_used;
  }

  public static int getFinishedTransientTaskCount() {
    return m_transient_task_repository.m_finished_task_count;
  }

  public static int getTransientPendingQueueSize() {
    return queue.size();
  }

  public static int getPersistentPendingQueueSize() {
    return dbqueue.size();
  }

  public static String getTransientTimerThreadStatus() {
    return thread.m_status;
  }

  public static String getPersistentTimerThreadStatus() {
    return dbthread.m_status;
  }

  public static void notifyTransientTimerThread() {
    synchronized (queue) {
      queue.notify();
    }
  }

  public static void notifyPersistentTimerThread() {
    synchronized (dbqueue) {
      dbqueue.notify();
    }
  }

  public static TaskRepository getTransientTaskRepository() {
    return m_transient_task_repository;
  }
  
  public static final void execute(Runnable runnable) {
    APM_POOL.execute(runnable);
  }
  /*
   * public static TaskRepository getPersistentTaskRepository() { return
   * m_persistent_task_repository; }
   */
}
