package com.verizon.enterprise.vps.core;

import com.verizon.enterprise.vps.middleware.TaskDeliverLocal;
import com.verizon.enterprise.vps.util.LogHelper;

/**
 * Timer Thread.
 */
class TimerDBThread extends TimerThread {
  TimerDBThread(TaskDBQueue queue) {
    super(queue);
  }

  public void run() {
    init();
    try {
      // wait for 3 min until transient thread might finish creating seeds for
      // db migration jobs
      sleep(180000);
    } catch (Exception wakeup) {
    }

    while (m_bRunning) {
      try {
        TaskDeliverLocal td = m_local_home.create();
        m_status = STATUS_DELIVER;
        long timeToWait = td.deliverPersistentTask((TaskDBQueue)queue);
        if (notified) {
          timeToWait = 100; // flow control a little bit
          notified = false;
        }

        if (timeToWait > 0) {
          synchronized (queue) {
            LogHelper.info("TimerDBThread sleeps " + timeToWait + " ms.");
            m_status = STATUS_WAITING;
            queue.wait(timeToWait);
          }
        }
      } catch (InterruptedException e2) {
        e2.printStackTrace();
      } catch (Throwable e) {
        e.printStackTrace();
        try {
          sleep(1000);
        } catch (InterruptedException e2) {
        }
      }
    }
    LogHelper.info("TimerDBThread is shutdown.");
  }
}
