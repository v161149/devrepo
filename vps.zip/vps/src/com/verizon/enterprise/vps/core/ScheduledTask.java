package com.verizon.enterprise.vps.core;

/**
 * ScheduledTask wraps ExecutionTask for fast timestamp comparison in queue. <p>
 *
 * <p>Title: VPS</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import java.sql.Timestamp;
import java.util.Date;

import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.util.TimeHelper;
import com.verizon.kernel.exception.DatalayerException;

public class ScheduledTask extends TaskInstanceObject {
  private static final long serialVersionUID = 7750417908812321247L;
  public long scheduledExecutionTime = 0;
  public ExecutionTask m_task; // runnable
  ISchedule schedule;
  // boolean recurring = false;
  // boolean persistent = false;
  int recurrence = 0; // how many times this task has recurred.

  public ScheduledTask(ExecutionTask task) {
    m_task = task;
    scheduledExecutionTime = TimeHelper.getTime(m_task.getExecuteTime());
  }

  public void setStatus(char status) throws DatalayerException {
    m_task.setStatus(new String(new char[] {status}));
  }

  public char getStatusChar() {
    String status = m_task.getStatus();
    if ((null == status) || (status.length() <= 0))
      return IVpsTask.PHANTOM;
    else
      return status.charAt(0);
  }

  public boolean isPersistent() {
    return (m_task instanceof PersistentExecutionTask);
  }

  public int getExecutionCount() {
    return recurrence;
  }

  public String getTaskDescription() {
    try {
      return m_task.getTask().getDescription();
    } catch (Exception e) {
      return "Error: " + e.getMessage();
    }
  }

  public Date getScheduleStartTime() {
    return schedule.getStartEffectiveTime();
  }

  public Date getScheduleEndTime() {
    return schedule.getEndEffectiveTime();
  }

  public Long getPendingTaskOid() {
    return m_task == null ? null : m_task.getPendingTaskOid();
  }

  public Long getJobScheduleDefOid() {
    return m_task == null ? null : m_task.getJobScheduleDefOid();
  }
  
  public String toString() {
    return "ScheduledTask[" + m_task + ", " + new Timestamp(scheduledExecutionTime) + "]";
  }
}
