package com.verizon.enterprise.vps.core;

import com.verizon.enterprise.vps.dataobjects.IVpsInteractiveTask;
import com.verizon.enterprise.vps.dataobjects.IVpsTaskListener;

/**
 * <p>Title: vps</p> <p>Description: vps</p> <p>Copyright: Copyright (c)
 * 2003</p> <p>Company: Verizon</p>
 * 
 * @author cc00
 * @version 1.1
 */

public class InteractiveExecutionTask extends TransientExecutionTask {
  private static final long serialVersionUID = 8277027990838828437L;
  private IVpsTaskListener m_listener;

  public void execute() {
    if (m_listener != null) {
      m_listener.taskStarted();
    }
    super.execute();
    if (m_listener != null) {
      IVpsInteractiveTask task = (IVpsInteractiveTask)getTask();
      if (task.isSuccessful()) {
        m_listener.taskSucceeded(task.getResult());
      } else {
        m_listener.taskFailed(task.getResult());
      }
    }
  }

  public InteractiveExecutionTask(IVpsInteractiveTask task, IVpsTaskListener listener) {
    super(task);
    m_listener = listener;
  }
}