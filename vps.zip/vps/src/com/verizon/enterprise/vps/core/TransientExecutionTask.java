package com.verizon.enterprise.vps.core;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ISchedule;

public class TransientExecutionTask extends ExecutionTask {
  private static final long serialVersionUID = -6426362717576112442L;
  public static final int JMS_EXECUTION_QUEUE = 0;
  public static final int WLS_EXECUTION_QUEUE = 1;

  protected IVpsTask m_task;

  public TransientExecutionTask(IVpsTask task) {
    m_task = task;
  }

  public IVpsTask getTask() {
    return m_task;
  }

  public ISchedule getSchedule() {
    return Dispatcher.getTransientTaskSchedule(getJobScheduleDefOid());
  }

  public void deliver() throws Exception {
    boolean useWLSQueue = true;
    /*
     * try { useWLSQueue = Config.getBooleanProperty("vps",
     * "transient.execution.queue.weblogic", Boolean.TRUE); } catch (Exception
     * ignore) {}
     */
    if (useWLSQueue) {
      deliverToWLSQueue();
    } else {
      super.deliver();
    }
  }
  
  public String toString() {
    return "TransientExecutionTask(" + m_task.getDescription() + ")"; 
  }
}
