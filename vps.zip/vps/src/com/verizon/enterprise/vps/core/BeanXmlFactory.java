package com.verizon.enterprise.vps.core;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.*;
import java.lang.reflect.*;

// JDOM
import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.input.DOMBuilder;
import org.jdom.output.*;

import org.apache.commons.beanutils.*;
import com.verizon.kernel.xml.JDomUtil;
import com.verizon.kernel.xml.XmlHelper;

import com.verizon.enterprise.vps.dataobjects.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Verizon </p>
 * @author Zhong Chen
 * @version 1.0
 */

public class BeanXmlFactory {
    public static final String TAG_ENTRY  = "entry";
    public static final String TAG_KEY    = "key";
    public static final String TAG_VALUE  = "value";
    public static final String TAG_ARG  = "arg";
    public static final String ATTR_TYPE  = "type";
    public static final String ATTR_NAME  = "name";
    static final int MAX_LOOP_CNT = 10;

    /** Build java bean object from XML string */
    public static Object buildJavaBeanFromXml(String sBeanXml) throws Exception {
        Element elem = JDomUtil.parseXmlString(sBeanXml);
        return buildJavaBeanFromXmlElem(elem);
    }

    /** Build java bean object from XML element */
    public static Object buildJavaBeanFromXmlElem(Element elem) throws Exception {
        // Type has to be there.
        String sType = elem.getAttributeValue(ATTR_TYPE);
        if (sType == null || sType.length() == 0) {
            throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Missing type for JavaBean.");
        }

        return buildJavaBeanFromXmlElem(elem, sType);
    }

    /** Build java bean object from XML element */
    public static Object buildJavaBeanFromXmlElem(Element elem, String sType) throws Exception {
        // Create instance
        Class cls = Class.forName(sType);

        // Branch out for collection classes
        if (java.util.Collection.class.isAssignableFrom(cls))
        {
            return buildCollectionFromXmlElem(elem, cls);
        }
        else if (java.util.Map.class.isAssignableFrom(cls))
        {
            return buildMapFromXmlElem(elem, cls);
        }
        else if (cls.equals(java.lang.String.class))
        {
            return new String(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Integer.class))
        {
            return new Integer(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Long.class)) {
            return new Long(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Short.class)) {
            return new Short(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Byte.class)) {
            return new Byte(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Float.class)) {
            return new Float(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Double.class)) {
            return new Double(elem.getTextTrim());
        }
        else if (cls.equals(java.lang.Boolean.class)) {
            return new Boolean(elem.getTextTrim());
        }

        // populate attributes
        Object bean = cls.newInstance();
        String sMemberType;
        Element eChild;
        List qMembers = elem.getChildren();
        Iterator iter = qMembers.iterator();
        while (iter.hasNext()) {
            eChild = (Element)iter.next();
            if (!PropertyUtils.isWriteable(bean, eChild.getName()))
            {
                throw new TaskParsingException(TaskParsingException.PARSING_ERROR,
                                               "Cannot find writable property '" +
                                               eChild.getName() + "' in class '" + cls + "'.");
            }
            sMemberType = eChild.getAttributeValue(ATTR_TYPE);
            if (sMemberType == null || sMemberType.length() == 0 ||
                sMemberType.equalsIgnoreCase("int") ||
                sMemberType.equalsIgnoreCase("integer") ||
                sMemberType.equalsIgnoreCase("long") ||
                sMemberType.equalsIgnoreCase("short") ||
                sMemberType.equalsIgnoreCase("boolean") ||
                sMemberType.equalsIgnoreCase("float") ||
                sMemberType.equalsIgnoreCase("double")
                ) {
                BeanUtils.setProperty(bean, eChild.getName(), eChild.getTextTrim());
            }
            else if (sMemberType.equalsIgnoreCase("string")) {
                // String can be XML
                BeanUtils.setProperty(
                    bean,
                    eChild.getName(),
                    XmlHelper.hasChildren(eChild)? com.verizon.kernel.xml.JDomUtil.getElementString(eChild)
                     : eChild.getText());
            }
            else {
                BeanUtils.setProperty(bean, eChild.getName(), buildJavaBeanFromXmlElem(eChild, sMemberType));
            }
        }

        return bean;
    }

    /** Build collection object from XML element */
    public static Object buildCollectionFromXmlElem(Element elem, Class cls) throws Exception
    {
        Collection qResult = (Collection)cls.newInstance();

        // Expect a list of entries
        Element eEntry;
        List qEntries = elem.getChildren(TAG_ENTRY);
        Iterator iter = qEntries.iterator();
        while (iter.hasNext()) {
            eEntry = (Element)iter.next();
            qResult.add(BeanXmlFactory.buildJavaBeanFromXmlElem(eEntry));
        }

        return qResult;
    }

    /** Build map object from XML element */
    public static Object buildMapFromXmlElem(Element elem, Class cls) throws Exception
    {
        Map qResult = (Map)cls.newInstance();

        // Expect a list of entries
        Element eEntry, eKey, eValue;
        List qEntries = elem.getChildren(TAG_ENTRY);
        Iterator iter = qEntries.iterator();
        while (iter.hasNext()) {
            eEntry = (Element)iter.next();
            eKey = eEntry.getChild(TAG_KEY);
            eValue = eEntry.getChild(TAG_VALUE);
            if (eKey != null && eValue != null) {
                qResult.put(BeanXmlFactory.buildJavaBeanFromXmlElem(eKey),
                            BeanXmlFactory.buildJavaBeanFromXmlElem(eValue));
            }
        }

        return qResult;
    }

    public static String buildXmlFromMap(Map map, String tag, String name)
        throws VpsException
    {
        StringBuffer buf = new StringBuffer();

        if (map == null)
        {
            buf.append(getStartTag(tag, name, null));
            buf.append(getEndTag(tag));

            return buf.toString();
        }

        buf.append(getStartTag(tag, name, map.getClass().getName()));

        Set keySet = map.keySet();
        Iterator keyIter = keySet.iterator();
        Object key;
        Object value;
        while (keyIter.hasNext())
        {
            key = (String)keyIter.next();
            value = map.get(key);
            buf.append(getStartTag(TAG_ENTRY, null, null));
            buf.append(buildXmlFromPrimitiveType(key, TAG_KEY, null));
            buf.append(buildXmlFromObject(value, TAG_VALUE, null, 1));
            buf.append(getEndTag(TAG_ENTRY));
        }

        buf.append(getEndTag(tag));
        return buf.toString();
    }

    public static String buildXmlFromCollection(Collection collection, String tag, String name)
    throws VpsException
    {
        StringBuffer buf = new StringBuffer();

        if (collection == null)
        {
            buf.append(getStartTag(tag, name, null));
            buf.append(getEndTag(tag));

            return buf.toString();
        }

        buf.append(getStartTag(tag, name, collection.getClass().getName()));

        Iterator iter = collection.iterator();
        Object value;

        while (iter.hasNext())
        {
            value = iter.next();
            if (value == null)
                continue;
            buf.append(buildXmlFromObject(value, TAG_ENTRY, null, 1));
        }

        buf.append(getEndTag(tag));
        return buf.toString();
    }

    public static String buildXmlFromPrimitiveType(Object obj, String tag, String name)
    {
        StringBuffer buf = new StringBuffer();

        if (obj == null)
        {
            buf.append(getStartTag(tag, name, null));
            buf.append(getEndTag(tag));

            return buf.toString();
        }

        if (obj.getClass().isPrimitive())
            buf.append(getStartTag(tag, name, null));
        else
            buf.append(getStartTag(tag, name, obj.getClass().getName()));

        if (obj == null)
            buf.append("");
        else if (obj instanceof String)
            buf.append(((String)obj).toString());
        else if (obj instanceof Integer ||
                 obj instanceof Long ||
                 obj instanceof Short)
            buf.append(((Integer)obj).toString());
        else if (obj instanceof Double ||
                 obj instanceof Float)
            buf.append(((Double)obj).toString());
        else if (obj instanceof Byte)
            buf.append(((Byte)obj).toString());
        else if (obj instanceof Boolean)
            buf.append(((Boolean)obj).toString());
        else if (obj instanceof Character)
            buf.append(((Character)obj).toString());
        else
            buf.append(obj);

        buf.append(getEndTag(tag));

        return buf.toString();
    }

    public static String buildXmlFromObject(Object obj, String tag, String name, int loopCnt) throws VpsException
    {
        StringBuffer buf = new StringBuffer();

        if (obj == null)
        {
            buf.append(getStartTag(tag, name, null));
            buf.append(getEndTag(tag));

            return buf.toString();
        }

        if (loopCnt > MAX_LOOP_CNT)
            throw new TaskParsingException(TaskParsingException.PARSING_ERROR, "Java Bean Structure is too deep.");

        Class c = obj.getClass();

        if (isPrimitive(obj))
        {
            //System.out.println("Is primitive.");
            return buildXmlFromPrimitiveType(obj, tag, name);
        }

        Field[] declairedFields = c.getDeclaredFields();
        Method[] declairedMethods = c.getDeclaredMethods();

        Field field;
        Method method;
        //Class type;
        String fieldName;
        String methodName;
        Object result;

        buf.append(getStartTag(tag, name, c.getName()));

        for (int i = 0; i < declairedFields.length; i++)
        {
            field = declairedFields[i];
            fieldName = field.getName();
            if (fieldName == null) continue;
            methodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
            try
            {
                method = c.getMethod(methodName, new Class[]{});
                result = method.invoke(obj, new Object[] {});
                if (result == null)
                {
//                    buf.append(getStartTag(fieldName, null, method.getReturnType().getName()));
//                    buf.append(getEndTag(fieldName));
                }
                else
                {
                    Class cls = result.getClass();
                    if (java.util.Map.class.isAssignableFrom(cls))
                        buf.append(buildXmlFromMap((Map)result, fieldName, null));
                    else if (java.util.Collection.class.isAssignableFrom(cls))
                        buf.append(buildXmlFromCollection((Collection)result, fieldName, null));
                    else
                        buf.append(buildXmlFromObject(result, fieldName, null, loopCnt++));
                }
            }
            catch (NoSuchMethodException nme)
            {
            }
            catch (InvocationTargetException ite)
            {
            }
            catch (IllegalAccessException ia)
            {
            }
        }

        buf.append(getEndTag(tag));

        return buf.toString();
    }

    public static boolean isPrimitive(Object obj)
    {
        if (obj == null) return true;

        Class c = obj.getClass();

        if (c.isPrimitive()) return true;

        if (obj instanceof String ||
            obj instanceof Integer ||
            obj instanceof Long ||
            obj instanceof Short ||
            obj instanceof Double ||
            obj instanceof Float ||
            obj instanceof Byte ||
            obj instanceof Boolean ||
            obj instanceof Character)
            return true;

        return false;
    }

    public static String getStartTag(String tag, String name, String type)
    {
        StringBuffer buf = new StringBuffer();

        buf.append("<");
        buf.append(tag);
        if (name != null && name.trim().length() > 0)
        {
            buf.append(" ");
            buf.append(ATTR_NAME);
            buf.append("=\"");
            buf.append(name);
            buf.append("\"");
        }

        if (type != null && type.trim().length() > 0)
        {
            buf.append(" ");
            buf.append(ATTR_TYPE);
            buf.append("=\"");
            buf.append(type);
            buf.append("\"");
        }
        buf.append(">");

        return buf.toString();
    }

    public static String getEndTag(String tag)
    {
        StringBuffer buf = new StringBuffer();

        buf.append("</");
        buf.append(tag);
        buf.append(">");
        //buf.append("\n");

        return buf.toString();
    }

}
