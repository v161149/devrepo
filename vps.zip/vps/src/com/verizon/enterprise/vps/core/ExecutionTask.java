package com.verizon.enterprise.vps.core;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;

import com.verizon.common.datalayer.ecp.PendingTaskObject;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.util.Domain;
import com.verizon.enterprise.vps.util.JmsHelper;
import com.verizon.enterprise.vps.util.LogHelper;

/**
 * ExecutionTask class defines minimum information for the task to be executed
 * and rescheduled. It is delivered by <code>TimerThread</code> to execution
 * queue, typically a JMS queue. <p>
 * 
 * @author Chunsheng Chen
 * @version 1.0
 */

public abstract class ExecutionTask extends PendingTaskObject implements Serializable {
  private static final long serialVersionUID = -4275566154937760903L;

  // -------------------------------------------------------
  // methods to be removed after schema and datalayer change
  /*
   * private String apmDomainId; public void setApmDomainId(String domainId) {
   * LogHelper.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$set apm domain id to
   * "+(domainId==null?"null":domainId)); apmDomainId = domainId; } public
   * String getApmDomainId() { return apmDomainId; }
   */
  // -------------------------------------------------------
  public void setStatus(char status) {
    setStatus(new String(new char[] {status}));
  }

  public void deliver() throws Exception {
    deliverToJMSQueue();
  }

  protected void deliverToJMSQueue() throws Exception {
    // deliver it to JMS queue for execution
    LogHelper.info("ExecutionTask: delivering to JMS queue" + this);
    // for testing purpose, deliver it to weblogic exeuction queue?
    // weblogic.kernel.Kernel.execute(new VpsExecuteRequest(task));
    JmsHelper.postPersistentMessage(this);
    IVpsTask task = getTask();
    if (task != null)
      LogHelper.info("JMS task submited: " + task.getDescription());
  }

  protected void deliverToWLSQueue() {
    // deliver it to execution queue JMS, weblogic exeuction queue?
    LogHelper.info("ExecutionTask: delivering to corrent thread pool task queue: " + this);
    Dispatcher.m_num_of_exec_threads_used++;
    // submit to weblogic "default" execution queue
    Dispatcher.execute(new VpsExecuteRequest(this));
    try {
      IVpsTask task = getTask();
      if (task != null) {
        LogHelper.info("ExecutionTask: submited to corrent thread pool task queue: " + task.getDescription());
      }
    } catch (Exception ex) {
    }
  }

  public void execute() {
    IVpsTask task = null;
    boolean succeed = false;

    TaskInstanceObject ti;
    if ((ti = Dispatcher.getActiveTask(getJobScheduleDefOid(), null, null)) == null) {
      // in case task lost in the repository (not likely) or task executed
      // in remote JVM (might be for the MDB).
      ti = new TaskInstanceObject();
    }
    ti.setStartTime(new Timestamp(System.currentTimeMillis()));
    try {
      task = getTask();
      if (null != task) {
        LogHelper.info("ExecutionTask: running: " + task);
        beforeStart();
        task.run();
        succeed = true;
      }
    } catch (Exception e) {
      LogHelper.error("Error executing task. ");
      LogHelper.logStacktrace(e);
      String sMsg = null;
      if (e instanceof InvocationTargetException) {
        Throwable te = ((InvocationTargetException)e).getTargetException();
        sMsg = (te == null ? e.getMessage() : (te.getClass().getName() + ": " + te.getMessage()));
      } else {
        sMsg = e.getMessage();
      }
      if (sMsg != null && sMsg.length() > 200)
        sMsg = sMsg.substring(0, 200);
      ti.setMessage(sMsg);
      LogHelper.info("Task instance msg: " + sMsg + ", succeed: " + succeed);
      //throw e;
    } catch (Throwable t) {
      LogHelper.logStacktrace(t);
    } finally {
      ti.setEndTime(new Timestamp(System.currentTimeMillis()));
      if (succeed) {
        ti.setStatus(new String(new char[] {IVpsTask.FINISHED}));
        ti.setMessage(task == null ? "null" : task.getDescription());
      } else {
        ti.setStatus(new String(new char[] {IVpsTask.FAILED}));
      }
      ti.setTimestamp(ti.getEndTime());
      ti.setUserId(getUserId());
      ti.setJobRefOid(this.getJobScheduleDefOid());
      try {
        finishUp(ti);
        Dispatcher.submit(this, getSchedule(), true, null);
      } catch (Throwable it) {
        LogHelper.logStacktrace(it);
      }
    }
  }

  public void beforeStart() throws Exception {
    LogHelper.info("ExecutionTask: before running customer task: " + this);
    setApmDomain(Domain.getDomainId());
  }

  public void finishUp(TaskInstanceObject ti) throws Exception {
    LogHelper.info("ExecutionTask: set status to finish: " + this);
    setStatus(new String(new char[] {IVpsTask.FINISHED}));
    setApmDomain(null);
  }

  public String toString() {
	// db oid should be enough to track down the task info. xml string could be too big.
    return getClass().getName() + "(job_schedule_def_oid=" + this.getJobScheduleDefOid() + ",pending_task_oid=" + this.getPendingTaskOid() + ")";
    //return new XMLOutputter().outputString(this.toXmlElement());
  }

  /**
   * get the runnable IVpsTask to run.
   * 
   * @return runnable IVpsTask
   */
  public abstract IVpsTask getTask();

  /**
   * lookup schedule for this task to regenerate recurring task
   * 
   * @return schedule associated with this task
   */
  public abstract ISchedule getSchedule() throws Exception;

  private class VpsExecuteRequest implements Runnable {
    ExecutionTask _task;

    public VpsExecuteRequest(ExecutionTask task) {
      this._task = task;
    }

    public void run() {
      try {
        LogHelper.info("Begin execution of task=" + _task);
        _task.execute();
        LogHelper.info("Done execution of task=" + _task);
      } finally {
        Dispatcher.m_num_of_exec_threads_used--;
      }
    }
  }
}
