package com.verizon.enterprise.vps.core;

import java.util.Hashtable;

import javax.management.ObjectName;

import weblogic.common.T3ServicesDef;
import weblogic.common.T3StartupDef;

import com.verizon.enterprise.vps.jmx.VpsRuntime;
import com.verizon.enterprise.vps.schedule.OnceSchedule;
import com.verizon.enterprise.vps.schedule.ScheduleManager;
import com.verizon.enterprise.vps.util.JmxHelper;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.enterprise.vps.util.TaskConfigBootstrapTask;

/**
 * <p>Title: VPS</p> <p>Description: </p> <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * 
 * @author Chunsheng Chen
 * @version 1.0
 */

public class DispatcherStartup implements T3StartupDef {
  public DispatcherStartup() {
  }

  public String startup(String name, Hashtable ht) throws Exception {
    // A favor for report project.
    System.setProperty("crystal.enterprise.trace.override", "true");
    try {
      /*
       * MBeanServer mbeanServer = MBeanServerFactory.createMBeanServer( "vps");
       * mbeanServer.createMBean("com.verizon.enterprise.vps.jmx.VpsRuntime",
       * new ObjectName("vps:name=VpsRuntime"));
       */
      weblogic.management.MBeanHome home = JmxHelper.getLocalMBeanHome();
      // ObjectName oname =
      // JmxHelper.getVpsObjectName(home.getMBeanServer().getServerName());
      // System.out.println(home.getMBeanServer().createMBean("com.verizon.enterprise.vps.jmx.VpsRuntime",oname));
      Object mbean = new VpsRuntime();
      ObjectName oname = new ObjectName("operations:name=VpsRuntime");
      home.getMBeanServer().registerMBean(mbean, oname);
    } catch (Exception e) {
      LogHelper.error("VPS MBean error.", e);
    }
    Dispatcher.initialize();
    try {
      new ScheduleManager().scheduleTransientJob(new TaskConfigBootstrapTask(), new OnceSchedule());
    } catch (Exception e) {
      LogHelper.error("Error submit bootstrap jobs.", e);
    }
    return "dispatcher started";
  }

  public void setServices(T3ServicesDef services) {
  }
}