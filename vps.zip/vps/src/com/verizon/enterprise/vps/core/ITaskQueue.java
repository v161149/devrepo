package com.verizon.enterprise.vps.core;

/**
 * Priority queue interface for scheduled tasks.
 *
 * @see ScheduledTask
 */

import com.verizon.kernel.exception.DatalayerException;
import com.verizon.kernel.jdbc.ConnectionInterface;

public interface ITaskQueue {
  /**
   * Returns the first task in the queue without removing it.
   * 
   * @return the first task in the queue, null if no tasks in the queue.
   */
  public ScheduledTask peek() throws DatalayerException;

  public ScheduledTask peek(ConnectionInterface ci) throws DatalayerException;

  /**
   * Add a task into the priority task queue.
   * 
   * @param task the task to add into the queue
   * @return the task added into the queue
   */
  public boolean add(ScheduledTask task) throws DatalayerException;

  public boolean add(ScheduledTask task, ConnectionInterface ci) throws DatalayerException;

  /**
   * Remove the most prioritied task from the queue.
   * 
   * @return true if a task removed from the queue, null if no tasks removed.
   */
  public boolean remove() throws DatalayerException;

  public boolean remove(ConnectionInterface ci) throws DatalayerException;

  /**
   * Remove a particular task from the queue.
   * 
   * @return true if a task removed from the queue, null if no tasks removed.
   */
  // public boolean remove(ScheduledTask task) throws DatalayerException;

  /**
   * update a particular task in the queue. if the schedule of the task changes,
   * the queue will be reshuffled.
   * 
   * @return true if a task removed from the queue, null if no tasks removed.
   */
  // public boolean update(ScheduledTask task) throws DatalayerException;

  /**
   * Number of tasks currently contains in the queue.
   * 
   * @return number of tasks in the queue
   */
  public int size();
}
