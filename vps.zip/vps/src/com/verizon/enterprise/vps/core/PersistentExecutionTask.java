package com.verizon.enterprise.vps.core;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

import com.verizon.common.datalayer.ecp.JobScheduleDefObject;
import com.verizon.common.datalayer.ecp.JobScheduleDefTable;
import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.common.datalayer.ecp.TaskInstanceObject;
import com.verizon.common.datalayer.ecp.TaskInstanceTable;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.dataobjects.XmlPersistentTask;
import com.verizon.enterprise.vps.schedule.ISchedule;
import com.verizon.enterprise.vps.schedule.ScheduleParser;
import com.verizon.enterprise.vps.util.LogHelper;

public class PersistentExecutionTask extends ExecutionTask {
  static final long serialVersionUID = 1410306009836616926L;
  private IVpsTask m_task;

  public PersistentExecutionTask() {
    // setApmDomainId(com.verizon.enterprise.vps.util.Domain.getPersistentApmDomainId());
  }

  public PersistentExecutionTask(IVpsTask task) {
    // this();
    m_task = task;
  }

  public IVpsTask getTask() {
    if (m_task != null) {
      return m_task;
    }

    String sTaskInfo = getTaskInfo();
    try {
      if (sTaskInfo != null && sTaskInfo.startsWith("<exec ")) {
        m_task = XmlPersistentTask.parse(sTaskInfo);
      } else {
        m_task = new XmlPersistentTask(getTaskInfo());
      }
    } catch (Throwable t) {
      LogHelper.logStacktrace(t);
    }
    return m_task;
  }

  public ISchedule getSchedule() {
    ISchedule schedule = null;
    try {
      JobScheduleDefObject job = JobScheduleDefTable.retrieve(getJobScheduleDefOidObject());
      this.setTaskInfo(job.getTaskInfo());
      String schedule_status = job.getStatus();
      if ((null != schedule_status) && (1 == schedule_status.length()) && (ISchedule.STATUS_ACTIVE == schedule_status.charAt(0))) {
        String schedule_info = job.getScheduleInfo();
        if (null != schedule_info) {
          schedule = ScheduleParser.parseSchedule(schedule_info);
          LogHelper.info(schedule.getScheduleInfoString());
        }
      }
    } catch (Exception e) {
      LogHelper.error("error retrieve persistent schedule. ", e);
    }
    return schedule;
  }

  public void beforeStart() throws Exception {
    super.beforeStart();
    PendingTaskTable.update(this);
  }

  public void finishUp(TaskInstanceObject ti) throws Exception {
    super.finishUp(ti);
    PendingTaskTable.update(this);
    try {
      TaskInstanceTable.create(ti);
      LogHelper.info("Task instance created with oid " + ti.getTaskInstanceOid());
    } catch (Throwable ex) {
      LogHelper.warn("Error creating task instance with oid " + ti.getTaskInstanceOid(), ex);
    }
  }

  public void setStatus(String s) {
    LogHelper.info("Update status to " + s + " for " + this);
    super.setStatus(s);
  }
}
