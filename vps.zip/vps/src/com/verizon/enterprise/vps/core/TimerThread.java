package com.verizon.enterprise.vps.core;

import com.verizon.enterprise.vps.middleware.TaskDeliverHome;
import com.verizon.enterprise.vps.middleware.TaskDeliverLocal;
import com.verizon.enterprise.vps.middleware.TaskDeliverLocalHome;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.ejb.EJBHomeFactory;
import com.verizon.kernel.ejb.EJBLocalHomeFactory;

/**
 * Timer Thread.
 */
class TimerThread extends Thread {
  /**
   * Our Timer's queue. We store this reference in preference to a reference to
   * the Timer so the reference graph remains acyclic. Otherwise, the Timer
   * would never be garbage-collected and this thread would never go away.
   */
  protected ITaskQueue queue;
  public static final String TASK_DELIVER_LOCAL_JNDI = "enterprise.TaskDeliverLocal";
  protected TaskDeliverLocalHome m_local_home;
  String m_status;
  protected boolean m_bRunning = true;
  boolean notified = false; // In case we lose notify signal if peek() is slow.
  public static final String STATUS_INITIAL = "initial";
  public static final String STATUS_DELIVER = "deliver";
  public static final String STATUS_WAITING = "waiting";

  TimerThread(ITaskQueue queue) {
    this.queue = queue;
    this.setDaemon(true);
    this.start();
  }

  protected void init() {
    Runtime.getRuntime().addShutdownHook(new Thread() {
      public void run() {
        LogHelper.info("Shutting down timer threads.");
        m_bRunning = false;
      }
    });
    m_status = STATUS_INITIAL;
    String TASK_DELIVER_JNDI = "enterprise.TaskDeliver";
    LogHelper.info("Starting " + getClass().getName());
    // Sleep at start up time.
    while (m_local_home == null) {
      try {
        Thread.sleep(10000);
        TaskDeliverHome m_home = (TaskDeliverHome)EJBHomeFactory.getFactory().lookUpHome(TASK_DELIVER_JNDI, TASK_DELIVER_JNDI);
        m_home.create().initLocalHome();
        m_local_home = (TaskDeliverLocalHome)EJBLocalHomeFactory.getFactory().lookUpHome(TASK_DELIVER_LOCAL_JNDI, TASK_DELIVER_LOCAL_JNDI);
      } catch (Throwable ex) {
        LogHelper.warn("Retrying JNDI lookup due to exception: ", ex);
      }
    }
    LogHelper.info("Started " + getClass().getName());
  }

  public void run() {
    init();
    while (m_bRunning) {
      try {
        TaskDeliverLocal td = m_local_home.create();
        synchronized (queue) {
          m_status = STATUS_DELIVER;
          long timeToWait = td.deliverTransientTask((TaskQueue)queue);
          if (notified) {
            timeToWait = 100; // flow control a little bit
            notified = false;
          }
          if (timeToWait > 0) {
            LogHelper.info("TimerThread sleeps " + timeToWait + " ms.");
            m_status = STATUS_WAITING;
            queue.wait(timeToWait);
          }
        }
      } catch (InterruptedException e2) {
        e2.printStackTrace();
      } catch (Throwable e) {
        e.printStackTrace();
        try {
          sleep(1000);
        } catch (InterruptedException e2) {
        }
      }
    }
    LogHelper.info("Timer thread is shutdown.");
  }
}
