package com.verizon.enterprise.vps.core;

import com.verizon.kernel.jdbc.ConnectionInterface;

/**
 * This class represents a scheduled (pending) task queue: a priority queue of
 * ScheduledTask, ordered on scheduledExecutionTime. Each TimerThread object has
 * one of these, one for in-memory tasks, one for DB tasks. Internally this
 * class uses a heap, which offers log(n) performance for the add, remove
 * operations, and constant time performance for the peek operation.
 */
public class TaskQueue implements ITaskQueue {
  /**
   * Priority queue represented as a balanced binary heap: the two children of
   * queue[n] are queue[2*n] and queue[2*n+1]. The priority queue is ordered on
   * the ScheduledTask.scheduledExecutionTime field: The TimerTask with the
   * lowest scheduledExecutionTime is in queue[1] (assuming the queue is
   * nonempty). For each node n in the heap, and each descendant of n, d,
   * n.scheduledExecutionTime <= d.scheduledExecutionTime.
   */
  protected ScheduledTask[] queue;

  /**
   * The number of tasks in the priority queue. (The tasks are stored in
   * queue[1] up to queue[size]).
   */
  private int size = 0;

  public TaskQueue() {
    this(128);
  }

  public TaskQueue(int initial_capacity) {
    queue = new ScheduledTask[initial_capacity];
  }

  /**
   * Adds a new task to the priority queue.
   */
  public boolean add(ScheduledTask task, ConnectionInterface ci) {
    return add(task);
  }

  public boolean add(ScheduledTask task) {
    if (task.recurrence > 0) {
      remove(task);
    }
    // Grow backing store if necessary
    if (++size == queue.length) {
      ScheduledTask[] newQueue = new ScheduledTask[2 * queue.length];
      System.arraycopy(queue, 0, newQueue, 0, size);
      queue = newQueue;
    }

    queue[size] = task;
    fixUp(size);
    return true;
  }

  /**
   * Return the "head task" of the priority queue. (The head task is an task
   * with the lowest scheduledExecutionTime.)
   */
  public ScheduledTask peek(ConnectionInterface ci) {
    return peek();
  }

  public ScheduledTask peek() {
    return queue[1];
  }

  /**
   * Remove the head task from the priority queue.
   */
  public boolean remove(ConnectionInterface ci) {
    return remove();
  }

  public boolean remove() {
    ScheduledTask task = queue[1];
    queue[1] = queue[size];
    queue[size--] = null; // Drop extra reference to prevent memory leak
    fixDown(1);
    return true;
  }

  public boolean remove(ScheduledTask task) {
    for (int i = 1; i <= size; i++) {
      if (queue[i].m_task.getPendingTaskOid().longValue() == task.m_task.getPendingTaskOid().longValue()) {
        queue[i] = queue[size];
        queue[size--] = null;
        fixDown(i);
        return true;
      }
    }
    return false;
  }

  public boolean update(ScheduledTask task) {
    if (remove(task)) {
      return add(task);
    } else {
      return false;
    }
  }

  /**
   * Returns true if the priority queue contains no elements.
   */
  public boolean isEmpty() {
    return size == 0;
  }

  /**
   * Removes all elements from the priority queue.
   */
  public void clear() {
    // Null out task references to prevent memory leak
    for (int i = 1; i <= size; i++)
      queue[i] = null;

    size = 0;
  }

  /**
   * Establishes the heap invariant (described above) assuming the heap
   * satisfies the invariant except possibly for the leaf-node indexed by k
   * (which may have a scheduledExecutionTime less than its parent's). This
   * method functions by "promoting" queue[k] up the hierarchy (by swapping it
   * with its parent) repeatedly until queue[k]'s scheduledExecutionTime is
   * greater than or equal to that of its parent.
   */
  protected void fixUp(int k) {
    while (k > 1) {
      int j = k >> 1;
      if (queue[j].scheduledExecutionTime <= queue[k].scheduledExecutionTime)
        break;
      ScheduledTask tmp = queue[j];
      queue[j] = queue[k];
      queue[k] = tmp;
      k = j;
    }
  }

  /**
   * Establishes the heap invariant (described above) in the subtree rooted at
   * k, which is assumed to satisfy the heap invariant except possibly for node
   * k itself (which may have a scheduledExecutionTime greater than its
   * children's). This method functions by "demoting" queue[k] down the
   * hierarchy (by swapping it with its smaller child) repeatedly until
   * queue[k]'s scheduledExecutionTime is less than or equal to those of its
   * children.
   */
  protected void fixDown(int k) {
    int j;
    while ((j = k << 1) <= size) {
      if (j < size && queue[j].scheduledExecutionTime > queue[j + 1].scheduledExecutionTime)
        j++; // j indexes smallest kid
      if (queue[k].scheduledExecutionTime <= queue[j].scheduledExecutionTime)
        break;
      ScheduledTask tmp = queue[j];
      queue[j] = queue[k];
      queue[k] = tmp;
      k = j;
    }
  }

  public int size() {
    return size;
  }
}
