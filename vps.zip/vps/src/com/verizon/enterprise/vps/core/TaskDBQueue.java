package com.verizon.enterprise.vps.core;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.verizon.common.datalayer.ecp.PendingTaskTable;
import com.verizon.enterprise.vps.dataobjects.IVpsTask;
import com.verizon.enterprise.vps.util.DbHelper;
import com.verizon.enterprise.vps.util.LogHelper;
import com.verizon.kernel.exception.DatalayerException;
import com.verizon.kernel.jdbc.ConnectionInterface;

public class TaskDBQueue implements ITaskQueue {
  // public static final String GET_FIRST_TASK_SQL =
  // Config.getProperty("vps.vps", "vps.sql.GET_FIRST_TASK_SQL");
  // private static final int DELAYED_HOUR = 2;
  //private static final String GET_FIRST_TASK_SQL = "SELECT * FROM pending_task WHERE pending_task_oid IN(SELECT pending_task_oid FROM(SELECT pending_task_oid FROM PENDING_TASK WHERE status='A' ORDER BY execute_time)WHERE ROWNUM <= 1) FOR UPDATE";
  private static final String GET_FIRST_TASK_SQL = "select pending_task_oid from pending_task where status='A' and execute_time=(select min(execute_time) from pending_task where status='A') for update";
  private ScheduledTask m_the_first_ready_task = null;

  public ScheduledTask peek() throws DatalayerException {
    ConnectionInterface ci = null;
    try {
      ci = DbHelper.getConnection();
      return peek(ci);
    } finally {
      if (null != ci) {
        ci.close();
        ci = null;
      }
    }
  }

  public ScheduledTask peek(ConnectionInterface ci) throws DatalayerException {
    LogHelper.info("TaskDBQueue: Peek for the first available task.");
    m_the_first_ready_task = null;
    PreparedStatement ps = null;
    boolean task_found = false;
    long the_first_pending_task_oid = -1;
    try {
      ps = ci.getConnection().prepareStatement(GET_FIRST_TASK_SQL);
      // ps.setTimestamp(1, new Timestamp(System.currentTimeMillis() -
      // DELAYED_HOUR * 3600000L));
      ResultSet rs = ps.executeQuery();
      if (rs.next()) {
        the_first_pending_task_oid = rs.getLong(1);
        LogHelper.info("peeking pending task " + the_first_pending_task_oid);
        task_found = true;
      }
    } catch (SQLException e) {
      throw new DatalayerException("SQL exception", ScheduledTask.class, e);
    } finally {
      try {
        if (ps != null) {
          ps.close();
        }
      } catch (SQLException warning) {
      }
    }
    if (task_found) {
      ExecutionTask task0 = new PersistentExecutionTask();
      task0.setPendingTaskOid(new Long(the_first_pending_task_oid));
      task0 = (ExecutionTask)PendingTaskTable.retrieve(task0, ci);
      m_the_first_ready_task = new ScheduledTask(task0);
    }
    /*
     * //Wait for Datalayer enhances support to "select for update"
     * java.util.List lst = ScheduledDBTaskTable.search(WHERE_CLAUSE,
     * m_connection_interface); if (lst.size()<1) return null; ScheduledDBTask
     * task = (ScheduledDBTask) lst.get(0);
     */
    return m_the_first_ready_task;
  }

  public boolean remove(ScheduledTask task) throws DatalayerException {
    return remove(task, null);
  }

  public boolean remove(ScheduledTask task, ConnectionInterface ci) throws DatalayerException {
    LogHelper.info("TaskDBQueue: Remove task " + task.m_task.getPendingTaskOid());
    task.setStatus(IVpsTask.EXECUTING);
    if (null != ci)
      return (PendingTaskTable.update(task.m_task, ci) > 0);
    else
      return (PendingTaskTable.update(task.m_task) > 0);
  }

  public boolean remove() throws DatalayerException {
    return remove((ConnectionInterface)null);
  }

  public boolean remove(ConnectionInterface ci) throws com.verizon.kernel.exception.DatalayerException {
    return ((m_the_first_ready_task != null) && remove(m_the_first_ready_task, ci));
  }

  public boolean add(ScheduledTask task) throws DatalayerException {
    return add(task, null);
  }

  public boolean add(ScheduledTask task, ConnectionInterface ci) throws DatalayerException {
    // for add operation, we use a seperate db connection
    // so to not interfere with peek/remove operations.
    //
    // add operations may be just an update operation if it is rescheduling
    LogHelper.info("TaskDBQueue: Add/Recur task " + task.m_task.getPendingTaskOid() + ", recurring=" + task.recurrence);
    if (task.recurrence > 0) {
      // should be update ... where status = 'A', which is safer
      if (null != ci)
        return (PendingTaskTable.update(task.m_task, ci) > 0);
      else
        return (PendingTaskTable.update(task.m_task) > 0);
    } else {
      if (null != ci)
        return (PendingTaskTable.create(task.m_task, ci) > 0);
      else
        return (PendingTaskTable.create(task.m_task) > 0);
    }
  }

  public boolean update(ScheduledTask task) throws DatalayerException {
    return update(task, null);
  }

  public boolean update(ScheduledTask task, ConnectionInterface ci) throws DatalayerException {
    // should be update ... where status = 'A', which is safer
    LogHelper.info("TaskDBQueue: Update task " + task.m_task.getPendingTaskOid());
    if (null != ci)
      return (PendingTaskTable.update(task.m_task, ci) > 0);
    else
      return (PendingTaskTable.update(task.m_task) > 0);
  }

  public int size() {
    return DbHelper.getNumTasksOfStatus(IVpsTask.PENDING);
  }
}
