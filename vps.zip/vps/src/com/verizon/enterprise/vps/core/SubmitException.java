package com.verizon.enterprise.vps.core;

import com.verizon.enterprise.vps.dataobjects.*;


/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author Chunsheng Chen
 * @version 1.0
 */

public class SubmitException extends VpsException
{
    // Error codes
    public static final int GENERIC_SUBMIT_ERROR = 1;
    public static final int LAST_ERROR           = 2;

// Error messages
    private static String[] ms_qErrMsg = null;

// Init error messages
    static {
        ms_qErrMsg = new String[LAST_ERROR];
        ms_qErrMsg[GENERIC_SUBMIT_ERROR] = "Submit error: ?.";
    }

    /**
     * Contractor.
     */
    protected String[] getAllErrorMessages() {return ms_qErrMsg;}

    /** Constructor */
    public SubmitException(int nErrCode) {
        super(nErrCode, null, null, null);
    }

    /** Constructor */
    public SubmitException(int nErrCode, String sMsg1) {
        super(nErrCode, sMsg1, null, null);
    }

    /** Constructor */
    public SubmitException(int nErrCode, String sMsg1, String sMsg2) {
        super(nErrCode, sMsg1, sMsg2, null);
    }

    /** Constructor */
    public SubmitException(int nErrCode, String sMsg1, String sMsg2, String sMsg3) {
        super(nErrCode, sMsg1, sMsg2, sMsg3);
    }

    public SubmitException(Exception e)
    {
        this(GENERIC_SUBMIT_ERROR, e.getMessage());
		e.printStackTrace();
    }

}
