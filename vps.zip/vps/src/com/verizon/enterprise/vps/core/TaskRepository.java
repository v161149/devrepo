package com.verizon.enterprise.vps.core;

import java.util.Collection;
import java.util.Hashtable;

import com.verizon.enterprise.vps.util.LogHelper;

/**
 * This class stores historic information about finished jobs. <p>Title: vps</p>
 * <p>Description: vps</p> <p>Copyright: Copyright (c) 2003</p> <p>Company:
 * Verizon</p>
 * 
 * @author cc00
 * @version 1.1
 */
public class TaskRepository {
  private Hashtable m_scheduled_tasks = new Hashtable();
  private TaskHistory m_task_history = new TaskHistory();

  int m_finished_task_count = 0;

  public TaskTrackingObject[] getCurrentTasks() {
    Collection tasks = m_scheduled_tasks.values();
    Object[] o = tasks.toArray();
    // LogHelper.debug("JJMMXX got "+o.length+" current tasks");
    TaskTrackingObject[] t = new TaskTrackingObject[o.length];
    for (int i = 0; i < t.length; i++) {
      t[i] = new TaskTrackingObject((ScheduledTask)o[i]);
    }
    return t;
  }

  public TaskTrackingObject[] getTaskHistory() {
    return m_task_history.list();
  }

  void add(Long oid, ScheduledTask task) {
    if (null != oid) {
      ScheduledTask oldtask = (ScheduledTask)m_scheduled_tasks.put(oid, task);
      if (oldtask != null) {
        m_task_history.add(oldtask);
      }
    }
  }

  void remove(Long oid) {
    m_finished_task_count++;
    if (null != oid) {
      ScheduledTask task = (ScheduledTask)m_scheduled_tasks.remove(oid);
      if (task != null) {
        m_task_history.add(task);
      } else {
        LogHelper.warn("Failed to remove " + oid);
      }
    }
  }

  ScheduledTask getActiveTask(Long oid) {
    return oid == null ? null : (ScheduledTask)m_scheduled_tasks.get(oid);
  }

  // defines a circular array structure
  static class TaskHistory {
    public static final int CAPACITY = 20;
    private ScheduledTask[] m_historic_tasks = new ScheduledTask[CAPACITY];
    private int m_start = 0;
    private int m_offset = 0;
    private boolean m_bEmpty = true;

    synchronized void add(ScheduledTask task) {
      if (m_bEmpty) {
        m_historic_tasks[0] = task;
        m_bEmpty = false;
      } else {
        if (++m_offset >= CAPACITY) {
          m_offset = 0;
        }
        if (m_start == m_offset) {
          if (++m_start >= CAPACITY) {
            m_start = 0;
          }
        }
        m_historic_tasks[m_offset] = task;
      }
    }

    public synchronized TaskTrackingObject[] list() {
      int size = m_offset - m_start;
      if (size < 0) {
        size += CAPACITY;
      }
      if (!m_bEmpty) {
        size++;
      }
      TaskTrackingObject[] list = new TaskTrackingObject[size];
      for (int i = 0; i < size; i++) {
        list[i] = new TaskTrackingObject(m_historic_tasks[(m_start + i) % CAPACITY]);
      }
      return list;
    }
  }
}