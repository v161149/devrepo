package com.verizon.enterprise.vps.core;

import java.util.Date;
import java.util.Date;
import java.sql.Timestamp;
import com.verizon.enterprise.vps.core.ScheduledTask;

/**
 * <p>Title: vps</p>
 * <p>Description: vps</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Verizon</p>
 * @author cc00
 * @version 1.1
 */

public class TaskTrackingObject implements java.io.Serializable
{
    private Date sstart;
    private Date send;
    private Timestamp start;
    private Timestamp end;
    private String status;
    private String desc;
    private int ecount;
    private Long userid;
    private Long joid;

    public TaskTrackingObject(ScheduledTask t)
    {
        sstart = t.getScheduleStartTime();
        send = t.getScheduleEndTime();
        start = t.getStartTime();
        end = t.getEndTime();
        status = t.getStatus();
        desc = t.getTaskDescription();
        ecount = t.getExecutionCount();
        userid = t.getUserId();
        joid = t.getJobScheduleDefOid();
    }
    public Long getJobScheduleDefOid() {return joid;}
    public Date getScheduleStartTime() {return sstart;}
    public Date getScheduleEndTime() {return send;}
    public Timestamp getStartTime() {return start;}
    public Timestamp getEndTime() {return end;}
    public String getStatus() {return status;}
    public String getTaskDescription() {return desc;}
    public int getExecutionCount() {return ecount;}
    public Long getUserId() {return userid;}
}
