
var ie4 = (document.all) ? true : false;
var ns4 = (document.layers) ? true : false;
var ns6 = (document.getElementById && !document.all) ? true : false;
var isDHTML = 0;
var isLayers = 0;
var isAll = 0;
var isID = 0;

if (document.getElementById) {isID = 1; isDHTML = 1;}
else {
    if (document.all) {isAll = 1; isDHTML = 1;}
    else {
	browserVersion = parseInt(navigator.appVersion);
	if ((navigator.appName.indexOf('Netscape') != -1) && (browserVersion == 4)) {isLayers = 1; isDHTML = 1;}
    }
}

function showAvailableTokens(lay) {
    
    if (ie4) {document.all[lay].style.visibility = "visible";}
    if (ns4) {document.layers[lay].visibility = "show";}
    if (ns6) {document.getElementById([lay]).style.display = "block";}
}

function findDOM(objectID,withStyle) {
    if (withStyle == 1) {
	if (isID) { return (document.getElementById(objectID).style) ; }
	else { 
	    if (isAll) { return (document.all[objectID].style); }
	    else {
		if (isLayers) { return (document.layers[objectID]); }
	    };}
    }
    else {
	if (isID) { return (document.getElementById(objectID)) ; }
	else { 
		if (isAll) { return (document.all[objectID]); }
		else {
		    if (isLayers) { return (document.layers[objectID]); }
		};}
    }
}

function setLayer(objectID, layerNum) {
	 var domStyle = findDOM(objectID, 1);
	 domStyle.zIndex = layerNum; 
}

function setVisibility(objectID, state) {
    var dom = findDOM(objectID, 1);
    dom.visibility = state;
}

function describeNode (dataNode) {
    //alert ("dataNode = " + dataNode);
    document.forms["nnTreeForm"].elements["linkClicked"].value = dataNode;
    document.forms["nnTreeForm"].submit();
}

function openPopup(targetURL, newWindowName, width, height) {
    var windowprops = "width=" + width + ",height=" + height +",scrollbars=yes,resizable=yes";
    popup = window.open(targetURL, newWindowName, windowprops);
    setTimeout('popup.focus();',250);
}

function openScheduleSetup(targetURL, newWindowName, width, height) {
    var windowprops = "width=" + width + ",height=" + height +",scrollbars=yes,resizable=yes";
    popup = window.open(targetURL, newWindowName, windowprops);
    setTimeout('popup.focus();',250);
}

function osCommandValidate(osCommand) {
    if (osCommand.indexOf("/VZ/") != 0) {
	alert("OS commands have to begin with \"/VZ/\".");
	return false;
    }
    else if (osCommand.indexOf(";") > 0 
	|| osCommand.indexOf("..") > 0 
	|| osCommand.indexOf("|") > 0 ) {
	alert("OS commands can not contain ; .. or |.");
	return false;
    }
    else {
	return true;
    }
}

function monitorDetail(aLink)
{
    //alert ("aLink = " + aLink);
    document.forms["MonitorForm"].elements["linkClicked"].value = aLink;
    document.forms["MonitorForm"].submit();
}

function monitorTab(aTab)
{
    //alert ("aTab = " + aTab);
    document.forms["MonitorForm"].elements["tabClicked"].value = aTab;
    document.forms["MonitorForm"].submit();
}
