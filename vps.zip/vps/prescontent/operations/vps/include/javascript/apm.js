var taskQue = new Array();
var currentHttp;
var servlet;
var finishedTaskName;
var startOpening = false;
var connectionFinished = false;

function registerTaskInQueue(taskName, maxWaitingSec, callBackFunc) {
    // alert ("taskName" + taskName + ", maxWaitingSec" + maxWaitingSec + ", callBackFunc" + callBackFunc);
    taskQue.push([taskName, maxWaitingSec, callBackFunc]);
}

function start(servletURL) {
    servlet = servletURL;
    openConnection();
}

function openConnection() {
    
    if (currentHttp != undefined){
	currentHttp.abort();
    }
    else {
	currentHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    arguements = makeupArguements();
    var servletURL = servlet + arguements;
    //alert ("Open connection to " + servletURL);
    startOpening = true;
    currentHttp.Open("POST", servletURL, true);
    currentHttp.onreadystatechange = function () { responseCallBack();}
    currentHttp.send();
    startOpening = false;
}


function responseCallBack() {
    
    if (currentHttp.readyState == 4
	|| currentHttp.readyState == 'complete') {
	finishedTaskName = currentHttp.getResponseHeader("FinishedTaskName");
	task = findTaskAmongTaskQue(finishedTaskName); //the queue will be reduced by one if task is found
	if (task != undefined) {
	    task[2](currentHttp.responseText);
	}

	connectionFinished = true;	
	
	if (taskQue.length != 0){
	    openConnection();
	} 
    }
}

function findTaskAmongTaskQue(taskName) {
    var length = taskQue.length;
    var task;
    var tempQue = new Array();

    for (i=0; i<length; i++) {
	if (taskName == taskQue[i][0]) {
	    task = taskQue[i];
	}
	else {
	    tempQue.push(taskQue[i]);
	}
    }
    
    taskQue = tempQue;

    return task;
}

function makeupArguements() {
    var length = taskQue.length;
    var taskNames;
    var maxWaitingSecs;
    
    for (i=0; i<length; i++) {
	if (i==0) {
	    taskNames = taskQue[i][0];
	    maxWaitingSecs = taskQue[i][1];
	}
	else {
	    taskNames = taskNames + '$' + taskQue[i][0];
	    maxWaitingSecs = maxWaitingSecs  + '$' + taskQue[i][1];
	}
    }

    if (finishedTaskName == undefined)
	return '?taskNames=' + taskNames + '&maxWaitingSecs=' + maxWaitingSecs + '&finishedTaskName=';
    else
	return '?taskNames=' + taskNames + '&maxWaitingSecs=' + maxWaitingSecs + '&finishedTaskName=' + finishedTaskName;
}





























