package com.myndscript.springboot.common.context;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StandardContextDeserializer {
    private static final Logger LOGGER = LoggerFactory.getLogger(StandardContextDeserializer.class);
    public StandardContext deserialize(byte[] arg1) {
      ObjectMapper mapper = new ObjectMapper();
      StandardContext context = null;
      try {
        context = mapper.readValue(arg1, StandardContext.class);
      } catch (Exception e) {
          LOGGER.error(e.getMessage());
      }
      return context;
    }
}
