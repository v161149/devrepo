package com.myndscript.springboot.queries;

import com.myndscript.springboot.common.Constants;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.Date;
import java.util.Random;
import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import com.myndscript.springboot.dto.*;
import com.myndscript.springboot.common.context.*;
import com.myndscript.springboot.jdbc.OracleConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.myndscript.springboot.common.Constants;

public class QueryManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(QueryManager.class);
	
	public static JWTUserDetails getUserInfo(IContext context) throws Exception {
		String FETCH_USER_INFO = "SELECT * FROM JEFFREY.DEV_SECURITY_USER WHERE EMPLID=?";
		Connection conn = null;
		PreparedStatement ps = null;   
		ResultSet rs = null;
		JWTUserDetails resp = new JWTUserDetails();
		
		try {
			JwtRequest request = context.getJwtRequest();
			OracleConfiguration orclConfig = context.getOracleConfiguration();
			DataSource ds= orclConfig.dataSource();
			conn = ds.getConnection();
			ps = conn.prepareStatement(FETCH_USER_INFO);
			ps.setString(1, request.getEmplId());		
			rs = ps.executeQuery();
			while (rs.next()) {
				resp.setFirstName(rs.getString("FIRSTNAME"));
				resp.setLastname(rs.getString("LASTNAME"));
				resp.setEmailId(rs.getString("EMAILID"));
				break;
			}
			ps.close();
		} catch (Exception e) {
			throw e;
		} finally {
			releaseDBResource(conn, ps, null, null);
		}
		return resp;
	}
	
	public static StockResponseDTO getRealTimeStockPrice(IContext context) throws Exception {
    	StockResponseDTO resp = new StockResponseDTO();
    	try {
    		StockRequestDTO stockInfo = context.getStockRequestDTO();
	    	resp.setStockQuote(stockInfo.getStockQuote());
	    	resp.setStockExchange(stockInfo.getStockExchange());
	    	Date now = new Date();
	    	resp.setTradeDate(DateFormat.getDateTimeInstance().format(now));
	    	double random = new Random().nextDouble();
	    	double result = Double.parseDouble(String.format("%.2f", (random*(Constants.MAX_VALUE - Constants.MIN_VALUE)+Constants.MIN_VALUE)));
	    	resp.setPrice(result);
	    	LOGGER.info("getRealTimeStockPriceSyncApi is invoked..");
    	} catch (Exception exp) {
    		exp.printStackTrace();
    	}
        return resp;		
	}
	
	public static StockResponseDTO fetchLatestStockQuote(IContext context) throws Exception {
		String FETCH_STOCK_QUOTE = "SELECT * FROM JEFFREY.DEV_STOCK_HIST WHERE STOCK_SYMBOL=? AND ROWNUM=1 ORDER BY DATE_TIME DESC";
		Connection conn = null;
		PreparedStatement ps = null;   
		ResultSet rs = null;
		StockResponseDTO resp = new StockResponseDTO();
		
		try {
			StockRequestDTO stockInfo = context.getStockRequestDTO();
			resp.setStockQuote(stockInfo.getStockQuote());
			resp.setStockExchange(stockInfo.getStockExchange());		
			OracleConfiguration orclConfig = context.getOracleConfiguration();
			DataSource ds= orclConfig.dataSource();
			conn = ds.getConnection();
			ps = conn.prepareStatement(FETCH_STOCK_QUOTE);
			ps.setString(1, stockInfo.getStockQuote());		
			rs = ps.executeQuery();
			while (rs.next()) {
				resp.setPrice(rs.getDouble("STOCK_PRICE"));
				resp.setTradeDate(DateFormat.getDateTimeInstance().format(rs.getTimestamp("DATE_TIME")));
				break;
			}
			ps.close();
		} catch (Exception e) {
			throw e;
		} finally {
			releaseDBResource(conn, ps, null, null);
		}
		return resp;
	}
	
	public static void releaseDBResource(Connection conn, PreparedStatement statement, Statement dtatement2, ResultSet resultset)  {
		try {
			if(resultset!=null) {
				resultset.close();
				resultset=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			if(dtatement2!=null) {
				dtatement2.close();
				dtatement2=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			if(statement!=null) {
				statement.close();
				statement=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			if(conn!=null) {
				conn.close();
				conn=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}		
	}
}
