package com.myndscript.springboot.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Date;

@XmlRootElement(name = "StockResponseDTO")
public class StockRequestDTO implements Serializable{
	private static final long serialversionUID = 129348938L;
    @XmlAttribute(name = "stockQuote", required=true)
    private String stockQuote;
    @XmlElement(name = "stockExchange", required=true)
    private String stockExchange;
    
    public String getStockQuote() {
    	return stockQuote;
    }
    public void setStockQuote(String param) {
    	this.stockQuote=param;
    }
    
    public String getStockExchange() {
    	return stockExchange;
    }
    public void setStockExchange(String param) {
    	this.stockExchange=param;
    }
}
