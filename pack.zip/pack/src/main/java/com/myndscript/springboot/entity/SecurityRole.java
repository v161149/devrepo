package com.myndscript.springboot.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the DEV_SECURITY_ROLE database table.
 * 
 */
@Entity
@Table(name="DEV_SECURITY_ROLE")
public class SecurityRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="DEV_SECURITY_ROLE_ID_GENERATOR", sequenceName="DEV_SECURITY_ROLE_ID_SEQUENCE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DEV_SECURITY_ROLE_ID_GENERATOR")
	private long id;

	@Column(name="description")
	private String description;

	@Column(name="name")
	private String name;

	//bi-directional many-to-many association to DevSecurityUser
	@ManyToMany(mappedBy="securityRoles", fetch=FetchType.EAGER)
	private List<SecurityUser> securityUsers;

	public SecurityRole() {}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SecurityUser> getSecurityUsers() {
		return this.securityUsers;
	}

	public void setSecurityUsers(List<SecurityUser> securityUsers) {
		this.securityUsers = securityUsers;
	}

}