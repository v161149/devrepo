package com.myndscript.springboot.security.jwt;

import java.util.LinkedHashMap;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.myndscript.springboot.dto.*;
import io.jsonwebtoken.Jwts;
import javax.xml.bind.DatatypeConverter;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.SignatureAlgorithm;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import com.myndscript.springboot.common.context.*;

public class JWTTokenApis {
	private static String STATUS_SUCCESS="SUCCESS";
	private static String SUBJECT_PAYLOAD="PAYLOAD";
	private static String PAYLOAD_KEY_ID="PAYLOAD_ID";
	
    //secret key should be stored in db or server.
	//but for demo purpose, we store it in the code
	private static String DEMO_SECRET_KEY="2dfefefht35655VBKJGHED2";
	public static String getDemoSecretKey(String clientId) throws Exception { 
		return DEMO_SECRET_KEY; 
	} 
	
	public static String getSecretKey(String clientId) throws Exception { 
		String value = null; 
		value = System.getenv(clientId); 
		return value; 
	} 
	
	public static JWTToken generateJwtToken(JwtRequest koreJwt, JWTUserDetails userDetails, StandardContext payload) throws Exception { 	
		String secretKey = getDemoSecretKey(koreJwt.getClientId());// DEMO code!!
		//String secretKey = getSecretKey(koreJwt.getClientId()); //Real code!!
		
		JWTToken jwtResponse = new JWTToken();
		Claims claims = null;
		if (userDetails != null) { 
			Map<String, Object> header = new HashMap<>(); 
			header.put("alg", "HS256"); 
			header.put("typ", "JWT"); 
			header.put("fName", userDetails.getFirstName()); 
			header.put("lName", userDetails.getLastname()); 
		    byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secretKey);
		    SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
		    Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
		    if(payload!=null) {
		        claims = Jwts.claims().setSubject(SUBJECT_PAYLOAD);
		        claims.put(PAYLOAD_KEY_ID, payload);
		    } 
		    
			String token=Jwts.builder().setHeader(header)
					         .setClaims(claims)
					         .setIssuedAt(new Date()) 
					         .setExpiration(new Date(new Date().getTime() + 24 * 60 * 60 * 1000)) 
					         .setAudience(koreJwt.getAud()) 
					         .setIssuer(koreJwt.getClientId()) // .setSubject("#"+ koreJwt.getEmplId()) 
					         .setSubject("#"+ koreJwt.getEmplId()+"@"+userDetails.getEmailId())
					         .claim("isAnonymous",false) 
					         .signWith(signatureAlgorithm, signingKey) 
					         .compact(); 
			 
			jwtResponse.setClientId(koreJwt.getClientId());
			jwtResponse.setJwt(token); 
			jwtResponse.setStatusCode("SUCCESS"); 
		} else { 
			final ErrorDTO error = new ErrorDTO(); 
			error.setErrorCode("SPL-00001"); 
			error.setErrorDescription("User info wasn't found!"); 
			jwtResponse.setJwt(null); 
			jwtResponse.getErrorDTO().add(error); 
			jwtResponse.setStatusCode("FAILURE"); 
		} 
		return jwtResponse; 
	}

	public static boolean verifyJWTToken(JWTToken request) {
		boolean resp = false;
		try {
			if (request!=null&&request.getStatusCode().equalsIgnoreCase(STATUS_SUCCESS)) {
			    //This line will throw an exception if it is not a signed JWS (as expected)
			    Claims claims = Jwts.parser()        
			       .setSigningKey(DatatypeConverter.parseBase64Binary(getDemoSecretKey(request.getClientId())))
			       .parseClaimsJws(request.getJwt()).getBody();
			    resp=true;

			    //StandardContext payload = (StandardContext)claims.get(PAYLOAD_KEY_ID);
			    System.out.println("ID: " + claims.getId());
			    System.out.println("Subject: " + claims.getSubject());
			    System.out.println("Audience: " + claims.getAudience());
			    System.out.println("Issuer: " + claims.getIssuer());
			    System.out.println("Expiration: " + claims.getExpiration());		
			    LinkedHashMap payloadHashMap = (LinkedHashMap) claims.get(PAYLOAD_KEY_ID);
			    LinkedHashMap stockQuoteHashMap = (LinkedHashMap)payloadHashMap.get("stockRequestDTO");
			    System.out.println("Quote: " + stockQuoteHashMap.get("stockQuote"));
			    System.out.println("Exchange: " + stockQuoteHashMap.get("stockExchange"));
			}			
		} catch (Exception exp) {
			exp.printStackTrace();
		}
		return resp;
	}
	
	/*
    public static void main(String args[]) {
    	try {
	    	JwtRequest koreJwt = new JwtRequest(); 
	    	koreJwt.setAud("Mynd3112");
	    	koreJwt.setEmplId("v161149");
	    	koreJwt.setClientId("MyndClient");

	    	JWTUserDetails userDetails = new JWTUserDetails();
	    	userDetails.setFirstName("Brian");
	    	userDetails.setLastname("Xu");
	    	userDetails.setEmailId("brian.xu@myndscript.com");
	    	
	    	StandardContext payload = new StandardContext();
	    	StockRequestDTO quote = new StockRequestDTO();
	    	quote.setStockExchange("NY");
	    	quote.setStockQuote("MSFT");
	    	payload.setStockRequestDTO(quote);
	    	JWTToken jwtToken = JWTTokenApis.generateJwtToken(koreJwt, userDetails, payload);
	    	JWTTokenApis.verifyJWTToken(jwtToken);
    	} catch (Exception exp) {
    		exp.printStackTrace();
    	}
    }	
    */
}
