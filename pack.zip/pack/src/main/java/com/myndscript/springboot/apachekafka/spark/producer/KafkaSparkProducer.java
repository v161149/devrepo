package com.myndscript.springboot.apachekafka.spark.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import com.myndscript.springboot.market.LoadedMarketData;

@Service
public class KafkaSparkProducer {

    private static final Logger LOG = LoggerFactory.getLogger(KafkaSparkProducer.class);

    @Autowired
    private KafkaTemplate<String, LoadedMarketData> kafkaTemplate;

    @Value("${jsa.kafka.topic}")
    private String topic;

    public void send(LoadedMarketData data){
        LOG.info("sending data='{}' to topic='{}'", data, topic);

        Message<LoadedMarketData> message = MessageBuilder
                .withPayload(data)
                .setHeader(KafkaHeaders.TOPIC, topic)
                .build();
        kafkaTemplate.send(message);
    }
}
