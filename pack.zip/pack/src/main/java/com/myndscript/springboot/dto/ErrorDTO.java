package com.myndscript.springboot.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "ErrorDTO")
public class ErrorDTO implements Serializable{
	private static final long serialversionUID = 129348941L;
	
	@XmlAttribute(name = "errorCode", required=true)
    private String errorCode;
    @XmlAttribute(name = "errorDescription", required=true)
    private String errorDescription;
    
    public String getErrorCode() {
    	return errorCode;
    }
    public void setErrorCode(String param) {
    	this.errorCode=param;
    }
    
    public String getErrorDescription() {
    	return errorDescription;
    }
    public void setErrorDescription(String param) {
    	this.errorDescription=param;
    }   
}
