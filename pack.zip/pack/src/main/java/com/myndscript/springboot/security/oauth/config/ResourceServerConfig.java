package com.myndscript.springboot.security.oauth.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;

@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(ResourceServerConfig.class);
    
    @Value("${security.jwt.resource-ids}")
    private String resourceIds;
	
    @Override
    public void configure(ResourceServerSecurityConfigurer resources) {
        LOGGER.info("oauth-ResourceServerConfig::configure(ResourceServerSecurityConfigurer resources)()");
        resources.resourceId(resourceIds).stateless(false);
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        LOGGER.info("oauth-ResourceServerConfig::configure(HttpSecurity http)");
        http.
            anonymous().disable()
            .authorizeRequests()
            .antMatchers("/springbootsvc/oauth/**").access("hasRole('ADMIN')")
            .and().exceptionHandling().accessDeniedHandler(new OAuth2AccessDeniedHandler());
    }

}