package com.myndscript.springboot.repositories;

import java.util.List;
import com.myndscript.springboot.entity.BasicAuthUser;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BasicAuthUserRepository extends CrudRepository<BasicAuthUser, Long>{
    @Override
    List<BasicAuthUser> findAll();
    BasicAuthUser findByUsername(String username);
    @Override
    BasicAuthUser save(BasicAuthUser user);
    void delete(BasicAuthUser user);
}
