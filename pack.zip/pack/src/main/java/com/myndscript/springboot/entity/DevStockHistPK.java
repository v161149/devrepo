package com.myndscript.springboot.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DEV_STOCK_HIST database table.
 * 
 */
@Embeddable
public class DevStockHistPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="STOCK_SYMBOL")
	private String stockSymbol;

	@Column(name="STOCK_EXCHANGE")
	private String stockExchange;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATE_TIME")
	private java.util.Date dateTime;

	public DevStockHistPK() {
	}
	public String getStockSymbol() {
		return this.stockSymbol;
	}
	public void setStockSymbol(String stockSymbol) {
		this.stockSymbol = stockSymbol;
	}
	public String getStockExchange() {
		return this.stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public java.util.Date getDateTime() {
		return this.dateTime;
	}
	public void setDateTime(java.util.Date dateTime) {
		this.dateTime = dateTime;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DevStockHistPK)) {
			return false;
		}
		DevStockHistPK castOther = (DevStockHistPK)other;
		return 
			this.stockSymbol.equals(castOther.stockSymbol)
			&& this.stockExchange.equals(castOther.stockExchange)
			&& this.dateTime.equals(castOther.dateTime);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.stockSymbol.hashCode();
		hash = hash * prime + this.stockExchange.hashCode();
		hash = hash * prime + this.dateTime.hashCode();
		
		return hash;
	}
}