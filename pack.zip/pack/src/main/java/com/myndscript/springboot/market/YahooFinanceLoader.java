package com.myndscript.springboot.market;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import com.myndscript.springboot.dto.market.MarketDataType;
import com.myndscript.springboot.dto.market.TickerSymbol;
import com.myndscript.springboot.common.util.csv.CSVFormat;
import com.myndscript.springboot.common.util.csv.ReadCSV;
import com.myndscript.springboot.common.util.http.FormUtility;

import java.text.SimpleDateFormat;

/**
 * This class loads financial data from Yahoo. One caution on Yahoo data.
 */
public class YahooFinanceLoader implements MarketLoader {

	/**
	 * This method builds a URL to load data from Yahoo Finance for a neural
	 * network to train with.
	 * 
	 * @param ticker
	 *            The ticker symbol to access.
	 * @param from
	 *            The beginning date.
	 * @param to
	 *            The ending date.
	 * @return The UEL
	 * @throws IOException
	 *             An error accessing the data.
	 */
	private URL buildURL(final TickerSymbol ticker, final Date from,
			final Date to) throws IOException {
		// process the dates
		final Calendar calendarFrom = Calendar.getInstance();
		calendarFrom.setTime(from);
		final Calendar calendarTo = Calendar.getInstance();
		calendarTo.setTime(to);

		// construct the URL
		final OutputStream os = new ByteArrayOutputStream();
		final FormUtility form = new FormUtility(os, null);
		form.add("s", ticker.getSymbol().toUpperCase());
		form.add("a", "" + calendarFrom.get(Calendar.MONTH));
		form.add("b", "" + calendarFrom.get(Calendar.DAY_OF_MONTH));
		form.add("c", "" + calendarFrom.get(Calendar.YEAR));
		form.add("d", "" + calendarTo.get(Calendar.MONTH));
		form.add("e", "" + calendarTo.get(Calendar.DAY_OF_MONTH));
		form.add("f", "" + calendarTo.get(Calendar.YEAR));
		form.add("g", "d");
		form.add("ignore", ".csv");
		os.close();
		final String str = "http://ichart.finance.yahoo.com/table.csv?"
				+ os.toString();
		return new URL(str);
	}

	/**
	 * Load the specified financial data.
	 * 
	 * @param ticker
	 *            The ticker symbol to load.
	 * @param dataNeeded
	 *            The financial data needed.
	 * @param from
	 *            The beginning date to load data from.
	 * @param to
	 *            The ending date to load data to.
	 * @return A collection of LoadedMarketData objects that represent the data
	 *         loaded.
	 */
	public Collection<LoadedMarketData> load(final TickerSymbol ticker) {
		try {
			final Collection<LoadedMarketData> result = new ArrayList<LoadedMarketData>();
			final ReadCSV csv = new ReadCSV(ticker.getFileName(), true, CSVFormat.ENGLISH);

			while (csv.next()) {
                                final String sDate = csv.get("date");
				final Date date = csv.getDate("date");
				final double adjClose = csv.getDouble("adj close");
				final double open = csv.getDouble("open");
				final double close = csv.getDouble("close");
				final double high = csv.getDouble("high");
				final double low = csv.getDouble("low");
				final double volume = csv.getDouble("volume");

				LoadedMarketData data = new LoadedMarketData();
                                data.setTicker(ticker.getSymbol());
                                data.setWhen(date);   
                                data.setStrWhen(sDate);
				data.setOpenPrice(open);
				data.setClosePrice(close);
                                data.setAdjClosePrice(adjClose);
				data.setHighPrice(high);
				data.setLowPrice(low);
				data.setVolumn(volume);
				result.add(data);
			}
			csv.close();
			return result;
		} catch (final Exception e) {
			throw new LoaderError(e);
		}
	}
/*        
        //Unit Test
        public static void main(String args[]){
            Collection<LoadedMarketData> result = new ArrayList<LoadedMarketData>();
            try {
                String symbol = "XON";
                String fullFileName = "C:\\development\\AI\\testdata\\marketdateset\\"+symbol+".CSV";
                TickerSymbol ticker = new TickerSymbol(symbol,fullFileName);
                YahooFinanceLoader inst = new YahooFinanceLoader();
                result = inst.load(ticker);
                for (LoadedMarketData record : result) {
                    System.out.println(record.toString());
                }
                System.out.println("End");
            } catch (Exception exp) {
                exp.printStackTrace();
            }
         }
*/
}
