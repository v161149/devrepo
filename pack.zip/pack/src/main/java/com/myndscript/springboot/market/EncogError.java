package com.myndscript.springboot.market;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * General error class for Encog. All Encog errors should extend from this
 * class. Doing this ensures that they will be caught as Encog errors. This also
 * ensures that any subclasses will be logged.
 */
public class EncogError extends RuntimeException {

        @SuppressWarnings("compatibility:-7434581966354655857")
        private static final long serialVersionUID = -5909341149180956178L;
        
        private static final Logger LOG = LoggerFactory.getLogger(EncogError.class);
	/**
	 * Construct a message exception.
	 * 
	 * @param msg
	 *            The exception message.
	 */
	public EncogError(final String msg) {
		super(msg);
                LOG.error(msg);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param t
	 *            The other exception.
	 */
	public EncogError(final Throwable t) {
		super(t);
	        LOG.error("Caught the other exception",t);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param msg
	 *            A message.
	 * @param t
	 *            The other exception.
	 */
	public EncogError(final String msg, final Throwable t) {
		super(msg, t);
                LOG.error(msg,t);
	}
}
