package com.myndscript.springboot.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DEV_SECURITY_BASIC_AUTH")
public class BasicAuthUser implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	private long id;

	@Column(name="username")
	private String username;

	@Column(name="encoded_password")
	private String encodedpassword;

	@Column(name="decoded_password")
	private String decodedpassword;
	
	@Column(name="role")
	private String role;

	public BasicAuthUser() {}

	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return this.username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public String getEncodedpassword() {
		return this.encodedpassword;
	}
	public void setEncodedpassword(String password) {
		this.encodedpassword = password;
	}

	public String getDecodedpassword() {
		return this.decodedpassword;
	}
	public void setDecodedpassword(String password) {
		this.decodedpassword = password;
	}
	
	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
