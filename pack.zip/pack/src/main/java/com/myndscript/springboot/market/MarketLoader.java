package com.myndscript.springboot.market;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

import com.myndscript.springboot.dto.market.MarketDataType;
import com.myndscript.springboot.dto.market.TickerSymbol;

/**
 * This interface defines a class that can be used to load external financial
 * data.
 */
public interface MarketLoader {

	/**
	 * Load the specified ticker symbol for the specified date.
	 * 
	 * @param ticker
	 *            The ticker symbol to load.
	 * @param dataNeeded
	 *            Which data is actually needed.
	 * @param from
	 *            Beginning date for load.
	 * @param to
	 *            Ending date for load.
	 * @return A collection of LoadedMarketData objects that was loaded.
	 */
	Collection<LoadedMarketData> load(TickerSymbol ticker);
}
