package com.myndscript.springboot.common.util.csv;

import java.util.ArrayList;
import java.util.List;

public class ParseCSVLine {
	
	private CSVFormat format;
	
	public ParseCSVLine(CSVFormat theFormat)
	{
		this.format = theFormat;
	}
	
	public List<String> parse(final String line) {
		if( this.format.getSeparator()==' ') {
			return parseSpaceSep(line);
		} else {
			return parseCharSep(line);
		}
	}
	
	private List<String> parseSpaceSep(final String line) {
		final List<String> result = new ArrayList<String>();
		SimpleParser parse  = new SimpleParser(line);
		
		while(!parse.eol()) {
			if( parse.peek()=='\"') {
				result.add( parse.readQuotedString() );
			} else {
				result.add( parse.readToWhiteSpace() );
			}
			parse.eatWhiteSpace();
		}
		
		return result;
	}

	/**
	 * Parse the line into a list of values.
	 * 
	 * @param line
	 *            The line to parse.
	 * @return The elements on this line.
	 */
	private List<String> parseCharSep(final String line) {
		final StringBuilder item = new StringBuilder();
		final List<String> result = new ArrayList<String>();
		boolean quoted = false;
		boolean hadQuotes = false;

		for (int i = 0; i < line.length(); i++) {
			final char ch = line.charAt(i);
			if ((ch == this.format.getSeparator()) && !quoted) {
				String s = item.toString();
				if( !hadQuotes ) {
					s = s.trim();
				}
				result.add(s);
				item.setLength(0);
				quoted = false;
				hadQuotes = false;
			} else if ((ch == '\"') && quoted) {
				if( (i+1)<line.length() && line.charAt(i+1)=='\"' ) {
					i++;
					item.append("\"");
				} else {
					quoted = false;
				}
			} else if ((ch == '\"') && (item.length() == 0)) {
				hadQuotes = true;
				quoted = true;
			} else {
				item.append(ch);
			}
		}

		if (item.length() > 0) {
			String s = item.toString();
			if( !hadQuotes ) {
				s = s.trim();
			}
			result.add(s);
		}

		return result;
	}

}
