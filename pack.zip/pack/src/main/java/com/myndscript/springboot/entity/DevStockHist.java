package com.myndscript.springboot.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the DEV_STOCK_HIST database table.
 * 
 */
@Entity
@Table(name="DEV_STOCK_HIST")
@NamedQuery(name="DevStockHist.findAll", query="SELECT d FROM DevStockHist d")
public class DevStockHist implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DevStockHistPK id;

	@Column(name="STOCK_PRICE")
	private BigDecimal stockPrice;

	public DevStockHist() {
	}

	public DevStockHistPK getId() {
		return this.id;
	}

	public void setId(DevStockHistPK id) {
		this.id = id;
	}

	public BigDecimal getStockPrice() {
		return this.stockPrice;
	}

	public void setStockPrice(BigDecimal stockPrice) {
		this.stockPrice = stockPrice;
	}

}