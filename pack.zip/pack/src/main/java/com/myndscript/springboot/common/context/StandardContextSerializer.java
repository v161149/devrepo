package com.myndscript.springboot.common.context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

public class StandardContextSerializer{
    private static final Logger LOGGER = LoggerFactory.getLogger(StandardContextSerializer.class);
    
    public byte[] serialize(StandardContext arg1) {
      byte[] retVal = null;
      ObjectMapper objectMapper = new ObjectMapper();
      try {
        retVal = objectMapper.writeValueAsString(arg1).getBytes();
      } catch (Exception e) {
          LOGGER.error(e.getMessage());
      }
      return retVal;
    }
}
