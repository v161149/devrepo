package com.myndscript.springboot.common.util;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Connection;

public class CommonUtil {

	public static void releaseDBResource(Connection conn, PreparedStatement statement, Statement dtatement2, ResultSet resultset)  {
		try {
			if(resultset!=null) {
				resultset.close();
				resultset=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			if(dtatement2!=null) {
				dtatement2.close();
				dtatement2=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			if(statement!=null) {
				statement.close();
				statement=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			if(conn!=null) {
				conn.close();
				conn=null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}		
	}
}
