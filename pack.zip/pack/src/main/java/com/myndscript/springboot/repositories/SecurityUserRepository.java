package com.myndscript.springboot.repositories;

import com.myndscript.springboot.entity.SecurityUser;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SecurityUserRepository extends CrudRepository<SecurityUser, Long> {
	SecurityUser findByUsername(String username);
}
