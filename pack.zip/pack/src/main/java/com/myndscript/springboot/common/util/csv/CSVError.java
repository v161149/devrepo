package com.myndscript.springboot.common.util.csv;

import com.myndscript.springboot.market.EncogError;

/**
 * An error has occured while working with CSV data.
 */
public class CSVError extends EncogError {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6118582877885550843L;

	/**
	 * Construct a message exception.
	 * 
	 * @param msg
	 *            The exception message.
	 */
	public CSVError(final String msg) {
		super(msg);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param t
	 *            The other exception.
	 */
	public CSVError(final Throwable t) {
		super(t);
	}
}
