package com.myndscript.springboot.jms.artemis;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.math.BigDecimal;
import java.util.Random;
import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.Timestamp;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.converter.MessageConverter;
import org.springframework.stereotype.Component;
import com.myndscript.springboot.dto.*;
import com.myndscript.springboot.jdbc.*;
import com.myndscript.springboot.common.util.*;
import com.myndscript.springboot.common.context.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.myndscript.springboot.common.Constants;

import com.myndscript.springboot.entity.DevStockHist;

import com.myndscript.springboot.entity.DevStockHistPK;

import java.sql.SQLException;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.TransactionStatus;

@Component
public class ArtemisJmsConsumer {
	private static final Logger LOGGER = LoggerFactory.getLogger(ArtemisJmsConsumer.class);
	
        @Autowired
        PlatformTransactionManager transactionManager;
    
        @Autowired
        EntityManagerFactory entityManagerFactory;
    
        @Autowired
        DataSource dataSource;
    
	@JmsListener(destination = "${jms.queue.destination}")
	public void receive(Message msg) {
		try {
			if (msg.getPayload() instanceof IContext) {
				StockResponseDTO resp = fetchRealTimeStockPrice((IContext)msg.getPayload());
				LOGGER.info("Recieved MQ Message: " + resp.getStockQuote() + " price "+resp.getPrice());				
			} else {
				LOGGER.error("Message Type Unkown !");
			}
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}
	/*
         * CMT: Container Managed Transaction
         */
        @Transactional(rollbackFor = Exception.class)
	private StockResponseDTO fetchRealTimeStockPrice5(IContext context) throws Exception {
		String INSERT_STOCK_QUOTE = "INSERT INTO JEFFREY.DEV_STOCK_HIST(STOCK_SYMBOL,STOCK_EXCHANGE,STOCK_PRICE,DATE_TIME) VALUES(?,?,?,?)";
		Connection conn = null;
		PreparedStatement ps = null;   
		StockResponseDTO resp = new StockResponseDTO();
                StockRequestDTO stockInfo = context.getStockRequestDTO();	
                //OracleConfiguration orclConfig = context.getOracleConfiguration();
                
                resp.setStockQuote(stockInfo.getStockQuote());
                resp.setStockExchange(stockInfo.getStockExchange());
                Date now = Calendar.getInstance().getTime();
                Timestamp sqlTodayTime = new Timestamp(now.getTime());
                resp.setTradeDate(DateFormat.getDateTimeInstance().format(now));
                double random = new Random().nextDouble();
                double result = Double.parseDouble(String.format("%.2f", (random*(Constants.MAX_VALUE - Constants.MIN_VALUE)+Constants.MIN_VALUE)));
                resp.setPrice(result);	
                
                //persist data in db
                //DataSource ds= orclConfig.dataSource();
                conn = dataSource.getConnection();
                conn.setAutoCommit(false);
                ps = conn.prepareStatement(INSERT_STOCK_QUOTE);
                ps.setString(1, resp.getStockQuote());
                ps.setString(2, resp.getStockExchange());
                ps.setBigDecimal(3, new BigDecimal(resp.getPrice()));
                ps.setTimestamp(4, sqlTodayTime);
                ps.executeQuery();
                if (result>90) {
                    throw new Exception("Test rollback");
                }
                CommonUtil.releaseDBResource(conn, ps, null, null);
		return resp;
	}
        
        //Transaction Manager
        private StockResponseDTO fetchRealTimeStockPrice2(IContext context) throws Exception {
            String INSERT_STOCK_QUOTE = "INSERT INTO JEFFREY.DEV_STOCK_HIST(STOCK_SYMBOL,STOCK_EXCHANGE,STOCK_PRICE,DATE_TIME) VALUES(?,?,?,?)";
            Connection conn = null;
            PreparedStatement ps = null;   
            StockResponseDTO resp = new StockResponseDTO();
            //2. Transaction Manager:
            DefaultTransactionDefinition def = new DefaultTransactionDefinition();
            def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
            TransactionStatus transactionStatus = null;
            //PlatformTransactionManager transactionManager = null;

            try {
                    StockRequestDTO stockInfo = context.getStockRequestDTO();       
                    OracleConfiguration orclConfig = context.getOracleConfiguration();
                    
                    resp.setStockQuote(stockInfo.getStockQuote());
                    resp.setStockExchange(stockInfo.getStockExchange());
                    Date now = Calendar.getInstance().getTime();
                    Timestamp sqlTodayTime = new Timestamp(now.getTime());
                    resp.setTradeDate(DateFormat.getDateTimeInstance().format(now));
                    double random = new Random().nextDouble();
                    double result = Double.parseDouble(String.format("%.2f", (random*(Constants.MAX_VALUE - Constants.MIN_VALUE)+Constants.MIN_VALUE)));
                    resp.setPrice(result);  
                    
                    //persist data in db
                    DataSource ds= orclConfig.dataSource();
                    //2. Transaction Manager:
                    transactionManager = orclConfig.transactionManager(ds);
                    conn = ds.getConnection();
                    conn.setAutoCommit(false);
                    ps = conn.prepareStatement(INSERT_STOCK_QUOTE);
                    ps.setString(1, resp.getStockQuote());
                    ps.setString(2, resp.getStockExchange());
                    ps.setBigDecimal(3, new BigDecimal(resp.getPrice()));
                    ps.setTimestamp(4, sqlTodayTime);
                    ps.executeQuery();
                    if (result>80) {
                        throw new Exception("Test rollback");
                    }
                    //2. Transaction Manager:
                    transactionManager.commit(transactionStatus);
            } catch(Exception e) {
                    //2. Transaction Manager:
                    if (transactionManager!=null&&transactionStatus != null) {
                        transactionManager.rollback(transactionStatus);
                    }
                    throw e;
            } finally {
                    CommonUtil.releaseDBResource(conn, ps, null, null);
            }
            return resp;
    }
    
    //1. JDBC transaction
    private StockResponseDTO fetchRealTimeStockPrice3(IContext context) throws Exception {
            String INSERT_STOCK_QUOTE = "INSERT INTO JEFFREY.DEV_STOCK_HIST(STOCK_SYMBOL,STOCK_EXCHANGE,STOCK_PRICE,DATE_TIME) VALUES(?,?,?,?)";
            Connection conn = null;
            PreparedStatement ps = null;   
            StockResponseDTO resp = new StockResponseDTO();
            try {
                    StockRequestDTO stockInfo = context.getStockRequestDTO();       
                    OracleConfiguration orclConfig = context.getOracleConfiguration();
                    
                    resp.setStockQuote(stockInfo.getStockQuote());
                    resp.setStockExchange(stockInfo.getStockExchange());
                    Date now = Calendar.getInstance().getTime();
                    Timestamp sqlTodayTime = new Timestamp(now.getTime());
                    resp.setTradeDate(DateFormat.getDateTimeInstance().format(now));
                    double random = new Random().nextDouble();
                    double result = Double.parseDouble(String.format("%.2f", (random*(Constants.MAX_VALUE - Constants.MIN_VALUE)+Constants.MIN_VALUE)));
                    resp.setPrice(result);  
                    
                    //persist data in db
                    DataSource ds= orclConfig.dataSource();
                    conn = ds.getConnection();
                    conn.setAutoCommit(false);
                    ps = conn.prepareStatement(INSERT_STOCK_QUOTE);
                    ps.setString(1, resp.getStockQuote());
                    ps.setString(2, resp.getStockExchange());
                    ps.setBigDecimal(3, new BigDecimal(resp.getPrice()));
                    ps.setTimestamp(4, sqlTodayTime);
                    ps.executeQuery();
                    if (result>80) {
                        throw new Exception("Test rollback");
                    }
                    //1. JDBC transaction: 
                    conn.commit();
            } catch(Exception e) {
                    //1. JDBC transaction: 
                    conn.rollback();
                    throw e;
            } finally {
                    CommonUtil.releaseDBResource(conn, ps, null, null);
            }
            return resp;
    }
    
    //4. Entity manager Transaction Management:
    private StockResponseDTO fetchRealTimeStockPrice(IContext context) throws Exception {
            EntityManager entityManager = entityManagerFactory.createEntityManager();   
            StockResponseDTO resp = new StockResponseDTO();
            try {
                    StockRequestDTO stockInfo = context.getStockRequestDTO();       
                    resp.setStockQuote(stockInfo.getStockQuote());
                    resp.setStockExchange(stockInfo.getStockExchange());
                    Date now = Calendar.getInstance().getTime();
                    Timestamp sqlTodayTime = new Timestamp(now.getTime());
                    resp.setTradeDate(DateFormat.getDateTimeInstance().format(now));
                    double random = new Random().nextDouble();
                    double result = Double.parseDouble(String.format("%.2f", (random*(Constants.MAX_VALUE - Constants.MIN_VALUE)+Constants.MIN_VALUE)));
                    resp.setPrice(result);  
                    
                    DevStockHistPK stockPriceRecordPk = new DevStockHistPK();
                    DevStockHist stockPriceRecord = new DevStockHist();
                    stockPriceRecordPk.setStockSymbol(resp.getStockQuote());
                    stockPriceRecordPk.setStockExchange(resp.getStockExchange());
                    stockPriceRecordPk.setDateTime(sqlTodayTime);
                    stockPriceRecord.setId(stockPriceRecordPk);
                    stockPriceRecord.setStockPrice(new BigDecimal(resp.getPrice()));
                    entityManager.getTransaction().begin();
                    entityManager.persist(stockPriceRecord);

                    if (result>80) {
                        throw new Exception("Test rollback");
                    }
                    entityManager.getTransaction().commit();
            } catch(Exception e) {
                    entityManager.getTransaction().rollback();
                    throw e;
            } finally {
                    entityManager.close();
            }
            return resp;
    }
}