package com.myndscript.springboot.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "StockResponseDTO")
public class StockResponseDTO implements Serializable{
	private static final long serialversionUID = 129348939L;
    @XmlAttribute(name = "stockQuote", required=true)
    private String stockQuote;
    @XmlElement(name = "stockExchange", required=true)
    private String stockExchange;
    @XmlElement(name = "tradeDate", required=true)
    private String tradeDate;
    @XmlElement(name = "price", required=true)
    private double price;
    @XmlAttribute(name = "status", required=true)
    private String status;
    @XmlAttribute(name = "errMsg", required=true)
    private String errMsg;    
    
    public String getStockQuote() {
    	return stockQuote;
    }
    public void setStockQuote(String param) {
    	this.stockQuote=param;
    }
    
    public String getStockExchange() {
    	return stockExchange;
    }
    public void setStockExchange(String param) {
    	this.stockExchange=param;
    }
    
    public String getTradeDate() {
    	return tradeDate;
    }
    public void setTradeDate(String param) {
    	this.tradeDate=param;
    }    
    
    public double getPrice() {
    	return price;
    }
    public void setPrice(double param) {
    	this.price=param;
    }    
    
    public String getStatus() {
    	return status;
    }
    public void setStatus(String param) {
    	this.status=param;
    }
    
    public String getErrMsg() {
    	return errMsg;
    }
    public void setErrMsg(String param) {
    	this.errMsg=param;
    }     
}
