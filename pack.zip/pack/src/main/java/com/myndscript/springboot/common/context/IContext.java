package com.myndscript.springboot.common.context;

import com.myndscript.springboot.dto.*;
import com.myndscript.springboot.jdbc.OracleConfiguration;

public interface IContext {
    public JwtRequest getJwtRequest();
    public void setJwtRequest(JwtRequest request);
    public OracleConfiguration getOracleConfiguration();
    public void setOracleConfiguration(OracleConfiguration orcl);
    public StockRequestDTO getStockRequestDTO();
    public void setStockRequestDTO(StockRequestDTO dto);
    public StockResponseDTO getStockResponseDTO();
    public void setStockResponseDTO(StockResponseDTO dto);    
}
