package com.myndscript.springboot.facade.basicauth;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;

import com.myndscript.springboot.common.Constants;
import com.myndscript.springboot.common.context.IContext;
import com.myndscript.springboot.common.context.StandardContext;
import com.myndscript.springboot.dto.AsyncResponse;
import com.myndscript.springboot.dto.Response;
import com.myndscript.springboot.dto.SecurityUserProfileDTO;
import com.myndscript.springboot.dto.StockRequestDTO;
import com.myndscript.springboot.dto.StockResponseDTO;
import com.myndscript.springboot.entity.BasicAuthUser;
import com.myndscript.springboot.jdbc.OracleConfiguration;
import com.myndscript.springboot.jms.artemis.ArtemisJmsProducer;
import com.myndscript.springboot.queries.QueryManager;
import com.myndscript.springboot.repositories.BasicAuthUserRepository;

import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/springbootsvc/basic-auth")
public class SecurityResourceController {
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityResourceController.class);	
    
    @Autowired(required = true)
    private BasicAuthUserRepository userRepository;

    @Autowired
    ArtemisJmsProducer producer;
    @Autowired
    OracleConfiguration orclConfig;
    
    @RequestMapping(method = RequestMethod.GET, value="/getAllUsers")
    @ResponseBody
    public List<BasicAuthUser> getAllUsers() {
        LOGGER.info("SecurityResourceController::getAllUsers() is invoked.");
        List<BasicAuthUser> resp = null;
        Response errResp = null;
        try {
            resp = userRepository.findAll();
        } catch (Exception exp) {
            errResp = new Response();
            errResp.setStatus(Constants.STATUS_FAILURE);
            errResp.setErrMsg(exp.getMessage());
        }
        if (resp!=null) {
            return resp;
        } else {
            return resp;
        }
    }
    
    @RequestMapping(method = RequestMethod.POST, value="/registerUser")
    @ResponseBody
    BasicAuthUser registerUser(@RequestBody SecurityUserProfileDTO request) {
            
        LOGGER.info("SecurityResourceController::registerUser() is invoked.");
        Response errResp = null;
        BasicAuthUser resp = null;
        try {
            LOGGER.info("SecurityResourceController::registerUser() input id="+request.getId());
            LOGGER.info("SecurityResourceController::registerUser() input username="+request.getUserName());
            LOGGER.info("SecurityResourceController::registerUser() input encodedpassword="+request.getEncodedPassword());
            LOGGER.info("SecurityResourceController::registerUser() input decodedpassword="+request.getDecodedPassword());
            LOGGER.info("SecurityResourceController::registerUser() input role="+request.getRole());
            BasicAuthUser user = new BasicAuthUser();
            user.setId(request.getId());
            user.setDecodedpassword(request.getDecodedPassword());
            user.setEncodedpassword(request.getEncodedPassword());
            user.setUsername(request.getUserName());
            user.setRole(request.getRole());
            LOGGER.info("SecurityResourceController::registerUser() JPA input id="+user.getId());
            LOGGER.info("SecurityResourceController::registerUser() JPA input username="+user.getUsername());
            LOGGER.info("SecurityResourceController::registerUser() JPA input encodedpassword="+user.getEncodedpassword());
            LOGGER.info("SecurityResourceController::registerUser() JPA input decodedpassword="+user.getDecodedpassword());
            LOGGER.info("SecurityResourceController::registerUser() JPA input role="+user.getRole());
            resp = userRepository.save(user);
        } catch (Exception exp) {
            errResp = new Response();
            errResp.setStatus(Constants.STATUS_FAILURE);
            errResp.setErrMsg(exp.getMessage());            
        }
        if (resp!=null) {
            return resp;
        } else {
            return resp;
        }
    }
    
    @RequestMapping(method = RequestMethod.PUT, value="/updateUser")
    @ResponseBody
    public BasicAuthUser updateUserRole(@RequestBody SecurityUserProfileDTO request) {          
        LOGGER.info("SecurityResourceController::updateUserRole() is invoked.");  
        Response errResp = null;
        BasicAuthUser resp = null;
        try {
            BasicAuthUser existUser = userRepository.findByUsername(request.getUserName());
            if(existUser!=null) {
                existUser.setRole(request.getRole());
                resp = userRepository.save(existUser);
            } else {
                throw new Exception("The user doesn't exist.");
            }
        } catch (Exception exp) {
            errResp = new Response();
            errResp.setStatus(Constants.STATUS_FAILURE);
            errResp.setErrMsg(exp.getMessage());               
        }
        if (resp!=null) {
            return resp;
        } else {
            return resp;
        }            
    }  
    
    @RequestMapping(method = RequestMethod.DELETE, value="/deleteUser/{userName}")
    @ResponseBody
    public Response deleteUser(@PathVariable("userName") String userName) {            
        LOGGER.info("SecurityResourceController::deleteUser() is invoked."); 
        Response resp = null;
        try {
            LOGGER.info("SecurityResourceController::deleteUser() input="+userName);
            BasicAuthUser existUser = userRepository.findByUsername(userName);
            userRepository.delete(existUser);
            resp = new Response();
            resp.setStatus(Constants.STATUS_SUCCESS);           
        } catch (Exception exp) {
            resp = new Response();
            resp.setStatus(Constants.STATUS_FAILURE);
            resp.setErrMsg(exp.getMessage());              
        }
        return resp;            
    }
    
    //get real-time stock quote
    @RequestMapping(method = RequestMethod.POST, value="/syncPriceQuote/",
                        produces = {"application/json"},
                        consumes = {"application/json", "application/xml"})
    @ResponseBody
    StockResponseDTO getRealTimeStockPriceSyncApi(@RequestBody StockRequestDTO stockInfo) {
        StockResponseDTO resp = new StockResponseDTO();
        try {
            IContext context = new StandardContext();
            context.setStockRequestDTO(stockInfo);              
            resp = QueryManager.getRealTimeStockPrice(context);
            resp.setStatus(AsyncResponse.STATUS_SUCCESS);
            LOGGER.info("getRealTimeStockPriceSyncApi is invoked..");
        } catch (Exception exp) {
            exp.printStackTrace();
            resp.setStatus(AsyncResponse.STATUS_FAILURE);
            resp.setErrMsg(exp.getMessage());
            LOGGER.error(exp.getMessage());
        }
        return resp;
    }

    //get async stock quote
    @RequestMapping(method = RequestMethod.POST, value="/asyncSendPriceQuoteMsg/",
                                produces = {"application/json"},
                                consumes = {"application/json", "application/xml"})
        @ResponseBody
        AsyncResponse getRealTimeStockPriceAsyncApi(@RequestBody StockRequestDTO stockInfo) {
        AsyncResponse resp = new AsyncResponse();
        try {
            IContext context = new StandardContext();
            context.setOracleConfiguration(orclConfig);
            context.setStockRequestDTO(stockInfo);
                        //post jms msg
                        producer.send(context);
                        LOGGER.info("getRealTimeStockPriceAsyncApi is invoked.. and sent jms msg");
                        resp.setStatus(AsyncResponse.STATUS_PROGRESS);
        } catch (Exception exp) {
                exp.printStackTrace();
                resp.setStatus(AsyncResponse.STATUS_FAILURE);
                resp.setErrMsg(exp.getMessage());
                LOGGER.error(exp.getMessage());
        }
        return resp;
    }

    //get async stock quote
    @RequestMapping(method = RequestMethod.POST, value="/pullAsyncPriceQuoteMsg/",
                                produces = {"application/json"},
                                consumes = {"application/json", "application/xml"})
        @ResponseBody
        StockResponseDTO pullAsyncRealTimeStockPriceMsg(@RequestBody StockRequestDTO stockInfo) {
        StockResponseDTO resp = new StockResponseDTO();
        try {
            //fetch in db
            IContext context = new StandardContext();
            context.setOracleConfiguration(orclConfig);
            context.setStockRequestDTO(stockInfo);
            resp = QueryManager.fetchLatestStockQuote(context);
            resp.setStatus(AsyncResponse.STATUS_SUCCESS);
            LOGGER.info("pullAsyncRealTimeStockPriceMsg is invoked..");
        } catch (Exception exp) {
                exp.printStackTrace();
                resp.setStatus(AsyncResponse.STATUS_FAILURE);
                resp.setErrMsg(exp.getMessage());
                LOGGER.error(exp.getMessage());
        }
        return resp;
    }    
}
