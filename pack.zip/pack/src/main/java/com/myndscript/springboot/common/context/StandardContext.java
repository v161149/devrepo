package com.myndscript.springboot.common.context;

import java.io.Serializable;
import com.myndscript.springboot.jdbc.OracleConfiguration;
import com.myndscript.springboot.dto.*;

public class StandardContext implements IContext, Serializable{
    private static final long serialversionUID = 129348941L;
    private JwtRequest jwtRequest;
    private OracleConfiguration orcl;
    private StockRequestDTO request;
    private StockResponseDTO response;

	@Override
    public JwtRequest getJwtRequest() {
    	return this.jwtRequest;
    }
    
	@Override
    public void setJwtRequest(JwtRequest request) {
    	this.jwtRequest=request;
    }
    
	@Override
	public OracleConfiguration getOracleConfiguration() {
		return this.orcl;
	}
	@Override
    public void setOracleConfiguration(OracleConfiguration orcl) {
		this.orcl=orcl;
	}
	
	@Override
    public StockRequestDTO getStockRequestDTO() {
    	return this.request;
    }
	@Override
    public void setStockRequestDTO(StockRequestDTO dto) {
    	this.request=dto;
    }
	
	@Override
    public StockResponseDTO getStockResponseDTO() {
    	return response;
    }
	@Override
    public void setStockResponseDTO(StockResponseDTO dto) {
    	this.response=dto;
    }
}
