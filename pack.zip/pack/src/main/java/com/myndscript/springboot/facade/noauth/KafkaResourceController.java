package com.myndscript.springboot.facade.noauth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.myndscript.springboot.apachekafka.spark.producer.KafkaSparkProducer;
import com.myndscript.springboot.dto.AsyncResponse;
import org.springframework.web.bind.annotation.ResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import com.myndscript.springboot.dto.market.TickerSymbol;
import com.myndscript.springboot.market.LoadedMarketData;

import com.myndscript.springboot.market.YahooFinanceLoader;

import java.util.ArrayList;
import java.util.Collection;

@RestController
@RequestMapping(path = "/springbootsvc/no-auth")
public class KafkaResourceController {
        private static final Logger LOGGER = LoggerFactory.getLogger(KafkaResourceController.class);

        @Autowired
        KafkaSparkProducer kafkasparkproducer;
  
        @RequestMapping(method = RequestMethod.POST, value="/asyncSendBatchPriceQuoteMsg/",
                                produces = {"application/json"},
                                consumes = {"application/json", "application/xml"})        
        @ResponseBody
        public AsyncResponse batchStockPriceQuoteproducer(@RequestBody TickerSymbol stockInfo){
            AsyncResponse resp = new AsyncResponse();
            try {
                Collection<LoadedMarketData> histDataSet = new ArrayList<LoadedMarketData>();
                YahooFinanceLoader inst = new YahooFinanceLoader();
                histDataSet = inst.load(stockInfo);
                for(LoadedMarketData record : histDataSet) {
                    kafkasparkproducer.send(record);
                    Thread.sleep(2000); // send stock info every 2 second
                }
                resp.setStatus(AsyncResponse.STATUS_PROGRESS);
            } catch (Exception exp) {
                exp.printStackTrace();
                resp.setStatus(AsyncResponse.STATUS_FAILURE);
                resp.setErrMsg(exp.getMessage());
                LOGGER.error(exp.getMessage());                
            }
            return resp;
        }        
}
