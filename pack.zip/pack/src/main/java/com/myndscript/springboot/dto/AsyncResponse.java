package com.myndscript.springboot.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "AsyncResponse")
public class AsyncResponse implements Serializable{
	private static final long serialversionUID = 129348940L;
	public static final String STATUS_PROGRESS = "IN PROGRESS";
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILURE = "FAILURE";
	
    @XmlAttribute(name = "status", required=true)
    private String status;
    @XmlAttribute(name = "errMsg", required=true)
    private String errMsg;
    
    public String getStatus() {
    	return status;
    }
    public void setStatus(String param) {
    	this.status=param;
    }
    
    public String getErrMsg() {
    	return errMsg;
    }
    public void setErrMsg(String param) {
    	this.errMsg=param;
    }   
}
