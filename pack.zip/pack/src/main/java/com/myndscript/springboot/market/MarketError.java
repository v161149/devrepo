package com.myndscript.springboot.market;

/**
 * Thrown when an error occurs processing market data.
 */
public class MarketError extends TemporalError {
    /**
     * The serial id for this class.
     */
    @SuppressWarnings("compatibility:-4572961270458150336")
    private static final long serialVersionUID = 9199552396430520659L;

	/**
	 * Construct a message exception.
	 * 
	 * @param msg
	 *            The exception message.
	 */
	public MarketError(final String msg) {
		super(msg);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param t
	 *            The other exception.
	 */
	public MarketError(final Throwable t) {
		super(t);
	}

}
