package com.myndscript.springboot.jms.artemis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import com.myndscript.springboot.dto.*;
import com.myndscript.springboot.common.context.*;

@Component
@EnableJms
public class ArtemisJmsProducer {
	@Autowired
	JmsTemplate jmsTemplate;
	@Value("${jms.queue.destination}")
	String destinationQueue;
	
	public void send(IContext msg) {
		try {
			jmsTemplate.convertAndSend(destinationQueue, msg);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}
}