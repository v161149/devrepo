package com.myndscript.springboot.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "JWTToken")
public class JWTToken implements Serializable {

    @SuppressWarnings("compatibility:-721629913081871144")
    private static final long serialVersionUID = 5637740039926689259L;

    @XmlElement(name = "clientId", required = true)
    private String clientId;
    @XmlElement(name = "jwt", required = true)
    private String jwt;
    @XmlElement(name = "statusCode", required = true)
    private String statusCode="NA";
    private List<ErrorDTO> errorDTO = new ArrayList<>();

    public String getClientId() {
        return clientId;
    }
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
    
    public String getJwt() {
        return jwt;
    }
    public void setJwt(String jwt) {
        this.jwt = jwt;
    }

    public String getStatusCode() {
            return statusCode;
    }
    public void setStatusCode(final String statusCode) {
            this.statusCode = statusCode;
    }
    
    public List<ErrorDTO> getErrorDTO() {
            return errorDTO;
    }
    public void setErrorDTO(final List<ErrorDTO> paramValue) {
            errorDTO = paramValue;
    }
}
