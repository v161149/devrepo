package com.myndscript.springboot.dto;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Date;

@XmlRootElement(name = "SecurityUserProfileDTO")
public class SecurityUserProfileDTO implements Serializable{
	private static final long serialversionUID = 129348950L;
	
	@XmlAttribute(name = "id", required=true)
	private long id;	
    @XmlAttribute(name = "userName", required=true)
    private String userName;
    @XmlElement(name = "decodedPassword", required=true)
    private String decodedPassword;
    @XmlElement(name = "encodedPassword", required=true)
    private String encodedPassword;
    @XmlElement(name = "role", required=true)
    private String role;

	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
    
    public String getUserName() {
    	return userName;
    }
    public void setUserName(String param) {
    	this.userName=param;
    }
    
    public String getDecodedPassword() {
    	return decodedPassword;
    }
    public void setDecodedPassword(String param) {
    	this.decodedPassword=param;
    }

    public String getEncodedPassword() {
    	return encodedPassword;
    }
    public void setEncodedPassword(String param) {
    	this.encodedPassword=param;
    }
    
    public String getRole() {
    	return role;
    }
    public void setRole(String param) {
    	this.role=param;
    }	
}
