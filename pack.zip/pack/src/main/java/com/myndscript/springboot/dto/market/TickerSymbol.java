package com.myndscript.springboot.dto.market;

import javax.xml.bind.annotation.*;

@XmlRootElement(name = "TickerSymbol")
public class TickerSymbol {

    /**
     * The ticker symbol.
     */
	@XmlAttribute(name = "symbol", required=true)
	private final String symbol;

	/**
	 * The fileName.
	 */
	@XmlAttribute(name = "fileName", required=true)
	private final String fileName; //local file location

	/**
	 * Construct a ticker symbol with no exchange.
	 * 
	 * @param symbol
	 *            The ticker symbol.
	 */
	public TickerSymbol(final String symbol) {
		this.symbol = symbol;
		this.fileName = null;
	}

        public TickerSymbol() {
                this.symbol = null;
                this.fileName = null;
        }
    
	/**
	 * Construct a ticker symbol with exchange.
	 * 
	 * @param symbol
	 *            The ticker symbol.
	 * @param exchange
	 *            The exchange.
	 */
	public TickerSymbol(final String symbol, final String fileName) {
		this.symbol = symbol;
		this.fileName = fileName;
	}

	/**
	 * @return the exchange
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * @return the symbol
	 */
	public String getSymbol() {
		return this.symbol;
	}
}
