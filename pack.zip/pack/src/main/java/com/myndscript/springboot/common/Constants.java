package com.myndscript.springboot.common;

public class Constants {
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String STATUS_FAILURE = "FAILURE";
    public final static double MIN_VALUE = 50.00;
    public final static double MAX_VALUE = 100.00;    
}
