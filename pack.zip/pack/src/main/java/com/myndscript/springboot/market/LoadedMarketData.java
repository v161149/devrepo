package com.myndscript.springboot.market;

import java.util.Date;

public class LoadedMarketData {
	private Date when;
        private String strWhen;
	private String ticker;
        private double openPrice = 0.0;
        private double lowPrice = 0.0;
        private double highPrice = 0.0;
        private double closePrice = 0.0;
        private double adjClosePrice = 0.0;
        private double volumn = 0.0;

        public LoadedMarketData() {
        }
        
	public String getTicker() {
		return this.ticker;
	}
        public void setTicker(String ticker) {
                this.ticker = ticker;
        }
        
	public Date getWhen() {
		return this.when;
	}
        public void setWhen(Date when) {
                this.when = when;
        }
        public String getStrWhen() {
                return this.strWhen;
        }
        public void setStrWhen(String strWhen) {
                this.strWhen = strWhen;
        }
    
        public void setOpenPrice(double openPrice) {
            this.openPrice = openPrice;
        }
    
        public double getOpenPrice() {
            return openPrice;
        }
    
        public void setLowPrice(double lowPrice) {
            this.lowPrice = lowPrice;
        }
    
        public double getLowPrice() {
            return lowPrice;
        }
    
        public void setHighPrice(double highPrice) {
            this.highPrice = highPrice;
        }
    
        public double getHighPrice() {
            return highPrice;
        }
    
        public void setClosePrice(double closePrice) {
            this.closePrice = closePrice;
        }
    
        public double getClosePrice() {
            return closePrice;
        }

        public void setAdjClosePrice(double adjClosePrice) {
            this.adjClosePrice = adjClosePrice;
        }
        
        public double getAdjClosePrice() {
            return adjClosePrice;
        }
    
        public void setVolumn(double volumn) {
            this.volumn = volumn;
        }
    
        public double getVolumn() {
            return volumn;
        }
    
        public LoadedMarketData getShallowCopy() {
            LoadedMarketData copyObj = new LoadedMarketData();
            copyObj.setWhen(this.when);
            copyObj.setStrWhen(this.strWhen);
            copyObj.setTicker(this.ticker);
            copyObj.setOpenPrice(this.openPrice);
            copyObj.setHighPrice(this.highPrice);
            copyObj.setClosePrice(this.closePrice);
            copyObj.setAdjClosePrice(this.adjClosePrice);
            copyObj.setVolumn(this.volumn);
            return copyObj;
        }
    
        @Override
        public String toString() {
            StringBuilder dailyStockInfo = new StringBuilder();
            dailyStockInfo.append(this.ticker).append(",")
                          .append(this.strWhen).append(",")
                          .append("Open: ").append(this.openPrice).append(",")
                          .append("Low: ").append(this.lowPrice).append(",")
                          .append("High: ").append(this.highPrice).append(",")
                          .append("Close: ").append(this.closePrice).append(",")
                          .append("Adjusted Close: ").append(this.adjClosePrice).append(",")
                          .append("Volumn: ").append(this.volumn).append(";");
            return dailyStockInfo.toString();
        }
}
