package com.myndscript.springboot.market;

/**
 * An error that occurs when financial data is being loaded.
 * 
 * @author jheaton
 * 
 */
public class LoaderError extends MarketError {
	/**
     * The serial version for this class.
     */
    @SuppressWarnings("oracle.jdeveloper.java.serialversionuid-field-in-nonserializable-class")
    private static final long serialVersionUID = 4525043656696667974L;

	/**
	 * Construct a message exception.
	 * 
	 * @param msg
	 *            The exception message.
	 */
	public LoaderError(final String msg) {
		super(msg);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param t
	 *            The other exception.
	 */
	public LoaderError(final Throwable t) {
		super(t);
	}

}
