package com.myndscript.springboot.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the DEV_SECURITY_USER database table.
 * 
 */
@Entity
@Table(name="DEV_SECURITY_USER")
public class SecurityUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="DEV_SECURITY_USER_ID_GENERATOR", sequenceName="DEV_SECURITY_USER_ID_SEQUENCE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DEV_SECURITY_USER_ID_GENERATOR")
	private long id;

	@Column(name="encoded_password")
	private String encryptpassword;

	@Column(name="decoded_password")
	private String decryptpassword;
	
	@Column(name="username")
	private String username;

	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@Column(name="emplid")
	private String emplid;

	@Column(name="emailid")
	private String emailid;
	
	//bi-directional many-to-many association to SecurityRole
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(
		name="DEV_SECURITY_USER_ROLE"
		, joinColumns={
			@JoinColumn(name="USER_ID")
			}
		, inverseJoinColumns={
			@JoinColumn(name="ROLE_ID")
			}
		)
	private List<SecurityRole> securityRoles;

	public SecurityUser() {}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEncryptpassword() {
		return this.encryptpassword;
	}

	public void setEncryptpassword(String password) {
		this.encryptpassword = password;
	}

	public String getDecryptpassword() {
		return this.decryptpassword;
	}

	public void setDecryptpassword(String password) {
		this.decryptpassword = password;
	}
	
	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmplid() {
		return this.emplid;
	}

	public void setEmplid(String emplid) {
		this.emplid = emplid;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public List<SecurityRole> getSecurityRoles() {
		return this.securityRoles;
	}

	public void setSecurityRoles(List<SecurityRole> securityRoles) {
		this.securityRoles = securityRoles;
	}

}