package com.myndscript.springboot.dto;

import java.io.Serializable;

public class JWTUserDetails implements Serializable {

    @SuppressWarnings("compatibility:-7877910778644622207")
    private static final long serialVersionUID = -5429275146280932029L;

    private String eid;
    private String firstName;
    private String lastName;
    private String emailId;

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastname() {
        return lastName;
    }

    public void setLastname(String lastname) {
        this.lastName = lastname;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Override
    public String toString() {
        return "JWTUserDetails [eid=" + eid + ", firstName=" + firstName + ", lastname=" + lastName + ", emailId=" + emailId + "]";
    }

}
