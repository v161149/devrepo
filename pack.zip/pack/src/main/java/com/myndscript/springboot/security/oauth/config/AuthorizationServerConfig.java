package com.myndscript.springboot.security.oauth.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;

@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationServerConfig.class);
    
    @Value("${security.jwt.client-id}")
    private String clientId;

    @Value("${security.jwt.client-secret}")
    private String clientSecret;

    @Value("${security.jwt.grant-type}")
    private String grantType;

    @Value("${security.jwt.scope-read}")
    private String scopeRead;

    @Value("${security.jwt.scope-write}")
    private String scopeWrite;

    @Value("${security.jwt.resource-ids}")
    private String resourceIds;

    @Value("${security.authorization.code}")
    private String authorizationCode;

    @Value("${security.refresh.token}")
    private String refreshToken;

    @Value("${security.implicit}")
    private String implicit;
    
    @Value("${security.trust}")
    private String trust;

    @Value("${security.access.token.validity.seconds}")
    private String accessTokenValidity;
    
    @Value("${security.refresh.token.validity.seconds}")
    private String refreshTokenValidity;
	
	@Autowired
	private TokenStore tokenStore;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Override
	public void configure(ClientDetailsServiceConfigurer configurer) throws Exception {
	    LOGGER.info("oauth-AuthorizationServerConfig::configure(ClientDetailsServiceConfigurer configurer)");
	    configurer.inMemory()
	              .withClient(clientId)
	              .secret(clientSecret)
	              .authorizedGrantTypes(grantType, authorizationCode, refreshToken, implicit )
	              .scopes(scopeRead, scopeWrite, trust)
	              .accessTokenValiditySeconds(Integer.parseInt(accessTokenValidity))
	              .refreshTokenValiditySeconds(Integer.parseInt(refreshTokenValidity));
	}

	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
	    LOGGER.info("oauth-AuthorizationServerConfig::configure(AuthorizationServerEndpointsConfigurer endpoints)");
                endpoints.tokenStore(tokenStore)
				.authenticationManager(authenticationManager);
	}
}