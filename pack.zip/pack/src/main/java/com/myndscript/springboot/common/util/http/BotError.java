package com.myndscript.springboot.common.util.http;

import com.myndscript.springboot.market.EncogError;

/**
 * Used to represent any error that occurs in the bot part of Encog.
 */
public class BotError extends EncogError {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4280940104791165511L;

	/**
	 * Construct a message exception.
	 * 
	 * @param msg
	 *            The exception message.
	 */
	public BotError(final String msg) {
		super(msg);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param t
	 *            The other exception.
	 */
	public BotError(final Throwable t) {
		super(t);
	}
}
