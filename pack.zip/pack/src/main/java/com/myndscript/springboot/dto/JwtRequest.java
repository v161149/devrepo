package com.myndscript.springboot.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "JwtRequest")
public class JwtRequest implements Serializable {

    @SuppressWarnings("compatibility:3311711400504770852")
    private static final long serialVersionUID = -7267796255400282294L;
    @XmlElement(name = "emplId", required = true)
    private String emplId;
    @XmlElement(name = "secretKey", required = true)
    private String secretKey;
    @XmlElement(name = "clientId", required = true)
    private String clientId;
    @XmlElement(name = "identity", required = true)
    private String identity;
    @XmlElement(name = "aud", required = true)
    private String aud;
    @XmlElement(name = "isAnonymous", required = true)
    private boolean isAnonymous;

    public String getEmplId() {
        return emplId;
    }

    public void setEmplId(String emplId) {
        this.emplId = emplId;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
    
    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getAud() {
        return aud;
    }

    public void setAud(String aud) {
        this.aud = aud;
    }

    public boolean isAnonymous() {
        return isAnonymous;
    }

    public void setAnonymous(boolean anonymous) {
        isAnonymous = anonymous;
    }

    @Override
    public String toString() {
        return "KoreJwt{" +
                "emplId='" + emplId + '\'' +
                ", secretKey='" + secretKey + '\'' +
                ", clientId='" + clientId + '\'' +
                ", identity='" + identity + '\'' +
                ", aud='" + aud + '\'' +
                ", isAnonymous=" + isAnonymous +
                '}';
    }
}
