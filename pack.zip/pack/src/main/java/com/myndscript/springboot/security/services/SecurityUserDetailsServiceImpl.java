package com.myndscript.springboot.security.services;

import com.myndscript.springboot.entity.SecurityUser;
import com.myndscript.springboot.entity.SecurityRole;
import com.myndscript.springboot.repositories.SecurityUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

@Service(value = "userService")
public class SecurityUserDetailsServiceImpl implements UserDetailsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SecurityUserDetailsServiceImpl.class);
	@Autowired
    private SecurityUserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    	LOGGER.info("SecurityUserDetailsServiceImpl::loadUserByUsername() is invoked. input username="+username);
    	SecurityUser user = userRepository.findByUsername(username);
    	LOGGER.info("Called userRepository.findByUsername() api.");
        if(user == null) {
        	LOGGER.info("SecurityUser object is empty");
            throw new UsernameNotFoundException(String.format("The username %s doesn't exist", username));
        }
        LOGGER.info("SecurityUser object isn't empty");
        List<GrantedAuthority> authorities = new ArrayList<>();
        List<SecurityRole> roles = user.getSecurityRoles();
        for(SecurityRole role : roles){
            authorities.add(new SimpleGrantedAuthority("ROLE_"+role.getName()));
            LOGGER.info("Role name="+role.getName());
        }

        UserDetails userDetails = new org.springframework.security.core.userdetails.
                                  User(user.getUsername(), user.getEncryptpassword(), authorities);
         
        LOGGER.info("User name="+user.getUsername()+", encryptpassword="+user.getEncryptpassword()+", decryptpassword="+user.getDecryptpassword());
        return userDetails;
    }
}
