package com.myndscript.springboot.facade.noauth;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import net.bull.javamelody.MonitoredWithSpring;
import com.myndscript.springboot.entity.*;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/springbootsvc/no-auth")
public class StudentRetrieveController {
	
    @RequestMapping(method = RequestMethod.GET, value="/student/allstudent")
    @ResponseBody
    public List<Student> getStudent() {
            return StudentRegistration.getInstance().getStudentRecords();
    }

    @RequestMapping(method = RequestMethod.POST, value="/register/student")
    @ResponseBody
    StudentRegistrationReply registerStudent(@RequestBody Student student) {
        System.out.println("In registerStudent");
        StudentRegistrationReply stdregreply = new StudentRegistrationReply();           
    
        StudentRegistration.getInstance().add(student);
    
        //We are setting the below value just to reply a message back to the caller
        stdregreply.setName(student.getName());
        stdregreply.setAge(student.getAge());
        stdregreply.setRegistrationNumber(student.getRegistrationNumber());
        stdregreply.setRegistrationStatus("Successful");
        return stdregreply;
    }
}
