package com.myndscript.springboot.market;

/**
 * Error occurred processing temporal data.
 */
public class TemporalError extends EncogError {
    /**
     * The serial id for this class.
     */
    @SuppressWarnings("compatibility:5396132503847924541")
    private static final long serialVersionUID = -5534812476029464649L;

	/**
	 * Construct a message exception.
	 * 
	 * @param msg
	 *            The exception message.
	 */
	public TemporalError(final String msg) {
		super(msg);
	}

	/**
	 * Construct an exception that holds another exception.
	 * 
	 * @param t
	 *            The other exception.
	 */
	public TemporalError(final Throwable t) {
		super(t);
	}

}
