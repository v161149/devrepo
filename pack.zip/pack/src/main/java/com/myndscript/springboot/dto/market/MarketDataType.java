package com.myndscript.springboot.dto.market;

public enum MarketDataType {
	/**
	 * The market open for the day.
	 */
	OPEN,

	/**
	 * The market close for the day.
	 */
	CLOSE,

        /**
         * The low for the day.
         */
        LOW,
        
        /**
         * The high for the day.
         */
        HIGH,
    
	/**
	 * The volume for the day.
	 */
	VOLUME,
        
        ALL
}
