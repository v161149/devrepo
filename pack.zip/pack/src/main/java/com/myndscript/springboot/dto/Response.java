package com.myndscript.springboot.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "Response")
public class Response implements Serializable{
    private static final long serialversionUID = 129348951L;
	
    @XmlAttribute(name = "status", required=true)
    private String status;
    @XmlAttribute(name = "errMsg", required=true)
    private String errMsg;
    
    public String getStatus() {
    	return status;
    }
    public void setStatus(String param) {
    	this.status=param;
    }
    
    public String getErrMsg() {
    	return errMsg;
    }
    public void setErrMsg(String param) {
    	this.errMsg=param;
    }   
}
