package com.myndscript.spark.kafkasparkintegration.stockprediction;

import com.myndscript.spark.kafkasparkintegration.stockprediction.ai.StockPricePrediction;
import com.myndscript.spark.kafkasparkintegration.stockprediction.dataset.DataSetQueryManager;
import com.myndscript.springboot.market.LoadedMarketData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.time.Duration;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
//import com.google.common.collect.ImmutableList;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.VoidFunction;
//import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.ml.feature.MinMaxScaler;
import org.apache.spark.ml.feature.VectorAssembler;

public class KafkaSparkMktDataLoadConsumer {
    public static void main(String[] args) {
        KafkaConsumer<String, LoadedMarketData> consumer = null;
        try {
            JsonDeserializer<LoadedMarketData> deserializer = new JsonDeserializer<>(LoadedMarketData.class);
            deserializer.setRemoveTypeHeaders(false);
            deserializer.addTrustedPackages("*");
            deserializer.setUseTypeMapperForKey(true); 
            
            Map<String, Object> config = new HashMap<>();
            config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
            config.put(ConsumerConfig.GROUP_ID_CONFIG, "jsa-group");
            config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
            config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
            config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
            config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, deserializer);
            consumer = new KafkaConsumer<>(config,new StringDeserializer(), deserializer);
            consumer.subscribe(Arrays.asList("jsa-springboot-topic"));        
    
            boolean running = true;
            System.out.println("Spark computation engine received Kafka messages....");
            
            //----------Option #1 starts---------//
            //SparkSession spark = SparkSession.builder().master("local[2]").appName("Stock Real-Time Prediction Demo").getOrCreate();
            //JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());
            //SQLContext sqlContext2 = spark.sqlContext();
            //----------Option #1 ends---------//
            
            //----------Option #2 starts---------//
            // configure spark
            SparkConf sparkConf = new SparkConf().setAppName("Load Stock Market Rea-Time Data")
                                                 .setMaster("local[2]").set("spark.executor.memory","512m");
            // start a spark context
            JavaSparkContext jsp = new JavaSparkContext(sparkConf);
            //Create the sql context
            SQLContext sqlContext =  new SQLContext(jsp);
            //----------Option #2 ends---------//
            
            List<StructField> fieldList = new ArrayList<StructField>();
            //Create 9 objects for 9 columns
            fieldList.add(DataTypes.createStructField("date",DataTypes.DateType,true));
            fieldList.add(DataTypes.createStructField("sdate",DataTypes.StringType,true));
            fieldList.add(DataTypes.createStructField("symbol",DataTypes.StringType,true));
            fieldList.add(DataTypes.createStructField("open",DataTypes.DoubleType,true));
            fieldList.add(DataTypes.createStructField("close",DataTypes.DoubleType,true));
            fieldList.add(DataTypes.createStructField("low",DataTypes.DoubleType,true));
            fieldList.add(DataTypes.createStructField("high",DataTypes.DoubleType,true));
            fieldList.add(DataTypes.createStructField("adj close",DataTypes.DoubleType,true));
            fieldList.add(DataTypes.createStructField("volume",DataTypes.IntegerType,true));
            //Now create a StructType object from the list
            StructType tickerTblSchema = DataTypes.createStructType(fieldList);
            List<Row> rowList = new ArrayList<>();
            List<LoadedMarketData> stockHistList = new ArrayList<>();
            int stockInfoRecordCounts = 0;
            String symbol = "XON";
            
            while (running) {
                ConsumerRecords<String, LoadedMarketData> records = consumer.poll(Duration.ofMillis(2000));
                if(records!=null&&!records.isEmpty()) {
                    for (ConsumerRecord<String, LoadedMarketData> record : records) {
                        stockInfoRecordCounts++;
                        rowList.add(RowFactory.create(new java.sql.Date(record.value().getWhen().getTime()),
                                                      record.value().getStrWhen(),
                                                      record.value().getTicker(),
                                                      new Double(record.value().getOpenPrice()),
                                                      new Double(record.value().getClosePrice()),
                                                      new Double(record.value().getLowPrice()),
                                                      new Double(record.value().getHighPrice()),
                                                      new Double(record.value().getAdjClosePrice()),
                                                      new Integer((int)record.value().getVolumn())));
                        stockHistList.add(record.value().getShallowCopy());
                        System.out.println(record.value().toString());
                    }                
                } else if ((records==null||records.isEmpty())&&stockInfoRecordCounts>0) {
                    running = false;
                    break;
                }
            }
            Dataset<Row> rawDataSet = sqlContext.createDataFrame(rowList, tickerTblSchema).toDF();
            //Display loaded rea-time stoc data
            System.out.println("Display loaded rea-time stoc data..");
            DataSetQueryManager.queryShowSymbolAndNumberofCounts(rawDataSet); 
            
            //Prepare dataset for training with all features in "features" column
            System.out.println("Prepare dataset for training with all features in \"features\" column..");
            VectorAssembler assembler = new VectorAssembler().setInputCols(new String[] {"open", "low", "high", "volume", "close"})
                                                             .setOutputCol("features");

            rawDataSet = assembler.transform(rawDataSet).drop("open", "low", "high", "volume", "close");

            rawDataSet = new MinMaxScaler().setMin(0)
                                           .setMax(1)
                                           .setInputCol("features").setOutputCol("normalizedFeatures")
                                           .fit(rawDataSet).transform(rawDataSet)
                                           .drop("features").toDF("features"); 
            //Load the history data into Stock Prediction engine and then predict the future
            StockPricePrediction.predictStockFuture(stockHistList, symbol);
        } catch (Exception exp) {
            exp.printStackTrace();
        } finally {
            if (consumer!=null) {
                consumer.close();
            }
        }
    }
}