package com.myndscript.spark.kafkasparkintegration.stockprediction.dataset;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.functions;

public class DataSetQueryManager {

    public static void queryShowDataSet(Dataset<Row> rawDataSet) throws Exception {
        if (rawDataSet!=null&&rawDataSet.count()>0) {
            rawDataSet.show();
        }
    }
    
    public static void queryShowSymbolAndNumberofCounts(Dataset<Row> rawDataSet) throws Exception {
        if (rawDataSet!=null&&rawDataSet.count()>0) {
            Dataset<Row> symbols = rawDataSet.select("sdate", "symbol").groupBy("symbol").agg(functions.count("sdate").as("count"));
            System.out.println("Number of Symbols: " + symbols.count());
            symbols.show();
        }
    }    
}
