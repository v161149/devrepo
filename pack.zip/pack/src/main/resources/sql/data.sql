DELETE FROM DEV_SECURITY_USER_ROLE;
DELETE FROM DEV_SECURITY_ROLE;
DELETE FROM DEV_SECURITY_USER;

INSERT INTO DEV_SECURITY_ROLE (id, name, description) VALUES (DEV_SECURITY_ROLE_ID_SEQUENCE.nextval, 'USER', 'User - has authority to call async-RESTful-pulling api');
INSERT INTO DEV_SECURITY_ROLE (id, name, description) VALUES (DEV_SECURITY_ROLE_ID_SEQUENCE.nextval, 'ADMIN', 'Admin - has authority to call async-RESTful-api');
INSERT INTO DEV_SECURITY_ROLE (id, name, description) VALUES (DEV_SECURITY_ROLE_ID_SEQUENCE.nextval, 'SUPER_ADMIN', 'Super Admin - has authority to call sync-RESTful-real-time api');

INSERT INTO DEV_SECURITY_USER (id, username, password,firstname,lastname,emplid,emailid) VALUES (DEV_SECURITY_USER_ID_SEQUENCE.nextval, 'mynd-user', '3112usr','Brian','Xu','v001','beijiang.x.xu@gmail.com');
INSERT INTO DEV_SECURITY_USER (id, username, password,firstname,lastname,emplid,emailid) VALUES (DEV_SECURITY_USER_ID_SEQUENCE.nextval, 'mynd-admin', '3112adm','Jeffrey','Xu','v002','jeffrey.x.xu@gmail.com');
INSERT INTO DEV_SECURITY_USER (id, username, password,firstname,lastname,emplid,emailid) VALUES (DEV_SECURITY_USER_ID_SEQUENCE.nextval, 'mynd-superadmin', '3112sadm','Jessica','Xu','v003','jessica.x.xu@gmail.com');

INSERT INTO DEV_SECURITY_USER_ROLE(user_id, role_id) VALUES(1,1);
INSERT INTO DEV_SECURITY_USER_ROLE(user_id, role_id) VALUES(2,2);
INSERT INTO DEV_SECURITY_USER_ROLE(user_id, role_id) VALUES(3,3);
--Bcrypt Hash Generator and Matcher
--https://www.devglan.com/online-tools/bcrypt-hash-generator
update dev_security_user set password='$2a$08$M6B8UM7Pf85qWSTekTB4ZOfmqIE.zmAN4XCzJj1SivQ5iZHKWchHe' where username='mynd-user';
update dev_security_user set password='$2a$08$hwY1Z7dn1QqKtiuw8GNJIelzCHP36fXhHnwG7zJamNONjVZRAuqfW' where username='mynd-admin';
update dev_security_user set password='$2a$08$op.7mp922JcvuoRcAGcxou0n7MYdUD86oX4LMsuA26frGhmQuCC7C' where username='mynd-superadmin';
