database_svc CLI
=================

This repository includes a small interactive SQLite CLI at `database_svc/db_cli.py` for quick inspection and safe modifications of the project's database. It also includes a transactional test script `database_svc/tx_test.py`.

db_cli.py features

- Interactive prompt with transaction-aware indicator. When a transaction is active the prompt shows `tx(<db_name)>`, otherwise it shows `<db_name> >`.
- Commands:
  - `.tables` - list tables
  - `.schema <table>` - show CREATE statement for a table
  - `SELECT <...>` - run a SELECT query and print results. For multi-line SQL, terminate with `;`.
  - `UPDATE/DELETE <...>` - modify data. Full-table operations (no WHERE) require explicit confirmation. These commands can be executed inside a transaction.
  - `BEGIN` - start a transaction
  - `COMMIT` - commit the current transaction
  - `ROLLBACK` - rollback the current transaction
  - `.tx` - show transaction status
  - `exit` - quit the CLI

Notes
- Multi-line SQL: When you enter a statement that doesn't finish with a semicolon, the CLI will prompt with `... ` for additional lines. Terminate the statement with `;` on the last line.
- Safety: Destructive statements (UPDATE/DELETE without WHERE) require typing `UPDATE ALL` or `DELETE ALL` on the confirmation prompt.
- Transactions: If you `BEGIN` a transaction, subsequent UPDATE/DELETE statements will not be auto-committed; use `COMMIT` to persist changes or `ROLLBACK` to undo.

Advanced formatting and environment toggles

- Wrap width: Set the maximum column width (default 100) with environment variable `DB_CLI_MAX_COL_WIDTH`.
- Per-column width overrides: use `DB_CLI_COL_WIDTHS` with format `col1=80,col2=40` to set a specific width for named columns (case-insensitive column names). Example:
 - Per-column width overrides: use `DB_CLI_COL_WIDTHS` with format `col1=80,col2=40` to set a specific width for named columns (case-insensitive column names). Example:
```powershell
$env:DB_CLI_COL_WIDTHS = 'name=30,sql=80'
```

- Preserve SQL indentation: the CLI attempts to preserve leading whitespace when wrapping SQL or other indented text so wrapped lines keep original indentation.
- Disable color: set `DB_CLI_NO_COLOR=1` to turn off ANSI coloring in headers and separators.

- Per-column alignment: use `DB_CLI_COL_ALIGN` with format `col1=left,col2=center` to set alignment per column. Values are `left`, `center`, or `right`.
  Example:

```powershell
$env:DB_CLI_COL_ALIGN = 'name=left,sql=center'
```

Running the CLI

From PowerShell (example):

```powershell
python .\database_svc\db_cli.py .\database\SLA_MANAGEMENT_DB.db
```

Transactional test script

`database_svc/tx_test.py` programmatically tests transaction visibility across two connections. It prints PASS/FAIL for rollback and commit visibility. Run it with the path to your DB (it defaults to `../database/SLA_MANAGEMENT_DB.db`):

```powershell
python .\database_svc\tx_test.py
```

If you want changes to behavior (prompt format, multi-line terminator, command aliases), open an issue or edit `db_cli.py` directly.