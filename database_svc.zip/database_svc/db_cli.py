import os
import sqlite3
import sys

def print_help():
    """Prints help for the interactive CLI."""
    print("Commands:")
    print("  .tables                - list tables")
    print("  .schema <table>        - show CREATE statement for a table")
    print("  SELECT <...>           - run a query and print results (terminate with ; for multi-line)")
    print("  UPDATE/DELETE <...>    - modify data (prompts for confirmation)")
    print("  BEGIN                  - start a transaction")
    print("  COMMIT                 - commit current transaction")
    print("  ROLLBACK               - rollback current transaction")
    print("  .tx                    - show transaction status")
    print("  exit                   - quit the CLI")

def list_tables(cursor):
    """Prints a list of all tables in the database."""
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    if tables:
        print("Tables:")
        for table in tables:
            print(f"- {table[0]}")
    else:
        print("No tables found.")

def show_schema(cursor, table_name):
    """Prints the schema (CREATE statement) for a specific table."""
    cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}';")
    schema = cursor.fetchone()
    if schema:
        print(f"Schema for '{table_name}':")
        print(schema[0])
    else:
        print(f"Table '{table_name}' not found.")

def query_table(cursor, query):
    """Executes a SELECT query and prints the results."""
    try:
        cursor.execute(query)
        rows = cursor.fetchall()
        
        if not rows:
            print("No results found.")
            return

        import textwrap

        # Max column width (can be overridden by env var DB_CLI_MAX_COL_WIDTH)
        try:
            MAX_COL_WIDTH = int(os.environ.get('DB_CLI_MAX_COL_WIDTH', '100'))
        except Exception:
            MAX_COL_WIDTH = 100

        # Convert rows to strings and compute widths per column
        column_names = [description[0] for description in cursor.description]
        # stringified rows (replace None with 'NULL')
        str_rows = []
        for row in rows:
            str_rows.append([('NULL' if v is None else str(v)) for v in row])

        col_count = len(column_names)
        # Determine column widths but cap by MAX_COL_WIDTH so long cells will wrap
        widths = [0] * col_count
        for i, col in enumerate(column_names):
            widths[i] = len(col)
        for r in str_rows:
            for i, cell in enumerate(r):
                widths[i] = max(widths[i], min(len(cell), MAX_COL_WIDTH))

        # Per-column alignment overrides (format: col1=left,col2=center). Values: left, center, right
        col_align_overrides = {}
        raw_align = os.environ.get('DB_CLI_COL_ALIGN', '').strip()
        if raw_align:
            try:
                for part in raw_align.split(','):
                    if not part.strip():
                        continue
                    if '=' in part:
                        k, v = part.split('=', 1)
                    elif ':' in part:
                        k, v = part.split(':', 1)
                    else:
                        continue
                    k = k.strip().lower()
                    val = v.strip().lower()
                    if val in ('left', 'center', 'right'):
                        col_align_overrides[k] = val
            except Exception:
                col_align_overrides = {}

        # Prepare wrapped cells: for each row produce list of lists (lines)
        wrapped_rows = []
        for r in str_rows:
            wrapped = []
            for i, cell in enumerate(r):
                w = widths[i]
                # Use textwrap to preserve words where possible
                if len(cell) <= w:
                    lines = [cell]
                else:
                    # wrap on whitespace; fallback to hard break if necessary
                    lines = textwrap.wrap(cell, width=w, break_long_words=True, break_on_hyphens=False)
                    if not lines:
                        lines = [cell[:w]]
                wrapped.append(lines)
            wrapped_rows.append(wrapped)

        # Header and separator (header centered by default)
        def align_text(s, w, alignment='left'):
            if alignment == 'right':
                return s.rjust(w)
            if alignment == 'center':
                return s.center(w)
            return s.ljust(w)

        header = ' | '.join(align_text(column_names[i], widths[i], 'center') for i in range(col_count))
        sep = '-+-'.join('-' * widths[i] for i in range(col_count))
        print(header)
        print(sep)

        # Print each wrapped row: determine the max height for the row and print line-by-line
        for wrapped in wrapped_rows:
            row_height = max(len(cell_lines) for cell_lines in wrapped)
            for line_idx in range(row_height):
                parts = []
                for i in range(col_count):
                    cell_lines = wrapped[i]
                    txt = cell_lines[line_idx] if line_idx < len(cell_lines) else ''
                    col_key = column_names[i].strip().lower()
                    alignment = col_align_overrides.get(col_key, 'left')
                    parts.append(align_text(txt, widths[i], alignment))
                print(' | '.join(parts))
            
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")


def execute_modification(conn, cursor, sql, commit=True):
    """Execute UPDATE or DELETE statements with safety confirmations.

    This function prompts the user to confirm destructive operations and
    commits the transaction if confirmed. It prints the number of affected rows.
    """
    sql_strip = sql.strip()
    cmd = sql_strip.split()[0].lower() if sql_strip else ''

    # Warn if no WHERE clause (potential full-table op)
    has_where = ' where ' in sql_strip.lower()

    print(f"About to run: {sql_strip}")
    if cmd in ('delete', 'update') and not has_where:
        # require explicit confirmation for full-table operations
        confirm = input(f"WARNING: This {cmd.upper()} has no WHERE clause and may affect all rows.\nType '{cmd.upper()} ALL' to proceed: ")
        if confirm != f"{cmd.upper()} ALL":
            print("Aborted by user.")
            return
    else:
        confirm = input("Are you sure you want to execute this statement? (yes/no): ")
        if confirm.strip().lower() != 'yes':
            print("Aborted by user.")
            return

    try:
        cursor.execute(sql_strip)
        if commit:
            conn.commit()
        # sqlite3 Cursor.rowcount may be -1 for some statements; attempt to report it
        try:
            affected = cursor.rowcount
        except Exception:
            affected = 'unknown'
        print(f"Statement executed. Rows affected: {affected}")
    except sqlite3.Error as e:
        print(f"An error occurred executing modification: {e}")

def main(db_path):
    """Main function for the interactive terminal interface with transaction support."""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        print(f"Connected to database: {db_path}")

        in_tx = False
        db_name = os.path.basename(db_path)
        while True:
            # show transaction-aware prompt
            prompt = f"tx({db_name})> " if in_tx else f"{db_name}> "

            # Read a statement. Support multi-line SQL terminated by a semicolon or a blank line.
            def read_statement():
                lines = []
                while True:
                    try:
                        line = input(prompt if not lines else '... ')
                    except (EOFError, KeyboardInterrupt):
                        return None
                    if line is None:
                        return None
                    # preserve original line content but strip trailing whitespace
                    stripped = line.rstrip()
                    # blank line terminates multi-line input if we've already read something
                    if stripped == '' and lines:
                        return ' '.join(l.strip() for l in lines).strip()
                    lines.append(stripped)
                    # single-word commands finish immediately
                    first = lines[0].strip().split()[0].lower() if lines[0].strip() else ''
                    if first in ('begin', 'commit', 'rollback', '.tx', '.tables', '.help', 'help', 'exit', 'quit') or lines[0].strip().lower().startswith('.schema'):
                        return lines[0].strip()
                    # if any line ends with semicolon, finish and return full joined input (keep semicolons for multi-statement handling)
                    if any(l.endswith(';') for l in lines):
                        stmt = ' '.join(l.strip() for l in lines)
                        return stmt.strip()

            raw = read_statement()
            if raw is None:
                # treat as user interrupt
                print('\nExiting.')
                break
            if not raw:
                continue

            # Allow multiple statements separated by semicolons in a single input.
            # Normalize and split; keep statements that are not empty after stripping.
            parts = [p.strip() for p in raw.split(';') if p.strip()]
            for cl in parts:
                low = cl.lower()

                if low in ('.tables',):
                    list_tables(cursor)
                    continue

                if low.startswith('.schema '):
                    table_name = cl.split(' ', 1)[1]
                    show_schema(cursor, table_name)
                    continue

                if low in ('exit', 'quit'):
                    # If a transaction is active, warn user
                    if in_tx:
                        print('A transaction is active. Commit or rollback before exiting.')
                        continue
                    # exit the outer loop and CLI
                    return

                if low in ('.help', 'help'):
                    print_help()
                    continue

            # Transaction controls
                if low in ('begin', '.begin'):
                    try:
                        conn.execute('BEGIN')
                        in_tx = True
                        print('Transaction started.')
                    except sqlite3.Error as e:
                        print(f'Failed to begin transaction: {e}')
                    continue

                if low == 'commit':
                    if in_tx:
                        try:
                            conn.commit()
                            in_tx = False
                            print('Transaction committed.')
                        except sqlite3.Error as e:
                            print(f'Commit failed: {e}')
                    else:
                        print('No active transaction.')
                    continue

                if low == 'rollback':
                    if in_tx:
                        try:
                            conn.rollback()
                            in_tx = False
                            print('Transaction rolled back.')
                        except sqlite3.Error as e:
                            print(f'Rollback failed: {e}')
                    else:
                        print('No active transaction.')
                    continue

                if low == '.tx':
                    print('In transaction.' if in_tx else 'Not in transaction.')
                    continue

                # SELECT queries
                if low.startswith('select'):
                    query_table(cursor, cl)
                    continue

                # UPDATE/DELETE with safety checks
                if low.startswith(('update', 'delete')):
                    # detect unsafe full-table operation (no WHERE)
                    if ' where ' not in low:
                        print('\nWARNING: This statement will affect all rows in the table(s).')
                        print("To proceed type: YES (all caps)")
                        confirmation = input('Confirm: ').strip()
                        if confirmation != 'YES':
                            print('Aborted.')
                            continue

                    # execute; if in a transaction, defer commit until user calls COMMIT
                    execute_modification(conn, cursor, cl, commit=(not in_tx))
                    continue

                print("Invalid command. Supported: .tables, .schema <name>, SELECT <...>, UPDATE <...>, DELETE <...>, BEGIN, COMMIT, ROLLBACK, .tx, exit")

            # end for each statement in parts

    except sqlite3.Error as e:
        print(f"Failed to connect to database: {e}")
        sys.exit(1)
    finally:
        if 'conn' in locals() and conn:
            # If a transaction is still open, roll it back to avoid leaving DB locked
            try:
                if in_tx:
                    conn.rollback()
                    print('Rolled back active transaction on exit.')
            except Exception:
                pass
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python db_cli.py <database_file.db>")
        sys.exit(1)
    
    database_file = sys.argv[1]
    main(database_file)