import sqlite3
import os
from pathlib import Path

DATABASE_NAME = "SLA_MANAGEMENT_DB"
# Place the database file in the project's top-level `database` directory.
# Compute project root based on this file's location (assumes this file is in
# database_gen_svc/ under the project root).
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATABASE_DIR = PROJECT_ROOT / "database"
DATABASE_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = str(DATABASE_DIR / f"{DATABASE_NAME}.db")


def create_database():
    """Create SQLite database and all required tables."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # Table 1: ASSETS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ASSETS (
                ASSET_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                ASSET_NAME TEXT NOT NULL UNIQUE,
                AIT_NUMBER INTEGER,
                STATUS TEXT
            )
        """)
        
        # Table 2: SLA_DATABASE_DETAILS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SLA_DATABASE_DETAILS (
                ASSET_ID INTEGER NOT NULL,
                DATABASE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                DATABASE_NAME TEXT,
                BUSINESS_NAME TEXT,
                BUSINESS_DESCRIPTION TEXT,
                FOREIGN KEY (ASSET_ID) REFERENCES ASSETS(ASSET_ID)
            )
        """)
        
        # Table 3: SLA_DATABASE_TABLE_DETAILS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SLA_DATABASE_TABLE_DETAILS (
                DATABASE_ID INTEGER NOT NULL,
                TABLE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                TABLE_NAME TEXT,
                BUSINESS_NAME TEXT,
                BUSINESS_DESCRIPTION TEXT,
                FOREIGN KEY (DATABASE_ID) REFERENCES SLA_DATABASE_DETAILS(DATABASE_ID)
            )
        """)
        
        # Table 4: SLA_DATABASE_TABLE_COLUMN_DETAILS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SLA_DATABASE_TABLE_COLUMN_DETAILS (
                TABLE_ID INTEGER NOT NULL,
                COLUMN_NAME TEXT,
                DATA_TYPE TEXT,
                BUSINESS_NAME TEXT,
                BUSINESS_DESCRIPTION TEXT,
                CLASSIFICATION TEXT,
                FOREIGN KEY (TABLE_ID) REFERENCES SLA_DATABASE_TABLE_DETAILS(TABLE_ID)
            )
        """)
        
        # Table 5: SCHEDULED_SLAS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SCHEDULED_SLAS (
                ASSET_ID INTEGER NOT NULL,
                SLA_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                SLA_NAME TEXT,
                SLA_TYPE TEXT,
                TIME_ZONE TEXT,
                FIRST_EXECUTION_DATE TEXT,
                EXPECTED_START_TIME TEXT,
                EXPECTED_END_TIME TEXT,
                FREQUENCY TEXT,
                DEPENDENT_SLAS TEXT,
                DEPENDENT_JOBS TEXT,
                FOREIGN KEY (ASSET_ID) REFERENCES ASSETS(ASSET_ID)
            )
        """)
        
        # Table 6: SCHEDULED_JOBS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SCHEDULED_JOBS (
                SLA_ID INTEGER NOT NULL,
                JOB_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                JOB_NAME TEXT,
                JOB_TYPE TEXT,
                TIME_ZONE TEXT,
                FIRST_EXECUTION_DATE TEXT,
                EXPECTED_START_TIME TEXT,
                EXPECTED_END_TIME TEXT,
                FREQUENCY TEXT,
                DEPENDENT_JOBS TEXT,
                FOREIGN KEY (SLA_ID) REFERENCES SCHEDULED_SLAS(SLA_ID)
            )
        """)
        
        # Table 7: SLAS_MONITOR_LOG
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SLAS_MONITOR_LOG (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                SLA_SRC_ID TEXT,
                SLA_NAME TEXT,
                SLA_TYPE TEXT,
                TIME_ZONE TEXT,
                FREQUENCY TEXT,
                EXPECTED_EXECUTION_DATE TEXT,
                EXPECTED_START_TIME TEXT,
                EXPECTED_END_TIME TEXT,
                EXECUTION_DATE TEXT,
                START_TIME TEXT,
                END_TIME TEXT,
                STATUS TEXT,
                DEPENDENT_SLAS TEXT,
                DEPENDENT_JOBS TEXT
            )
        """)
        
        # Table 8: JOBS_MONITOR_LOG
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS JOBS_MONITOR_LOG (
                SLA_ID INTEGER,
                SLA_SRC_ID TEXT,
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                JOB_SRC_ID INTEGER,
                JOB_NAME TEXT,
                JOB_TYPE TEXT,
                TIME_ZONE TEXT,
                FREQUENCY TEXT,
                EXPECTED_EXECUTION_DATE TEXT,
                EXPECTED_START_TIME TEXT,
                EXPECTED_END_TIME TEXT,
                EXECUTION_DATE TEXT,
                START_TIME TEXT,
                END_TIME TEXT,
                STATUS TEXT,
                DEPENDENT_JOBS TEXT
            )
        """)
        
        # Table 9: SLAS_DELIVERIES_HISTORY
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS SLAS_DELIVERIES_HISTORY (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                SLA_SRC_ID TEXT,
                SLA_NAME TEXT,
                SLA_TYPE TEXT,
                TIME_ZONE TEXT,
                FREQUENCY TEXT,
                EXPECTED_EXECUTION_DATE TEXT,
                EXPECTED_START_TIME TEXT,
                EXPECTED_END_TIME TEXT,
                EXECUTION_DATE TEXT,
                START_TIME TEXT,
                END_TIME TEXT,
                STATUS TEXT,
                DEPENDENT_SLAS TEXT,
                DEPENDENT_JOBS TEXT
            )
        """)
        
        # Table 10: JOBS_DELIVERIES_HISTORY
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS JOBS_DELIVERIES_HISTORY (
                SLA_ID INTEGER,
                SLA_SRC_ID TEXT,
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                JOB_SRC_ID INTEGER,
                JOB_NAME TEXT,
                JOB_TYPE TEXT,
                TIME_ZONE TEXT,
                FREQUENCY TEXT,
                EXPECTED_EXECUTION_DATE TEXT,
                EXPECTED_START_TIME TEXT,
                EXPECTED_END_TIME TEXT,
                EXECUTION_DATE TEXT,
                START_TIME TEXT,
                END_TIME TEXT,
                STATUS TEXT,
                DEPENDENT_JOBS TEXT
            )
        """)
        
        conn.commit()
        print(f"Database '{DATABASE_NAME}' created successfully at: {DB_PATH}")
        print("All 10 tables created successfully.")
        
    except sqlite3.Error as e:
        print(f"Error creating database: {e}")
        conn.rollback()
        
    finally:
        conn.close()


def verify_database():
    """Verify database and tables were created."""
    if not os.path.exists(DB_PATH):
        print("Database file not found.")
        return False
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    )
    tables = cursor.fetchall()
    conn.close()
    
    expected_tables = [
        "ASSETS",
        "SLA_DATABASE_DETAILS",
        "SLA_DATABASE_TABLE_DETAILS",
        "SLA_DATABASE_TABLE_COLUMN_DETAILS",
        "SCHEDULED_SLAS",
        "SCHEDULED_JOBS",
        "SLAS_MONITOR_LOG",
        "JOBS_MONITOR_LOG",
        "SLAS_DELIVERIES_HISTORY",
        "JOBS_DELIVERIES_HISTORY"
    ]
    
    # Filter out internal SQLite tables (e.g., sqlite_sequence) which can appear
    # when using AUTOINCREMENT. Only consider user tables for verification.
    actual_tables = [table[0] for table in tables if not table[0].startswith('sqlite_')]

    print("\n--- Database Verification ---")
    print(f"Database Location: {DB_PATH}")
    print(f"Total User Tables Found: {len(actual_tables)}")

    missing_tables = [t for t in expected_tables if t not in actual_tables]
    for expected_table in expected_tables:
        status = "✓" if expected_table in actual_tables else "✗"
        print(f"{status} {expected_table}")

    if not missing_tables:
        print("\n✓ All expected tables created successfully!")
        return True
    else:
        print("\n✗ Some tables are missing:")
        for t in missing_tables:
            print(f" - {t}")
        return False


if __name__ == "__main__":
    create_database()
    verify_database()