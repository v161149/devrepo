/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

export { default as DynamicIcon, iconNames } from './dist/esm/DynamicIcon.js';
export { default as dynamicIconImports } from './dist/esm/dynamicIconImports.js';
//# sourceMappingURL=dynamic.mjs.map
