
require('thenify-all').withCallback(
  require('child_process'),
  exports, [
    'exec',
    'execFile',
  ]
)
