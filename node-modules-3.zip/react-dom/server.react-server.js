'use strict';

throw new Error(
  'react-dom/server is not supported in React Server Components.'
);
