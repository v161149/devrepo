"""
MCP Client - REST API service that uses Gemini LLM with MCP tools
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import google.generativeai as genai
from fastmcp.client import Client as MCPClient
import os
from dotenv import load_dotenv
import json
import uvicorn
from contextlib import asynccontextmanager

# Configuration
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://localhost:8001")

# Pydantic models for request/response
class ColumnRequest(BaseModel):
    column_name: str

class ColumnResponse(BaseModel):
    column_name: str
    business_name: str
    business_description: str
    classification: str

class TableRequest(BaseModel):
    table_name: str
    columns: List[ColumnRequest]

class TableResponse(BaseModel):
    table_name: str
    business_name: str
    business_description: str
    columns: List[ColumnResponse]

class SchemaEnrichmentRequest(BaseModel):
    request_id: str
    database_name: str
    tables: List[TableRequest]

class SchemaEnrichmentResponse(BaseModel):
    request_id: str
    database_name: str
    business_name: str
    business_description: str
    tables: List[TableResponse]


# MCP Client wrapper
class MCPClientWrapper:
    def __init__(self):
        self.client = None
        self.tools = []
        
    async def connect(self):
        """Connect to MCP server"""
        try:
            # Create MCP client with HTTP transport
            self.client = MCPClient(MCP_SERVER_URL)
            # fastmcp.Client uses an async context/connect pattern. Use its _connect
            # method to establish the session for long-lived usage.
            await self.client._connect()

            # Get available tools
            try:
                self.tools = await self.client.list_tools()
                # tools are mcp Tool dataclasses; try to show names if present
                tool_names = [getattr(t, 'name', repr(t)) for t in self.tools]
                print(f"Connected to MCP server. Available tools: {tool_names}")
            except Exception:
                # If listing tools fails, leave tools empty but keep client connected
                self.tools = []
                print("Connected to MCP server, but failed to list tools.")
        except Exception as e:
            # Don't raise here — allow the FastAPI app to start even if MCP server
            # is not available. Keep client as None to indicate not connected.
            print(f"Failed to connect to MCP server: {e}")
            self.client = None
            self.tools = []
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Call a tool on the MCP server"""
        if not self.client:
            raise RuntimeError("MCP client not connected")
        # If client exists but is not connected, report as not connected
        if hasattr(self.client, 'is_connected') and not self.client.is_connected():
            raise RuntimeError("MCP client not connected")
        
        try:
            result = await self.client.call_tool(tool_name, arguments)
            return result
        except Exception as e:
            print(f"Error calling tool {tool_name}: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from MCP server"""
        if self.client:
            # Use close() to forcefully stop the client and close the transport
            # (clean shutdown).
            await self.client.close()


# Global MCP client
mcp_client = MCPClientWrapper()


# Lifespan context manager for FastAPI
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    await mcp_client.connect()
    yield
    # Shutdown
    await mcp_client.disconnect()


# Initialize FastAPI app
app = FastAPI(
    title="Business Metadata Enrichment API",
    description="Enrich database schemas with business metadata using Gemini LLM and MCP",
    version="1.0.0",
    lifespan=lifespan
)


def get_gemini_model():
    """Initialize and return Gemini model"""
    if not GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY environment variable not set")
    
    genai.configure(api_key=GEMINI_API_KEY)
    return genai.GenerativeModel('gemini-2.0-flash-exp')


def create_mcp_tools_description() -> str:
    """Create a description of available MCP tools for the LLM"""
    tools_desc = """
Available MCP Tools for enriching metadata:

1. enrich_database_metadata(database_name: str) -> Dict
   - Adds business_name and business_description for a database
   
2. enrich_table_metadata(table_name: str, database_context: str) -> Dict
   - Adds business_name and business_description for a table
   
3. enrich_column_metadata(column_name: str, table_context: str, database_context: str) -> Dict
   - Adds business_name, business_description, and classification for a column
   
4. enrich_full_schema(schema_data: Dict) -> Dict
   - Enriches the complete schema in one call

You should use these tools to generate accurate business metadata.
"""
    return tools_desc


async def process_with_gemini_and_mcp(request_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process the schema enrichment request using Gemini LLM with MCP tools
    """
    try:
        # Use the full schema enrichment tool for efficiency
        result = await mcp_client.call_tool(
            "enrich_full_schema",
            {"schema_data": request_data}
        )
        
        # Extract content from MCP result
        if isinstance(result, dict) and 'content' in result:
            # Parse the content if it's a string
            content = result['content']
            if isinstance(content, str):
                # Try to parse as JSON
                try:
                    return json.loads(content)
                except:
                    pass
            elif isinstance(content, list) and len(content) > 0:
                # Handle list content
                first_item = content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    try:
                        return json.loads(first_item['text'])
                    except:
                        pass
            return content
        
        return result
        
    except Exception as e:
        print(f"Error in MCP tool call: {e}")
        # Fallback: try using Gemini directly with tool descriptions
        return await fallback_gemini_processing(request_data)


async def fallback_gemini_processing(request_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fallback processing using Gemini LLM when MCP tools fail
    """
    model = get_gemini_model()
    
    system_prompt = f"""You are a database metadata expert. Your task is to enrich database schemas with business-friendly metadata.

{create_mcp_tools_description()}

Given a database schema, you need to:
1. Add 'business_name' and 'business_description' to the database level
2. Add 'business_name' and 'business_description' to each table
3. Add 'business_name', 'business_description', and 'classification' to each column

Classification levels:
- Confidential: Sensitive data like passwords, user IDs, SSNs
- Restricted: Personal information like email, phone, address
- Internal: Non-public operational data
- Public: Information meant for public access

Return ONLY a valid JSON object with the enriched schema. Do not include any markdown or explanations.
"""
    
    user_prompt = f"""Please enrich this database schema:

{json.dumps(request_data, indent=2)}

Return the complete enriched schema as JSON."""
    
    try:
        response = model.generate_content(
            f"{system_prompt}\n\n{user_prompt}"
        )
        
        # Parse the response
        response_text = response.text.strip()
        
        # Remove markdown code blocks if present
        if response_text.startswith('```'):
            response_text = response_text.split('```')[1]
            if response_text.startswith('json'):
                response_text = response_text[4:]
            response_text = response_text.strip()
        
        enriched_data = json.loads(response_text)
        return enriched_data
        
    except Exception as e:
        print(f"Error in Gemini fallback: {e}")
        raise


@app.post("/enrich-schema", response_model=SchemaEnrichmentResponse)
async def enrich_schema(request: SchemaEnrichmentRequest):
    """
    Enrich database schema with business metadata using Gemini LLM and MCP tools
    """
    try:
        # Convert request to dict
        request_dict = request.model_dump()
        
        # Process with Gemini and MCP
        enriched_data = await process_with_gemini_and_mcp(request_dict)
        
        # Validate and return response
        response = SchemaEnrichmentResponse(**enriched_data)
        return response
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to enrich schema: {str(e)}"
        )


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "mcp_connected": mcp_client.client is not None,
        "gemini_configured": GEMINI_API_KEY is not None
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)