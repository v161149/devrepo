"""
MCP Server - Provides business metadata enrichment tools
"""
from fastmcp import FastMCP
from typing import Dict, List, Any
import uvicorn

# Initialize FastMCP server
mcp = FastMCP("Business Metadata Server")


@mcp.tool()
def enrich_database_metadata(database_name: str) -> Dict[str, str]:
    """
    Enriches database with business name and description.
    
    Args:
        database_name: The technical database name
        
    Returns:
        Dictionary with business_name and business_description
    """
    # This is a simplified implementation
    # In production, this would connect to a metadata repository
    business_name = database_name.replace('_', ' ').title()
    business_description = f"{business_name} - Enterprise database"
    
    return {
        "business_name": business_name,
        "business_description": business_description
    }


@mcp.tool()
def enrich_table_metadata(table_name: str, database_context: str = "") -> Dict[str, str]:
    """
    Enriches table with business name and description.
    
    Args:
        table_name: The technical table name
        database_context: Optional database context for better inference
        
    Returns:
        Dictionary with business_name and business_description
    """
    # Map common table patterns to business names
    table_patterns = {
        'users': ('User Accounts', 'Stores information about registered users'),
        'products': ('Product Catalog', 'Contains product information'),
        'orders': ('Customer Orders', 'Tracks customer purchase orders'),
        'inventory': ('Inventory Management', 'Manages stock levels'),
    }
    
    if table_name.lower() in table_patterns:
        business_name, desc = table_patterns[table_name.lower()]
        return {
            "business_name": business_name,
            "business_description": desc
        }
    
    # Default behavior
    business_name = table_name.replace('_', ' ').title()
    business_description = f"Database table storing {business_name.lower()} information"
    
    return {
        "business_name": business_name,
        "business_description": business_description
    }


@mcp.tool()
def enrich_column_metadata(
    column_name: str, 
    table_context: str = "",
    database_context: str = ""
) -> Dict[str, str]:
    """
    Enriches column with business name, description, and classification.
    
    Args:
        column_name: The technical column name
        table_context: Optional table context
        database_context: Optional database context
        
    Returns:
        Dictionary with business_name, business_description, and classification
    """
    # Classification rules based on column patterns
    confidential_patterns = ['password', 'ssn', 'user_id', 'username', 'account']
    restricted_patterns = ['email', 'phone', 'address', 'salary']
    public_patterns = ['name', 'description', 'price', 'title', 'category']
    
    column_lower = column_name.lower()
    
    # Determine classification
    classification = "Internal"  # Default
    if any(pattern in column_lower for pattern in confidential_patterns):
        classification = "Confidential"
    elif any(pattern in column_lower for pattern in restricted_patterns):
        classification = "Restricted"
    elif any(pattern in column_lower for pattern in public_patterns):
        classification = "Public"
    
    # Generate business name
    business_name = column_name.replace('_', ' ').title()
    
    # Generate business description based on common patterns
    description_map = {
        'id': 'unique identifier',
        'name': 'name field',
        'email': 'email address for communication',
        'created': 'timestamp when record was created',
        'updated': 'timestamp when record was last updated',
        'price': 'monetary value',
        'quantity': 'numeric count',
        'status': 'current state or status',
    }
    
    business_description = f"The {business_name.lower()}"
    for pattern, desc in description_map.items():
        if pattern in column_lower:
            business_description = f"A {desc} for this record"
            break
    
    return {
        "business_name": business_name,
        "business_description": business_description,
        "classification": classification
    }


@mcp.tool()
def enrich_full_schema(schema_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Enriches complete database schema with business metadata.
    
    Args:
        schema_data: Full schema including database, tables, and columns
        
    Returns:
        Enriched schema with all business metadata
    """
    result = schema_data.copy()
    
    # Enrich database
    if 'database_name' in result:
        db_meta = enrich_database_metadata(result['database_name'])
        result.update(db_meta)
    
    # Enrich tables
    if 'tables' in result:
        for table in result['tables']:
            table_meta = enrich_table_metadata(
                table['table_name'],
                result.get('database_name', '')
            )
            table.update(table_meta)
            
            # Enrich columns
            if 'columns' in table:
                for column in table['columns']:
                    column_meta = enrich_column_metadata(
                        column['column_name'],
                        table['table_name'],
                        result.get('database_name', '')
                    )
                    column.update(column_meta)
    
    return result


if __name__ == "__main__":
    # Run the MCP server with HTTP transport
    import sys
    
    # FastMCP will handle the HTTP server setup
    mcp.run(transport="http", port=8001)