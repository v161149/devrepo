"""
Simple transactional tests for the SQLite DB used by the project.
This script programmatically exercises BEGIN/UPDATE/ROLLBACK and COMMIT and
verifies visibility across two connections.

Usage:
    python tx_test.py [path/to/SLA_MANAGEMENT_DB.db]

If no path is provided the script will try to locate the DB next to this file:
../database/SLA_MANAGEMENT_DB.db

It prints PASS/FAIL for rollback and commit checks and exits with code 0 on success,
non-zero on failure.
"""
import os
import sys
import sqlite3


def get_default_db_path():
    base = os.path.dirname(__file__)
    # expected repo layout: database/SLA_MANAGEMENT_DB.db
    return os.path.normpath(os.path.join(base, '..', 'database', 'SLA_MANAGEMENT_DB.db'))


def run_test(db_path):
    print(f"Using DB: {db_path}")
    conn1 = sqlite3.connect(db_path)
    conn2 = sqlite3.connect(db_path)

    cur1 = conn1.cursor()
    cur2 = conn2.cursor()

    # create a small temp table for testing
    cur1.execute("CREATE TABLE IF NOT EXISTS tx_test (id INTEGER PRIMARY KEY, val TEXT);")
    conn1.commit()

    # ensure clean state
    cur1.execute("DELETE FROM tx_test;")
    conn1.commit()

    # insert initial row
    cur1.execute("INSERT INTO tx_test (id, val) VALUES (1, 'a');")
    conn1.commit()

    # --- Test rollback visibility ---
    # begin transaction on conn1 and update
    conn1.execute('BEGIN')
    cur1.execute("UPDATE tx_test SET val='b' WHERE id=1;")

    # read from conn1 (should see 'b')
    cur1.execute("SELECT val FROM tx_test WHERE id=1;")
    v_conn1 = cur1.fetchone()[0]

    # read from conn2 (should still see 'a' because conn1 hasn't committed)
    cur2.execute("SELECT val FROM tx_test WHERE id=1;")
    v_conn2 = cur2.fetchone()[0]

    rollback_ok = (v_conn1 == 'b' and v_conn2 == 'a')

    # rollback and verify both see 'a'
    conn1.rollback()
    cur1.execute("SELECT val FROM tx_test WHERE id=1;")
    v_after_rb = cur1.fetchone()[0]

    rollback_final_ok = (v_after_rb == 'a')

    # --- Test commit visibility ---
    # begin transaction on conn1 and update then commit
    conn1.execute('BEGIN')
    cur1.execute("UPDATE tx_test SET val='c' WHERE id=1;")
    conn1.commit()

    # now conn2 should see 'c'
    cur2.execute("SELECT val FROM tx_test WHERE id=1;")
    v_conn2_after_commit = cur2.fetchone()[0]

    commit_ok = (v_conn2_after_commit == 'c')

    # Cleanup: reset to initial state
    cur1.execute("UPDATE tx_test SET val='a' WHERE id=1;")
    conn1.commit()

    conn1.close()
    conn2.close()

    print("Rollback visibility test:", "PASS" if rollback_ok and rollback_final_ok else "FAIL")
    print("Commit visibility test:", "PASS" if commit_ok else "FAIL")

    all_ok = rollback_ok and rollback_final_ok and commit_ok
    return 0 if all_ok else 2


if __name__ == '__main__':
    db_path = sys.argv[1] if len(sys.argv) > 1 else get_default_db_path()
    if not os.path.exists(db_path):
        print(f"Database file not found: {db_path}")
        sys.exit(3)
    rc = run_test(db_path)
    sys.exit(rc)
