# SLA Tracking System

This repository contains a React frontend and a Python/Flask backend with a SQLite database for managing SLAs, assets, and scheduled jobs.

Quick start (Windows PowerShell):

1. Create a Python virtual environment and install backend dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt || pip install -e backend
```

2. Start the backend (example uses port 5000):

```powershell
$env:PORT=5000; $env:HOST='127.0.0.1'; python .\backend\src\data_management_service.py
```

3. Start the frontend (in a separate shell):

```powershell
cd frontend
npm install
npm run dev
```

End-to-end test

An automated end-to-end test script is provided at `backend/scripts/e2e_test_upload.py`. It will:
- start the backend on a temporary test port (default 5002)
- wait for the health endpoint
- upload `frontend/onboarding.xlsx` to `/api/upload-spreadsheet`
- verify the upload response and query `/api/assets`, `/api/slas`, `/api/jobs` to check counts
- shutdown the test server

Run the test (PowerShell):

```powershell
python .\backend\scripts\e2e_test_upload.py
```

Notes

- The backend declares `openpyxl` in `backend/pyproject.toml`. Ensure dependencies are installed in your Python environment before running.
- The e2e test starts the server as a subprocess and will terminate it when finished. If the test port is already in use, edit the `PORT` variable at the top of the test script.

If you want, I can also add a `requirements.txt` produced from `pyproject.toml` and a short PowerShell script to set up the virtual env automatically.