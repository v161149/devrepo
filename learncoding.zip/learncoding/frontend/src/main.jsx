import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

try {
  console.log('Mounting React app');
  const rootEl = document.getElementById('root');
  if (!rootEl) {
    throw new Error('Root element #root not found');
  }
  createRoot(rootEl).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
} catch (err) {
  // Ensure the error is visible even if React cannot mount
  console.error('Failed to mount React app:', err);
  try {
    const root = document.getElementById('root');
    if (root) {
      root.innerHTML = `<div style="padding:24px;font-family:system-ui,Segoe UI,Roboto,'Helvetica Neue',Arial;">"Failed to mount app: ${String(err).replace(/</g,'&lt;')}"</div>`;
    } else {
      document.body.innerHTML = `<div style="padding:24px;font-family:system-ui,Segoe UI,Roboto,'Helvetica Neue',Arial;">"Failed to mount app: ${String(err).replace(/</g,'&lt;')}"</div>`;
    }
  } catch (e) {
    console.error('Also failed to write error to DOM', e);
  }
}
