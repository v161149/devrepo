from flask import Flask, request, jsonify
import sqlite3
import os
from pathlib import Path
from datetime import datetime
import logging

app = Flask(__name__)

DATABASE_NAME = "SLA_MANAGEMENT_DB"
CURRENT_PATH = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_PATH.parent.parent.parent
DATABASE_DIR = PROJECT_ROOT / "database"
DB_PATH = str(DATABASE_DIR / f"{DATABASE_NAME}.db")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_db_connection():
    """Get database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def check_database():
    """Verify database exists."""
    if not os.path.exists(DB_PATH):
        return False, "Database not found at " + DB_PATH
    return True, "Database found"


@app.route('/api/activate-asset', methods=['POST'])
def activate_asset():
    """
    Activate an asset and populate monitoring tables.
    
    Request JSON:
    {
        "asset_name": "Sales and Service Application",
        "status": "Active"
    }
    
    Steps:
    1. Check status is 'Active'
    2. Retrieve ASSET_ID from ASSETS table
    3. Get all SLAs for this ASSET_ID and copy to SLAS_MONITOR_LOG
    4. Get all JOBS for these SLAs and copy to JOBS_MONITOR_LOG
    """
    try:
        data = request.get_json()
        asset_name = data.get('asset_name')
        status = data.get('status')

        if not asset_name or not status:
            return jsonify({"error": "Missing asset_name or status"}), 400

        # Step 1: Check status
        if status.lower() != 'active':
            return jsonify({
                "status": "skipped",
                "message": f"Asset status is '{status}', not 'Active'. Skipping activation."
            }), 200

        conn = get_db_connection()
        cursor = conn.cursor()

        # Step 2: Get ASSET_ID from ASSET_NAME
        cursor.execute("SELECT ASSET_ID FROM ASSETS WHERE ASSET_NAME=?", (asset_name,))
        asset_row = cursor.fetchone()

        if not asset_row:
            conn.close()
            return jsonify({
                "error": f"Asset '{asset_name}' not found in database"
            }), 404

        asset_id = asset_row['ASSET_ID']
        logger.info(f"Activating asset: {asset_name} (ID: {asset_id})")

        # Step 3: Get all SLAs for this ASSET_ID
        cursor.execute(
            """SELECT * FROM SCHEDULED_SLAS WHERE ASSET_ID=?""",
            (asset_id,)
        )
        slas = cursor.fetchall()

        if not slas:
            conn.close()
            return jsonify({
                "status": "success",
                "message": f"Asset '{asset_name}' activated but no SLAs found",
                "slas_copied": 0,
                "jobs_copied": 0
            }), 200

        # Copy SLAs to SLAS_MONITOR_LOG
        slas_copied = 0
        sla_ids = []

        for sla in slas:
            sla_id = sla['SLA_ID']
            sla_ids.append(sla_id)

            cursor.execute(
                """INSERT INTO SLAS_MONITOR_LOG 
                   (SLA_SRC_ID, SLA_NAME, SLA_TYPE, TIME_ZONE, FREQUENCY,
                    EXPECTED_EXECUTION_DATE, EXPECTED_START_TIME, EXPECTED_END_TIME,
                    STATUS, DEPENDENT_SLAS, DEPENDENT_JOBS)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (str(sla_id), sla['SLA_NAME'], sla['SLA_TYPE'], sla['TIME_ZONE'],
                 sla['FREQUENCY'], sla['FIRST_EXECUTION_DATE'],
                 sla['EXPECTED_START_TIME'], sla['EXPECTED_END_TIME'],
                 'Unknown', sla['DEPENDENT_SLAS'], sla['DEPENDENT_JOBS'])
            )
            slas_copied += 1

        logger.info(f"Copied {slas_copied} SLAs to monitoring log")

        # Step 4: Get all JOBS for these SLAs
        jobs_copied = 0

        if sla_ids:
            # Create placeholder string for SQL IN clause
            placeholders = ','.join('?' * len(sla_ids))
            query = f"""SELECT * FROM SCHEDULED_JOBS WHERE SLA_ID IN ({placeholders})"""

            cursor.execute(query, sla_ids)
            jobs = cursor.fetchall()

            # Copy jobs to JOBS_MONITOR_LOG
            for job in jobs:
                cursor.execute(
                    """INSERT INTO JOBS_MONITOR_LOG 
                       (SLA_ID, SLA_SRC_ID, JOB_SRC_ID, JOB_NAME, JOB_TYPE, TIME_ZONE,
                        FREQUENCY, EXPECTED_EXECUTION_DATE, EXPECTED_START_TIME,
                        EXPECTED_END_TIME, STATUS, DEPENDENT_JOBS)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (job['SLA_ID'], str(job['SLA_ID']), job['JOB_ID'],
                     job['JOB_NAME'], job['JOB_TYPE'], job['TIME_ZONE'],
                     job['FREQUENCY'], job['FIRST_EXECUTION_DATE'],
                     job['EXPECTED_START_TIME'], job['EXPECTED_END_TIME'],
                     'Unknown', job['DEPENDENT_JOBS'])
                )
                jobs_copied += 1

            logger.info(f"Copied {jobs_copied} jobs to monitoring log")

        conn.commit()
        conn.close()

        return jsonify({
            "status": "success",
            "message": f"Asset '{asset_name}' activated successfully",
            "asset_id": asset_id,
            "slas_copied": slas_copied,
            "jobs_copied": jobs_copied,
            "timestamp": datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"Error activating asset: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/activate-asset-deactivate', methods=['POST'])
def deactivate_asset():
    """
    Deactivate an asset and optionally clear monitoring data.
    
    Request JSON:
    {
        "asset_name": "Sales and Service Application",
        "status": "Inactive",
        "clear_logs": false
    }
    """
    try:
        data = request.get_json()
        asset_name = data.get('asset_name')
        status = data.get('status')
        clear_logs = data.get('clear_logs', False)

        if not asset_name or not status:
            return jsonify({"error": "Missing asset_name or status"}), 400

        # Only process if status is 'Inactive'
        if status.lower() != 'inactive':
            return jsonify({
                "status": "skipped",
                "message": f"Asset status is '{status}', not 'Inactive'. Skipping deactivation."
            }), 200

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get ASSET_ID
        cursor.execute("SELECT ASSET_ID FROM ASSETS WHERE ASSET_NAME=?", (asset_name,))
        asset_row = cursor.fetchone()

        if not asset_row:
            conn.close()
            return jsonify({"error": f"Asset '{asset_name}' not found"}), 404

        asset_id = asset_row['ASSET_ID']

        if clear_logs:
            # Get SLA_IDs for this asset
            cursor.execute(
                "SELECT SLA_ID FROM SCHEDULED_SLAS WHERE ASSET_ID=?",
                (asset_id,)
            )
            sla_rows = cursor.fetchall()
            sla_ids = [row['SLA_ID'] for row in sla_rows]

            if sla_ids:
                # Delete from monitoring logs
                placeholders = ','.join('?' * len(sla_ids))
                cursor.execute(f"DELETE FROM SLAS_MONITOR_LOG WHERE SLA_SRC_ID IN ({placeholders})",
                             [str(sid) for sid in sla_ids])
                cursor.execute(f"DELETE FROM JOBS_MONITOR_LOG WHERE SLA_ID IN ({placeholders})",
                             sla_ids)

        conn.commit()
        conn.close()

        logger.info(f"Deactivated asset: {asset_name} (clear_logs: {clear_logs})")

        return jsonify({
            "status": "success",
            "message": f"Asset '{asset_name}' deactivated",
            "asset_id": asset_id,
            "logs_cleared": clear_logs,
            "timestamp": datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"Error deactivating asset: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/get-asset-slas', methods=['GET'])
def get_asset_slas():
    """
    Get all SLAs and their jobs for a specific asset.
    Query parameter: asset_id
    """
    try:
        asset_id = request.args.get('asset_id')

        if not asset_id:
            return jsonify({"error": "Missing asset_id parameter"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get all SLAs for this asset
        cursor.execute(
            "SELECT * FROM SCHEDULED_SLAS WHERE ASSET_ID=?",
            (asset_id,)
        )
        slas = cursor.fetchall()

        result = []
        for sla in slas:
            sla_dict = dict(sla)

            # Get jobs for this SLA
            cursor.execute(
                "SELECT * FROM SCHEDULED_JOBS WHERE SLA_ID=?",
                (sla['SLA_ID'],)
            )
            jobs = cursor.fetchall()
            sla_dict['jobs'] = [dict(job) for job in jobs]

            result.append(sla_dict)

        conn.close()

        return jsonify({
            "status": "success",
            "asset_id": asset_id,
            "data": result
        }), 200

    except Exception as e:
        logger.error(f"Error retrieving asset SLAs: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/get-monitoring-summary', methods=['GET'])
def get_monitoring_summary():
    """
    Get summary statistics of current monitoring logs.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get SLA monitoring statistics
        cursor.execute("""
            SELECT STATUS, COUNT(*) as count 
            FROM SLAS_MONITOR_LOG 
            GROUP BY STATUS
        """)
        sla_stats = {row['STATUS']: row['count'] for row in cursor.fetchall()}

        # Get Jobs monitoring statistics
        cursor.execute("""
            SELECT STATUS, COUNT(*) as count 
            FROM JOBS_MONITOR_LOG 
            GROUP BY STATUS
        """)
        jobs_stats = {row['STATUS']: row['count'] for row in cursor.fetchall()}

        # Get total counts
        cursor.execute("SELECT COUNT(*) as total FROM SLAS_MONITOR_LOG")
        total_slas = cursor.fetchone()['total']

        cursor.execute("SELECT COUNT(*) as total FROM JOBS_MONITOR_LOG")
        total_jobs = cursor.fetchone()['total']

        conn.close()

        return jsonify({
            "status": "success",
            "sla_monitoring": {
                "total": total_slas,
                "by_status": sla_stats
            },
            "jobs_monitoring": {
                "total": total_jobs,
                "by_status": jobs_stats
            },
            "timestamp": datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"Error getting monitoring summary: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/clear-monitoring-logs', methods=['DELETE'])
def clear_monitoring_logs():
    """
    Clear all monitoring logs (use with caution).
    Optional query parameter: older_than_days (clear logs older than X days)
    """
    try:
        older_than_days = request.args.get('older_than_days')

        conn = get_db_connection()
        cursor = conn.cursor()

        if older_than_days:
            # Clear only old logs
            cursor.execute(
                """DELETE FROM SLAS_MONITOR_LOG 
                   WHERE EXECUTION_DATE < datetime('now', '-' || ? || ' days')""",
                (older_than_days,)
            )
            sla_deleted = cursor.rowcount

            cursor.execute(
                """DELETE FROM JOBS_MONITOR_LOG 
                   WHERE EXECUTION_DATE < datetime('now', '-' || ? || ' days')""",
                (older_than_days,)
            )
            jobs_deleted = cursor.rowcount
        else:
            # Clear all logs
            cursor.execute("DELETE FROM SLAS_MONITOR_LOG")
            sla_deleted = cursor.rowcount

            cursor.execute("DELETE FROM JOBS_MONITOR_LOG")
            jobs_deleted = cursor.rowcount

        conn.commit()
        conn.close()

        logger.info(f"Cleared monitoring logs - SLAs: {sla_deleted}, Jobs: {jobs_deleted}")

        return jsonify({
            "status": "success",
            "message": "Monitoring logs cleared",
            "slas_deleted": sla_deleted,
            "jobs_deleted": jobs_deleted,
            "timestamp": datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"Error clearing monitoring logs: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    """Check service health."""
    try:
        exists, msg = check_database()
        if not exists:
            return jsonify({"status": "error", "message": msg}), 503

        conn = get_db_connection()
        conn.close()

        return jsonify({
            "status": "healthy",
            "service": "schedule_generation_service",
            "database": "connected",
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 503


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500


if __name__ == '__main__':
    exists, msg = check_database()
    if not exists:
        print(f"WARNING: {msg}")
        print("Please run create_database.py first.")
    else:
        print(f"Schedule Generation Service - Database connected: {DB_PATH}")

    app.run(debug=True, port=5001)