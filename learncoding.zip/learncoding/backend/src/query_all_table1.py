import os, sqlite3
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DB = os.path.join(ROOT, 'database', 'SLA_MANAGEMENT_DB.db')
conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
cur = conn.cursor()
print('DB used:', DB)
rows = cur.execute('SELECT * FROM SLA_DATABASE_TABLE_COLUMN_DETAILS WHERE TABLE_ID=1').fetchall()
print('rows count:', len(rows))
for r in rows:
    print(dict(r))
conn.close()
