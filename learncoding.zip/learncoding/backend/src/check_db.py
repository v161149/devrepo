import sqlite3
from pathlib import Path
import os

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / 'database' / 'SLA_MANAGEMENT_DB.db'
print('DB path:', DB_PATH)
conn = sqlite3.connect(str(DB_PATH))
conn.row_factory = sqlite3.Row
cur = conn.cursor()

for tbl in ['SLA_DATABASE_DETAILS','SLA_DATABASE_TABLE_DETAILS','SLA_DATABASE_TABLE_COLUMN_DETAILS']:
    try:
        cur.execute(f'SELECT COUNT(*) as cnt FROM {tbl}')
        print(f"{tbl}:", cur.fetchone()['cnt'])
    except Exception as e:
        print(f"Error reading {tbl}: {e}")

# Print sample database details
print('\nSample SLA_DATABASE_DETAILS rows:')
for r in cur.execute('SELECT * FROM SLA_DATABASE_DETAILS LIMIT 5').fetchall():
    print(dict(r))

print('\nSample SLA_DATABASE_TABLE_DETAILS rows:')
for r in cur.execute('SELECT * FROM SLA_DATABASE_TABLE_DETAILS LIMIT 5').fetchall():
    print(dict(r))

print('\nSample SLA_DATABASE_TABLE_COLUMN_DETAILS rows:')
for r in cur.execute('SELECT * FROM SLA_DATABASE_TABLE_COLUMN_DETAILS LIMIT 10').fetchall():
    print(dict(r))

conn.close()