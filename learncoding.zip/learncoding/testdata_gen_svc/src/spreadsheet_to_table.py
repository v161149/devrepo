import pandas as pd
import sys
from tabulate import tabulate

def read_and_display_spreadsheet(file_path):
    """
    Read a spreadsheet file with multiple tabs and display each as a formatted table.
    
    Args:
        file_path (str): Path to the Excel file (.xlsx, .xls)
    """
    try:
        # Read the Excel file and get all sheet names
        xls = pd.ExcelFile(file_path)
        sheet_names = xls.sheet_names
        
        print(f"\n{'='*80}")
        print(f"Spreadsheet: {file_path}")
        print(f"Number of tabs: {len(sheet_names)}")
        print(f"{'='*80}\n")
        
        # Iterate through each sheet and display as table
        for sheet_name in sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            print(f"\n{'─'*80}")
            print(f"Tab: {sheet_name}")
            print(f"Rows: {len(df)}, Columns: {len(df.columns)}")
            print(f"{'─'*80}\n")
            
            # Display table using tabulate for nice formatting
            print(tabulate(df, headers='keys', tablefmt='grid', showindex=False))
            print()
    
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading file: {e}")
        sys.exit(1)

def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <path_to_spreadsheet>")
        print("Example: python script.py data.xlsx")
        sys.exit(1)
    
    file_path = sys.argv[1]
    read_and_display_spreadsheet(file_path)

if __name__ == "__main__":
    main()