'use strict';
require('../register')('q', {Promise: require('q').Promise})
