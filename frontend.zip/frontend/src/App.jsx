import './index.css';
import React, { useState, useCallback, useEffect } from 'react';
import { Upload, Edit2, Save, Power, RotateCcw } from 'lucide-react';

// (ErrorBoundary moved to top of file)
export default function SLAManagementSystem() {
  const [activeTab, setActiveTab] = useState('onboarding');
  const [assets, setAssets] = useState([]);
  const [slas, setSlas] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [databaseDetails, setDatabaseDetails] = useState([]);
  const [managementSubTab, setManagementSubTab] = useState('assets');
  const [editingRows, setEditingRows] = useState(new Set());
  const [highlightedRows, setHighlightedRows] = useState(new Set());
  const [slaMonitorLog, setSlaMonitorLog] = useState([]);
  const [jobsMonitorLog, setJobsMonitorLog] = useState([]);
  const [slaHistory, setSlaHistory] = useState([]);
  const [jobsHistory, setJobsHistory] = useState([]);
  const [uploadProgress, setUploadProgress] = useState(null); // 0-100 or null
  const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle' | 'uploading' | 'success' | 'error'
  const [uploadResponse, setUploadResponse] = useState(null);

  // Polling for real-time monitoring
  useEffect(() => {
    if (activeTab === 'monitoring-slas') {
      const interval = setInterval(() => {
        // In real implementation, this would call the backend API
        console.log('Polling SLA Monitor Log');
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  useEffect(() => {
    if (activeTab === 'monitoring-jobs') {
      const interval = setInterval(() => {
        // In real implementation, this would call the backend API
        console.log('Polling Jobs Monitor Log');
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  const handleFileUpload = useCallback((e) => {
    const file = e.dataTransfer?.files[0] || e.target.files?.[0];
    if (!file) return;

    const apiBase = window.location.hostname === 'localhost' ? 'http://localhost:5000' : '';
    const formData = new FormData();
    formData.append('file', file, file.name);

    setUploadProgress(0);
    setUploadStatus('uploading');
    setUploadResponse(null);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${apiBase}/api/upload-spreadsheet`);

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.round((event.loaded / event.total) * 100);
        setUploadProgress(percent);
      }
    };

    xhr.onload = async () => {
      try {
        const contentType = xhr.getResponseHeader('Content-Type') || '';
        let json = null;
        if (contentType.includes('application/json')) {
          json = JSON.parse(xhr.responseText);
        } else {
          json = { message: xhr.responseText };
        }

        if (xhr.status >= 200 && xhr.status < 300) {
          setUploadStatus('success');
          setUploadResponse(json);
          // refresh management data
          fetchManagementData();
        } else {
          setUploadStatus('error');
          setUploadResponse(json);
        }
      } catch (err) {
        setUploadStatus('error');
        setUploadResponse({ error: err.message });
      }
      setUploadProgress(null);
    };

    xhr.onerror = () => {
      setUploadStatus('error');
      setUploadResponse({ error: 'Network error during upload' });
      setUploadProgress(null);
    };

    xhr.send(formData);
  }, []);

  // Fetch assets/slas/jobs from backend
  const fetchManagementData = async () => {
    try {
      const apiBase = window.location.hostname === 'localhost' ? 'http://localhost:5000' : '';
      // Fetch assets first so we can map ASSET_ID -> ASSET_NAME for SLAs
      const assetsRes = await fetch(`${apiBase}/api/assets`);
      let assetsData = [];
      if (assetsRes.ok) {
        const a = await assetsRes.json();
        // Map backend keys to display keys
        assetsData = (a.data || []).map(row => ({
          'Asset Name': row.ASSET_NAME,
          'AIT Number': row.AIT_NUMBER,
          'Status': row.STATUS,
          // Keep original fields for lookups
          ASSET_ID: row.ASSET_ID
        }));
        setAssets(assetsData);
      }

      // Build asset id -> name map
      const assetIdToName = {};
      assetsData.forEach(r => { if (r.ASSET_ID) assetIdToName[r.ASSET_ID] = r['Asset Name']; });

      // Fetch SLAs
      const slasRes = await fetch(`${apiBase}/api/slas`);
      let slasData = [];
      if (slasRes.ok) {
        const s = await slasRes.json();
        slasData = (s.data || []).map(row => ({
          'Asset Name': assetIdToName[row.ASSET_ID] || row.ASSET_ID,
          'SLA Name': row.SLA_NAME,
          'SLA Type': row.SLA_TYPE,
          'Time Zone': row.TIME_ZONE,
          'Expected Start Time': row.EXPECTED_START_TIME,
          'Expected End Time': row.EXPECTED_END_TIME,
          'Frequency': row.FREQUENCY,
          // Keep original for lookups
          SLA_ID: row.SLA_ID
        }));
        setSlas(slasData);
      }

      // Build sla id -> name map
      const slaIdToName = {};
      slasData.forEach(r => { if (r.SLA_ID) slaIdToName[r.SLA_ID] = r['SLA Name']; });

      // Fetch jobs
      const jobsRes = await fetch(`${apiBase}/api/jobs`);
      if (jobsRes.ok) {
        const j = await jobsRes.json();
        const jobsData = (j.data || []).map(row => ({
          // Backend returns ASSET_NAME (string) joined; fall back to assetIdToName lookup if needed
          'Asset Name': row.ASSET_NAME || assetIdToName[row.ASSET_ID] || '',
          'SLA Name': slaIdToName[row.SLA_ID] || row.SLA_ID,
          'Job Name': row.JOB_NAME,
          'Job Type': row.JOB_TYPE,
          'Time Zone': row.TIME_ZONE,
          'Expected Start Time': row.EXPECTED_START_TIME,
          'Expected End Time': row.EXPECTED_END_TIME,
          'Frequency': row.FREQUENCY
        }));
        setJobs(jobsData);
      }
    } catch (err) {
      console.error('Error fetching management data', err);
    }
  };

  // Load management data when management tab becomes active
  useEffect(() => {
    if (activeTab === 'management') {
      fetchManagementData();
    }
  }, [activeTab]);

  // Fetch database details when user opens Database subtab
  const fetchDatabaseDetails = async () => {
    try {
      const apiBase = window.location.hostname === 'localhost' ? 'http://localhost:5000' : '';
      const res = await fetch(`${apiBase}/api/database-details`);
      if (!res.ok) {
        console.warn('Failed to fetch database details', res.status);
        setDatabaseDetails([]);
        return;
      }
      const json = await res.json();
      // Accept either { data: [...] } or [...]
      const payload = Array.isArray(json) ? json : (json.data || json);

      // Basic normalization: ensure tables/columns arrays exist so UI doesn't crash
      const normalized = (payload || []).map(db => ({
        DATABASE_ID: db.DATABASE_ID || db.database_id || db.id,
        AIT_NUMBER: db.AIT_NUMBER || db.ait_number || db.AIT_NUMBER || '',
        ASSET_NAME: db.ASSET_NAME || db.asset_name || '',
        DATABASE_NAME: db.DATABASE_NAME || db.database_name || db.name || '',
        BUSINESS_NAME: db.BUSINESS_NAME || db.business_name || db.BUSINESS_NAME || '',
        BUSINESS_DESCRIPTION: db.BUSINESS_DESCRIPTION || db.business_description || db.BUSINESS_DESCRIPTION || '',
        tables: (db.tables || db.TABLES || []).map(t => ({
          TABLE_ID: t.TABLE_ID || t.table_id || t.id,
          TABLE_NAME: t.TABLE_NAME || t.table_name || t.name || '',
          BUSINESS_NAME: t.BUSINESS_NAME || t.business_name || '',
          BUSINESS_DESCRIPTION: t.BUSINESS_DESCRIPTION || t.business_description || '',
          columns: (t.columns || t.COLUMNS || []).map(c => ({
            COLUMN_NAME: c.COLUMN_NAME || c.column_name || c.name || '',
            DATA_TYPE: c.DATA_TYPE || c.data_type || c.type || '',
            CLASSIFICATION: c.CLASSIFICATION || c.classification || '',
            BUSINESS_NAME: c.BUSINESS_NAME || c.business_name || '',
            BUSINESS_DESCRIPTION: c.BUSINESS_DESCRIPTION || c.business_description || ''
          }))
        }))
      }));

      setDatabaseDetails(normalized);
    } catch (err) {
      console.error('Error fetching database details', err);
      setDatabaseDetails([]);
    }
  };

  useEffect(() => {
    if (activeTab === 'management' && managementSubTab === 'database') {
      fetchDatabaseDetails();
    }
  }, [activeTab, managementSubTab]);

  const handleCellChange = (tableType, rowIndex, columnName, value) => {
    const newRow = new Set(editingRows);
    newRow.add(`${tableType}-${rowIndex}`);
    setEditingRows(newRow);

    const highlighted = new Set(highlightedRows);
    highlighted.add(`${tableType}-${rowIndex}`);
    setHighlightedRows(highlighted);

    if (tableType === 'assets') {
      const updatedAssets = [...assets];
      updatedAssets[rowIndex] = { ...updatedAssets[rowIndex], [columnName]: value };
      setAssets(updatedAssets);
    } else if (tableType === 'slas') {
      const updatedSlas = [...slas];
      updatedSlas[rowIndex] = { ...updatedSlas[rowIndex], [columnName]: value };
      setSlas(updatedSlas);
    } else if (tableType === 'jobs') {
      const updatedJobs = [...jobs];
      updatedJobs[rowIndex] = { ...updatedJobs[rowIndex], [columnName]: value };
      setJobs(updatedJobs);
    }
  };

  const handleSave = (tableType) => {
    // Call backend service to save changes
    console.log(`Saving ${tableType} data to database`);
    alert(`${tableType} data saved successfully!`);
    setEditingRows(new Set());
  };

  const handleActivate = (assetName, status) => {
    // Call backend schedule_generation_service
    console.log('Activating asset:', assetName, 'Status:', status);
    alert(`Asset '${assetName}' activated with status: ${status}`);
  };

  const renderNavigation = () => (
    <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-6 py-0">
        <div className="flex flex-wrap gap-1 py-4">
          {[
            { id: 'onboarding', label: 'SLA Onboarding' },
            { id: 'management', label: 'SLA Management' },
            { id: 'monitoring-slas', label: 'Monitoring SLAs in Real-Time' },
            { id: 'monitoring-jobs', label: 'Monitoring Jobs in Real-Time' },
            { id: 'history-slas', label: 'Historical Actual SLAs Data' },
            { id: 'history-jobs', label: 'Historical Actual Jobs Data' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-t-lg font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-white text-blue-600'
                  : 'bg-blue-500 hover:bg-blue-400'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const renderOnboarding = () => (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <h2 className="text-2xl font-bold mb-8 text-gray-800">SLA Onboarding</h2>
      <div
        onDrop={handleFileUpload}
        onDragOver={(e) => e.preventDefault()}
        className="border-2 border-dashed border-blue-400 rounded-lg p-16 text-center bg-blue-50 hover:bg-blue-100 transition-colors cursor-pointer"
      >
        <Upload className="mx-auto mb-4 text-blue-600" size={48} />
        <p className="text-xl font-semibold mb-2">Drag and drop your spreadsheet here</p>
        <p className="text-gray-600 mb-4">or click to browse</p>
        <input
          type="file"
          accept=".xlsx,.xls,.csv"
          onChange={handleFileUpload}
          className="hidden"
          id="file-input"
        />
        <label htmlFor="file-input" className="inline-block px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer">
          Browse Files
        </label>
        <p className="text-sm text-gray-500 mt-4">Supported formats: Excel (.xlsx, .xls), CSV</p>
        {/* Upload progress and server response */}
        <div className="mt-6 max-w-lg mx-auto text-left">
          {uploadStatus === 'uploading' && uploadProgress !== null && (
            <div className="mb-2">
              <div className="text-sm text-gray-600 mb-1">Uploading: {uploadProgress}%</div>
              <div className="w-full bg-gray-200 rounded h-3">
                <div className="bg-blue-600 h-3 rounded" style={{ width: `${uploadProgress}%` }} />
              </div>
            </div>
          )}

          {uploadStatus === 'success' && uploadResponse && (
            <div className="p-3 bg-green-50 border border-green-200 rounded">
              <div className="text-sm font-semibold text-green-700">Upload succeeded</div>
              <pre className="text-xs text-gray-700 mt-2 whitespace-pre-wrap">{JSON.stringify(uploadResponse, null, 2)}</pre>
              <div className="mt-2 text-right">
                <button onClick={() => setUploadResponse(null)} className="text-sm text-blue-600">Dismiss</button>
              </div>
            </div>
          )}

          {uploadStatus === 'error' && uploadResponse && (
            <div className="p-3 bg-red-50 border border-red-200 rounded">
              <div className="text-sm font-semibold text-red-700">Upload failed</div>
              <pre className="text-xs text-gray-700 mt-2 whitespace-pre-wrap">{JSON.stringify(uploadResponse, null, 2)}</pre>
              <div className="mt-2 text-right">
                <button onClick={() => setUploadResponse(null)} className="text-sm text-blue-600">Dismiss</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderTable = (data, columns, tableType) => (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-blue-600 text-white">
            {columns.map(col => (
              <th key={col} className="px-4 py-3 text-left font-semibold border">{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => (
            <tr
              key={idx}
              className={`border-b ${
                highlightedRows.has(`${tableType}-${idx}`)
                  ? 'bg-yellow-100'
                  : idx % 2 === 0
                  ? 'bg-gray-50'
                  : 'bg-white'
              } hover:bg-blue-50`}
            >
              {columns.map(col => (
                <td key={`${idx}-${col}`} className="px-4 py-3 border">
                  <textarea
                    rows={1}
                    value={row[col] || ''}
                    onChange={(e) => handleCellChange(tableType, idx, col, e.target.value)}
                    className="w-full px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                    style={{ resize: 'vertical' }}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderManagementSubtab = (subTab) => {
    switch (subTab) {
      case 'assets':
        return (
          <div>
            <h3 className="text-xl font-bold mb-4">Assets</h3>
            {assets.length > 0 ? (
              renderTable(
                assets,
                ['Asset Name', 'AIT Number', 'Status'],
                'assets'
              )
            ) : (
              <p className="text-gray-500">No assets data uploaded yet.</p>
            )}
            <div className="mt-6 flex gap-4 justify-center">
              <button
                onClick={() => handleSave('assets')}
                className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Save size={20} /> Save
              </button>
              <button
                onClick={() => handleActivate(assets[0]?.['Asset Name'], 'Active')}
                className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Power size={20} /> Activate
              </button>
            </div>
          </div>
        );
      case 'slas':
        return (
          <div>
            <h3 className="text-xl font-bold mb-4">SLAs</h3>
            {slas.length > 0 ? (
              renderTable(
                slas,
                ['Asset Name', 'SLA Name', 'SLA Type', 'Time Zone', 'Expected Start Time', 'Expected End Time', 'Frequency'],
                'slas'
              )
            ) : (
              <p className="text-gray-500">No SLAs data uploaded yet.</p>
            )}
            <div className="mt-6 flex justify-center">
              <button
                onClick={() => handleSave('slas')}
                className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Save size={20} /> Save
              </button>
            </div>
          </div>
        );
      case 'jobs':
        return (
          <div>
            <h3 className="text-xl font-bold mb-4">Jobs</h3>
            {jobs.length > 0 ? (
              renderTable(
                jobs,
                ['Asset Name', 'SLA Name', 'Job Name', 'Job Type', 'Time Zone', 'Expected Start Time', 'Expected End Time', 'Frequency'],
                'jobs'
              )
            ) : (
              <p className="text-gray-500">No jobs data uploaded yet.</p>
            )}
            <div className="mt-6 flex justify-center">
              <button
                onClick={() => handleSave('jobs')}
                className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Save size={20} /> Save
              </button>
            </div>
          </div>
        );
      case 'database':
        return (
            <div>
              <h3 className="text-xl font-bold mb-4">Database Detail</h3>
            {databaseDetails.length === 0 ? (
              <p className="text-gray-500">No database details uploaded yet.</p>
            ) : (
              <DatabaseDetailsView
                databaseDetails={databaseDetails}
                onUpdate={(updated) => setDatabaseDetails(updated)}
              />
            )}
          </div>
        );
      default:
        return null;
    }
  };

  // Component: Database details view (inline mini-component)
  function DatabaseDetailsView({ databaseDetails, onUpdate }) {
    const [selectedDb, setSelectedDb] = useState(0);
    const [selectedTable, setSelectedTable] = useState(0);
    const [local, setLocal] = useState(databaseDetails || []);
    const [edited, setEdited] = useState({});

    useEffect(() => {
      setLocal(databaseDetails || []);
    }, [databaseDetails]);

    const apiBase = window.location.hostname === 'localhost' ? 'http://localhost:5000' : '';

    const updateLocalDbField = (dbIdx, field, value) => {
      const copy = JSON.parse(JSON.stringify(local));
      copy[dbIdx][field] = value;
      setLocal(copy);
      setEdited(prev => ({ ...prev, [`db-${dbIdx}`]: true }));
    };

    const updateLocalTableField = (dbIdx, tableIdx, field, value) => {
      const copy = JSON.parse(JSON.stringify(local));
      copy[dbIdx].tables[tableIdx][field] = value;
      setLocal(copy);
      setEdited(prev => ({ ...prev, [`table-${dbIdx}-${tableIdx}`]: true }));
    };

    const updateLocalColumnField = (dbIdx, tableIdx, colIdx, field, value) => {
      const copy = JSON.parse(JSON.stringify(local));
      copy[dbIdx].tables[tableIdx].columns[colIdx][field] = value;
      setLocal(copy);
      setEdited(prev => ({ ...prev, [`col-${dbIdx}-${tableIdx}-${colIdx}`]: true }));
    };

    const saveDatabase = async (dbIdx) => {
      const db = local[dbIdx];
      try {
        const res = await fetch(`${apiBase}/api/database-details/${db.DATABASE_ID}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ BUSINESS_NAME: db.BUSINESS_NAME, BUSINESS_DESCRIPTION: db.BUSINESS_DESCRIPTION })
        });
        if (res.ok) {
          setEdited(prev => ({ ...prev, [`db-${dbIdx}`]: false }));
          onUpdate(local);
          alert('Database saved');
        } else {
          const err = await res.json();
          alert('Error saving database: ' + (err.error || JSON.stringify(err)));
        }
      } catch (e) {
        alert('Error saving database: ' + e.message);
      }
    };

    const saveTableAndColumns = async (dbIdx, tableIdx) => {
      const table = local[dbIdx].tables[tableIdx];
      try {
        // update table business fields
        const tRes = await fetch(`${apiBase}/api/database-details/tables/${table.TABLE_ID}`, {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ BUSINESS_NAME: table.BUSINESS_NAME, BUSINESS_DESCRIPTION: table.BUSINESS_DESCRIPTION })
        });
        if (!tRes.ok) {
          const err = await tRes.json();
          alert('Error saving table: ' + (err.error || JSON.stringify(err)));
          return;
        }

        // update columns
        const colsPayload = (table.columns || []).map(c => ({
          COLUMN_NAME: c.COLUMN_NAME,
          BUSINESS_NAME: c.BUSINESS_NAME,
          BUSINESS_DESCRIPTION: c.BUSINESS_DESCRIPTION,
          CLASSIFICATION: c.CLASSIFICATION
        }));
        const cRes = await fetch(`${apiBase}/api/database-details/tables/${table.TABLE_ID}/columns`, {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ columns: colsPayload })
        });

        if (!cRes.ok) {
          const err = await cRes.json();
          alert('Error saving columns: ' + (err.error || JSON.stringify(err)));
          return;
        }

        setEdited(prev => ({ ...prev, [`table-${dbIdx}-${tableIdx}`]: false }));
        onUpdate(local);
        alert('Table and columns saved');
      } catch (e) {
        alert('Error saving table/columns: ' + e.message);
      }
    };

    const currentDb = local[selectedDb] || null;

    return (
      <div>
        <div className="flex gap-4">
          <div className="w-1/4 bg-white rounded-lg shadow p-4">
            <h4 className="font-semibold mb-2">Databases</h4>
            <div className="flex flex-col gap-2">
              {local.map((db, idx) => (
                <button key={idx} onClick={() => { setSelectedDb(idx); setSelectedTable(0); }}
                  className={`text-left px-3 py-2 rounded ${selectedDb===idx ? 'bg-blue-50 border-l-4 border-blue-600' : 'hover:bg-gray-50'}`}>
                  {db.DATABASE_NAME}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 bg-white rounded-lg shadow p-6">
            {currentDb ? (
              <div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm text-gray-600">AIT Number</label>
                    <input readOnly value={currentDb.AIT_NUMBER || ''} className="w-full mt-1 p-2 border rounded bg-gray-50" />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600">Asset Name</label>
                    <input readOnly value={currentDb.ASSET_NAME || ''} className="w-full mt-1 p-2 border rounded bg-gray-50" />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-sm text-gray-600">Database Name</label>
                  <input readOnly value={currentDb.DATABASE_NAME || ''} className="w-full mt-1 p-2 border rounded bg-gray-50" />
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm text-gray-600">Database Business Name</label>
                    <input value={currentDb.BUSINESS_NAME || ''}
                      onChange={(e) => updateLocalDbField(selectedDb, 'BUSINESS_NAME', e.target.value)}
                      className={`w-full mt-1 p-2 border rounded ${!(currentDb.BUSINESS_NAME || '').trim() ? 'border-red-500 bg-red-50' : ''}`} />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600">Database Business Description</label>
                    <input value={currentDb.BUSINESS_DESCRIPTION || ''}
                      onChange={(e) => updateLocalDbField(selectedDb, 'BUSINESS_DESCRIPTION', e.target.value)}
                      className={`w-full mt-1 p-2 border rounded ${!(currentDb.BUSINESS_DESCRIPTION || '').trim() ? 'border-red-500 bg-red-50' : ''}`} />
                  </div>
                </div>

                <div className="mb-6">
                  <h4 className="font-semibold mb-2">Tables</h4>
                  <div className="flex gap-2 mb-4">
                    {(currentDb.tables || []).map((t, ti) => (
                      <button key={ti} onClick={() => setSelectedTable(ti)}
                        className={`px-3 py-2 rounded ${selectedTable===ti ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}>
                        {t.TABLE_NAME}
                      </button>
                    ))}
                  </div>

                  {currentDb.tables && currentDb.tables[selectedTable] ? (
                    <div>
                      <div className="mb-3">
                        <label className="block text-sm text-gray-600">Table Name</label>
                        <input readOnly value={currentDb.tables[selectedTable].TABLE_NAME || ''} className="w-full mt-1 p-2 border rounded bg-gray-50" />
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="block text-sm text-gray-600">Table Business Name</label>
                          <input value={currentDb.tables[selectedTable].BUSINESS_NAME || ''}
                            onChange={(e) => updateLocalTableField(selectedDb, selectedTable, 'BUSINESS_NAME', e.target.value)}
                            className={`w-full mt-1 p-2 border rounded ${!(currentDb.tables[selectedTable].BUSINESS_NAME || '').trim() ? 'border-red-500 bg-red-50' : ''}`} />
                        </div>
                        <div>
                          <label className="block text-sm text-gray-600">Table Business Description</label>
                          <input value={currentDb.tables[selectedTable].BUSINESS_DESCRIPTION || ''}
                            onChange={(e) => updateLocalTableField(selectedDb, selectedTable, 'BUSINESS_DESCRIPTION', e.target.value)}
                            className={`w-full mt-1 p-2 border rounded ${!(currentDb.tables[selectedTable].BUSINESS_DESCRIPTION || '').trim() ? 'border-red-500 bg-red-50' : ''}`} />
                        </div>
                      </div>

                      <div className="mb-4">
                        <h5 className="font-semibold mb-2">Columns</h5>
                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse">
                            <thead>
                              <tr className="bg-gray-100">
                                <th className="px-3 py-2 text-left">Column Name</th>
                                <th className="px-3 py-2 text-left">Data Type</th>
                                <th className="px-3 py-2 text-left">Classification</th>
                                <th className="px-3 py-2 text-left">Business Name</th>
                                <th className="px-3 py-2 text-left">Business Description</th>
                              </tr>
                            </thead>
                            <tbody>
                              {currentDb.tables[selectedTable].columns.map((c, ci) => (
                                <tr key={ci} className="border-b">
                                  <td className="px-3 py-2">{c.COLUMN_NAME}</td>
                                  <td className="px-3 py-2">{c.DATA_TYPE}</td>
                                  <td className="px-3 py-2">
                                    <select value={c.CLASSIFICATION || ''} onChange={(e) => updateLocalColumnField(selectedDb, selectedTable, ci, 'CLASSIFICATION', e.target.value)} className="p-1 border rounded">
                                      <option value="">--</option>
                                      <option value="Public">Public</option>
                                      <option value="Internal">Internal</option>
                                      <option value="Restricted">Restricted</option>
                                      <option value="Confidential">Confidential</option>
                                    </select>
                                  </td>
                                  <td className="px-3 py-2">
                                    <input value={c.BUSINESS_NAME || ''} onChange={(e) => updateLocalColumnField(selectedDb, selectedTable, ci, 'BUSINESS_NAME', e.target.value)}
                                      className={`w-full p-1 border rounded ${!(c.BUSINESS_NAME || '').trim() ? 'border-red-500 bg-red-50' : ''}`} />
                                  </td>
                                  <td className="px-3 py-2">
                                    <input value={c.BUSINESS_DESCRIPTION || ''} onChange={(e) => updateLocalColumnField(selectedDb, selectedTable, ci, 'BUSINESS_DESCRIPTION', e.target.value)}
                                      className={`w-full p-1 border rounded ${!(c.BUSINESS_DESCRIPTION || '').trim() ? 'border-red-500 bg-red-50' : ''}`} />
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div className="flex gap-3 justify-center">
                        <button onClick={() => saveDatabase(selectedDb)} className="px-4 py-2 bg-blue-600 text-white rounded">Save Database</button>
                        <button onClick={() => saveTableAndColumns(selectedDb, selectedTable)} className="px-4 py-2 bg-green-600 text-white rounded">Save Table & Columns</button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-500">No tables found for this database.</p>
                  )}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  const renderManagement = () => (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">SLA Management</h2>
      <div className="flex gap-2 mb-6 border-b border-gray-300">
        {['assets', 'slas', 'jobs', 'database'].map(subTab => (
          <button
            key={subTab}
            onClick={() => setManagementSubTab(subTab)}
            className={`px-4 py-2 font-medium transition-all ${
              managementSubTab === subTab
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-blue-600'
            }`}
          >
            {subTab.charAt(0).toUpperCase() + subTab.slice(1)}
          </button>
        ))}
      </div>
      <div className="bg-white rounded-lg shadow p-6 overflow-auto">
        {renderManagementSubtab(managementSubTab)}
      </div>
    </div>
  );

  const renderMonitoringTable = (data, title, columns) => (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <RotateCcw size={16} className="animate-spin" />
          Auto-refreshing every 5 seconds
        </div>
      </div>
      <div className="bg-white rounded-lg shadow overflow-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-green-600 text-white">
              {columns.map(col => (
                <th key={col} className="px-4 py-3 text-left font-semibold border">{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.length > 0 ? (
              data.map((row, idx) => (
                <tr key={idx} className={idx % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                  {columns.map(col => (
                    <td key={`${idx}-${col}`} className="px-4 py-3 border text-sm">
                      {row[col] || '-'}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length} className="px-4 py-6 text-center text-gray-500">
                  No data available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderHistoryTable = (data, title, columns) => (
    <div className="max-w-7xl mx-auto px-6 py-8">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">{title}</h2>
      <div className="bg-white rounded-lg shadow overflow-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-purple-600 text-white">
              {columns.map(col => (
                <th key={col} className="px-4 py-3 text-left font-semibold border">{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.length > 0 ? (
              data.map((row, idx) => (
                <tr key={idx} className={idx % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                  {columns.map(col => (
                    <td key={`${idx}-${col}`} className="px-4 py-3 border text-sm">
                      {row[col] || '-'}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length} className="px-4 py-6 text-center text-gray-500">
                  No historical data available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white shadow-xl">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <h1 className="text-3xl font-bold">SLA Management & Real-Time Tracking System</h1>
        </div>
      </div>

      {/* Navigation */}
      {renderNavigation()}

      {/* Content */}
      <div className="min-h-screen bg-gray-100 py-8">
        {activeTab === 'onboarding' && renderOnboarding()}
        {activeTab === 'management' && renderManagement()}
        {activeTab === 'monitoring-slas' && renderMonitoringTable(slaMonitorLog, 'Monitoring SLAs in Real-Time', ['SLA Name', 'SLA Type', 'Status', 'Expected Start Time', 'Start Time', 'Expected End Time', 'End Time'])}
        {activeTab === 'monitoring-jobs' && renderMonitoringTable(jobsMonitorLog, 'Monitoring Jobs in Real-Time', ['Job Name', 'Job Type', 'Status', 'Expected Start Time', 'Start Time', 'Expected End Time', 'End Time'])}
        {activeTab === 'history-slas' && renderHistoryTable(slaHistory, 'Historical Actual SLAs Data', ['SLA Name', 'SLA Type', 'Status', 'Execution Date', 'Start Time', 'End Time'])}
        {activeTab === 'history-jobs' && renderHistoryTable(jobsHistory, 'Historical Actual Jobs Data', ['Job Name', 'Job Type', 'Status', 'Execution Date', 'Start Time', 'End Time'])}
      </div>
      </div>
    </ErrorBoundary>
  );
}

// Simple error boundary to surface runtime errors in the page (helps debugging blank page)
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, info: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.error('Uncaught error in React tree:', error, info);
    this.setState({ error, info });
  }

  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-start justify-center p-8 bg-gray-50">
          <div className="max-w-4xl w-full bg-white rounded shadow p-6 border border-red-100">
            <h2 className="text-xl font-bold text-red-700 mb-2">Application error</h2>
            <div className="text-sm text-gray-700 mb-4">An error occurred while rendering the app. The error details are shown below.</div>
            <pre className="text-xs whitespace-pre-wrap bg-red-50 p-3 rounded border border-red-100 text-red-800 overflow-auto">
{String(this.state.error && (this.state.error.stack || this.state.error.message || this.state.error))}
            </pre>
            <div className="mt-4 text-right">
              <button onClick={() => location.reload()} className="px-3 py-1 bg-blue-600 text-white rounded">Reload</button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}