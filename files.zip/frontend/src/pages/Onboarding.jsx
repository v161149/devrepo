/**
 * Onboarding.jsx
 * 5-step wizard for new users to create their first Asset, Service, Job, and SLA
 * Part 2: Frontend Components - SLA Portal Enhancements
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FiCheckCircle, 
  FiCircle, 
  FiArrowRight, 
  FiArrowLeft,
  FiServer,
  FiDatabase,
  FiBriefcase,
  FiTarget,
  FiHelpCircle,
  FiCalendar,
  FiClock,
  FiInfo
} from 'react-icons/fi';
import Button from '../components/Button';

const Onboarding = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [showCronHelper, setShowCronHelper] = useState(false);
  const [showSLACalculator, setShowSLACalculator] = useState(false);
  
  // Form state for each step
  const [assetData, setAssetData] = useState({
    asset_name: 'My Production Server',
    asset_type: 'Server',
    asset_owner: 'IT Operations',
    description: 'Main production application server',
    onboarded_date: new Date().toISOString().split('T')[0],
    status: 'active'
  });

  const [serviceData, setServiceData] = useState({
    name: 'Critical Application Service',
    description: 'Core business application service',
    owner_team: 'Application Team',
    asset_id: '', // Will be set after asset creation
    monitoring_method: 'direct',
    deployment_location: 'autosys'
  });

  const [jobData, setJobData] = useState({
    job_name: 'Daily Data Processing',
    job_type: 'ETL',
    deployment_location: 'autosys',
    schedule: '0 2 * * *', // 2 AM daily
    description: 'Daily batch processing job',
    expected_duration: 60
  });

  const [slaData, setSlaData] = useState({
    name: 'Daily Processing SLA',
    metric_type: 'uptime',
    target_value: 99.0,
    target_unit: 'percentage',
    priority: 'P1',
    description: 'Ensure daily processing completes successfully',
    effective_from: new Date().toISOString().split('T')[0]
  });

  const [createdIds, setCreatedIds] = useState({
    assetId: null,
    serviceId: null,
    jobId: null,
    slaId: null
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Steps configuration
  const steps = [
    { number: 1, title: 'Create Asset', icon: FiServer, description: 'Define your infrastructure asset' },
    { number: 2, title: 'Create Service', icon: FiDatabase, description: 'Set up a service on the asset' },
    { number: 3, title: 'Add Job', icon: FiBriefcase, description: 'Configure a scheduled job' },
    { number: 4, title: 'Define SLA', icon: FiTarget, description: 'Set service level objectives' },
    { number: 5, title: 'Complete', icon: FiCheckCircle, description: 'Review and finish' }
  ];

  // Validation functions
  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 1:
        if (!assetData.asset_name) newErrors.asset_name = 'Asset name is required';
        if (!assetData.asset_type) newErrors.asset_type = 'Asset type is required';
        if (!assetData.asset_owner) newErrors.asset_owner = 'Asset owner is required';
        break;
      case 2:
        if (!serviceData.name) newErrors.name = 'Service name is required';
        if (!serviceData.owner_team) newErrors.owner_team = 'Owner team is required';
        break;
      case 3:
        if (!jobData.job_name) newErrors.job_name = 'Job name is required';
        if (!jobData.schedule) newErrors.schedule = 'Schedule is required';
        if (!isValidCron(jobData.schedule)) newErrors.schedule = 'Invalid cron format';
        break;
      case 4:
        if (!slaData.name) newErrors.name = 'SLA name is required';
        if (!slaData.target_value || slaData.target_value <= 0) {
          newErrors.target_value = 'Valid target value is required';
        }
        break;
      default:
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Cron validation (basic)
  const isValidCron = (cron) => {
    const parts = cron.split(' ');
    return parts.length === 5;
  };

  // API calls
  const createAsset = async () => {
    try {
      const token = localStorage.getItem('token');  // ← ADD THIS LINE
      
      const response = await fetch('http://localhost:5000/api/v1/assets', {  // ← Full URL
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // ← ADD THIS LINE
        },
        body: JSON.stringify({
          ...assetData,
          org_id: '1' // Default org
        })
      });
      
      if (!response.ok) throw new Error('Failed to create asset');
      
      const data = await response.json();
      setCreatedIds(prev => ({ ...prev, assetId: data.asset_id }));
      setServiceData(prev => ({ ...prev, asset_id: data.asset_id }));
      return data.asset_id;
    } catch (error) {
      console.error('Error creating asset:', error);
      setErrors({ submit: 'Failed to create asset. Please try again.' });
      throw error;
    }
  };

  const createService = async () => {
    try {
      const token = localStorage.getItem('token');
      
      console.log('=== CREATE SERVICE DEBUG ===');
      console.log('Service data:', serviceData);
      
      const response = await fetch('http://localhost:5000/api/v1/services', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          ...serviceData,
          org_id: '1',
          is_active: true
        })
      });
      
      console.log('Response status:', response.status);
      
      if (!response.ok) {
        // ✅ GET THE ACTUAL ERROR MESSAGE FROM BACKEND
        const errorData = await response.json();
        console.error('=== BACKEND ERROR ===');
        console.error('Error details:', errorData);
        throw new Error(errorData.error || 'Failed to create service');
      }
      
      const data = await response.json();
      console.log('✅ Service created:', data);
      setCreatedIds(prev => ({ ...prev, serviceId: data.service_id }));
      return data.service_id;
    } catch (error) {
      console.error('Error creating service:', error);
      setErrors({ submit: 'Failed to create service. Please try again.' });
      throw error;
    }
  };

  const createJob = async () => {
    try {
      const token = localStorage.getItem('token');  // ← ADD THIS LINE
      
      // Note: This is a placeholder - adjust based on your actual job creation API
      const response = await fetch('http://localhost:5000/api/v1/jobs', {  // ← Full URL
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // ← ADD THIS LINE
        },
        body: JSON.stringify({
          ...jobData,
          service_id: createdIds.serviceId,
          asset_id: createdIds.assetId
        })
      });
      
      if (!response.ok) throw new Error('Failed to create job');
      
      const data = await response.json();
      setCreatedIds(prev => ({ ...prev, jobId: data.job_id }));
      return data.job_id;
    } catch (error) {
      console.error('Error creating job:', error);
      setErrors({ submit: 'Failed to create job. Please try again.' });
      throw error;
    }
  };

  const createSLA = async () => {
    try {
      const token = localStorage.getItem('token');  // ← ADD THIS LINE
      
      const response = await fetch('http://localhost:5000/api/v1/slas', {  // ← Full URL
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // ← ADD THIS LINE
        },
        body: JSON.stringify({
          ...slaData,
          org_id: '1',
          service_id: createdIds.serviceId,
          start_condition: JSON.stringify({ type: 'job_start' }),
          stop_condition: JSON.stringify({ type: 'job_complete' }),
          is_active: true,
          version: 1
        })
      });
      
      if (!response.ok) throw new Error('Failed to create SLA');
      
      const data = await response.json();
      setCreatedIds(prev => ({ ...prev, slaId: data.sla_id }));
      return data.sla_id;
    } catch (error) {
      console.error('Error creating SLA:', error);
      setErrors({ submit: 'Failed to create SLA. Please try again.' });
      throw error;
    }
  };

  // Navigation handlers
  const handleNext = async () => {
    if (!validateStep(currentStep)) {
      return;
    }

    setIsSubmitting(true);
    setErrors({});

    try {
      // Create entities as we progress through steps
      if (currentStep === 1) {
        await createAsset();
      } else if (currentStep === 2) {
        await createService();
      } else if (currentStep === 3) {
        await createJob();
      } else if (currentStep === 4) {
        await createSLA();
      }

      setCurrentStep(prev => prev + 1);
    } catch (error) {
      // Error already set in create functions
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(1, prev - 1));
    setErrors({});
  };

  const handleFinish = () => {
    // Navigate to Process Flow to see the created hierarchy
    navigate(`/process-flow?highlight=${createdIds.assetId}`);
  };

  // Render step content
  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Step 1: Create Your First Asset</h3>
            <p className="text-gray-600 mb-6">
              An asset represents a piece of infrastructure (server, database, application) that runs your services.
            </p>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Asset Name *
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.asset_name ? 'border-red-500' : 'border-gray-300'
                }`}
                value={assetData.asset_name}
                onChange={(e) => setAssetData({ ...assetData, asset_name: e.target.value })}
                placeholder="e.g., Production App Server"
              />
              {errors.asset_name && (
                <p className="text-red-500 text-sm mt-1">{errors.asset_name}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Asset Type *
              </label>
              <select
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.asset_type ? 'border-red-500' : 'border-gray-300'
                }`}
                value={assetData.asset_type}
                onChange={(e) => setAssetData({ ...assetData, asset_type: e.target.value })}
              >
                <option value="Server">Server</option>
                <option value="Database">Database</option>
                <option value="Application">Application</option>
                <option value="Cloud Service">Cloud Service</option>
              </select>
              {errors.asset_type && (
                <p className="text-red-500 text-sm mt-1">{errors.asset_type}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Asset Owner *
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.asset_owner ? 'border-red-500' : 'border-gray-300'
                }`}
                value={assetData.asset_owner}
                onChange={(e) => setAssetData({ ...assetData, asset_owner: e.target.value })}
                placeholder="e.g., IT Operations Team"
              />
              {errors.asset_owner && (
                <p className="text-red-500 text-sm mt-1">{errors.asset_owner}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={assetData.description}
                onChange={(e) => setAssetData({ ...assetData, description: e.target.value })}
                placeholder="Brief description of this asset"
                rows="3"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Onboarded Date
              </label>
              <input
                type="date"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={assetData.onboarded_date}
                onChange={(e) => setAssetData({ ...assetData, onboarded_date: e.target.value })}
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Step 2: Create a Service</h3>
            <p className="text-gray-600 mb-6">
              A service represents a business capability or application running on your asset.
            </p>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Service Name *
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.name ? 'border-red-500' : 'border-gray-300'
                }`}
                value={serviceData.name}
                onChange={(e) => setServiceData({ ...serviceData, name: e.target.value })}
                placeholder="e.g., Payment Processing Service"
              />
              {errors.name && (
                <p className="text-red-500 text-sm mt-1">{errors.name}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Owner Team *
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.owner_team ? 'border-red-500' : 'border-gray-300'
                }`}
                value={serviceData.owner_team}
                onChange={(e) => setServiceData({ ...serviceData, owner_team: e.target.value })}
                placeholder="e.g., Application Development Team"
              />
              {errors.owner_team && (
                <p className="text-red-500 text-sm mt-1">{errors.owner_team}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={serviceData.description}
                onChange={(e) => setServiceData({ ...serviceData, description: e.target.value })}
                placeholder="What does this service do?"
                rows="3"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Deployment Location
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={serviceData.deployment_location}
                onChange={(e) => setServiceData({ ...serviceData, deployment_location: e.target.value })}
              >
                <option value="autosys">Autosys</option>
                <option value="ansible_tower">Ansible Tower</option>
                <option value="airflow">Airflow</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start">
                <FiInfo className="text-blue-500 mt-1 mr-3 flex-shrink-0" />
                <div>
                  <p className="text-sm text-blue-800">
                    This service will run on: <strong>{assetData.asset_name}</strong>
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Step 3: Add a Scheduled Job</h3>
            <p className="text-gray-600 mb-6">
              Jobs are scheduled tasks that run as part of your service (batch jobs, ETL processes, etc.).
            </p>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Job Name *
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.job_name ? 'border-red-500' : 'border-gray-300'
                }`}
                value={jobData.job_name}
                onChange={(e) => setJobData({ ...jobData, job_name: e.target.value })}
                placeholder="e.g., Daily Sales Report"
              />
              {errors.job_name && (
                <p className="text-red-500 text-sm mt-1">{errors.job_name}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Job Type
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={jobData.job_type}
                onChange={(e) => setJobData({ ...jobData, job_type: e.target.value })}
              >
                <option value="ETL">ETL (Extract, Transform, Load)</option>
                <option value="Batch">Batch Processing</option>
                <option value="Report">Report Generation</option>
                <option value="Backup">Backup</option>
                <option value="Sync">Data Synchronization</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Schedule (Cron Format) *
                <button
                  type="button"
                  onClick={() => setShowCronHelper(true)}
                  className="ml-2 text-primary-600 hover:text-primary-700"
                >
                  <FiHelpCircle className="inline" /> Help
                </button>
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono ${
                  errors.schedule ? 'border-red-500' : 'border-gray-300'
                }`}
                value={jobData.schedule}
                onChange={(e) => setJobData({ ...jobData, schedule: e.target.value })}
                placeholder="0 2 * * *"
              />
              {errors.schedule && (
                <p className="text-red-500 text-sm mt-1">{errors.schedule}</p>
              )}
              <p className="text-sm text-gray-500 mt-1">
                Current: Runs at 2:00 AM every day
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Expected Duration (minutes)
              </label>
              <input
                type="number"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={jobData.expected_duration}
                onChange={(e) => setJobData({ ...jobData, expected_duration: parseInt(e.target.value) })}
                placeholder="60"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={jobData.description}
                onChange={(e) => setJobData({ ...jobData, description: e.target.value })}
                placeholder="What does this job do?"
                rows="3"
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Step 4: Define SLA</h3>
            <p className="text-gray-600 mb-6">
              Set service level objectives to monitor and track your service's performance.
            </p>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                SLA Name *
              </label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.name ? 'border-red-500' : 'border-gray-300'
                }`}
                value={slaData.name}
                onChange={(e) => setSlaData({ ...slaData, name: e.target.value })}
                placeholder="e.g., 99% Uptime SLA"
              />
              {errors.name && (
                <p className="text-red-500 text-sm mt-1">{errors.name}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Metric Type
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={slaData.metric_type}
                onChange={(e) => setSlaData({ ...slaData, metric_type: e.target.value })}
              >
                <option value="uptime">Uptime</option>
                <option value="response_time">Response Time</option>
                <option value="resolution_time">Resolution Time</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target Value * (%)
                <button
                  type="button"
                  onClick={() => setShowSLACalculator(true)}
                  className="ml-2 text-primary-600 hover:text-primary-700"
                >
                  <FiHelpCircle className="inline" /> Calculator
                </button>
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.target_value ? 'border-red-500' : 'border-gray-300'
                }`}
                value={slaData.target_value}
                onChange={(e) => setSlaData({ ...slaData, target_value: parseFloat(e.target.value) })}
                placeholder="99.0"
              />
              {errors.target_value && (
                <p className="text-red-500 text-sm mt-1">{errors.target_value}</p>
              )}
              <p className="text-sm text-gray-500 mt-1">
                99% = ~7.2 hours downtime/month | 99.9% = ~43 minutes/month
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority
              </label>
              <select
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={slaData.priority}
                onChange={(e) => setSlaData({ ...slaData, priority: e.target.value })}
              >
                <option value="P1">P1 - Critical</option>
                <option value="P2">P2 - High</option>
                <option value="P3">P3 - Medium</option>
                <option value="P4">P4 - Low</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Effective From
              </label>
              <input
                type="date"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={slaData.effective_from}
                onChange={(e) => setSlaData({ ...slaData, effective_from: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={slaData.description}
                onChange={(e) => setSlaData({ ...slaData, description: e.target.value })}
                placeholder="What is this SLA measuring?"
                rows="3"
              />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <FiCheckCircle className="text-6xl text-green-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Congratulations!</h3>
              <p className="text-gray-600">
                You've successfully set up your first monitoring hierarchy.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h4 className="font-semibold text-gray-800 mb-4">What You Created:</h4>
              
              <div className="space-y-3">
                <div className="flex items-start">
                  <FiServer className="text-blue-500 mt-1 mr-3 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-gray-800">Asset: {assetData.asset_name}</p>
                    <p className="text-sm text-gray-600">{assetData.asset_type}</p>
                  </div>
                </div>

                <div className="ml-8 border-l-2 border-gray-300 pl-4 py-2">
                  <div className="flex items-start">
                    <FiDatabase className="text-purple-500 mt-1 mr-3 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-800">Service: {serviceData.name}</p>
                      <p className="text-sm text-gray-600">{serviceData.owner_team}</p>
                    </div>
                  </div>

                  <div className="ml-8 border-l-2 border-gray-300 pl-4 py-2 mt-2">
                    <div className="flex items-start">
                      <FiBriefcase className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-gray-800">Job: {jobData.job_name}</p>
                        <p className="text-sm text-gray-600">{jobData.job_type}</p>
                      </div>
                    </div>

                    <div className="ml-8 border-l-2 border-gray-300 pl-4 py-2 mt-2">
                      <div className="flex items-start">
                        <FiTarget className="text-orange-500 mt-1 mr-3 flex-shrink-0" />
                        <div>
                          <p className="font-medium text-gray-800">SLA: {slaData.name}</p>
                          <p className="text-sm text-gray-600">
                            Target: {slaData.target_value}% {slaData.metric_type}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                <strong>Next Steps:</strong> View your setup in the Process Flow diagram, explore the 
                monitoring dashboard, or add more assets and services.
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome to SLA Monitor</h1>
          <p className="text-gray-600">Let's set up your first monitoring hierarchy</p>
        </div>

        {/* Progress Steps */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <React.Fragment key={step.number}>
                <div className="flex flex-col items-center flex-1">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                      step.number < currentStep
                        ? 'bg-green-500 text-white'
                        : step.number === currentStep
                        ? 'bg-primary-600 text-white'
                        : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {step.number < currentStep ? (
                      <FiCheckCircle className="text-xl" />
                    ) : (
                      <step.icon className="text-xl" />
                    )}
                  </div>
                  <p className="text-xs font-medium text-center hidden sm:block">
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`h-1 flex-1 mx-2 ${
                      step.number < currentStep ? 'bg-green-500' : 'bg-gray-200'
                    }`}
                  />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-6">
          {renderStepContent()}

          {errors.submit && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{errors.submit}</p>
            </div>
          )}
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between">
          <Button
            variant="secondary"
            onClick={handleBack}
            disabled={currentStep === 1 || isSubmitting}
          >
            <FiArrowLeft className="mr-2" />
            Back
          </Button>

          {currentStep < 5 ? (
            <Button
              onClick={handleNext}
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Creating...' : 'Next'}
              <FiArrowRight className="ml-2" />
            </Button>
          ) : (
            <Button onClick={handleFinish}>
              View Process Flow
              <FiArrowRight className="ml-2" />
            </Button>
          )}
        </div>

        {/* Cron Helper Modal */}
        {showCronHelper && (
          <CronHelperModal onClose={() => setShowCronHelper(false)} />
        )}

        {/* SLA Calculator Modal */}
        {showSLACalculator && (
          <SLACalculatorModal onClose={() => setShowSLACalculator(false)} />
        )}
      </div>
    </div>
  );
};

// Cron Helper Modal Component
const CronHelperModal = ({ onClose }) => {
  const commonSchedules = [
    { label: 'Every hour', cron: '0 * * * *' },
    { label: 'Every day at midnight', cron: '0 0 * * *' },
    { label: 'Every day at 2 AM', cron: '0 2 * * *' },
    { label: 'Every weekday at 9 AM', cron: '0 9 * * 1-5' },
    { label: 'Every Monday at 8 AM', cron: '0 8 * * 1' },
    { label: 'Every 15 minutes', cron: '*/15 * * * *' },
    { label: 'First day of month', cron: '0 0 1 * *' }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Cron Schedule Helper</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            ✕
          </button>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-4">
            Cron format: <code className="bg-gray-100 px-2 py-1 rounded">minute hour day month weekday</code>
          </p>

          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <h4 className="font-medium mb-2">Common Schedules:</h4>
            <div className="space-y-2">
              {commonSchedules.map((schedule, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm">{schedule.label}</span>
                  <code className="bg-white px-3 py-1 rounded border text-sm font-mono">
                    {schedule.cron}
                  </code>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Format Guide:</h4>
            <ul className="text-sm space-y-1 text-gray-700">
              <li>• <code>*</code> = any value</li>
              <li>• <code>*/n</code> = every n units (e.g., */15 = every 15 minutes)</li>
              <li>• <code>n-m</code> = range (e.g., 1-5 = Monday to Friday)</li>
              <li>• <code>n,m</code> = list (e.g., 1,3,5 = Mon, Wed, Fri)</li>
            </ul>
          </div>
        </div>

        <Button onClick={onClose} className="w-full">
          Got it!
        </Button>
      </div>
    </div>
  );
};

// SLA Calculator Modal Component
const SLACalculatorModal = ({ onClose }) => {
  const [uptime, setUptime] = useState(99.0);

  const calculateDowntime = (uptimePercent) => {
    const downtimePercent = 100 - uptimePercent;
    const monthlyMinutes = 30 * 24 * 60;
    const yearlyMinutes = 365 * 24 * 60;
    
    return {
      monthly: (monthlyMinutes * downtimePercent / 100).toFixed(2),
      yearly: (yearlyMinutes * downtimePercent / 100).toFixed(2)
    };
  };

  const downtime = calculateDowntime(uptime);

  const slaLevels = [
    { percent: 90, monthly: '72 hours', yearly: '36.5 days' },
    { percent: 95, monthly: '36 hours', yearly: '18.25 days' },
    { percent: 99, monthly: '7.2 hours', yearly: '3.65 days' },
    { percent: 99.5, monthly: '3.6 hours', yearly: '1.83 days' },
    { percent: 99.9, monthly: '43 minutes', yearly: '8.76 hours' },
    { percent: 99.99, monthly: '4.3 minutes', yearly: '52.6 minutes' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">SLA Uptime Calculator</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            ✕
          </button>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Uptime Percentage: {uptime}%
          </label>
          <input
            type="range"
            min="90"
            max="99.99"
            step="0.01"
            value={uptime}
            onChange={(e) => setUptime(parseFloat(e.target.value))}
            className="w-full"
          />

          <div className="mt-4 bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Allowed Downtime:</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Per Month</p>
                <p className="text-lg font-semibold">{downtime.monthly} minutes</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Per Year</p>
                <p className="text-lg font-semibold">{downtime.yearly} minutes</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <h4 className="font-medium mb-3">Common SLA Levels:</h4>
          <div className="space-y-2">
            {slaLevels.map((level) => (
              <div
                key={level.percent}
                className="flex justify-between items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
                onClick={() => setUptime(level.percent)}
              >
                <span className="font-medium">{level.percent}%</span>
                <span className="text-sm text-gray-600">
                  {level.monthly}/month • {level.yearly}/year
                </span>
              </div>
            ))}
          </div>
        </div>

        <Button onClick={onClose} className="w-full">
          Close
        </Button>
      </div>
    </div>
  );
};

export default Onboarding;
