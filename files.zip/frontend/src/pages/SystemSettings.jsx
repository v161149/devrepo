/**
 * System Settings Page
 * Manage system-wide configuration, preferences, and admin settings
 */

import React, { useState, useEffect } from 'react';
import { 
  FiSettings, 
  FiSave,
  FiRefreshCw,
  FiMail,
  FiClock,
  FiAlertCircle,
  FiDatabase,
  FiShield,
  FiToggleLeft,
  FiToggleRight,
  FiCheckCircle,
  FiUsers,
  FiServer
} from 'react-icons/fi';
import Button from '../components/Button';
import Card from '../components/Card';

const SystemSettings = () => {
  const [settings, setSettings] = useState({
    // Email Settings
    emailEnabled: true,
    emailServer: 'smtp.company.com',
    emailPort: '587',
    emailFrom: 'sla-portal@company.com',
    
    // Alert Settings
    alertRetention: '90',
    alertBatchSize: '100',
    criticalAlertEscalation: true,
    
    // System Settings
    sessionTimeout: '480',
    enableAuditLog: true,
    enableMetrics: true,
    
    // Health Monitoring
    healthCheckInterval: '60',
    jobCheckInterval: '1800',
    
    // Database
    autoBackup: true,
    backupRetention: '30',
    
    // LLM Provider
    llmProvider: 'mock',
    llmApiKey: ''
  });

  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // In production, save to backend
    console.log('Saving settings:', settings);
    
    setSaving(false);
    setSaved(true);
    
    setTimeout(() => setSaved(false), 3000);
  };

  const toggleBoolean = (field) => {
    handleChange(field, !settings[field]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
          <p className="text-gray-600 mt-2">
            Configure system-wide preferences and administrative settings
          </p>
        </div>
        <div className="flex gap-3">
          {saved && (
            <div className="flex items-center gap-2 text-green-600 bg-green-50 px-4 py-2 rounded-lg">
              <FiCheckCircle />
              <span className="font-medium">Settings Saved</span>
            </div>
          )}
          <Button
            onClick={handleSave}
            disabled={saving}
            icon={saving ? FiRefreshCw : FiSave}
            className={saving ? 'animate-pulse' : ''}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      {/* Email Notification Settings */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-100 rounded-lg">
            <FiMail className="text-2xl text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Email Notifications</h2>
            <p className="text-sm text-gray-600">Configure SMTP server and email settings</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Email Enabled Toggle */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="font-medium text-gray-900">Enable Email Notifications</label>
              <p className="text-sm text-gray-600">Send alerts and notifications via email</p>
            </div>
            <button
              onClick={() => toggleBoolean('emailEnabled')}
              className="flex items-center gap-2"
            >
              {settings.emailEnabled ? (
                <FiToggleRight className="text-4xl text-green-500" />
              ) : (
                <FiToggleLeft className="text-4xl text-gray-400" />
              )}
            </button>
          </div>

          {settings.emailEnabled && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SMTP Server
                  </label>
                  <input
                    type="text"
                    value={settings.emailServer}
                    onChange={(e) => handleChange('emailServer', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="smtp.company.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SMTP Port
                  </label>
                  <input
                    type="text"
                    value={settings.emailPort}
                    onChange={(e) => handleChange('emailPort', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="587"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  From Email Address
                </label>
                <input
                  type="email"
                  value={settings.emailFrom}
                  onChange={(e) => handleChange('emailFrom', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="sla-portal@company.com"
                />
              </div>
            </>
          )}
        </div>
      </Card>

      {/* Alert Management Settings */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-yellow-100 rounded-lg">
            <FiAlertCircle className="text-2xl text-yellow-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Alert Management</h2>
            <p className="text-sm text-gray-600">Configure alert processing and retention</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="font-medium text-gray-900">Critical Alert Escalation</label>
              <p className="text-sm text-gray-600">Auto-escalate critical alerts after 1 hour</p>
            </div>
            <button
              onClick={() => toggleBoolean('criticalAlertEscalation')}
              className="flex items-center gap-2"
            >
              {settings.criticalAlertEscalation ? (
                <FiToggleRight className="text-4xl text-green-500" />
              ) : (
                <FiToggleLeft className="text-4xl text-gray-400" />
              )}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Alert Retention (days)
              </label>
              <input
                type="number"
                value={settings.alertRetention}
                onChange={(e) => handleChange('alertRetention', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                min="30"
                max="365"
              />
              <p className="text-xs text-gray-500 mt-1">
                Keep alert history for specified days
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Alert Batch Size
              </label>
              <input
                type="number"
                value={settings.alertBatchSize}
                onChange={(e) => handleChange('alertBatchSize', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                min="10"
                max="1000"
              />
              <p className="text-xs text-gray-500 mt-1">
                Number of alerts to process in each batch
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* System Performance */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-green-100 rounded-lg">
            <FiClock className="text-2xl text-green-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Performance & Monitoring</h2>
            <p className="text-sm text-gray-600">Configure health checks and monitoring intervals</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Health Check Interval (seconds)
              </label>
              <input
                type="number"
                value={settings.healthCheckInterval}
                onChange={(e) => handleChange('healthCheckInterval', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                min="30"
                max="3600"
              />
              <p className="text-xs text-gray-500 mt-1">
                How often to check service health (30-3600 seconds)
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Job Check Interval (seconds)
              </label>
              <input
                type="number"
                value={settings.jobCheckInterval}
                onChange={(e) => handleChange('jobCheckInterval', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                min="300"
                max="7200"
              />
              <p className="text-xs text-gray-500 mt-1">
                How often to check job completion (300-7200 seconds)
              </p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Session Timeout (minutes)
            </label>
            <input
              type="number"
              value={settings.sessionTimeout}
              onChange={(e) => handleChange('sessionTimeout', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              min="15"
              max="1440"
            />
            <p className="text-xs text-gray-500 mt-1">
              User session expiration time (15-1440 minutes)
            </p>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="font-medium text-gray-900">Enable Audit Logging</label>
              <p className="text-sm text-gray-600">Track all user actions and system changes</p>
            </div>
            <button
              onClick={() => toggleBoolean('enableAuditLog')}
              className="flex items-center gap-2"
            >
              {settings.enableAuditLog ? (
                <FiToggleRight className="text-4xl text-green-500" />
              ) : (
                <FiToggleLeft className="text-4xl text-gray-400" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="font-medium text-gray-900">Enable Performance Metrics</label>
              <p className="text-sm text-gray-600">Collect detailed performance statistics</p>
            </div>
            <button
              onClick={() => toggleBoolean('enableMetrics')}
              className="flex items-center gap-2"
            >
              {settings.enableMetrics ? (
                <FiToggleRight className="text-4xl text-green-500" />
              ) : (
                <FiToggleLeft className="text-4xl text-gray-400" />
              )}
            </button>
          </div>
        </div>
      </Card>

      {/* Database Settings */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-purple-100 rounded-lg">
            <FiDatabase className="text-2xl text-purple-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Database Management</h2>
            <p className="text-sm text-gray-600">Configure backup and maintenance settings</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="font-medium text-gray-900">Automatic Backups</label>
              <p className="text-sm text-gray-600">Daily database backups at 2 AM</p>
            </div>
            <button
              onClick={() => toggleBoolean('autoBackup')}
              className="flex items-center gap-2"
            >
              {settings.autoBackup ? (
                <FiToggleRight className="text-4xl text-green-500" />
              ) : (
                <FiToggleLeft className="text-4xl text-gray-400" />
              )}
            </button>
          </div>

          {settings.autoBackup && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Backup Retention (days)
              </label>
              <input
                type="number"
                value={settings.backupRetention}
                onChange={(e) => handleChange('backupRetention', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                min="7"
                max="365"
              />
              <p className="text-xs text-gray-500 mt-1">
                How long to keep database backups (7-365 days)
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* AI Help Bot Settings */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-indigo-100 rounded-lg">
            <FiSettings className="text-2xl text-indigo-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold">AI Help Bot Configuration</h2>
            <p className="text-sm text-gray-600">Configure LLM provider for help bot</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              LLM Provider
            </label>
            <select
              value={settings.llmProvider}
              onChange={(e) => handleChange('llmProvider', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            >
              <option value="mock">Mock Provider (Testing)</option>
              <option value="claude">Anthropic Claude</option>
              <option value="chatgpt">OpenAI ChatGPT</option>
              <option value="custom">Custom LLM</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Select AI provider for help bot responses
            </p>
          </div>

          {settings.llmProvider !== 'mock' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                API Key
              </label>
              <input
                type="password"
                value={settings.llmApiKey}
                onChange={(e) => handleChange('llmApiKey', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="Enter API key..."
              />
              <p className="text-xs text-gray-500 mt-1">
                API key for {settings.llmProvider} (stored encrypted)
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* System Info */}
      <Card className="bg-gray-50">
        <div className="flex items-center gap-3 mb-4">
          <FiServer className="text-2xl text-gray-600" />
          <h3 className="text-lg font-semibold">System Information</h3>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Version</p>
            <p className="font-medium">1.0.0</p>
          </div>
          <div>
            <p className="text-gray-600">Database</p>
            <p className="font-medium">SQLite 3.x</p>
          </div>
          <div>
            <p className="text-gray-600">Backend</p>
            <p className="font-medium">Flask API</p>
          </div>
          <div>
            <p className="text-gray-600">Frontend</p>
            <p className="font-medium">React 18</p>
          </div>
        </div>
      </Card>

      {/* Save Reminder */}
      {!saved && (
        <Card className="bg-yellow-50 border-yellow-200">
          <div className="flex items-start gap-4">
            <FiAlertCircle className="text-2xl text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h4 className="font-semibold text-yellow-900 mb-2">Unsaved Changes</h4>
              <p className="text-sm text-yellow-800">
                Remember to click "Save Changes" to apply your configuration updates.
                Changes are not automatically saved.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default SystemSettings;
