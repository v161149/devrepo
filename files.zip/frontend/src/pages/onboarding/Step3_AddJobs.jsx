/**
 * Step 3: Add Jobs (Optional)
 * 
 * UPDATED: Added log monitoring configuration fields
 * - Job Identifier
 * - Log Server Type (dropdown)
 * - Log Template (JSON editor with presets)
 */

import React, { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiSave, FiX, FiAlertCircle } from 'react-icons/fi';
import Button from '../../components/Button';

const JOB_TYPES = [
  { id: 'monitoring', name: 'Monitoring' },
  { id: 'backup', name: 'Backup' },
  { id: 'maintenance', name: 'Maintenance' },
  { id: 'deployment', name: 'Deployment' },
  { id: 'health_check', name: 'Health Check' },
  { id: 'security_scan', name: 'Security Scan' },
  { id: 'log_collection', name: 'Log Collection' },
  { id: 'data_sync', name: 'Data Synchronization' },
  { id: 'other', name: 'Other' }
];

// Log template presets for jobs
const JOB_LOG_TEMPLATE_PRESETS = {
  'job_execution': {
    name: 'Job Execution',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      duration_seconds: '{{duration}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track job execution status and timing'
  },
  'data_processing': {
    name: 'Data Processing',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      duration_seconds: '{{duration}}',
      records_processed: '{{records}}',
      records_failed: '{{failed}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track data processing jobs with record counts'
  },
  'scheduled_task': {
    name: 'Scheduled Task',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      scheduled_time: '{{scheduled}}',
      actual_start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      on_time: '{{on_time}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track scheduled tasks and on-time execution'
  },
  'custom': {
    name: 'Custom Template',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Start with a minimal template and customize'
  }
};

const JobCard = ({ job, asset, services, onEdit, onDelete }) => {
  const getParentName = () => {
    if (job.parent_type === 'asset') {
      return `Asset: ${asset.asset_name}`;
    } else if (job.parent_type === 'service') {
      const service = services.find(s => s.tempId === job.parent_id);
      return service ? `Service: ${service.service_name}` : 'Unknown Service';
    }
    return 'Unknown';
  };

  return (
    <div className="border border-gray-200 rounded-lg p-4 bg-white hover:border-primary-300 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900">{job.job_name}</h4>
          <p className="text-sm text-gray-600 mt-1">
            {JOB_TYPES.find(t => t.id === job.job_type)?.name || job.job_type}
          </p>
          
          <div className="mt-2 text-xs text-gray-500 space-y-1">
            <div className="inline-flex items-center px-2 py-1 bg-gray-100 rounded">
              {getParentName()}
            </div>
            {job.job_identifier && (
              <div className="mt-1">
                ID: <span className="font-mono font-medium">{job.job_identifier}</span>
              </div>
            )}
            {job.log_server_type && (
              <div>
                Log: <span className="font-medium">{job.log_server_type}</span>
              </div>
            )}
          </div>
          
          {job.schedule && (
            <p className="text-xs text-gray-500 mt-2">
              Schedule: <code className="bg-gray-100 px-1 py-0.5 rounded">{job.schedule}</code>
            </p>
          )}
          
          {job.description && (
            <p className="text-sm text-gray-500 mt-2">{job.description}</p>
          )}
        </div>

        <div className="flex items-center space-x-2 ml-4">
          <button
            onClick={() => onEdit(job.tempId)}
            className="p-2 text-gray-600 hover:text-primary-600 hover:bg-primary-50 rounded transition-colors"
            title="Edit job"
          >
            <FiEdit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(job.tempId)}
            className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
            title="Delete job"
          >
            <FiTrash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

const JobForm = ({ job, asset, services, onUpdate, onSave, onCancel, errors = {}, logConnectors = [] }) => {
  const [showLogConfig, setShowLogConfig] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState('');

  // Auto-expand log config if any log fields are filled
  useEffect(() => {
    if (job.job_identifier || job.log_server_type || job.log_template) {
      setShowLogConfig(true);
    }
  }, [job.job_identifier, job.log_server_type, job.log_template]);

  const handlePresetLoad = (presetKey) => {
    if (presetKey && JOB_LOG_TEMPLATE_PRESETS[presetKey]) {
      const preset = JOB_LOG_TEMPLATE_PRESETS[presetKey];
      onUpdate('log_template', JSON.stringify(preset.template, null, 2));
      setSelectedPreset(presetKey);
    }
  };

  const validateLogTemplate = (template) => {
    if (!template) return true;
    try {
      JSON.parse(template);
      return true;
    } catch (e) {
      return false;
    }
  };

  return (
    <div className="border border-primary-200 rounded-lg p-6 bg-primary-50">
      <h4 className="font-semibold text-gray-900 mb-4">
        {job.job_name ? 'Edit Job' : 'New Job'}
      </h4>

      <div className="space-y-4">
        {/* Basic Information */}
        <div className="grid grid-cols-2 gap-4">
          {/* Job Name */}
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Job Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={job.job_name}
              onChange={(e) => onUpdate('job_name', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.job_name ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
              placeholder="e.g., Daily Database Backup"
            />
            {errors.job_name && (
              <p className="text-sm text-red-600 mt-1">{errors.job_name}</p>
            )}
          </div>

          {/* Job Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Job Type <span className="text-red-500">*</span>
            </label>
            <select
              value={job.job_type}
              onChange={(e) => onUpdate('job_type', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.job_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
            >
              <option value="">Select type...</option>
              {JOB_TYPES.map(type => (
                <option key={type.id} value={type.id}>{type.name}</option>
              ))}
            </select>
            {errors.job_type && (
              <p className="text-sm text-red-600 mt-1">{errors.job_type}</p>
            )}
          </div>

          {/* Parent Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Link To <span className="text-red-500">*</span>
            </label>
            <select
              value={job.parent_type}
              onChange={(e) => {
                onUpdate('parent_type', e.target.value);
                onUpdate('parent_id', ''); // Reset parent_id when type changes
              }}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.parent_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
            >
              <option value="">Select...</option>
              <option value="asset">Asset</option>
              <option value="service">Service</option>
            </select>
            {errors.parent_type && (
              <p className="text-sm text-red-600 mt-1">{errors.parent_type}</p>
            )}
          </div>

          {/* Parent Selection */}
          {job.parent_type === 'service' && (
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Service <span className="text-red-500">*</span>
              </label>
              <select
                value={job.parent_id}
                onChange={(e) => onUpdate('parent_id', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                  errors.parent_id ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
              >
                <option value="">Select service...</option>
                {services.map(service => (
                  <option key={service.tempId} value={service.tempId}>
                    {service.service_name}
                  </option>
                ))}
              </select>
              {errors.parent_id && (
                <p className="text-sm text-red-600 mt-1">{errors.parent_id}</p>
              )}
            </div>
          )}

          {/* Schedule */}
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Schedule (Cron Expression)
            </label>
            <input
              type="text"
              value={job.schedule || ''}
              onChange={(e) => onUpdate('schedule', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
              placeholder="e.g., 0 2 * * * (Daily at 2:00 AM)"
            />
            <p className="text-xs text-gray-500 mt-1">
              Optional: Use cron format (minute hour day month weekday)
            </p>
          </div>
          {/* Expected Duration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Expected Duration (minutes)
              <span className="text-gray-500 ml-1">(Optional)</span>
            </label>
            <input
              type="number"
              value={job.expected_duration ? Math.floor(job.expected_duration / 60) : ''}
              onChange={(e) => {
                const minutes = parseInt(e.target.value) || 0;
                onUpdate('expected_duration', minutes * 60); // Convert to seconds
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="e.g., 45"
            />
            <p className="text-xs text-gray-500 mt-1">
              How long this job is expected to take (used for Execution Window SLA)
            </p>
          </div>
          {/* Description */}
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={job.description || ''}
              onChange={(e) => onUpdate('description', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              rows={2}
              placeholder="Optional description..."
            />
          </div>
        </div>

        {/* Log Monitoring Configuration - Collapsible Section */}
        <div className="border-t border-gray-200 pt-4">
          <button
            type="button"
            onClick={() => setShowLogConfig(!showLogConfig)}
            className="flex items-center justify-between w-full text-left mb-3"
          >
            <span className="text-sm font-medium text-gray-700">
              {showLogConfig ? '▼' : '▶'} Log Monitoring Configuration (Optional)
            </span>
          </button>

          {showLogConfig && (
            <div className="space-y-4 pl-4 border-l-2 border-primary-200">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                <div className="flex items-start gap-2">
                  <FiAlertCircle className="text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-blue-800">
                    Configure log-based monitoring for this job. First, set up log server connectors in <strong>Tools → Log Server Setup</strong>.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Job Identifier */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Job Identifier
                  </label>
                  <input
                    type="text"
                    value={job.job_identifier || ''}
                    onChange={(e) => onUpdate('job_identifier', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm ${
                      errors.job_identifier ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    placeholder="e.g., ETL-DAILY-001"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Unique identifier used in log entries
                  </p>
                  {errors.job_identifier && (
                    <p className="text-sm text-red-600 mt-1">{errors.job_identifier}</p>
                  )}
                </div>

                {/* Log Server Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Log Server Type
                  </label>
                  <select
                    value={job.log_server_type || ''}
                    onChange={(e) => onUpdate('log_server_type', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                      errors.log_server_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                  >
                    <option value="">Select log server...</option>
                    {logConnectors.length === 0 ? (
                      <option value="" disabled>No log servers configured</option>
                    ) : (
                      logConnectors
                        .filter(c => c.is_active)
                        .map(connector => (
                          <option key={connector.connector_id} value={connector.log_server_type}>
                            {connector.connector_name} ({connector.log_server_type})
                          </option>
                        ))
                    )}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">
                    Select the log server where this job sends logs
                  </p>
                  {errors.log_server_type && (
                    <p className="text-sm text-red-600 mt-1">{errors.log_server_type}</p>
                  )}
                </div>

                {/* Log Template */}
                <div className="col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-sm font-medium text-gray-700">
                      Log Entry Template
                    </label>
                    <div className="flex items-center gap-2">
                      <select
                        value={selectedPreset}
                        onChange={(e) => handlePresetLoad(e.target.value)}
                        className="text-xs px-2 py-1 border border-gray-300 rounded"
                      >
                        <option value="">Load Preset...</option>
                        {Object.entries(JOB_LOG_TEMPLATE_PRESETS).map(([key, preset]) => (
                          <option key={key} value={key}>{preset.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <textarea
                    value={job.log_template || ''}
                    onChange={(e) => onUpdate('log_template', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm ${
                      errors.log_template ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    rows={10}
                    placeholder='{\n  "identifier": "{{job_identifier}}",\n  "status": "{{status}}",\n  "start_time": "{{start_time}}",\n  "end_time": "{{end_time}}",\n  "timestamp": "{{timestamp}}"\n}'
                  />
                  {job.log_template && !validateLogTemplate(job.log_template) && (
                    <p className="text-sm text-red-600 mt-1">Invalid JSON format</p>
                  )}
                  {errors.log_template && (
                    <p className="text-sm text-red-600 mt-1">{errors.log_template}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    This template must match the format your job uses in log entries
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Form Actions */}
      <div className="flex items-center justify-end space-x-3 mt-6">
        <Button variant="secondary" onClick={onCancel}>
          <FiX className="mr-2" />
          Cancel
        </Button>
        <Button onClick={onSave}>
          <FiSave className="mr-2" />
          Save Job
        </Button>
      </div>
    </div>
  );
};

const Step3_AddJobs = ({
  asset,
  services,
  jobs,
  onAddJob,
  onUpdateJob,
  onRemoveJob
}) => {
  const [editingId, setEditingId] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [logConnectors, setLogConnectors] = useState([]);

  // Fetch log connectors on mount
  useEffect(() => {
    fetchLogConnectors();
  }, []);

  const fetchLogConnectors = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setLogConnectors(data.data || []);
      }
    } catch (error) {
      console.error('Error fetching log connectors:', error);
      setLogConnectors([]);
    }
  };

  const handleAddNew = () => {
    const tempId = onAddJob();
    setEditingId(tempId);
  };

  const handleEdit = (tempId) => {
    setEditingId(tempId);
  };

  const validateJob = (job) => {
    const errors = {};

    if (!job.job_name || job.job_name.trim() === '') {
      errors.job_name = 'Job name is required';
    }

    if (!job.job_type || job.job_type.trim() === '') {
      errors.job_type = 'Job type is required';
    }

    if (!job.parent_type) {
      errors.parent_type = 'Please select what this job is linked to';
    }

    if (job.parent_type === 'service' && !job.parent_id) {
      errors.parent_id = 'Please select a service';
    }

    // Validate log configuration if any log field is filled
    const hasLogConfig = job.job_identifier || job.log_server_type || job.log_template;
    
    if (hasLogConfig) {
      if (!job.job_identifier || job.job_identifier.trim() === '') {
        errors.job_identifier = 'Job identifier is required when using log monitoring';
      }
      
      if (!job.log_server_type) {
        errors.log_server_type = 'Log server type is required when using log monitoring';
      }
      
      if (!job.log_template || job.log_template.trim() === '') {
        errors.log_template = 'Log template is required when using log monitoring';
      } else {
        try {
          JSON.parse(job.log_template);
        } catch (e) {
          errors.log_template = 'Invalid JSON format';
        }
      }
    }

    return errors;
  };

  const handleSave = () => {
    const editingJob = jobs.find(j => j.tempId === editingId);
    const errors = validateJob(editingJob);

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setFormErrors({});
    setEditingId(null);
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormErrors({});
  };

  const handleDelete = (tempId) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      onRemoveJob(tempId);
      if (editingId === tempId) {
        setEditingId(null);
        setFormErrors({});
      }
    }
  };

  const handleUpdate = (tempId, field, value) => {
    onUpdateJob(tempId, { [field]: value });
  };

  const editingJob = jobs.find(j => j.tempId === editingId);
  const displayedJobs = jobs.filter(j => j.tempId !== editingId);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Add Jobs (Optional)</h2>
        <p className="text-gray-600 mt-2">
          Add jobs that run on this asset or its services. You can skip this step and add jobs later.
        </p>
      </div>

      {/* Existing Jobs */}
      {displayedJobs.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900">Jobs ({displayedJobs.length})</h3>
          {displayedJobs.map(job => (
            <JobCard
              key={job.tempId}
              job={job}
              asset={asset}
              services={services}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {/* Editing Form */}
      {editingJob && (
        <JobForm
          job={editingJob}
          asset={asset}
          services={services}
          onUpdate={(field, value) => handleUpdate(editingId, field, value)}
          onSave={handleSave}
          onCancel={handleCancel}
          errors={formErrors}
          logConnectors={logConnectors}
        />
      )}

      {/* Add New Button */}
      {!editingId && (
        <Button onClick={handleAddNew} variant="outline">
          <FiPlus className="mr-2" />
          Add Job
        </Button>
      )}
    </div>
  );
};

export default Step3_AddJobs;
