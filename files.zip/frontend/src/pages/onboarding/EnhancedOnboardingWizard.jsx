/**
 * Enhanced Onboarding Wizard Component - FIXED VERSION
 * 
 * Fixed: API call to use fetch instead of apiService.post
 */

import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiCheck, FiChevronRight, FiChevronLeft } from 'react-icons/fi';
import Card from '../../components/Card';
import Button from '../../components/Button';

// Import step components
import Step1_CreateAsset from './Step1_CreateAsset';
import Step2_AddServices from './Step2_AddServices';
import Step3_AddJobs from './Step3_AddJobs';
import Step4_DefineSLAs from './Step4_DefineSLAs';
import Step5_ReviewComplete from './Step5_ReviewComplete';

const STEPS = [
  { number: 1, title: 'Create Asset', required: true },
  { number: 2, title: 'Add Services', required: false },
  { number: 3, title: 'Add Jobs', required: false },
  { number: 4, title: 'Define SLAs', required: false },
  { number: 5, title: 'Review & Complete', required: true }
];

const EnhancedOnboardingWizard = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  // Helper to get today's date in MM/DD/YYYY format
  const getTodayFormatted = () => {
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const year = today.getFullYear();
    return `${month}/${day}/${year}`;
  };

  // Wizard state
  const [wizardState, setWizardState] = useState({
    currentStep: 1,
    
    // Step 1: Asset (required)
    asset: {
      asset_name: '',
      asset_type: 'Server',
      asset_owner: '',
      description: '',
      onboarded_date: getTodayFormatted(),
      status: 'active'
    },

    // Step 2: Services (optional, multiple)
    services: [],

    // Step 3: Jobs (optional, multiple)
    jobs: [],

    // Step 4: SLAs (optional, multiple)
    slas: [],

    // Validation errors
    errors: {
      asset: {},
      services: [],
      jobs: [],
      slas: []
    }
  });

  // ============================================================================
  // ASSET ACTIONS
  // ============================================================================

  const updateAsset = useCallback((field, value) => {
    setWizardState(prev => ({
      ...prev,
      asset: {
        ...prev.asset,
        [field]: value
      }
    }));
  }, []);

  const validateAsset = useCallback(() => {
    const errors = {};
    const { asset } = wizardState;

    if (!asset.asset_name || asset.asset_name.trim() === '') {
      errors.asset_name = 'Asset name is required';
    }

    if (!asset.asset_type || asset.asset_type.trim() === '') {
      errors.asset_type = 'Asset type is required';
    }

    if (!asset.asset_owner || asset.asset_owner.trim() === '') {
      errors.asset_owner = 'Asset owner is required';
    }

    if (!asset.onboarded_date) {
      errors.onboarded_date = 'Onboarded date is required';
    }

    setWizardState(prev => ({
      ...prev,
      errors: {
        ...prev.errors,
        asset: errors
      }
    }));

    return Object.keys(errors).length === 0;
  }, [wizardState]);

  // ============================================================================
  // SERVICE ACTIONS
  // ============================================================================

  const addService = useCallback(() => {
    const newService = {
      tempId: `svc-temp-${Date.now()}`,
      service_name: '',
      service_type: '',
      description: '',
      status: 'active'
    };

    setWizardState(prev => ({
      ...prev,
      services: [...prev.services, newService]
    }));

    return newService.tempId;
  }, []);

  const updateService = useCallback((tempId, fieldOrUpdates, value) => {
    setWizardState(prev => ({
      ...prev,
      services: prev.services.map(svc => {
        if (svc.tempId !== tempId) return svc;
        // Handle both: updateService(tempId, field, value) and updateService(tempId, {field: value})
        return typeof fieldOrUpdates === 'object' 
          ? { ...svc, ...fieldOrUpdates } 
          : { ...svc, [fieldOrUpdates]: value };
      })
    }));
  }, []);

  const removeService = useCallback((tempId) => {
    setWizardState(prev => ({
      ...prev,
      services: prev.services.filter(svc => svc.tempId !== tempId),
      // Also remove jobs/SLAs linked to this service
      jobs: prev.jobs.filter(job =>
        !(job.parent_type === 'service' && job.parent_id === tempId)
      ),
      slas: prev.slas.filter(sla =>
        !(sla.target_type === 'service' && sla.target_id === tempId)
      )
    }));
  }, []);

  // ============================================================================
  // JOB ACTIONS
  // ============================================================================

  const addJob = useCallback((parentType = 'asset', parentId = null) => {
    const newJob = {
      tempId: `job-temp-${Date.now()}`,
      job_name: '',
      job_type: '',
      parent_type: parentType,
      parent_id: parentId,
      schedule: '',
      description: ''
    };

    setWizardState(prev => ({
      ...prev,
      jobs: [...prev.jobs, newJob]
    }));

    return newJob.tempId;
  }, []);

  const updateJob = useCallback((tempId, fieldOrUpdates, value) => {
    setWizardState(prev => ({
      ...prev,
      jobs: prev.jobs.map(job => {
        if (job.tempId !== tempId) return job;
        // Handle both: updateJob(tempId, field, value) and updateJob(tempId, {field: value})
        return typeof fieldOrUpdates === 'object' 
          ? { ...job, ...fieldOrUpdates } 
          : { ...job, [fieldOrUpdates]: value };
      })
    }));
  }, []);

  const removeJob = useCallback((tempId) => {
    setWizardState(prev => ({
      ...prev,
      jobs: prev.jobs.filter(job => job.tempId !== tempId),
      // Also remove SLAs linked to this job
      slas: prev.slas.filter(sla =>
        !(sla.target_type === 'job' && sla.target_id === tempId)
      )
    }));
  }, []);

  // ============================================================================
  // SLA ACTIONS
  // ============================================================================

  const addSLA = useCallback((targetType, targetId) => {
    const newSLA = {
      tempId: `sla-temp-${Date.now()}`,
      sla_name: '',
      sla_type: '',
      target_type: targetType,
      target_id: targetId,
      target_value: 99.9,
      threshold_warning: 95.0,
      threshold_critical: 90.0,
      measurement_period: 'monthly'
    };

    setWizardState(prev => ({
      ...prev,
      slas: [...prev.slas, newSLA]
    }));

    return newSLA.tempId;
  }, []);

  const updateSLA = useCallback((tempId, fieldOrUpdates, value) => {
    setWizardState(prev => ({
      ...prev,
      slas: prev.slas.map(sla => {
        if (sla.tempId !== tempId) return sla;
        // Handle both: updateSLA(tempId, field, value) and updateSLA(tempId, {field: value})
        return typeof fieldOrUpdates === 'object' 
          ? { ...sla, ...fieldOrUpdates } 
          : { ...sla, [fieldOrUpdates]: value };
      })
    }));
  }, []);

  const removeSLA = useCallback((tempId) => {
    setWizardState(prev => ({
      ...prev,
      slas: prev.slas.filter(sla => sla.tempId !== tempId)
    }));
  }, []);

  // ============================================================================
  // NAVIGATION
  // ============================================================================

  const canProceed = useCallback((step) => {
    switch (step) {
      case 1: // Asset - required
        return validateAsset();
      case 2: // Services - optional
      case 3: // Jobs - optional
      case 4: // SLAs - optional
        return true;
      default:
        return false;
    }
  }, [validateAsset]);

  const nextStep = useCallback(() => {
    if (canProceed(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 5));
    }
  }, [currentStep, canProceed]);

  const previousStep = useCallback(() => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  }, []);

  const skipStep = useCallback(() => {
    // Only steps 2, 3, 4 can be skipped
    if (currentStep >= 2 && currentStep <= 4) {
      nextStep();
    }
  }, [currentStep, nextStep]);

  // ============================================================================
  // SUBMIT
  // ============================================================================

  const prepareJobsForBackend = (jobs, services) => {
    return jobs.map(job => {
      let parent_index = null;

      // Determine parent index
      if (job.parent_type === 'service' && job.parent_id) {
        parent_index = services.findIndex(
          s => s.tempId === job.parent_id || s.service_id === job.parent_id
        );
        if (parent_index === -1) {
          console.warn(`Could not find service for job: ${job.job_name}`);
          parent_index = 0; // Fallback
        }
      }
      // If parent_type is 'asset', parent_index stays null (backend uses asset_id directly)

      return {
        ...job,
        parent_index,
        job_name: job.job_name,
        job_type: job.job_type || 'batch'
      };
    });
  };

  const prepareSLAsForBackend = (slas, services, jobs) => {
    return slas.map(sla => {
      let target_type = null;
      let target_index = null;

      // Determine target type and find index in array
      if (sla.service_id) {
        target_type = 'service';
        target_index = services.findIndex(
          s => s.tempId === sla.service_id || s.service_id === sla.service_id
        );
      } else if (sla.job_id) {
        target_type = 'job';
        target_index = jobs.findIndex(
          j => j.tempId === sla.job_id || j.job_id === sla.job_id
        );
      }

      // Warn if target not found
      if (target_index === -1) {
        console.warn(`Could not find target for SLA: ${sla.name}`);
        target_index = 0; // Fallback to first item
      }

      return {
        ...sla,
        // Backend required fields
        target_type,
        target_index,
        sla_type: sla.metric_type || sla.sla_type,
        sla_name: sla.name || sla.sla_name,
        // Preserve field mapping
        log_field_mapping: sla.log_field_mapping 
          ? (typeof sla.log_field_mapping === 'string' 
            ? sla.log_field_mapping 
            : JSON.stringify(sla.log_field_mapping))
          : null
      };
    });
  };

  const handleComplete = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      // Transform Jobs to backend format
      const preparedJobs = prepareJobsForBackend(
        wizardState.jobs,
        wizardState.services
      );

      // Transform SLAs to backend format
      const preparedSLAs = prepareSLAsForBackend(
        wizardState.slas,
        wizardState.services,
        wizardState.jobs
      );

      // Log for debugging
      console.log('Prepared Jobs for backend:', preparedJobs);
      console.log('Prepared SLAs for backend:', preparedSLAs);

      const payload = {
        asset: wizardState.asset,
        services: wizardState.services,
        jobs: preparedJobs,    // Use prepared Jobs
        slas: preparedSLAs     // Use prepared SLAs
      };

      console.log('Submitting onboarding data:', payload);

      // Get auth token
      const token = localStorage.getItem('token');
      
      const response = await fetch('/api/v1/onboarding/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to complete onboarding');
      }

      const result = await response.json();
      console.log('Onboarding completed successfully:', result);

      // Navigate to asset details page
      navigate(`/assets/${result.data.asset.asset_id}`);

    } catch (err) {
      console.error('Onboarding error:', err);
      setSubmitError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };  


  // ============================================================================
  // RENDER
  // ============================================================================

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <Step1_CreateAsset
            asset={wizardState.asset}
            errors={wizardState.errors.asset}
            onUpdate={updateAsset}
          />
        );

      case 2:
        return (
          <Step2_AddServices
            services={wizardState.services}
            onAddService={addService}
            onUpdateService={updateService}
            onRemoveService={removeService}
          />
        );

      case 3:
        return (
          <Step3_AddJobs
            asset={wizardState.asset}
            services={wizardState.services}
            jobs={wizardState.jobs}
            onAddJob={addJob}
            onUpdateJob={updateJob}
            onRemoveJob={removeJob}
          />
        );

      case 4:
        return (
          <Step4_DefineSLAs
            services={wizardState.services}
            jobs={wizardState.jobs}
            slas={wizardState.slas}
            onAddSLA={addSLA}
            onUpdateSLA={updateSLA}
            onRemoveSLA={removeSLA}
          />
        );

      case 5:
        return (
          <Step5_ReviewComplete
            wizardState={wizardState}
            onComplete={handleComplete}
            isSubmitting={isSubmitting}
            error={submitError}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Onboarding Wizard
          </h1>
          <p className="text-gray-600">
            Create your asset and optionally add services, jobs, and SLAs
          </p>
        </div>

        {/* Progress Indicator */}
        <Card className="mb-6">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => (
              <React.Fragment key={step.number}>
                <div className="flex items-center">
                  <div
                    className={`
                      w-10 h-10 rounded-full flex items-center justify-center font-semibold
                      ${currentStep > step.number
                        ? 'bg-green-500 text-white'
                        : currentStep === step.number
                          ? 'bg-primary-500 text-white'
                          : 'bg-gray-200 text-gray-600'
                      }
                    `}
                  >
                    {currentStep > step.number ? (
                      <FiCheck className="w-5 h-5" />
                    ) : (
                      step.number
                    )}
                  </div>
                  <div className="ml-3">
                    <div className="text-sm font-medium text-gray-900">
                      {step.title}
                    </div>
                    {!step.required && (
                      <div className="text-xs text-gray-500">Optional</div>
                    )}
                  </div>
                </div>

                {index < STEPS.length - 1 && (
                  <div className="flex-1 mx-4">
                    <div
                      className={`h-1 rounded ${currentStep > step.number
                        ? 'bg-green-500'
                        : 'bg-gray-200'
                        }`}
                    />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        </Card>

        {/* Step Content */}
        <Card className="mb-6">
          {renderStepContent()}
        </Card>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between">
          <div>
            {currentStep > 1 && (
              <Button
                variant="secondary"
                onClick={previousStep}
                disabled={isSubmitting}
              >
                <FiChevronLeft className="mr-2" />
                Back
              </Button>
            )}
          </div>

          <div className="flex items-center space-x-3">
            {/* Skip button for optional steps */}
            {currentStep >= 2 && currentStep <= 4 && (
              <Button
                variant="outline"
                onClick={skipStep}
                disabled={isSubmitting}
              >
                Skip
              </Button>
            )}

            {/* Next/Complete button */}
            {currentStep < 5 ? (
              <Button
                onClick={nextStep}
                disabled={isSubmitting}
              >
                Next
                <FiChevronRight className="ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleComplete}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Completing...' : 'Complete Setup'}
              </Button>
            )}
          </div>
        </div>

        {/* Summary Info */}
        <div className="mt-6 text-center text-sm text-gray-600">
          <div className="flex items-center justify-center space-x-6">
            <div>
              <span className="font-semibold">{wizardState.services.length}</span> Services
            </div>
            <div>•</div>
            <div>
              <span className="font-semibold">{wizardState.jobs.length}</span> Jobs
            </div>
            <div>•</div>
            <div>
              <span className="font-semibold">{wizardState.slas.length}</span> SLAs
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedOnboardingWizard;
