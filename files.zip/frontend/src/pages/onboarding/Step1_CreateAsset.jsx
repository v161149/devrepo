/**
 * Step 1: Create Asset (Required)
 * 
 * Basic asset information form
 */

import React from 'react';

const ASSET_TYPES = [
  { id: 'Server', name: 'Server' },
  { id: 'Database Server', name: 'Database Server' },
  { id: 'Application Server', name: 'Application Server' },
  { id: 'Web Server', name: 'Web Server' },
  { id: 'Storage', name: 'Storage' },
  { id: 'Network Device', name: 'Network Device' },
  { id: 'Virtual Machine', name: 'Virtual Machine' },
  { id: 'Container', name: 'Container' },
  { id: 'Cloud Resource', name: 'Cloud Resource' },
  { id: 'Other', name: 'Other' }
];

const Step1_CreateAsset = ({ asset, errors, onUpdate }) => {
  // Helper to convert MM/DD/YYYY to YYYY-MM-DD for date input
  const dateToInputValue = (dateStr) => {
    if (!dateStr) return '';
    
    // If in MM/DD/YYYY format
    if (/^\d{2}\/\d{2}\/\d{4}/.test(dateStr)) {
      const [month, day, year] = dateStr.split('/');
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    
    // If already in YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}/.test(dateStr)) {
      return dateStr.split('T')[0];
    }
    
    return '';
  };

  // Helper to convert YYYY-MM-DD to MM/DD/YYYY for storage
  const inputValueToDate = (inputValue) => {
    if (!inputValue) return '';
    
    const [year, month, day] = inputValue.split('-');
    return `${month}/${day}/${year}`;
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Create Asset</h2>
        <p className="text-sm text-gray-600 mt-1">
          Enter the basic information for your asset. This is the only required step.
        </p>
      </div>

      <div className="space-y-6">
        {/* Asset Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Asset Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={asset.asset_name}
            onChange={(e) => onUpdate('asset_name', e.target.value)}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
              errors.asset_name ? 'border-red-300 bg-red-50' : 'border-gray-300'
            }`}
            placeholder="e.g., Production Web Server"
          />
          {errors.asset_name && (
            <p className="text-sm text-red-600 mt-1">{errors.asset_name}</p>
          )}
        </div>

        {/* Asset Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Asset Type <span className="text-red-500">*</span>
          </label>
          <select
            value={asset.asset_type}
            onChange={(e) => onUpdate('asset_type', e.target.value)}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
              errors.asset_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
            }`}
          >
            {ASSET_TYPES.map(type => (
              <option key={type.id} value={type.id}>{type.name}</option>
            ))}
          </select>
          {errors.asset_type && (
            <p className="text-sm text-red-600 mt-1">{errors.asset_type}</p>
          )}
        </div>

        {/* Asset Owner */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Asset Owner <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={asset.asset_owner}
            onChange={(e) => onUpdate('asset_owner', e.target.value)}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
              errors.asset_owner ? 'border-red-300 bg-red-50' : 'border-gray-300'
            }`}
            placeholder="e.g., IT Operations Team"
          />
          {errors.asset_owner && (
            <p className="text-sm text-red-600 mt-1">{errors.asset_owner}</p>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            value={asset.description}
            onChange={(e) => onUpdate('description', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            rows={3}
            placeholder="Optional description of the asset..."
          />
        </div>

        {/* Onboarded Date */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Onboarded Date <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <input
              type="date"
              value={dateToInputValue(asset.onboarded_date)}
              onChange={(e) => onUpdate('onboarded_date', inputValueToDate(e.target.value))}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 pr-10 ${
                errors.onboarded_date ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
              📅
            </div>
          </div>
          {errors.onboarded_date && (
            <p className="text-sm text-red-600 mt-1">{errors.onboarded_date}</p>
          )}
        </div>

        {/* Status */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </label>
          <select
            value={asset.status}
            onChange={(e) => onUpdate('status', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="decommissioned">Decommissioned</option>
          </select>
        </div>
      </div>

      {/* Info Box */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start">
          <div className="text-blue-500 mt-0.5">ℹ️</div>
          <div className="ml-3 text-sm text-blue-800">
            <p className="font-medium">Next Steps (Optional)</p>
            <p className="mt-1">
              After creating your asset, you can optionally add services, jobs, and SLAs. 
              You can also skip these steps and add them later.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Step1_CreateAsset;
