/**
 * BulkStep1_SelectAssetConnector.jsx
 * 
 * Step 1 of Bulk Onboarding Wizard
 * - Lists available asset connectors
 * - Shows empty state if no connectors
 * - Allows user to select and import data from connector
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiServer, FiAlertCircle, FiSettings, FiUpload, FiCheck } from 'react-icons/fi';
import Button from '../../components/Button';
import ConnectorSelector from './shared/ConnectorSelector';

const BulkStep1_SelectAssetConnector = ({
  assets,
  selectedConnector,
  onDataImported
}) => {
  const navigate = useNavigate();
  const [connectors, setConnectors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch available asset connectors
  useEffect(() => {
    fetchAssetConnectors();
  }, []);

  const fetchAssetConnectors = async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        'http://localhost:5000/api/v1/connectors?type=asset',
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch asset connectors');
      }

      const data = await response.json();
      // Backend returns {data: [...]} with type filtering
      setConnectors(data.data || []);
    } catch (err) {
      console.error('Error fetching asset connectors:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleImportData = async (connector) => {
    try {
      const token = localStorage.getItem('token');
      const connectorId = connector.id || connector.connector_id;
      
      console.log('Fetching data from connector:', connectorId);
      
      // Use /fetch endpoint to get data from connector (doesn't import to DB yet)
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}/fetch`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            filters: {} // Optional filters
          })
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to fetch data from connector');
      }

  const result = await response.json();
  console.log('Fetched data:', result);

  // Backend now applies field mappings, use data directly
  const fetchedAssets = result.data || [];

      if (fetchedAssets.length === 0) {
        throw new Error('No data returned from connector');
      }

      // Pass normalized data back to wizard (will be imported in Step 5)
      onDataImported(fetchedAssets, connector);

      return { success: true, count: fetchedAssets.length };
    } catch (err) {
      console.error('Error fetching data:', err);
      throw err;
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading asset connectors...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <div className="flex items-start">
          <FiAlertCircle className="text-red-600 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-red-900 mb-2">Error Loading Connectors</h3>
            <p className="text-red-700 mb-4">{error}</p>
            <Button onClick={fetchAssetConnectors} variant="outline">
              Try Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Empty state - no connectors available
  if (connectors.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-6">
          <FiServer className="w-10 h-10 text-blue-600" />
        </div>

        <h2 className="text-2xl font-semibold text-gray-900 mb-4">
          No Asset Connectors Found
        </h2>

        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          To bulk import assets, you need to create an asset connector first. 
          Asset connectors allow you to import infrastructure data from external systems.
        </p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 max-w-2xl mx-auto">
          <div className="flex items-start">
            <FiSettings className="text-blue-600 mr-3 mt-1 flex-shrink-0" />
            <div className="text-left">
              <h4 className="font-semibold text-gray-900 mb-2">Setup Required</h4>
              <p className="text-sm text-gray-700 mb-3">
                Go to <strong>Tools → Metadata Retrieval</strong> to create and configure 
                an asset connector. You can choose from:
              </p>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• <strong>Custom API</strong> - Connect to your own REST API</li>
                <li>• <strong>Demo Asset Simulator</strong> - Test with sample data</li>
              </ul>
            </div>
          </div>
        </div>

        <Button onClick={() => navigate('/tools/metadata-retrieval')}>
          <FiSettings className="mr-2" />
          Go to Metadata Retrieval
        </Button>
      </div>
    );
  }

  // Main view - show connectors
  return (
    <div className="py-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Step 1: Import Assets
        </h2>
        <p className="text-gray-600">
          Select an asset connector to import infrastructure data. 
          Assets are required to proceed with bulk onboarding.
        </p>
      </div>

      {/* Show success message if data already imported */}
      {assets.length > 0 && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <FiCheck className="text-green-600 mr-3 flex-shrink-0" />
            <div>
              <p className="font-medium text-green-900">
                {assets.length} asset{assets.length !== 1 ? 's' : ''} imported successfully
              </p>
              {selectedConnector && (
                <p className="text-sm text-green-700 mt-1">
                  From: {selectedConnector.connector_name}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Educational Note */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <FiAlertCircle className="text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-900">
            <p className="font-medium mb-1">About Asset Import</p>
            <p>
              Assets represent your infrastructure components (servers, applications, databases, etc.). 
              Services and jobs can be linked to these assets in the following steps.
            </p>
          </div>
        </div>
      </div>

      {/* Connector Selector */}
      <ConnectorSelector
        connectors={connectors}
        selectedConnector={selectedConnector}
        onImportData={handleImportData}
        connectorType="asset"
      />
    </div>
  );
};

export default BulkStep1_SelectAssetConnector;
