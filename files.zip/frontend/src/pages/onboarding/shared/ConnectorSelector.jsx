/**
 * ConnectorSelector.jsx
 * 
 * Reusable component for displaying and selecting connectors
 * Shows connector cards with import button
 */

import React, { useState } from 'react';
import { FiDatabase, FiLoader, FiCheck, FiAlertCircle } from 'react-icons/fi';
import Button from '../../../components/Button';

const ConnectorSelector = ({ 
  connectors, 
  selectedConnector, 
  onImportData, 
  connectorType 
}) => {
  const [importingId, setImportingId] = useState(null);
  const [error, setError] = useState(null);
  const [importedConnectorIds, setImportedConnectorIds] = useState(new Set());

  const handleImport = async (connector) => {
    console.log('ConnectorSelector: handleImport called for connector:', connector);
    setImportingId(connector.id || connector.connector_id);
    setError(null);

    try {
      console.log('ConnectorSelector: Calling onImportData...');
      const result = await onImportData(connector);
      console.log('ConnectorSelector: Import successful:', result);
      
      // Mark this connector as having successfully imported data
      setImportedConnectorIds(prev => new Set([...prev, connector.id || connector.connector_id]));
      
      // Success - parent component handles state update
    } catch (err) {
      console.error('ConnectorSelector: Import error:', err);
      setError(err.message);
      alert(`Error importing data: ${err.message}`);
    } finally {
      setImportingId(null);
    }
  };

  if (!connectors || connectors.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No {connectorType} connectors available
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start">
            <FiAlertCircle className="text-red-600 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-red-900">Import Error</p>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Connector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {connectors.map((connector) => {
          const connectorId = connector.id || connector.connector_id;
          const hasImported = importedConnectorIds.has(connectorId);
          const isImporting = importingId === connectorId;

          return (
            <div
              key={connectorId}
              className={`border rounded-lg p-4 transition-all ${
                hasImported
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 hover:border-primary-300 hover:shadow-md'
              }`}
            >
              {/* Connector Info */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center">
                  <div className="p-2 bg-primary-100 rounded-lg mr-3">
                    <FiDatabase className="text-primary-600" size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {connector.connector_name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {connector.platform}
                    </p>
                    {connector.total_imports > 0 && (
                      <p className="text-xs text-gray-500 mt-1">
                        {connector.total_imports} import{connector.total_imports !== 1 ? 's' : ''}
                      </p>
                    )}
                  </div>
                </div>
                {hasImported && (
                  <div className="flex items-center justify-center w-8 h-8 bg-green-500 rounded-full">
                    <FiCheck className="text-white" size={16} />
                  </div>
                )}
              </div>

              {/* Import Button */}
              <Button
                onClick={() => handleImport(connector)}
                disabled={isImporting || hasImported}
                variant={hasImported ? 'outline' : 'primary'}
                className="w-full"
              >
                {isImporting ? (
                  <>
                    <FiLoader className="mr-2 animate-spin" />
                    Importing...
                  </>
                ) : hasImported ? (
                  <>
                    <FiCheck className="mr-2" />
                    Data Imported
                  </>
                ) : (
                  'Import Data'
                )}
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ConnectorSelector;
