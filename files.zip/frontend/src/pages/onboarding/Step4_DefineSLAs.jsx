/**
 * Step4_DefineSLAs - WITH FIELD MAPPING
 * 
 * Allows users to:
 * 1. Define SLA name, type, target
 * 2. Select which service/job to apply to
 * 3. MAP log template fields to SLA evaluation criteria
 * 4. Configure success/failure conditions
 */

import React, { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiSave, FiX, FiAlertCircle, FiInfo } from 'react-icons/fi';
import Button from '../../components/Button';

// SLA Type definitions with field mapping requirements
const SLA_TYPES = {
  'uptime': {
    name: 'Uptime / Availability',
    description: 'Track service uptime and availability',
    requiredFields: ['status_field'],
    optionalFields: ['success_values', 'failure_values'],
    evaluationType: 'percentage',
    defaultMapping: {
      status_field: 'status',
      success_values: ['up', 'running', 'active', 'healthy', 'ok'],
      failure_values: ['down', 'error', 'failed', 'degraded', 'unhealthy']
    }
  },
  'response_time': {
    name: 'Response Time',
    description: 'Monitor response time performance',
    requiredFields: ['response_time_field'],
    optionalFields: ['threshold_operator'],
    evaluationType: 'threshold',
    defaultMapping: {
      response_time_field: 'response_time_ms',
      threshold_operator: '<=',
      threshold_unit: 'ms'
    }
  },
  'error_rate': {
    name: 'Error Rate',
    description: 'Track error rates and failures',
    requiredFields: ['error_field'],
    optionalFields: ['total_field', 'error_values'],
    evaluationType: 'percentage',
    defaultMapping: {
      error_field: 'error_count',
      total_field: 'total_requests',
      error_values: ['error', 'failed', 'exception']
    }
  },
  'success_rate': {
    name: 'Success Rate',
    description: 'Monitor successful operations',
    requiredFields: ['status_field'],
    optionalFields: ['success_values'],
    evaluationType: 'percentage',
    defaultMapping: {
      status_field: 'status',
      success_values: ['success', 'completed', 'ok', 'done']
    }
  },
  'throughput': {
    name: 'Throughput',
    description: 'Track processing throughput',
    requiredFields: ['throughput_field'],
    optionalFields: ['threshold_operator'],
    evaluationType: 'threshold',
    defaultMapping: {
      throughput_field: 'records_processed',
      threshold_operator: '>=',
      threshold_unit: 'records'
    }
  },
  'latency': {
    name: 'Latency',
    description: 'Monitor operation latency',
    requiredFields: ['latency_field'],
    optionalFields: ['threshold_operator', 'percentile'],
    evaluationType: 'threshold',
    defaultMapping: {
      latency_field: 'duration_seconds',
      threshold_operator: '<=',
      threshold_unit: 'seconds',
      percentile: 95
    }
  }
,
  'execution_window': {
    name: 'Execution Window',
    description: 'Ensure jobs start and finish within expected time window',
    requiredFields: ['start_time_field', 'end_time_field', 'duration_field'],
    optionalFields: ['start_tolerance_minutes', 'duration_tolerance_percentage'],
    evaluationType: 'window_compliance',
    applicableToJobs: true,
    applicableToServices: false,
    defaultMapping: {
      start_time_field: 'start_time',
      end_time_field: 'end_time',
      duration_field: 'duration_seconds',
      start_tolerance_minutes: 5,
      duration_tolerance_percentage: 10,
      check_no_overlap: true
    }
  }
};

const SLACard = ({ sla, onEdit, onDelete }) => {
  return (
    <div className="border border-gray-200 rounded-lg p-4 bg-white hover:border-primary-300 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900">{sla.name}</h4>
          <p className="text-sm text-gray-600 mt-1">
            {SLA_TYPES[sla.metric_type]?.name || sla.metric_type}
          </p>
          <div className="flex items-center space-x-4 mt-3 text-xs text-gray-500">
            <span>Target: <span className="font-medium text-green-600">{sla.target_value}%</span></span>
            <span>Apply to: <span className="font-medium">{sla.apply_to_name}</span></span>
            {sla.log_field_mapping && (
              <span className="text-blue-600">✓ Field Mapping Configured</span>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-2 ml-4">
          <button
            onClick={() => onEdit(sla.tempId)}
            className="p-2 text-gray-400 hover:text-primary-600 transition-colors"
            title="Edit"
          >
            <FiEdit2 size={16} />
          </button>
          <button
            onClick={() => onDelete(sla.tempId)}
            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
            title="Delete"
          >
            <FiTrash2 size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

const FieldMappingConfigurator = ({ 
  slaType, 
  selectedEntity, 
  fieldMapping, 
  onUpdateMapping 
}) => {
  const [availableFields, setAvailableFields] = useState([]);
  const [showHelp, setShowHelp] = useState(true);

  useEffect(() => {
    if (selectedEntity && selectedEntity.log_template) {
      extractFieldsFromTemplate(selectedEntity.log_template);
    }
  }, [selectedEntity]);

  const extractFieldsFromTemplate = (template) => {
    try {
      const templateObj = typeof template === 'string' ? JSON.parse(template) : template;
      const fields = Object.keys(templateObj).filter(key => 
        !['timestamp'].includes(key) // Exclude timestamp from field options
      );
      setAvailableFields(fields);
    } catch (e) {
      console.error('Error parsing log template:', e);
      setAvailableFields([]);
    }
  };

  if (!slaType || !SLA_TYPES[slaType]) {
    return null;
  }

  const slaConfig = SLA_TYPES[slaType];

  const renderFieldSelector = (fieldKey, label, helpText) => {
    return (
      <div key={fieldKey} className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label} <span className="text-red-500">*</span>
        </label>
        <select
          value={fieldMapping?.[fieldKey] || ''}
          onChange={(e) => onUpdateMapping({ ...fieldMapping, [fieldKey]: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        >
          <option value="">Select field from log template...</option>
          {availableFields.map(field => (
            <option key={field} value={field}>{field}</option>
          ))}
        </select>
        {helpText && (
          <p className="text-xs text-gray-500 mt-1">{helpText}</p>
        )}
      </div>
    );
  };

  const renderValuesList = (fieldKey, label, placeholder, helpText) => {
    const values = fieldMapping?.[fieldKey] || [];
    const valuesString = Array.isArray(values) ? values.join(', ') : values;

    return (
      <div key={fieldKey} className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
        <input
          type="text"
          value={valuesString}
          onChange={(e) => {
            const newValues = e.target.value.split(',').map(v => v.trim()).filter(Boolean);
            onUpdateMapping({ ...fieldMapping, [fieldKey]: newValues });
          }}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          placeholder={placeholder}
        />
        {helpText && (
          <p className="text-xs text-gray-500 mt-1">{helpText}</p>
        )}
      </div>
    );
  };

  const renderThresholdOperator = () => {
    return (
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Threshold Operator
        </label>
        <select
          value={fieldMapping?.threshold_operator || '<='}
          onChange={(e) => onUpdateMapping({ ...fieldMapping, threshold_operator: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        >
          <option value="<=">&lt;= (Less than or equal)</option>
          <option value=">=">&gt;= (Greater than or equal)</option>
          <option value="<">&lt; (Less than)</option>
          <option value=">">&gt; (Greater than)</option>
          <option value="=">=  (Equal to)</option>
        </select>
        <p className="text-xs text-gray-500 mt-1">
          How to compare measured value against target
        </p>
      </div>
    );
  };

  return (
    <div className="border-t border-gray-200 pt-4 mt-4">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-semibold text-gray-900">Field Mapping Configuration</h4>
        <button
          onClick={() => setShowHelp(!showHelp)}
          className="text-sm text-primary-600 hover:text-primary-800"
        >
          <FiInfo className="inline mr-1" />
          {showHelp ? 'Hide' : 'Show'} Help
        </button>
      </div>

      {showHelp && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
          <p className="text-sm text-blue-800">
            <FiInfo className="inline mr-1" />
            <strong>Field Mapping</strong>: Map fields from your log template to this SLA's evaluation criteria.
            This tells the system which log fields to use when calculating SLA compliance.
          </p>
        </div>
      )}

      {availableFields.length === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
          <p className="text-sm text-yellow-800">
            <FiAlertCircle className="inline mr-1" />
            No log template found for selected {selectedEntity?.service_id ? 'service' : 'job'}.
            Please configure log monitoring first.
          </p>
        </div>
      )}

      {availableFields.length > 0 && (
        <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
          <div className="text-xs text-gray-600 mb-3">
            <strong>Available log fields:</strong> {availableFields.join(', ')}
          </div>

          {/* Uptime / Availability */}
          {slaType === 'uptime' && (
            <>
              {renderFieldSelector(
                'status_field',
                'Status Field',
                'The log field that contains the service status'
              )}
              {renderValuesList(
                'success_values',
                'Success Values (comma-separated)',
                'e.g., up, running, active, healthy',
                'Values that indicate the service is UP'
              )}
              {renderValuesList(
                'failure_values',
                'Failure Values (comma-separated)',
                'e.g., down, error, failed, degraded',
                'Values that indicate the service is DOWN'
              )}
            </>
          )}

          {/* Response Time */}
          {slaType === 'response_time' && (
            <>
              {renderFieldSelector(
                'response_time_field',
                'Response Time Field',
                'The log field that contains the response time'
              )}
              {renderThresholdOperator()}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Unit
                </label>
                <input
                  type="text"
                  value={fieldMapping?.threshold_unit || 'ms'}
                  onChange={(e) => onUpdateMapping({ ...fieldMapping, threshold_unit: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="e.g., ms, seconds"
                />
              </div>
            </>
          )}

          {/* Error Rate */}
          {slaType === 'error_rate' && (
            <>
              {renderFieldSelector(
                'error_field',
                'Error Count Field',
                'The log field that contains error count or error indicator'
              )}
              {renderFieldSelector(
                'total_field',
                'Total Count Field (optional)',
                'The log field that contains total request count'
              )}
              {renderValuesList(
                'error_values',
                'Error Indicator Values (comma-separated)',
                'e.g., error, failed, exception',
                'Values that indicate an error occurred'
              )}
            </>
          )}

          {/* Success Rate */}
          {slaType === 'success_rate' && (
            <>
              {renderFieldSelector(
                'status_field',
                'Status Field',
                'The log field that contains the operation status'
              )}
              {renderValuesList(
                'success_values',
                'Success Values (comma-separated)',
                'e.g., success, completed, ok, done',
                'Values that indicate successful completion'
              )}
            </>
          )}

          {/* Throughput */}
          {slaType === 'throughput' && (
            <>
              {renderFieldSelector(
                'throughput_field',
                'Throughput Field',
                'The log field that contains the throughput metric'
              )}
              {renderThresholdOperator()}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Unit
                </label>
                <input
                  type="text"
                  value={fieldMapping?.threshold_unit || 'records'}
                  onChange={(e) => onUpdateMapping({ ...fieldMapping, threshold_unit: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="e.g., records, requests, messages"
                />
              </div>
            </>
          )}

          {/* Latency */}
          {slaType === 'latency' && (
            <>
              {renderFieldSelector(
                'latency_field',
                'Latency Field',
                'The log field that contains the latency metric'
              )}
              {renderThresholdOperator()}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Percentile (optional)
                </label>
                <select
                  value={fieldMapping?.percentile || 95}
                  onChange={(e) => onUpdateMapping({ ...fieldMapping, percentile: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                >
                  <option value={50}>50th percentile (median)</option>
                  <option value={90}>90th percentile</option>
                  <option value={95}>95th percentile</option>
                  <option value={99}>99th percentile</option>
                </select>
              </div>
            </>
          )}


          {/* Execution Window */}
          {slaType === 'execution_window' && (
            <>
              {renderFieldSelector(
                'start_time_field',
                'Start Time Field',
                'The log field that contains job start time (ISO 8601 format)'
              )}
              
              {renderFieldSelector(
                'end_time_field',
                'End Time Field',
                'The log field that contains job end time (ISO 8601 format)'
              )}
              
              {renderFieldSelector(
                'duration_field',
                'Duration Field',
                'The log field that contains execution duration in seconds'
              )}
              
              {/* Start Tolerance */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Start Tolerance (minutes)
                </label>
                <input
                  type="number"
                  value={fieldMapping?.start_tolerance_minutes || 5}
                  onChange={(e) => onUpdateMapping({ 
                    ...fieldMapping, 
                    start_tolerance_minutes: parseInt(e.target.value) 
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="5"
                />
                <p className="text-xs text-gray-500 mt-1">
                  How many minutes late can the job start before it's considered non-compliant
                </p>
              </div>
              
              {/* Duration Tolerance */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Duration Tolerance (%)
                </label>
                <input
                  type="number"
                  value={fieldMapping?.duration_tolerance_percentage || 10}
                  onChange={(e) => onUpdateMapping({ 
                    ...fieldMapping, 
                    duration_tolerance_percentage: parseInt(e.target.value) 
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="10"
                />
                <p className="text-xs text-gray-500 mt-1">
                  How much longer (%) than expected duration is acceptable (e.g., 10% = allow 10% over expected time)
                </p>
              </div>
              
              {/* Check for Overlap */}
              <div className="mb-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={fieldMapping?.check_no_overlap !== false}
                    onChange={(e) => onUpdateMapping({ 
                      ...fieldMapping, 
                      check_no_overlap: e.target.checked 
                    })}
                    className="mr-2 h-4 w-4"
                  />
                  <span className="text-sm text-gray-700">
                    Check that job finishes before next scheduled run
                  </span>
                </label>
                <p className="text-xs text-gray-500 mt-1 ml-6">
                  Job must complete before the next execution window begins (prevents overlapping executions)
                </p>
              </div>
              
              {/* Execution Window Preview */}
              <div className="bg-white border border-gray-300 rounded-lg p-3 mt-4 mb-4">
                <div className="text-xs font-semibold text-gray-700 mb-2">
                  Evaluation Logic:
                </div>
                <div className="text-xs text-gray-600 space-y-1">
                  <div className="font-semibold mt-2 text-blue-600">Start Time Check:</div>
                  <div>• Scheduled Start: Based on job_schedule (cron)</div>
                  <div>• Actual Start: From <span className="font-mono text-blue-600">{fieldMapping?.start_time_field || 'start_time'}</span></div>
                  <div>• Start Delay: actual_start - scheduled_start</div>
                  <div>• ✅ Compliant if: delay ≤ {fieldMapping?.start_tolerance_minutes || 5} minutes</div>
                  
                  <div className="font-semibold mt-3 text-blue-600">Duration Check:</div>
                  <div>• Expected Duration: From job.expected_duration</div>
                  <div>• Actual Duration: From <span className="font-mono text-blue-600">{fieldMapping?.duration_field || 'duration_seconds'}</span></div>
                  <div>• Max Allowed: expected × (1 + {fieldMapping?.duration_tolerance_percentage || 10}%)</div>
                  <div>• ✅ Compliant if: actual_duration ≤ max_allowed</div>
                  
                  {fieldMapping?.check_no_overlap !== false && (
                    <>
                      <div className="font-semibold mt-3 text-blue-600">Overlap Check:</div>
                      <div>• Next Scheduled Run: scheduled_start + cron_interval</div>
                      <div>• Actual End: From <span className="font-mono text-blue-600">{fieldMapping?.end_time_field || 'end_time'}</span></div>
                      <div>• ✅ Compliant if: end_time &lt; next_scheduled_start</div>
                    </>
                  )}
                  
                  <div className="font-semibold mt-3 text-green-600">Overall:</div>
                  <div>• Job is compliant if ALL checks pass</div>
                </div>
              </div>
              
              {/* Warning if no expected_duration */}
              {selectedEntity && !selectedEntity.expected_duration && (
                <div className="bg-yellow-50 border border-yellow-300 rounded-lg p-3 mt-4 mb-4">
                  <div className="flex items-start">
                    <FiAlertCircle className="text-yellow-600 mr-2 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-yellow-800">
                      <strong>Warning:</strong> This job does not have an expected_duration configured. 
                      Execution Window SLA requires expected_duration to evaluate compliance. 
                      Please configure expected_duration in Step 3 when adding the job.
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Preview - Only show for non-execution_window SLAs */}
          {slaType !== 'execution_window' && (
            <div className="bg-white border border-gray-300 rounded-lg p-3 mt-4">
              <div className="text-xs font-semibold text-gray-700 mb-2">Evaluation Preview:</div>
              <div className="text-xs text-gray-600 font-mono">
                {slaConfig.evaluationType === 'percentage' && (
                  <div>
                    Compliance% = (Success Count / Total Count) × 100<br/>
                    {fieldMapping?.status_field && (
                      <>Field: <span className="text-blue-600">{fieldMapping.status_field}</span></>
                    )}
                  </div>
                )}
                {slaConfig.evaluationType === 'threshold' && (
                  <div>
                    Measured Value {fieldMapping?.threshold_operator || '<='} Target Value<br/>
                    {fieldMapping?.response_time_field && (
                      <>Field: <span className="text-blue-600">{fieldMapping.response_time_field}</span></>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const SLAForm = ({ 
  sla, 
  services, 
  jobs, 
  onUpdate, 
  onSave, 
  onCancel, 
  errors = {} 
}) => {
  const [applyToType, setApplyToType] = useState(sla.service_id ? 'service' : 'job');
  const [selectedEntity, setSelectedEntity] = useState(null);

  useEffect(() => {
    // Load selected entity to get log template
    if (applyToType === 'service' && sla.service_id) {
      const service = services.find(s => s.tempId === sla.service_id || s.service_id === sla.service_id);
      setSelectedEntity(service);
    } else if (applyToType === 'job' && sla.job_id) {
      const job = jobs.find(j => j.tempId === sla.job_id || j.job_id === sla.job_id);
      setSelectedEntity(job);
    }
  }, [applyToType, sla.service_id, sla.job_id, services, jobs]);

  const handleApplyToTypeChange = (type) => {
    setApplyToType(type);
    onUpdate('service_id', '');
    onUpdate('job_id', '');
    setSelectedEntity(null);
  };

  const handleEntityChange = (entityId) => {
    if (applyToType === 'service') {
      onUpdate('service_id', entityId);
      onUpdate('job_id', '');
      const service = services.find(s => s.tempId === entityId || s.service_id === entityId);
      setSelectedEntity(service);
    } else {
      onUpdate('job_id', entityId);
      onUpdate('service_id', '');
      const job = jobs.find(j => j.tempId === entityId || j.job_id === entityId);
      setSelectedEntity(job);
    }
  };

  const handleMetricTypeChange = (type) => {
    onUpdate('metric_type', type);
    // Set default field mapping for this SLA type
    if (SLA_TYPES[type]) {
      onUpdate('log_field_mapping', JSON.stringify(SLA_TYPES[type].defaultMapping));
    }
  };

  const handleFieldMappingUpdate = (mapping) => {
    onUpdate('log_field_mapping', JSON.stringify(mapping));
  };

  const currentFieldMapping = sla.log_field_mapping ? 
    (typeof sla.log_field_mapping === 'string' ? JSON.parse(sla.log_field_mapping) : sla.log_field_mapping) 
    : {};

  return (
    <div className="border border-primary-200 rounded-lg p-6 bg-primary-50">
      <h4 className="font-semibold text-gray-900 mb-4">
        {sla.name ? 'Edit SLA' : 'New SLA'}
      </h4>

      <div className="space-y-4">
        {/* SLA Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            SLA Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={sla.name || ''}
            onChange={(e) => onUpdate('name', e.target.value)}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
              errors.name ? 'border-red-300 bg-red-50' : 'border-gray-300'
            }`}
            placeholder="e.g., Uptime SLA"
          />
          {errors.name && (
            <p className="text-sm text-red-600 mt-1">{errors.name}</p>
          )}
        </div>

        {/* SLA Type and Apply To */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              SLA Type <span className="text-red-500">*</span>
            </label>
            <select
              value={sla.metric_type || ''}
              onChange={(e) => handleMetricTypeChange(e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.metric_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
            >
              <option value="">Select SLA type...</option>
              {Object.keys(SLA_TYPES).map(key => (
                <option key={key} value={key}>
                  {SLA_TYPES[key].name}
                </option>
              ))}
            </select>
            {sla.metric_type && SLA_TYPES[sla.metric_type] && (
              <p className="text-xs text-gray-500 mt-1">
                {SLA_TYPES[sla.metric_type].description}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Apply To <span className="text-red-500">*</span>
            </label>
            <div className="flex space-x-2 mb-2">
              <button
                type="button"
                onClick={() => handleApplyToTypeChange('service')}
                className={`flex-1 px-3 py-2 text-sm rounded-lg border transition-colors ${
                  applyToType === 'service'
                    ? 'bg-primary-600 text-white border-primary-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-primary-300'
                }`}
              >
                Service
              </button>
              <button
                type="button"
                onClick={() => handleApplyToTypeChange('job')}
                className={`flex-1 px-3 py-2 text-sm rounded-lg border transition-colors ${
                  applyToType === 'job'
                    ? 'bg-primary-600 text-white border-primary-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-primary-300'
                }`}
              >
                Job
              </button>
            </div>

            <select
              value={applyToType === 'service' ? (sla.service_id || '') : (sla.job_id || '')}
              onChange={(e) => handleEntityChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="">Select {applyToType}...</option>
              {applyToType === 'service' 
                ? services.map(s => (
                    <option key={s.tempId || s.service_id} value={s.tempId || s.service_id}>
                      {s.service_name}
                    </option>
                  ))
                : jobs.map(j => (
                    <option key={j.tempId || j.job_id} value={j.tempId || j.job_id}>
                      {j.job_name}
                    </option>
                  ))
              }
            </select>
          </div>
        </div>

        {/* Target, Warning, Critical */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Target Value (%) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              step="0.1"
              value={sla.target_value || ''}
              onChange={(e) => onUpdate('target_value', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.target_value ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
              placeholder="99.9"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Warning Threshold (%)
            </label>
            <input
              type="number"
              step="0.1"
              value={sla.warning_threshold || ''}
              onChange={(e) => onUpdate('warning_threshold', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="95"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Critical Threshold (%)
            </label>
            <input
              type="number"
              step="0.1"
              value={sla.critical_threshold || ''}
              onChange={(e) => onUpdate('critical_threshold', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="90"
            />
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-xs text-blue-800">
            <FiInfo className="inline mr-1" />
            <strong>Note:</strong> Warning threshold should be higher than critical threshold.
            Example: Target 99.9%, Warning 95%, Critical 90%
          </p>
        </div>

        {/* Measurement Period */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Measurement Period
          </label>
          <select
            value={sla.measurement_period || 'Monthly'}
            onChange={(e) => onUpdate('measurement_period', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          >
            <option value="Hourly">Hourly</option>
            <option value="Daily">Daily</option>
            <option value="Weekly">Weekly</option>
            <option value="Monthly">Monthly</option>
            <option value="Quarterly">Quarterly</option>
            <option value="Yearly">Yearly</option>
          </select>
        </div>

        {/* Field Mapping Configuration */}
        {sla.metric_type && selectedEntity && (
          <FieldMappingConfigurator
            slaType={sla.metric_type}
            selectedEntity={selectedEntity}
            fieldMapping={currentFieldMapping}
            onUpdateMapping={handleFieldMappingUpdate}
          />
        )}

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            value={sla.description || ''}
            onChange={(e) => onUpdate('description', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            rows={2}
            placeholder="Optional description..."
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-3 pt-4 border-t">
          <Button variant="secondary" onClick={onCancel}>
            <FiX className="mr-2" />
            Cancel
          </Button>
          <Button onClick={onSave}>
            <FiSave className="mr-2" />
            Save SLA
          </Button>
        </div>
      </div>
    </div>
  );
};

const Step4_DefineSLAs = ({
  slas,
  services,
  jobs,
  onAddSLA,
  onUpdateSLA,
  onRemoveSLA
}) => {
  const [editingId, setEditingId] = useState(null);
  const [formErrors, setFormErrors] = useState({});

  const handleAddNew = () => {
    const tempId = onAddSLA();
    setEditingId(tempId);
  };

  const handleEdit = (tempId) => {
    setEditingId(tempId);
  };

  const validateSLA = (sla) => {
    const errors = {};

    if (!sla.name || sla.name.trim() === '') {
      errors.name = 'SLA name is required';
    }

    if (!sla.metric_type) {
      errors.metric_type = 'SLA type is required';
    }

    if (!sla.target_value || sla.target_value === '') {
      errors.target_value = 'Target value is required';
    }

    if (!sla.service_id && !sla.job_id) {
      errors.apply_to = 'Must select a service or job to apply SLA to';
    }

    // Validate field mapping if log template exists
    const entity = sla.service_id 
      ? services.find(s => s.tempId === sla.service_id || s.service_id === sla.service_id)
      : jobs.find(j => j.tempId === sla.job_id || j.job_id === sla.job_id);

    if (entity && entity.log_template && sla.metric_type) {
      const slaConfig = SLA_TYPES[sla.metric_type];
      if (slaConfig && sla.log_field_mapping) {
        const mapping = typeof sla.log_field_mapping === 'string' 
          ? JSON.parse(sla.log_field_mapping) 
          : sla.log_field_mapping;

        // Check required fields
        for (const requiredField of slaConfig.requiredFields) {
          if (!mapping[requiredField]) {
            errors.field_mapping = `Field mapping incomplete: ${requiredField} is required`;
            break;
          }
        }
      }
    }


    // Validate execution_window SLA requirements
    if (sla.metric_type === 'execution_window') {
      if (!sla.job_id) {
        errors.metric_type = 'Execution Window SLA can only be applied to jobs, not services';
      } else {
        const job = jobs.find(j => j.tempId === sla.job_id || j.job_id === sla.job_id);
        if (job && !job.expected_duration) {
          errors.job_id = 'Job must have expected_duration configured for Execution Window SLA. Please add expected_duration in Step 3.';
        }
      }
    }

    return errors;
  };

  const handleSave = () => {
    const editingSLA = slas.find(s => s.tempId === editingId);
    const errors = validateSLA(editingSLA);

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setFormErrors({});
    setEditingId(null);
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormErrors({});
  };

  const handleDelete = (tempId) => {
    if (window.confirm('Are you sure you want to delete this SLA?')) {
      onRemoveSLA(tempId);
      if (editingId === tempId) {
        setEditingId(null);
        setFormErrors({});
      }
    }
  };

  const handleUpdate = (tempId, field, value) => {
    onUpdateSLA(tempId, { [field]: value });
  };

  const editingSLA = slas.find(s => s.tempId === editingId);
  const displayedSLAs = slas.filter(s => s.tempId !== editingId);

  // Enhance displayed SLAs with entity names
  const enhancedSLAs = displayedSLAs.map(sla => {
    let apply_to_name = '';
    if (sla.service_id) {
      const service = services.find(s => s.tempId === sla.service_id || s.service_id === sla.service_id);
      apply_to_name = service ? service.service_name : 'Unknown Service';
    } else if (sla.job_id) {
      const job = jobs.find(j => j.tempId === sla.job_id || j.job_id === sla.job_id);
      apply_to_name = job ? job.job_name : 'Unknown Job';
    }
    return { ...sla, apply_to_name };
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Define SLAs (Optional)</h2>
        <p className="text-gray-600 mt-2">
          Set Service Level Agreements for your services or jobs to track performance and uptime.
        </p>
      </div>

      {/* Existing SLAs */}
      {enhancedSLAs.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900">SLAs ({enhancedSLAs.length})</h3>
          {enhancedSLAs.map(sla => (
            <SLACard
              key={sla.tempId}
              sla={sla}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {/* Editing Form */}
      {editingSLA && (
        <SLAForm
          sla={editingSLA}
          services={services}
          jobs={jobs}
          onUpdate={(field, value) => handleUpdate(editingId, field, value)}
          onSave={handleSave}
          onCancel={handleCancel}
          errors={formErrors}
        />
      )}

      {/* Add New Button */}
      {!editingId && (
        <Button onClick={handleAddNew} variant="outline">
          <FiPlus className="mr-2" />
          Add SLA
        </Button>
      )}
    </div>
  );
};

export default Step4_DefineSLAs;
