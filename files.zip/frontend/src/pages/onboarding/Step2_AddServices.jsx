/**
 * Step 2: Add Services (Optional)
 * 
 * UPDATED: Added log monitoring configuration fields
 * - Service Identifier
 * - Log Server Type (dropdown)
 * - Log Template (JSON editor with presets)
 */

import React, { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiSave, FiX, FiAlertCircle } from 'react-icons/fi';
import Button from '../../components/Button';

const SERVICE_TYPES = [
  { id: 'web_server', name: 'Web Server' },
  { id: 'database', name: 'Database' },
  { id: 'application', name: 'Application' },
  { id: 'api', name: 'API Service' },
  { id: 'message_queue', name: 'Message Queue' },
  { id: 'cache', name: 'Cache Service' },
  { id: 'storage', name: 'Storage Service' },
  { id: 'other', name: 'Other' }
];

// Log template presets for services
const LOG_TEMPLATE_PRESETS = {
  'uptime_availability': {
    name: 'Uptime / Availability',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track service uptime and availability status'
  },
  'performance': {
    name: 'Performance Metrics',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      response_time_ms: '{{response_time}}',
      cpu_usage: '{{cpu}}',
      memory_usage: '{{memory}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Monitor performance metrics like response time, CPU, memory'
  },
  'error_tracking': {
    name: 'Error Tracking',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      error_count: '{{errors}}',
      error_rate: '{{error_rate}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track errors and error rates'
  },
  'custom': {
    name: 'Custom Template',
    template: {
      identifier: '{{service_identifier}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Start with a minimal template and customize'
  }
};

const ServiceCard = ({ service, onEdit, onDelete, linkedJobsCount, linkedSLAsCount }) => {
  return (
    <div className="border border-gray-200 rounded-lg p-4 bg-white hover:border-primary-300 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900">{service.service_name}</h4>
          <p className="text-sm text-gray-600 mt-1">
            {SERVICE_TYPES.find(t => t.id === service.service_type)?.name || service.service_type}
          </p>
          {service.description && (
            <p className="text-sm text-gray-500 mt-2">{service.description}</p>
          )}
          
          <div className="flex items-center space-x-4 mt-3 text-xs text-gray-500">
            <span>Status: <span className="font-medium">{service.status}</span></span>
            {service.service_identifier && (
              <span>ID: <span className="font-mono font-medium">{service.service_identifier}</span></span>
            )}
            {service.log_server_type && (
              <span>Log: <span className="font-medium">{service.log_server_type}</span></span>
            )}
            {linkedJobsCount > 0 && (
              <span>{linkedJobsCount} job{linkedJobsCount !== 1 ? 's' : ''}</span>
            )}
            {linkedSLAsCount > 0 && (
              <span>{linkedSLAsCount} SLA{linkedSLAsCount !== 1 ? 's' : ''}</span>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2 ml-4">
          <button
            onClick={() => onEdit(service.tempId)}
            className="p-2 text-gray-600 hover:text-primary-600 hover:bg-primary-50 rounded transition-colors"
            title="Edit service"
          >
            <FiEdit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(service.tempId)}
            className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
            title="Delete service"
          >
            <FiTrash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

const ServiceForm = ({ service, onUpdate, onSave, onCancel, errors = {}, logConnectors = [] }) => {
  const [showLogConfig, setShowLogConfig] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState('');

  // Auto-expand log config if any log fields are filled
  useEffect(() => {
    if (service.service_identifier || service.log_server_type || service.log_template) {
      setShowLogConfig(true);
    }
  }, [service.service_identifier, service.log_server_type, service.log_template]);

  const handlePresetLoad = (presetKey) => {
    if (presetKey && LOG_TEMPLATE_PRESETS[presetKey]) {
      const preset = LOG_TEMPLATE_PRESETS[presetKey];
      onUpdate('log_template', JSON.stringify(preset.template, null, 2));
      setSelectedPreset(presetKey);
    }
  };

  const validateLogTemplate = (template) => {
    if (!template) return true;
    try {
      JSON.parse(template);
      return true;
    } catch (e) {
      return false;
    }
  };

  return (
    <div className="border border-primary-200 rounded-lg p-6 bg-primary-50">
      <h4 className="font-semibold text-gray-900 mb-4">
        {service.service_name ? 'Edit Service' : 'New Service'}
      </h4>

      <div className="space-y-4">
        {/* Basic Information */}
        <div className="grid grid-cols-2 gap-4">
          {/* Service Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Service Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={service.service_name}
              onChange={(e) => onUpdate('service_name', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.service_name ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
              placeholder="e.g., Apache Web Service"
            />
            {errors.service_name && (
              <p className="text-sm text-red-600 mt-1">{errors.service_name}</p>
            )}
          </div>

          {/* Service Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Service Type <span className="text-red-500">*</span>
            </label>
            <select
              value={service.service_type}
              onChange={(e) => onUpdate('service_type', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                errors.service_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
            >
              <option value="">Select type...</option>
              {SERVICE_TYPES.map(type => (
                <option key={type.id} value={type.id}>{type.name}</option>
              ))}
            </select>
            {errors.service_type && (
              <p className="text-sm text-red-600 mt-1">{errors.service_type}</p>
            )}
          </div>

          {/* Description */}
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={service.description}
              onChange={(e) => onUpdate('description', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              rows={2}
              placeholder="Optional description..."
            />
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              value={service.status}
              onChange={(e) => onUpdate('status', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

        {/* Log Monitoring Configuration - Collapsible Section */}
        <div className="border-t border-gray-200 pt-4">
          <button
            type="button"
            onClick={() => setShowLogConfig(!showLogConfig)}
            className="flex items-center justify-between w-full text-left mb-3"
          >
            <span className="text-sm font-medium text-gray-700">
              {showLogConfig ? '▼' : '▶'} Log Monitoring Configuration (Optional)
            </span>
          </button>

          {showLogConfig && (
            <div className="space-y-4 pl-4 border-l-2 border-primary-200">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                <div className="flex items-start gap-2">
                  <FiAlertCircle className="text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-blue-800">
                    Configure log-based monitoring for this service. First, set up log server connectors in <strong>Tools → Log Server Setup</strong>.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Service Identifier */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Service Identifier
                  </label>
                  <input
                    type="text"
                    value={service.service_identifier || ''}
                    onChange={(e) => onUpdate('service_identifier', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm ${
                      errors.service_identifier ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    placeholder="e.g., WEB-SRV-001"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Unique identifier used in log entries
                  </p>
                  {errors.service_identifier && (
                    <p className="text-sm text-red-600 mt-1">{errors.service_identifier}</p>
                  )}
                </div>

                {/* Log Server Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Log Server Type
                  </label>
                  <select
                    value={service.log_server_type || ''}
                    onChange={(e) => onUpdate('log_server_type', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                      errors.log_server_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                  >
                    <option value="">Select log server...</option>
                    {logConnectors.length === 0 ? (
                      <option value="" disabled>No log servers configured</option>
                    ) : (
                      logConnectors
                        .filter(c => c.is_active)
                        .map(connector => (
                          <option key={connector.connector_id} value={connector.log_server_type}>
                            {connector.connector_name} ({connector.log_server_type})
                          </option>
                        ))
                    )}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">
                    Select the log server where this service sends logs
                  </p>
                  {errors.log_server_type && (
                    <p className="text-sm text-red-600 mt-1">{errors.log_server_type}</p>
                  )}
                </div>

                {/* Log Template */}
                <div className="col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-sm font-medium text-gray-700">
                      Log Entry Template
                    </label>
                    <div className="flex items-center gap-2">
                      <select
                        value={selectedPreset}
                        onChange={(e) => handlePresetLoad(e.target.value)}
                        className="text-xs px-2 py-1 border border-gray-300 rounded"
                      >
                        <option value="">Load Preset...</option>
                        {Object.entries(LOG_TEMPLATE_PRESETS).map(([key, preset]) => (
                          <option key={key} value={key}>{preset.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <textarea
                    value={service.log_template || ''}
                    onChange={(e) => onUpdate('log_template', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm ${
                      errors.log_template ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    rows={8}
                    placeholder='{\n  "identifier": "{{service_identifier}}",\n  "status": "{{status}}",\n  "timestamp": "{{timestamp}}"\n}'
                  />
                  {service.log_template && !validateLogTemplate(service.log_template) && (
                    <p className="text-sm text-red-600 mt-1">Invalid JSON format</p>
                  )}
                  {errors.log_template && (
                    <p className="text-sm text-red-600 mt-1">{errors.log_template}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    This template must match the format your service uses in log entries
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Form Actions */}
      <div className="flex items-center justify-end space-x-3 mt-6">
        <Button variant="secondary" onClick={onCancel}>
          <FiX className="mr-2" />
          Cancel
        </Button>
        <Button onClick={onSave}>
          <FiSave className="mr-2" />
          Save Service
        </Button>
      </div>
    </div>
  );
};

const Step2_AddServices = ({
  services,
  onAddService,
  onUpdateService,
  onRemoveService
}) => {
  const [editingId, setEditingId] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [logConnectors, setLogConnectors] = useState([]);

  // Fetch log connectors on mount
  useEffect(() => {
    fetchLogConnectors();
  }, []);

  const fetchLogConnectors = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setLogConnectors(data.data || []);
      }
    } catch (error) {
      console.error('Error fetching log connectors:', error);
      setLogConnectors([]);
    }
  };

  const handleAddNew = () => {
    const tempId = onAddService();
    setEditingId(tempId);
  };

  const handleEdit = (tempId) => {
    setEditingId(tempId);
  };

  const validateService = (service) => {
    const errors = {};

    if (!service.service_name || service.service_name.trim() === '') {
      errors.service_name = 'Service name is required';
    }

    if (!service.service_type || service.service_type.trim() === '') {
      errors.service_type = 'Service type is required';
    }

    // Validate log configuration if any log field is filled
    const hasLogConfig = service.service_identifier || service.log_server_type || service.log_template;
    
    if (hasLogConfig) {
      // If any log field is filled, all three should be filled
      if (!service.service_identifier || service.service_identifier.trim() === '') {
        errors.service_identifier = 'Service identifier is required when using log monitoring';
      }
      
      if (!service.log_server_type) {
        errors.log_server_type = 'Log server type is required when using log monitoring';
      }
      
      if (!service.log_template || service.log_template.trim() === '') {
        errors.log_template = 'Log template is required when using log monitoring';
      } else {
        // Validate JSON format
        try {
          JSON.parse(service.log_template);
        } catch (e) {
          errors.log_template = 'Invalid JSON format';
        }
      }
    }

    return errors;
  };

  const handleSave = () => {
    const editingService = services.find(s => s.tempId === editingId);
    const errors = validateService(editingService);

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setFormErrors({});
    setEditingId(null);
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormErrors({});
  };

  const handleDelete = (tempId) => {
    if (window.confirm('Are you sure you want to delete this service?')) {
      onRemoveService(tempId);
      if (editingId === tempId) {
        setEditingId(null);
        setFormErrors({});
      }
    }
  };

  const handleUpdate = (tempId, field, value) => {
    onUpdateService(tempId, { [field]: value });
  };

  // Count linked entities for each service
  const getLinkedCounts = (service) => {
    // This would be calculated based on jobs and SLAs in the parent component
    // For now, return 0
    return { jobsCount: 0, slasCount: 0 };
  };

  const editingService = services.find(s => s.tempId === editingId);
  const displayedServices = services.filter(s => s.tempId !== editingId);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Add Services (Optional)</h2>
        <p className="text-gray-600 mt-2">
          Add services that run on this asset. You can skip this step and add services later.
        </p>
      </div>

      {/* Existing Services */}
      {displayedServices.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900">Services ({displayedServices.length})</h3>
          {displayedServices.map(service => {
            const counts = getLinkedCounts(service);
            return (
              <ServiceCard
                key={service.tempId}
                service={service}
                onEdit={handleEdit}
                onDelete={handleDelete}
                linkedJobsCount={counts.jobsCount}
                linkedSLAsCount={counts.slasCount}
              />
            );
          })}
        </div>
      )}

      {/* Editing Form */}
      {editingService && (
        <ServiceForm
          service={editingService}
          onUpdate={(field, value) => handleUpdate(editingId, field, value)}
          onSave={handleSave}
          onCancel={handleCancel}
          errors={formErrors}
          logConnectors={logConnectors}
        />
      )}

      {/* Add New Button */}
      {!editingId && (
        <Button onClick={handleAddNew} variant="outline">
          <FiPlus className="mr-2" />
          Add Service
        </Button>
      )}
    </div>
  );
};

export default Step2_AddServices;
