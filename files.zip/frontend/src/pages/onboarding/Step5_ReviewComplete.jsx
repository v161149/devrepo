/**
 * Step 5: Review & Complete
 * 
 * Shows summary of everything that will be created
 * and allows user to complete the onboarding
 */

import React from 'react';
import { FiCheck, FiServer, FiDatabase, FiClock, FiTarget, FiAlertCircle } from 'react-icons/fi';
import Button from '../../components/Button';

const Step5_ReviewComplete = ({
  wizardState,
  onComplete,
  isSubmitting,
  error
}) => {
  const { asset, services, jobs, slas } = wizardState;

  // Get parent name for job
  const getJobParent = (job) => {
    if (job.parent_type === 'asset') {
      return `Asset: ${asset.asset_name}`;
    }
    const service = services.find(s => s.tempId === job.parent_id);
    return service ? `Service: ${service.service_name}` : 'Unknown';
  };

  // Get target name for SLA
  const getSLATarget = (sla) => {
    // Check for service_id first (new format)
    if (sla.service_id) {
      const service = services.find(
        s => s.tempId === sla.service_id || s.service_id === sla.service_id
      );
      return service ? `Service: ${service.service_name}` : 'Unknown Service';
    }
    
    // Check for job_id (new format)
    if (sla.job_id) {
      const job = jobs.find(
        j => j.tempId === sla.job_id || j.job_id === sla.job_id
      );
      return job ? `Job: ${job.job_name}` : 'Unknown Job';
    }
    
    // Fallback to old target_type format (for backward compatibility)
    if (sla.target_type === 'service') {
      const service = services.find(s => s.tempId === sla.target_id);
      return service ? `Service: ${service.service_name}` : 'Unknown Service';
    }
    
    if (sla.target_type === 'job') {
      const job = jobs.find(j => j.tempId === sla.target_id);
      return job ? `Job: ${job.job_name}` : 'Unknown Job';
    }
    
    return 'Unknown';
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Review & Complete</h2>
        <p className="text-sm text-gray-600 mt-1">
          Review your configuration before completing the onboarding process.
        </p>
      </div>

      <div className="space-y-6">
        {/* Asset Summary */}
        <div className="border border-gray-200 rounded-lg p-5 bg-white">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <FiServer className="w-5 h-5 text-green-600" />
            </div>
            <div className="ml-3">
              <h3 className="text-lg font-semibold text-gray-900">Asset</h3>
              <p className="text-sm text-gray-600">Your primary asset</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Name:</span>
              <span className="ml-2 font-medium text-gray-900">{asset.asset_name}</span>
            </div>
            <div>
              <span className="text-gray-600">Type:</span>
              <span className="ml-2 font-medium text-gray-900">{asset.asset_type}</span>
            </div>
            <div>
              <span className="text-gray-600">Owner:</span>
              <span className="ml-2 font-medium text-gray-900">{asset.asset_owner}</span>
            </div>
            <div>
              <span className="text-gray-600">Status:</span>
              <span className={`ml-2 font-medium capitalize ${
                asset.status === 'active' ? 'text-green-600' : 'text-gray-600'
              }`}>
                {asset.status}
              </span>
            </div>
            {asset.description && (
              <div className="col-span-2">
                <span className="text-gray-600">Description:</span>
                <span className="ml-2 text-gray-900">{asset.description}</span>
              </div>
            )}
            <div>
              <span className="text-gray-600">Onboarded:</span>
              <span className="ml-2 text-gray-900">{asset.onboarded_date}</span>
            </div>
          </div>
        </div>

        {/* Services Summary */}
        {services.length > 0 ? (
          <div className="border border-gray-200 rounded-lg p-5 bg-white">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <FiDatabase className="w-5 h-5 text-blue-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-semibold text-gray-900">
                  Services ({services.length})
                </h3>
                <p className="text-sm text-gray-600">Services linked to this asset</p>
              </div>
            </div>

            <div className="space-y-3">
              {services.map((service, index) => (
                <div key={service.tempId} className="pl-4 border-l-2 border-blue-200">
                  <div className="font-medium text-gray-900">{index + 1}. {service.service_name}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    Type: {service.service_type} • Status: {service.status}
                  </div>
                  {service.description && (
                    <div className="text-sm text-gray-500 mt-1">{service.description}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="border border-gray-200 rounded-lg p-5 bg-gray-50">
            <div className="flex items-center text-gray-600">
              <FiDatabase className="w-5 h-5 mr-3" />
              <span>No services added</span>
            </div>
          </div>
        )}

        {/* Jobs Summary */}
        {jobs.length > 0 ? (
          <div className="border border-gray-200 rounded-lg p-5 bg-white">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <FiClock className="w-5 h-5 text-purple-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-semibold text-gray-900">
                  Jobs ({jobs.length})
                </h3>
                <p className="text-sm text-gray-600">Scheduled tasks and jobs</p>
              </div>
            </div>

            <div className="space-y-3">
              {jobs.map((job, index) => (
                <div key={job.tempId} className="pl-4 border-l-2 border-purple-200">
                  <div className="font-medium text-gray-900">{index + 1}. {job.job_name}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    Type: {job.job_type} • Linked to: {getJobParent(job)}
                  </div>
                  {job.schedule && (
                    <div className="text-xs text-gray-500 mt-1 font-mono">
                      Schedule: {job.schedule}
                    </div>
                  )}
                  {job.description && (
                    <div className="text-sm text-gray-500 mt-1">{job.description}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="border border-gray-200 rounded-lg p-5 bg-gray-50">
            <div className="flex items-center text-gray-600">
              <FiClock className="w-5 h-5 mr-3" />
              <span>No jobs added</span>
            </div>
          </div>
        )}

        {/* SLAs Summary */}
        {slas.length > 0 ? (
          <div className="border border-gray-200 rounded-lg p-5 bg-white">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <FiTarget className="w-5 h-5 text-orange-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-semibold text-gray-900">
                  SLAs ({slas.length})
                </h3>
                <p className="text-sm text-gray-600">Service level agreements</p>
              </div>
            </div>

            <div className="space-y-3">
              {slas.map((sla, index) => (
                <div key={sla.tempId} className="pl-4 border-l-2 border-orange-200">
                  <div className="font-medium text-gray-900">{index + 1}. {sla.sla_name}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    Type: {sla.metric_type || sla.sla_type} • Applied to: {getSLATarget(sla)}
                  </div>
                  <div className="flex items-center space-x-4 mt-2 text-sm">
                    <span className="text-green-600">
                      Target: {sla.target_value}%
                    </span>
                    <span className="text-yellow-600">
                      Warning: {sla.threshold_warning}%
                    </span>
                    <span className="text-red-600">
                      Critical: {sla.threshold_critical}%
                    </span>
                    <span className="text-gray-600">
                      Period: {sla.measurement_period}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="border border-gray-200 rounded-lg p-5 bg-gray-50">
            <div className="flex items-center text-gray-600">
              <FiTarget className="w-5 h-5 mr-3" />
              <span>No SLAs defined</span>
            </div>
          </div>
        )}

        {/* Summary Stats */}
        <div className="border border-primary-200 rounded-lg p-5 bg-primary-50">
          <h3 className="font-semibold text-gray-900 mb-3">Summary</h3>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-600">1</div>
              <div className="text-sm text-gray-600 mt-1">Asset</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">{services.length}</div>
              <div className="text-sm text-gray-600 mt-1">Services</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{jobs.length}</div>
              <div className="text-sm text-gray-600 mt-1">Jobs</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">{slas.length}</div>
              <div className="text-sm text-gray-600 mt-1">SLAs</div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="border border-red-200 rounded-lg p-4 bg-red-50">
            <div className="flex items-start">
              <FiAlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
              <div className="ml-3">
                <h4 className="font-semibold text-red-800">Error</h4>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Success Info */}
        <div className="border border-green-200 rounded-lg p-4 bg-green-50">
          <div className="flex items-start">
            <FiCheck className="w-5 h-5 text-green-600 mt-0.5" />
            <div className="ml-3">
              <h4 className="font-semibold text-green-800">Ready to Complete</h4>
              <p className="text-sm text-green-700 mt-1">
                Click "Complete Setup" to create your asset{services.length > 0 && ', services'}
                {jobs.length > 0 && ', jobs'}{slas.length > 0 && ', and SLAs'}. 
                You'll be redirected to the asset details page where you can manage everything.
              </p>
            </div>
          </div>
        </div>

        {/* Complete Button */}
        <div className="flex justify-center pt-4">
          <Button
            onClick={onComplete}
            disabled={isSubmitting}
            size="lg"
            className="px-8"
          >
            {isSubmitting ? (
              <>
                <span className="animate-spin mr-2">⏳</span>
                Completing Setup...
              </>
            ) : (
              <>
                <FiCheck className="mr-2" />
                Complete Setup
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Step5_ReviewComplete;
