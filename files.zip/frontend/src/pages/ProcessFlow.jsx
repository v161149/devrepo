/**
 * ProcessFlow.jsx
 * Interactive hierarchical diagram showing Asset → Service → Job → SLA relationships
 * Part 2: Frontend Components - SLA Portal Enhancements
 */

import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useSearchParams } from 'react-router-dom';
import {
  FiServer,
  FiDatabase,
  FiBriefcase,
  FiTarget,
  FiChevronDown,
  FiChevronRight,
  FiRefreshCw,
  FiZoomIn,
  FiZoomOut,
  FiMaximize2,
  FiFilter,
  FiSearch,
  FiAlertCircle,
  FiCheckCircle,
  FiClock,
  FiInfo,
  FiEye,
  FiEdit
} from 'react-icons/fi';
import Button from '../components/Button';
import apiService from '../services/api';

const ProcessFlow = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const highlightId = searchParams.get('highlight');
  
  const [assets, setAssets] = useState([]);
  const [services, setServices] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [slas, setSlas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // UI State
  const [expandedAssets, setExpandedAssets] = useState(new Set());
  const [expandedServices, setExpandedServices] = useState(new Set());
  const [expandedJobs, setExpandedJobs] = useState(new Set());
  const [selectedNode, setSelectedNode] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all'); // all, active, issues
  const [zoomLevel, setZoomLevel] = useState(100);
  
  const containerRef = useRef(null);

  // Load all data
  useEffect(() => {
    loadData();
  }, []);

  // Auto-expand and highlight if coming from onboarding
  useEffect(() => {
    if (highlightId && assets.length > 0) {
      // Find and expand the asset
      const asset = assets.find(a => a.asset_id === highlightId);
      if (asset) {
        setExpandedAssets(new Set([asset.asset_id]));
        
        // Expand related services
        const relatedServices = services.filter(s => s.asset_id === asset.asset_id);
        setExpandedServices(new Set(relatedServices.map(s => s.service_id)));
        
        // Select the asset
        setSelectedNode({ type: 'asset', data: asset });
        
        // Scroll to it
        setTimeout(() => {
          const element = document.getElementById(`asset-${asset.asset_id}`);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 100);
      }
    }
  }, [highlightId, assets, services]);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('ProcessFlow - Loading data...');
      
      // Load all entities using apiService (same as Dashboard)
      const [assetsRes, servicesRes, jobsRes, slasRes] = await Promise.all([
        apiService.assets.list(),
        apiService.services.getAll(),
        apiService.jobs.getAll(),
        apiService.slas.getAll()
      ]);

      console.log('ProcessFlow - Data loaded');

      // Extract data
      const assetsData = assetsRes.data?.data || assetsRes.data;
      const servicesData = servicesRes.data?.data || servicesRes.data;
      const jobsData = jobsRes.data?.data || jobsRes.data;
      const slasData = slasRes.data?.data || slasRes.data;

      // Set state
      setAssets(Array.isArray(assetsData) ? assetsData : assetsData.assets || []);
      setServices(Array.isArray(servicesData) ? servicesData : servicesData.services || []);
      setSlas(Array.isArray(slasData) ? slasData : slasData.slas || []);
      setJobs(Array.isArray(jobsData) ? jobsData : jobsData.jobs || []);  // ✅ Load from API
      
      console.log('ProcessFlow - Success:', {
        assets: Array.isArray(assetsData) ? assetsData.length : 0,
        services: Array.isArray(servicesData) ? servicesData.length : 0,
        jobs: Array.isArray(jobsData) ? jobsData.length : 0,
        slas: Array.isArray(slasData) ? slasData.length : 0
      });
      
    } catch (err) {
      console.error('ProcessFlow - Error:', err);
      
      if (err.response?.status === 401) {
        // Token expired - redirect to login
        navigate('/login');
      } else {
        setError('Failed to load process flow data. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Toggle expand/collapse
  const toggleAsset = (assetId) => {
    const newExpanded = new Set(expandedAssets);
    if (newExpanded.has(assetId)) {
      newExpanded.delete(assetId);
    } else {
      newExpanded.add(assetId);
    }
    setExpandedAssets(newExpanded);
  };

  const toggleService = (serviceId) => {
    const newExpanded = new Set(expandedServices);
    if (newExpanded.has(serviceId)) {
      newExpanded.delete(serviceId);
    } else {
      newExpanded.add(serviceId);
    }
    setExpandedServices(newExpanded);
  };

  const toggleJob = (jobId) => {
    const newExpanded = new Set(expandedJobs);
    if (newExpanded.has(jobId)) {
      newExpanded.delete(jobId);
    } else {
      newExpanded.add(jobId);
    }
    setExpandedJobs(newExpanded);
  };

  // Expand/collapse all
  const expandAll = () => {
    setExpandedAssets(new Set(assets.map(a => a.asset_id)));
    setExpandedServices(new Set(services.map(s => s.service_id)));
    setExpandedJobs(new Set(jobs.map(j => j.job_id)));
  };

  const collapseAll = () => {
    setExpandedAssets(new Set());
    setExpandedServices(new Set());
    setExpandedJobs(new Set());
  };

  // Zoom controls
  const zoomIn = () => setZoomLevel(prev => Math.min(prev + 10, 150));
  const zoomOut = () => setZoomLevel(prev => Math.max(prev - 10, 50));
  const resetZoom = () => setZoomLevel(100);

  // Filter functions
  const getServicesForAsset = (assetId) => {
    return services.filter(s => s.asset_id === assetId);
  };

  const getJobsForService = (serviceId) => {
    return jobs.filter(j => j.service_id === serviceId);
  };

  // Get jobs that belong directly to asset (no service_id)
  const getJobsForAsset = (assetId) => {
    return jobs.filter(j => j.asset_id === assetId && !j.service_id);
  };

  // Get SLAs that apply to the service level (no specific job_id)
  const getServiceLevelSLAs = (serviceId) => {
    return slas.filter(s => s.service_id === serviceId && !s.job_id);
  };

  // Get SLAs for a specific job
  const getJobLevelSLAs = (jobId) => {
    return slas.filter(s => s.job_id === jobId);
  };

  // Search and filter
  const matchesSearch = (text) => {
    if (!searchTerm) return true;
    return text.toLowerCase().includes(searchTerm.toLowerCase());
  };

  const matchesFilter = (item, type) => {
    if (filterType === 'all') return true;
    if (filterType === 'active') {
      if (type === 'asset') return item.status === 'active';
      if (type === 'service') return item.is_active;
      if (type === 'job') return item.is_active;
      if (type === 'sla') return item.is_active;
      return true;
    }
    if (filterType === 'issues') {
      if (type === 'service') return !item.is_active;
      if (type === 'job') return !item.is_active;
      if (type === 'sla') return !item.is_active;
      return false;
    }
    return true;
  };

  // Enhanced filtering - search across all entity types
  const getFilteredAssets = () => {
    if (!searchTerm && filterType === 'all') {
      // No filtering - return all assets
      return assets;
    }

    return assets.filter(asset => {
      // Check if asset matches
      const assetMatches = matchesSearch(asset.asset_name) && matchesFilter(asset, 'asset');
      
      if (assetMatches) return true;

      // Check if any service matches
      const assetServices = services.filter(s => s.asset_id === asset.asset_id);
      const serviceMatches = assetServices.some(service => {
        const svcMatches = matchesSearch(service.name) && matchesFilter(service, 'service');
        if (svcMatches) return true;

        // Check if any job under this service matches
        const serviceJobs = jobs.filter(j => j.service_id === service.service_id);
        const jobMatches = serviceJobs.some(job => 
          matchesSearch(job.job_name) && matchesFilter(job, 'job')
        );
        if (jobMatches) return true;

        // Check if any SLA under this service matches
        const serviceSLAs = slas.filter(sla => sla.service_id === service.service_id);
        const slaMatches = serviceSLAs.some(sla =>
          matchesSearch(sla.name) && matchesFilter(sla, 'sla')
        );
        return slaMatches;
      });

      if (serviceMatches) return true;

      // Check if any job directly under asset matches
      const assetJobs = jobs.filter(j => j.asset_id === asset.asset_id);
      const jobMatches = assetJobs.some(job => {
        const jMatches = matchesSearch(job.job_name) && matchesFilter(job, 'job');
        if (jMatches) return true;

        // Check if any SLA under this job matches
        const jobSLAs = slas.filter(sla => sla.job_id === job.job_id);
        return jobSLAs.some(sla =>
          matchesSearch(sla.name) && matchesFilter(sla, 'sla')
        );
      });

      return jobMatches;
    });
  };

  const filteredAssets = getFilteredAssets();

  // Helper to check if entity should be visible based on search
  const shouldShowService = (service) => {
    if (!searchTerm) return true;
    
    // Service name matches
    if (matchesSearch(service.name)) return true;
    
    // Any job under service matches
    const serviceJobs = jobs.filter(j => j.service_id === service.service_id);
    if (serviceJobs.some(job => matchesSearch(job.job_name))) return true;
    
    // Any SLA under service matches
    const serviceSLAs = slas.filter(sla => sla.service_id === service.service_id);
    if (serviceSLAs.some(sla => matchesSearch(sla.name))) return true;
    
    return false;
  };

  const shouldShowJob = (job) => {
    if (!searchTerm) return true;
    
    // Job name matches
    if (matchesSearch(job.job_name)) return true;
    
    // Any SLA under job matches
    const jobSLAs = slas.filter(sla => sla.job_id === job.job_id);
    return jobSLAs.some(sla => matchesSearch(sla.name));
  };

  const shouldShowSLA = (sla) => {
    if (!searchTerm) return true;
    return matchesSearch(sla.name);
  };


  // Get status badge
  const getStatusBadge = (status, type) => {
    if (type === 'asset') {
      return status === 'active' ? (
        <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full flex items-center">
          <FiCheckCircle className="mr-1" /> Active
        </span>
      ) : (
        <span className="px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full">
          Inactive
        </span>
      );
    }
    if (type === 'service') {
      return status ? (
        <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full flex items-center">
          <FiCheckCircle className="mr-1" /> Active
        </span>
      ) : (
        <span className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full flex items-center">
          <FiAlertCircle className="mr-1" /> Inactive
        </span>
      );
    }
    if (type === 'sla') {
      return status ? (
        <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">
          Active
        </span>
      ) : (
        <span className="px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full">
          Inactive
        </span>
      );
    }
    return null;
  };

  // Get SLA compliance indicator
  const getSLACompliance = (sla) => {
    // This would come from actual monitoring data
    // For now, showing mock data
    const mockCompliance = Math.random() * 100;
    
    if (mockCompliance >= sla.target_value) {
      return (
        <div className="flex items-center text-green-600 text-sm">
          <FiCheckCircle className="mr-1" />
          {mockCompliance.toFixed(1)}% (Meeting)
        </div>
      );
    } else {
      return (
        <div className="flex items-center text-red-600 text-sm">
          <FiAlertCircle className="mr-1" />
          {mockCompliance.toFixed(1)}% (Breach)
        </div>
      );
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <FiRefreshCw className="text-4xl text-primary-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading process flow...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <FiAlertCircle className="text-4xl text-red-500 mx-auto mb-4" />
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={loadData}>
            <FiRefreshCw className="mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-gray-600 text-sm mt-1">
              Visual hierarchy of Assets → Services → Jobs → SLAs
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={loadData}>
              <FiRefreshCw className="mr-2" />
              Refresh
            </Button>
            <Button variant="secondary" size="sm" onClick={expandAll}>
              Expand All
            </Button>
            <Button variant="secondary" size="sm" onClick={collapseAll}>
              Collapse All
            </Button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-4 flex-wrap">
          {/* Search */}
          <div className="flex-1 min-w-[300px]">
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search assets, services, jobs..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Filter */}
          <div className="flex items-center gap-2">
            <FiFilter className="text-gray-400" />
            <select
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
            >
              <option value="all">All Items</option>
              <option value="active">Active Only</option>
              <option value="issues">With Issues</option>
            </select>
          </div>

          {/* Zoom Controls */}
          <div className="flex items-center gap-2 border-l border-gray-300 pl-4">
            <button
              onClick={zoomOut}
              className="p-2 hover:bg-gray-100 rounded-lg"
              title="Zoom Out"
            >
              <FiZoomOut />
            </button>
            <span className="text-sm text-gray-600 min-w-[60px] text-center">
              {zoomLevel}%
            </span>
            <button
              onClick={zoomIn}
              className="p-2 hover:bg-gray-100 rounded-lg"
              title="Zoom In"
            >
              <FiZoomIn />
            </button>
            <button
              onClick={resetZoom}
              className="p-2 hover:bg-gray-100 rounded-lg"
              title="Reset Zoom"
            >
              <FiMaximize2 />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex">
        {/* Process Flow Diagram */}
        <div
          ref={containerRef}
          className="flex-1 p-6 overflow-auto"
          style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top left' }}
        >
          {filteredAssets.length === 0 ? (
            <div className="text-center py-12">
              <FiInfo className="text-4xl text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">
                {searchTerm || filterType !== 'all' 
                  ? 'No items match your search or filter criteria.'
                  : 'No assets found. Create your first asset to get started.'}
              </p>
              {!searchTerm && filterType === 'all' && (
                <Button onClick={() => window.location.href = '/onboarding'}>
                  Start Onboarding
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredAssets.map(asset => (
                <AssetNode
                  key={asset.asset_id}
                  asset={asset}
                  services={getServicesForAsset(asset.asset_id)}
                  jobs={jobs}
                  slas={slas}
                  expanded={expandedAssets.has(asset.asset_id)}
                  expandedServices={expandedServices}
                  expandedJobs={expandedJobs}
                  onToggle={() => toggleAsset(asset.asset_id)}
                  onToggleService={toggleService}
                  onToggleJob={toggleJob}
                  onSelectNode={setSelectedNode}
                  selectedNode={selectedNode}
                  getJobsForService={getJobsForService}
                  getJobsForAsset={getJobsForAsset}
                  getServiceLevelSLAs={getServiceLevelSLAs}
                  getJobLevelSLAs={getJobLevelSLAs}
                  getStatusBadge={getStatusBadge}
                  getSLACompliance={getSLACompliance}
                  highlighted={asset.asset_id === highlightId}
                  shouldShowService={shouldShowService}
                  shouldShowJob={shouldShowJob}
                  shouldShowSLA={shouldShowSLA}
                  searchTerm={searchTerm}
                />
              ))}
            </div>
          )}
        </div>

        {/* Details Panel */}
        {selectedNode && (
          <div className="w-96 bg-white border-l border-gray-200 p-6 overflow-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-800">Details</h2>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>

            <DetailsPanel node={selectedNode} />
          </div>
        )}
      </div>

      {/* Stats Bar */}
      <div className="bg-white border-t border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center gap-6">
            <span>Assets: {assets.length}</span>
            <span>Services: {services.length}</span>
            <span>Jobs: {jobs.length}</span>
            <span>SLAs: {slas.length}</span>
          </div>
          <div>
            Showing {filteredAssets.length} of {assets.length} assets
          </div>
        </div>
      </div>
    </div>
  );
};

// Asset Node Component
const AssetNode = ({
  asset,
  services,
  jobs,
  slas,
  expanded,
  expandedServices,
  expandedJobs,
  onToggle,
  onToggleService,
  onToggleJob,
  onSelectNode,
  selectedNode,
  getJobsForService,
  getJobsForAsset,
  getServiceLevelSLAs,
  getJobLevelSLAs,
  getStatusBadge,
  getSLACompliance,
  highlighted,
  shouldShowService,
  shouldShowJob,
  shouldShowSLA,
  searchTerm
}) => {
  const isSelected = selectedNode?.type === 'asset' && selectedNode?.data.asset_id === asset.asset_id;

  return (
    <div
      id={`asset-${asset.asset_id}`}
      className={`bg-white rounded-lg shadow-sm border-2 transition-all ${
        highlighted ? 'border-primary-500 shadow-lg' : 'border-gray-200'
      } ${isSelected ? 'ring-2 ring-primary-500' : ''}`}
    >
      {/* Asset Header */}
      <div
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50"
        onClick={onToggle}
      >
        <div className="flex items-center flex-1">
          <button className="mr-2 text-gray-400 hover:text-gray-600">
            {expanded ? <FiChevronDown /> : <FiChevronRight />}
          </button>
          <FiServer className="text-blue-500 text-xl mr-3" />
          <div className="flex-1">
            <h3 className="font-semibold text-gray-800">{asset.asset_name}</h3>
            <p className="text-sm text-gray-500">
              {asset.asset_type} • {asset.asset_owner}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {getStatusBadge(asset.status, 'asset')}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelectNode({ type: 'asset', data: asset });
            }}
            className="p-2 hover:bg-gray-100 rounded-lg"
            title="View Details"
          >
            <FiEye className="text-gray-400" />
          </button>
        </div>
      </div>

      {/* Services and Asset-Level Jobs */}
      {expanded && (() => {
        // Filter services based on search
        const visibleServices = services.filter(service => shouldShowService(service));
        
        // Get jobs that belong directly to this asset (no service_id)
        const assetLevelJobs = getJobsForAsset(asset.asset_id);
        const visibleAssetJobs = assetLevelJobs.filter(job => shouldShowJob(job));
        
        return (
          <div className="pl-12 pr-4 pb-4">
            {/* Render Services */}
            {visibleServices.length > 0 && (
              <div className="space-y-2 mb-4">
                <p className="text-xs font-medium text-gray-500 uppercase mb-2">
                  Associated Services
                </p>
                {visibleServices.map(service => (
                  <ServiceNode
                    key={service.service_id}
                    service={service}
                    jobs={getJobsForService(service.service_id)}
                    serviceLevelSLAs={getServiceLevelSLAs(service.service_id)}
                    expanded={expandedServices.has(service.service_id)}
                    expandedJobs={expandedJobs}
                    onToggle={() => onToggleService(service.service_id)}
                    onToggleJob={onToggleJob}
                    onSelectNode={onSelectNode}
                    selectedNode={selectedNode}
                    getJobLevelSLAs={getJobLevelSLAs}
                    getStatusBadge={getStatusBadge}
                    getSLACompliance={getSLACompliance}
                    shouldShowJob={shouldShowJob}
                    shouldShowSLA={shouldShowSLA}
                  />
                ))}
              </div>
            )}

            {/* Render Asset-Level Jobs (jobs without service_id) */}
            {visibleAssetJobs.length > 0 && (
              <div className="space-y-2 mb-4">
                <p className="text-xs font-medium text-gray-500 uppercase mb-2">
                  Associated Jobs
                </p>
                {visibleAssetJobs.map(job => (
                  <JobNode
                    key={job.job_id}
                    job={job}
                    jobLevelSLAs={getJobLevelSLAs(job.job_id)}
                    expanded={expandedJobs.has(job.job_id)}
                    onToggle={() => onToggleJob(job.job_id)}
                    onSelectNode={onSelectNode}
                    selectedNode={selectedNode}
                    getStatusBadge={getStatusBadge}
                    getSLACompliance={getSLACompliance}
                    shouldShowSLA={shouldShowSLA}
                  />
                ))}
              </div>
            )}

            {/* Empty State */}
            {visibleServices.length === 0 && visibleAssetJobs.length === 0 && (
              <p className="text-sm text-gray-500 italic">
                {searchTerm ? 'No matching services or jobs' : 'No services or jobs configured'}
              </p>
            )}
          </div>
        );
      })()}
    </div>
  );
};

// Service Node Component
const ServiceNode = ({
  service,
  jobs,
  serviceLevelSLAs,
  expanded,
  expandedJobs,
  onToggle,
  onToggleJob,
  onSelectNode,
  selectedNode,
  getJobLevelSLAs,
  getStatusBadge,
  getSLACompliance,
  shouldShowJob,
  shouldShowSLA
}) => {
  const isSelected = selectedNode?.type === 'service' && selectedNode?.data.service_id === service.service_id;

  return (
    <div
      className={`bg-purple-50 rounded-lg border ${
        isSelected ? 'border-purple-500 ring-2 ring-purple-500' : 'border-purple-200'
      }`}
    >
      {/* Service Header */}
      <div
        className="flex items-center justify-between p-3 cursor-pointer hover:bg-purple-100"
        onClick={onToggle}
      >
        <div className="flex items-center flex-1">
          <button className="mr-2 text-gray-400 hover:text-gray-600">
            {expanded ? <FiChevronDown /> : <FiChevronRight />}
          </button>
          <FiDatabase className="text-purple-500 mr-2" />
          <div className="flex-1">
            <h4 className="font-medium text-gray-800">{service.name}</h4>
            <p className="text-xs text-gray-500">{service.owner_team}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {getStatusBadge(service.is_active, 'service')}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelectNode({ type: 'service', data: service });
            }}
            className="p-1 hover:bg-purple-200 rounded"
            title="View Details"
          >
            <FiEye className="text-gray-400 text-sm" />
          </button>
        </div>
      </div>

      {/* Jobs and SLAs */}
      {expanded && (
        <div className="pl-8 pr-3 pb-3">
          {/* Service-Level SLAs (apply to entire service) */}
          {(() => {
            const visibleSLAs = serviceLevelSLAs.filter(sla => shouldShowSLA(sla));
            return visibleSLAs.length > 0 && (
              <div className="mb-3">
                <p className="text-xs font-medium text-gray-500 uppercase mb-2">Service SLAs</p>
                <div className="space-y-2">
                  {visibleSLAs.map(sla => (
                    <SLANode
                      key={sla.sla_id}
                      sla={sla}
                      onSelectNode={onSelectNode}
                      selectedNode={selectedNode}
                      getStatusBadge={getStatusBadge}
                      getSLACompliance={getSLACompliance}
                    />
                  ))}
                </div>
              </div>
            );
          })()}

          {/* Jobs (with their own job-level SLAs) */}
          {(() => {
            const visibleJobs = jobs.filter(job => shouldShowJob(job));
            return visibleJobs.length > 0 && (
              <div className="space-y-2 mb-3">
                <p className="text-xs font-medium text-gray-500 uppercase mb-2">Jobs</p>
                {visibleJobs.map(job => (
                  <JobNode
                    key={job.job_id}
                    job={job}
                    jobLevelSLAs={getJobLevelSLAs(job.job_id)}
                    expanded={expandedJobs.has(job.job_id)}
                    onToggle={() => onToggleJob(job.job_id)}
                    onSelectNode={onSelectNode}
                    selectedNode={selectedNode}
                    getStatusBadge={getStatusBadge}
                    getSLACompliance={getSLACompliance}
                    shouldShowSLA={shouldShowSLA}
                  />
                ))}
              </div>
            );
          })()}

          {jobs.length === 0 && serviceLevelSLAs.length === 0 && (
            <p className="text-xs text-gray-500 italic">No jobs or SLAs configured</p>
          )}
        </div>
      )}
    </div>
  );
};

// Job Node Component
const JobNode = ({ 
  job, 
  jobLevelSLAs,
  expanded, 
  onToggle, 
  onSelectNode, 
  selectedNode,
  getStatusBadge,
  getSLACompliance,
  shouldShowSLA
}) => {
  const isSelected = selectedNode?.type === 'job' && selectedNode?.data.job_id === job.job_id;

  return (
    <div className="space-y-2">
      {/* Job Card */}
      <div
        className={`bg-green-50 rounded-lg border p-2 cursor-pointer hover:bg-green-100 ${
          isSelected ? 'border-green-500 ring-2 ring-green-500' : 'border-green-200'
        }`}
        onClick={() => onSelectNode({ type: 'job', data: job })}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center flex-1">
            <button 
              className="mr-2 text-gray-400 hover:text-gray-600"
              onClick={(e) => {
                e.stopPropagation();
                onToggle();
              }}
            >
              {expanded && jobLevelSLAs.length > 0 ? <FiChevronDown /> : <FiChevronRight />}
            </button>
            <FiBriefcase className="text-green-500 mr-2" />
            <div className="flex-1">
              <p className="font-medium text-sm text-gray-800">{job.job_name}</p>
              <p className="text-xs text-gray-500">
                {job.job_type} • {job.schedule}
                {jobLevelSLAs.length > 0 && (
                  <span className="ml-2 text-orange-600">
                    ({jobLevelSLAs.length} SLA{jobLevelSLAs.length > 1 ? 's' : ''})
                  </span>
                )}
              </p>
            </div>
          </div>
          <FiEye className="text-gray-400 text-sm" />
        </div>
      </div>

      {/* Job-Level SLAs (nested under job) */}
      {expanded && (() => {
        const visibleJobSLAs = jobLevelSLAs.filter(sla => shouldShowSLA(sla));
        return visibleJobSLAs.length > 0 && (
          <div className="ml-8 space-y-2">
            {visibleJobSLAs.map(sla => (
              <SLANode
                key={sla.sla_id}
                sla={sla}
                onSelectNode={onSelectNode}
                selectedNode={selectedNode}
                getStatusBadge={getStatusBadge}
                getSLACompliance={getSLACompliance}
                isJobLevel={true}
              />
            ))}
          </div>
        );
      })()}
    </div>
  );
};

// SLA Node Component
const SLANode = ({ sla, onSelectNode, selectedNode, getStatusBadge, getSLACompliance, isJobLevel = false }) => {
  const isSelected = selectedNode?.type === 'sla' && selectedNode?.data.sla_id === sla.sla_id;

  return (
    <div
      className={`bg-orange-50 rounded-lg border p-2 cursor-pointer hover:bg-orange-100 ${
        isSelected ? 'border-orange-500 ring-2 ring-orange-500' : 'border-orange-200'
      }`}
      onClick={() => onSelectNode({ type: 'sla', data: sla })}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center flex-1">
          <FiTarget className="text-orange-500 mr-2" />
          <div className="flex-1">
            <p className="font-medium text-sm text-gray-800">
              {sla.name}
              {isJobLevel && (
                <span className="ml-2 text-xs bg-orange-200 text-orange-800 px-2 py-0.5 rounded">
                  Job SLA
                </span>
              )}
            </p>
            <p className="text-xs text-gray-500">
              Target: {sla.target_value}% {sla.metric_type}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {getSLACompliance(sla)}
          <FiEye className="text-gray-400 text-sm" />
        </div>
      </div>
    </div>
  );
};

// Details Panel Component
const DetailsPanel = ({ node }) => {
  const { type, data } = node;

  if (type === 'asset') {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-800">{data.asset_name}</h3>
          <button className="p-2 hover:bg-gray-100 rounded-lg" title="Edit">
            <FiEdit className="text-gray-400" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Type</label>
            <p className="text-gray-800">{data.asset_type}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Owner</label>
            <p className="text-gray-800">{data.asset_owner}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Status</label>
            <p className="text-gray-800">{data.status}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Onboarded</label>
            <p className="text-gray-800">
              {new Date(data.onboarded_date).toLocaleDateString()}
            </p>
          </div>

          {data.description && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Description</label>
              <p className="text-gray-800">{data.description}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (type === 'service') {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-800">{data.name}</h3>
          <button className="p-2 hover:bg-gray-100 rounded-lg" title="Edit">
            <FiEdit className="text-gray-400" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Owner Team</label>
            <p className="text-gray-800">{data.owner_team}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Status</label>
            <p className="text-gray-800">{data.is_active ? 'Active' : 'Inactive'}</p>
          </div>

          {data.deployment_location && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Deployment</label>
              <p className="text-gray-800">{data.deployment_location}</p>
            </div>
          )}

          {data.description && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Description</label>
              <p className="text-gray-800">{data.description}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (type === 'job') {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-800">{data.job_name}</h3>
          <button className="p-2 hover:bg-gray-100 rounded-lg" title="Edit">
            <FiEdit className="text-gray-400" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Type</label>
            <p className="text-gray-800">{data.job_type}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Schedule</label>
            <p className="text-gray-800 font-mono text-sm">{data.schedule}</p>
          </div>

          {data.deployment_location && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Deployment</label>
              <p className="text-gray-800">{data.deployment_location}</p>
            </div>
          )}

          {data.expected_duration && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Duration</label>
              <p className="text-gray-800">{data.expected_duration} minutes</p>
            </div>
          )}

          {data.description && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Description</label>
              <p className="text-gray-800">{data.description}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (type === 'sla') {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-800">{data.name}</h3>
          <button className="p-2 hover:bg-gray-100 rounded-lg" title="Edit">
            <FiEdit className="text-gray-400" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Metric Type</label>
            <p className="text-gray-800 capitalize">{data.metric_type.replace('_', ' ')}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Target</label>
            <p className="text-gray-800">
              {data.target_value}% {data.target_unit}
            </p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Priority</label>
            <p className="text-gray-800">{data.priority}</p>
          </div>

          <div>
            <label className="text-xs font-medium text-gray-500 uppercase">Effective From</label>
            <p className="text-gray-800">
              {new Date(data.effective_from).toLocaleDateString()}
            </p>
          </div>

          {data.description && (
            <div>
              <label className="text-xs font-medium text-gray-500 uppercase">Description</label>
              <p className="text-gray-800">{data.description}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
};

export default ProcessFlow;
