import React, { useState, useEffect } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { FiDownload, FiCalendar, FiFilter, FiTrendingUp, FiTrendingDown, FiCheckCircle, FiAlertTriangle } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import apiService from '../services/api';

const Reports = () => {
  const [loading, setLoading] = useState(true);
  const [slas, setSlas] = useState([]);
  const [services, setServices] = useState([]);
  const [dateRange, setDateRange] = useState('30'); // Default 30 days
  const [selectedService, setSelectedService] = useState('all');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  
  // Summary metrics
  const [metrics, setMetrics] = useState({
    totalSLAs: 0,
    compliant: 0,
    breached: 0,
    avgCompliance: 0
  });

  useEffect(() => {
    loadReportData();
  }, [dateRange, selectedService, customStartDate, customEndDate]);

  const loadReportData = async () => {
    try {
      setLoading(true);

      // Load SLAs
      const slaResponse = await apiService.slas.getAll();
      const slaData = slaResponse.data?.data || [];

      // Load Services
      const serviceResponse = await apiService.services.getAll();
      const serviceData = serviceResponse.data?.data || [];

      // Filter by selected service if not "all"
      let filteredSLAs = slaData;
      if (selectedService !== 'all') {
        filteredSLAs = slaData.filter(sla => sla.service_id === selectedService);
      }

      setSlas(filteredSLAs);
      setServices(serviceData);

      // Calculate metrics
      const totalSLAs = filteredSLAs.length;
      const compliant = filteredSLAs.filter(sla => 
        sla.current_compliance >= sla.target_value
      ).length;
      const breached = totalSLAs - compliant;
      const avgCompliance = totalSLAs > 0
        ? filteredSLAs.reduce((sum, sla) => sum + (sla.current_compliance || 0), 0) / totalSLAs
        : 0;

      setMetrics({
        totalSLAs,
        compliant,
        breached,
        avgCompliance: Math.round(avgCompliance * 100) / 100
      });

    } catch (err) {
      console.error('Error loading report data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Prepare data for compliance by service chart
  const getComplianceByService = () => {
    const serviceMap = new Map();
    
    slas.forEach(sla => {
      const serviceName = sla.service_name || 'Unknown Service';
      if (!serviceMap.has(serviceName)) {
        serviceMap.set(serviceName, {
          name: serviceName,
          totalSLAs: 0,
          compliant: 0,
          breached: 0
        });
      }
      
      const data = serviceMap.get(serviceName);
      data.totalSLAs++;
      if (sla.current_compliance >= sla.target_value) {
        data.compliant++;
      } else {
        data.breached++;
      }
    });

    return Array.from(serviceMap.values());
  };

  // Prepare data for SLA status pie chart
  const getStatusPieData = () => {
    return [
      { name: 'Compliant', value: metrics.compliant, color: '#10b981' },
      { name: 'Breached', value: metrics.breached, color: '#ef4444' }
    ];
  };

  // Prepare data for compliance distribution
  const getComplianceDistribution = () => {
    const ranges = [
      { name: '0-50%', min: 0, max: 50, count: 0 },
      { name: '50-75%', min: 50, max: 75, count: 0 },
      { name: '75-90%', min: 75, max: 90, count: 0 },
      { name: '90-95%', min: 90, max: 95, count: 0 },
      { name: '95-100%', min: 95, max: 100, count: 0 }
    ];

    slas.forEach(sla => {
      const compliance = sla.current_compliance || 0;
      for (const range of ranges) {
        if (compliance >= range.min && compliance < range.max) {
          range.count++;
          break;
        }
      }
    });

    return ranges;
  };

  const exportToCSV = () => {
    const headers = ['SLA Name', 'Service', 'Type', 'Target', 'Current Compliance', 'Status'];
    const rows = slas.map(sla => [
      sla.name,
      sla.service_name || 'Unknown',
      sla.sla_type,
      `${sla.target_value}%`,
      `${sla.current_compliance?.toFixed(2) || 0}%`,
      sla.current_compliance >= sla.target_value ? 'Compliant' : 'Breached'
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sla-compliance-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">SLA Compliance Reports</h1>
        <Button
          onClick={exportToCSV}
          icon={FiDownload}
          variant="outline"
        >
          Export CSV
        </Button>
      </div>

      {/* Filters */}
      <Card title="Filters">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Date Range */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <FiCalendar className="inline mr-2" />
              Date Range
            </label>
            <div className="flex gap-2">
              <button
                onClick={() => setDateRange('7')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                  dateRange === '7'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                7 Days
              </button>
              <button
                onClick={() => setDateRange('30')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                  dateRange === '30'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                30 Days
              </button>
              <button
                onClick={() => setDateRange('90')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                  dateRange === '90'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                90 Days
              </button>
            </div>
          </div>

          {/* Service Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <FiFilter className="inline mr-2" />
              Service
            </label>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="all">All Services</option>
              {services.map(service => (
                <option key={service.service_id} value={service.service_id}>
                  {service.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total SLAs</p>
              <p className="text-3xl font-bold text-gray-900">{metrics.totalSLAs}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <FiFilter className="text-2xl text-blue-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Compliant</p>
              <p className="text-3xl font-bold text-green-600">{metrics.compliant}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <FiCheckCircle className="text-2xl text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Breached</p>
              <p className="text-3xl font-bold text-red-600">{metrics.breached}</p>
            </div>
            <div className="p-3 bg-red-100 rounded-lg">
              <FiAlertTriangle className="text-2xl text-red-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Avg Compliance</p>
              <p className="text-3xl font-bold text-purple-600">{metrics.avgCompliance}%</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              {metrics.avgCompliance >= 95 ? (
                <FiTrendingUp className="text-2xl text-purple-600" />
              ) : (
                <FiTrendingDown className="text-2xl text-purple-600" />
              )}
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Compliance by Service */}
        <Card title="Compliance by Service">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={getComplianceByService()}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="compliant" fill="#10b981" name="Compliant" />
              <Bar dataKey="breached" fill="#ef4444" name="Breached" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* SLA Status Distribution */}
        <Card title="SLA Status Distribution">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={getStatusPieData()}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {getStatusPieData().map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Compliance Distribution */}
      <Card title="Compliance Distribution">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={getComplianceDistribution()}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#3b82f6" name="Number of SLAs" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Detailed Table */}
      <Card title="SLA Details">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  SLA Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Service
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Target
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Current
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {slas.length === 0 ? (
                <tr>
                  <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                    No SLAs found for the selected criteria
                  </td>
                </tr>
              ) : (
                slas.map((sla) => {
                  const isCompliant = sla.current_compliance >= sla.target_value;
                  return (
                    <tr key={sla.sla_id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {sla.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sla.service_name || 'Unknown Service'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sla.sla_type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sla.target_value}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sla.current_compliance?.toFixed(2) || 0}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 py-1 text-xs font-semibold rounded-full ${
                            isCompliant
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {isCompliant ? '✓ Compliant' : '✗ Breached'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default Reports;
