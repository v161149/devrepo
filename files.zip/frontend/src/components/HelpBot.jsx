/**
 * HelpBot.jsx
 * Context-aware AI help bot that assists users with the SLA Portal
 * Part 2: Frontend Components - SLA Portal Enhancements
 */

import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import {
  FiMessageCircle,
  FiX,
  FiSend,
  FiUser,
  FiHelpCircle,
  FiMinimize2,
  FiMaximize2,
  FiRefreshCw,
  FiThumbsUp,
  FiThumbsDown,
  FiCopy,
  FiCheck
} from 'react-icons/fi';

const HelpBot = () => {
  const location = useLocation();
  
  // UI State
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => `session-${Date.now()}`);
  
  // Feedback state
  const [copiedMessageId, setCopiedMessageId] = useState(null);
  
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Initial greeting message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: 1,
        type: 'bot',
        text: "👋 Hi! I'm your SLA Portal assistant. I can help you with:\n\n• Creating assets, services, and SLAs\n• Understanding the process flow\n• Troubleshooting issues\n• Navigating the portal\n\nWhat would you like to know?",
        timestamp: new Date()
      }]);
    }
  }, []);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, isMinimized]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Get context from current page
  const getPageContext = () => {
    const path = location.pathname;
    const contexts = {
      '/dashboard': 'Dashboard - Overview of services and SLA compliance',
      '/assets': 'Assets - Infrastructure management',
      '/services': 'Services - Service configuration',
      '/slas': 'SLAs - Service Level Agreements',
      '/process-flow': 'Process Flow - Visual hierarchy diagram',
      '/onboarding': 'Onboarding - Setup wizard for new users',
      '/alerts': 'Alerts - SLA breach notifications',
      '/settings': 'Settings - User preferences'
    };
    
    return contexts[path] || 'SLA Monitoring Portal';
  };

  // Send question to backend
  const sendQuestion = async (question) => {
    setIsLoading(true);
    
    try {
      const response = await fetch('/api/v1/help/ask', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question,
          session_id: sessionId,
          current_page: location.pathname,
          context: getPageContext()
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      
      return {
        text: data.answer,
        provider: data.provider || 'mock',
        responseTime: data.response_time_ms
      };
      
    } catch (error) {
      console.error('Error getting help:', error);
      
      // Fallback to mock responses
      return {
        text: getMockResponse(question),
        provider: 'mock',
        responseTime: 0
      };
    } finally {
      setIsLoading(false);
    }
  };

  // Mock responses for demo/fallback
  const getMockResponse = (question) => {
    const q = question.toLowerCase();
    
    // Context-aware responses
    if (location.pathname === '/onboarding') {
      if (q.includes('asset')) {
        return "To create an asset in the onboarding wizard:\n\n1. Enter a descriptive name (e.g., 'Production Server')\n2. Select the asset type (Server, Database, Application, etc.)\n3. Specify the owner team\n4. Add a description\n5. Click 'Next' to proceed\n\nThe asset represents the infrastructure that runs your services.";
      }
      if (q.includes('service')) {
        return "In Step 2, you'll create a service:\n\n1. Give it a clear name (e.g., 'Payment Processing')\n2. Assign an owner team\n3. Choose the deployment location\n4. The service will automatically link to your asset\n\nServices represent business capabilities running on your infrastructure.";
      }
      if (q.includes('sla')) {
        return "For SLA configuration in Step 4:\n\n1. Name your SLA (e.g., '99% Uptime')\n2. Choose a metric type (uptime, response time, etc.)\n3. Set your target (e.g., 99.0%)\n4. Select priority level\n\nUse the calculator to see downtime allowances!";
      }
    }
    
    if (location.pathname === '/process-flow') {
      if (q.includes('expand') || q.includes('view')) {
        return "To navigate the Process Flow:\n\n• Click the arrow (▶) to expand/collapse nodes\n• Use 'Expand All' to see the full hierarchy\n• Click the eye icon (👁) to view details\n• Use search to find specific items\n• Zoom controls are in the top toolbar";
      }
      if (q.includes('hierarchy')) {
        return "The Process Flow shows your monitoring hierarchy:\n\n📦 Assets (Infrastructure)\n  └─ 🔷 Services (Applications)\n      ├─ 💼 Jobs (Scheduled tasks)\n      │   └─ 🎯 Job SLAs\n      └─ 🎯 Service SLAs\n\nClick nodes to see details in the side panel.";
      }
    }
    
    // General questions
    if (q.includes('create') && q.includes('asset')) {
      return "To create an asset:\n\n1. Go to Assets page\n2. Click 'Create Asset'\n3. Fill in:\n   • Asset name\n   • Asset type\n   • Owner\n   • Description\n4. Click 'Create'\n\nOr use the Onboarding wizard for guided setup!";
    }
    
    if (q.includes('create') && q.includes('sla')) {
      return "To create an SLA:\n\n1. Navigate to SLAs page\n2. Click 'Create SLA'\n3. Select the service or job\n4. Choose metric type:\n   • Uptime\n   • Response time\n   • Resolution time\n5. Set target value and priority\n6. Save\n\n💡 Tip: Use the SLA calculator to understand downtime allowances!";
    }
    
    if (q.includes('alert') || q.includes('notification')) {
      return "SLA breach alerts work like this:\n\n1. System monitors service/job performance\n2. If SLA target is missed, an alert is created\n3. Alerts appear in:\n   • Dashboard (top right bell icon)\n   • Alerts page\n   • Email notifications (if configured)\n\nYou can acknowledge or resolve alerts from the Alerts page.";
    }
    
    if (q.includes('service') && q.includes('job')) {
      return "Services vs Jobs:\n\n**Service** 🔷\n• Represents a business capability\n• Runs continuously\n• Example: 'Payment API'\n\n**Job** 💼\n• Scheduled/batch task\n• Runs on a schedule\n• Example: 'Daily ETL'\n\nJobs belong to Services in the hierarchy.";
    }
    
    if (q.includes('sla') && q.includes('service') && q.includes('job')) {
      return "SLA Types:\n\n**Service-Level SLA** 🎯\n• Applies to entire service\n• Measures overall availability\n• Example: '99.9% uptime'\n\n**Job-Level SLA** 🎯\n• Applies to specific job\n• Measures job completion\n• Example: 'Complete by 6 AM'\n\nA service can have both types!";
    }
    
    if (q.includes('dashboard')) {
      return "The Dashboard shows:\n\n📊 **Key Metrics**\n• Total assets, services, SLAs\n• Active alerts\n• SLA compliance rate\n\n📈 **Charts**\n• Compliance trends\n• Service health\n• Alert history\n\nClick any metric to drill down for details.";
    }
    
    if (q.includes('import') || q.includes('bulk')) {
      return "Bulk import (coming soon!):\n\n1. Go to Tools > Import Data\n2. Choose connector:\n   • Autosys\n   • Ansible Tower\n   • CSV upload\n3. Map fields\n4. Preview and confirm\n5. Import\n\nCurrently, use the Onboarding wizard for individual setup.";
    }
    
    // Default response
    return "I can help you with:\n\n• **Creating** assets, services, jobs, and SLAs\n• **Understanding** the process flow and hierarchy\n• **Navigating** different pages\n• **Troubleshooting** common issues\n• **Configuring** alerts and notifications\n\nCould you please be more specific about what you'd like to know?";
  };

  // Handle sending message
  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      text: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Get bot response
    const response = await sendQuestion(userMessage.text);
    
    const botMessage = {
      id: Date.now() + 1,
      type: 'bot',
      text: response.text,
      timestamp: new Date(),
      provider: response.provider,
      responseTime: response.responseTime
    };

    setMessages(prev => [...prev, botMessage]);
    
    // Log to backend
    logHelpQuestion(userMessage.text, botMessage.text, response.provider, response.responseTime);
  };

  // Log question for analytics
  const logHelpQuestion = async (question, answer, provider, responseTime) => {
    try {
      await fetch('/api/v1/help/log', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question,
          answer,
          provider,
          current_page: location.pathname,
          response_time_ms: responseTime,
          session_id: sessionId
        })
      });
    } catch (error) {
      console.error('Error logging help question:', error);
    }
  };

  // Handle feedback
  const handleFeedback = async (messageId, wasHelpful, feedbackText = '') => {
    try {
      await fetch('/api/v1/help/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message_id: messageId,
          was_helpful: wasHelpful,
          feedback_text: feedbackText,
          session_id: sessionId
        })
      });
      
      // Update message to show feedback submitted
      setMessages(prev => prev.map(msg => 
        msg.id === messageId 
          ? { ...msg, feedbackSubmitted: true, wasHelpful }
          : msg
      ));
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  };

  // Copy message to clipboard
  const copyToClipboard = (text, messageId) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(messageId);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  // Quick action buttons
  const quickActions = [
    { text: "How do I create an asset?", icon: FiHelpCircle },
    { text: "What's the difference between service and job SLAs?", icon: FiHelpCircle },
    { text: "How do I set up alerts?", icon: FiHelpCircle },
    { text: "Show me the process flow", icon: FiHelpCircle }
  ];

  // Handle quick action click
  const handleQuickAction = (text) => {
    setInputValue(text);
    inputRef.current?.focus();
  };

  // Reset conversation
  const resetConversation = () => {
    setMessages([{
      id: Date.now(),
      type: 'bot',
      text: "Conversation reset. How can I help you?",
      timestamp: new Date()
    }]);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-primary-600 text-white rounded-full p-4 shadow-lg hover:bg-primary-700 transition-all hover:scale-110 z-50"
        aria-label="Open help chat"
      >
        <FiMessageCircle className="text-2xl" />
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
          ?
        </span>
      </button>
    );
  }

  return (
    <div
      className={`fixed bottom-6 right-6 bg-white rounded-lg shadow-2xl z-50 flex flex-col transition-all ${
        isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'
      }`}
      style={{ maxHeight: 'calc(100vh - 100px)' }}
    >
      {/* Header */}
      <div className="bg-primary-600 text-white p-4 rounded-t-lg flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FiMessageCircle className="text-xl" />
          <div>
            <h3 className="font-semibold">SLA Portal Assistant</h3>
            {!isMinimized && (
              <p className="text-xs text-primary-100">
                On: {getPageContext().split(' - ')[0]}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {!isMinimized && (
            <button
              onClick={resetConversation}
              className="p-1 hover:bg-primary-700 rounded"
              title="Reset conversation"
            >
              <FiRefreshCw />
            </button>
          )}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-primary-700 rounded"
            title={isMinimized ? "Maximize" : "Minimize"}
          >
            {isMinimized ? <FiMaximize2 /> : <FiMinimize2 />}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-primary-700 rounded"
            title="Close"
          >
            <FiX />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.type === 'user'
                      ? 'bg-primary-600 text-white'
                      : 'bg-white border border-gray-200'
                  }`}
                >
                  {message.type === 'bot' && (
                    <div className="flex items-center gap-2 mb-2 text-xs text-gray-500">
                      <FiHelpCircle />
                      <span>Assistant</span>
                    </div>
                  )}
                  
                  <div className="whitespace-pre-wrap text-sm">
                    {message.text}
                  </div>
                  
                  <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                    <span>
                      {message.timestamp.toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                    
                    {message.type === 'bot' && message.provider && (
                      <span className="text-xs">
                        {message.provider === 'mock' ? '🤖 Mock' : '🧠 AI'}
                      </span>
                    )}
                  </div>
                  
                  {/* Bot message actions */}
                  {message.type === 'bot' && (
                    <div className="flex items-center gap-2 mt-3 pt-2 border-t border-gray-100">
                      <button
                        onClick={() => copyToClipboard(message.text, message.id)}
                        className="text-gray-500 hover:text-gray-700 p-1 rounded"
                        title="Copy to clipboard"
                      >
                        {copiedMessageId === message.id ? (
                          <FiCheck className="text-green-600" />
                        ) : (
                          <FiCopy />
                        )}
                      </button>
                      
                      {!message.feedbackSubmitted ? (
                        <>
                          <button
                            onClick={() => handleFeedback(message.id, true)}
                            className="text-gray-500 hover:text-green-600 p-1 rounded"
                            title="Helpful"
                          >
                            <FiThumbsUp />
                          </button>
                          <button
                            onClick={() => handleFeedback(message.id, false)}
                            className="text-gray-500 hover:text-red-600 p-1 rounded"
                            title="Not helpful"
                          >
                            <FiThumbsDown />
                          </button>
                        </>
                      ) : (
                        <span className="text-xs text-gray-500">
                          {message.wasHelpful ? '👍 Thanks!' : '👎 Feedback noted'}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 rounded-lg p-3">
                  <div className="flex items-center gap-2 text-gray-500">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                    <span className="text-sm">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Actions */}
          {messages.length <= 1 && (
            <div className="p-3 bg-white border-t border-gray-200">
              <p className="text-xs text-gray-600 mb-2">Quick questions:</p>
              <div className="flex flex-wrap gap-2">
                {quickActions.map((action, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickAction(action.text)}
                    className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-full flex items-center gap-1 transition-colors"
                  >
                    <action.icon className="text-xs" />
                    {action.text.length > 30 ? action.text.substring(0, 30) + '...' : action.text}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input Area */}
          <div className="p-4 bg-white border-t border-gray-200 rounded-b-lg">
            <div className="flex gap-2">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask a question..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                disabled={isLoading}
              />
              <button
                onClick={handleSend}
                disabled={!inputValue.trim() || isLoading}
                className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <FiSend />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Press Enter to send • Context: {getPageContext().split(' - ')[0]}
            </p>
          </div>
        </>
      )}
    </div>
  );
};

export default HelpBot;
