/**
 * Card Component
 * Reusable card container with optional header and footer
 */

import React from 'react';

const Card = ({
  children,
  title,
  subtitle,
  header,
  footer,
  padding = true,
  className = '',
  hoverable = false,
  ...props
}) => {
  const baseStyles = 'bg-white rounded-xl shadow-lg overflow-hidden';
  const hoverStyles = hoverable ? 'transition-all duration-300 hover:shadow-xl hover:-translate-y-1' : '';
  const paddingStyles = padding ? 'p-6' : '';

  return (
    <div className={`${baseStyles} ${hoverStyles} ${className}`} {...props}>
      {(title || header) && (
        <div className="border-b border-gray-200 pb-4 mb-4">
          {header || (
            <>
              <h3 className="text-lg font-bold text-gray-900">{title}</h3>
              {subtitle && <p className="text-sm text-gray-600 mt-1">{subtitle}</p>}
            </>
          )}
        </div>
      )}
      
      <div className={paddingStyles}>
        {children}
      </div>
      
      {footer && (
        <div className="border-t border-gray-200 pt-4 mt-4">
          {footer}
        </div>
      )}
    </div>
  );
};

export default Card;
