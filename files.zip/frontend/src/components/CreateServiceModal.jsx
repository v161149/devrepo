/**
 * CreateServiceModal - Comprehensive service creation modal
 * Matches the "Add Services" step from Manual Onboarding wizard
 * 
 * CORRECTED: Uses proper API format based on backend api_service.py
 */

import React, { useState, useEffect } from 'react';
import { FiX, FiAlertCircle } from 'react-icons/fi';
import Button from './Button';

const SERVICE_TYPES = [
  { id: 'web_service', name: 'Web Service' },
  { id: 'api', name: 'API' },
  { id: 'database', name: 'Database' },
  { id: 'application', name: 'Application' },
  { id: 'microservice', name: 'Microservice' },
  { id: 'batch_job', name: 'Batch Job' },
  { id: 'queue', name: 'Message Queue' },
  { id: 'cache', name: 'Cache Service' },
  { id: 'storage', name: 'Storage Service' },
  { id: 'other', name: 'Other' }
];

// Log template presets (matching Step2 onboarding)
const LOG_TEMPLATE_PRESETS = {
  'uptime_availability': {
    name: 'Uptime / Availability',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track service uptime and availability status'
  },
  'performance': {
    name: 'Performance Metrics',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      response_time_ms: '{{response_time}}',
      cpu_usage: '{{cpu}}',
      memory_usage: '{{memory}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Monitor performance metrics like response time, CPU, memory'
  },
  'error_tracking': {
    name: 'Error Tracking',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      error_count: '{{errors}}',
      error_rate: '{{error_rate}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Track errors and error rates'
  },
  'custom': {
    name: 'Custom Template',
    template: {
      identifier: '{{service_identifier}}',
      timestamp: '{{timestamp}}'
    },
    description: 'Start with a minimal template and customize'
  }
};

const CreateServiceModal = ({ 
  isOpen, 
  onClose, 
  onSuccess, 
  preselectedAssetId = null 
}) => {
  const [formData, setFormData] = useState({
    name: '',
    service_type: '',
    description: '',
    status: 'active',
    asset_id: '',
    // Log monitoring fields
    enable_log_monitoring: false,
    service_identifier: '',
    log_server_type: '',
    log_template: ''
  });

  const [assets, setAssets] = useState([]);
  const [logConnectors, setLogConnectors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedPreset, setSelectedPreset] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadAssets();
      loadLogConnectors();
      // Reset form
      setFormData({
        name: '',
        service_type: '',
        description: '',
        status: 'active',
        asset_id: preselectedAssetId || '',
        enable_log_monitoring: false,
        service_identifier: '',
        log_server_type: '',
        log_template: ''
      });
      setSelectedPreset('');
      setError('');
    }
  }, [isOpen, preselectedAssetId]);

  const loadAssets = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.warn('No auth token found');
        setAssets([]);
        return;
      }
      
      const response = await fetch('http://localhost:5000/api/v1/assets', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        // API returns { data: [...], count: ... }
        setAssets(Array.isArray(result.data) ? result.data : []);
      } else {
        console.warn('Failed to load assets:', response.status);
        setAssets([]);
      }
    } catch (err) {
      console.error('Error loading assets:', err);
      setAssets([]);
    }
  };

  const loadLogConnectors = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.warn('No auth token found');
        setLogConnectors([]);
        return;
      }
      
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        // Handle different possible response formats
        if (Array.isArray(result)) {
          setLogConnectors(result);
        } else if (result.data && Array.isArray(result.data)) {
          setLogConnectors(result.data);
        } else {
          setLogConnectors([]);
        }
      } else {
        // Not an error if no log connectors configured
        console.log('No log connectors available or not configured');
        setLogConnectors([]);
      }
    } catch (err) {
      console.error('Error loading log connectors:', err);
      setLogConnectors([]);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handlePresetChange = (presetId) => {
    setSelectedPreset(presetId);
    if (presetId && LOG_TEMPLATE_PRESETS[presetId]) {
      const preset = LOG_TEMPLATE_PRESETS[presetId];
      handleChange('log_template', JSON.stringify(preset.template, null, 2));
    }
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      setError('Service name is required');
      return false;
    }
    if (!formData.service_type) {
      setError('Service type is required');
      return false;
    }
    if (!formData.asset_id) {
      setError('Please link to an asset');
      return false;
    }

    // Validate log monitoring if enabled
    if (formData.enable_log_monitoring) {
      if (!formData.service_identifier.trim()) {
        setError('Service identifier is required for log monitoring');
        return false;
      }
      if (!formData.log_server_type) {
        setError('Log server type is required for log monitoring');
        return false;
      }
      if (!formData.log_template.trim()) {
        setError('Log template is required for log monitoring');
        return false;
      }

      // Validate JSON format
      try {
        JSON.parse(formData.log_template);
      } catch (e) {
        setError('Log template must be valid JSON');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Build metadata for log monitoring fields
      const metadata = {};
      
      if (formData.enable_log_monitoring) {
        metadata.service_identifier = formData.service_identifier.trim();
        metadata.log_server_type = formData.log_server_type;
        metadata.log_template = formData.log_template.trim();
      }
      
      // Add service_type to metadata as well (based on backend code)
      metadata.service_type = formData.service_type;

      const payload = {
        name: formData.name.trim(),
        description: formData.description.trim(),
        asset_id: formData.asset_id,
        status: formData.status,
        metadata: metadata
      };

      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/services', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create service');
      }
      
      if (onSuccess) {
        onSuccess();
      }
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to create service');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  // Get asset name for display when preselected
  const preselectedAssetName = preselectedAssetId && Array.isArray(assets) 
    ? (assets.find(a => a.asset_id === preselectedAssetId)?.asset_name || 'Loading...')
    : 'Loading...';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Add New Service</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <FiX className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <FiAlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-800">Error</p>
                <p className="text-sm text-red-600 mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Service Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Service Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="e.g., Apache Web Service"
              required
            />
          </div>

          {/* Service Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Service Type <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.service_type}
              onChange={(e) => handleChange('service_type', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              required
            >
              <option value="">Select type...</option>
              {SERVICE_TYPES.map(type => (
                <option key={type.id} value={type.id}>{type.name}</option>
              ))}
            </select>
          </div>

          {/* Link to Asset - Conditional rendering */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Link to Asset <span className="text-red-500">*</span>
            </label>
            {preselectedAssetId ? (
              /* Show asset name as read-only when preselected */
              <>
                <input
                  type="text"
                  value={preselectedAssetName}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
                  disabled
                  readOnly
                />
                <p className="text-xs text-gray-500 mt-1">
                  Service will be linked to this asset
                </p>
              </>
            ) : (
              /* Show dropdown when not preselected */
              <select
                value={formData.asset_id}
                onChange={(e) => handleChange('asset_id', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                required
              >
                <option value="">Select asset...</option>
                {Array.isArray(assets) && assets.map(asset => (
                  <option key={asset.asset_id} value={asset.asset_id}>
                    {asset.asset_name}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              placeholder="Optional description..."
              rows={3}
            />
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              value={formData.status}
              onChange={(e) => handleChange('status', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="maintenance">Maintenance</option>
            </select>
          </div>

          {/* Log Monitoring Configuration */}
          <div className="border-t border-gray-200 pt-6">
            <div className="flex items-center gap-2 mb-4">
              <input
                type="checkbox"
                id="enable_log_monitoring"
                checked={formData.enable_log_monitoring}
                onChange={(e) => handleChange('enable_log_monitoring', e.target.checked)}
                className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
              />
              <label htmlFor="enable_log_monitoring" className="text-sm font-medium text-gray-700">
                Log Monitoring Configuration (Optional)
              </label>
            </div>

            {formData.enable_log_monitoring && (
              <div className="space-y-4 pl-6 border-l-2 border-primary-200">
                {/* Service Identifier */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Service Identifier <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.service_identifier}
                    onChange={(e) => handleChange('service_identifier', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="e.g., WEB-SVC-001"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Unique identifier to find this service in logs
                  </p>
                </div>

                {/* Log Server Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Log Server Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.log_server_type}
                    onChange={(e) => handleChange('log_server_type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    <option value="">Select log server...</option>
                    {logConnectors.length === 0 ? (
                      <option value="" disabled>No log servers configured</option>
                    ) : (
                      Array.isArray(logConnectors) && logConnectors
                        .filter(c => c.is_active)
                        .map((connector) => (
                          <option key={connector.connector_id} value={connector.log_server_type}>
                            {connector.connector_name} ({connector.log_server_type})
                          </option>
                        ))
                    )}
                  </select>
                </div>

                {/* Log Template Preset */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Log Template Preset
                  </label>
                  <select
                    value={selectedPreset}
                    onChange={(e) => handlePresetChange(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    <option value="">Select preset...</option>
                    {Object.entries(LOG_TEMPLATE_PRESETS).map(([id, preset]) => (
                      <option key={id} value={id}>{preset.name}</option>
                    ))}
                  </select>
                </div>

                {/* Log Template JSON */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Log Template (JSON) <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={formData.log_template}
                    onChange={(e) => handleChange('log_template', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent font-mono text-sm"
                    placeholder='{"identifier": "{{service_identifier}}", "status": "{{status}}"}'
                    rows={8}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Define the log entry structure with placeholders
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={loading}
            >
              {loading ? 'Creating...' : 'Create Service'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateServiceModal;
