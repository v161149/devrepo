/**
 * Layout Component
 * Main application layout with sidebar and header
 * UPDATED: Added Onboarding submenu (Manual and Bulk)
 */

import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  FiHome, // Home - Dashboard
  FiServer, // Server - Assets
  FiDatabase, // Database - Services
  FiClock, // Clock - Jobs
  FiBell, // Bell - Alerts
  FiBarChart2, // Bar Chart - Reports
  FiSettings, // Settings
  FiLogOut, // Log Out
  FiMenu, // Menu
  FiX, // X (close)
  FiActivity,// Activity
  FiGitBranch, // Process Flow
  FiBookOpen, // Onboarding
  FiTool, // Tools parent menu
  FiDownload, // Metadata Retrieval
  FiChevronDown, // Submenu toggle
  FiEdit, // Manual Onboarding
  FiUpload // Bulk Onboarding
} from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import Button from './Button';

const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [openSubmenu, setOpenSubmenu] = useState(null); // Track open submenu
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const navigation = [
    { id: 'dashboard', name: 'Dashboard', icon: FiHome, path: '/dashboard' },
    { 
      id: 'onboarding', 
      name: 'Onboarding', 
      icon: FiBookOpen,
      children: [ // NEW - Onboarding submenu
        { id: 'manual-onboarding', name: 'Manual Onboarding', icon: FiEdit, path: '/onboarding/manual' },
        { id: 'bulk-onboarding', name: 'Bulk Onboarding', icon: FiUpload, path: '/onboarding/bulk' },
      ]
    },
    { id: 'process-flow', name: 'Process Flow', icon: FiGitBranch, path: '/process-flow' },
    //{ id: 'assets', name: 'Assets', icon: FiServer, path: '/assets' },
    //{ id: 'services', name: 'Services', icon: FiDatabase, path: '/services' },
    //{ id: 'jobs', name: 'Jobs', icon: FiClock, path: '/jobs' },
    { id: 'alerts', name: 'Alerts', icon: FiBell, path: '/alerts' },
    { id: 'reports', name: 'Reports', icon: FiBarChart2, path: '/reports' },
    { 
      id: 'tools', 
      name: 'Tools', 
      icon: FiTool,
      children: [ // Nested menu
        { id: 'metadata-retrieval', name: 'Metadata Retrieval', icon: FiDownload, path: '/tools/metadata-retrieval' },
        { id: 'integration-health', name: 'Integration Health', icon: FiActivity, path: '/tools/integration-health' },
        { id: 'log-server-setup', name: 'Log Server Setup', icon: FiServer, path: '/tools/log-server-setup' },
        { id: 'system-settings', name: 'System Settings', icon: FiSettings, path: '/tools/system-settings' },
      ]
    },
    { id: 'settings', name: 'Settings', icon: FiSettings, path: '/settings' },
  ];

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const isActivePath = (path) => {
    return location.pathname === path;
  };

  // Check if any child path is active
  const isChildActive = (children) => {
    if (!children) return false;
    return children.some(child => location.pathname === child.path);
  };

  // Toggle submenu
  const toggleSubmenu = (itemId) => {
    setOpenSubmenu(openSubmenu === itemId ? null : itemId);
  };

  // Auto-open submenu if a child is active
  React.useEffect(() => {
    navigation.forEach(item => {
      if (item.children && isChildActive(item.children)) {
        setOpenSubmenu(item.id);
      }
    });
  }, [location.pathname]);

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? 'w-64' : 'w-20'
        } bg-gray-900 text-white transition-all duration-300 flex flex-col`}
      >
        {/* Logo */}
        <div className="p-4 flex items-center justify-between border-b border-gray-800">
          {sidebarOpen && (
            <div className="flex items-center">
              <FiActivity className="text-2xl text-primary-400 mr-2" />
              <span className="text-xl font-bold">SLA Monitor</span>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded hover:bg-gray-800 transition"
          >
            {sidebarOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 overflow-y-auto">
          {navigation.map((item) => {
            const Icon = item.icon;
            const active = isActivePath(item.path);
            const hasChildren = item.children && item.children.length > 0;
            const isOpen = openSubmenu === item.id;
            const childActive = isChildActive(item.children);
            
            return (
              <div key={item.id}>
                {/* Parent Menu Item */}
                {hasChildren ? (
                  // Menu item with children (Onboarding, Tools)
                  <button
                    onClick={() => toggleSubmenu(item.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 mb-2 rounded-lg transition ${
                      childActive
                        ? 'bg-primary-600 text-white'
                        : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center">
                      <Icon className={`text-xl ${sidebarOpen ? 'mr-3' : 'mx-auto'}`} />
                      {sidebarOpen && <span>{item.name}</span>}
                    </div>
                    {sidebarOpen && (
                      <FiChevronDown 
                        className={`text-lg transition-transform duration-200 ${
                          isOpen ? 'transform rotate-180' : ''
                        }`}
                      />
                    )}
                  </button>
                ) : (
                  // Regular menu item (no children)
                  <Link
                    to={item.path}
                    className={`flex items-center px-4 py-3 mb-2 rounded-lg transition ${
                      active
                        ? 'bg-primary-600 text-white'
                        : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                    }`}
                  >
                    <Icon className={`text-xl ${sidebarOpen ? 'mr-3' : 'mx-auto'}`} />
                    {sidebarOpen && <span>{item.name}</span>}
                  </Link>
                )}

                {/* Submenu Items (Children) */}
                {hasChildren && isOpen && sidebarOpen && (
                  <div className="ml-4 mb-2 border-l-2 border-gray-700">
                    {item.children.map((child) => {
                      const ChildIcon = child.icon;
                      const childActive = isActivePath(child.path);
                      
                      return (
                        <Link
                          key={child.id}
                          to={child.path}
                          className={`flex items-center px-4 py-2 mb-1 ml-4 rounded-lg transition text-sm ${
                            childActive
                              ? 'bg-primary-500 text-white'
                              : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                          }`}
                        >
                          <ChildIcon className="text-lg mr-3" />
                          <span>{child.name}</span>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-gray-800">
          {sidebarOpen ? (
            <div className="mb-3">
              <p className="text-sm text-gray-400">Logged in as</p>
              <p className="text-sm font-medium truncate">{user?.email}</p>
            </div>
          ) : null}
          
          <button
            onClick={handleLogout}
            className="w-full flex items-center px-4 py-3 text-gray-400 hover:bg-gray-800 hover:text-white rounded-lg transition"
          >
            <FiLogOut className={`text-xl ${sidebarOpen ? 'mr-3' : 'mx-auto'}`} />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="px-6 py-4 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                {(() => {
                  // Find current page name (including nested children)
                  for (const item of navigation) {
                    if (item.path === location.pathname) {
                      return item.name;
                    }
                    if (item.children) {
                      const child = item.children.find(c => c.path === location.pathname);
                      if (child) {
                        return child.name;
                      }
                    }
                  }
                  return 'Dashboard';
                })()}
              </h2>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Welcome, {user?.username || 'User'}
              </span>
              <div className="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold">
                {user?.username?.charAt(0)?.toUpperCase() || 'U'}
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
