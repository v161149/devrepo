/**
 * API Client Service
 * Handles all HTTP requests to the backend API
 * Centralizes API logic and provides reusable methods
 */

import axios from 'axios';

// Base API configuration
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds
});

// Request interceptor - Add auth token to requests
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - Handle common errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Unauthorized - clear auth and redirect to login
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API Service object with all endpoints
const apiService = {
  // ============= Authentication =============
  auth: {
    login: (email, password) =>
      apiClient.post('/auth/login', { email, password }),
    
    logout: () =>
      apiClient.post('/auth/logout'),
    
    getCurrentUser: () =>
      apiClient.get('/auth/me'),
  },

  // ============= Services =============
  services: {
    getAll: (params = {}) =>
      apiClient.get('/services', { params }),
    
    getById: (id) =>
      apiClient.get(`/services/${id}`),
    
    create: (data) =>
      apiClient.post('/services', data),
    
    update: (id, data) =>
      apiClient.put(`/services/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/services/${id}`),
    
    getSLAs: (serviceId) =>
      apiClient.get(`/services/${serviceId}/slas`),
    
    testConnection: (data) =>
      apiClient.post('/services/test-connection', data),
  },

  // ============= SLAs =============
  slas: {
    getAll: (params = {}) =>
      apiClient.get('/slas', { params }),
    
    getById: (id) =>
      apiClient.get(`/slas/${id}`),
    
    getByService: (serviceId) =>
      apiClient.get(`/services/${serviceId}/slas`),
    
    create: (data) =>
      apiClient.post('/slas', data),
    
    update: (id, data) =>
      apiClient.put(`/slas/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/slas/${id}`),
    
    hardDelete: (id) =>
      apiClient.delete(`/slas/${id}/hard`),
    
    getCompliance: (id) =>
      apiClient.get(`/slas/${id}/compliance`),
    
    getBreaches: (id) =>
      apiClient.get(`/slas/${id}/breaches`),

    // Get SLA type definitions
    getSLATypes: (entityType = null) =>
      apiClient.get('/sla-types', { params: { entity_type: entityType } }),

    // Get SLA field mapping
    getFieldMapping: (slaId) =>
      apiClient.get(`/slas/${slaId}/field-mapping`),

    // Update SLA field mapping  
    updateFieldMapping: (slaId, fieldMapping, evaluationConfig = null) =>
      apiClient.put(`/slas/${slaId}/field-mapping`, {
        log_field_mapping: fieldMapping,
        evaluation_config: evaluationConfig
      }),

    // Get service SLA compliance
    getServiceCompliance: (serviceId, params = {}) =>
      apiClient.get(`/services/${serviceId}/sla-compliance`, { params }),

    // Get job SLA compliance
    getJobCompliance: (jobId, params = {}) =>
      apiClient.get(`/jobs/${jobId}/sla-compliance`, { params }),

    // Get SLA compliance summary
    getComplianceSummary: (slaId, days = 30) =>
      apiClient.get(`/slas/${slaId}/compliance-summary`, { params: { days } }),

    // Get service SLA status (view)
    getServiceSLAStatus: (serviceId) =>
      apiClient.get(`/services/${serviceId}/sla-status`),

    // Get job SLA status (view)
    getJobSLAStatus: (jobId) =>
      apiClient.get(`/jobs/${jobId}/sla-status`),

    // Get recent breaches
    getRecentBreaches: (days = 7, limit = 50) =>
      apiClient.get('/sla-breaches/recent', { params: { days, limit } }),

    // Get dashboard data
    getDashboard: (days = 30) =>
      apiClient.get('/sla-compliance/dashboard', { params: { days } }),
  },

  // ============= Events =============
  events: {
    getAll: (params = {}) =>
      apiClient.get('/events', { params }),
    
    getById: (id) =>
      apiClient.get(`/events/${id}`),
    
    ingest: (data) =>
      apiClient.post('/events', data),
  },

  // ============= Alerts =============
  alerts: {
    getAll: (params = {}) =>
      apiClient.get('/alerts', { params }),
    
    getById: (id) =>
      apiClient.get(`/alerts/${id}`),
    
    acknowledge: (id) =>
      apiClient.post(`/alerts/${id}/acknowledge`),
    
    resolve: (id) =>
      apiClient.post(`/alerts/${id}/resolve`),
  },

  // ============= Evaluations =============
  evaluations: {
    getAll: (params = {}) =>
      apiClient.get('/evaluations', { params }),
    
    getById: (id) =>
      apiClient.get(`/evaluations/${id}`),
  },

  // ============= Dashboard & Metrics =============
  dashboard: {
    getMetrics: (periodDays = 30) =>
      apiClient.get('/dashboard/metrics', { params: { period_days: periodDays } }),
    
    getServiceHealth: () =>
      apiClient.get('/dashboard/service-health'),
    
    getAlertSummary: () =>
      apiClient.get('/dashboard/alert-summary'),

    getIndirectMonitoring: (params = {}) =>
      apiClient.get('/dashboard/service-health-indirect', { params }),
  },

  // ============= Reports =============
  reports: {
    getSLACompliance: (params = {}) =>
      apiClient.get('/reports/sla-compliance', { params }),
    
    getBreachAnalysis: (params = {}) =>
      apiClient.get('/reports/breach-analysis', { params }),
    
    exportCSV: (params = {}) =>
      apiClient.get('/reports/export/csv', { params, responseType: 'blob' }),
  },

  // ============= Customers =============
  customers: {
    getAll: (params = {}) =>
      apiClient.get('/customers', { params }),
    
    getById: (id) =>
      apiClient.get(`/customers/${id}`),
    
    create: (data) =>
      apiClient.post('/customers', data),
    
    update: (id, data) =>
      apiClient.put(`/customers/${id}`, data),
  },

  // ============= Integrations =============
  integrations: {
    getAll: () =>
      apiClient.get('/integrations'),
    
    getById: (id) =>
      apiClient.get(`/integrations/${id}`),
    
    create: (data) =>
      apiClient.post('/integrations', data),
    
    update: (id, data) =>
      apiClient.put(`/integrations/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/integrations/${id}`),
    
    test: (id) =>
      apiClient.post(`/integrations/${id}/test`),
  },

  // ============= Users =============
  users: {
    getAll: (params = {}) =>
      apiClient.get('/users', { params }),
    
    getById: (id) =>
      apiClient.get(`/users/${id}`),
    
    create: (data) =>
      apiClient.post('/users', data),
    
    update: (id, data) =>
      apiClient.put(`/users/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/users/${id}`),
  },
 
 // ============= Assets =============
  assets: {
    list: (params = {}) =>
      apiClient.get('/assets', { params }),

    get: (id) =>
      apiClient.get(`/assets/${id}`),

    create: (data) =>
      apiClient.post('/assets', data),

    update: (id, data) =>
      apiClient.put(`/assets/${id}`, data),

    delete: (id) =>
      apiClient.delete(`/assets/${id}`),

    getServices: (assetId) =>
      apiClient.get(`/assets/${assetId}/services`),

    addService: (assetId, data) =>
      apiClient.post(`/assets/${assetId}/services`, data),
  },

// ============= Jobs =============
  jobs: {
    getAll: (params = {}) =>
      apiClient.get('/jobs', { params }), 
    
    get: (id) =>
      apiClient.get(`/jobs/${id}`), 
    
    create: (data) =>
      apiClient.post('/jobs', data),
    
    update: (id, data) =>
      apiClient.put(`/jobs/${id}`, data), 
    
    delete: (id) =>
      apiClient.delete(`/jobs/${id}`),
    
    getSLAs: (jobId) =>
      apiClient.get(`/jobs/${jobId}/slas`),
  },
};

export default apiService;
export { apiClient, API_BASE_URL };
