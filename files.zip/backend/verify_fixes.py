#!/usr/bin/env python3
"""
Quick verification and fix script for job monitor issues
"""

import os
import sys

def check_files():
    """Check if fixes were applied"""
    
    print("=" * 80)
    print("Job Monitor Fix Verification")
    print("=" * 80)
    print()
    
    issues = []
    
    # Check 1: database_service.py
    print("1. Checking database_service.py...")
    try:
        with open('database_service.py', 'r') as f:
            content = f.read()
            
        if 'met_sla,' in content and 'INSERT INTO job_monitoring_results' in content:
            print("   ❌ ISSUE: Still has 'met_sla' in job_monitoring_results INSERT")
            print("   Line 1475 has: records_processed, log_entry, parsed_data, met_sla,")
            print("   Should be:     records_processed, log_entry, parsed_data,")
            issues.append("database_service.py not fixed")
        else:
            print("   ✅ Looks good - met_sla removed")
    except FileNotFoundError:
        print("   ❌ File not found")
        issues.append("database_service.py missing")
    
    print()
    
    # Check 2: log_connector.py
    print("2. Checking log_connector.py...")
    try:
        with open('log_connector.py', 'r') as f:
            content = f.read()
            
        if '_query_logs_from_files' in content:
            print("   ✅ Has _query_logs_from_files method")
        else:
            print("   ❌ ISSUE: Missing _query_logs_from_files method")
            print("   CustomConnector needs file reading implementation")
            issues.append("log_connector.py not fixed")
            
        if '# Simplified implementation' in content and 'return []' in content:
            # Check if it's still the placeholder
            lines = content.split('\n')
            for i, line in enumerate(lines):
                if 'class CustomConnector' in line:
                    # Check next 50 lines for placeholder
                    chunk = '\n'.join(lines[i:i+50])
                    if '# Simplified implementation' in chunk and 'return []' in chunk:
                        print("   ⚠️  WARNING: May still have placeholder code")
                        break
    except FileNotFoundError:
        print("   ❌ File not found")
        issues.append("log_connector.py missing")
    
    print()
    
    # Check 3: Connector configuration
    print("3. Checking connector configuration...")
    try:
        import sqlite3
        conn = sqlite3.connect('sla_portal.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT connector_id, log_server_type, connection_config 
            FROM log_server_connectors 
            WHERE is_active = 1
        """)
        
        row = cursor.fetchone()
        if row:
            connector_id, log_server_type, connection_config = row
            print(f"   Connector ID: {connector_id}")
            print(f"   Type: {log_server_type}")
            print(f"   Config: {connection_config}")
            
            if not connection_config or 'log_directory' not in connection_config:
                print("   ⚠️  WARNING: connection_config missing log_directory")
                print("   Should have: {'log_directory':'synthetic_logs','server_type':'mock'}")
        else:
            print("   ❌ No active connector found")
            issues.append("No active log connector")
        
        conn.close()
    except Exception as e:
        print(f"   ❌ Could not check database: {e}")
    
    print()
    print("=" * 80)
    
    if issues:
        print("❌ ISSUES FOUND:")
        for issue in issues:
            print(f"   - {issue}")
        print()
        print("ACTION REQUIRED:")
        print("1. Copy database_service_FIXED.py to database_service.py")
        print("2. Copy log_connector_FIXED.py to log_connector.py")
        print("3. Run this script again to verify")
        return False
    else:
        print("✅ ALL CHECKS PASSED!")
        print()
        print("You can now run:")
        print("  python api_service.py")
        print("  python job_monitor_daemon.py --interval 60")
        return True

def quick_fix():
    """Apply quick fixes"""
    print()
    print("=" * 80)
    print("Applying Quick Fixes")
    print("=" * 80)
    print()
    
    # Fix 1: database_service.py
    print("Fix 1: Removing met_sla from database_service.py...")
    try:
        with open('database_service.py', 'r') as f:
            content = f.read()
        
        # Find and fix the INSERT statement
        old_insert = """                INSERT INTO job_monitoring_results (
                    result_id, job_id, org_id, check_time, status,
                    execution_start_time, execution_end_time, duration_seconds,
                    records_processed, log_entry, parsed_data, met_sla,
                    error_message, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        
        new_insert = """                INSERT INTO job_monitoring_results (
                    result_id, job_id, org_id, check_time, status,
                    execution_start_time, execution_end_time, duration_seconds,
                    records_processed, log_entry, parsed_data,
                    error_message, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        
        if old_insert in content:
            content = content.replace(old_insert, new_insert)
            
            # Also need to remove the met_sla parameter
            content = content.replace(
                "                result.get('parsed_data'),\n                result.get('met_sla'),",
                "                result.get('parsed_data'),"
            )
            
            # Backup
            import shutil
            shutil.copy('database_service.py', 'database_service.py.backup')
            
            with open('database_service.py', 'w') as f:
                f.write(content)
            
            print("   ✅ Fixed database_service.py")
            print("   ✅ Backup saved to database_service.py.backup")
        else:
            print("   ⚠️  Could not find exact pattern - may already be fixed")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    print()
    print("Fix 2: Updating connector configuration...")
    try:
        import sqlite3
        conn = sqlite3.connect('sla_portal.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE log_server_connectors
            SET connection_config = '{"log_directory":"synthetic_logs","server_type":"mock"}'
            WHERE log_server_type = 'custom' AND is_active = 1
        """)
        
        conn.commit()
        print(f"   ✅ Updated {cursor.rowcount} connector(s)")
        conn.close()
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    print()
    print("=" * 80)
    print("Quick fixes applied! Run verification again:")
    print("  python verify_fixes.py")
    print("=" * 80)

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--fix':
        quick_fix()
    else:
        success = check_files()
        
        if not success:
            print()
            print("To apply quick fixes automatically, run:")
            print("  python verify_fixes.py --fix")
