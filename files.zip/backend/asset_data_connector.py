"""
Asset Data Connector
Imports asset metadata from external asset management APIs

Supports importing servers, databases, cloud resources, and other infrastructure assets.
"""

import sqlite3
import os
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from base_connector import BaseConnector

logger = logging.getLogger(__name__)


class AssetDataConnector(BaseConnector):
    """
    Connector for importing assets from external asset management systems
    
    Handles fetching asset data and bulk importing into the portal database
    with field mapping and transformation support.
    """
    
    def test_connection(self) -> bool:
        """
        Test connection to asset API
        
        Returns:
            True if health check succeeds, False otherwise
        """
        try:
            response = self._make_request('GET', '/api/health', timeout=5)
            data = response.json()
            
            # Check if response indicates healthy status
            status = data.get('status', '').lower()
            is_healthy = status in ['healthy', 'ok', 'up']
            
            if is_healthy:
                logger.info(f"✓ Asset API connection successful: {data}")
            else:
                logger.warning(f"Asset API returned unhealthy status: {data}")
            
            return is_healthy
            
        except Exception as e:
            logger.error(f"Asset API connection test failed: {str(e)}")
            return False
    
    def fetch_data(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch assets from API (wrapper for fetch_assets)
        
        Args:
            filters: Optional filter parameters
            
        Returns:
            List of asset objects
        """
        return self.fetch_assets(filters)
    
    def fetch_assets(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch assets from external API
        
        Args:
            filters: Optional filters such as:
                - asset_type: Filter by asset type (server, database, cloud)
                - environment: Filter by environment (production, staging, dev)
                - datacenter: Filter by datacenter location
                - status: Filter by status (active, inactive)
                
        Returns:
            List of asset dictionaries
            
        Example:
            assets = connector.fetch_assets({
                'environment': 'production',
                'asset_type': 'server'
            })
        """
        try:
            logger.info(f"Fetching assets with filters: {filters}")
            
            response = self._make_request('GET', '/api/assets', params=filters or {})
            data = response.json()
            
            # Handle different response formats
            if 'assets' in data:
                assets = data['assets']
            elif isinstance(data, list):
                assets = data
            else:
                logger.warning(f"Unexpected response format: {data}")
                assets = []
            
            logger.info(f"Fetched {len(assets)} assets")
            return assets
            
        except Exception as e:
            logger.error(f"Failed to fetch assets: {str(e)}")
            raise Exception(f"Failed to fetch assets: {str(e)}")
    
    def fetch_asset_by_id(self, asset_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch a specific asset by ID
        
        Args:
            asset_id: Unique identifier for the asset
            
        Returns:
            Asset dictionary or None if not found
        """
        try:
            logger.info(f"Fetching asset: {asset_id}")
            
            response = self._make_request('GET', f'/api/assets/{asset_id}')
            asset = response.json()
            
            logger.info(f"Retrieved asset: {asset.get('asset_id')}")
            return asset
            
        except Exception as e:
            logger.error(f"Failed to fetch asset {asset_id}: {str(e)}")
            return None
    
    def bulk_import_assets(
        self, 
        org_id: int, 
        assets: List[Dict[str, Any]], 
        field_mappings: List[Dict[str, Any]],
        db_path: str = None
    ) -> Dict[str, Any]:
        """
        Bulk import assets into portal database
        
        Args:
            org_id: Organization ID for imported assets
            assets: List of asset objects from API
            field_mappings: List of field mapping rules
            db_path: Optional database path (defaults to ../database/sla_portal.db)
            
        Returns:
            Dictionary with import results:
                - imported: Number of successfully imported assets
                - failed: Number of failed imports
                - errors: List of error details
                - asset_ids: List of created asset IDs
                
        Example:
            results = connector.bulk_import_assets(
                org_id=1,
                assets=fetched_assets,
                field_mappings=[
                    {
                        'source_field': 'host_name',
                        'target_field': 'name',
                        'transformation_rule': 'value.upper()',
                        'is_required': True
                    },
                    {
                        'source_field': 'machine_type',
                        'target_field': 'asset_type',
                        'transformation_rule': None,
                        'is_required': True
                    }
                ]
            )
        """
        results = {
            'imported': 0,
            'updated': 0,
            'failed': 0,
            'errors': [],
            'asset_ids': []
        }
        
        logger.info(f"Starting bulk import of {len(assets)} assets")
        
        for i, asset in enumerate(assets, 1):
            try:
                # Apply field mappings
                mapped_asset = self._apply_field_mappings(asset, field_mappings)
                
                # Debug: Log the mapped asset data
                logger.info(f"Mapped asset data: {mapped_asset}")
                
                # Validate required fields (use portal field names)
                if not mapped_asset.get('asset_name'):
                    raise Exception("Asset name is required")
                
                # Upsert into database (insert or update)
                asset_id, was_updated = self._upsert_asset(org_id, mapped_asset, db_path)
                
                if was_updated:
                    results['updated'] += 1
                else:
                    results['imported'] += 1
                    
                results['asset_ids'].append(asset_id)
                
                action = "Updated" if was_updated else "Imported"
                logger.info(f"{action} asset {i}/{len(assets)}: {mapped_asset.get('asset_name')} (ID: {asset_id})")
                
            except Exception as e:
                results['failed'] += 1
                error_detail = {
                    'asset': asset.get('asset_id', asset.get('host_name', 'unknown')),
                    'error': str(e),
                    'index': i
                }
                results['errors'].append(error_detail)
                logger.error(f"Failed to import asset {i}/{len(assets)}: {str(e)}")
        
        logger.info(f"Bulk import complete: {results['imported']} inserted, {results['updated']} updated, {results['failed']} failed")
        return results
    
    def _apply_field_mappings(
        self, 
        source_data: Dict[str, Any], 
        field_mappings: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Apply field mappings to transform source data to portal format
        
        Handles two types of mappings:
        1. Source field mappings: Maps API field → Portal field
        2. Constant value fields: Uses source_field as the constant value
        
        Args:
            source_data: Original data from API
            field_mappings: List of mapping rules with source_field and target_field
            
        Returns:
            Dictionary with portal field names as keys
        """
        mapped_data = {}
        
        # Constant fields that don't come from API
        constant_fields = {'status', 'onboarded_date'}
        
        for mapping in field_mappings:
            source_field = mapping.get('source_field')
            target_field = mapping.get('target_field')
            transformation_rule = mapping.get('transformation_rule')
            
            if not source_field or not target_field:
                continue
            
            # Check if this is a constant field (status, onboarded_date)
            if target_field in constant_fields:
                # For constant fields, source_field IS the value
                value = source_field
                logger.debug(f"Constant field {target_field}: using value '{value}'")
            else:
                # For regular fields, get value from source data
                value = source_data.get(source_field)
                
                # Apply transformation if specified
                if value and transformation_rule:
                    try:
                        # Simple transformations: upper(), lower(), strip()
                        if 'upper()' in transformation_rule:
                            value = str(value).upper()
                        elif 'lower()' in transformation_rule:
                            value = str(value).lower()
                        elif 'strip()' in transformation_rule:
                            value = str(value).strip()
                    except Exception as e:
                        logger.warning(f"Failed to apply transformation {transformation_rule}: {e}")
            
            # Set the mapped value
            mapped_data[target_field] = value if value is not None else ''
        
        logger.debug(f"Applied field mappings: {len(mapped_data)} fields mapped")
        return mapped_data
    
    def _upsert_asset(
        self, 
        org_id: int, 
        asset_data: Dict[str, Any],
        db_path: str = None
    ) -> tuple:
        """
        Insert or update asset in the database (upsert)
        
        Args:
            org_id: Organization ID
            asset_data: Mapped asset data
            db_path: Optional database path
            
        Returns:
            Tuple of (asset_id, was_updated: bool)
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            # Generate asset_id if not provided  
            # Use UUID-style ID since asset_id is TEXT PRIMARY KEY
            if not asset_data.get('asset_id'):
                import uuid
                asset_data['asset_id'] = f"ASSET-{uuid.uuid4().hex[:8].upper()}"
            
            # Check if asset already exists (by asset_name and org_id)
            cursor.execute('''
                SELECT asset_id FROM assets 
                WHERE asset_name = ? AND org_id = ?
            ''', (asset_data.get('asset_name'), org_id))
            
            existing = cursor.fetchone()
            
            if existing:
                # Update existing asset
                existing_asset_id = existing[0]
                
                # Get and normalize status value
                status_value = asset_data.get('status', 'Active')
                if status_value:
                    status_value = str(status_value).lower()
                else:
                    status_value = 'active'
                
                logger.info(f"Updating asset with status: '{status_value}' (from: '{asset_data.get('status')}')")
                
                cursor.execute('''
                    UPDATE assets 
                    SET asset_type = ?,
                        asset_owner = ?,
                        description = ?,
                        onboarded_date = ?,
                        status = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE asset_id = ? AND org_id = ?
                ''', (
                    asset_data.get('asset_type', 'Unknown'),
                    asset_data.get('asset_owner', 'Unknown'),
                    asset_data.get('description', 'N/A'),
                    asset_data.get('onboarded_date'),
                    status_value,
                    existing_asset_id,
                    org_id
                ))
                
                conn.commit()
                logger.info(f"✓ Updated asset: {asset_data.get('asset_name')} (ID: {existing_asset_id})")
                return (existing_asset_id, True)
            else:
                # Insert new asset
                
                # Get and normalize status value
                status_value = asset_data.get('status', 'Active')
                if status_value:
                    status_value = str(status_value).lower()
                else:
                    status_value = 'active'
                
                logger.info(f"Inserting asset with status: '{status_value}' (from: '{asset_data.get('status')}')")
                
                cursor.execute('''
                    INSERT INTO assets (
                        asset_id, org_id, asset_name, asset_type, asset_owner,
                        description, onboarded_date, status, 
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ''', (
                    asset_data.get('asset_id'),
                    org_id,
                    asset_data.get('asset_name', 'Unknown'),
                    asset_data.get('asset_type', 'Unknown'),
                    asset_data.get('asset_owner', 'Unknown'),
                    asset_data.get('description', 'N/A'),
                    asset_data.get('onboarded_date'),
                    status_value
                ))
                
                conn.commit()
                logger.info(f"✓ Inserted asset: {asset_data.get('asset_name')} (ID: {asset_data.get('asset_id')})")
                return (asset_data.get('asset_id'), False)
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Database error: {str(e)}")
            raise Exception(f"Database error: {str(e)}")
        finally:
            conn.close()
    
    # Keep old method name for backwards compatibility but call new upsert method
    def _insert_asset(
        self, 
        org_id: int, 
        asset_data: Dict[str, Any],
        db_path: str = None
    ) -> int:
        """
        Insert or update asset (wrapper for _upsert_asset)
        
        Returns:
            ID of created/updated asset
        """
        asset_id, was_updated = self._upsert_asset(org_id, asset_data, db_path)
        return asset_id
    
    def preview_mapping(
        self, 
        assets: List[Dict[str, Any]], 
        field_mappings: List[Dict[str, Any]],
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Preview how field mappings will transform assets
        
        Useful for testing mappings before bulk import
        
        Args:
            assets: List of asset objects from API
            field_mappings: List of field mapping rules
            limit: Maximum number of assets to preview (default: 5)
            
        Returns:
            List of preview objects with:
                - original: Original asset data
                - mapped: Transformed asset data
                - warnings: Any mapping warnings
        """
        previews = []
        
        for asset in assets[:limit]:
            try:
                mapped = self._apply_field_mappings(asset, field_mappings)
                
                preview = {
                    'original': asset,
                    'mapped': mapped,
                    'warnings': []
                }
                
                # Check for missing required fields
                for mapping in field_mappings:
                    if mapping.get('is_required'):
                        target = mapping['target_field']
                        if not mapped.get(target):
                            preview['warnings'].append(f"Required field '{target}' is missing or empty")
                
                previews.append(preview)
                
            except Exception as e:
                previews.append({
                    'original': asset,
                    'mapped': {},
                    'warnings': [f"Mapping failed: {str(e)}"]
                })
        
        return previews


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=" * 60)
    print("Asset Data Connector - Test Mode")
    print("=" * 60)
    print()
    
    # Create connector instance
    connector = AssetDataConnector(
        config_id=1,
        api_endpoint='http://localhost:5003/api'
    )
    
    # Test connection
    print("Testing connection...")
    if connector.test_connection():
        print("✓ Connection successful!")
    else:
        print("✗ Connection failed!")
        exit(1)
    
    print()
    
    # Fetch assets
    print("Fetching assets...")
    try:
        assets = connector.fetch_assets()
        print(f"✓ Fetched {len(assets)} assets")
        
        if assets:
            print("\nFirst asset:")
            for key, value in list(assets[0].items())[:5]:
                print(f"  {key}: {value}")
            print("  ...")
    except Exception as e:
        print(f"✗ Failed to fetch assets: {e}")
        exit(1)
    
    print()
    
    # Test with filters
    print("Testing filters (production environment)...")
    try:
        prod_assets = connector.fetch_assets({'environment': 'production'})
        print(f"✓ Found {len(prod_assets)} production assets")
    except Exception as e:
        print(f"✗ Filter test failed: {e}")
    
    print()
    
    # Preview mapping
    print("Testing field mapping preview...")
    sample_mappings = [
        {
            'source_field': 'host_name',
            'target_field': 'name',
            'transformation_rule': 'value.upper()',
            'is_required': True
        },
        {
            'source_field': 'machine_type',
            'target_field': 'asset_type',
            'transformation_rule': None,
            'is_required': True
        },
        {
            'source_field': 'responsible_team',
            'target_field': 'asset_owner',
            'transformation_rule': None,
            'is_required': False
        }
    ]
    
    previews = connector.preview_mapping(assets, sample_mappings, limit=2)
    print(f"✓ Generated {len(previews)} preview(s)")
    
    if previews:
        print("\nFirst preview:")
        print(f"  Original name: {previews[0]['original'].get('host_name')}")
        print(f"  Mapped name: {previews[0]['mapped'].get('name')}")
        if previews[0]['warnings']:
            print(f"  Warnings: {previews[0]['warnings']}")
    
    print()
    print("=" * 60)
    print("Test complete!")
    print("=" * 60)
    
    # Close connector
    connector.close()
