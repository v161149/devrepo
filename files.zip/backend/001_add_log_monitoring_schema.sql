-- Migration: Add Log-Based Monitoring Schema
-- Version: 001
-- Description: Add tables and columns for log-based SLA monitoring
-- Date: 2025-01-02

-- ============================================================================
-- PART 1: Create log_server_connectors table
-- ============================================================================

CREATE TABLE IF NOT EXISTS log_server_connectors (
    connector_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    connector_name TEXT NOT NULL,
    connector_description TEXT,
    log_server_type TEXT NOT NULL CHECK(log_server_type IN (
        'splunk',
        'elk',
        'cloudwatch',
        'stackdriver',
        'datadog_logs',
        'azure_monitor',
        'custom'
    )),
    api_endpoint_url TEXT NOT NULL,
    api_credentials TEXT,  -- JSON: encrypted credentials
    connection_config TEXT, -- JSON: additional configs (port, index, search params, etc.)
    is_active BOOLEAN DEFAULT 1 CHECK(is_active IN (0, 1)),
    last_test_time TIMESTAMP,
    last_test_status TEXT CHECK(last_test_status IN ('success', 'failed', NULL)),
    last_test_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    updated_by TEXT,
    
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL,
    
    UNIQUE(org_id, connector_name)
);

-- Index for fast lookups by org and type
CREATE INDEX IF NOT EXISTS idx_log_connectors_org_type 
ON log_server_connectors(org_id, log_server_type, is_active);

-- Index for active connectors
CREATE INDEX IF NOT EXISTS idx_log_connectors_active 
ON log_server_connectors(org_id, is_active);

-- ============================================================================
-- PART 2: Add log monitoring columns to services table
-- ============================================================================

-- Add service_identifier column (without UNIQUE - SQLite limitation)
ALTER TABLE services ADD COLUMN service_identifier TEXT;

-- Add log_template column (stores JSON template)
ALTER TABLE services ADD COLUMN log_template TEXT;

-- Add log_server_type column (references log_server_connectors.log_server_type)
ALTER TABLE services ADD COLUMN log_server_type TEXT;

-- Create unique index for service_identifier (alternative to UNIQUE constraint)
CREATE UNIQUE INDEX IF NOT EXISTS idx_services_identifier_unique 
ON services(service_identifier) 
WHERE service_identifier IS NOT NULL;

-- Index for services with log monitoring enabled
CREATE INDEX IF NOT EXISTS idx_services_log_monitoring 
ON services(org_id, log_server_type, is_active) 
WHERE service_identifier IS NOT NULL;

-- ============================================================================
-- PART 3: Add log monitoring columns to jobs table
-- ============================================================================

-- Add job_identifier column (without UNIQUE - SQLite limitation)
ALTER TABLE jobs ADD COLUMN job_identifier TEXT;

-- Add log_template column (stores JSON template)
ALTER TABLE jobs ADD COLUMN log_template TEXT;

-- Add log_server_type column (references log_server_connectors.log_server_type)
ALTER TABLE jobs ADD COLUMN log_server_type TEXT;

-- Create unique index for job_identifier (alternative to UNIQUE constraint)
CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_identifier_unique 
ON jobs(job_identifier) 
WHERE job_identifier IS NOT NULL;

-- Index for jobs with log monitoring enabled
CREATE INDEX IF NOT EXISTS idx_jobs_log_monitoring 
ON jobs(org_id, log_server_type, is_active) 
WHERE job_identifier IS NOT NULL;

-- ============================================================================
-- PART 4: Create service_monitoring_results table
-- ============================================================================

CREATE TABLE IF NOT EXISTS service_monitoring_results (
    result_id TEXT PRIMARY KEY,
    service_id TEXT NOT NULL,
    org_id TEXT NOT NULL,
    check_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT CHECK(status IN ('up', 'down', 'degraded', 'unknown')),
    response_time_ms REAL,
    log_entry TEXT,  -- Raw log entry found (JSON)
    parsed_data TEXT,  -- Parsed fields from log (JSON)
    is_healthy BOOLEAN,
    error_message TEXT,
    metadata TEXT,  -- Additional monitoring metadata (JSON)
    
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE CASCADE,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

-- Index for SLA calculations (by service, most recent first)
CREATE INDEX IF NOT EXISTS idx_service_monitoring_results_sla 
ON service_monitoring_results(service_id, check_time DESC);

-- Index for time-based queries
CREATE INDEX IF NOT EXISTS idx_service_monitoring_results_time 
ON service_monitoring_results(org_id, check_time DESC);

-- Index for health status queries
CREATE INDEX IF NOT EXISTS idx_service_monitoring_results_health 
ON service_monitoring_results(service_id, is_healthy, check_time DESC);

-- ============================================================================
-- PART 5: Create job_monitoring_results table
-- ============================================================================

CREATE TABLE IF NOT EXISTS job_monitoring_results (
    result_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    org_id TEXT NOT NULL,
    check_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT CHECK(status IN ('success', 'failed', 'running', 'not_run', 'unknown')),
    execution_start_time TIMESTAMP,
    execution_end_time TIMESTAMP,
    duration_seconds REAL,
    records_processed INTEGER,
    log_entry TEXT,  -- Raw log entry found (JSON)
    parsed_data TEXT,  -- Parsed fields from log (JSON)
    met_sla BOOLEAN,
    error_message TEXT,
    metadata TEXT,  -- Additional monitoring metadata (JSON)
    
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id) ON DELETE CASCADE
);

-- Index for SLA calculations (by job, most recent first)
CREATE INDEX IF NOT EXISTS idx_job_monitoring_results_sla 
ON job_monitoring_results(job_id, check_time DESC);

-- Index for time-based queries
CREATE INDEX IF NOT EXISTS idx_job_monitoring_results_time 
ON job_monitoring_results(org_id, check_time DESC);

-- Index for SLA compliance queries
CREATE INDEX IF NOT EXISTS idx_job_monitoring_results_sla_status 
ON job_monitoring_results(job_id, met_sla, check_time DESC);

-- ============================================================================
-- PART 6: Record migration in schema_migrations table
-- ============================================================================

INSERT INTO schema_migrations (migration_id, migration_name, version, status)
VALUES (
    '001-log-monitoring-' || strftime('%Y%m%d%H%M%S', 'now'),
    'Add Log-Based Monitoring Schema',
    '001',
    'applied'
);

-- ============================================================================
-- Migration Complete
-- ============================================================================

-- Summary of changes:
-- 1. Created log_server_connectors table
-- 2. Added service_identifier, log_template, log_server_type to services
-- 3. Added job_identifier, log_template, log_server_type to jobs
-- 4. Created service_monitoring_results table
-- 5. Created job_monitoring_results table
-- 6. Added appropriate indexes for performance
