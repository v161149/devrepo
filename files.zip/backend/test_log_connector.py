#!/usr/bin/env python3
"""
Debug script to test log connector directly
"""

import sys
import os
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_log_connector():
    """Test the log connector directly"""
    
    print("=" * 80)
    print("LOG CONNECTOR DEBUG TEST")
    print("=" * 80)
    print()
    
    # Import after adding to path
    from log_connector import get_log_connector
    
    # Create connector config (same as database)
    connector_config = {
        'api_endpoint_url': 'http://localhost:8000',
        'api_credentials': '{}',
        'connection_config': '{"log_directory":"synthetic_logs","server_type":"mock"}',
        'log_server_type': 'custom'
    }
    
    print("Step 1: Create connector")
    print(f"  Config: {connector_config['connection_config']}")
    
    try:
        connector = get_log_connector(connector_config)
        print(f"  ✅ Connector created: {type(connector).__name__}")
    except Exception as e:
        print(f"  ❌ Failed to create connector: {e}")
        return
    
    print()
    
    # Test query
    identifier = "DB-SYNC-HOURLY-002"
    time_range_minutes = 60
    
    print(f"Step 2: Query logs")
    print(f"  Identifier: {identifier}")
    print(f"  Time range: {time_range_minutes} minutes")
    
    # Calculate time range
    now = datetime.now()
    print(f"  Current time: {now.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Looking for logs between:")
    print(f"    {(now - timedelta(minutes=time_range_minutes)).strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"    {now.strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    try:
        logs = connector.query_logs(identifier, time_range_minutes)
        print(f"  ✅ Query successful")
        print(f"  ✅ Fetched {len(logs)} logs")
        
        if logs:
            print()
            print("First 3 logs:")
            for i, log in enumerate(logs[:3], 1):
                print(f"  {i}. timestamp: {log.get('timestamp')}")
                print(f"     status: {log.get('status')}")
                print(f"     duration: {log.get('duration_seconds')}s")
                print()
        else:
            print()
            print("⚠️  No logs returned!")
            print()
            print("Debugging why:")
            
            # Check if directory exists
            log_dir = "synthetic_logs"
            if not os.path.exists(log_dir):
                print(f"  ❌ Directory doesn't exist: {log_dir}")
            else:
                print(f"  ✅ Directory exists: {log_dir}")
                
                # List files
                files = [f for f in os.listdir(log_dir) if f.endswith('.log')]
                print(f"  ✅ Found {len(files)} .log files")
                
                # Check for our file
                matching = [f for f in files if identifier in f]
                if matching:
                    print(f"  ✅ Found matching file: {matching[0]}")
                    
                    # Read and check timestamps
                    import json
                    log_file = os.path.join(log_dir, matching[0])
                    with open(log_file, 'r') as f:
                        entries = []
                        for line in f:
                            try:
                                entries.append(json.loads(line.strip()))
                            except:
                                pass
                    
                    print(f"  ✅ File has {len(entries)} entries")
                    print()
                    print("  Checking timestamps:")
                    
                    in_range_count = 0
                    start_check = now - timedelta(minutes=time_range_minutes)
                    
                    for entry in entries[:5]:  # Check first 5
                        ts_str = entry.get('timestamp')
                        try:
                            ts = datetime.fromisoformat(ts_str)
                            in_range = start_check <= ts <= now
                            if in_range:
                                in_range_count += 1
                            status = "✅ IN RANGE" if in_range else "❌ TOO OLD"
                            print(f"    {ts_str}: {status}")
                        except:
                            print(f"    {ts_str}: ❌ INVALID FORMAT")
                    
                    if entries:
                        print(f"  ... ({len(entries)} total entries)")
                        print(f"  ✅ {in_range_count} entries in time range")
                else:
                    print(f"  ❌ No files match identifier: {identifier}")
                    print(f"  Files found: {files}")
            
    except Exception as e:
        print(f"  ❌ Query failed: {e}")
        import traceback
        traceback.print_exc()
    
    print()
    print("=" * 80)
    print("CONCLUSION")
    print("=" * 80)
    print()
    
    if logs and len(logs) > 0:
        print("✅ Log connector is working!")
        print("   The issue is elsewhere (job_monitor config?)")
    else:
        print("❌ Log connector returned 0 logs")
        print("   Check the debugging info above")
    
    print()

if __name__ == "__main__":
    test_log_connector()
