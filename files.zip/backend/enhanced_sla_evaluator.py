"""
SLA Evaluator Service - Enhanced Version
Evaluates SLAs using field mappings and creates compliance records

This replaces the simple boolean approach with per-SLA compliance tracking
"""

import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
import uuid

logger = logging.getLogger(__name__)


class EnhancedSLAEvaluator:
    """
    Enhanced SLA Evaluator that:
    1. Evaluates each SLA independently
    2. Uses field mappings to extract values from log data
    3. Creates individual compliance records per SLA
    4. Supports multiple SLA types (uptime, response_time, completeness, etc.)
    """
    
    def __init__(self, db_service):
        """
        Initialize SLA evaluator
        
        Args:
            db_service: DatabaseService instance
        """
        self.db = db_service
        
    def evaluate_service_slas(self, service_id: str, monitoring_result_id: str, 
                              parsed_log_data: Dict[str, Any], org_id: str) -> List[Dict]:
        """
        Evaluate all SLAs for a service monitoring result
        
        Args:
            service_id: Service ID
            monitoring_result_id: ID of the monitoring result
            parsed_log_data: Parsed data from log entry
            org_id: Organization ID
            
        Returns:
            List of compliance results
        """
        try:
            # Get all SLAs for this service
            slas = self._get_service_slas(service_id, org_id)
            
            if not slas:
                logger.info(f"No SLAs found for service {service_id}")
                return []
            
            compliance_results = []
            
            # Evaluate each SLA independently
            for sla in slas:
                try:
                    compliance = self._evaluate_single_sla(
                        sla=sla,
                        parsed_data=parsed_log_data,
                        result_id=monitoring_result_id,
                        org_id=org_id,
                        entity_type='service'
                    )
                    
                    if compliance:
                        # Store compliance result
                        self._create_service_compliance_record(compliance)
                        compliance_results.append(compliance)
                        
                        logger.info(
                            f"SLA '{sla['name']}' for service {service_id}: "
                            f"{'MET' if compliance['met_sla'] else 'BREACHED'} "
                            f"(measured: {compliance['measured_value']}, target: {compliance['target_value']})"
                        )
                    
                except Exception as e:
                    logger.error(f"Error evaluating SLA {sla.get('sla_id')}: {e}")
                    continue
            
            return compliance_results
            
        except Exception as e:
            logger.error(f"Error evaluating service SLAs: {e}")
            return []
    
    def evaluate_job_slas(self, job_id: str, monitoring_result_id: str,
                         parsed_log_data: Dict[str, Any], org_id: str) -> List[Dict]:
        """
        Evaluate all SLAs for a job monitoring result
        
        Args:
            job_id: Job ID
            monitoring_result_id: ID of the monitoring result
            parsed_log_data: Parsed data from log entry
            org_id: Organization ID
            
        Returns:
            List of compliance results
        """
        try:
            # Get all SLAs for this job
            slas = self._get_job_slas(job_id, org_id)
            
            if not slas:
                logger.info(f"No SLAs found for job {job_id}")
                return []
            
            compliance_results = []
            
            # Evaluate each SLA independently
            for sla in slas:
                try:
                    compliance = self._evaluate_single_sla(
                        sla=sla,
                        parsed_data=parsed_log_data,
                        result_id=monitoring_result_id,
                        org_id=org_id,
                        entity_type='job'
                    )
                    
                    if compliance:
                        # Store compliance result
                        self._create_job_compliance_record(compliance)
                        compliance_results.append(compliance)
                        
                        logger.info(
                            f"SLA '{sla['name']}' for job {job_id}: "
                            f"{'MET' if compliance['met_sla'] else 'BREACHED'} "
                            f"(measured: {compliance['measured_value']}, target: {compliance['target_value']})"
                        )
                    
                except Exception as e:
                    logger.error(f"Error evaluating SLA {sla.get('sla_id')}: {e}")
                    continue
            
            return compliance_results
            
        except Exception as e:
            logger.error(f"Error evaluating job SLAs: {e}")
            return []
    
    def _evaluate_single_sla(self, sla: Dict, parsed_data: Dict[str, Any],
                            result_id: str, org_id: str, entity_type: str) -> Optional[Dict]:
        """
        Evaluate a single SLA using field mappings
        
        Args:
            sla: SLA configuration
            parsed_data: Parsed log data
            result_id: Monitoring result ID
            org_id: Organization ID
            entity_type: 'service' or 'job'
            
        Returns:
            Compliance result dict or None if cannot evaluate
        """
        try:
            # Get field mapping
            field_mapping = self._get_field_mapping(sla)
            
            if not field_mapping:
                logger.warning(f"No field mapping for SLA {sla['sla_id']}, using default evaluation")
                return self._evaluate_without_mapping(sla, parsed_data, result_id, org_id)
            
            # Get SLA type
            sla_type = sla.get('metric_type', 'uptime')
            
            # Route to appropriate evaluator based on SLA type
            evaluators = {
                'uptime': self._evaluate_uptime_sla,
                'response_time': self._evaluate_response_time_sla,
                'error_rate': self._evaluate_error_rate_sla,
                'success_rate': self._evaluate_success_rate_sla,
                'throughput': self._evaluate_throughput_sla,
                'resolution_time': self._evaluate_resolution_time_sla,
                'execution_window': self._evaluate_execution_window_sla,  # NEW!
                'custom': self._evaluate_custom_sla
            }
            
            evaluator = evaluators.get(sla_type, self._evaluate_generic_sla)
            
            compliance = evaluator(sla, parsed_data, field_mapping, result_id, org_id)
            
            return compliance
            
        except Exception as e:
            logger.error(f"Error in _evaluate_single_sla: {e}")
            return None
    
    def _evaluate_uptime_sla(self, sla: Dict, parsed_data: Dict, 
                            field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate uptime/availability SLA"""
        
        # Extract status from log using field mapping
        status_field = field_mapping.get('status', 'status')
        status = parsed_data.get(status_field, 'unknown').lower()
        
        # Determine if up or down
        up_values = ['up', 'running', 'active', 'healthy', 'ok', 'available']
        is_up = status in up_values
        
        # For uptime, measured_value is 100 if up, 0 if down
        measured_value = 100.0 if is_up else 0.0
        target_value = float(sla.get('target_value', 99.9))
        
        met_sla = measured_value >= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'uptime',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'status': status,
                'expected': 'up',
                'target': target_value
            }) if not met_sla else None
        }
    
    def _evaluate_response_time_sla(self, sla: Dict, parsed_data: Dict,
                                   field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate response time SLA"""
        
        # Extract response time from log
        response_field = field_mapping.get('response_time_ms', 'response_time')
        measured_value = float(parsed_data.get(response_field, 0))
        
        # Target is maximum allowed response time
        target_value = float(sla.get('target_value', 200))
        
        # For response time, lower is better
        met_sla = measured_value <= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'response_time',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'response_time_ms': measured_value,
                'target_ms': target_value,
                'overage_ms': measured_value - target_value
            }) if not met_sla else None
        }
    
    def _evaluate_error_rate_sla(self, sla: Dict, parsed_data: Dict,
                                field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate error rate SLA"""
        
        # Try to get error_rate directly
        error_rate_field = field_mapping.get('error_rate', 'error_rate')
        measured_value = parsed_data.get(error_rate_field)
        
        # If not available, calculate from error_count / total_requests
        if measured_value is None:
            error_count = float(parsed_data.get(field_mapping.get('error_count', 'error_count'), 0))
            total_requests = float(parsed_data.get(field_mapping.get('total_requests', 'total_requests'), 1))
            measured_value = (error_count / total_requests * 100) if total_requests > 0 else 0
        else:
            measured_value = float(measured_value)
        
        target_value = float(sla.get('target_value', 1.0))
        
        # For error rate, lower is better
        met_sla = measured_value <= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'error_rate',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'error_rate': measured_value,
                'target': target_value
            }) if not met_sla else None
        }
    
    def _evaluate_success_rate_sla(self, sla: Dict, parsed_data: Dict,
                                  field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate success rate SLA (for jobs)"""
        
        # Extract status
        status_field = field_mapping.get('status', 'status')
        status = parsed_data.get(status_field, 'unknown').lower()
        
        # Determine if successful
        success_values = ['success', 'completed', 'done', 'finished', 'ok']
        is_success = status in success_values
        
        measured_value = 100.0 if is_success else 0.0
        target_value = float(sla.get('target_value', 99.0))
        
        met_sla = measured_value >= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'success_rate',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'status': status,
                'expected': 'success',
                'target': target_value
            }) if not met_sla else None
        }
    
    def _evaluate_throughput_sla(self, sla: Dict, parsed_data: Dict,
                                field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate throughput SLA"""
        
        throughput_field = field_mapping.get('throughput', 'throughput')
        measured_value = float(parsed_data.get(throughput_field, 0))
        target_value = float(sla.get('target_value', 100))
        
        # For throughput, higher is better
        met_sla = measured_value >= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'throughput',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'throughput': measured_value,
                'target': target_value
            }) if not met_sla else None
        }
    
    def _evaluate_resolution_time_sla(self, sla: Dict, parsed_data: Dict,
                                     field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate resolution time SLA"""
        
        resolution_field = field_mapping.get('resolution_time', 'resolution_time')
        measured_value = float(parsed_data.get(resolution_field, 0))
        target_value = float(sla.get('target_value', 60))
        
        # For resolution time, lower is better
        met_sla = measured_value <= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'resolution_time',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'resolution_time': measured_value,
                'target': target_value
            }) if not met_sla else None
        }
    

    def _create_compliance_result(
        self,
        sla: Dict[str, Any],
        result_id: str,
        org_id: str,
        met_sla: bool,
        measured_value: float,
        target_value: float,
        details: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Create a standardized SLA compliance result dictionary
        
        This method creates consistent compliance result objects for database storage.
        Called throughout the evaluator when evaluating any SLA type.
        
        Args:
            sla: SLA configuration dictionary
            result_id: Unique ID for this monitoring result
            org_id: Organization ID
            met_sla: Boolean indicating if SLA was met
            measured_value: Actual measured metric value
            target_value: Target threshold from SLA
            details: Optional additional details (breach info, errors, etc.)
            
        Returns:
            Dictionary ready for database insertion
        """
        import uuid
        import json
        from datetime import datetime
        
        # Calculate breach severity if SLA not met
        breach_severity = None
        if not met_sla:
            if measured_value == 0:
                breach_severity = 'critical'
            else:
                miss_percentage = ((target_value - measured_value) / target_value) * 100
                if miss_percentage >= 10:
                    breach_severity = 'critical'
                elif miss_percentage >= 5:
                    breach_severity = 'major'
                else:
                    breach_severity = 'minor'
        
        # Format breach details
        breach_details = None
        if not met_sla and details:
            breach_details = json.dumps(details)
        
        # Create compliance result
        return {
            'compliance_id': f"comp-{uuid.uuid4().hex[:12]}",
            'result_id': result_id,
            'sla_id': sla.get('sla_id'),
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'threshold_value': target_value,
            'measurement_type': sla.get('metric_type', 'unknown'),
            'breach_severity': breach_severity,
            'breach_details': breach_details,
            'evaluated_at': datetime.utcnow().isoformat()
        }

    def _evaluate_execution_window_sla(self, sla: Dict, parsed_data: Dict,
                                      field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """
        Evaluate Execution Window SLA - checks job timing compliance
        
        Validates:
        1. Job started within tolerance of scheduled time
        2. Job completed within expected duration (+ tolerance)
        3. Job finished before next scheduled execution (if enabled)
        
        Args:
            sla: SLA configuration
            parsed_data: Parsed log data with start_time, end_time, duration_seconds
            field_mapping: Field mapping configuration
            result_id: Monitoring result ID
            org_id: Organization ID
            
        Returns:
            Compliance result dictionary
        """
        from croniter import croniter
        from datetime import datetime, timedelta
        
        try:
            # Get the job to access schedule and expected_duration
            job_id = sla.get('job_id')
            if not job_id:
                logger.error("Execution Window SLA must be linked to a job")
                return self._create_compliance_result(
                    sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                    details={'error': 'No job_id configured'}
                )
            
            job = self.db.get_job(job_id)
            if not job:
                logger.error(f"Job {job_id} not found")
                return self._create_compliance_result(
                    sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                    details={'error': f'Job {job_id} not found'}
                )
            
            # Get job configuration
            expected_duration = job.get('expected_duration')
            job_schedule = job.get('schedule')
            
            if not expected_duration:
                logger.error(f"Job {job_id} has no expected_duration configured")
                return self._create_compliance_result(
                    sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                    details={'error': 'Job missing expected_duration'}
                )
            
            if not job_schedule:
                logger.error(f"Job {job_id} has no schedule configured")
                return self._create_compliance_result(
                    sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                    details={'error': 'Job missing schedule'}
                )
            
            # Extract field names from mapping
            start_time_field = field_mapping.get('start_time_field', 'start_time')
            end_time_field = field_mapping.get('end_time_field', 'end_time')
            duration_field = field_mapping.get('duration_field', 'duration_seconds')
            start_tolerance_minutes = field_mapping.get('start_tolerance_minutes', 5)
            duration_tolerance_pct = field_mapping.get('duration_tolerance_percentage', 10)
            check_no_overlap = field_mapping.get('check_no_overlap', True)
            
            # Get values from parsed data
            actual_start_str = parsed_data.get(start_time_field)
            actual_end_str = parsed_data.get(end_time_field)
            actual_duration = parsed_data.get(duration_field, 0)
            
            if not actual_start_str or not actual_end_str:
                logger.warning(f"Missing timing fields in log data: start={actual_start_str}, end={actual_end_str}")
                return self._create_compliance_result(
                    sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                    details={'error': 'Missing start_time or end_time in log data'}
                )
            
            # Parse timestamps
            try:
                actual_start = self._parse_timestamp(actual_start_str)
                actual_end = self._parse_timestamp(actual_end_str)
            except Exception as e:
                logger.error(f"Error parsing timestamps: {e}")
                return self._create_compliance_result(
                    sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                    details={'error': f'Invalid timestamp format: {e}'}
                )
            
            # Find the closest scheduled time using cron schedule
            scheduled_start = self._find_closest_scheduled_time(actual_start, job_schedule)
            
            # Check 1: Start Time Compliance
            start_delay_seconds = (actual_start - scheduled_start).total_seconds()
            start_delay_minutes = abs(start_delay_seconds) / 60
            start_ok = start_delay_minutes <= start_tolerance_minutes
            
            # Check 2: Duration Compliance
            max_allowed_duration = expected_duration * (1 + duration_tolerance_pct / 100)
            duration_ok = actual_duration <= max_allowed_duration
            
            # Check 3: No Overlap (if enabled)
            if check_no_overlap:
                next_scheduled = self._get_next_scheduled_time(scheduled_start, job_schedule)
                overlap_ok = actual_end < next_scheduled
            else:
                overlap_ok = True
            
            # Overall compliance
            is_compliant = start_ok and duration_ok and overlap_ok
            
            # Calculate a compliance score (100 if all pass, 0 if any fail)
            compliance_percentage = 100.0 if is_compliant else 0.0
            
            # Build detailed result
            details = {
                'scheduled_start': scheduled_start.isoformat(),
                'actual_start': actual_start.isoformat(),
                'actual_end': actual_end.isoformat(),
                'start_delay_minutes': round(start_delay_minutes, 2),
                'start_ok': start_ok,
                'actual_duration_seconds': actual_duration,
                'expected_duration_seconds': expected_duration,
                'max_allowed_duration_seconds': int(max_allowed_duration),
                'duration_ok': duration_ok,
                'overlap_ok': overlap_ok,
                'overall_compliant': is_compliant
            }
            
            # Add violation reason if not compliant
            if not is_compliant:
                reasons = []
                if not start_ok:
                    reasons.append(f"Started {start_delay_minutes:.1f} min {'late' if start_delay_seconds > 0 else 'early'}")
                if not duration_ok:
                    reasons.append(f"Took {actual_duration}s (max {int(max_allowed_duration)}s)")
                if not overlap_ok:
                    reasons.append("Overlapped with next execution")
                details['violation_reason'] = "; ".join(reasons)
            
            return self._create_compliance_result(
                sla=sla,
                result_id=result_id,
                org_id=org_id,
                met_sla=is_compliant,
                measured_value=compliance_percentage,
                target_value=sla.get('target_value', 99.0),
                details=details
            )
            
        except Exception as e:
            logger.error(f"Error evaluating execution window SLA: {e}", exc_info=True)
            return self._create_compliance_result(
                sla, result_id, org_id, False, 0, sla.get('target_value', 99.0),
                details={'error': str(e)}
            )
    
    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """Parse ISO 8601 timestamp string to datetime object"""
        if isinstance(timestamp_str, datetime):
            return timestamp_str
        # Handle ISO 8601 format with Z or timezone
        timestamp_str = str(timestamp_str).replace('Z', '+00:00')
        return datetime.fromisoformat(timestamp_str)
    
    def _find_closest_scheduled_time(self, actual_start: datetime, cron_schedule: str) -> datetime:
        """Find the scheduled time closest to actual start time using cron"""
        from croniter import croniter
        from datetime import timedelta
        
        # Start from 1 hour before actual start
        base_time = actual_start - timedelta(hours=1)
        
        try:
            cron = croniter(cron_schedule, base_time)
            
            # Get next few scheduled times
            scheduled_times = []
            for _ in range(5):
                scheduled_times.append(cron.get_next(datetime))
            
            # Find the closest one to actual_start
            closest = min(scheduled_times, key=lambda x: abs((x - actual_start).total_seconds()))
            return closest
            
        except Exception as e:
            logger.error(f"Error parsing cron schedule '{cron_schedule}': {e}")
            # Fallback: return actual_start rounded to nearest hour
            return actual_start.replace(minute=0, second=0, microsecond=0)
    
    def _get_next_scheduled_time(self, scheduled_start: datetime, cron_schedule: str) -> datetime:
        """Get the next scheduled execution after the given time"""
        from croniter import croniter
        from datetime import timedelta
        
        try:
            cron = croniter(cron_schedule, scheduled_start)
            return cron.get_next(datetime)
        except Exception as e:
            logger.error(f"Error getting next scheduled time: {e}")
            # Fallback: add 1 day
            return scheduled_start + timedelta(days=1)
    
    def _evaluate_custom_sla(self, sla: Dict, parsed_data: Dict,
                           field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Evaluate custom SLA type"""
        return self._evaluate_generic_sla(sla, parsed_data, field_mapping, result_id, org_id)
    
    def _evaluate_generic_sla(self, sla: Dict, parsed_data: Dict,
                            field_mapping: Dict, result_id: str, org_id: str) -> Dict:
        """Generic SLA evaluator (fallback)"""
        
        # Try to extract a value from the primary field
        primary_field = field_mapping.get('primary_field', 'value')
        measured_value = float(parsed_data.get(primary_field, 0))
        target_value = float(sla.get('target_value', 100))
        
        # Assume higher is better for generic
        met_sla = measured_value >= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'custom',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'measured': measured_value,
                'target': target_value
            }) if not met_sla else None
        }
    
    def _evaluate_without_mapping(self, sla: Dict, parsed_data: Dict,
                                  result_id: str, org_id: str) -> Dict:
        """Fallback evaluation when no field mapping is configured"""
        
        # Simple status-based evaluation
        status = parsed_data.get('status', 'unknown').lower()
        up_values = ['up', 'running', 'success', 'ok', 'healthy']
        is_up = status in up_values
        
        measured_value = 100.0 if is_up else 0.0
        target_value = float(sla.get('target_value', 99.0))
        met_sla = measured_value >= target_value
        
        return {
            'compliance_id': f"COMP-{uuid.uuid4().hex[:16].upper()}",
            'result_id': result_id,
            'sla_id': sla['sla_id'],
            'org_id': org_id,
            'met_sla': met_sla,
            'measured_value': measured_value,
            'target_value': target_value,
            'measurement_type': 'default',
            'breach_severity': self._calculate_breach_severity(met_sla, measured_value, target_value, sla),
            'breach_details': json.dumps({
                'status': status,
                'note': 'Evaluated without field mapping'
            }) if not met_sla else None
        }
    
    def _calculate_breach_severity(self, met_sla: bool, measured_value: float,
                                   target_value: float, sla: Dict) -> str:
        """Calculate breach severity based on how far from target"""
        
        if met_sla:
            return 'none'
        
        # Try to get metadata for thresholds
        metadata = sla.get('metadata')
        if metadata:
            try:
                meta = json.loads(metadata) if isinstance(metadata, str) else metadata
                warning_threshold = meta.get('warning_threshold')
                critical_threshold = meta.get('critical_threshold')
                
                if critical_threshold is not None and measured_value <= critical_threshold:
                    return 'critical'
                elif warning_threshold is not None and measured_value <= warning_threshold:
                    return 'warning'
            except:
                pass
        
        # Default: breach is critical
        return 'critical'
    
    def _get_field_mapping(self, sla: Dict) -> Optional[Dict]:
        """Extract field mapping from SLA configuration"""
        
        field_mapping_json = sla.get('log_field_mapping')
        
        if not field_mapping_json:
            return None
        
        try:
            if isinstance(field_mapping_json, str):
                return json.loads(field_mapping_json)
            elif isinstance(field_mapping_json, dict):
                return field_mapping_json
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing field mapping: {e}")
            return None
        
        return None
    
    def _get_service_slas(self, service_id: str, org_id: str) -> List[Dict]:
        """Get all active SLAs for a service"""
        
        with self.db.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM slas
                WHERE service_id = ?
                AND org_id = ?
                AND is_active = 1
            """, (service_id, org_id))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def _get_job_slas(self, job_id: str, org_id: str) -> List[Dict]:
        """Get all active SLAs for a job"""
        
        with self.db.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM slas
                WHERE job_id = ?
                AND org_id = ?
                AND is_active = 1
            """, (job_id, org_id))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def _create_service_compliance_record(self, compliance: Dict):
        """Store service SLA compliance record in database"""
        
        with self.db.get_connection() as conn:
            conn.execute("""
                INSERT INTO service_sla_compliance (
                    compliance_id, result_id, sla_id, org_id,
                    met_sla, measured_value, target_value,
                    measurement_type, breach_severity, breach_details
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                compliance['compliance_id'],
                compliance['result_id'],
                compliance['sla_id'],
                compliance['org_id'],
                compliance['met_sla'],
                compliance['measured_value'],
                compliance['target_value'],
                compliance['measurement_type'],
                compliance['breach_severity'],
                compliance.get('breach_details')
            ))
    
    def _create_job_compliance_record(self, compliance: Dict):
        """Store job SLA compliance record in database"""
        
        with self.db.get_connection() as conn:
            conn.execute("""
                INSERT INTO job_sla_compliance (
                    compliance_id, result_id, sla_id, org_id,
                    met_sla, measured_value, target_value,
                    measurement_type, breach_severity, breach_details
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                compliance['compliance_id'],
                compliance['result_id'],
                compliance['sla_id'],
                compliance['org_id'],
                compliance['met_sla'],
                compliance['measured_value'],
                compliance['target_value'],
                compliance['measurement_type'],
                compliance['breach_severity'],
                compliance.get('breach_details')
            ))
