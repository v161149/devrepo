import os
import sys

log_dir = 'synthetic_logs'
identifier = 'DB-SYNC-HOURLY-002'

print("=" * 80)
print("LOG FILE DEBUGGING")
print("=" * 80)
print()

print(f"Current directory: {os.getcwd()}")
print(f"Looking for logs in: {os.path.abspath(log_dir)}")
print(f"Searching for identifier: {identifier}")
print()

# Check if directory exists
if not os.path.exists(log_dir):
    print(f"❌ Directory not found: {log_dir}")
    print()
    print("Create it with:")
    print(f"  mkdir {log_dir}")
    sys.exit(1)

print(f"✅ Directory exists: {log_dir}")
print()

# List all files
all_files = os.listdir(log_dir)
print(f"All files in directory ({len(all_files)}):")
for f in all_files:
    size = os.path.getsize(os.path.join(log_dir, f))
    print(f"  - {f} ({size} bytes)")
print()

# Find matching files
matching = [f for f in all_files if identifier in f and f.endswith('.log')]

if not matching:
    print(f"❌ No matching files found for identifier: {identifier}")
    print()
    print("Files should contain the identifier in the name:")
    print(f"  - job_{identifier}.log")
    print(f"  - service_{identifier}.log")
    print(f"  - {identifier}.log")
    sys.exit(1)

print(f"✅ Found {len(matching)} matching file(s):")
for f in matching:
    print(f"  - {f}")
print()

# Try to read the first matching file
log_file = os.path.join(log_dir, matching[0])
print(f"Reading: {log_file}")
print()

try:
    with open(log_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    print(f"✅ Successfully read file")
    print(f"   Lines: {len(lines)}")
    print()
    
    if lines:
        print("First 3 lines:")
        for i, line in enumerate(lines[:3], 1):
            print(f"  {i}: {line.strip()}")
        print()
        
        # Check if it's valid JSON
        import json
        try:
            for i, line in enumerate(lines[:3], 1):
                entry = json.loads(line.strip())
                print(f"Line {i} parsed as JSON:")
                print(f"  Keys: {list(entry.keys())}")
                if 'job_id' in entry:
                    print(f"  job_id: {entry['job_id']}")
                if 'timestamp' in entry:
                    print(f"  timestamp: {entry['timestamp']}")
                print()
        except json.JSONDecodeError as e:
            print(f"⚠️  Not valid JSON: {e}")
    else:
        print("❌ File is empty!")
        
except Exception as e:
    print(f"❌ Error reading file: {e}")
    import traceback
    traceback.print_exc()

print("=" * 80)
print("If this test succeeds, the log connector should work too!")
print("=" * 80)
