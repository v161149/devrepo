"""
Alert Generation Service
Monitors SLAs and creates alerts when breaches are detected
"""

import logging
import uuid
from datetime import datetime
from typing import Dict, List

logger = logging.getLogger(__name__)


class AlertGenerationService:
    """Service to generate alerts for SLA breaches"""
    
    def __init__(self, db_service):
        self.db = db_service
    
    def check_and_create_alerts(self, org_id: str):
        """Check all active SLAs and create alerts for breaches"""
        try:
            logger.info(f"Checking SLAs for alerts in org: {org_id}")
            
            # Get all active SLAs for the organization
            with self.db.get_connection() as conn:
                slas = conn.execute("""
                    SELECT s.*, srv.name as service_name
                    FROM slas s
                    JOIN services srv ON s.service_id = srv.service_id
                    WHERE s.org_id = ? AND s.is_active = 1
                """, (org_id,)).fetchall()
                
                alerts_created = 0
                
                for sla in slas:
                    # Get latest health check for this service
                    health = conn.execute("""
                        SELECT status, checked_at, message
                        FROM service_health_checks
                        WHERE service_id = ?
                        ORDER BY checked_at DESC
                        LIMIT 1
                    """, (sla['service_id'],)).fetchone()
                    
                    if not health:
                        continue
                    
                    # Check if this is a breach
                    if health['status'] == 'healthy':
                        current_value = 99.95
                    else:
                        current_value = 0.0
                    
                    target_value = sla['target_value']
                    is_breach = current_value < target_value
                    
                    if is_breach:
                        # Check if there's already a pending or sent alert for this SLA
                        existing_alert = conn.execute("""
                            SELECT alert_id FROM alerts
                            WHERE sla_id = ? AND status IN ('pending', 'sent')
                            ORDER BY created_at DESC
                            LIMIT 1
                        """, (sla['sla_id'],)).fetchone()
                        
                        if not existing_alert:
                            # Create a new alert
                            alert_id = f"alert-{uuid.uuid4().hex[:12]}"
                            
                            # Determine severity based on how far below target
                            breach_percentage = ((target_value - current_value) / target_value) * 100
                            if breach_percentage >= 10:
                                severity = 'critical'
                            elif breach_percentage >= 5:
                                severity = 'high'
                            elif breach_percentage >= 2:
                                severity = 'medium'
                            else:
                                severity = 'low'
                            
                            # Create message
                            message = f"Service '{sla['service_name']}' is breaching SLA '{sla['name']}'. Current: {current_value:.2f}%, Target: {target_value}%"
                            
                            # Create metadata with additional info
                            import json
                            metadata = {
                                'breach_percentage': breach_percentage,
                                'current_value': current_value,
                                'target_value': target_value,
                                'title': f"SLA Breach: {sla['name']}"
                            }
                            
                            alert_data = {
                                'alert_id': alert_id,
                                'org_id': org_id,
                                'evaluation_id': 'auto-generated',  # For auto-generated alerts
                                'sla_id': sla['sla_id'],
                                'service_id': sla['service_id'],
                                'alert_type': 'breach',
                                'severity': severity,
                                'message': message,
                                'channels': '["email"]',  # JSON array as string
                                'status': 'pending',
                                'metadata': json.dumps(metadata),  # Proper JSON encoding
                                'created_at': datetime.now().isoformat()
                            }
                            
                            # Insert alert
                            conn.execute("""
                                INSERT INTO alerts (
                                    alert_id, org_id, evaluation_id, sla_id, service_id,
                                    alert_type, severity, message, channels, status, metadata, created_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """, (
                                alert_data['alert_id'],
                                alert_data['org_id'],
                                alert_data['evaluation_id'],
                                alert_data['sla_id'],
                                alert_data['service_id'],
                                alert_data['alert_type'],
                                alert_data['severity'],
                                alert_data['message'],
                                alert_data['channels'],
                                alert_data['status'],
                                alert_data['metadata'],
                                alert_data['created_at']
                            ))
                            
                            logger.info(f"Created alert {alert_id} for SLA {sla['sla_id']}")
                            alerts_created += 1
                    
                    else:
                        # SLA is compliant, update any pending/sent alerts to acknowledged
                        conn.execute("""
                            UPDATE alerts
                            SET status = 'acknowledged', acknowledged_at = ?
                            WHERE sla_id = ? AND status IN ('pending', 'sent')
                        """, (datetime.now().isoformat(), sla['sla_id']))
                
                logger.info(f"Alert check complete. Created {alerts_created} new alerts")
                return alerts_created
                
        except Exception as e:
            logger.error(f"Error checking for alerts: {str(e)}")
            import traceback
            traceback.print_exc()
            return 0
