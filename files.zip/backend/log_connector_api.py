"""
Log Connector API Endpoints
Handles CRUD operations for log server connectors
"""

from flask import request, jsonify
import uuid
from datetime import datetime
import json
import logging
from functools import wraps

logger = logging.getLogger(__name__)


def setup_log_connector_routes(app, db, require_auth):
    """
    Setup log connector routes
    
    Args:
        app: Flask app instance
        db: Database service instance
        require_auth: The require_auth decorator from api_service
    
    This function should be called from api_service.py with:
    setup_log_connector_routes(app, database_service, require_auth)
    """
    
    def get_user_org():
        """Get organization ID for current authenticated user"""
        # Get user_id from request context (set by auth middleware)
        user_id = getattr(request, 'user_id', None)
        if not user_id:
            return None
        
        # Query user's org_id from database
        with db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT org_id FROM users WHERE user_id = ?",
                (user_id,)
            )
            row = cursor.fetchone()
            return row['org_id'] if row else None
    

    
    @app.route('/api/v1/log-connectors', methods=['GET'])
    @require_auth
    def get_log_connectors():
        """Get all log connectors for the current organization"""
        try:
            # Get org_id from authenticated user
            org_id = get_user_org()
            if not org_id:
                return jsonify({'error': 'Authentication required'}), 401
            
            # Get connectors
            connectors = db.get_log_connectors_by_org(org_id)
            
            return jsonify({
                'success': True,
                'data': connectors,
                'count': len(connectors)
            }), 200
            
        except Exception as e:
            logger.error(f"Error fetching log connectors: {e}")
            return jsonify({
                'success': False,
                'error': 'Failed to fetch log connectors',
                'message': str(e)
            }), 500
    
    @app.route('/api/v1/log-connectors/<connector_id>', methods=['GET'])
    @require_auth
    def get_log_connector(connector_id):
        """Get a specific log connector"""
        try:
            connector = db.get_log_connector(connector_id)
            
            if not connector:
                return jsonify({
                    'success': False,
                    'error': 'Log connector not found'
                }), 404
            
            return jsonify({
                'success': True,
                'data': connector
            }), 200
            
        except Exception as e:
            logger.error(f"Error fetching log connector: {e}")
            return jsonify({
                'success': False,
                'error': 'Failed to fetch log connector',
                'message': str(e)
            }), 500
    
    @app.route('/api/v1/log-connectors', methods=['POST'])
    @require_auth
    def create_log_connector():
        """Create a new log connector"""
        try:
            data = request.json
            
            # Validate required fields
            if not data.get('connector_name'):
                return jsonify({
                    'success': False,
                    'error': 'connector_name is required'
                }), 400
            
            # Get org_id from authenticated user
            org_id = get_user_org()
            if not org_id:
                return jsonify({'error': 'Authentication required'}), 401
            
            # Generate connector ID
            connector_id = f"lsc-{uuid.uuid4().hex[:12]}"
            
            # Prepare connector data
            connector_data = {
                'connector_id': connector_id,
                'org_id': org_id,
                'connector_name': data['connector_name'],
                'connector_description': data.get('connector_description', ''),
                'log_server_type': data.get('log_server_type', 'custom'),
                'api_endpoint_url': data.get('api_endpoint_url', ''),
                'api_credentials': data.get('api_credentials', '{}'),
                'connection_config': data.get('connection_config', '{}'),
                'is_active': data.get('is_active', 1)
            }
            
            # Create connector
            db.create_log_connector(connector_data)
            
            # Fetch and return created connector
            created_connector = db.get_log_connector(connector_id)
            
            return jsonify({
                'success': True,
                'message': 'Log connector created successfully',
                'data': created_connector,
                'connector_id': connector_id
            }), 201
            
        except Exception as e:
            logger.error(f"Error creating log connector: {e}")
            return jsonify({
                'success': False,
                'error': 'Failed to create log connector',
                'message': str(e)
            }), 500
    
    @app.route('/api/v1/log-connectors/<connector_id>/test', methods=['POST'])
    @require_auth
    def test_log_connector(connector_id):
        """Test connection to log server"""
        try:
            # Get connector
            connector = db.get_log_connector(connector_id)
            if not connector:
                return jsonify({
                    'success': False,
                    'error': 'Log connector not found'
                }), 404
            
            # Import log connector module
            from log_connector import get_log_connector
            
            # Create log connector instance
            try:
                log_conn = get_log_connector(connector)
            except Exception as e:
                return jsonify({
                    'success': False,
                    'connector_name': connector.get('connector_name'),
                    'message': f'Failed to initialize connector: {str(e)}'
                }), 500
            
            # Test connection
            success, message = log_conn.test_connection()
            
            # Update connector with test results
            db.update_log_connector(connector_id, {
                'last_test_time': datetime.utcnow().isoformat(),
                'last_test_status': 'success' if success else 'failed',
                'last_test_message': message
            })
            
            return jsonify({
                'success': success,
                'connector_name': connector.get('connector_name'),
                'message': message
            }), 200 if success else 500
            
        except Exception as e:
            logger.error(f"Error testing log connector: {e}")
            
            # Still try to update the connector with failure
            try:
                db.update_log_connector(connector_id, {
                    'last_test_time': datetime.utcnow().isoformat(),
                    'last_test_status': 'failed',
                    'last_test_message': str(e)
                })
            except:
                pass
            
            return jsonify({
                'success': False,
                'error': 'Failed to test log connector',
                'message': str(e)
            }), 500
    
    logger.info("Log connector API routes registered")


# For backwards compatibility
def register_routes(app, database_service):
    """Register log connector routes with the Flask app"""
    # Note: This won't work without require_auth, but kept for backwards compatibility
    logger.warning("Using deprecated register_routes without require_auth - authentication may fail")
    setup_log_connector_routes(app, database_service, lambda f: f)
