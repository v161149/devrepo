"""
SLA Data Connector
Imports SLA definitions from external systems

Matches SLAs to existing services by service_id
Validates service existence before import
"""

import sqlite3
import os
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from base_connector import BaseConnector

logger = logging.getLogger(__name__)


class SLADataConnector(BaseConnector):
    """
    Connector for importing SLA definitions from external systems
    
    SLAs are matched to existing services in the portal by service_id.
    The connector validates that services exist before importing SLAs.
    """
    
    def test_connection(self) -> bool:
        """
        Test connection to SLA API
        
        Returns:
            True if health check succeeds, False otherwise
        """
        try:
            response = self._make_request('GET', '/api/health', timeout=5)
            data = response.json()
            
            status = data.get('status', '').lower()
            is_healthy = status in ['healthy', 'ok', 'up']
            
            if is_healthy:
                logger.info(f"SLA API connection successful: {data}")
            else:
                logger.warning(f"SLA API returned unhealthy status: {data}")
            
            return is_healthy
            
        except Exception as e:
            logger.error(f"SLA API connection test failed: {str(e)}")
            return False
    
    def fetch_data(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch SLAs from API (wrapper for fetch_slas)
        
        Args:
            filters: Optional filter parameters
            
        Returns:
            List of SLA objects
        """
        return self.fetch_slas(filters)
    
    def fetch_slas(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch SLA definitions from external API
        
        Args:
            filters: Optional filters such as:
                - service_id: Filter by service ID
                - sla_type: Filter by SLA type (availability, performance, etc.)
                - is_active: Filter by active status
                
        Returns:
            List of SLA dictionaries (must include service_id for matching)
            
        Example SLA object:
            {
                "name": "99.9% Uptime",
                "service_id": "SVC-001",  # Required for matching
                "sla_type": "availability",
                "target_value": "99.9",
                "measurement_window": "monthly",
                "threshold_warning": "99.5",
                "threshold_critical": "99.0"
            }
        """
        try:
            logger.info(f"Fetching SLAs with filters: {filters}")
            
            response = self._make_request('GET', '/api/slas', params=filters or {})
            data = response.json()
            
            # Handle different response formats
            if 'slas' in data:
                slas = data['slas']
            elif isinstance(data, list):
                slas = data
            else:
                logger.warning(f"Unexpected response format: {data}")
                slas = []
            
            logger.info(f"Fetched {len(slas)} SLAs")
            return slas
            
        except Exception as e:
            logger.error(f"Failed to fetch SLAs: {str(e)}")
            raise Exception(f"Failed to fetch SLAs: {str(e)}")
    
    def fetch_sla_by_id(self, sla_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch a specific SLA by ID
        
        Args:
            sla_id: Unique identifier for the SLA
            
        Returns:
            SLA dictionary or None if not found
        """
        try:
            logger.info(f"Fetching SLA: {sla_id}")
            
            response = self._make_request('GET', f'/api/slas/{sla_id}')
            sla = response.json()
            
            logger.info(f"Retrieved SLA: {sla.get('name')}")
            return sla
            
        except Exception as e:
            logger.error(f"Failed to fetch SLA {sla_id}: {str(e)}")
            return None
    
    def bulk_import_slas(
        self,
        org_id: int,
        slas: List[Dict[str, Any]],
        field_mappings: List[Dict[str, Any]],
        db_path: str = None
    ) -> Dict[str, Any]:
        """
        Bulk import SLAs into portal database
        
        Validates that referenced services exist before importing
        
        Args:
            org_id: Organization ID
            slas: List of SLA objects from API (must include service_id)
            field_mappings: List of field mapping rules
            db_path: Optional database path
            
        Returns:
            Dictionary with import results:
                - imported: Number of successfully imported SLAs
                - failed: Number of failed imports
                - errors: List of error details
                - sla_ids: List of created SLA IDs
                
        Example:
            results = connector.bulk_import_slas(
                org_id=1,
                slas=fetched_slas,
                field_mappings=[
                    {
                        'source_field': 'sla_name',
                        'target_field': 'name',
                        'transformation_rule': None,
                        'is_required': True
                    },
                    {
                        'source_field': 'uptime_target',
                        'target_field': 'target_value',
                        'transformation_rule': 'str(value)',
                        'is_required': True
                    }
                ]
            )
        """
        results = {
            'imported': 0,
            'failed': 0,
            'errors': [],
            'sla_ids': []
        }
        
        logger.info(f"Starting bulk import of {len(slas)} SLAs")
        
        for i, sla in enumerate(slas, 1):
            try:
                # Apply field mappings
                mapped_sla = self._apply_field_mappings(sla, field_mappings)
                
                # Validate service_id exists
                service_id = mapped_sla.get('service_id')
                if not service_id:
                    raise Exception("service_id is required for SLA import")
                
                if not self._service_exists(service_id, db_path):
                    raise Exception(f"Service ID {service_id} not found in database")
                
                # Validate required SLA fields
                if not mapped_sla.get('name'):
                    raise Exception("SLA name is required")
                
                if not mapped_sla.get('sla_type'):
                    raise Exception("SLA type is required")
                
                # Insert into database
                sla_id = self._insert_sla(org_id, mapped_sla, db_path)
                
                results['imported'] += 1
                results['sla_ids'].append(sla_id)
                
                logger.info(f"Imported SLA {i}/{len(slas)}: {mapped_sla.get('name')} (ID: {sla_id})")
                
            except Exception as e:
                results['failed'] += 1
                error_detail = {
                    'sla': sla.get('name', sla.get('sla_name', 'unknown')),
                    'service_id': sla.get('service_id'),
                    'error': str(e),
                    'index': i
                }
                results['errors'].append(error_detail)
                logger.error(f"Failed to import SLA {i}/{len(slas)}: {str(e)}")
        
        logger.info(f"Bulk import complete: {results['imported']} succeeded, {results['failed']} failed")
        return results
    
    def _service_exists(self, service_id: int, db_path: str = None) -> bool:
        """
        Check if service exists in database
        
        Args:
            service_id: Service ID to check
            db_path: Optional database path
            
        Returns:
            True if service exists, False otherwise
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT 1 FROM services WHERE service_id = ?', (service_id,))
            exists = cursor.fetchone() is not None
            
            if exists:
                logger.debug(f"Service {service_id} exists")
            else:
                logger.warning(f"Service {service_id} does not exist")
            
            return exists
            
        finally:
            conn.close()
    
    def _insert_sla(
        self,
        org_id: int,
        sla_data: Dict[str, Any],
        db_path: str = None
    ) -> int:
        """
        Insert SLA into database
        
        Args:
            org_id: Organization ID
            sla_data: Mapped SLA data
            db_path: Optional database path
            
        Returns:
            ID of created SLA
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO slas (
                    org_id, name, sla_type, target_value,
                    measurement_window, threshold_warning, threshold_critical,
                    service_id, job_id, customer_id, is_active,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            ''', (
                org_id,
                sla_data.get('name'),
                sla_data.get('sla_type'),
                sla_data.get('target_value'),
                sla_data.get('measurement_window', 'monthly'),
                sla_data.get('threshold_warning'),
                sla_data.get('threshold_critical'),
                sla_data.get('service_id'),
                sla_data.get('job_id'),  # Optional - for job-level SLAs
                sla_data.get('customer_id'),  # Optional
                sla_data.get('is_active', True)
            ))
            
            sla_id = cursor.lastrowid
            conn.commit()
            
            return sla_id
            
        except sqlite3.IntegrityError as e:
            conn.rollback()
            raise Exception(f"SLA constraint violation: {str(e)}")
        except Exception as e:
            conn.rollback()
            raise Exception(f"Database error: {str(e)}")
        finally:
            conn.close()
    
    def get_service_mapping(self, db_path: str = None) -> Dict[str, int]:
        """
        Get mapping of service names/IDs from database
        
        Useful for matching SLAs to services when external system
        uses service names instead of IDs
        
        Args:
            db_path: Optional database path
            
        Returns:
            Dictionary mapping service names to IDs
            
        Example:
            {
                "Production API": 1,
                "Data Pipeline": 2,
                "Email Service": 3
            }
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT service_id, name FROM services')
            rows = cursor.fetchall()
            
            mapping = {name: service_id for service_id, name in rows}
            
            logger.info(f"Retrieved mapping for {len(mapping)} services")
            return mapping
            
        finally:
            conn.close()
    
    def preview_mapping(
        self,
        slas: List[Dict[str, Any]],
        field_mappings: List[Dict[str, Any]],
        db_path: str = None,
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Preview how field mappings will transform SLAs
        
        Also validates service_id references
        
        Args:
            slas: List of SLA objects from API
            field_mappings: List of field mapping rules
            db_path: Optional database path
            limit: Maximum number of SLAs to preview (default: 5)
            
        Returns:
            List of preview objects with:
                - original: Original SLA data
                - mapped: Transformed SLA data
                - warnings: Any mapping warnings
                - service_exists: Whether referenced service exists
        """
        previews = []
        
        for sla in slas[:limit]:
            try:
                mapped = self._apply_field_mappings(sla, field_mappings)
                
                preview = {
                    'original': sla,
                    'mapped': mapped,
                    'warnings': [],
                    'service_exists': False
                }
                
                # Check if service_id is present
                service_id = mapped.get('service_id')
                if not service_id:
                    preview['warnings'].append("service_id is missing - required for import")
                else:
                    # Check if service exists
                    if self._service_exists(service_id, db_path):
                        preview['service_exists'] = True
                    else:
                        preview['warnings'].append(f"Service ID {service_id} not found in database")
                
                # Check for missing required fields
                for mapping in field_mappings:
                    if mapping.get('is_required'):
                        target = mapping['target_field']
                        if not mapped.get(target):
                            preview['warnings'].append(f"Required field '{target}' is missing or empty")
                
                previews.append(preview)
                
            except Exception as e:
                previews.append({
                    'original': sla,
                    'mapped': {},
                    'warnings': [f"Mapping failed: {str(e)}"],
                    'service_exists': False
                })
        
        return previews
    
    def validate_sla_data(self, sla_data: Dict[str, Any]) -> List[str]:
        """
        Validate SLA data before import
        
        Args:
            sla_data: Mapped SLA data to validate
            
        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []
        
        # Check required fields
        if not sla_data.get('name'):
            errors.append("SLA name is required")
        
        if not sla_data.get('sla_type'):
            errors.append("SLA type is required")
        
        if not sla_data.get('service_id'):
            errors.append("service_id is required")
        
        if not sla_data.get('target_value'):
            errors.append("target_value is required")
        
        # Validate SLA type
        valid_types = ['availability', 'performance', 'capacity', 'security', 'compliance', 'custom']
        if sla_data.get('sla_type') and sla_data['sla_type'] not in valid_types:
            errors.append(f"Invalid sla_type. Must be one of: {', '.join(valid_types)}")
        
        # Validate measurement window
        valid_windows = ['hourly', 'daily', 'weekly', 'monthly', 'quarterly', 'yearly']
        window = sla_data.get('measurement_window')
        if window and window not in valid_windows:
            errors.append(f"Invalid measurement_window. Must be one of: {', '.join(valid_windows)}")
        
        return errors


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=" * 60)
    print("SLA Data Connector - Test Mode")
    print("=" * 60)
    print()
    
    # Create connector instance
    connector = SLADataConnector(
        config_id=1,
        api_endpoint='http://localhost:5004/api'  # Example SLA API
    )
    
    # Test connection
    print("Testing connection...")
    if connector.test_connection():
        print("✓ Connection successful!")
    else:
        print("✗ Connection failed!")
        print("Note: This is expected if SLA simulator is not running")
    
    print()
    
    # Test data validation
    print("Testing SLA data validation...")
    
    valid_sla = {
        'name': '99.9% Uptime',
        'sla_type': 'availability',
        'service_id': 1,
        'target_value': '99.9',
        'measurement_window': 'monthly'
    }
    
    errors = connector.validate_sla_data(valid_sla)
    if not errors:
        print("✓ Valid SLA data passed validation")
    else:
        print(f"✗ Validation errors: {errors}")
    
    print()
    
    invalid_sla = {
        'name': '',  # Missing
        'sla_type': 'invalid_type',  # Invalid
        'service_id': None  # Missing
    }
    
    errors = connector.validate_sla_data(invalid_sla)
    if errors:
        print("✓ Invalid SLA data correctly rejected:")
        for error in errors:
            print(f"  - {error}")
    else:
        print("✗ Validation failed to catch errors")
    
    print()
    
    # Test field mapping preview
    print("Testing field mapping preview...")
    
    sample_slas = [
        {
            'sla_name': 'API Uptime',
            'service_identifier': 1,
            'type': 'availability',
            'target': '99.95',
            'window': 'monthly'
        }
    ]
    
    sample_mappings = [
        {
            'source_field': 'sla_name',
            'target_field': 'name',
            'transformation_rule': None,
            'is_required': True
        },
        {
            'source_field': 'service_identifier',
            'target_field': 'service_id',
            'transformation_rule': 'int(value)',
            'is_required': True
        },
        {
            'source_field': 'type',
            'target_field': 'sla_type',
            'transformation_rule': None,
            'is_required': True
        },
        {
            'source_field': 'target',
            'target_field': 'target_value',
            'transformation_rule': 'str(value)',
            'is_required': True
        },
        {
            'source_field': 'window',
            'target_field': 'measurement_window',
            'transformation_rule': None,
            'is_required': False
        }
    ]
    
    # Note: This will try to check the database
    previews = connector.preview_mapping(sample_slas, sample_mappings, limit=1)
    
    if previews:
        print(f"✓ Generated {len(previews)} preview(s)")
        print("\nFirst preview:")
        print(f"  Original name: {previews[0]['original'].get('sla_name')}")
        print(f"  Mapped name: {previews[0]['mapped'].get('name')}")
        print(f"  Service exists: {previews[0]['service_exists']}")
        if previews[0]['warnings']:
            print(f"  Warnings:")
            for warning in previews[0]['warnings']:
                print(f"    - {warning}")
    
    print()
    print("=" * 60)
    print("Test complete!")
    print("=" * 60)
    
    # Close connector
    connector.close()
