"""
Main API Service
Flask REST API that orchestrates all microservices
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import uuid
import json
import hashlib
from datetime import datetime, timedelta
from functools import wraps
import logging

from database_service import DatabaseService
from sla_evaluation_engine import SLAEvaluationEngine
from alerting_service import AlertingService
from health_monitoring_service import HealthMonitoringService
from alert_generation_service import AlertGenerationService
from job_monitoring_service import get_job_monitoring_service
from help_service import get_configured_help_service
from connector_factory import get_connector, get_connector_from_db
from log_connector_api import setup_log_connector_routes

# Initialize Flask app
app = Flask(__name__)
# Enable CORS for React frontend with explicit configuration
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:3000", "http://localhost:3001", "http://localhost:3010"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "supports_credentials": True
    }
})

# Initialize services
db_service = DatabaseService('../database/sla_portal.db')
sla_engine = SLAEvaluationEngine(db_service)
alert_service = AlertingService(db_service)
alert_generator = AlertGenerationService(db_service)
health_monitor = HealthMonitoringService(db_service, check_interval=60)  # Check every 60 seconds
job_monitor = get_job_monitoring_service(db_service)  # Job monitoring service (every 30 minutes)
help_service = get_configured_help_service()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info("Log connector API routes registered")

# ===== HELPER FUNCTIONS =====

def parse_sla_metadata(sla):
    """
    Parse SLA metadata JSON and extract fields to top level for frontend access.
    Extracts: warning_threshold, critical_threshold, measurement_period
    """
    if sla.get('metadata'):
        try:
            # Parse metadata if it's a JSON string
            metadata = json.loads(sla['metadata']) if isinstance(sla['metadata'], str) else sla['metadata']
            
            # Add metadata fields to top level for easier frontend access
            sla['warning_threshold'] = metadata.get('warning_threshold')
            sla['critical_threshold'] = metadata.get('critical_threshold')
            sla['measurement_period'] = metadata.get('measurement_period', 'Monthly')
        except (json.JSONDecodeError, TypeError) as e:
            logger.error(f"Error parsing SLA metadata for SLA {sla.get('sla_id')}: {e}")
    
    return sla

# ===== AUTHENTICATION & AUTHORIZATION =====

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Allow OPTIONS requests without authentication (CORS preflight)
        if request.method == 'OPTIONS':
            # Return an empty successful response for CORS preflight
            return ('', 200)
        
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'error': 'No authorization token provided'}), 401
        
        # Remove 'Bearer ' prefix if present
        if token.startswith('Bearer '):
            token = token[7:]
        
        # Validate token
        with db_service.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM sessions WHERE token = ? AND expires_at > ?",
                (token, datetime.now().isoformat())
            )
            session = cursor.fetchone()
        
        if not session:
            return jsonify({'error': 'Invalid or expired token'}), 401
        
        # Add user info to request
        request.user_id = dict(session)['user_id']
        return f(*args, **kwargs)
    
    return decorated_function

# Setup log connector routes (must be after require_auth is defined)
setup_log_connector_routes(app, db_service, require_auth)


def get_user_org():
    """Get organization ID for current user"""
    # Get user_id from request context (set in require_auth decorator)
    user_id = getattr(request, 'user_id', None)
    if not user_id:
        return None
    
    # Query user by user_id to get their org_id
    with db_service.get_connection() as conn:
        cursor = conn.execute(
            "SELECT org_id FROM users WHERE user_id = ?", 
            (user_id,)
        )
        row = cursor.fetchone()
        return row['org_id'] if row else None

# ===== AUTHENTICATION ENDPOINTS =====

@app.route('/api/v1/auth/login', methods=['POST'])
def login():
    """Login endpoint"""
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({'error': 'Email and password required'}), 400
    
    # Get user
    user = db_service.get_user_by_email(email)
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Verify password
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    if user['password_hash'] != password_hash:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    # Create session
    session_id = f"sess-{uuid.uuid4().hex}"
    token = uuid.uuid4().hex
    expires_at = (datetime.now() + timedelta(days=7)).isoformat()
    
    with db_service.get_connection() as conn:
        conn.execute("""
            INSERT INTO sessions (session_id, user_id, token, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (session_id, user['user_id'], token, expires_at,
              request.remote_addr, request.headers.get('User-Agent')))
    
    logger.info(f"User {email} logged in")
    
    return jsonify({
        'token': token,
        'user': {
            'user_id': user['user_id'],
            'email': user['email'],
            'username': user['username'],
            'role': user['role'],
            'org_id': user['org_id']
        },
        'expires_at': expires_at
    })

@app.route('/api/v1/auth/logout', methods=['POST'])
@require_auth
def logout():
    """Logout endpoint"""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    
    with db_service.get_connection() as conn:
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
    
    return jsonify({'message': 'Logged out successfully'})

# ===== EVENT INGESTION ENDPOINTS =====

@app.route('/api/v1/events', methods=['POST'])
@require_auth
def ingest_event():
    """Ingest event and trigger SLA evaluation"""
    data = request.json
    
    # Validate required fields
    required_fields = ['service_id', 'timestamp', 'event_type']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Create event
    event_id = f"evt-{uuid.uuid4().hex[:12]}"
    event_data = {
        'event_id': event_id,
        'org_id': get_user_org(),
        'service_id': data['service_id'],
        'customer_id': data.get('customer_id'),
        'timestamp': data['timestamp'],
        'event_type': data['event_type'],
        'status': data.get('status'),
        'priority': data.get('priority'),
        'duration': data.get('duration'),
        'source': data.get('source', 'api'),
        'payload': data.get('attributes', {}),
        'normalized_data': data
    }
    
    try:
        db_service.create_event(event_data)
        
        # Trigger SLA evaluation
        evaluations = sla_engine.process_event(event_data)
        
        # Process any new alerts
        for evaluation in evaluations:
            if evaluation.get('is_breach'):
                # Find associated alert and process it
                alerts = db_service.get_alerts(event_data['org_id'], status='pending')
                for alert in alerts:
                    if alert['evaluation_id'] == evaluation.get('evaluation_id'):
                        alert_service.process_alert(alert['alert_id'])
        
        logger.info(f"Event {event_id} ingested and processed")
        
        return jsonify({
            'event_id': event_id,
            'evaluations': len(evaluations),
            'message': 'Event ingested successfully'
        }), 201
    
    except Exception as e:
        logger.error(f"Error ingesting event: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/events', methods=['GET'])
@require_auth
def get_events():
    """Get events with filters"""
    org_id = get_user_org()
    
    filters = {}
    if request.args.get('service_id'):
        filters['service_id'] = request.args.get('service_id')
    if request.args.get('event_type'):
        filters['event_type'] = request.args.get('event_type')
    if request.args.get('start_date'):
        filters['start_date'] = request.args.get('start_date')
    if request.args.get('end_date'):
        filters['end_date'] = request.args.get('end_date')
    
    limit = int(request.args.get('limit', 100))
    offset = int(request.args.get('offset', 0))
    
    events = db_service.get_events(org_id, filters, limit, offset)
    
    return jsonify({
        'events': events,
        'count': len(events),
        'limit': limit,
        'offset': offset
    })

# ===== SERVICE ENDPOINTS =====

@app.route('/api/v1/services', methods=['GET', 'OPTIONS'])
@require_auth
def get_services():
    """Get all services with health status"""
    if request.method == 'OPTIONS':
        return '', 200
    
    org_id = get_user_org()
    customer_id = request.args.get('customer_id')
    
    # Get services with health status
    if customer_id:
        services = db_service.get_services_by_org(org_id, customer_id)
    else:
        services = db_service.get_services_with_health(org_id)
    
    # Add job_count and sla_count for each service
    for service in services:
        with db_service.get_connection() as conn:
            # Get job count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM jobs WHERE service_id = ?",
                (service['service_id'],)
            )
            service['job_count'] = cursor.fetchone()['count']
            
            # Get SLA count (service-level SLAs only)
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM slas WHERE service_id = ? AND job_id IS NULL",
                (service['service_id'],)
            )
            service['sla_count'] = cursor.fetchone()['count']
    
    return jsonify({
        'data': services,  # Changed from 'services' to 'data' for consistency
        'count': len(services)
    })


@app.route('/api/v1/services/<service_id>', methods=['GET', 'PUT', 'DELETE'])
@require_auth
def handle_service(service_id):
    """Handle service operations by ID"""
    
    if request.method == 'GET':
        # Get service by ID with health status
        service = db_service.get_service(service_id)
        
        if not service:
            return jsonify({'error': 'Service not found'}), 404
        
        # Get health status
        health = db_service.get_service_health(service_id)
        if health:
            service['health_status'] = health['status']
            service['health_message'] = health['message']
            service['health_checked_at'] = health['checked_at']
            service['response_time'] = health.get('response_time')
        
        return jsonify(service)
    
    elif request.method == 'PUT':
        # Update service
        data = request.json
        
        try:
            # Update service
            updates = {}
            if 'name' in data:
                updates['name'] = data['name']
            if 'description' in data:
                updates['description'] = data['description']
            if 'owner_team' in data:
                updates['owner_team'] = data['owner_team']
            if 'is_active' in data:
                updates['is_active'] = data['is_active']
            if 'monitoring_method' in data:
                updates['monitoring_method'] = data['monitoring_method']
            if 'deployment_location' in data:
                updates['deployment_location'] = data['deployment_location']
            if 'execution_time' in data:
                updates['execution_time'] = data['execution_time']
            if 'metadata' in data:
                updates['metadata'] = data['metadata']
            if 'tags' in data:
                updates['tags'] = data['tags']
            # ADDED: Log monitoring fields
            if 'service_identifier' in data:
                updates['service_identifier'] = data['service_identifier']
            if 'log_template' in data:
                updates['log_template'] = data['log_template']
            if 'log_server_type' in data:
                updates['log_server_type'] = data['log_server_type']
            
            with db_service.get_connection() as conn:
                # Build update query
                set_clauses = ', '.join([f"{k} = ?" for k in updates.keys()])
                values = list(updates.values())
                values.append(service_id)
                
                conn.execute(
                    f"UPDATE services SET {set_clauses} WHERE service_id = ?",
                    values
                )
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            org_id = get_user_org()
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': org_id,
                'user_id': request.user_id,
                'action': 'update_service',
                'resource_type': 'service',
                'resource_id': service_id,
                'ip_address': request.remote_addr,
                'changes': json.dumps(data),
                'metadata': json.dumps({'service_id': service_id})
            })
            
            return jsonify({'message': 'Service updated successfully'}), 200
        except Exception as e:
            logger.error(f"Error updating service: {e}")
            return jsonify({'error': str(e)}), 500
    
    elif request.method == 'DELETE':
        # Delete service
        try:
            with db_service.get_connection() as conn:
                # Check if service exists
                cursor = conn.execute(
                    "SELECT service_id FROM services WHERE service_id = ?",
                    (service_id,)
                )
                if not cursor.fetchone():
                    return jsonify({'error': 'Service not found'}), 404
                
                # Delete service (cascading will handle related records)
                conn.execute(
                    "DELETE FROM services WHERE service_id = ?",
                    (service_id,)
                )
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            org_id = get_user_org()
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': org_id,
                'user_id': request.user_id,
                'action': 'delete_service',
                'resource_type': 'service',
                'resource_id': service_id,
                'ip_address': request.remote_addr,
                'changes': json.dumps({}),
                'metadata': json.dumps({'service_id': service_id})
            })
            
            return jsonify({'message': 'Service deleted successfully'}), 200
        except Exception as e:
            logger.error(f"Error deleting service: {e}")
            return jsonify({'error': str(e)}), 500

@app.route('/api/v1/services', methods=['POST'])
@require_auth
def create_service():
    """Create new service"""
    data = request.json
    
    service_id = f"svc-{uuid.uuid4().hex[:8]}"
    service_data = {
        'service_id': service_id,
        'org_id': get_user_org(),
        'customer_id': data.get('customer_id'),
        'name': data['name'],
        'description': data.get('description'),
        'owner_team': data.get('owner_team'),
        'asset_id': data.get('asset_id'),  # Asset linking
        'monitoring_method': data.get('monitoring_method', 'direct'),  # Monitoring method
        'deployment_location': data.get('deployment_location'),  # Deployment location
        'tags': data.get('tags', []),
        'metadata': data.get('metadata', {})  # Metadata for additional config
    }
    
    try:
        db_service.create_service(service_data)
        
        # Create audit log
        log_id = f"log-{uuid.uuid4().hex[:12]}"
        db_service.create_audit_log({
            'log_id': log_id,
            'org_id': service_data['org_id'],
            'user_id': request.user_id,
            'action': 'create_service',
            'resource_type': 'service',
            'resource_id': service_id,
            'ip_address': request.remote_addr,
            'metadata': {
                'name': data['name'], 
                'monitoring_method': service_data['monitoring_method'],
                'deployment_location': service_data.get('deployment_location')
            }
        })
        
        return jsonify({
            'service_id': service_id,
            'message': 'Service created successfully'
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ===== SLA ENDPOINTS =====

@app.route('/api/v1/services/<service_id>/slas', methods=['GET'])
@require_auth
def get_service_slas(service_id):
    """Get SLAs for a service (including both active and inactive)"""
    # Get all SLAs (active and inactive) for the service detail page
    slas = db_service.get_slas_by_service(service_id, active_only=False)
    
    return jsonify({
        'data': slas,  # Changed from 'slas' to 'data' to match frontend expectation
        'count': len(slas)
    })

@app.route('/api/v1/slas', methods=['GET', 'POST'])
@require_auth
def handle_slas():
    """Handle SLA operations - Updated to support job_id"""
    try:
        if request.method == 'GET':
            # Get all SLAs for organization
            org_id = get_user_org()
            service_id = request.args.get('service_id')
            job_id = request.args.get('job_id')  # ← NEW
            sla_type = request.args.get('type')  # ← NEW: 'service' or 'job'
            
            if service_id:
                # Get SLAs for specific service
                if sla_type == 'service':
                    # Get only service-level SLAs
                    slas = db_service.get_service_level_slas(service_id, active_only=False)
                elif sla_type == 'job':
                    # Get only job-level SLAs for this service
                    all_slas = db_service.get_all_slas_for_service_and_jobs(service_id, active_only=False)
                    slas = all_slas['job_level']
                elif job_id:
                    # Get SLAs for specific job
                    slas = db_service.get_job_level_slas(job_id, active_only=False)
                else:
                    # Get all SLAs (both service and job level)
                    slas = db_service.get_slas_by_service(service_id, active_only=False)
            elif job_id:
                # Get SLAs for specific job only
                slas = db_service.get_job_level_slas(job_id, active_only=False)
            else:
                # Get all SLAs for organization
                slas = db_service.get_slas_by_org(org_id)
            
            # Parse metadata for all SLAs
            parsed_slas = [parse_sla_metadata(dict(sla)) for sla in slas]
            
            return jsonify({
                'data': parsed_slas,
                'count': len(parsed_slas)
            })
        
        elif request.method == 'POST':
            # Create new SLA
            data = request.json
            
            sla_id = f"sla-{uuid.uuid4().hex[:8]}"
            
            # Handle both camelCase (from frontend) and snake_case field names
            start_condition = data.get('start_condition') or data.get('startCondition')
            stop_condition = data.get('stop_condition') or data.get('stopCondition')
            business_hours_id = data.get('business_hours_id') or data.get('businessHoursId')
            escalation_policy_id = data.get('escalation_policy_id') or data.get('escalationPolicyId')
            effective_from = data.get('effective_from') or data.get('effectiveFrom', datetime.now().isoformat())
            effective_until = data.get('effective_until') or data.get('effectiveUntil')
            job_id = data.get('job_id')  # ← NEW: Extract job_id
            
            # Collect metadata from various fields
            metadata = data.get('metadata', {})
            
            # Add warning_threshold, critical_threshold, measurement_period if provided
            if 'warning_threshold' in data or 'warningThreshold' in data:
                metadata['warning_threshold'] = data.get('warning_threshold') or data.get('warningThreshold')
            if 'critical_threshold' in data or 'criticalThreshold' in data:
                metadata['critical_threshold'] = data.get('critical_threshold') or data.get('criticalThreshold')
            if 'measurement_period' in data or 'measurementPeriod' in data:
                metadata['measurement_period'] = data.get('measurement_period') or data.get('measurementPeriod')
            
            # NEW: Add log field mapping and evaluation schedule
            if 'log_field_criteria' in data or 'logFieldCriteria' in data:
                metadata['log_field_criteria'] = data.get('log_field_criteria') or data.get('logFieldCriteria')
            if 'log_field_status' in data or 'logFieldStatus' in data:
                metadata['log_field_status'] = data.get('log_field_status') or data.get('logFieldStatus')
            if 'evaluation_schedule' in data or 'evaluationSchedule' in data:
                metadata['evaluation_schedule'] = data.get('evaluation_schedule') or data.get('evaluationSchedule')
            
            # Legacy metadata fields (for backward compatibility)
            if 'thresholds' in data:
                metadata['thresholds'] = data['thresholds']
            if 'escalationSteps' in data:
                metadata['escalationSteps'] = data['escalationSteps']
            if 'penalties' in data:
                metadata['penalties'] = data['penalties']
            if 'incentives' in data:
                metadata['incentives'] = data['incentives']
            if 'pauseCondition' in data:
                metadata['pauseCondition'] = data['pauseCondition']
            if 'customCalendar' in data:
                metadata['customCalendar'] = data['customCalendar']
            
            sla_data = {
                'sla_id': sla_id,
                'org_id': get_user_org(),
                'service_id': data['service_id'],
                'job_id': job_id,  # ← NEW: Add job_id
                'customer_id': data.get('customer_id'),
                'name': data['name'],
                'metric_type': data['metric_type'],
                'target_value': data['target_value'],
                'target_unit': data['target_unit'],
                'priority': data.get('priority'),
                'business_hours_id': business_hours_id,
                'escalation_policy_id': escalation_policy_id,
                'start_condition': start_condition,
                'stop_condition': stop_condition,
                'effective_from': effective_from,
                'effective_until': effective_until,
                'created_by': request.user_id,
                'metadata': metadata
            }
            
            db_service.create_sla(sla_data)
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            sla_type = "job-level" if job_id else "service-level"  # ← NEW
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': sla_data['org_id'],
                'user_id': request.user_id,
                'action': 'create_sla',
                'resource_type': 'sla',
                'resource_id': sla_id,
                'ip_address': request.remote_addr,
                'metadata': {'name': data['name'], 'type': sla_type}  # ← NEW
            })
            
            return jsonify({
                'sla_id': sla_id,
                'sla_type': sla_type,  # ← NEW
                'message': f'{sla_type.capitalize()} SLA created successfully'  # ← NEW
            }), 201
    
    except Exception as e:
        logger.error(f"Error in handle_slas: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/slas/<sla_id>', methods=['GET', 'PUT', 'DELETE'])
@require_auth
def handle_sla_detail(sla_id):
    """Handle individual SLA operations"""
    try:
        if request.method == 'GET':
            # Get SLA by ID
            sla = db_service.get_sla(sla_id)
            
            if not sla:
                return jsonify({'error': 'SLA not found'}), 404
            
            # Parse metadata and return
            parsed_sla = parse_sla_metadata(dict(sla))
            return jsonify(parsed_sla)
        
        elif request.method == 'PUT':
            # Update SLA
            data = request.json
            
            # Check if SLA exists
            sla = db_service.get_sla(sla_id)
            if not sla:
                return jsonify({'error': 'SLA not found'}), 404
            
            # Prepare update data
            update_data = {}
            
            # Fields that can be updated
            updatable_fields = [
                'name', 'description', 'metric_type', 'target_value', 'target_unit',
                'priority', 'business_hours_id', 'escalation_policy_id',
                'start_condition', 'stop_condition', 'effective_from', 'effective_until',
                'is_active'
            ]
            
            for field in updatable_fields:
                if field in data:
                    update_data[field] = data[field]
            
            # Handle metadata separately - merge with existing metadata
            if any(key in data for key in ['metadata', 'warning_threshold', 'warningThreshold', 
                                           'critical_threshold', 'criticalThreshold',
                                           'measurement_period', 'measurementPeriod']):
                # Get existing metadata
                existing_metadata = {}
                if sla.get('metadata'):
                    import json
                    existing_metadata = json.loads(sla['metadata']) if isinstance(sla['metadata'], str) else sla['metadata']
                
                # Merge with new metadata
                new_metadata = data.get('metadata', {})
                
                # Add individual threshold fields
                if 'warning_threshold' in data or 'warningThreshold' in data:
                    new_metadata['warning_threshold'] = data.get('warning_threshold') or data.get('warningThreshold')
                if 'critical_threshold' in data or 'criticalThreshold' in data:
                    new_metadata['critical_threshold'] = data.get('critical_threshold') or data.get('criticalThreshold')
                if 'measurement_period' in data or 'measurementPeriod' in data:
                    new_metadata['measurement_period'] = data.get('measurement_period') or data.get('measurementPeriod')
                
                # NEW: Add log field mapping and evaluation schedule
                if 'log_field_criteria' in data or 'logFieldCriteria' in data:
                    new_metadata['log_field_criteria'] = data.get('log_field_criteria') or data.get('logFieldCriteria')
                if 'log_field_status' in data or 'logFieldStatus' in data:
                    new_metadata['log_field_status'] = data.get('log_field_status') or data.get('logFieldStatus')
                if 'evaluation_schedule' in data or 'evaluationSchedule' in data:
                    new_metadata['evaluation_schedule'] = data.get('evaluation_schedule') or data.get('evaluationSchedule')
                
                # Merge with existing
                existing_metadata.update(new_metadata)
                update_data['metadata'] = existing_metadata
            
            # Update the SLA
            db_service.update_sla(sla_id, update_data)
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': sla['org_id'],
                'user_id': request.user_id,
                'action': 'update_sla',
                'resource_type': 'sla',
                'resource_id': sla_id,
                'ip_address': request.remote_addr,
                'metadata': {'updated_fields': list(update_data.keys())}
            })
            
            return jsonify({'message': 'SLA updated successfully'})
        
        elif request.method == 'DELETE':
            # Deactivate SLA (soft delete)
            logger.info(f"DELETE request for SLA: {sla_id}")
            
            # Step 1: Get SLA
            logger.info(f"Step 1: Fetching SLA {sla_id}")
            sla = db_service.get_sla(sla_id)
            logger.info(f"Step 1 complete: SLA found = {sla is not None}")
            
            if not sla:
                logger.warning(f"SLA not found: {sla_id}")
                return jsonify({'error': 'SLA not found'}), 404
            
            # Step 2: Update SLA
            logger.info(f"Step 2: Deactivating SLA {sla_id}")
            db_service.update_sla(sla_id, {'is_active': 0})
            logger.info(f"Step 2 complete: SLA deactivated")
            
            # Step 3: Create audit log
            logger.info(f"Step 3: Creating audit log")
            try:
                log_id = f"log-{uuid.uuid4().hex[:12]}"
                db_service.create_audit_log({
                    'log_id': log_id,
                    'org_id': sla['org_id'],
                    'user_id': request.user_id,
                    'action': 'deactivate_sla',
                    'resource_type': 'sla',
                    'resource_id': sla_id,
                    'ip_address': request.remote_addr,
                    'metadata': {'name': sla.get('name', 'Unknown')}
                })
                logger.info(f"Step 3 complete: Audit log created")
            except Exception as audit_error:
                logger.warning(f"Step 3 failed (non-critical): {audit_error}")
                # Continue anyway - deactivation succeeded
            
            logger.info(f"DELETE request successful for SLA: {sla_id}")
            return jsonify({'message': 'SLA deactivated successfully'})
    
    except Exception as e:
        error_msg = f"Error in handle_sla_detail for {sla_id}: {str(e)}"
        logger.error(error_msg)
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': str(e),
            'details': error_msg,
            'sla_id': sla_id,
            'method': request.method
        }), 500

@app.route('/api/v1/slas/<sla_id>/hard', methods=['DELETE'])
@require_auth
def hard_delete_sla(sla_id):
    """Permanently delete SLA (hard delete)"""
    try:
        logger.info(f"HARD DELETE request for SLA: {sla_id}")
        
        # Get SLA first to check if it exists and for audit log
        sla = db_service.get_sla(sla_id)
        
        if not sla:
            logger.warning(f"SLA not found for hard delete: {sla_id}")
            return jsonify({'error': 'SLA not found'}), 404
        
        # Create audit log before deletion
        try:
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': sla['org_id'],
                'user_id': request.user_id,
                'action': 'hard_delete_sla',
                'resource_type': 'sla',
                'resource_id': sla_id,
                'ip_address': request.remote_addr,
                'metadata': {
                    'name': sla.get('name', 'Unknown'),
                    'service_id': sla.get('service_id'),
                    'warning': 'PERMANENT DELETION - Data cannot be recovered'
                }
            })
        except Exception as audit_error:
            logger.warning(f"Failed to create audit log for hard delete: {audit_error}")
        
        # Permanently delete from database
        db_service.hard_delete_sla(sla_id)
        
        logger.info(f"HARD DELETE successful for SLA: {sla_id}")
        return jsonify({'message': 'SLA permanently deleted'})
    
    except Exception as e:
        error_msg = f"Error in hard_delete_sla for {sla_id}: {str(e)}"
        logger.error(error_msg)
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': str(e),
            'details': error_msg,
            'sla_id': sla_id
        }), 500

# ===== EVALUATION & REPORTING ENDPOINTS =====

@app.route('/api/v1/reports/sla-compliance', methods=['GET'])
@require_auth
def get_sla_compliance():
    """Get SLA compliance report"""
    org_id = get_user_org()
    service_id = request.args.get('service_id')
    period = request.args.get('period', '30d')
    
    # Parse period
    period_days = int(period.replace('d', ''))
    
    # Get compliance summary
    compliance = db_service.get_sla_compliance_summary(org_id, service_id)
    
    # Get evaluations for the period
    period_start = (datetime.now() - timedelta(days=period_days)).isoformat()
    evaluations = db_service.get_evaluations(org_id, filters={
        'service_id': service_id
    } if service_id else None)
    
    # Filter by period
    period_evaluations = [
        e for e in evaluations
        if e['start_timestamp'] >= period_start
    ]
    
    total_evaluations = len(period_evaluations)
    breaches = [e for e in period_evaluations if e['is_breach']]
    compliance_rate = ((total_evaluations - len(breaches)) / total_evaluations * 100) if total_evaluations > 0 else 100
    
    return jsonify({
        'period': period,
        'total_evaluations': total_evaluations,
        'breaches': len(breaches),
        'compliance_percentage': round(compliance_rate, 2),
        'summary': compliance,
        'breach_details': breaches[:10]  # Top 10 breaches
    })

@app.route('/api/v1/dashboard/metrics', methods=['GET'])
@require_auth
def get_dashboard_metrics():
    """Get dashboard metrics and generate alerts for breaches"""
    org_id = get_user_org()
    period_days = int(request.args.get('period_days', 30))
    
    # Generate alerts for any SLA breaches
    try:
        alert_generator.check_and_create_alerts(org_id)
    except Exception as e:
        logger.error(f"Error generating alerts: {e}")
    
    metrics = db_service.get_dashboard_metrics(org_id, period_days)
    
    return jsonify(metrics)

# ===== ALERT ENDPOINTS =====

@app.route('/api/v1/alerts', methods=['GET', 'OPTIONS'])
@require_auth
def get_alerts():
    """Get alerts"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        status = request.args.get('status')
        limit = request.args.get('limit')
        
        alerts = db_service.get_alerts(org_id, status)
        
        # Apply limit if provided
        if limit:
            try:
                limit_int = int(limit)
                alerts = alerts[:limit_int]
            except ValueError:
                pass
        
        return jsonify({
            'alerts': alerts,
            'count': len(alerts)
        })
    except Exception as e:
        logger.error(f"Error getting alerts: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to get alerts: {str(e)}'}), 500

@app.route('/api/v1/alerts/<alert_id>/acknowledge', methods=['POST'])
@require_auth
def acknowledge_alert(alert_id):
    """Acknowledge an alert"""
    result = alert_service.acknowledge_alert(alert_id, request.user_id)
    
    return jsonify(result)

# ===== WEBHOOK ENDPOINTS =====

@app.route('/api/v1/webhooks/datadog', methods=['POST'])
def webhook_datadog():
    """Receive webhook from Datadog"""
    data = request.json
    
    # Transform Datadog payload to our event format
    # This is a simplified example
    event_data = {
        'service_id': data.get('tags', {}).get('service', 'unknown'),
        'timestamp': datetime.now().isoformat(),
        'event_type': 'incident.created' if data.get('event_type') == 'triggered' else 'incident.resolved',
        'priority': 'P1' if data.get('priority') == 'high' else 'P2',
        'source': 'datadog',
        'attributes': data
    }
    
    logger.info(f"Received Datadog webhook: {data.get('id')}")
    
    return jsonify({'message': 'Webhook received'}), 200

@app.route('/api/v1/webhooks/slack', methods=['POST'])
def webhook_slack():
    """Receive webhook from Slack"""
    data = request.json
    
    logger.info(f"Received Slack webhook")
    
    return jsonify({'message': 'Webhook received'}), 200

# ===== HEALTH & INFO ENDPOINTS =====

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/v1/info', methods=['GET'])
def info():
    """API info endpoint"""
    return jsonify({
        'name': 'SLA Monitoring Portal API',
        'version': '1.0.0',
        'description': 'REST API for SLA monitoring and management'
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500


# ===== SERVICE MANAGEMENT ENDPOINTS =====

@app.route('/api/v1/services/test-connection', methods=['POST'])
@require_auth
def test_service_connection():
    """Test service connection"""
    data = request.json
    service_type = data.get('type')
    config = data.get('config', {})
    
    try:
        # Test connection based on service type
        
        if service_type in ['mysql', 'aurora']:
            # MySQL/Aurora connection test - REAL CONNECTION
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import pymysql
                
                # Attempt real connection
                connection = pymysql.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                # Execute test query
                with connection.cursor() as cursor:
                    cursor.execute("SELECT VERSION()")
                    version = cursor.fetchone()[0]
                
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to {service_type} database: {database} (MySQL {version})'
                }), 200
                
            except ImportError:
                # pymysql not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': f'Configuration validated for {service_type} (real connection testing unavailable - install pymysql)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except pymysql.err.OperationalError as e:
                error_msg = str(e)
                if 'Access denied' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif "Can't connect" in error_msg or 'Connection refused' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to {service_type} server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {error_msg}'
                    }), 200
                    
            except pymysql.err.ProgrammingError as e:
                error_msg = str(e)
                if 'Unknown database' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" does not exist on {host}:{port}'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Database error: {error_msg}'
                    }), 200
                    
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection test failed: {str(e)}'
                }), 200
        
        elif service_type == 'postgresql':
            # PostgreSQL connection test - REAL CONNECTION
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import psycopg2
                
                # Attempt real connection
                connection = psycopg2.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                # Execute test query
                cursor = connection.cursor()
                cursor.execute("SELECT version()")
                version = cursor.fetchone()[0]
                cursor.close()
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to PostgreSQL database: {database}'
                }), 200
                
            except ImportError:
                # psycopg2 not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for PostgreSQL (real connection testing unavailable - install psycopg2)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except psycopg2.OperationalError as e:
                error_msg = str(e)
                if 'authentication failed' in error_msg.lower():
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'does not exist' in error_msg and 'database' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" does not exist'
                    }), 200
                elif 'could not connect' in error_msg.lower() or 'connection refused' in error_msg.lower():
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to PostgreSQL server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {error_msg}'
                    }), 200
                    
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection test failed: {str(e)}'
                }), 200
        
        elif service_type == 'mongodb':
            # MongoDB connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database'
                }), 400
            
            try:
                from pymongo import MongoClient
                from pymongo.errors import ConnectionFailure, OperationFailure, ServerSelectionTimeoutError
                
                # Build connection string
                if username and password:
                    conn_string = f"mongodb://{username}:{password}@{host}:{port}/{database}"
                else:
                    conn_string = f"mongodb://{host}:{port}/{database}"
                
                # Attempt real connection
                client = MongoClient(conn_string, serverSelectionTimeoutMS=5000)
                
                # Test connection
                client.admin.command('ping')
                
                # Get server info
                server_info = client.server_info()
                version = server_info.get('version', 'unknown')
                
                client.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to MongoDB database: {database} (MongoDB {version})'
                }), 200
                
            except ImportError:
                # pymongo not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for MongoDB (real connection testing unavailable - install pymongo)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except OperationFailure as e:
                return jsonify({
                    'success': False,
                    'message': 'Authentication failed: Wrong username or password'
                }), 200
                
            except (ConnectionFailure, ServerSelectionTimeoutError) as e:
                return jsonify({
                    'success': False,
                    'message': f'Cannot connect to MongoDB server at {host}:{port}. Is the server running?'
                }), 200
                
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection test failed: {str(e)}'
                }), 200
        
        elif service_type == 'oracle':
            # Oracle Database connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            service_name = config.get('service_name')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, service_name, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, service_name, username, password'
                }), 400
            
            try:
                import cx_Oracle
                
                # Build connection string (format: username/password@host:port/service_name)
                dsn = cx_Oracle.makedsn(host, int(port), service_name=service_name)
                
                # Attempt real connection
                connection = cx_Oracle.connect(
                    user=username,
                    password=password,
                    dsn=dsn,
                    encoding="UTF-8"
                )
                
                # Execute test query
                cursor = connection.cursor()
                cursor.execute("SELECT BANNER FROM v$version WHERE ROWNUM = 1")
                version = cursor.fetchone()[0]
                cursor.close()
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to Oracle database: {service_name}'
                }), 200
                
            except ImportError:
                # cx_Oracle not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for Oracle (real connection testing unavailable - install cx_Oracle)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except Exception as e:
                error_msg = str(e).lower()
                if 'invalid username/password' in error_msg or 'ora-01017' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'ora-12541' in error_msg or 'no listener' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to Oracle server at {host}:{port}. Is the listener running?'
                    }), 200
                elif 'ora-12514' in error_msg or 'could not resolve' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Service name "{service_name}" not found. Check TNS configuration.'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {str(e)}'
                    }), 200
        
        elif service_type == 'mssql':
            # Microsoft SQL Server connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import pymssql
                
                # Attempt real connection
                connection = pymssql.connect(
                    server=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    timeout=5,
                    login_timeout=5
                )
                
                # Execute test query
                cursor = connection.cursor()
                cursor.execute("SELECT @@VERSION")
                version_info = cursor.fetchone()[0]
                # Extract version number
                version = version_info.split('\n')[0] if version_info else 'SQL Server'
                cursor.close()
                connection.close()
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to SQL Server database: {database}'
                }), 200
                
            except ImportError:
                # pymssql not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for SQL Server (real connection testing unavailable - install pymssql)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except Exception as e:
                error_msg = str(e).lower()
                if 'login failed' in error_msg or '18456' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'cannot open database' in error_msg or '4060' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" does not exist or access denied'
                    }), 200
                elif 'connection refused' in error_msg or 'timed out' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to SQL Server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {str(e)}'
                    }), 200
        
        elif service_type == 'db2':
            # IBM DB2 connection test - REAL CONNECTION
            host = config.get('host')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields: host, port, database, username, password'
                }), 400
            
            try:
                import ibm_db
                
                # Build connection string
                conn_string = (
                    f"DATABASE={database};"
                    f"HOSTNAME={host};"
                    f"PORT={port};"
                    f"PROTOCOL=TCPIP;"
                    f"UID={username};"
                    f"PWD={password};"
                )
                
                # Attempt real connection
                connection = ibm_db.connect(conn_string, "", "")
                
                # Execute test query
                stmt = ibm_db.exec_immediate(connection, "SELECT SERVICE_LEVEL FROM SYSIBMADM.ENV_INST_INFO")
                result = ibm_db.fetch_tuple(stmt)
                version = result[0] if result else 'DB2'
                
                ibm_db.close(connection)
                
                return jsonify({
                    'success': True,
                    'message': f'Successfully connected to IBM DB2 database: {database}'
                }), 200
                
            except ImportError:
                # ibm_db not installed - fall back to validation
                try:
                    port_int = int(port)
                    if port_int < 1 or port_int > 65535:
                        raise ValueError("Invalid port number")
                    return jsonify({
                        'success': True,
                        'message': 'Configuration validated for IBM DB2 (real connection testing unavailable - install ibm_db)'
                    }), 200
                except ValueError:
                    return jsonify({
                        'success': False,
                        'message': f'Invalid port number: {port}'
                    }), 400
                    
            except Exception as e:
                error_msg = str(e).lower()
                if 'authorization failure' in error_msg or 'sql30082n' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': 'Authentication failed: Wrong username or password'
                    }), 200
                elif 'database not found' in error_msg or 'sql1013n' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Database "{database}" not found or not cataloged'
                    }), 200
                elif 'communication error' in error_msg or 'sql30081n' in error_msg:
                    return jsonify({
                        'success': False,
                        'message': f'Cannot connect to DB2 server at {host}:{port}. Is the server running?'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection error: {str(e)}'
                    }), 200
            
        elif service_type in ['api_gateway', 'microservice', 'nginx', 'apache', 'esb']:
            # HTTP endpoint test - ACTUAL HTTP REQUEST
            url = config.get('url')
            health_endpoint = config.get('health_endpoint') or config.get('status_endpoint')
            
            if not url:
                return jsonify({
                    'success': False,
                    'message': 'Missing required field: url'
                }), 400
            
            # Validate that health_endpoint is just a path, not a full URL
            if health_endpoint and ('http://' in health_endpoint or 'https://' in health_endpoint):
                return jsonify({
                    'success': False,
                    'message': 'Health/Status Endpoint should be just a path (e.g., /health), not a full URL. Please enter only the path in the endpoint field.'
                }), 400
            
            # Perform actual HTTP request
            import requests
            try:
                # Construct full URL
                test_url = url
                endpoint_used = "base URL"
                
                if health_endpoint:
                    # Add health endpoint path
                    if not url.endswith('/'):
                        test_url += '/'
                    if health_endpoint.startswith('/'):
                        health_endpoint = health_endpoint[1:]
                    test_url += health_endpoint
                    endpoint_used = health_endpoint
                
                # Make HTTP request with timeout
                logger.info(f"Testing connection to: {test_url}")
                response = requests.get(test_url, timeout=5, verify=False)
                
                logger.info(f"Response status code: {response.status_code}")
                
                if response.status_code in [200, 201, 204]:
                    return jsonify({
                        'success': True,
                        'message': f'Successfully connected to {test_url} (Status: {response.status_code})'
                    }), 200
                elif response.status_code in [301, 302, 307, 308]:
                    # Redirect - could be success or not, treat as success with warning
                    return jsonify({
                        'success': True,
                        'message': f'Connected to {test_url} (Redirect {response.status_code}). Check endpoint configuration.'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': f'Connection failed: {test_url} returned HTTP {response.status_code}'
                    }), 200
                    
            except requests.exceptions.Timeout:
                return jsonify({
                    'success': False,
                    'message': f'Connection timeout after 5 seconds'
                }), 200
            except requests.exceptions.ConnectionError:
                return jsonify({
                    'success': False,
                    'message': f'Connection refused or host unreachable'
                }), 200
            except requests.exceptions.RequestException as e:
                return jsonify({
                    'success': False,
                    'message': f'Connection error: {str(e)}'
                }), 200
            
        elif service_type in ['snowflake', 'bigquery']:
            # Cloud data warehouse validation
            if service_type == 'snowflake':
                account = config.get('account')
                warehouse = config.get('warehouse')
                if not account or not warehouse:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: account and warehouse'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for Snowflake account: {account}'
                }), 200
                
            elif service_type == 'bigquery':
                project_id = config.get('project_id')
                dataset = config.get('dataset')
                if not project_id or not dataset:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: project_id and dataset'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for BigQuery project: {project_id}'
                }), 200
            
        elif service_type in ['etl_batch', 'spark_streaming', 'flink']:
            # Data processing jobs - validate endpoint if provided
            endpoint = config.get('endpoint') or config.get('master_url') or config.get('jobmanager_url')
            
            if endpoint:
                # Try to connect to monitoring endpoint
                import requests
                try:
                    response = requests.get(endpoint, timeout=5, verify=False)
                    if response.status_code in [200, 201, 204]:
                        return jsonify({
                            'success': True,
                            'message': f'Successfully connected to {service_type} at {endpoint}'
                        }), 200
                    else:
                        return jsonify({
                            'success': False,
                            'message': f'Endpoint returned HTTP {response.status_code}'
                        }), 200
                except Exception as e:
                    return jsonify({
                        'success': False,
                        'message': f'Connection failed: {str(e)}'
                    }), 200
            else:
                # Just validate configuration
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for {service_type}'
                }), 200
            
        elif service_type in ['kafka', 'rabbitmq', 'ibm_mq', 'aws_sqs']:
            # Messaging systems - validate configuration
            if service_type == 'kafka':
                servers = config.get('bootstrap_servers')
                if not servers:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required field: bootstrap_servers'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for Kafka: {servers}'
                }), 200
                
            elif service_type == 'rabbitmq':
                host = config.get('host')
                port = config.get('port')
                if not host or not port:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: host and port'
                    }), 400
                    
                # Try to connect to RabbitMQ management API
                import requests
                try:
                    mgmt_url = f"http://{host}:{port}/api/overview"
                    response = requests.get(mgmt_url, timeout=5, verify=False)
                    if response.status_code in [200, 401]:  # 401 means it's there but needs auth
                        return jsonify({
                            'success': True,
                            'message': f'Successfully found RabbitMQ at {host}:{port}'
                        }), 200
                except:
                    # Management API not accessible, just validate config
                    return jsonify({
                        'success': True,
                        'message': f'Configuration validated for RabbitMQ: {host}:{port}'
                    }), 200
                    
            elif service_type == 'ibm_mq':
                host = config.get('host')
                port = config.get('port')
                queue_manager = config.get('queue_manager')
                if not all([host, port, queue_manager]):
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: host, port, queue_manager'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for IBM MQ: {host}:{port}/{queue_manager}'
                }), 200
                
            elif service_type == 'aws_sqs':
                queue_url = config.get('queue_url')
                region = config.get('region')
                if not queue_url or not region:
                    return jsonify({
                        'success': False,
                        'message': 'Missing required fields: queue_url and region'
                    }), 400
                    
                return jsonify({
                    'success': True,
                    'message': f'Configuration validated for AWS SQS: {queue_url}'
                }), 200
            
        else:
            return jsonify({
                'success': True,
                'message': f'Configuration validated for {service_type}'
            }), 200
            
    except Exception as e:
        logger.error(f"Connection test error: {e}")
        return jsonify({
            'success': False,
            'message': f'Connection test failed: {str(e)}'
        }), 500

# ===== ASSETS API ENDPOINTS =====

@app.route('/api/v1/assets', methods=['GET', 'POST', 'OPTIONS'])
@require_auth
def handle_assets():
    """Handle asset operations"""
    try:
        if request.method == 'GET':
            # Get all assets for organization
            org_id = get_user_org()
            
            # Get query parameters
            status = request.args.get('status')  # Filter by status
            asset_type = request.args.get('asset_type')  # Filter by type
            search = request.args.get('search')  # Search in name
            
            # Build query
            query = "SELECT * FROM assets WHERE org_id = ?"
            params = [org_id]
            
            if status:
                query += " AND status = ?"
                params.append(status)
            
            if asset_type:
                query += " AND asset_type = ?"
                params.append(asset_type)
            
            if search:
                query += " AND asset_name LIKE ?"
                params.append(f"%{search}%")
            
            query += " ORDER BY created_at DESC"
            
            with db_service.get_connection() as conn:
                cursor = conn.execute(query, params)
                assets = [dict(row) for row in cursor.fetchall()]
            
            # Get service count for each asset
            for asset in assets:
                with db_service.get_connection() as conn:
                    cursor = conn.execute(
                        "SELECT COUNT(*) as count FROM services WHERE asset_id = ?",
                        (asset['asset_id'],)
                    )
                    asset['service_count'] = cursor.fetchone()['count']
                    
                    # Get job count for each asset (jobs linked directly to asset OR via services)
                    cursor = conn.execute(
                        """
                        SELECT COUNT(*) as count FROM jobs 
                        WHERE asset_id = ? 
                        OR service_id IN (SELECT service_id FROM services WHERE asset_id = ?)
                        """,
                        (asset['asset_id'], asset['asset_id'])
                    )
                    asset['job_count'] = cursor.fetchone()['count']
            
            return jsonify({
                'data': assets,
                'count': len(assets)
            })
        
        elif request.method == 'POST':
            # Create new asset
            data = request.json
            
            asset_id = f"asset-{uuid.uuid4().hex[:8]}"
            asset_data = {
                'asset_id': asset_id,
                'org_id': get_user_org(),
                'asset_name': data['asset_name'],
                'asset_type': data['asset_type'],
                'asset_owner': data.get('asset_owner'),
                'description': data.get('description'),
                'onboarded_date': data.get('onboarded_date', datetime.now().isoformat()),
                'status': data.get('status', 'active'),
                'created_by': request.user_id,
                'metadata': json.dumps(data.get('metadata', {}))
            }
            
            with db_service.get_connection() as conn:
                conn.execute("""
                    INSERT INTO assets (
                        asset_id, org_id, asset_name, asset_type, asset_owner,
                        description, onboarded_date, status, created_by, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    asset_data['asset_id'], asset_data['org_id'], asset_data['asset_name'],
                    asset_data['asset_type'], asset_data['asset_owner'], asset_data['description'],
                    asset_data['onboarded_date'], asset_data['status'], asset_data['created_by'],
                    asset_data['metadata']
                ))
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': asset_data['org_id'],
                'user_id': request.user_id,
                'action': 'create_asset',
                'resource_type': 'asset',
                'resource_id': asset_id,
                'ip_address': request.remote_addr,
                'metadata': {'name': data['asset_name']}
            })
            
            return jsonify({
                'asset_id': asset_id,
                'message': 'Asset created successfully'
            }), 201
    
    except Exception as e:
        logger.error(f"Error in handle_assets: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/assets/<asset_id>', methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
@require_auth
def handle_asset_detail(asset_id):
    """Handle individual asset operations"""
    try:
        if request.method == 'GET':
            # Get asset by ID
            with db_service.get_connection() as conn:
                cursor = conn.execute(
                    "SELECT * FROM assets WHERE asset_id = ?", (asset_id,)
                )
                asset = cursor.fetchone()
                
                if not asset:
                    return jsonify({'error': 'Asset not found'}), 404
                
                asset = dict(asset)
                
                # Get associated services
                cursor = conn.execute("""
                    SELECT * FROM services WHERE asset_id = ?
                    ORDER BY created_at DESC
                """, (asset_id,))
                asset['services'] = [dict(row) for row in cursor.fetchall()]
            
            return jsonify(asset)
        
        elif request.method == 'PUT':
            # Update asset
            data = request.json
            
            # Build update fields
            update_fields = []
            values = []
            
            if 'asset_name' in data:
                update_fields.append('asset_name = ?')
                values.append(data['asset_name'])
            
            if 'asset_type' in data:
                update_fields.append('asset_type = ?')
                values.append(data['asset_type'])
            
            if 'asset_owner' in data:
                update_fields.append('asset_owner = ?')
                values.append(data['asset_owner'])
            
            if 'description' in data:
                update_fields.append('description = ?')
                values.append(data['description'])
            
            if 'status' in data:
                update_fields.append('status = ?')
                values.append(data['status'])
            
            if 'metadata' in data:
                update_fields.append('metadata = ?')
                values.append(json.dumps(data['metadata']))
            
            # Add updated_at
            update_fields.append('updated_at = ?')
            values.append(datetime.now().isoformat())
            
            values.append(asset_id)
            
            with db_service.get_connection() as conn:
                conn.execute(
                    f"UPDATE assets SET {', '.join(update_fields)} WHERE asset_id = ?",
                    values
                )
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': get_user_org(),
                'user_id': request.user_id,
                'action': 'update_asset',
                'resource_type': 'asset',
                'resource_id': asset_id,
                'ip_address': request.remote_addr,
                'metadata': {'name': data.get('asset_name', 'Unknown')}
            })
            
            return jsonify({'message': 'Asset updated successfully'})
        
        elif request.method == 'DELETE':
            # Delete asset
            with db_service.get_connection() as conn:
                # Check if asset has services
                cursor = conn.execute(
                    "SELECT COUNT(*) as count FROM services WHERE asset_id = ?",
                    (asset_id,)
                )
                service_count = cursor.fetchone()['count']
                
                if service_count > 0:
                    return jsonify({
                        'error': f'Cannot delete asset with {service_count} associated services. Remove services first.'
                    }), 400
                
                # Delete asset
                conn.execute("DELETE FROM assets WHERE asset_id = ?", (asset_id,))
            
            # Create audit log
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': get_user_org(),
                'user_id': request.user_id,
                'action': 'delete_asset',
                'resource_type': 'asset',
                'resource_id': asset_id,
                'ip_address': request.remote_addr,
                'metadata': {}
            })
            
            return jsonify({'message': 'Asset deleted successfully'})
    
    except Exception as e:
        logger.error(f"Error in handle_asset_detail for {asset_id}: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/assets/<asset_id>/services', methods=['GET', 'POST', 'OPTIONS'])
@require_auth
def handle_asset_services(asset_id):
    """Handle services associated with an asset"""
    try:
        if request.method == 'GET':
            # Get all services for this asset
            with db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT s.*, 
                           COUNT(DISTINCT sla.sla_id) as sla_count
                    FROM services s
                    LEFT JOIN slas sla ON s.service_id = sla.service_id
                    WHERE s.asset_id = ?
                    GROUP BY s.service_id
                    ORDER BY s.created_at DESC
                """, (asset_id,))
                services = [dict(row) for row in cursor.fetchall()]
            
            return jsonify({
                'data': services,
                'count': len(services)
            })
        
        elif request.method == 'POST':
            # Associate existing service with asset or create new service for asset
            data = request.json
            
            if 'service_id' in data:
                # Associate existing service
                service_id = data['service_id']
                
                with db_service.get_connection() as conn:
                    conn.execute(
                        "UPDATE services SET asset_id = ? WHERE service_id = ?",
                        (asset_id, service_id)
                    )
                
                return jsonify({'message': 'Service associated with asset'})
            else:
                # Create new service for this asset
                service_id = f"svc-{uuid.uuid4().hex[:8]}"
                
                with db_service.get_connection() as conn:
                    conn.execute("""
                        INSERT INTO services (
                            service_id, org_id, service_name, service_type,
                            description, owner_team, asset_id, created_by
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        service_id, get_user_org(), data['service_name'],
                        data['service_type'], data.get('description'),
                        data.get('owner_team'), asset_id, request.user_id
                    ))
                
                return jsonify({
                    'service_id': service_id,
                    'message': 'Service created and associated with asset'
                }), 201
    
    except Exception as e:
        logger.error(f"Error in handle_asset_services for {asset_id}: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/dashboard/stats', methods=['GET', 'OPTIONS'])
@require_auth
def get_dashboard_stats():
    """Get dashboard statistics including assets"""
    try:
        org_id = get_user_org()
        
        with db_service.get_connection() as conn:
            # Get asset count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM assets WHERE org_id = ? AND status = 'active'",
                (org_id,)
            )
            total_assets = cursor.fetchone()['count']
            
            # Get service count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM services WHERE org_id = ?",
                (org_id,)
            )
            total_services = cursor.fetchone()['count']
            
            # Get SLA count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM slas WHERE org_id = ?",
                (org_id,)
            )
            total_slas = cursor.fetchone()['count']
            
            # Get active alert count
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM alerts WHERE org_id = ? AND status = 'open'",
                (org_id,)
            )
            active_alerts = cursor.fetchone()['count']
        
        return jsonify({
            'total_assets': total_assets,
            'total_services': total_services,
            'total_slas': total_slas,
            'active_alerts': active_alerts
        })
    
    except Exception as e:
        logger.error(f"Error in get_dashboard_stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/dashboard/service-health-indirect', methods=['GET'])
@require_auth
def get_service_health_indirect():
    """
    Get service health data for indirect monitoring (scheduled jobs)
    Combines data from service_monitoring_log and slas tables
    """
    try:
        org_id = get_user_org()
        
        # Get pagination parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))  # Default 10 rows per page
        offset = (page - 1) * limit
        
        # Get filter parameters
        deployment_location = request.args.get('deployment_location', '')
        search = request.args.get('search', '')
        
        with db_service.get_connection() as conn:
            # Build query
            query = """
                SELECT 
                    sml.id,
                    sml.asset_id,
                    sml.asset_name,
                    sml.service_id,
                    sml.service_name,
                    sml.job_name,
                    sml.job_type,
                    sml.deployment_location,
                    sml.job_schedule,
                    sml.scheduled_execution_date,
                    sml.scheduled_start_time,
                    sml.scheduled_end_time,
                    sml.scheduled_execution_duration,
                    sml.start_time,
                    sml.end_time,
                    sml.on_time_ind,
                    sml.creation_time,
                    'indirect' as monitoring_method,
                    COUNT(DISTINCT sla.sla_id) as sla_count,
                    COUNT(DISTINCT CASE WHEN a.status = 'open' THEN a.alert_id END) as active_alerts
                FROM service_monitoring_log sml
                LEFT JOIN services s ON sml.service_id = s.service_id
                LEFT JOIN slas sla ON sml.service_id = sla.service_id
                LEFT JOIN alerts a ON sla.sla_id = a.sla_id
                WHERE s.org_id = ?
            """
            
            params = [org_id]
            
            # Add filters
            if deployment_location and deployment_location.lower() != 'all':
                query += " AND sml.deployment_location = ?"
                params.append(deployment_location)
            
            if search:
                query += """ AND (
                    sml.service_name LIKE ? OR 
                    sml.job_name LIKE ? OR 
                    sml.asset_name LIKE ?
                )"""
                search_param = f"%{search}%"
                params.extend([search_param, search_param, search_param])
            
            # Group by to aggregate SLA count and alerts
            query += """
                GROUP BY 
                    sml.id, sml.asset_id, sml.asset_name, sml.service_id, 
                    sml.service_name, sml.job_name, sml.job_type, 
                    sml.deployment_location, sml.job_schedule,
                    sml.scheduled_execution_date, sml.scheduled_start_time,
                    sml.scheduled_end_time, sml.scheduled_execution_duration,
                    sml.start_time, sml.end_time, sml.on_time_ind,
                    sml.creation_time
                ORDER BY sml.scheduled_start_time DESC
            """
            
            # Get total count for pagination
            count_query = f"""
                SELECT COUNT(DISTINCT sml.id) as total
                FROM service_monitoring_log sml
                LEFT JOIN services s ON sml.service_id = s.service_id
                WHERE s.org_id = ?
            """
            count_params = [org_id]
            
            if deployment_location and deployment_location.lower() != 'all':
                count_query += " AND sml.deployment_location = ?"
                count_params.append(deployment_location)
            
            if search:
                count_query += """ AND (
                    sml.service_name LIKE ? OR 
                    sml.job_name LIKE ? OR 
                    sml.asset_name LIKE ?
                )"""
                count_params.extend([search_param, search_param, search_param])
            
            cursor = conn.execute(count_query, count_params)
            total = cursor.fetchone()['total']
            
            # Add pagination
            query += " LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            # Execute main query
            cursor = conn.execute(query, params)
            services = [dict(row) for row in cursor.fetchall()]
            
            return jsonify({
                'data': services,
                'total': total,
                'page': page,
                'limit': limit,
                'total_pages': (total + limit - 1) // limit
            })
    
    except Exception as e:
        logger.error(f"Error in get_service_health_indirect: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ===== JOB MONITORING ENDPOINTS =====

@app.route('/api/v1/job-monitoring/scheduled', methods=['GET'])
@require_auth
def get_scheduled_jobs():
    """Get scheduled job executions"""
    try:
        # Get query parameters
        service_id = request.args.get('service_id')
        date = request.args.get('date')  # YYYY-MM-DD
        window_start = request.args.get('window_start')  # YYYY-MM-DD HH:MM:SS
        window_end = request.args.get('window_end')  # YYYY-MM-DD HH:MM:SS
        
        if service_id:
            # Get by service
            limit = int(request.args.get('limit', 100))
            jobs = db_service.get_scheduled_jobs_by_service(service_id, limit)
        elif date:
            # Get by date
            jobs = db_service.get_scheduled_jobs_by_date(date)
        elif window_start and window_end:
            # Get by window
            jobs = db_service.get_scheduled_jobs_in_window(window_start, window_end)
        else:
            # Get today's jobs by default
            from datetime import datetime
            today = datetime.now().strftime('%Y-%m-%d')
            jobs = db_service.get_scheduled_jobs_by_date(today)
        
        return jsonify({
            'data': jobs,
            'count': len(jobs)
        })
        
    except Exception as e:
        logger.error(f"Error getting scheduled jobs: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/job-monitoring/stats', methods=['GET'])
@require_auth
def get_job_monitoring_stats():
    """Get job monitoring statistics"""
    try:
        stats = db_service.get_job_monitoring_stats()
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"Error getting job monitoring stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/job-monitoring/execution/<int:record_id>', methods=['PUT'])
@require_auth
def update_job_execution(record_id):
    """Update job execution status"""
    try:
        data = request.json
        
        success = db_service.update_job_execution_status(
            record_id=record_id,
            start_time=data.get('start_time'),
            end_time=data.get('end_time'),
            on_time_ind=data.get('on_time_ind')
        )
        
        if success:
            return jsonify({'message': 'Job execution updated successfully'})
        else:
            return jsonify({'error': 'Failed to update job execution'}), 400
            
    except Exception as e:
        logger.error(f"Error updating job execution: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/services/<service_id>/slas/organized', methods=['GET'])
@require_auth
def get_organized_slas(service_id):
    """
    Get SLAs organized by type (service-level vs job-level)
    Returns: {"service_level": [...], "job_level": [...]}
    """
    try:
        active_only = request.args.get('active_only', 'false').lower() == 'true'
        organized_slas = db_service.get_all_slas_for_service_and_jobs(service_id, active_only)
        
        return jsonify(organized_slas)
    
    except Exception as e:
        logger.error(f"Error getting organized SLAs: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/jobs', methods=['POST', 'OPTIONS'])
@require_auth
def create_job():
    """Create new job"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.json
        org_id = get_user_org()
        
        # Generate job ID
        job_id = f"job-{uuid.uuid4().hex[:8]}"
        
        # Prepare job data
        job_data = {
            'job_id': job_id,
            'org_id': org_id,
            'service_id': data.get('service_id'),
            'asset_id': data.get('asset_id'),
            'job_name': data['job_name'],
            'job_type': data.get('job_type', 'ETL'),
            'deployment_location': data.get('deployment_location', 'autosys'),
            'schedule': data.get('schedule'),
            'description': data.get('description'),
            'expected_duration': data.get('expected_duration', 60),
            'is_active': True
        }
        
        # Insert into database
        with db_service.get_connection() as conn:
            conn.execute("""
                INSERT INTO jobs (job_id, org_id, service_id, asset_id, job_name, 
                                  job_type, deployment_location, schedule, description, 
                                  expected_duration, is_active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (
                job_data['job_id'],
                job_data['org_id'],
                job_data['service_id'],
                job_data['asset_id'],
                job_data['job_name'],
                job_data['job_type'],
                job_data['deployment_location'],
                job_data['schedule'],
                job_data['description'],
                job_data['expected_duration'],
                1  # is_active
            ))
        
        logger.info(f"Created job: {job_data['job_name']} (type: {job_data['job_type']}, schedule: {job_data['schedule']})")
        
        # Create audit log
        log_id = f"log-{uuid.uuid4().hex[:12]}"
        db_service.create_audit_log({
            'log_id': log_id,
            'org_id': org_id,
            'user_id': request.user_id,
            'action': 'create_job',
            'resource_type': 'job',
            'resource_id': job_id,
            'ip_address': request.remote_addr,
            'metadata': {
                'job_name': job_data['job_name'],
                'job_type': job_data['job_type'],
                'schedule': job_data['schedule']
            }
        })
        
        return jsonify({
            'job_id': job_id,
            'message': 'Job created successfully'
        }), 201
        
    except Exception as e:
        logger.error(f"Error creating job: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/jobs', methods=['GET', 'OPTIONS'])
@require_auth
def get_jobs():
    """Get all jobs for organization"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        
        # Optional filters
        service_id = request.args.get('service_id')
        asset_id = request.args.get('asset_id')
        is_active = request.args.get('is_active')
        
        # Build query
        query = """
            SELECT 
                job_id, org_id, asset_id, service_id,
                job_name, job_type, deployment_location,
                schedule, description, expected_duration,
                is_active, created_at, updated_at
            FROM jobs
            WHERE org_id = ?
        """
        params = [org_id]
        
        # Apply filters
        if service_id:
            query += " AND service_id = ?"
            params.append(service_id)
        
        if asset_id:
            query += " AND asset_id = ?"
            params.append(asset_id)
        
        if is_active is not None:
            query += " AND is_active = ?"
            params.append(1 if is_active.lower() == 'true' else 0)
        
        query += " ORDER BY created_at DESC"
        
        # Execute query
        with db_service.get_connection() as conn:
            cursor = conn.execute(query, params)
            columns = [description[0] for description in cursor.description]
            rows = cursor.fetchall()
            
            jobs = [dict(zip(columns, row)) for row in rows]
        
        # Add sla_count for each job
        for job in jobs:
            with db_service.get_connection() as conn:
                cursor = conn.execute(
                    "SELECT COUNT(*) as count FROM slas WHERE job_id = ?",
                    (job['job_id'],)
                )
                job['sla_count'] = cursor.fetchone()['count']
        
        logger.info(f"Retrieved {len(jobs)} jobs for org {org_id}")
        
        return jsonify({
            'success': True,
            'data': jobs,
            'count': len(jobs)
        })
        
    except Exception as e:
        logger.error(f"Error getting jobs: {str(e)}")
        return jsonify({
            'error': 'Failed to retrieve jobs',
            'message': str(e)
        }), 500
    
@app.route('/api/v1/jobs/<job_id>/slas', methods=['GET'])
@require_auth
def get_job_slas(job_id):
    """Get all SLAs for a specific job"""
    try:
        active_only = request.args.get('active_only', 'false').lower() == 'true'
        slas = db_service.get_job_level_slas(job_id, active_only)
        
        return jsonify({
            'data': slas,
            'count': len(slas)
        })
    
    except Exception as e:
        logger.error(f"Error getting job SLAs: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/jobs/<job_id>', methods=['GET', 'OPTIONS', 'PUT', 'DELETE'])
@require_auth
def job_detail(job_id):
    """Get, update, or delete a specific job"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        
        if request.method == 'GET':
            # Get job details
            with db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT 
                        job_id, org_id, asset_id, service_id,
                        job_name, job_type, deployment_location,
                        schedule, description, expected_duration,
                        is_active, created_at, updated_at,
                        job_identifier, log_template, log_server_type
                    FROM jobs
                    WHERE job_id = ? AND org_id = ?
                """, (job_id, org_id))
                
                row = cursor.fetchone()
                
                if not row:
                    return jsonify({
                        'error': 'Job not found'
                    }), 404
                
                columns = [description[0] for description in cursor.description]
                job = dict(zip(columns, row))
            
            logger.info(f"Retrieved job {job_id}")
            
            return jsonify({
                'success': True,
                'data': job
            })
        
        elif request.method == 'PUT':
            # Update job
            data = request.get_json()
            
            # Validate job exists and belongs to org
            with db_service.get_connection() as conn:
                cursor = conn.execute("""
                    SELECT job_id FROM jobs
                    WHERE job_id = ? AND org_id = ?
                """, (job_id, org_id))
                
                if not cursor.fetchone():
                    return jsonify({
                        'error': 'Job not found'
                    }), 404
                
                # Build update query
                update_fields = []
                params = []
                
                if 'job_name' in data:
                    update_fields.append('job_name = ?')
                    params.append(data['job_name'])
                
                if 'job_type' in data:
                    update_fields.append('job_type = ?')
                    params.append(data['job_type'])
                
                if 'deployment_location' in data:
                    update_fields.append('deployment_location = ?')
                    params.append(data['deployment_location'])
                
                if 'schedule' in data:
                    update_fields.append('schedule = ?')
                    params.append(data['schedule'])
                
                if 'description' in data:
                    update_fields.append('description = ?')
                    params.append(data['description'])
                
                if 'expected_duration' in data:
                    update_fields.append('expected_duration = ?')
                    params.append(data['expected_duration'])
                
                if 'is_active' in data:
                    update_fields.append('is_active = ?')
                    params.append(1 if data['is_active'] else 0)
                
                # ADDED: Log monitoring fields
                if 'job_identifier' in data:
                    update_fields.append('job_identifier = ?')
                    params.append(data['job_identifier'])
                
                if 'log_template' in data:
                    update_fields.append('log_template = ?')
                    params.append(data['log_template'])
                
                if 'log_server_type' in data:
                    update_fields.append('log_server_type = ?')
                    params.append(data['log_server_type'])
                
                # Always update updated_at
                update_fields.append('updated_at = CURRENT_TIMESTAMP')
                
                if not update_fields:
                    return jsonify({
                        'error': 'No fields to update'
                    }), 400
                
                # Update job
                params.extend([job_id, org_id])
                conn.execute(f"""
                    UPDATE jobs
                    SET {', '.join(update_fields)}
                    WHERE job_id = ? AND org_id = ?
                """, params)
                
                # Get updated job
                cursor = conn.execute("""
                    SELECT 
                        job_id, org_id, asset_id, service_id,
                        job_name, job_type, deployment_location,
                        schedule, description, expected_duration,
                        is_active, created_at, updated_at,
                        job_identifier, log_template, log_server_type
                    FROM jobs
                    WHERE job_id = ? AND org_id = ?
                """, (job_id, org_id))
                
                row = cursor.fetchone()
                columns = [description[0] for description in cursor.description]
                job = dict(zip(columns, row))
            
            logger.info(f"Updated job {job_id}")
            
            return jsonify({
                'success': True,
                'data': job,
                'message': 'Job updated successfully'
            })
        
        elif request.method == 'DELETE':
            # Delete job
            with db_service.get_connection() as conn:
                # Check if job exists
                cursor = conn.execute("""
                    SELECT job_id FROM jobs
                    WHERE job_id = ? AND org_id = ?
                """, (job_id, org_id))
                
                if not cursor.fetchone():
                    return jsonify({
                        'error': 'Job not found'
                    }), 404
                
                # Delete job (CASCADE will delete related SLAs)
                conn.execute("""
                    DELETE FROM jobs
                    WHERE job_id = ? AND org_id = ?
                """, (job_id, org_id))
            
            logger.info(f"Deleted job {job_id}")
            
            return jsonify({
                'success': True,
                'message': 'Job deleted successfully'
            })
    
    except Exception as e:
        logger.error(f"Error handling job {job_id}: {str(e)}")
        return jsonify({
            'error': 'Failed to process request',
            'message': str(e)
        }), 500
    
# ===== HELP BOT ENDPOINTS =====

@app.route('/api/v1/help/ask', methods=['POST'])
def ask_help():
    """
    Process help question and return answer
    Can use AI (Claude/ChatGPT) or mock responses
    """
    try:
        data = request.json
        question = data.get('question')
        session_id = data.get('session_id')
        current_page = data.get('current_page', '/')
        context = data.get('context', '')
        
        if not question:
            return jsonify({'error': 'Question is required'}), 400
        
        # Start timer
        import time
        start_time = time.time()
        
        # Try to get AI response (if configured)
        # For now, return mock response
        # In production, you could integrate with OpenAI/Claude API here
        
        answer = generate_mock_answer(question, current_page, context)
        provider = 'mock'
        
        # Calculate response time
        response_time_ms = int((time.time() - start_time) * 1000)
        
        return jsonify({
            'answer': answer,
            'provider': provider,
            'response_time_ms': response_time_ms,
            'session_id': session_id
        })
        
    except Exception as e:
        logger.error(f"Error in ask_help: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/help/log', methods=['POST'])
def log_help_question():
    """Log help question for analytics"""
    try:
        data = request.json
        
        # Get user_id if authenticated, otherwise None
        user_id = getattr(request, 'user_id', None)
        
        with db_service.get_connection() as conn:
            conn.execute("""
                INSERT INTO help_questions_log (
                    user_id, question, answer, provider, current_page,
                    response_time_ms, session_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                user_id,
                data.get('question'),
                data.get('answer'),
                data.get('provider', 'mock'),
                data.get('current_page'),
                data.get('response_time_ms'),
                data.get('session_id')
            ))
        
        return jsonify({'message': 'Question logged successfully'})
        
    except Exception as e:
        logger.error(f"Error logging help question: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/help/feedback', methods=['POST'])
def submit_help_feedback():
    """Submit feedback on help response"""
    try:
        data = request.json
        message_id = data.get('message_id')
        was_helpful = data.get('was_helpful')
        feedback_text = data.get('feedback_text', '')
        session_id = data.get('session_id')
        
        with db_service.get_connection() as conn:
            # Update the most recent question in this session
            conn.execute("""
                UPDATE help_questions_log
                SET was_helpful = ?, feedback_text = ?
                WHERE session_id = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, (was_helpful, feedback_text, session_id))
        
        return jsonify({'message': 'Feedback submitted successfully'})
        
    except Exception as e:
        logger.error(f"Error submitting feedback: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/help/analytics', methods=['GET'])
@require_auth
def get_help_analytics():
    """Get help bot usage analytics"""
    try:
        org_id = get_user_org()
        days = int(request.args.get('days', 30))
        
        with db_service.get_connection() as conn:
            # Get question statistics
            cursor = conn.execute("""
                SELECT 
                    COUNT(*) as total_questions,
                    COUNT(DISTINCT user_id) as unique_users,
                    AVG(response_time_ms) as avg_response_time,
                    COUNT(CASE WHEN was_helpful = 1 THEN 1 END) as helpful_count,
                    COUNT(CASE WHEN was_helpful = 0 THEN 1 END) as not_helpful_count,
                    provider
                FROM help_questions_log
                WHERE created_at >= datetime('now', '-' || ? || ' days')
                GROUP BY provider
            """, (days,))
            
            stats = [dict(row) for row in cursor.fetchall()]
            
            # Get most common questions
            cursor = conn.execute("""
                SELECT question, COUNT(*) as count
                FROM help_questions_log
                WHERE created_at >= datetime('now', '-' || ? || ' days')
                GROUP BY LOWER(question)
                ORDER BY count DESC
                LIMIT 10
            """, (days,))
            
            common_questions = [dict(row) for row in cursor.fetchall()]
            
            # Get questions by page
            cursor = conn.execute("""
                SELECT current_page, COUNT(*) as count
                FROM help_questions_log
                WHERE created_at >= datetime('now', '-' || ? || ' days')
                GROUP BY current_page
                ORDER BY count DESC
            """, (days,))
            
            questions_by_page = [dict(row) for row in cursor.fetchall()]
            
        return jsonify({
            'stats': stats,
            'common_questions': common_questions,
            'questions_by_page': questions_by_page,
            'period_days': days
        })
        
    except Exception as e:
        logger.error(f"Error getting help analytics: {str(e)}")
        return jsonify({'error': str(e)}), 500


# Helper function for mock responses
def generate_mock_answer(question, current_page, context):
    """
    Generate mock answer based on question and context
    In production, this would call an AI API
    """
    q = question.lower()
    
    # Page-specific responses
    if '/onboarding' in current_page:
        if 'asset' in q:
            return "In the onboarding wizard, create your asset in Step 1 by providing a name, type, and owner. The asset represents the infrastructure that runs your services."
        elif 'service' in q:
            return "Step 2 creates a service. Services are business capabilities that run on your assets. Provide a name, owner team, and select the deployment location."
        elif 'job' in q:
            return "Step 3 adds a scheduled job. Jobs are batch processes that run on a schedule. Specify the job name, type, and cron schedule. Use the cron helper for assistance!"
        elif 'sla' in q:
            return "Step 4 defines your SLA. Choose a metric type (uptime, response time, etc.), set your target percentage, and priority. The SLA calculator helps you understand downtime allowances."
    
    elif '/process-flow' in current_page:
        if 'expand' in q or 'collapse' in q:
            return "Click the arrow (▶/▼) next to any node to expand or collapse it. Use the 'Expand All' button in the toolbar to open the entire hierarchy at once."
        elif 'search' in q:
            return "Use the search box at the top to filter assets, services, and jobs. The search works across all names in real-time."
        elif 'zoom' in q:
            return "Use the zoom controls (+/-) in the toolbar to adjust the view. You can zoom from 50% to 150%. Click the reset button to return to 100%."
    
    elif '/dashboard' in current_page:
        if 'metric' in q or 'statistic' in q:
            return "The dashboard shows key metrics: total assets, services, SLAs, active alerts, and compliance rates. Click any metric card to drill down for details."
        elif 'chart' in q or 'graph' in q:
            return "Dashboard charts show compliance trends over time, service health status, and alert history. Hover over data points for detailed information."
    
    # General questions
    if 'create' in q and 'asset' in q:
        return "To create an asset: Go to Assets → Click 'Create Asset' → Fill in name, type, owner, and description → Save. Or use the Onboarding wizard for guided setup."
    
    elif 'create' in q and 'service' in q:
        return "To create a service: Go to Services → Click 'Create Service' → Select the asset → Provide service name, owner team, and configuration → Save."
    
    elif 'create' in q and 'sla' in q:
        return "To create an SLA: Go to SLAs → Click 'Create SLA' → Select service or job → Choose metric type → Set target value and priority → Configure conditions → Save."
    
    elif 'alert' in q or 'notification' in q:
        return "Alerts are generated when SLAs are breached. View them in the Alerts page or dashboard. You can acknowledge, resolve, or configure escalation policies for automated handling."
    
    elif 'import' in q or 'bulk' in q:
        return "Bulk import is available through Tools → Import Data. Connect to Autosys, Ansible Tower, or upload CSV files. Map fields, preview, and import multiple items at once."
    
    elif 'job' in q and 'sla' in q:
        return "Job-level SLAs apply to specific scheduled jobs, while service-level SLAs apply to the entire service. A service can have both types. Use job-level SLAs for specific completion requirements."
    
    elif 'cron' in q or 'schedule' in q:
        return "Cron format: minute hour day month weekday (e.g., '0 2 * * *' = 2 AM daily). Use the cron helper in the job creation form for common schedules and examples."
    
    elif 'compliance' in q:
        return "SLA compliance is calculated as: (total evaluations - breaches) / total evaluations × 100%. View compliance reports in the Dashboard or SLA detail pages."
    
    # Default response
    return "I'm here to help! I can assist with creating assets, services, jobs, and SLAs, understanding the process flow, troubleshooting issues, and navigating the portal. What specific aspect would you like to know more about?"

# ===== CONNECTOR MANAGEMENT ENDPOINTS =====

@app.route('/api/v1/connectors', methods=['GET', 'OPTIONS'])
@require_auth
def get_connectors():
    """Get all configured connectors with import stats"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        
        # Get optional type filter from query params
        connector_type = request.args.get('type')
        
        # Build WHERE clause
        where_conditions = ["cc.org_id = ?", "cc.is_active = 1"]
        params = [org_id]
        
        if connector_type:
            if connector_type == 'service':
                # For service requests, return connectors with service-related platforms
                # This excludes job-specific connectors even though they share the same connector_type
                where_conditions.append("(cc.connector_type IN ('service', 'service_job') AND cc.platform NOT IN ('demo_job', 'autosys'))")
            elif connector_type == 'job':
                # For job requests, return connectors with job-related platforms
                where_conditions.append("(cc.connector_type IN ('job', 'service_job') AND cc.platform IN ('demo_job', 'autosys', 'ansible_tower'))")
            else:
                # For asset and sla, use exact match
                where_conditions.append("cc.connector_type = ?")
                params.append(connector_type)
        
        where_clause = " AND ".join(where_conditions)
        
        with db_service.get_connection() as conn:
            cursor = conn.execute(f"""
                SELECT 
                    cc.id as connector_id,
                    cc.connector_type,
                    cc.connector_name,
                    cc.platform,
                    cc.api_endpoint_url,
                    cc.is_active,
                    cc.created_at,
                    cc.updated_at,
                    (SELECT COUNT(*) FROM import_history ih 
                     WHERE ih.connector_config_id = cc.id) as total_imports,
                    (SELECT MAX(started_at) FROM import_history ih 
                     WHERE ih.connector_config_id = cc.id) as last_import,
                    (SELECT status FROM import_history ih 
                     WHERE ih.connector_config_id = cc.id 
                     ORDER BY started_at DESC LIMIT 1) as last_import_status
                FROM connector_configurations cc
                WHERE {where_clause}
                ORDER BY cc.connector_type, cc.connector_name
            """, tuple(params))
            
            connectors = [dict(row) for row in cursor.fetchall()]
        
        return jsonify({'data': connectors}), 200
        
    except Exception as e:
        logger.error(f"Error getting connectors: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/connectors/<int:connector_id>/test', methods=['POST'])
@require_auth
def test_connector(connector_id):
    '''Test connector connection'''
    try:
        org_id = get_user_org()
        
        # Get connector config
        with db_service.get_connection() as conn:
            cursor = conn.execute('''
                SELECT id, connector_type, connector_name, platform,
                       api_endpoint_url, api_key, is_active
                FROM connector_configurations
                WHERE id = ? AND org_id = ?
            ''', (connector_id, org_id))
            
            row = cursor.fetchone()
            if not row:
                return jsonify({'error': 'Connector not found'}), 404
            
            config = dict(row)
        
        # Create connector config dict
        connector_config = {
            'id': config['id'],
            'connector_type': config['connector_type'],
            'platform': config.get('platform'),
            'api_endpoint': config['api_endpoint_url'],
            'api_key': config.get('api_key')
        }
        
        # Map service_job to actual type based on platform
        actual_connector_type = config['connector_type']
        if actual_connector_type == 'service_job':
            platform = config.get('platform', '')
            if platform in ['demo_job', 'autosys']:
                actual_connector_type = 'job'
            else:
                actual_connector_type = 'service'
        
        # Test connection using factory
        connector = get_connector(actual_connector_type, connector_config)
        is_connected = connector.test_connection()
        connector.close()
        
        return jsonify({
            'success': is_connected,
            'message': 'Connection successful' if is_connected else 'Connection failed',
            'connector_name': config['connector_name']
        })
        
    except Exception as e:
        logger.error(f"Error testing connector: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/v1/connectors/<int:connector_id>/fetch', methods=['POST'])
@require_auth
def fetch_connector_data(connector_id):
    '''Fetch data from connector with field mappings applied'''
    try:
        org_id = get_user_org()
        data = request.json
        filters = data.get('filters', {})
        
        # Get connector config AND field mappings
        with db_service.get_connection() as conn:
            cursor = conn.execute('''
                SELECT id, connector_type, connector_name, platform,
                       api_endpoint_url, api_key
                FROM connector_configurations
                WHERE id = ? AND org_id = ? AND is_active = 1
            ''', (connector_id, org_id))
            
            row = cursor.fetchone()
            if not row:
                return jsonify({'error': 'Connector not found or inactive'}), 404
            
            config = dict(row)
            
            # Get field mappings for this connector
            cursor = conn.execute('''
                SELECT source_field, target_field, transformation_rule, is_required
                FROM field_mappings
                WHERE connector_config_id = ?
                ORDER BY field_order
            ''', (connector_id,))
            
            field_mappings = [dict(row) for row in cursor.fetchall()]
        
        # Create connector
        connector_config = {
            'id': config['id'],
            'connector_type': config['connector_type'],
            'platform': config.get('platform'),
            'api_endpoint': config['api_endpoint_url'],
            'api_key': config.get('api_key')
        }
        
        # Map service_job to actual type based on platform
        # The connector factory expects 'service' or 'job', not 'service_job'
        actual_connector_type = config['connector_type']
        if actual_connector_type == 'service_job':
            # Determine if it's a service or job based on platform
            platform = config.get('platform', '')
            if platform in ['demo_job', 'autosys']:
                actual_connector_type = 'job'
            else:
                actual_connector_type = 'service'
        
        connector = get_connector(actual_connector_type, connector_config)
        
        # Fetch raw data from connector
        raw_data = connector.fetch_data(filters)
        
        # Apply field mappings to transform data
        mapped_data = []
        for item in raw_data:
            mapped_item = apply_field_mappings(item, field_mappings)
            mapped_data.append(mapped_item)
        
        connector.close()
        
        logger.info(f"Fetched {len(raw_data)} records, mapped to {len(mapped_data)} records")
        
        return jsonify({
            'data': mapped_data,
            'count': len(mapped_data),
            'connector_name': config['connector_name'],
            'connector_type': config['connector_type'],
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error fetching connector data: {str(e)}")
        return jsonify({'error': str(e)}), 500


def apply_field_mappings(source_data: dict, field_mappings: list) -> dict:
    """
    Apply field mappings to transform source data to target format
    
    Handles both:
    - Field mappings: source_field exists in source_data (e.g., 'host_name')
    - Static values: source_field doesn't exist in source_data (e.g., '12/25/2025', 'Active')
    
    Args:
        source_data: Raw data from connector
        field_mappings: List of mapping rules with source_field, target_field
        
    Returns:
        Transformed data with target field names
    """
    result = {}
    
    # Keep all original fields
    result.update(source_data)
    
    # Apply each mapping
    for mapping in field_mappings:
        source_field = mapping.get('source_field', '')
        target_field = mapping.get('target_field', '')
        
        if not source_field or not target_field:
            continue
        
        # Check if source_field exists in the source data
        if source_field in source_data:
            # Field mapping - get value from source data
            source_value = source_data[source_field]
            logger.debug(f"Field mapping: {source_field} -> {target_field} = {source_value}")
        else:
            # Static value - use source_field as the literal value
            source_value = source_field
            logger.debug(f"Static value: {target_field} = {source_value}")
        
        # Set target field
        result[target_field] = source_value
    
    return result


@app.route('/api/v1/connectors/<int:connector_id>/import', methods=['POST'])
@require_auth
def import_connector_data(connector_id):
    '''Bulk import data from connector'''
    import time
    start_time = time.time()
    
    try:
        org_id = get_user_org()
        user_id = request.user_id
        data = request.json
        selected_data = data.get('selected_data', [])
        asset_mapping = data.get('asset_mapping', {})
        
        if not selected_data:
            return jsonify({'error': 'No data selected for import'}), 400
        
        # Get connector config
        with db_service.get_connection() as conn:
            cursor = conn.execute('''
                SELECT id, connector_type, connector_name, platform,
                       api_endpoint_url, api_key
                FROM connector_configurations
                WHERE id = ? AND org_id = ? AND is_active = 1
            ''', (connector_id, org_id))
            
            row = cursor.fetchone()
            if not row:
                return jsonify({'error': 'Connector not found or inactive'}), 404
            
            config = dict(row)
            
            # Get field mappings
            cursor = conn.execute('''
                SELECT source_field, target_field, transformation_rule, is_required
                FROM field_mappings
                WHERE connector_config_id = ?
                ORDER BY id
            ''', (connector_id,))
            
            field_mappings = [dict(row) for row in cursor.fetchall()]
        
        # Create connector
        connector_config = {
            'id': config['id'],
            'connector_type': config['connector_type'],
            'platform': config.get('platform'),
            'api_endpoint': config['api_endpoint_url'],
            'api_key': config.get('api_key')
        }
        
        # Map service_job to actual type based on platform
        actual_connector_type = config['connector_type']
        if actual_connector_type == 'service_job':
            platform = config.get('platform', '')
            if platform in ['demo_job', 'autosys']:
                actual_connector_type = 'job'
            else:
                actual_connector_type = 'service'
        
        connector = get_connector(actual_connector_type, connector_config)
        
        # Perform import based on connector type
        if config['connector_type'] == 'asset':
            result = connector.bulk_import_assets(
                org_id=org_id,
                assets=selected_data,
                field_mappings=field_mappings
            )
        elif config['connector_type'] == 'service_job':
            result = connector.bulk_import_services_jobs(
                org_id=org_id,
                jobs=selected_data,
                asset_mapping=asset_mapping,
                field_mappings=field_mappings
            )
        elif config['connector_type'] == 'sla':
            result = connector.bulk_import_slas(
                org_id=org_id,
                slas=selected_data,
                field_mappings=field_mappings
            )
        else:
            return jsonify({'error': 'Invalid connector type'}), 400
        
        connector.close()
        
        # Calculate execution time
        execution_time = int(time.time() - start_time)
        
        # Map connector_type to import_type
        import_type_mapping = {
            'asset': 'asset',
            'service_job': 'service',  # Map service_job to service
            'sla': 'sla'
        }
        import_type = import_type_mapping.get(config['connector_type'], config['connector_type'])
        
        # Log to import_history table
        try:
            with db_service.get_connection() as conn:
                conn.execute('''
                    INSERT INTO import_history (
                        connector_config_id, import_type, records_fetched,
                        records_imported, records_failed, error_details,
                        completed_at, status, imported_by,
                        execution_time_seconds
                    ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?)
                ''', (
                    connector_id,
                    import_type,
                    len(selected_data),
                    result.get('imported', 0),
                    result.get('failed', 0),
                    json.dumps(result.get('errors', [])) if result.get('errors') else None,
                    'completed',  # All imports that finish are 'completed' (even with some failures)
                    user_id,  # imported_by
                    execution_time
                ))
                
            logger.info(f"✓ Import logged to history: {result.get('imported', 0)} succeeded, {result.get('failed', 0)} failed in {execution_time}s")
        except Exception as history_error:
            logger.warning(f"Failed to log import history: {history_error}")
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error importing connector data: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/connectors', methods=['POST', 'OPTIONS'])
@require_auth
def create_connector():
    """Create new connector with field mappings"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.json
        org_id = get_user_org()
        user_id = request.user_id
        
        # Validate required fields
        if not data.get('connector_name'):
            return jsonify({'error': 'Connector name is required'}), 400
        if not data.get('connector_type'):
            return jsonify({'error': 'Connector type is required'}), 400
        if not data.get('api_endpoint_url'):
            return jsonify({'error': 'API endpoint URL is required'}), 400
        
        # Validate connector_type
        # Accept both individual types (service, job) and combined type (service_job)
        valid_types = ['asset', 'service', 'job', 'service_job', 'sla']
        if data['connector_type'] not in valid_types:
            return jsonify({'error': f'Invalid connector type. Must be one of: {", ".join(valid_types)}'}), 400
        
        # Validate platform (optional)
        if data.get('platform'):
            valid_platforms = ['autosys', 'ansible_tower', 'custom', 'demo_autosys', 'demo_ansible', 'demo_asset', 'demo_service', 'demo_job', 'demo_sla']
            if data['platform'] not in valid_platforms:
                return jsonify({'error': f'Invalid platform. Must be one of: {", ".join(valid_platforms)}'}), 400
        
        # Get field mappings from request (JSON object)
        field_mappings = data.get('field_mappings', {})
        if isinstance(field_mappings, str):
            field_mappings = json.loads(field_mappings)
        
        # Insert connector into database
        with db_service.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO connector_configurations (
                    org_id, connector_type, connector_name, platform,
                    api_endpoint_url, api_key, is_active, created_by,
                    created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, 1, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (
                org_id,
                data['connector_type'],
                data['connector_name'],
                data.get('platform'),
                data['api_endpoint_url'],
                data.get('api_key'),
                user_id
            ))
            
            connector_id = cursor.lastrowid
            
            # Insert field mappings
            if field_mappings:
                field_order = 0
                for target_field, source_field in field_mappings.items():
                    # Determine if field is required based on connector type
                    is_required = is_field_required(data['connector_type'], target_field)
                    
                    cursor.execute("""
                        INSERT INTO field_mappings (
                            connector_config_id, source_field, target_field,
                            is_required, field_order, created_at
                        )
                        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    """, (
                        connector_id,
                        source_field,
                        target_field,
                        is_required,
                        field_order
                    ))
                    field_order += 1
                
                logger.info(f"Created {len(field_mappings)} field mappings for connector {connector_id}")
        
        logger.info(f"Created connector: {data['connector_name']} (type: {data['connector_type']}, id: {connector_id})")
        
        # Create audit log
        try:
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': org_id,
                'user_id': user_id,
                'action': 'create_connector',
                'resource_type': 'connector',
                'resource_id': str(connector_id),
                'ip_address': request.remote_addr,
                'metadata': {
                    'name': data['connector_name'],
                    'type': data['connector_type'],
                    'platform': data.get('platform'),
                    'field_mappings_count': len(field_mappings)
                }
            })
        except Exception as audit_error:
            logger.warning(f"Failed to create audit log: {audit_error}")
        
        return jsonify({
            'id': connector_id,
            'message': 'Connector created successfully',
            'field_mappings_count': len(field_mappings)
        }), 201
        
    except Exception as e:
        logger.error(f"Error creating connector: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


def is_field_required(connector_type, field_name):
    """
    Helper function to determine if a field is required for a connector type
    
    Args:
        connector_type: Type of connector ('asset', 'service_job', 'sla')
        field_name: Name of the field
        
    Returns:
        Boolean indicating if field is required
    """
    required_fields = {
        'asset': ['asset_name', 'asset_type', 'asset_owner', 'description'],
        'service': ['service_name', 'service_type', 'owner', 'description'],
        'job': ['job_name', 'job_type', 'owner', 'description'],
        'service_job': ['service_name', 'service_type', 'owner', 'description'],
        'sla': ['sla_name', 'target_metric', 'threshold', 'owner']
    }
    
    return field_name in required_fields.get(connector_type, [])

@app.route('/api/v1/connectors/<int:connector_id>/field-mappings', methods=['GET', 'OPTIONS'])
@require_auth
def get_field_mappings(connector_id):
    """Get field mappings for a connector"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        
        with db_service.get_connection() as conn:
            # Verify connector belongs to org
            cursor = conn.execute("""
                SELECT id FROM connector_configurations
                WHERE id = ? AND org_id = ?
            """, (connector_id, org_id))
            
            if not cursor.fetchone():
                return jsonify({'error': 'Connector not found'}), 404
            
            # Get field mappings
            cursor = conn.execute("""
                SELECT id, source_field, target_field, transformation_rule,
                       is_required, field_order
                FROM field_mappings
                WHERE connector_config_id = ?
                ORDER BY field_order
            """, (connector_id,))
            
            mappings = []
            for row in cursor.fetchall():
                mappings.append({
                    'id': row[0],
                    'source_field': row[1],
                    'target_field': row[2],
                    'transformation_rule': row[3],
                    'is_required': bool(row[4]),
                    'field_order': row[5]
                })
        
        return jsonify({
            'connector_id': connector_id,
            'mappings': mappings
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting field mappings: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/v1/connectors/<int:connector_id>', methods=['GET', 'OPTIONS'])
@require_auth
def get_connector_details(connector_id):
    """Get specific connector by ID"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        
        with db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT cc.*,
                       (SELECT COUNT(*) FROM field_mappings fm WHERE fm.connector_config_id = cc.id) as mapping_count,
                       (SELECT COUNT(*) FROM import_history ih WHERE ih.connector_config_id = cc.id) as import_count
                FROM connector_configurations cc
                WHERE cc.id = ? AND cc.org_id = ? AND cc.is_active = 1
            """, (connector_id, org_id))
            
            row = cursor.fetchone()
            if not row:
                return jsonify({'error': 'Connector not found'}), 404
            
            connector = dict(row)
            
            # Get field mappings
            cursor = conn.execute("""
                SELECT * FROM field_mappings 
                WHERE connector_config_id = ?
                ORDER BY field_order, id
            """, (connector_id,))
            
            connector['field_mappings'] = [dict(r) for r in cursor.fetchall()]
        
        return jsonify(connector), 200
        
    except Exception as e:
        logger.error(f"Error getting connector: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/connectors/<int:connector_id>', methods=['PUT', 'OPTIONS'])
@require_auth
def update_connector(connector_id):
    """Update connector"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.json
        org_id = get_user_org()
        user_id = request.user_id
        
        # Check connector exists
        with db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT id FROM connector_configurations 
                WHERE id = ? AND org_id = ?
            """, (connector_id, org_id))
            
            if not cursor.fetchone():
                return jsonify({'error': 'Connector not found'}), 404
            
            # Get field mappings from request
            field_mappings = data.get('field_mappings', {})
            if isinstance(field_mappings, str):
                field_mappings = json.loads(field_mappings)
            
            # Build update query dynamically
            update_parts = []
            params = []
            
            if 'connector_name' in data:
                update_parts.append('connector_name = ?')
                params.append(data['connector_name'])
            if 'connector_type' in data:
                update_parts.append('connector_type = ?')
                params.append(data['connector_type'])
            if 'platform' in data:
                update_parts.append('platform = ?')
                params.append(data['platform'])
            if 'api_endpoint_url' in data:
                update_parts.append('api_endpoint_url = ?')
                params.append(data['api_endpoint_url'])
            if 'api_key' in data:
                update_parts.append('api_key = ?')
                params.append(data['api_key'])
            if 'is_active' in data:
                update_parts.append('is_active = ?')
                params.append(1 if data['is_active'] else 0)
            
            if update_parts:
                update_parts.append('updated_at = CURRENT_TIMESTAMP')
                update_parts.append('updated_by = ?')
                params.extend([user_id, connector_id, org_id])
                
                conn.execute(f"""
                    UPDATE connector_configurations 
                    SET {', '.join(update_parts)}
                    WHERE id = ? AND org_id = ?
                """, params)
            
            # Update field mappings if provided
            if field_mappings:
                # Delete old mappings
                conn.execute("""
                    DELETE FROM field_mappings 
                    WHERE connector_config_id = ?
                """, (connector_id,))
                
                # Insert new mappings
                field_order = 0
                for target_field, source_field in field_mappings.items():
                    is_required = is_field_required(
                        data.get('connector_type', ''), 
                        target_field
                    )
                    
                    conn.execute("""
                        INSERT INTO field_mappings (
                            connector_config_id, source_field, target_field,
                            is_required, field_order, created_at
                        )
                        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    """, (
                        connector_id,
                        source_field,
                        target_field,
                        is_required,
                        field_order
                    ))
                    field_order += 1
                
                logger.info(f"Updated {len(field_mappings)} field mappings for connector {connector_id}")
        
        logger.info(f"Updated connector: {connector_id}")
        
        # Create audit log
        try:
            log_id = f"log-{uuid.uuid4().hex[:12]}"
            db_service.create_audit_log({
                'log_id': log_id,
                'org_id': org_id,
                'user_id': user_id,
                'action': 'update_connector',
                'resource_type': 'connector',
                'resource_id': str(connector_id),
                'ip_address': request.remote_addr,
                'metadata': {
                    'name': data.get('connector_name'),
                    'type': data.get('connector_type'),
                    'platform': data.get('platform'),
                    'field_mappings_count': len(field_mappings)
                }
            })
        except Exception as audit_error:
            logger.warning(f"Failed to create audit log: {audit_error}")
        
        return jsonify({
            'id': connector_id,
            'message': 'Connector updated successfully',
            'field_mappings_count': len(field_mappings)
        }), 200
        
    except Exception as e:
        logger.error(f"Error updating connector: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/connectors/<int:connector_id>', methods=['DELETE', 'OPTIONS'])
@require_auth
def delete_connector(connector_id):
    """Delete connector (soft delete)"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        user_id = request.user_id
        
        with db_service.get_connection() as conn:
            conn.execute("""
                UPDATE connector_configurations 
                SET is_active = 0, updated_at = CURRENT_TIMESTAMP, updated_by = ?
                WHERE id = ? AND org_id = ?
            """, (user_id, connector_id, org_id))
        
        logger.info(f"Deleted connector: {connector_id}")
        
        return jsonify({'message': 'Connector deleted successfully'}), 200
        
    except Exception as e:
        logger.error(f"Error deleting connector: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/connectors/<int:connector_id>/sync', methods=['POST', 'OPTIONS'])
@require_auth
def sync_connector(connector_id):
    """Trigger connector sync/import (simplified version)"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        user_id = request.user_id
        
        # Get connector
        with db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM connector_configurations 
                WHERE id = ? AND org_id = ? AND is_active = 1
            """, (connector_id, org_id))
            
            row = cursor.fetchone()
            if not row:
                return jsonify({'error': 'Connector not found'}), 404
            
            connector = dict(row)
        
        # Create import history record
        started_at = datetime.now()
        
        with db_service.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO import_history (
                    connector_config_id, import_type, records_fetched,
                    records_imported, records_failed, started_at,
                    status, imported_by
                )
                VALUES (?, ?, 0, 0, 0, ?, 'in_progress', ?)
            """, (connector_id, connector['connector_type'], started_at, user_id))
            
            import_id = cursor.lastrowid
        
        # TODO: Implement actual sync logic here
        # For now, simulate a successful sync
        import time
        time.sleep(0.5)  # Simulate API call
        
        completed_at = datetime.now()
        execution_time = int((completed_at - started_at).total_seconds())
        
        with db_service.get_connection() as conn:
            conn.execute("""
                UPDATE import_history 
                SET completed_at = ?,
                    status = 'completed',
                    records_fetched = 10,
                    records_imported = 10,
                    records_failed = 0,
                    execution_time_seconds = ?
                WHERE id = ?
            """, (completed_at, execution_time, import_id))
        
        logger.info(f"Synced connector: {connector_id} (import_id: {import_id})")
        
        return jsonify({
            'import_id': import_id,
            'message': 'Sync completed successfully',
            'records_fetched': 10,
            'records_imported': 10,
            'records_failed': 0
        }), 200
        
    except Exception as e:
        logger.error(f"Error syncing connector: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/connectors/<int:connector_id>/history', methods=['GET', 'OPTIONS'])
@require_auth  
def get_connector_import_history(connector_id):
    """Get import history for connector"""
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        org_id = get_user_org()
        limit = request.args.get('limit', 20, type=int)
        
        with db_service.get_connection() as conn:
            # Verify connector belongs to org
            cursor = conn.execute("""
                SELECT id FROM connector_configurations 
                WHERE id = ? AND org_id = ?
            """, (connector_id, org_id))
            
            if not cursor.fetchone():
                return jsonify({'error': 'Connector not found'}), 404
            
            # Get history
            cursor = conn.execute("""
                SELECT * FROM import_history 
                WHERE connector_config_id = ?
                ORDER BY started_at DESC
                LIMIT ?
            """, (connector_id, limit))
            
            history = []
            for row in cursor.fetchall():
                record = dict(row)
                if record.get('error_details'):
                    try:
                        record['error_details'] = json.loads(record['error_details'])
                    except:
                        pass
                history.append(record)
        
        return jsonify({'history': history}), 200
        
    except Exception as e:
        logger.error(f"Error getting connector history: {str(e)}")
        return jsonify({'error': str(e)}), 500
    
# ============================================
# HELPER FUNCTIONS - Add after get_user_org()
# ============================================

def get_connector_config(connector_id):
    """
    Helper function to get connector configuration by ID
    
    Args:
        connector_id: ID of the connector
        
    Returns:
        dict: Connector configuration or None
    """
    org_id = get_user_org()
    
    with db_service.get_connection() as conn:
        cursor = conn.execute('''
            SELECT id, connector_type, connector_name, platform,
                   api_endpoint_url, api_key, is_active, created_at
            FROM connector_configurations
            WHERE id = ? AND org_id = ?
        ''', (connector_id, org_id))
        
        row = cursor.fetchone()
        if row:
            return dict(row)
        return None


def get_field_mappings_list(connector_id):
    """
    Get field mappings for a connector
    
    Args:
        connector_id: ID of the connector
        
    Returns:
        list: List of field mapping dictionaries
    """
    with db_service.get_connection() as conn:
        cursor = conn.execute('''
            SELECT source_field, target_field, transformation_rule, is_required
            FROM field_mappings
            WHERE connector_config_id = ?
            ORDER BY id
        ''', (connector_id,))
        
        return [dict(row) for row in cursor.fetchall()]

# ============================================
# SYSTEM SETTINGS ENDPOINTS (NEW)
# ============================================

@app.route('/api/v1/settings', methods=['GET'])
@require_auth
def get_system_settings():
    '''Get system settings'''
    try:
        # In production, these would come from database
        # For now, return defaults
        settings = {
            'emailEnabled': True,
            'emailServer': 'smtp.company.com',
            'emailPort': '587',
            'emailFrom': 'sla-portal@company.com',
            'alertRetention': '90',
            'alertBatchSize': '100',
            'criticalAlertEscalation': True,
            'sessionTimeout': '480',
            'enableAuditLog': True,
            'enableMetrics': True,
            'healthCheckInterval': '60',
            'jobCheckInterval': '1800',
            'autoBackup': True,
            'backupRetention': '30',
            'llmProvider': 'mock'
        }
        
        return jsonify({'settings': settings})
        
    except Exception as e:
        logger.error(f"Error getting settings: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/settings', methods=['POST'])
@require_auth
def update_system_settings():
    '''Update system settings'''
    try:
        settings = request.json
        
        # In production, save to database
        # For now, just acknowledge
        logger.info(f"Settings updated: {settings}")
        
        return jsonify({
            'success': True,
            'message': 'Settings updated successfully'
        })
        
    except Exception as e:
        logger.error(f"Error updating settings: {str(e)}")
        return jsonify({'error': str(e)}), 500


# ============================================
# INTEGRATION HEALTH ENDPOINTS (NEW)
# ============================================

@app.route('/api/v1/health/integrations', methods=['GET'])
@require_auth
def get_integration_health():
    '''Get health status of all integrations'''
    try:
        org_id = get_user_org()
        
        # Get all active connectors
        with db_service.get_connection() as conn:
            cursor = conn.execute('''
                SELECT id, connector_name, connector_type, platform,
                       api_endpoint_url, is_active
                FROM connector_configurations
                WHERE org_id = ? AND is_active = 1
                ORDER BY connector_name
            ''', (org_id,))
            
            connectors = [dict(row) for row in cursor.fetchall()]
        
        # Test each connector
        health_results = []
        for connector in connectors:
            try:
                connector_config = {
                    'id': connector['id'],
                    'connector_type': connector['connector_type'],
                    'platform': connector.get('platform'),
                    'api_endpoint': connector['api_endpoint_url'],
                    'api_key': None  # Don't expose API key
                }
                
                conn_instance = get_connector(
                    connector_config['connector_type'], 
                    connector_config
                )
                is_healthy = conn_instance.test_connection()
                conn_instance.close()
                
                health_results.append({
                    'connector_id': connector['id'],
                    'connector_name': connector['connector_name'],
                    'status': 'healthy' if is_healthy else 'unhealthy',
                    'last_checked': datetime.now().isoformat()
                })
                
            except Exception as e:
                health_results.append({
                    'connector_id': connector['id'],
                    'connector_name': connector['connector_name'],
                    'status': 'error',
                    'error': str(e),
                    'last_checked': datetime.now().isoformat()
                })
        
        return jsonify({'health': health_results})
        
    except Exception as e:
        logger.error(f"Error getting integration health: {str(e)}")
        return jsonify({'error': str(e)}), 500


# ============================================
# IMPORT HISTORY ENDPOINT (NEW)
# ============================================

@app.route('/api/v1/connectors/<int:connector_id>/history', methods=['GET'])
@require_auth
def get_import_history(connector_id):
    '''Get import history for a connector'''
    try:
        limit = int(request.args.get('limit', 10))
        
        with db_service.get_connection() as conn:
            cursor = conn.execute('''
                SELECT import_id, data_type, records_attempted,
                       records_successful, records_failed, status,
                       error_details, created_at
                FROM import_history
                WHERE connector_config_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            ''', (connector_id, limit))
            
            history = [dict(row) for row in cursor.fetchall()]
        
        return jsonify({'history': history})
        
    except Exception as e:
        logger.error(f"Error getting import history: {str(e)}")
        return jsonify({'error': str(e)}), 500

# ============================================
# ENHANCED ONBOARDING WIZARD ENDPOINT (NEW)
# ============================================

@app.route('/api/v1/onboarding/complete', methods=['POST', 'OPTIONS'])
@require_auth
def complete_onboarding():
    """
    Complete onboarding with multiple services, jobs, and SLAs
    """
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.json
        org_id = get_user_org()
        user_id = request.user_id
        
        # Validate asset
        asset_data = data.get('asset', {})
        if not asset_data.get('asset_name'):
            return jsonify({'error': 'Asset name is required'}), 400
        
        # Start transaction
        with db_service.get_connection() as conn:
            import uuid
            
            # =================================================================
            # STEP 1: CREATE ASSET
            # =================================================================
            asset_id = f"ASSET-{uuid.uuid4().hex[:8].upper()}"
            
            conn.execute("""
                INSERT INTO assets (
                    asset_id, org_id, asset_name, asset_type, asset_owner,
                    description, onboarded_date, status,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (
                asset_id,
                org_id,
                asset_data.get('asset_name'),
                asset_data.get('asset_type', 'Server'),
                asset_data.get('asset_owner'),
                asset_data.get('description', ''),
                asset_data.get('onboarded_date'),
                asset_data.get('status', 'active').lower()
            ))
            
            logger.info(f"✓ Created asset: {asset_id}")
            
            # =================================================================
            # STEP 2: CREATE SERVICES
            # =================================================================
            services = data.get('services', [])
            service_ids = []
            
            for service_data in services:
                service_id = f"SVC-{uuid.uuid4().hex[:8].upper()}"
                
                # Your services table has: name, description, owner_team, asset_id, 
                # monitoring_method, deployment_location, tags, metadata, is_active
                # It does NOT have: service_name, service_type, or type
                
                # Build metadata JSON from service_type
                import json
                metadata = {}
                if service_data.get('service_type'):
                    metadata['service_type'] = service_data.get('service_type')

                metadata_json = json.dumps(metadata) if metadata else None

                # Extract service identifier
                service_identifier = service_data.get('service_identifier')
                if not service_identifier:
                    service_identifier = service_data.get('service_name', '').upper().replace(' ', '-')[:50]
                
                conn.execute("""
                    INSERT INTO services (
                        service_id, org_id, asset_id, name,
                        description, metadata, 
                        log_template, log_server_type, service_identifier,
                        is_active,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """, (
                    service_id,
                    org_id,
                    asset_id,
                    service_data.get('service_name'),
                    service_data.get('description', ''),
                    metadata_json,
                    service_data.get('log_template', 'custom'),
                    service_data.get('log_server_type', 'custom'),
                    service_identifier,
                    True
                ))
                
                service_ids.append(service_id)
                logger.info(f"✓ Created service: {service_id}")
            
            # =================================================================
            # STEP 3: CREATE JOBS
            # =================================================================
            jobs = data.get('jobs', [])
            job_ids = []
            
            for job_data in jobs:
                job_id = f"JOB-{uuid.uuid4().hex[:8].upper()}"
                
                # Determine parent
                parent_type = job_data.get('parent_type')
                parent_index = job_data.get('parent_index')
                
                if parent_type == 'asset':
                    job_asset_id = asset_id
                    job_service_id = None
                elif parent_type == 'service':
                    job_asset_id = None
                    job_service_id = service_ids[parent_index] if parent_index is not None else None
                else:
                    return jsonify({'error': f'Invalid parent_type: {parent_type}'}), 400
                
                # Jobs table likely has: job_name, job_type, schedule, description, is_active
                # Extract job identifier
                job_identifier = job_data.get('job_identifier')
                if not job_identifier:
                    job_identifier = job_data.get('job_name', '').upper().replace(' ', '-')[:50]
                
                conn.execute("""
                    INSERT INTO jobs (
                        job_id, org_id, asset_id, service_id,
                        job_name, job_type, schedule, description,
                        expected_duration, log_template, log_server_type, job_identifier,
                        is_active, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """, (
                    job_id,
                    org_id,
                    job_asset_id,
                    job_service_id,
                    job_data.get('job_name'),      # Maps to 'job_name'
                    job_data.get('job_type', ''),   # Maps to 'job_type'
                    job_data.get('schedule', ''),
                    job_data.get('description', ''),
                    job_data.get('expected_duration'),
                    job_data.get('log_template', 'custom'),
                    job_data.get('log_server_type', 'custom'),
                    job_identifier,
                    True  # is_active
                ))
                
                job_ids.append(job_id)
                logger.info(f"✓ Created job: {job_id} (parent: {parent_type})")
            
            # =================================================================
            # STEP 4: CREATE SLAS
            # =================================================================
            slas = data.get('slas', [])
            sla_ids = []
            
            for sla_data in slas:
                sla_id = f"SLA-{uuid.uuid4().hex[:8].upper()}"
                
                # Determine target
                target_type = sla_data.get('target_type')
                target_index = sla_data.get('target_index')
                
                if target_type == 'service':
                    sla_service_id = service_ids[target_index] if target_index is not None else None
                    sla_job_id = None
                elif target_type == 'job':
                    sla_service_id = None
                    sla_job_id = job_ids[target_index] if target_index is not None else None
                else:
                    return jsonify({'error': f'Invalid target_type: {target_type}'}), 400
                
                # SLAs table has: name, metric_type, target_value, target_unit,
                # start_condition, stop_condition, effective_from, is_active
                # Extract and format log_field_mapping
                log_field_mapping = sla_data.get('log_field_mapping')
                if log_field_mapping:
                    if isinstance(log_field_mapping, dict):
                        log_field_mapping = json.dumps(log_field_mapping)
                
                # Build metadata from additional SLA fields
                metadata = {}
                if sla_data.get('measurement_period'):
                    metadata['measurement_period'] = sla_data.get('measurement_period')
                if sla_data.get('warning_threshold'):
                    metadata['warning_threshold'] = sla_data.get('warning_threshold')
                if sla_data.get('critical_threshold'):
                    metadata['critical_threshold'] = sla_data.get('critical_threshold')
                if sla_data.get('description'):
                    metadata['description'] = sla_data.get('description')
                
                metadata_json = json.dumps(metadata) if metadata else None
                
                conn.execute("""
                    INSERT INTO slas (
                        sla_id, org_id, service_id, job_id,
                        name, metric_type, target_value, target_unit,
                        start_condition, stop_condition,
                        effective_from, is_active,
                        log_field_mapping,
                        metadata,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (
                    sla_id,
                    org_id,
                    sla_service_id,
                    sla_job_id,
                    sla_data.get('sla_name', 'SLA'),           # Maps to 'name'
                    sla_data.get('sla_type', 'custom'),        # Maps to 'metric_type'
                    sla_data.get('target_value', 99.9),
                    '%',                                        # target_unit
                    'start',                                    # start_condition (required)
                    'stop',                                     # stop_condition (required)
                    datetime.now().strftime('%Y-%m-%d'),       # effective_from (required)
                    True,                                       # is_active
                    log_field_mapping,                          # log_field_mapping
                    metadata_json                               # metadata
                ))
                
                sla_ids.append(sla_id)
                logger.info(f"✓ Created SLA: {sla_id} (target: {target_type})")
            
            # Commit transaction
            conn.commit()
            
            # =================================================================
            # CREATE AUDIT LOG
            # =================================================================
            try:
                log_id = f"log-{uuid.uuid4().hex[:12]}"
                db_service.create_audit_log({
                    'log_id': log_id,
                    'org_id': org_id,
                    'user_id': user_id,
                    'action': 'complete_onboarding',
                    'resource_type': 'asset',
                    'resource_id': asset_id,
                    'ip_address': request.remote_addr,
                    'metadata': {
                        'asset_id': asset_id,
                        'services_created': len(service_ids),
                        'jobs_created': len(job_ids),
                        'slas_created': len(sla_ids)
                    }
                })
            except Exception as e:
                logger.warning(f"Failed to create audit log: {e}")
            
            # =================================================================
            # RETURN RESPONSE
            # =================================================================
            return jsonify({
                'success': True,
                'data': {
                    'asset': {
                        'asset_id': asset_id,
                        'asset_name': asset_data.get('asset_name'),
                        'created_at': datetime.now().isoformat()
                    },
                    'services': [
                        {'service_id': sid, 'service_name': s.get('service_name')}
                        for sid, s in zip(service_ids, services)
                    ],
                    'jobs': [
                        {'job_id': jid, 'job_name': j.get('job_name')}
                        for jid, j in zip(job_ids, jobs)
                    ],
                    'slas': [
                        {'sla_id': sid, 'sla_name': s.get('sla_name')}
                        for sid, s in zip(sla_ids, slas)
                    ],
                    'summary': {
                        'assets_created': 1,
                        'services_created': len(service_ids),
                        'jobs_created': len(job_ids),
                        'slas_created': len(sla_ids)
                    }
                }
            }), 201
            
    except Exception as e:
        logger.error(f"Onboarding error: {str(e)}", exc_info=True)
        return jsonify({
            'error': 'Failed to complete onboarding',
            'message': str(e)
        }), 500

@app.route('/api/v1/bulk-onboarding/complete', methods=['POST', 'OPTIONS'])
@require_auth
def complete_bulk_onboarding():
    """
    Complete bulk onboarding - import multiple assets, services, jobs, and SLAs
    """
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.json
        org_id = get_user_org()
        user_id = request.user_id
        
        # Get data from request
        assets_data = data.get('assets', [])
        services_data = data.get('services', [])
        jobs_data = data.get('jobs', [])
        slas_data = data.get('slas', [])
        
        logger.info(f"Bulk onboarding started by user {user_id}: {len(assets_data)} assets, {len(services_data)} services, {len(jobs_data)} jobs, {len(slas_data)} SLAs")
        
        if not assets_data or len(assets_data) == 0:
            return jsonify({'error': 'At least one asset is required'}), 400
        
        # Track results
        results = {
            'assets': [],
            'services': [],
            'jobs': [],
            'slas': [],
            'errors': []
        }
        
        # Map to track asset IDs
        asset_id_map = {}  # connector asset_id -> db asset_id
        service_id_map = {}  # connector service_id -> db service_id
        job_id_map = {}  # connector job_id -> db job_id
        
        with db_service.get_connection() as conn:
            import uuid
            from datetime import datetime
            
            # ================================================================
            # STEP 1: IMPORT ASSETS
            # ================================================================
            for asset in assets_data:
                try:
                    # Generate new asset ID
                    asset_id = f"ASSET-{uuid.uuid4().hex[:8].upper()}"
                    
                    # Store original connector ID for mapping
                    connector_asset_id = asset.get('asset_id')
                    
                    # Parse onboarded_date if it's a string
                    onboarded_date = asset.get('onboarded_date')
                    if onboarded_date and isinstance(onboarded_date, str):
                        # Try to parse MM/DD/YYYY format
                        try:
                            parts = onboarded_date.split('/')
                            if len(parts) == 3:
                                # Convert MM/DD/YYYY to YYYY-MM-DD
                                onboarded_date = f"{parts[2]}-{parts[0].zfill(2)}-{parts[1].zfill(2)}"
                        except:
                            onboarded_date = datetime.now().strftime('%Y-%m-%d')
                    elif not onboarded_date:
                        onboarded_date = datetime.now().strftime('%Y-%m-%d')
                    
                    # Insert asset
                    conn.execute("""
                        INSERT INTO assets (
                            asset_id, org_id, asset_name, asset_type, asset_owner,
                            description, onboarded_date, status,
                            created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """, (
                        asset_id,
                        org_id,
                        asset.get('asset_name') or 'Unknown Asset',
                        asset.get('asset_type') or 'Server',
                        asset.get('asset_owner') or 'Unassigned',
                        asset.get('description', ''),
                        onboarded_date,
                        (asset.get('status', 'active') or 'active').lower()
                    ))
                    
                    # Map connector ID to DB ID
                    if connector_asset_id:
                        asset_id_map[connector_asset_id] = asset_id
                    
                    results['assets'].append({
                        'asset_id': asset_id,
                        'asset_name': asset.get('asset_name'),
                        'status': 'imported'
                    })
                    
                    logger.info(f"✓ Imported asset: {asset_id} - {asset.get('asset_name')}")
                    
                except Exception as e:
                    logger.error(f"Error importing asset: {str(e)}")
                    results['errors'].append({
                        'type': 'asset',
                        'data': asset.get('asset_name'),
                        'error': str(e)
                    })
            
            # ================================================================
            # STEP 2: IMPORT SERVICES
            # ================================================================
            for service in services_data:
                try:
                    service_id = f"SVC-{uuid.uuid4().hex[:8].upper()}"
                    connector_service_id = service.get('service_id')
                    
                    # Map asset_id from connector to DB
                    connector_asset_id = service.get('asset_id')
                    db_asset_id = asset_id_map.get(connector_asset_id)
                    
                    if not db_asset_id:
                        raise ValueError(f"Asset ID {connector_asset_id} not found in imported assets")
                    
                    # Build metadata JSON
                    import json
                    metadata = {}
                    if service.get('service_type'):
                        metadata['service_type'] = service.get('service_type')

                    # Convert metadata dict to JSON string for storage
                    metadata_json = json.dumps(metadata) if metadata else None

                    # Build metadata JSON from service_type
                    import json
                    metadata = {}
                    if service.get('service_type'):
                        metadata['service_type'] = service.get('service_type')

                    metadata_json = json.dumps(metadata) if metadata else None

                    conn.execute("""
                        INSERT INTO services (
                            service_id, org_id, asset_id, name,
                            description, metadata, is_active,
                            created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """, (
                        service_id,
                        org_id,
                        db_asset_id,
                        service.get('service_name') or service.get('name') or 'Unknown Service',
                        service.get('description', ''),
                        metadata_json,  # ✅ ADD THIS
                        True
                    ))
                    
                    if connector_service_id:
                        service_id_map[connector_service_id] = service_id
                    
                    results['services'].append({
                        'service_id': service_id,
                        'service_name': service.get('service_name'),
                        'status': 'imported'
                    })
                    
                    logger.info(f"✓ Imported service: {service_id}")
                    
                except Exception as e:
                    logger.error(f"Error importing service: {str(e)}")
                    results['errors'].append({
                        'type': 'service',
                        'data': service.get('service_name'),
                        'error': str(e)
                    })
            
            # ================================================================
            # STEP 3: IMPORT JOBS
            # ================================================================
            for job in jobs_data:
                try:
                    job_id = f"JOB-{uuid.uuid4().hex[:8].upper()}"
                    connector_job_id = job.get('job_id')
                    
                    # Map IDs (job can belong to asset OR service)
                    db_asset_id = None
                    db_service_id = None
                    
                    connector_asset_id = job.get('asset_id')
                    connector_service_id = job.get('service_id')
                    
                    if connector_asset_id:
                        db_asset_id = asset_id_map.get(connector_asset_id)
                    if connector_service_id:
                        db_service_id = service_id_map.get(connector_service_id)
                    
                    if not db_asset_id and not db_service_id:
                        raise ValueError("Job must have either asset_id or service_id")
                    
                    conn.execute("""
                        INSERT INTO jobs (
                            job_id, org_id, asset_id, service_id,
                            job_name, job_type, schedule, description,
                            is_active, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """, (
                        job_id,
                        org_id,
                        db_asset_id,
                        db_service_id,
                        job.get('job_name') or job.get('name') or 'Unknown Job',
                        job.get('job_type', ''),
                        job.get('schedule', ''),
                        job.get('description', ''),
                        True
                    ))
                    
                    if connector_job_id:
                        job_id_map[connector_job_id] = job_id
                    
                    results['jobs'].append({
                        'job_id': job_id,
                        'job_name': job.get('job_name'),
                        'status': 'imported'
                    })
                    
                    logger.info(f"✓ Imported job: {job_id}")
                    
                except Exception as e:
                    logger.error(f"Error importing job: {str(e)}")
                    results['errors'].append({
                        'type': 'job',
                        'data': job.get('job_name'),
                        'error': str(e)
                    })
            
            # ================================================================
            # STEP 4: IMPORT SLAs
            # ================================================================
            for sla in slas_data:
                try:
                    sla_id = f"SLA-{uuid.uuid4().hex[:8].upper()}"
                    
                    # Map IDs (SLA can be for service OR job)
                    db_service_id = None
                    db_job_id = None
                    
                    connector_service_id = sla.get('service_id')
                    connector_job_id = sla.get('job_id')
                    
                    if connector_service_id:
                        db_service_id = service_id_map.get(connector_service_id)
                    if connector_job_id:
                        db_job_id = job_id_map.get(connector_job_id)
                    
                    if not db_service_id and not db_job_id:
                        raise ValueError("SLA must have either service_id or job_id")
                    
                    # Map sla_type to valid metric_type
                    # Frontend sends sla_type like "Availability", "Performance"
                    # Database expects metric_type like "uptime", "success_rate", etc.
                    sla_type_mapping = {
                        'availability': 'uptime',
                        'uptime': 'uptime',
                        'performance': 'response_time',
                        'response time': 'response_time',
                        'success rate': 'success_rate',
                        'reliability': 'success_rate',
                        'throughput': 'throughput',
                        'error rate': 'error_rate',
                        'resolution': 'resolution_time'
                    }
                    
                    raw_sla_type = sla.get('sla_type') or sla.get('metric_type', 'uptime')
                    # Normalize to lowercase for mapping
                    normalized_type = raw_sla_type.lower() if isinstance(raw_sla_type, str) else 'uptime'
                    # Map to valid metric_type, default to 'uptime'
                    metric_type = sla_type_mapping.get(normalized_type, 'uptime')
                    
                    conn.execute("""
                        INSERT INTO slas (
                            sla_id, org_id, service_id, job_id,
                            name, metric_type, target_value, target_unit,
                            start_condition, stop_condition, effective_from,
                            is_active, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """, (
                        sla_id,
                        org_id,
                        db_service_id,
                        db_job_id,
                        sla.get('sla_name') or sla.get('name') or 'Unknown SLA',
                        metric_type,  # Use mapped metric_type
                        sla.get('target_value_percentage') or sla.get('target_value', 99.9),
                        sla.get('target_unit', '%'),
                        sla.get('start_condition', ''),
                        sla.get('stop_condition', ''),
                        sla.get('effective_from', datetime.now().strftime('%Y-%m-%d')),
                        True
                    ))
                    
                    results['slas'].append({
                        'sla_id': sla_id,
                        'name': sla.get('sla_name') or sla.get('name'),
                        'status': 'imported'
                    })
                    
                    logger.info(f"✓ Imported SLA: {sla_id} - {sla.get('sla_name') or sla.get('name')}")
                    
                except Exception as e:
                    logger.error(f"Error importing SLA: {str(e)}")
                    results['errors'].append({
                        'type': 'sla',
                        'data': sla.get('sla_name') or sla.get('name'),
                        'error': str(e)
                    })
        
        # Log summary
        logger.info(f"""
        Bulk onboarding completed:
        - Assets: {len(results['assets'])} imported
        - Services: {len(results['services'])} imported
        - Jobs: {len(results['jobs'])} imported
        - SLAs: {len(results['slas'])} imported
        - Errors: {len(results['errors'])}
        """)
        
        return jsonify({
            'success': True,
            'message': f"Bulk onboarding completed: {len(results['assets'])} assets, {len(results['services'])} services, {len(results['jobs'])} jobs, {len(results['slas'])} SLAs imported",
            'data': results
        }), 200
        
    except Exception as e:
        logger.error(f"Bulk onboarding error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e), 'message': 'Failed to complete bulk onboarding'}), 500

# ===== SLA TYPE DEFINITIONS =====

@app.route('/api/v1/sla-types', methods=['GET'])
@require_auth
def get_sla_types():
    """
    Get all SLA type definitions
    
    Query params:
        entity_type: Optional filter by 'service' or 'job'
    """
    try:
        entity_type = request.args.get('entity_type')
        
        sla_types = db_service.get_sla_type_definitions(entity_type)
        
        # Parse JSON fields
        for sla_type in sla_types:
            for field in ['default_field_mapping', 'validation_rules', 'display_config']:
                if sla_type.get(field):
                    try:
                        sla_type[field] = json.loads(sla_type[field])
                    except:
                        pass
        
        return jsonify({
            'sla_types': sla_types,
            'total': len(sla_types)
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching SLA types: {e}")
        return jsonify({'error': str(e)}), 500


# ===== SLA FIELD MAPPING =====

@app.route('/api/v1/slas/<sla_id>/field-mapping', methods=['GET'])
@require_auth
def get_sla_field_mapping(sla_id):
    """Get SLA field mapping configuration"""
    try:
        sla = db_service.get_sla_with_field_mapping(sla_id)
        
        if not sla:
            return jsonify({'error': 'SLA not found'}), 404
        
        return jsonify({
            'sla_id': sla['sla_id'],
            'name': sla['name'],
            'metric_type': sla['metric_type'],
            'log_field_mapping': sla.get('log_field_mapping'),
            'evaluation_config': sla.get('evaluation_config')
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching SLA field mapping: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/slas/<sla_id>/field-mapping', methods=['PUT'])
@require_auth
def update_sla_field_mapping(sla_id):
    """
    Update SLA field mapping configuration
    
    Body:
        log_field_mapping: Dict mapping SLA fields to log fields
        evaluation_config: Optional evaluation configuration
    """
    try:
        data = request.json
        
        log_field_mapping = data.get('log_field_mapping')
        evaluation_config = data.get('evaluation_config')
        
        if not log_field_mapping:
            return jsonify({'error': 'log_field_mapping is required'}), 400
        
        db_service.update_sla_field_mapping(
            sla_id=sla_id,
            log_field_mapping=log_field_mapping,
            evaluation_config=evaluation_config
        )
        
        logger.info(f"Updated field mapping for SLA {sla_id}")
        
        return jsonify({
            'success': True,
            'message': 'Field mapping updated successfully',
            'sla_id': sla_id
        }), 200
        
    except Exception as e:
        logger.error(f"Error updating SLA field mapping: {e}")
        return jsonify({'error': str(e)}), 500


# ===== SLA COMPLIANCE DATA =====

@app.route('/api/v1/services/<service_id>/sla-compliance', methods=['GET'])
@require_auth
def get_service_sla_compliance(service_id):
    """
    Get SLA compliance records for a service
    
    Query params:
        sla_id: Optional filter by specific SLA
        start_date: Optional start date (ISO format)
        end_date: Optional end date (ISO format)
        limit: Max records to return (default 100)
    """
    try:
        sla_id = request.args.get('sla_id')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = int(request.args.get('limit', 100))
        
        compliance_records = db_service.get_service_sla_compliance(
            service_id=service_id,
            start_date=start_date,
            end_date=end_date,
            sla_id=sla_id
        )
        
        # Limit results
        compliance_records = compliance_records[:limit]
        
        # Parse JSON fields
        for record in compliance_records:
            if record.get('breach_details'):
                try:
                    record['breach_details'] = json.loads(record['breach_details'])
                except:
                    pass
        
        return jsonify({
            'compliance_records': compliance_records,
            'total': len(compliance_records)
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching service SLA compliance: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/jobs/<job_id>/sla-compliance', methods=['GET'])
@require_auth
def get_job_sla_compliance(job_id):
    """
    Get SLA compliance records for a job
    
    Query params:
        sla_id: Optional filter by specific SLA
        start_date: Optional start date (ISO format)
        end_date: Optional end date (ISO format)
        limit: Max records to return (default 100)
    """
    try:
        sla_id = request.args.get('sla_id')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = int(request.args.get('limit', 100))
        
        compliance_records = db_service.get_job_sla_compliance(
            job_id=job_id,
            start_date=start_date,
            end_date=end_date,
            sla_id=sla_id
        )
        
        # Limit results
        compliance_records = compliance_records[:limit]
        
        # Parse JSON fields
        for record in compliance_records:
            if record.get('breach_details'):
                try:
                    record['breach_details'] = json.loads(record['breach_details'])
                except:
                    pass
        
        return jsonify({
            'compliance_records': compliance_records,
            'total': len(compliance_records)
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching job SLA compliance: {e}")
        return jsonify({'error': str(e)}), 500


# ===== SLA COMPLIANCE SUMMARY =====

@app.route('/api/v1/slas/<sla_id>/compliance-summary', methods=['GET'])
@require_auth
def get_sla_compliance_summary(sla_id):
    """
    Get compliance summary for an SLA
    
    Query params:
        days: Number of days to include (default 30)
    """
    try:
        days = int(request.args.get('days', 30))
        
        summary = db_service.get_sla_compliance_summary(sla_id, days)
        
        return jsonify(summary), 200
        
    except Exception as e:
        logger.error(f"Error fetching SLA compliance summary: {e}")
        return jsonify({'error': str(e)}), 500


# ===== SLA STATUS (Using Views) =====

@app.route('/api/v1/services/<service_id>/sla-status', methods=['GET'])
@require_auth
def get_service_sla_status(service_id):
    """Get SLA status summary for a service (uses v_service_sla_status view)"""
    try:
        sla_statuses = db_service.get_sla_status_by_service(service_id)
        
        return jsonify({
            'service_id': service_id,
            'sla_statuses': sla_statuses,
            'total_slas': len(sla_statuses)
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching service SLA status: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/jobs/<job_id>/sla-status', methods=['GET'])
@require_auth
def get_job_sla_status(job_id):
    """Get SLA status summary for a job (uses v_job_sla_status view)"""
    try:
        sla_statuses = db_service.get_sla_status_by_job(job_id)
        
        return jsonify({
            'job_id': job_id,
            'sla_statuses': sla_statuses,
            'total_slas': len(sla_statuses)
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching job SLA status: {e}")
        return jsonify({'error': str(e)}), 500


# ===== RECENT BREACHES =====

@app.route('/api/v1/sla-breaches/recent', methods=['GET'])
@require_auth
def get_recent_sla_breaches():
    """
    Get recent SLA breaches across all services and jobs
    
    Query params:
        days: Number of days to look back (default 7)
        limit: Maximum number of breaches (default 50)
    """
    try:
        org_id = get_user_org()
        days = int(request.args.get('days', 7))
        limit = int(request.args.get('limit', 50))
        
        breaches = db_service.get_recent_sla_breaches(org_id, days, limit)
        
        # Parse JSON fields
        for breach in breaches:
            if breach.get('breach_details'):
                try:
                    breach['breach_details'] = json.loads(breach['breach_details'])
                except:
                    pass
        
        return jsonify({
            'breaches': breaches,
            'total': len(breaches),
            'period_days': days
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching recent SLA breaches: {e}")
        return jsonify({'error': str(e)}), 500


# ===== DASHBOARD SUMMARY =====

@app.route('/api/v1/sla-compliance/dashboard', methods=['GET'])
@require_auth
def get_sla_compliance_dashboard():
    """
    Get SLA compliance dashboard summary
    
    Returns:
        Overall compliance statistics for the organization
    """
    try:
        org_id = get_user_org()
        days = int(request.args.get('days', 30))
        
        # Get all SLAs for org
        with db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT sla_id, name, metric_type
                FROM slas
                WHERE org_id = ? AND is_active = 1
            """, (org_id,))
            slas = [dict(row) for row in cursor.fetchall()]
        
        # Get compliance summary for each SLA
        sla_summaries = []
        total_checks = 0
        total_passed = 0
        total_failed = 0
        
        for sla in slas:
            summary = db_service.get_sla_compliance_summary(sla['sla_id'], days)
            summary['sla_name'] = sla['name']
            summary['sla_type'] = sla['metric_type']
            sla_summaries.append(summary)
            
            total_checks += summary['total']
            total_passed += summary['passed']
            total_failed += summary['failed']
        
        overall_compliance = (total_passed / total_checks * 100) if total_checks > 0 else 0
        
        # Get recent breaches
        recent_breaches = db_service.get_recent_sla_breaches(org_id, 7, 10)
        
        return jsonify({
            'overall_compliance_percentage': round(overall_compliance, 2),
            'total_checks': total_checks,
            'total_passed': total_passed,
            'total_failed': total_failed,
            'total_slas': len(slas),
            'sla_summaries': sla_summaries,
            'recent_breaches': recent_breaches[:10],
            'period_days': days
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching SLA compliance dashboard: {e}")
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    # Start health monitoring service
    logger.info("Starting health monitoring service...")
    health_monitor.start()
    
    # Start job monitoring service
    logger.info("Starting job monitoring service...")
    job_monitor.start()
    
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    finally:
        # Stop services on shutdown
        logger.info("Stopping services...")
        health_monitor.stop()
        job_monitor.stop()
