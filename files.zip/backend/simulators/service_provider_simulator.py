"""
Service Metadata Provider Simulator
Simulates service management API for testing
Port: 5004
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config/services.json')

def load_services():
    """Load dummy services from config file"""
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'service_provider_simulator',
        'version': '1.0'
    })

@app.route('/api/services', methods=['GET'])
def get_services():
    """
    Get all services with optional filters
    
    Query Parameters:
    - asset_id: Filter by asset ID
    - service_type: Filter by service type
    - status: Filter by status
    """
    services = load_services()
    
    # Apply filters
    asset_id = request.args.get('asset_id')
    service_type = request.args.get('service_type')
    status = request.args.get('status')
    
    if asset_id:
        services = [s for s in services if s.get('asset_id') == asset_id]
    if service_type:
        services = [s for s in services if s.get('service_type', '').lower() == service_type.lower()]
    if status:
        services = [s for s in services if s.get('status') == status]
    
    return jsonify({
        'services': services,
        'total': len(services),
        'timestamp': '2025-12-26T10:00:00Z'
    })

@app.route('/api/services/<service_id>', methods=['GET'])
def get_service(service_id):
    """Get specific service by ID"""
    services = load_services()
    service = next((s for s in services if s['service_id'] == service_id), None)
    
    if service:
        return jsonify(service)
    return jsonify({'error': 'Service not found'}), 404

if __name__ == '__main__':
    print("=" * 60)
    print("Service Provider Simulator Starting...")
    print("=" * 60)
    print(f"Endpoint: http://localhost:5004")
    print(f"Health Check: http://localhost:5004/api/health")
    print(f"Get Services: http://localhost:5004/api/services")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5004, debug=True)
