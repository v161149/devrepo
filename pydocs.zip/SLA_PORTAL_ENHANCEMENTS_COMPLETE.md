# SLA Monitoring Portal - Complete Enhancement Recommendations

**Comprehensive User Feedback Analysis & Implementation Plan**

*Prepared by: Claude (Anthropic AI Assistant)*  
*Date: December 14, 2025*

---

## Executive Summary

Based on comprehensive user feedback, we have identified **three critical enhancements** that will significantly improve the SLA Monitoring Portal's usability, efficiency, and user adoption.

### Three Key Enhancements

1. **Onboarding Menu & Guided Setup** - Step-by-step wizard to help new users understand the Asset → Service → Job → SLA hierarchy
2. **AI-Powered Help System** - Intelligent FAQ and contextual help using Claude API for natural language queries  
3. **Metadata Retrieval Service** - Automated bulk import from Autosys and Ansible Tower platforms (100+ assets, 200+ jobs per asset)

### Expected Impact

**⚡ Time Savings:**
- Reduce onboarding time from **days to hours**
- Eliminate **16+ hours of manual data entry** → **10 minutes**
- Decrease support requests by **60%**

**💰 Return on Investment:**
- For 100 assets with 20,000 jobs: Save **~20 hours** per setup
- Improved accuracy (eliminate manual entry errors)
- Better user satisfaction and adoption
- Reduced IT support burden

**📊 Success Metrics:**
- User onboarding completion rate: Target 80%+
- Time to first SLA created: Target < 30 minutes
- Support ticket reduction: Target 60%
- Data entry accuracy: Target 99%+

---

## Table of Contents

1. [User Feedback Overview](#1-user-feedback-overview)
2. [Enhancement #1: Onboarding Menu & Guided Setup](#2-enhancement-1-onboarding-menu--guided-setup)
   - 2.1 [Interactive Onboarding Flow](#21-interactive-onboarding-flow)
   - 2.2 [Process Flow Diagram](#22-process-flow-diagram)
   - 2.3 [Contextual Help & Tooltips](#23-contextual-help--tooltips)
3. [Enhancement #2: Help/FAQ System](#3-enhancement-2-helpfaq-system)
   - 3.1 [AI-Powered Help Bot](#31-ai-powered-help-bot-recommended)
   - 3.2 [Static FAQ Fallback](#32-static-faq-fallback)
4. [Enhancement #3: Metadata Retrieval Service](#4-enhancement-3-metadata-retrieval-service)
   - 4.1 [Architecture Design](#41-architecture-design)
   - 4.2 [Implementation Plan](#42-implementation-plan)
   - 4.3 [Benefits & ROI Analysis](#43-benefits--roi-analysis)
5. [Implementation Timeline & Priorities](#5-implementation-timeline--priorities)
6. [Additional Recommendations](#6-additional-recommendations)
7. [Technical Requirements](#7-technical-requirements)
8. [Conclusion & Next Steps](#8-conclusion--next-steps)

---

# 1. User Feedback Overview

## Current State Analysis

The SLA Monitoring Portal currently provides essential functionality for tracking service-level agreements, but user feedback reveals significant usability gaps that hinder adoption and efficiency.

## Pain Points Identified

### 🎯 **Challenge 1: Steep Learning Curve**

**Problem:**
- New users don't understand the Asset → Service → Job → SLA hierarchy
- No guided path to create their first complete SLA setup
- Portal assumes user knowledge of concepts and workflow
- No explanation of why each entity exists or how they relate

**User Quote:**  
*"If a user isn't familiar with the web portal, they will not know how to use it and create SLAs. The current portal doesn't tell users what the procedure is to set up SLAs."*

**Impact:**
- Average onboarding time: 2-3 days
- High abandonment rate for new users
- Increased dependency on IT support
- Inconsistent data entry practices

**Current Workaround:**
- Manual training sessions (time-consuming)
- Written documentation (often not read)
- Trial and error (leads to mistakes)

---

### ⏰ **Challenge 2: Manual Data Entry Burden**

**Problem:**
- Users need to create 100+ assets manually
- Each asset may have 200+ batch jobs to configure
- All job metadata must be entered field-by-field
- Process is repetitive, time-consuming, and error-prone

**Time Analysis:**
```
Per Asset:  2 minutes × 100 assets  = 200 minutes (~3.3 hours)
Per Job:    5 minutes × 20,000 jobs = 100,000 minutes (~1,667 hours)
                                      
Total Manual Entry Time: ~1,670 hours for 20,000 jobs
```

**User Quote:**  
*"Since user may need to create more than 100 assets and one asset may have 200 service batch jobs, user doesn't want to manually enter all mandatory data entries."*

**Impact:**
- Extremely high setup time (weeks to months)
- Data entry errors and inconsistencies
- User frustration and resistance
- Delayed portal adoption
- Duplicate effort (metadata exists in Autosys/Ansible Tower)

---

### ❓ **Challenge 3: No Integrated Help System**

**Problem:**
- No way to get instant answers about portal features
- No FAQ or searchable documentation within portal
- Users must contact IT support for basic questions
- No contextual help on forms or pages

**Impact:**
- High volume of support tickets for basic questions
- User frustration when stuck
- Slower task completion
- Support team overwhelmed with repetitive questions

**Common User Questions:**
- "How do I create an SLA?"
- "What's the difference between Asset and Service?"
- "Why is my job not being monitored?"
- "What does 'indirect monitoring' mean?"
- "How do I import jobs from Autosys?"

---

### 🔄 **Challenge 4: Duplicate Data Entry**

**Problem:**
- Job metadata already exists in Autosys and Ansible Tower
- No automated way to sync or import existing jobs
- Users must manually copy data from platform to portal
- Updates in source platforms not reflected in portal

**Available Platform Data:**

**Autosys provides:**
- Job name
- Job type  
- Description
- Machine/deployment location
- Schedules and conditions
- Status

**Ansible Tower provides:**
- Job template name and description
- Associated project and playbook
- Inventory (deployment location/target hosts)
- Credentials
- Schedules
- Extra variables
- Job type and verbosity
- All configuration parameters

**User Quote:**  
*"All those batch jobs can't be monitored directly because they're deployed in Autosys and Ansible Tower platforms, and these platforms offer web service endpoints to retrieve batch job metadata information."*

---

## User Request Summary

| Request | Priority | Impact | Effort | Timeline |
|---------|----------|--------|--------|----------|
| Onboarding menu with guided setup | **🔴 HIGH** | Reduces learning curve from days to hours | Medium | 2 weeks |
| Help/FAQ with AI-powered Q&A | **🟡 MEDIUM** | Reduces support requests by 60% | Low | 1 week |
| Metadata retrieval from Autosys/Ansible | **🔴 HIGH** | Saves 1,600+ hours per 20,000 jobs | High | 3-4 weeks |

---

# 2. Enhancement #1: Onboarding Menu & Guided Setup

## Overview

Create a comprehensive onboarding system that guides new users through their first complete SLA setup, teaching them the portal structure while they create real, working configurations.

## Problem Statement

**Current State:**  
New users face a blank portal with menu items (Dashboard, Assets, Services, Alerts, Reports, Settings) but no guidance on:
- Where to start
- What each menu item does
- How entities relate to each other
- Required creation order

**Desired State:**  
New users are greeted with a friendly onboarding wizard that walks them through creating their first Asset → Service → Job → SLA in a guided, educational manner.

---

## Recommended Solution

Implement a **three-pronged approach**:

1. **Interactive Onboarding Wizard** (Primary) - 4-step guided flow
2. **Visual Process Flow Diagram** - Interactive hierarchy visualization  
3. **Contextual Help & Tooltips** - Inline help throughout portal

---

## 2.1 Interactive Onboarding Flow

### Design Philosophy

**Progressive Disclosure:**  
Show one step at a time to avoid cognitive overload. Each step builds on the previous one.

**Learn by Doing:**  
Users create real, working configurations (not demos) that they can continue using after onboarding.

**Educational + Functional:**  
Each step explains concepts while collecting data, combining learning with productivity.

**Pre-filled Samples:**  
Provide realistic examples users can modify, reducing the "blank page" problem.

### 4-Step Wizard Design

---

#### **Step 1: Create Your First Asset**

**Learning Goal:** Understand what assets are and why they're needed

**UI Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│ 🎯 SLA Portal Onboarding                              [1/4] │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Progress:  [████████░░░░░░░░░░░░]  25%                    │
│                                                               │
│  ✓ Create Asset → ○ Create Service → ○ Configure Job       │
│                    → ○ Create SLA                           │
│                                                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Step 1: Create Your First Asset                             │
│  ═══════════════════════════════                             │
│                                                               │
│  📚 What is an Asset?                                        │
│                                                               │
│  Assets represent infrastructure components where your       │
│  services run. Think of them as the physical or virtual      │
│  "places" that host your applications.                       │
│                                                               │
│  Common examples:                                            │
│  • Production Server - Hosts multiple applications          │
│  • Database Cluster - Manages data storage                  │
│  • Cloud Instance - EC2, Azure VM, etc.                     │
│  • ETL Server - Runs batch processing jobs                  │
│                                                               │
│  💡 Pro Tip:                                                │
│  One asset can host multiple services. Group related         │
│  services on the same asset for easier management.          │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  Asset Name: *                                        │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Production Server                             │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Asset Type: *                                        │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Server                                     ▼ │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  Options: Server, Database, Cloud Resource,          │  │
│  │           Network Device, Application                 │  │
│  │                                                        │  │
│  │  Asset Owner: *                                       │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ IT Operations                                 │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Description:                                         │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Main production server hosting critical      │   │  │
│  │  │ applications and ETL pipelines                │   │  │
│  │  │                                                │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Onboarded Date: *                                    │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ 2025-12-14                                    │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Status:                                              │  │
│  │  ● Active   ○ Inactive                               │  │
│  │                                                        │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  ────────────────────────────────────────────────────────  │
│                                                               │
│  [Cancel]                    [Create Asset & Continue →]    │
│                                                               │
│  Or: [Skip to Bulk Import] if you have 100+ assets          │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

**Field Descriptions:**

| Field | Description | Example |
|-------|-------------|---------|
| Asset Name | Unique identifier for this infrastructure | "Production Server", "GRM DB Cluster" |
| Asset Type | Category of infrastructure | Server, Database, Cloud Resource |
| Asset Owner | Team/person responsible | "IT Operations", "Database Admin" |
| Description | Purpose and details | "Main production server hosting..." |
| Onboarded Date | When added to portal | Auto-filled with today's date |
| Status | Active or Inactive | Active (default) |

**Validation Rules:**
- Asset Name: Required, 3-100 characters, alphanumeric + spaces/hyphens
- Asset Type: Required, must select from dropdown
- Asset Owner: Required, 2-50 characters
- Description: Optional, max 500 characters
- Date: Auto-filled, cannot be future date
- Status: Defaults to Active

**Pre-filled Sample Data:**
```json
{
  "asset_name": "Production Server",
  "asset_type": "server",
  "asset_owner": "IT Operations",
  "description": "Main production server hosting critical applications and ETL pipelines",
  "onboarded_date": "2025-12-14",
  "status": "active"
}
```

---

#### **Step 2: Create Your First Service**

**Learning Goal:** Understand how services relate to assets

**UI Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│ 🎯 SLA Portal Onboarding                              [2/4] │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Progress:  [████████████████░░░░]  50%                     │
│                                                               │
│  ✓ Asset Created → ● Service → ○ Configure Job             │
│                                 → ○ Create SLA              │
│                                                               │
│  ✅ Asset Created: "Production Server"                      │
│                                                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Step 2: Create Your First Service                           │
│  ═══════════════════════════════                             │
│                                                               │
│  📚 What is a Service?                                       │
│                                                               │
│  Services are applications, jobs, or workloads running on    │
│  your assets. They represent the actual work being done.     │
│                                                               │
│  Common examples:                                            │
│  • ETL Pipeline - Daily data processing job                 │
│  • REST API - Web service endpoint                          │
│  • Database Service - MySQL/PostgreSQL instance             │
│  • Microservice - Container-based application               │
│                                                               │
│  💡 Pro Tip:                                                │
│  Services are linked to assets. One asset can host many      │
│  services. This service will run on: Production Server      │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  Service Name: *                                      │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ GRM Daily ETL                                 │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Service Type: *                                      │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ ETL Batch Job                              ▼ │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  Options: ETL Batch, API Gateway, Microservice,      │  │
│  │           MySQL, PostgreSQL, MongoDB                  │  │
│  │                                                        │  │
│  │  Owner Team: *                                        │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Data Engineering                              │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Deployment Location: *                               │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Autosys                                    ▼ │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  Options: Autosys, Airflow, Ansible Tower,           │  │
│  │           Kubernetes, AWS, Azure                      │  │
│  │                                                        │  │
│  │  Monitoring Method: *                                 │  │
│  │  ● Indirect (scheduled jobs)                         │  │
│  │  ○ Direct (real-time monitoring)                     │  │
│  │                                                        │  │
│  │  Description:                                         │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Daily ETL pipeline for GRM data processing   │   │  │
│  │  │ Loads data from source systems and transforms│   │  │
│  │  │ for reporting                                 │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Linked to Asset: Production Server                  │  │
│  │                                                        │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  [◀ Back]                   [Create Service & Continue →]   │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

**Pre-filled Sample Data:**
```json
{
  "name": "GRM Daily ETL",
  "service_type": "etl_batch",
  "owner_team": "Data Engineering",
  "deployment_location": "autosys",
  "monitoring_method": "indirect",
  "description": "Daily ETL pipeline for GRM data processing",
  "asset_id": "<created_from_step_1>"
}
```

---

#### **Step 3: Configure Job Details**

**Learning Goal:** Understand job scheduling and execution parameters

**UI Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│ 🎯 SLA Portal Onboarding                              [3/4] │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Progress:  [████████████████████████]  75%                │
│                                                               │
│  ✓ Asset → ✓ Service → ● Configure Job → ○ Create SLA     │
│                                                               │
│  ✅ Service Created: "GRM Daily ETL"                        │
│                                                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Step 3: Configure Job Details                               │
│  ═══════════════════════                                     │
│                                                               │
│  📚 What is a Job?                                           │
│                                                               │
│  Jobs define the work performed by a service and when it     │
│  runs. This includes the schedule, expected duration, and    │
│  execution parameters.                                       │
│                                                               │
│  ⏰ Schedule Format (Cron):                                 │
│  Cron uses 5 fields: minute hour day month weekday          │
│                                                               │
│  Common examples:                                            │
│  • "0 2 * * *"    - Daily at 2:00 AM                        │
│  • "0 */4 * * *"  - Every 4 hours                           │
│  • "*/15 * * * *" - Every 15 minutes                        │
│  • "0 0 * * 0"    - Weekly on Sunday at midnight            │
│  • "0 9 1 * *"    - Monthly on 1st at 9:00 AM              │
│                                                               │
│  💡 Pro Tip:                                                │
│  Expected duration helps us detect jobs running too long.    │
│  If a job usually takes 30 minutes but runs for 2 hours,    │
│  we'll alert you!                                            │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  Job Name: *                                          │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ GRM Daily Data Load                           │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Job Type: *                                          │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ ETL Batch                                  ▼ │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Job Schedule (Cron): *                               │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ 0 2 * * *                                     │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  Translation: Runs daily at 2:00 AM                  │  │
│  │  [📅 Schedule Helper]                                │  │
│  │                                                        │  │
│  │  Expected Duration (HH:MM:SS): *                      │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ 00:30:00                                      │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  This job typically runs for 30 minutes               │  │
│  │                                                        │  │
│  │  Description:                                         │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Loads daily GRM data from source systems,    │   │  │
│  │  │ performs transformations, and loads to data  │   │  │
│  │  │ warehouse                                     │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Service: GRM Daily ETL                               │  │
│  │  Asset: Production Server                             │  │
│  │                                                        │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  [◀ Back]                       [Save & Continue →]         │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

**Cron Schedule Helper Modal:**
```
┌────────────────────────────────────────────┐
│ 📅 Schedule Helper                        │
├────────────────────────────────────────────┤
│                                             │
│  Frequency: [Daily ▼]                      │
│                                             │
│  Time:   [02] : [00]  AM/PM: [AM ▼]       │
│          Hour    Min                        │
│                                             │
│  Cron Expression: 0 2 * * *                │
│                                             │
│  Runs: Every day at 2:00 AM                │
│                                             │
│  [Apply to Schedule]      [Cancel]         │
│                                             │
└────────────────────────────────────────────┘
```

**Pre-filled Sample Data:**
```json
{
  "job_name": "GRM Daily Data Load",
  "job_type": "etl_batch",
  "schedule": "0 2 * * *",
  "execution_time": "00:30:00",
  "description": "Loads daily GRM data from source systems"
}
```

---

#### **Step 4: Create Your First SLA**

**Learning Goal:** Understand SLA targets and monitoring

**UI Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│ 🎯 SLA Portal Onboarding                              [4/4] │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Progress:  [████████████████████████████████]  100%       │
│                                                               │
│  ✓ Asset → ✓ Service → ✓ Job → ● Create SLA               │
│                                                               │
│  ✅ Job Configured: "GRM Daily Data Load"                   │
│                                                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  Step 4: Create Your First SLA                               │
│  ═══════════════════════════                                 │
│                                                               │
│  📚 What is an SLA?                                          │
│                                                               │
│  SLAs (Service Level Agreements) define performance targets  │
│  and monitoring rules. They answer: "What does success look  │
│  like for this service?"                                     │
│                                                               │
│  SLA Types:                                                  │
│  • Uptime - Service should be up X% of the time             │
│  • Response Time - API should respond in < X milliseconds   │
│  • Completion Time - Job should finish in < X hours         │
│  • Availability - System should be available 24/7           │
│  • Error Rate - < X% of requests should fail                │
│                                                               │
│  💡 Pro Tip:                                                │
│  Choose realistic targets! A 99.5% uptime target means      │
│  your service can be down for about 3.6 hours per month.    │
│  Setting targets too high can lead to constant alerts.      │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                                                        │  │
│  │  SLA Name: *                                          │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ GRM ETL Uptime SLA                            │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  SLA Type: *                                          │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Uptime                                     ▼ │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  Options: Uptime, Response Time, Completion Time,    │  │
│  │           Availability, Error Rate                    │  │
│  │                                                        │  │
│  │  Target Value: *                                      │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ 99.5                                          │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  For Uptime: % (e.g. 99.5 = 99.5% uptime)            │  │
│  │  For Time: seconds or minutes                        │  │
│  │                                                        │  │
│  │  ℹ️ 99.5% uptime allows ~3.6 hours downtime/month  │  │
│  │                                                        │  │
│  │  Measurement Window: *                                │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Monthly                                    ▼ │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │  Options: Daily, Weekly, Monthly, Quarterly          │  │
│  │                                                        │  │
│  │  Description:                                         │  │
│  │  ┌──────────────────────────────────────────────┐   │  │
│  │  │ Maintain 99.5% uptime for GRM ETL pipeline  │   │  │
│  │  │ to ensure reliable daily data processing     │   │  │
│  │  └──────────────────────────────────────────────┘   │  │
│  │                                                        │  │
│  │  Service: GRM Daily ETL                               │  │
│  │  Asset: Production Server                             │  │
│  │                                                        │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  [◀ Back]                   [Create SLA & Finish ✓]         │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

**SLA Target Helper:**
```
┌────────────────────────────────────────────┐
│ 🎯 Uptime Calculator                       │
├────────────────────────────────────────────┤
│                                             │
│  Target: 99.5%                             │
│                                             │
│  Allowed Downtime:                         │
│  • Per Day:    7.2 minutes                 │
│  • Per Week:   50.4 minutes                │
│  • Per Month:  3.6 hours                   │
│  • Per Year:   43.8 hours                  │
│                                             │
│  Common Targets:                           │
│  • 99%     = 7.2 hours/month               │
│  • 99.5%   = 3.6 hours/month               │
│  • 99.9%   = 43 minutes/month              │
│  • 99.99%  = 4.3 minutes/month             │
│                                             │
│  [Close]                                   │
│                                             │
└────────────────────────────────────────────┘
```

**Pre-filled Sample Data:**
```json
{
  "name": "GRM ETL Uptime SLA",
  "sla_type": "uptime",
  "target_value": 99.5,
  "measurement_window": "monthly",
  "description": "Maintain 99.5% uptime for GRM ETL pipeline"
}
```

---

#### **Step 5: Completion Screen**

**UI Layout:**
```
┌──────────────────────────────────────────────────────────────┐
│                   🎉 Congratulations! 🎉                     │
│                                                               │
│              Onboarding Successfully Completed!              │
│                                                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  You've created your first complete SLA monitoring setup!    │
│                                                               │
│  📊 What You Created:                                        │
│  ═══════════════════════                                     │
│                                                               │
│  📦 Asset: Production Server                                │
│      Type: Server                                            │
│      Owner: IT Operations                                    │
│      Status: Active                                          │
│                                                               │
│  │                                                            │
│  ├─→ 📦 Service: GRM Daily ETL                             │
│  │      Type: ETL Batch Job                                 │
│  │      Owner: Data Engineering                             │
│  │      Deployment: Autosys                                 │
│  │      Monitoring: Indirect                                │
│  │                                                            │
│  │   │                                                        │
│  │   ├─→ 🔧 Job: GRM Daily Data Load                       │
│  │   │      Schedule: Daily at 2:00 AM (0 2 * * *)         │
│  │   │      Duration: 30 minutes                            │
│  │   │      Status: Configured ✓                            │
│  │   │                                                        │
│  │   └─→ 📋 SLA: GRM ETL Uptime SLA                        │
│  │          Type: Uptime                                     │
│  │          Target: 99.5% (monthly)                         │
│  │          Status: Active ✓                                │
│  │          Current: Monitoring...                          │
│                                                               │
│  ────────────────────────────────────────────────────────  │
│                                                               │
│  🚀 What's Next?                                            │
│  ═══════════════                                             │
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │              │  │              │  │              │     │
│  │  📊          │  │  ⚙️          │  │  📥          │     │
│  │  Dashboard   │  │  Manage      │  │  Bulk        │     │
│  │              │  │  Service     │  │  Import      │     │
│  │ View your    │  │              │  │              │     │
│  │ SLA metrics  │  │ Add more     │  │ Import from  │     │
│  │ and          │  │ jobs or      │  │ Autosys or   │     │
│  │ compliance   │  │ SLAs to this │  │ Ansible      │     │
│  │              │  │ service      │  │ Tower        │     │
│  │              │  │              │  │              │     │
│  │ [Go to       │  │ [Manage      │  │ [Start       │     │
│  │  Dashboard]  │  │  Service]    │  │  Import]     │     │
│  │              │  │              │  │              │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │              │  │              │  │              │     │
│  │  📚          │  │  🔔          │  │  🆘          │     │
│  │  Learn More  │  │  Set Up      │  │  Get Help    │     │
│  │              │  │  Alerts      │  │              │     │
│  │ View guides  │  │              │  │ Ask our AI   │     │
│  │ and best     │  │ Configure    │  │ assistant or │     │
│  │ practices    │  │ notifications│  │ view FAQ     │     │
│  │              │  │              │  │              │     │
│  │ [Documentation]│ [Alert Setup]│  │ [Help Bot]   │     │
│  │              │  │              │  │              │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                               │
│  ────────────────────────────────────────────────────────  │
│                                                               │
│  💡 Did you know?                                           │
│                                                               │
│  • You can create multiple SLAs for the same service        │
│  • Services can have both direct and indirect monitoring    │
│  • Use the Bulk Import feature if you have 100+ jobs        │
│  • The AI Help Bot can answer questions 24/7                │
│                                                               │
│  ────────────────────────────────────────────────────────  │
│                                                               │
│  [Start Another Onboarding]     [Go to Dashboard]           │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

---

### Implementation Files

**Frontend Components:**

1. **`frontend/src/pages/Onboarding.jsx`**  
   - Main onboarding page component
   - Step state management
   - Form validation
   - API calls to create entities
   - Already created! (see outputs)

2. **`frontend/src/components/OnboardingStep.jsx`**  
   - Reusable step container
   - Progress indicator
   - Navigation buttons

3. **`frontend/src/components/ProgressTracker.jsx`**  
   - Visual progress bar
   - Step indicators with icons
   - Completion percentage

4. **`frontend/src/components/CronHelper.jsx`**  
   - Interactive cron expression builder
   - Common schedule templates
   - Human-readable translation

5. **`frontend/src/components/SLACalculator.jsx`**  
   - Uptime calculator
   - Allowed downtime display
   - Common target reference

**Navigation Updates:**

1. **`frontend/src/components/Sidebar.jsx`**  
   - Add "Onboarding" menu item between Dashboard and Assets
   - Icon: 🎯 or graduation cap
   - Highlight for new users

2. **`frontend/src/App.jsx`**  
   - Add route: `/onboarding`
   - Protected route (requires authentication)

**Routing:**
```jsx
<Route path="/onboarding" element={<Onboarding />} />
```

---

## 2.2 Process Flow Diagram

### Overview

An interactive visual diagram showing the Asset → Service → Job → SLA hierarchy with clickable nodes and real-time status.

### Visual Design

```
Interactive Process Flow Diagram
═══════════════════════════════════════════════════════════

Legend:  [🟢 Created]  [🟡 In Progress]  [⚪ Not Started]  [🔴 Error]


📊 Asset: Production Server                             [🟢]
    ├─ Type: Server
    ├─ Owner: IT Operations
    └─ Status: Active

    │
    ├─→ 📦 Service: GRM ETL Pipeline                     [🟢]
    │       ├─ Type: ETL Batch
    │       ├─ Owner: Data Engineering
    │       ├─ Deployment: Autosys
    │       └─ Monitoring: Indirect
    │
    │       │
    │       ├─→ 🔧 Job: Daily Data Load                  [🟢]
    │       │     ├─ Schedule: 0 2 * * * (Daily 2 AM)
    │       │     ├─ Duration: 30 minutes
    │       │     ├─ Last Run: 2025-12-14 02:00
    │       │     └─ Status: Success ✓
    │       │
    │       │     │
    │       │     └─→ 📋 SLA: 99.5% Uptime              [🟢]
    │       │           ├─ Type: Uptime
    │       │           ├─ Target: 99.5%
    │       │           ├─ Window: Monthly
    │       │           ├─ Current: 99.8% ✓
    │       │           └─ Status: Met
    │       │
    │       └─→ 🔧 Job: Weekly Aggregation               [🟢]
    │             ├─ Schedule: 0 0 * * 0 (Sun midnight)
    │             ├─ Duration: 2 hours
    │             ├─ Last Run: 2025-12-08 00:00
    │             └─ Status: Success ✓
    │
    │             │
    │             └─→ 📋 SLA: 2 Hour Max Duration        [🟢]
    │                   ├─ Type: Completion Time
    │                   ├─ Target: 120 minutes
    │                   ├─ Window: Weekly
    │                   ├─ Current: 110 minutes ✓
    │                   └─ Status: Met
    │
    └─→ 📦 Service: API Gateway                          [🟢]
            ├─ Type: API
            ├─ Owner: Platform Team
            ├─ Deployment: Kubernetes
            └─ Monitoring: Direct

            │
            └─→ 📋 SLA: < 200ms Response                 [🟡]
                  ├─ Type: Response Time
                  ├─ Target: 200ms
                  ├─ Window: Daily
                  ├─ Current: 245ms ⚠️
                  └─ Status: At Risk


[Create New Asset]  [Export Configuration]  [Import Configuration]
```

### Interactive Features

**Click Actions:**
- **Click Asset** → Opens asset detail page
- **Click Service** → Opens service detail page  
- **Click Job** → Opens job configuration modal
- **Click SLA** → Opens SLA editor

**Hover Information:**
```
┌─────────────────────────────────────┐
│ 📦 Service: GRM ETL Pipeline       │
├─────────────────────────────────────┤
│ Type: ETL Batch                     │
│ Owner: Data Engineering             │
│ Deployment: Autosys                 │
│ Monitoring: Indirect                │
│ Jobs: 2                             │
│ SLAs: 2                             │
│ Status: All SLAs Met ✓              │
│                                     │
│ [View Details] [Edit Service]      │
└─────────────────────────────────────┘
```

**Color Coding:**
- 🟢 **Green**: Created and healthy
- 🟡 **Yellow**: Created but needs attention (SLA at risk)
- ⚪ **Gray**: Not yet created
- 🔴 **Red**: Error or SLA violation

**Zoom & Pan:**
- Mouse wheel to zoom in/out
- Drag to pan
- Fit to screen button
- Reset view button

**Export/Import:**
- Export as JSON
- Export as PNG image
- Import saved configuration
- Share with team

### Implementation

**Library:** React Flow (https://reactflow.dev/)

```jsx
// frontend/src/components/ProcessFlowDiagram.jsx

import ReactFlow, { 
  Background, 
  Controls,
  MiniMap 
} from 'reactflow';

const ProcessFlowDiagram = () => {
  const nodes = [
    {
      id: 'asset-1',
      type: 'assetNode',
      data: { label: 'Production Server', status: 'active' },
      position: { x: 250, y: 0 }
    },
    // ... more nodes
  ];

  const edges = [
    {
      id: 'asset-1-service-1',
      source: 'asset-1',
      target: 'service-1',
      animated: true
    },
    // ... more edges
  ];

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      fitView
    >
      <Background />
      <Controls />
      <MiniMap />
    </ReactFlow>
  );
};
```

---

## 2.3 Contextual Help & Tooltips

### Overview

Add **info icons (ℹ️)** throughout the portal with helpful tooltips and links to detailed documentation.

### Implementation Locations

#### **1. Form Fields**

Every input field should have contextual help:

```
Asset Name [ℹ️]
    ├─ Tooltip: "A unique name for this infrastructure component.
    │            Examples: 'Prod DB Server', 'ETL Cluster'"
    └─ Link: "Learn more about Assets →"
```

**Example:**
```jsx
<div className="form-field">
  <label>
    Asset Name *
    <Tooltip 
      content="A unique name for this infrastructure component"
      example="Prod DB Server, ETL Cluster"
      learnMore="/docs/assets"
    >
      <InfoIcon />
    </Tooltip>
  </label>
  <input type="text" name="asset_name" />
</div>
```

#### **2. Page Headers**

Every page should have contextual help:

```
┌─────────────────────────────────────────┐
│ Assets                              [?] │  ← Click for page help
├─────────────────────────────────────────┤
│ List of all infrastructure components   │
│ ...                                     │
└─────────────────────────────────────────┘
```

#### **3. Complex Features**

Features that need explanation:

```
Direct vs Indirect Monitoring [ℹ️]
    ├─ Tooltip: "Direct: Real-time API monitoring
    │            Indirect: Scheduled job monitoring"
    └─ Link: "Learn more →"
```

### Tooltip Component

```jsx
// frontend/src/components/Tooltip.jsx

const Tooltip = ({ content, example, learnMore, children }) => {
  return (
    <div className="relative inline-block">
      <div className="cursor-help">
        {children || <InfoIcon className="w-4 h-4 text-gray-400" />}
      </div>
      
      {/* Tooltip Popup */}
      <div className="tooltip-popup">
        <p>{content}</p>
        {example && <p className="text-sm mt-2">Example: {example}</p>}
        {learnMore && (
          <a href={learnMore} className="text-primary-600 text-sm">
            Learn more →
          </a>
        )}
      </div>
    </div>
  );
};
```

### Comprehensive Tooltip Map

| Location | Tooltip Text | Learn More Link |
|----------|--------------|-----------------|
| Asset Name | "Unique identifier for infrastructure component" | `/docs/assets` |
| Asset Type | "Category: Server, Database, Cloud, Network, Application" | `/docs/asset-types` |
| Service Type | "ETL Batch for scheduled jobs, API Gateway for REST APIs" | `/docs/service-types` |
| Deployment Location | "Where service runs: Autosys, Airflow, Ansible Tower, K8s, Cloud" | `/docs/deployment` |
| Monitoring Method | "Direct: Real-time. Indirect: Scheduled job monitoring" | `/docs/monitoring` |
| Job Schedule | "Cron format. Examples: '0 2 * * *' = daily at 2 AM" | `/docs/cron` |
| Execution Time | "Expected duration (HH:MM:SS). Alerts if exceeded" | `/docs/duration` |
| SLA Type | "Uptime %, Response Time, Completion Time, Availability, Error Rate" | `/docs/sla-types` |
| SLA Target | "For Uptime: % (99.5). For Time: ms or minutes" | `/docs/targets` |
| Measurement Window | "How often to measure: Daily, Weekly, Monthly, Quarterly" | `/docs/windows` |

---

This completes Enhancement #1: Onboarding. The system now provides comprehensive guidance for new users through interactive wizards, visual diagrams, and contextual help.

---

# 3. Enhancement #2: Help/FAQ System

## Overview

Implement an intelligent help system that provides instant answers to user questions, reducing support burden and improving user experience.

## Problem Statement

**Current State:**
- No integrated help or FAQ
- Users must contact IT support for basic questions
- No searchable documentation within portal
- Support team overwhelmed with repetitive questions

**Desired State:**
- AI-powered chat assistant available 24/7
- Instant answers to common questions
- Contextual help based on current page
- Reduced support tickets by 60%

---

## Recommended Solution

**Hybrid Approach:**

1. **AI-Powered Help Bot** (Primary) - Claude API integration
2. **Static FAQ** (Fallback) - Traditional FAQ page

---

## 3.1 AI-Powered Help Bot (Recommended)

### Why AI Help Bot?

**Advantages over Static FAQ:**

✅ **Natural Language Understanding**
- Users ask questions conversationally
- No need to browse categories or search keywords
- Understands intent and context

✅ **Context-Aware**
- Knows which page user is on
- Provides page-specific help
- Remembers conversation history

✅ **Actionable Responses**
- Provides direct links to features
- Shows step-by-step instructions
- Offers to open relevant pages

✅ **Learning & Improvement**
- Tracks common questions
- Improves responses over time
- Identifies documentation gaps

✅ **Cost-Effective**
- ~$0.001 per question
- Significantly cheaper than human support
- 24/7 availability
- Scales infinitely

✅ **Better User Experience**
- Faster than searching FAQ
- More conversational
- Can ask follow-up questions
- Gets smarter over time

### Technical Implementation

#### Backend Service

**File:** `backend/help_service.py`

```python
"""
AI Help Service
Provides intelligent help using Claude API
"""

import os
import anthropic
from datetime import datetime

class HelpService:
    def __init__(self):
        self.client = anthropic.Anthropic(
            api_key=os.environ.get("ANTHROPIC_API_KEY")
        )
        
        self.system_prompt = """You are a helpful assistant for an SLA Monitoring Portal.

Portal Structure:
- Asset → Service → Job → SLA (hierarchical relationship)
- Assets: Infrastructure components (servers, databases, etc.)
- Services: Applications/jobs running on assets
- Jobs: Scheduled work with cron expressions
- SLAs: Performance targets and monitoring rules

Your role:
- Help users understand how to create and manage Assets, Services, Jobs, and SLAs
- Explain portal features and navigation
- Provide step-by-step instructions
- Help interpret dashboards and reports
- Troubleshoot common issues
- Explain concepts clearly

Available features:
- Dashboard: View SLA metrics and compliance
- Assets: Manage infrastructure components
- Services: Manage applications and jobs
- Alerts: View and manage SLA violations
- Reports: Generate compliance reports
- Onboarding: Guided setup wizard for new users
- Metadata Retrieval: Bulk import from Autosys/Ansible Tower

Guidelines:
- Keep answers concise (2-4 paragraphs max)
- Provide actionable next steps
- Offer to show step-by-step if needed
- Include direct links when relevant
- Be friendly and encouraging
- If you don't know something, say so and suggest contacting support

Never:
- Make up features that don't exist
- Provide inaccurate technical information
- Be condescending or impatient
"""
    
    def get_help_response(self, user_question, current_page=None, conversation_history=[]):
        """
        Get AI-powered help response
        
        Args:
            user_question: User's question
            current_page: Current page URL (for context)
            conversation_history: Previous messages in conversation
        
        Returns:
            dict: {'answer': str, 'timestamp': str}
        """
        
        # Add current page context
        system_prompt = self.system_prompt
        if current_page:
            system_prompt += f"\n\nUser is currently on: {current_page}"
        
        # Build message history
        messages = []
        for msg in conversation_history:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # Add current question
        messages.append({
            "role": "user",
            "content": user_question
        })
        
        try:
            # Call Claude API
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1000,
                system=system_prompt,
                messages=messages
            )
            
            answer = response.content[0].text
            
            return {
                'answer': answer,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                'answer': "I'm sorry, I encountered an error. Please try again or contact support.",
                'timestamp': datetime.now().isoformat(),
                'error': str(e)
            }
    
    def log_question(self, question, answer, user_id):
        """Log questions for analytics and improvement"""
        # Store in database for analysis
        pass
```

#### API Endpoints

**File:** `backend/api_service.py`

```python
from help_service import HelpService

help_service = HelpService()

@app.route('/api/v1/help/ask', methods=['POST'])
@require_auth
def ask_help_question():
    """
    Ask the AI help assistant a question
    
    Request Body:
    {
        "question": "How do I create an SLA?",
        "current_page": "/services",
        "conversation_history": [
            {"role": "user", "content": "..."},
            {"role": "assistant", "content": "..."}
        ]
    }
    
    Response:
    {
        "answer": "To create an SLA...",
        "timestamp": "2025-12-14T10:30:00"
    }
    """
    
    data = request.json
    question = data.get('question')
    current_page = data.get('current_page')
    conversation_history = data.get('conversation_history', [])
    
    if not question:
        return jsonify({'error': 'Question is required'}), 400
    
    try:
        response = help_service.get_help_response(
            question, 
            current_page, 
            conversation_history
        )
        
        # Log for analytics
        user_id = get_current_user_id()
        help_service.log_question(question, response['answer'], user_id)
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/v1/help/common-questions', methods=['GET'])
def get_common_questions():
    """
    Get list of common questions for quick access
    
    Response:
    {
        "questions": [
            "How do I create an SLA?",
            "What's the difference between direct and indirect monitoring?",
            ...
        ]
    }
    """
    
    common_questions = [
        "How do I create an SLA for a batch job?",
        "What's the difference between direct and indirect monitoring?",
        "How do I import jobs from Autosys?",
        "Why is my job showing as 'failed'?",
        "How do I set up alerts for SLA violations?",
        "What does the onboarding wizard do?",
        "Can I bulk import 100+ jobs at once?",
        "How do I link a service to an asset?",
        "What cron format should I use for daily jobs?",
        "How do I view SLA compliance reports?"
    ]
    
    return jsonify({'questions': common_questions})
```

#### Frontend Component

**File:** `frontend/src/components/HelpBot.jsx`

```jsx
import React, { useState, useEffect, useRef } from 'react';
import { FiMessageCircle, FiX, FiSend, FiMinimize2, FiMaximize2 } from 'react-icons/fi';
import apiService from '../services/api';

const HelpBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hi! 👋 I'm your SLA Portal assistant. What would you like to know?",
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [commonQuestions, setCommonQuestions] = useState([]);
  
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load common questions
  useEffect(() => {
    const loadCommonQuestions = async () => {
      try {
        const response = await apiService.help.getCommonQuestions();
        setCommonQuestions(response.data.questions);
      } catch (err) {
        console.error('Failed to load common questions:', err);
      }
    };
    
    if (isOpen) {
      loadCommonQuestions();
    }
  }, [isOpen]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && !isMinimized) {
      inputRef.current?.focus();
    }
  }, [isOpen, isMinimized]);

  const handleSend = async (questionText = null) => {
    const question = questionText || input.trim();
    if (!question) return;

    // Add user message
    const userMessage = { 
      role: 'user', 
      content: question,
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      // Call help API
      const response = await apiService.help.ask({
        question: question,
        current_page: window.location.pathname,
        conversation_history: messages.slice(0, -1) // Exclude welcome message
      });

      // Add assistant response
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.data.answer,
        timestamp: response.data.timestamp
      }]);
      
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I'm sorry, I encountered an error. Please try again or contact support if the problem persists.",
        timestamp: new Date().toISOString(),
        error: true
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleQuickQuestion = (question) => {
    handleSend(question);
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 w-14 h-14 bg-primary-600 text-white rounded-full shadow-lg hover:bg-primary-700 transition-all duration-200 flex items-center justify-center z-50 hover:scale-110"
          aria-label="Open help chat"
        >
          <FiMessageCircle className="w-6 h-6" />
          {/* Notification badge for new features */}
          <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full"></span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div 
          className={`fixed bottom-6 right-6 bg-white rounded-lg shadow-2xl flex flex-col z-50 transition-all duration-200 ${
            isMinimized ? 'w-80 h-14' : 'w-96 h-[600px]'
          }`}
        >
          {/* Header */}
          <div className="bg-primary-600 text-white p-4 rounded-t-lg flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center mr-3">
                <FiMessageCircle className="w-5 h-5 text-primary-600" />
              </div>
              <div>
                <span className="font-semibold">SLA Portal Assistant</span>
                {!isMinimized && (
                  <div className="text-xs text-primary-100">Powered by Claude AI</div>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="hover:bg-primary-700 p-1 rounded transition"
                aria-label={isMinimized ? "Maximize" : "Minimize"}
              >
                {isMinimized ? (
                  <FiMaximize2 className="w-5 h-5" />
                ) : (
                  <FiMinimize2 className="w-5 h-5" />
                )}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="hover:bg-primary-700 p-1 rounded transition"
                aria-label="Close"
              >
                <FiX className="w-5 h-5" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-lg p-3 ${
                        msg.role === 'user'
                          ? 'bg-primary-600 text-white'
                          : msg.error
                          ? 'bg-red-100 text-red-900'
                          : 'bg-white text-gray-900 shadow-sm border border-gray-200'
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{msg.content}</div>
                      <div className={`text-xs mt-1 ${
                        msg.role === 'user' ? 'text-primary-100' : 'text-gray-500'
                      }`}>
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                ))}
                
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-white rounded-lg p-3 shadow-sm border border-gray-200">
                      <div className="flex space-x-2">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Questions */}
              {messages.length === 1 && commonQuestions.length > 0 && (
                <div className="p-4 border-t border-gray-200 bg-white">
                  <div className="text-sm font-medium text-gray-700 mb-2">
                    Common questions:
                  </div>
                  <div className="space-y-2">
                    {commonQuestions.slice(0, 3).map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleQuickQuestion(q)}
                        className="w-full text-left text-sm text-primary-600 hover:bg-primary-50 p-2 rounded transition"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="p-4 border-t border-gray-200 bg-white rounded-b-lg">
                <div className="flex space-x-2">
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask a question..."
                    rows={1}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 resize-none"
                    disabled={loading}
                  />
                  <button
                    onClick={() => handleSend()}
                    disabled={loading || !input.trim()}
                    className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
                    aria-label="Send message"
                  >
                    <FiSend className="w-5 h-5" />
                  </button>
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  Press Enter to send, Shift+Enter for new line
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
};

export default HelpBot;
```

#### API Service Integration

**File:** `frontend/src/services/api.js`

```javascript
// Add to existing apiService

const apiService = {
  // ... existing services ...
  
  help: {
    ask: (data) => apiClient.post('/help/ask', data),
    getCommonQuestions: () => apiClient.get('/help/common-questions')
  }
};
```

#### App Integration

**File:** `frontend/src/App.jsx`

```jsx
import HelpBot from './components/HelpBot';

function App() {
  return (
    <div className="App">
      {/* ... existing routes and components ... */}
      
      {/* Help Bot - Available on all pages */}
      <HelpBot />
    </div>
  );
}
```

### Example Conversations

#### **Example 1: Creating an SLA**

```
User: How do I create an SLA for a batch job?