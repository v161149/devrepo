---------------------Single Row validation---------------------------------------------
select distinct rate_deter_id from (
select 
       'update vprice_app.legacy_spec_det set rate_deter_value=', b.rate_deter_value, ' where leg_li_id=',a.leg_li_id,
       ' and rate_deter_id=',a.rate_deter_id,' and rate_deter_value=',a.rate_deter_value, ';'
from legacy_spec_det a, legacy_spec_det_single_row b
where a.leg_li_id=b.leg_li_id and
      a.rate_deter_id=b.rate_deter_id and
      b.sr_trans_type='UPDATE' and a.leg_li_id like '201712%' and
      a.rate_deter_value<>b.rate_deter_value
);
------------------Single ROw mapping----------------------
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='Gold'  
where leg_li_id like '201712%' and rate_deter_id='SP_APP_PERF_LEVEL' and rate_deter_value='Gold ';  
    
update vprice_legacy.legacy_spec_det_single_row   
set rate_deter_value = 'Ethernet over TDM or DWDM'    
where rate_deter_id='SP_ACC_TECH' and   
      rate_deter_value in ('TYPE1(Legacy)','TYPE3(Legacy)') and   
      leg_li_id in (   
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                 where leg_li_id like '201712%' and rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='Ethernet'   
                 );    
    
update vprice_legacy.legacy_spec_det_single_row   
set rate_deter_value = 'Switched Ethernet'    
where rate_deter_id='SP_ACC_TECH' and   
      rate_deter_value in ('STANDARD(Legacy)','TYPE2(Legacy)','TYPE4(Legacy)') and   
      leg_li_id in (   
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                 where leg_li_id like '201712%' and rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='Ethernet'   
                 );   
 
update vprice_legacy.legacy_spec_det_single_row   
set rate_deter_value = 'TDM (DSn/OCn/SDH)'    
where rate_deter_id='SP_ACC_TECH' and   
      rate_deter_value <> 'TDM (DSn/OCn/SDH)' and   
      leg_li_id in (   
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                 where leg_li_id like '201712%' and rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'   
                 );   

update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='45 Mbps'   
where rate_deter_id='SP_ACC_SPEED' and    
      rate_deter_value='44.736 Mbps(Legacy)' and   
      leg_li_id in (   
        select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
        where leg_li_id like '201712%' and rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'   
      );   
    
update vprice_legacy.legacy_spec_det_single_row    
set rate_deter_value ='On-Net'    
where rate_deter_id='SP_VZB_LIT_STATUS' and   
      leg_li_id in (   
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                 where leg_li_id like '201712%' and rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'         
      ) and           
      leg_li_id in (   
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                 where leg_li_id like '201712%' and rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Platinum'         
      ) and   
      leg_li_id in (   
                  select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                 where leg_li_id like '201712%' and rate_deter_id='SP_VZB_LIT_STATUS' and rate_deter_value<>'On-Net'        
      );   

update vprice_legacy.legacy_spec_det_single_row    
set rate_deter_value ='Off-Net'     
where rate_deter_id='SP_VZB_LIT_STATUS' and    
      leg_li_id in (    
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row    
                 where leg_li_id like '201712%' and rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'          
      ) and            
      leg_li_id in (    
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row    
                 where leg_li_id like '201712%' and rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Gold'          
      ) and    
      leg_li_id in (    
                  select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row    
                 where leg_li_id like '201712%' and rate_deter_id='SP_VZB_LIT_STATUS' and rate_deter_value<>'Off-Net'         
      );    

update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='ALSEOC'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ALSEOC','ALSEOSA','EOCCLEC','NXDS1') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ALS') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='ATTSWC15'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ATTBLG15','ATTMUX16','ATTSWC15') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='BS') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='ATTSWC15'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ATTBLG15','ATTMUX16','ATTSWC15') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ATT') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EPIPE'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EPIPE','CNBEVPL','CNBEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row 
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CNB') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EPLZLIT'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EPLHFC','EPLHFCZ','EPLLIT','EPLZ','EPLZLIT','EPL') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row  
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='COM') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPLBELITZ'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLBEHFC','EVPLBEHFCZ','EVPLBELIT','EVPLBE','EVPLBEZ','EVPLBELITZ','COXEOMC') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='COX') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPLLIT'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPL','EVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row  
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CRR') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPLPD'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLSP') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row  
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CTL') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='ELIEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ELIEOC','ELIEVPL','ELIEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ELI') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPLPD'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLB') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FPT') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='FRNBLG16'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('FRNEVPLPD','EVPLB','FRNBLG16','FRNSWC16','FRNEVPLXS') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FRN') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='LUMEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('LUMEVPL','LUMEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='LUM') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPL','EVPLLIT','WSNLANLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='LV3') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='MOERT'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('MOERT','MOERT10','MOERT30','MOESP') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='SDNEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SDNEVPL','SDNEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SDN') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='SNLEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SNLEVPL','SNLEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SNL') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='SUDEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SUDHFC','SUDEVPL','SUDEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SUD') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='TWCEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('TWCHFC','TWCEVPL','TWCEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='TWC') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='WINEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WINEOC','CES','WINEVPL','WINEVPPLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='WIN') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='WOWEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WOWHFC','WOWEVPL','WOWEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='WOW') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='NATIVEZONE1'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EOC','NATIVEZONE1','NATIVEZONE2','NATIVELIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='XO') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='ZAYEVPL'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ZAYEVPL','ZAYEVPLLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ZAY') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='WSNLAN'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WSNLAN','WSNLANLIT') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='TWT') and  
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPLPD'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLBLG1','EVPLBLG3','EVPLSWC1') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Gold') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_APP_PERF_LEVEL' and rate_deter_value='Gold') and                      
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   ) ; 
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='EVPLB'  
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLB','EVPLBLG2','EVPLBLG4','EVPLSWC2') or rate_deter_value is null) and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Gold') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_APP_PERF_LEVEL' and rate_deter_value='Silver') and                        
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='Gold'  
where rate_deter_id='SP_APP_PERF_LEVEL' and   
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_APP_PERF_LEVEL' and (rate_deter_value<>'Gold' or rate_deter_value is null)) and                        
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='Gold'  
where rate_deter_id='SP_OPER_PERF_LEVEL' and   
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712v%' and rate_deter_id='SP_OPER_PERF_LEVEL' and (rate_deter_value<>'Gold' or rate_deter_value is null)) and                        
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
 
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='Gold'  
where rate_deter_id='SP_OPER_PERF_LEVEL' and   
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and leg_li_id not like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and leg_li_id not like '201712v%' and rate_deter_id='SP_OPER_PERF_LEVEL' and (rate_deter_value is null)) and                        
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   );  
			     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='Gold'  
where rate_deter_id='SP_OPER_PERF_LEVEL' and   
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and leg_li_id not like '201712v%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and leg_li_id not like '201712v%' and rate_deter_id='SP_OPER_PERF_LEVEL' and (rate_deter_value is null)) and                        
      leg_li_id in (select a.li_id from vprice_legacy.legacy_line_item_single_row a,bi_type_feed3 b    
                    where a.li_id like '201712v%' and a.cw_feat_item_id = b.cir_id  
                   ); 	  
				     
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='VZB'  
where rate_deter_id='SP_ACC_PROVIDER' and   
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and rate_deter_id='SP_ACC_TECH' and rate_deter_value='Ethernet over TDM or DWDM') and  
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Platinum') and                        
      leg_li_id in (select leg_li_id from vprice_legacy.legacy_spec_det_single_row   
                    where leg_li_id like '201712%' and rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value<>'VZB');  
				      
update vprice_legacy.legacy_spec_det_single_row  
set rate_deter_Value='Ethernet over TDM or DWDM'   
where rate_deter_value='TYPE3(Legacy)'  and rate_deter_id='SP_ACC_TECH' and   
    leg_li_id in (  
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row  
                 where leg_li_id like '201712%' and   
                       rate_deter_id='SP_CUST_HAND_OFF_TYPE' and   
                       rate_deter_value='Ethernet'        
    );   
				      
update vprice_legacy.legacy_spec_det_single_row  
set rate_deter_Value='TDM (DSn/OCn/SDH)'   
where rate_deter_value='TYPE3(Legacy)' and   
    rate_deter_id='SP_ACC_TECH' and   
    leg_li_id in (  
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row  
                 where leg_li_id like '201712%' and   
                       rate_deter_id='SP_CUST_HAND_OFF_TYPE' and   
                       rate_deter_value='TDM'        
    ); 	   
