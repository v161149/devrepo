----------------------The access revenue in BI_TYPE_FEED3 doesn't consider discount value.
----------------------It's not accurate. We should not use its value to overwrite DWH charge value in LEGACY_RATE
----------------------We already fixed this issue in the data load app in Feb18 branch
--MERGE INTO vprice_legacy.LEGACY_RATE ca1 
--USING (SELECT b.leg_li_id,b.amount,b.discount
--       FROM vprice_legacy.LEGACY_LINE_ITEM a, vprice_legacy.LEGACY_RATE_STG b
--       WHERE a.prod_yy_mth=201712 and a.is_vrd='N' and a.is_metered=0 and a.prod_featr='FET_LA' and a.li_id=b.leg_li_id and 
--			 b.amount is not null and b.amount <>0 and b.discount is not null and b.discount <>0) ca2 
--ON ( 
--  ca1.leg_li_id = ca2.leg_li_id AND ca2.discount <>0 AND ca2.amount <>0
--) 
--WHEN MATCHED THEN UPDATE SET amount = ca2.amount;

----------------------The rate value and discount value in LEGACY_RATE is unit price. But PE divides it by qty in LEGACY_LINE_ITEM 
----------------------when fetching non-metered line items including rate and discount. This issue only happened in non-metered IGT
----------------------The same PE logic works fine for metered IGT data.
MERGE INTO vprice_legacy.LEGACY_RATE ca1 
USING (SELECT b.leg_li_id,a.qty,b.amount
       FROM vprice_legacy.LEGACY_LINE_ITEM a
       INNER JOIN vprice_legacy.LEGACY_RATE_STG b 
       ON (a.li_id=b.leg_li_id AND a.prod_yy_mth=201712 and a.is_metered=0 and a.qty>0 and a.prod_featr='FET_LA'
       )
       WHERE b.amount is not null and b.amount <>0) ca2 
ON ( 
  ca1.leg_li_id = ca2.leg_li_id
) 
WHEN MATCHED THEN UPDATE SET amount = ca2.amount*ca2.qty;

MERGE INTO vprice_legacy.LEGACY_RATE ca1 
USING (SELECT b.leg_li_id,a.qty,b.discount
       FROM vprice_legacy.LEGACY_LINE_ITEM a
       INNER JOIN vprice_legacy.LEGACY_RATE_STG b 
       ON (a.li_id=b.leg_li_id AND a.prod_yy_mth=201712 and a.is_metered=0 and a.qty>0 and a.prod_featr='FET_LA'
       )
       WHERE b.discount is not null and b.discount <>0) ca2 
ON ( 
  ca1.leg_li_id = ca2.leg_li_id
) 
WHEN MATCHED THEN UPDATE SET discount = ca2.discount*ca2.qty;