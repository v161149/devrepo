-----Single row data fix
update vprice_legacy.legacy_spec_det_single_row
set rate_deter_Value='Ethernet over TDM or DWDM' 
where rate_deter_value='TYPE3(Legacy)'
and leg_li_id like '201712%' and 
    rate_deter_id='SP_ACC_TECH' and 
    leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where leg_li_id like '201712%' and 
                       rate_deter_id='SP_CUST_HAND_OFF_TYPE' and 
                       rate_deter_value='Ethernet'      
    ); --270
--------second update  
--select count(*) from vprice_legacy.legacy_spec_det_single_row
update vprice_legacy.legacy_spec_det_single_row
set rate_deter_Value='TDM (DSn/OCn/SDH)' 
where rate_deter_value='TYPE3(Legacy)'
and leg_li_id like '201712%' and 
    rate_deter_id='SP_ACC_TECH' and 
    leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where leg_li_id like '201712%' and 
                       rate_deter_id='SP_CUST_HAND_OFF_TYPE' and 
                       rate_deter_value='TDM'      
    ); --615
commit;	