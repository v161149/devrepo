------------------------------------------------
--Insert missing UNI SPEED in 201802 PROD
------------------------------------------------
insert into legacy_spec_det (leg_li_id,rate_deter_id,rate_deter_value)
select leg_li_id,'SP_UNI_SPEED','10M'
From Vprice_Legacy.Legacy_Spec_Det 
Where  Rate_Deter_Id='SP_ACC_SPEED' And 
       Rate_Deter_Value in ('1.5 Mbps','2 Mbps','3 Mbps','4 Mbps','5 Mbps','6 Mbps','10 Mbps') and 
       Leg_Li_Id Like '201802%' And 
       Leg_Li_Id In (
       Select Leg_Li_Id From Vprice_Legacy.Legacy_Spec_Det 
       Where  Rate_Deter_Id='SP_ACC_TECH' And 
              Rate_Deter_Value='TYPE2(Legacy)' And 
              Leg_Li_Id Like '201802%' And 
              Leg_Li_Id Not In (Select Leg_Li_Id From Vprice_Legacy.Legacy_Spec_Det 
                                Where  Rate_Deter_Id='SP_UNI_SPEED' And Leg_Li_Id Like '201802%')
       );

insert into legacy_spec_det (leg_li_id,rate_deter_id,rate_deter_value)
select leg_li_id,'SP_UNI_SPEED','100M'
From Vprice_Legacy.Legacy_Spec_Det 
Where  Rate_Deter_Id='SP_ACC_SPEED' And 
       Rate_Deter_Value in ('20 Mbps','30 Mbps','40 Mbps','50 Mbps','60 Mbps','70 Mbps','100 Mbps') and 
       Leg_Li_Id Like '201802%' And 
       Leg_Li_Id In (
       Select Leg_Li_Id From Vprice_Legacy.Legacy_Spec_Det 
       Where  Rate_Deter_Id='SP_ACC_TECH' And 
              Rate_Deter_Value='TYPE2(Legacy)' And 
              Leg_Li_Id Like '201802%' And 
              Leg_Li_Id Not In (Select Leg_Li_Id From Vprice_Legacy.Legacy_Spec_Det 
                                Where  Rate_Deter_Id='SP_UNI_SPEED' And Leg_Li_Id Like '201802%')
       );
       

insert into legacy_spec_det (leg_li_id,rate_deter_id,rate_deter_value)
select leg_li_id,'SP_UNI_SPEED','1G'
From Vprice_Legacy.Legacy_Spec_Det 
Where  Rate_Deter_Id='SP_ACC_SPEED' And 
       Rate_Deter_Value in ('155 Mbps','200 Mbps','300 Mbps','1 Gbps') and 
       Leg_Li_Id Like '201802%' And 
       Leg_Li_Id In (
       Select Leg_Li_Id From Vprice_Legacy.Legacy_Spec_Det 
       Where  Rate_Deter_Id='SP_ACC_TECH' And 
              Rate_Deter_Value='TYPE2(Legacy)' And 
              Leg_Li_Id Like '201802%' And 
              Leg_Li_Id Not In (Select Leg_Li_Id From Vprice_Legacy.Legacy_Spec_Det 
                                Where  Rate_Deter_Id='SP_UNI_SPEED' And Leg_Li_Id Like '201802%')
       );  
 