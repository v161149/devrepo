update vprice_legacy.legacy_spec_det set rate_deter_value='4450_S' where rate_deter_id='SP_PAM_5090_Access_Type' and leg_li_id in ( 
select distinct b.leg_li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b 
where a.li_id=b.leg_li_id and  
a.is_vrd='N' and  
a.is_metered=1 and  
a.prod_featr='FET_PAM_2109_Toll_Free_Internati' and 
b.rate_deter_id ='SP_PAM_5090_Access_Type' and 
a.int_inv_literal_desc in ( 
'Switched Access to Dedicated'));

update vprice_legacy.legacy_spec_det set rate_deter_value='4452_D' where rate_deter_id='SP_PAM_5091_Egress_Type' and leg_li_id in ( 
select distinct b.leg_li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b 
where a.li_id=b.leg_li_id and  
a.is_vrd='N' and  
a.is_metered=1 and  
a.prod_featr='FET_PAM_2109_Toll_Free_Internati' and 
b.rate_deter_id ='SP_PAM_5091_Egress_Type' and 
a.int_inv_literal_desc in ( 
'Switched Access to Dedicated'));

update vprice_legacy.legacy_spec_det set rate_deter_value='4450_S' where rate_deter_id='SP_PAM_5090_Access_Type' and leg_li_id in ( 
select distinct b.leg_li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b 
where a.li_id=b.leg_li_id and  
a.is_vrd='N' and  
a.is_metered=1 and  
a.prod_featr='FET_PAM_2109_Toll_Free_Internati' and 
b.rate_deter_id ='SP_PAM_5090_Access_Type' and 
a.int_inv_literal_desc in ( 
'Local Network to Local Network', 
'Switched Access to Local Network'));

update vprice_legacy.legacy_spec_det set rate_deter_value='4451_L' where rate_deter_id='SP_PAM_5091_Egress_Type' and leg_li_id in ( 
select distinct b.leg_li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b 
where a.li_id=b.leg_li_id and  
a.is_vrd='N' and  
a.is_metered=1 and  
a.prod_featr='FET_PAM_2109_Toll_Free_Internati' and 
b.rate_deter_id ='SP_PAM_5091_Egress_Type' and 
a.int_inv_literal_desc in ( 
'Local Network to Local Network', 
'Switched Access to Local Network'))

update vprice_legacy.legacy_spec_det set rate_deter_value='4450_S' where rate_deter_id='SP_PAM_5090_Access_Type' and leg_li_id in ( 
select distinct b.leg_li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b 
where a.li_id=b.leg_li_id and  
a.is_vrd='N' and  
a.is_metered=1 and  
a.prod_featr='FET_PAM_2109_Toll_Free_Internati' and 
b.rate_deter_id ='SP_PAM_5090_Access_Type' and 
a.int_inv_literal_desc in ( 
'Local Network to Switched Access', 
'Switched Access to Switched Access'))

update vprice_legacy.legacy_spec_det set rate_deter_value='4453_S' where rate_deter_id='SP_PAM_5091_Egress_Type' and leg_li_id in ( 
select distinct b.leg_li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b 
where a.li_id=b.leg_li_id and  
a.is_vrd='N' and  
a.is_metered=1 and  
a.prod_featr='FET_PAM_2109_Toll_Free_Internati' and 
b.rate_deter_id ='SP_PAM_5091_Egress_Type' and 
a.int_inv_literal_desc in ( 
'Local Network to Switched Access', 
'Switched Access to Switched Access'))