-- Fix duplicate LD voice and Audio Conf data
delete from vprice_app.legacy_spec_det 
where rate_deter_id=''SP_PAM_BAN'' and leg_li_id in (
select li_id from vprice_app.legacy_line_item 
where is_vrd=''N'' and is_metered=1 and year= :year and month = :month and prod in (''PR_PAM_Long_Distance_Voice'',''PR_PAM_Audio_Conference'')
);

delete from vprice_app.legacy_spec_det 
where rate_deter_id=''SP_PAM_MAN'' and leg_li_id in (
select li_id from vprice_app.legacy_line_item 
where is_vrd=''N'' and is_metered=1 and year= :year and month = :month and prod in (''PR_PAM_Long_Distance_Voice'',''PR_PAM_Audio_Conference'')
); 

-- Fix unwanted ACC features
delete from vprice_app.legacy_spec_det where leg_li_id in (
select li_id from vprice_app.legacy_line_item 
where prod=''PR_ACC'' and is_vrd=''N'' and is_metered=0 and year= :year and month = :month and
prod_featr in (
''FET_ACC_OVR_USAGE'',
''FET_CARR_DIVER'',
''FET_CCONN'',
''FET_APP'',
''FET_LNSD'',
''FET_TSP_RESTOR'',
''FET_TSP_PRIOR_CHANGE''
));

delete from vprice_app.legacy_err_log where leg_li_id in (
select li_id from vprice_app.legacy_line_item 
where prod=''PR_ACC'' and is_vrd=''N'' and is_metered=0 and year= :year and month = :month and
prod_featr in (
''FET_ACC_OVR_USAGE'',
''FET_CARR_DIVER'',
''FET_CCONN'',
''FET_APP'',
''FET_LNSD'',
''FET_TSP_RESTOR'',
''FET_TSP_PRIOR_CHANGE''
));

delete from vprice_app.legacy_rate where leg_li_id in (
select li_id from vprice_app.legacy_line_item 
where prod=''PR_ACC'' and is_vrd=''N'' and is_metered=0 and year= :year and month = :month and
prod_featr in (
''FET_ACC_OVR_USAGE'',
''FET_CARR_DIVER'',
''FET_CCONN'',
''FET_APP'',
''FET_LNSD'',
''FET_TSP_RESTOR'',
''FET_TSP_PRIOR_CHANGE''
));

delete from vprice_app.legacy_line_item 
where prod=''PR_ACC'' and is_vrd=''N'' and is_metered=0 and year= :year and month = :month and
prod_featr in (
''FET_ACC_OVR_USAGE'',
''FET_CARR_DIVER'',
''FET_CCONN'',
''FET_APP'',
''FET_LNSD'',
''FET_TSP_RESTOR'',
''FET_TSP_PRIOR_CHANGE''
);

commit;


