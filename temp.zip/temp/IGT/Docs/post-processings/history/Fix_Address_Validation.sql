-------load 201710 unvalidated addresses to legacy_site_validation and set the status as'new'----------------------
insert into legacy_site_validation (LEGACY_SITE_ID,SITE_ADDR1,SITE_ADDR2,CITY,TERR_CODE,TERR_CODE_DESC,POST_CDE,CNTRY_NAME,VALIDITY_STATUS,VALIDITY_DATE)
select distinct a.LEGACY_SITE_ID,a.SITE_ADDR1,a.SITE_ADDR2,a.CITY,a.TERR_CODE,
                a.TERR_CODE_DESC,a.POST_CDE,a.CNTRY_NAME,'new',sysdate
from legacy_site a,legacy_line_item b
where a.legacy_site_id=b.legacy_site_id and b.year=2017 and b.month=10 and
      b.prod='PR_ACC' and a.legacy_site_id not in (
      select legacy_site_id from legacy_site_validation
      );
-------load 201710 ACCESS only unvalidated addresses with status 'new' from legacy_site_validation to legacy_site_validation_pending----------------------	  
insert into legacy_site_validation_pending (LEGACY_SITE_ID,SITE_ADDR1,SITE_ADDR2,CITY,TERR_CODE,TERR_CODE_DESC,POST_CDE,CNTRY_NAME)
select distinct a.LEGACY_SITE_ID,a.SITE_ADDR1,a.SITE_ADDR2,a.CITY,a.TERR_CODE,
                a.TERR_CODE_DESC,a.POST_CDE,a.CNTRY_NAME
from legacy_site_validation a, legacy_line_item b
where a.legacy_site_id=b.legacy_site_id and b.year=2017 and b.month=10 and
      a.validity_status='new' and b.prod='PR_ACC' and a.legacy_site_id not in (
        select distinct a.legacy_site_id from legacy_site_validation_pending a
        inner join legacy_site_cameo b on a.legacy_site_id=b.legacy_site_id
        where b.pass_validation in ('Y','N')      
      )	  

---------------Remove invalid value under site_addr_1
update legacy_site_validation_pending set site_addr2=null where site_addr2='NA';

select * 
from legacy_site_validation_pending 
where site_addr1 like '%0' and site_addr2 is not null;

update legacy_site_validation_pending set site_addr1=site_addr2, site_addr2=null
where legacy_site_id not in (5275763,5295403,5295847) and legacy_site_id in (
select legacy_site_id 
from legacy_site_validation_pending 
where site_addr1 like '%0' and site_addr2 is not null
);

update legacy_site_validation_pending set site_addr1=site_addr2,site_addr2=null
where site_addr2 is not null and
legacy_site_id in (
select legacy_site_id 
from legacy_site_validation_pending where site_addr1 not like '% %' and site_addr2 is not null
);

update legacy_site_validation_pending set site_addr2=null where site_addr2='STE NA';
update legacy_site_validation_pending set site_addr2=null where site_addr1 is not null and site_addr2 like 'STE%';
update legacy_site_validation_pending set cntry_name='USA' where cntry_name in ('US','AK') or cntry_name is null;

UPDATE LEGACY_SITE_VALIDATION_PENDING SET SITE_ADDR2=NULL 
WHERE LEGACY_SITE_ID IN (
SELECT LEGACY_SITE_ID
FROM LEGACY_SITE_VALIDATION_PENDING WHERE CNTRY_NAME IS NOT NULL AND 
        LEGACY_SITE_ID NOT IN (SELECT DISTINCT LEGACY_SITE_ID FROM LEGACY_SITE_CAMEO) AND
        SITE_ADDR2 IS NOT NULL);
==============================================================================================
--1. total 168560 --valid 167806 -- invalid 754 --Validity percentage = 99.5%
select count(*)
from legacy_site_validation 
where legacy_site_id in (select distinct a.LEGACY_SITE_ID
                         from legacy_site_validation a, legacy_line_item b
                         where a.legacy_site_id=b.legacy_site_id and 
                               b.year=2017 and b.month=10 and b.prod='PR_ACC' and
                               --a.validity_status in ('valid')
                               --a.validity_status in ('invalid')
                               a.validity_status not in ('valid','invalid')
                        )
;
--2. 641 total number of sites havent's been validated.
select count(*) from legacy_site_validation_pending where legacy_site_id in (
select legacy_site_id
from legacy_site_validation 
where legacy_site_id in (select distinct a.LEGACY_SITE_ID
                         from legacy_site_validation a, legacy_line_item b
                         where a.legacy_site_id=b.legacy_site_id and 
                               b.year=2017 and b.month=9 and b.prod='PR_ACC' and
                               a.validity_status not in ('valid','invalid')
                               --a.validity_status not in ('valid')
                               --a.validity_status not in ('invalid')
                        )
)                        
;
--3a. 641 total number of sites actually were validated but marked as none of valid or invalid.
select count(*) from legacy_site_batch_contents where legacy_site_id in (
  select count(*) from legacy_site_validation_pending where legacy_site_id in (
  select legacy_site_id
  from legacy_site_validation 
  where legacy_site_id in (select distinct a.LEGACY_SITE_ID
                           from legacy_site_validation a, legacy_line_item b
                           where a.legacy_site_id=b.legacy_site_id and 
                                 b.year=2017 and b.month=9 and b.prod='PR_ACC' and
                                 a.validity_status not in ('valid','invalid')
                          )
  ) 
)
;
--3b. fix 3a issue
select distinct 
       a.SITE_ADDR1,a.SITE_ADDR2,a.CITY,
       a.TERR_CODE,a.TERR_CODE_DESC,a.POST_CDE,a.CNTRY_NAME 
from legacy_site_validation_pending a 
where legacy_site_id in (
    select legacy_site_id
    from legacy_site_validation 
    where legacy_site_id in (select distinct a.LEGACY_SITE_ID
                             from legacy_site_validation a, legacy_line_item b
                             where a.legacy_site_id=b.legacy_site_id and 
                                   b.year=2017 and b.month=9 and b.prod='PR_ACC' and
                                   a.validity_status in ('invalid')
                                   --a.validity_status not in ('valid','invalid')
                                   --a.validity_status not in ('valid','invalid')
                            )
)                        
order by a.SITE_ADDR1;

update legacy_site_validation set validity_status='invalid' where legacy_site_id in (
select distinct legacy_site_id from legacy_site_validation_pending
where site_addr1 in ('115 NE OLD TOWN RD','1720 CONGRESSMAN WL DICKINSON DRIVE','CIRCUIT PROVISIONING-DAVE MELTON',
                     'PO BOX 561547','WEST 6 AVE AND KIPLING(DFC BL'))
;

update legacy_site_validation set validity_status='valid' where legacy_site_id in (
select distinct 
       a.legacy_site_id 
from legacy_site_validation_pending a 
where legacy_site_id in (
    select legacy_site_id
    from legacy_site_validation 
    where legacy_site_id in (select distinct a.LEGACY_SITE_ID
                             from legacy_site_validation a, legacy_line_item b
                             where a.legacy_site_id=b.legacy_site_id and 
                                   b.year=2017 and b.month=9 and b.prod='PR_ACC' and
                                   a.validity_status not in ('valid','invalid')
                            )
));
----------------------How many 201709 sites haven't been loaded to legacy_site_validation_pending?
select count(*) 
from legacy_site_validation 
where --legacy_site_id not in (select distinct legacy_site_id from legacy_site_cameo) and 
      legacy_site_id in (select distinct a.LEGACY_SITE_ID
                         from legacy_site_validation a, legacy_line_item b
                         where a.legacy_site_id=b.legacy_site_id and b.year=2017 and b.month=9 and
                               a.validity_status<>'valid' and b.prod='PR_ACC'
                        ) and
     legacy_site_id not in (select distinct legacy_site_id from legacy_site_validation_pending)                 
;
---------------------How many sites still sit in legacy_site_validation_pending but haven't been validated by cameo?
select count(*) 
--select distinct legacy_site_id
from legacy_site_validation_pending 
where legacy_site_id not in (select distinct legacy_site_id from legacy_site_batch_contents);
 --if exists, then probably need manual fix
select * 
from legacy_site_validation_pending 
where legacy_site_id not in (select distinct legacy_site_id from legacy_site_cameo);


