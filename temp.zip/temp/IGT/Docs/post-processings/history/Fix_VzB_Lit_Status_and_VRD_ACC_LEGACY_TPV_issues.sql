--------------------------
--remove lines related to features : 'FET_CARR_DIVER','FET_APP','FET_LNSD'
delete from vprice_legacy.legacy_err_log
where leg_li_id in (
select distinct li_id from vprice_legacy.legacy_line_item 
where li_id like '201709%' and prod_featr in ('FET_CARR_DIVER','FET_APP','FET_LNSD')
);

delete from vprice_legacy.legacy_rate
where leg_li_id in (
select distinct li_id from vprice_legacy.legacy_line_item
where li_id like '201709%' and prod_featr in ('FET_CARR_DIVER','FET_APP','FET_LNSD')
);

delete from vprice_legacy.legacy_spec_det
where leg_li_id in (
select distinct li_id from vprice_legacy.legacy_line_item
where li_id like '201709%' and prod_featr in ('FET_CARR_DIVER','FET_APP','FET_LNSD')
);

delete from vprice_legacy.legacy_line_item
where li_id like '201709%' and prod_featr in ('FET_CARR_DIVER','FET_APP','FET_LNSD');

--keep only VRD ACCESS FET_LA feature!
delete from vprice_legacy.legacy_err_log
where leg_li_id in (
select distinct li_id from vprice_legacy.legacy_line_item 
where li_id like '201709%' and prod='PR_ACC' and prod_featr <>'FET_LA' and is_vrd='Y'
);

delete from vprice_legacy.legacy_rate
where leg_li_id in (
select distinct li_id from vprice_legacy.legacy_line_item
where li_id like '201709%' and prod='PR_ACC' and prod_featr <>'FET_LA' and is_vrd='Y'
);

delete from vprice_legacy.legacy_spec_det
where leg_li_id in (
select distinct li_id from vprice_legacy.legacy_line_item
where li_id like '201709%' and prod='PR_ACC' and prod_featr <>'FET_LA' and is_vrd='Y'
);

delete from vprice_legacy.legacy_line_item 
where li_id like '201709%' and prod='PR_ACC' and prod_featr <>'FET_LA' and is_vrd='Y'

--------------------------Already fixed in java code
--Rate fix if necessary
--select 'update legacy_rate_single_row set amount=',c.ACCESS_REVENUE,' where leg_li_id=',a.li_id, '<Mynd>' 
--from legacy_line_item_single_row a, legacy_rate_single_row b, bi_type_feed3 c 
--where a.li_id=b.leg_li_id and a.cw_feat_item_id=c.cir_id and c.ACCESS_REVENUE<>b.amount;	
--------------------------
--For SP_CUST_HAND_OFF_TYPE=�Ethernet�, 
--if SP_ACC_TECH stays �TYPE1(Legacy)� or �TYPE3(Legacy)� set SP_ACC_TECH=�� Ethernet over TDM or DWDM� 
--else 
--if SP_ACC_TECH=� STANDARD(Legacy)�  or �TYPE2(Legacy)�  or �TYPE4(Legacy)� set SP_ACC_TECH=�Switched Ethernet�
update vprice_legacy.legacy_spec_det_single_row
set rate_deter_value = 'Ethernet over TDM or DWDM' 
where rate_deter_id='SP_ACC_TECH' and
      rate_deter_value in ('TYPE1(Legacy)','TYPE3(Legacy)') and
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='Ethernet'
                 );
      
update vprice_legacy.legacy_spec_det_single_row
set rate_deter_value = 'Switched Ethernet' 
where rate_deter_id='SP_ACC_TECH' and
      rate_deter_value in ('STANDARD(Legacy)','TYPE2(Legacy)','TYPE4(Legacy)') and
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='Ethernet'
                 ); 
-----------------------------------
--if SP_CUST_HAND_OFF_TYPE="TDM" and SP_ACC_TECH <>"TDM (DSn/OCn/SDH)" then 
--set SP_ACC_TECH ="TDM (DSn/OCn/SDH)"

update vprice_legacy.legacy_spec_det_single_row
set rate_deter_value = 'TDM (DSn/OCn/SDH)' 
where rate_deter_id='SP_ACC_TECH' and
      rate_deter_value <> 'TDM (DSn/OCn/SDH)' and
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'
                 );

-----------task#1 SP_ACC_SPEED fix 44.736
update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='45 Mbps'
where --leg_li_id like '201709LSR%' and 
      rate_deter_id='SP_ACC_SPEED' and 
      rate_deter_value='44.736 Mbps(Legacy)' and
      leg_li_id in (
        select leg_li_id from vprice_legacy.legacy_spec_det_single_row
        where rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'
      );

--For Customer Handoff (L1 Interface) = TDM and Operational Performance Level = 'Platinum" and VzB Lit Status <> "On-Net"
--then update  VzB Lit Status = "On-Net"
update vprice_legacy.legacy_spec_det_single_row 
set rate_deter_value ='On-Net' 
where rate_deter_id='SP_VZB_LIT_STATUS' and --leg_li_id like '201709LSR%' and
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'      
      ) and        
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Platinum'      
      ) and
      leg_li_id in (
                  select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_VZB_LIT_STATUS' and rate_deter_value<>'On-Net'     
      );
      
--For Customer Handoff (L1 Interface) = TDM and Operational Performance Level = 'Gold" and VzB Lit Status <> "Off-Net"
--then update  VzB Lit Status = "Off-Net"
update vprice_legacy.legacy_spec_det_single_row
set rate_deter_value ='Off-Net' 
where rate_deter_id='SP_VZB_LIT_STATUS' and --leg_li_id like '201709LSR%' and
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_CUST_HAND_OFF_TYPE' and rate_deter_value='TDM'      
      ) and        
      leg_li_id in (
                 select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Gold'      
      ) and
      leg_li_id in (
                  select distinct leg_li_id from vprice_legacy.legacy_spec_det_single_row
                 where rate_deter_id='SP_VZB_LIT_STATUS' and rate_deter_value<>'Off-Net'     
      );
-----------Apply ethernet COS mappings manually--------------
-----------task#2 VRD ACC_LEGACY_TPV FIX [BS and ATT] <-- comment fixed it in code!
--Single_row_VRD_LEGACY_TPV_Fix.sql
--update vprice_legacy.legacy_spec_det_single_row set rate_deter_value='ATTSWC15'
--where leg_li_id like '201709SRv%' and
--      rate_deter_id ='SP_ACC_LEGACY_TPV' and --rate_deter_value='ATTMUX16' and
--      leg_li_id in (
--select distinct a.leg_li_id 
--from vprice_legacy.legacy_spec_det_single_row a,vprice_legacy.bi_type_feed3 b, vprice_legacy.legacy_line_item_single_row c
--where a.rate_deter_id ='SP_ACC_LEGACY_TPV' and 
--      --a.rate_deter_value='ATTMUX16' and 
--      a.leg_li_id=c.li_id and 
--      c.cw_feat_item_id=b.cir_id and
--      b.cameo_carrier_abbr in ('BS','ATT') and
--      (b.sr_ethernet_cos is null or
--       b.sr_ethernet_cos not like 'ATTBLG15%' or
--      b.sr_ethernet_cos not like 'ATTMUX16%') and
--      a.leg_li_id in (
--                   select distinct leg_li_id 
--                   from vprice_legacy.legacy_spec_det_single_row
--                   where leg_li_id like '201709SRv%' and 
--                         rate_deter_id ='SP_ACC_TECH' and
--                         rate_deter_value <> 'Ethernet over TDM or DWDM'
--                 )
--);
--------------VRD CIRCUIT-----------------------------------------------------------
update legacy_spec_det_single_row set rate_deter_value='ALSEOC'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ALSEOC','ALSEOSA','EOCCLEC','NXDS1') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ALS') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='ATTSWC15'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ATTBLG15','ATTMUX16','ATTSWC15') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='BS') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );                   
update legacy_spec_det_single_row set rate_deter_value='ATTSWC15'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ATTBLG15','ATTMUX16','ATTSWC15') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ATT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='EPIPE'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EPIPE','CNBEVPL','CNBEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CNB') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='EPLZLIT'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EPLHFC','EPLHFCZ','EPLLIT','EPLZ','EPLZLIT','EPL') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='COM') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLBELITZ'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLBEHFC','EVPLBEHFCZ','EVPLBELIT','EVPLBE','EVPLBEZ','EVPLBELITZ','COXEOMC') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='COX') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='EVPLLIT'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPL','EVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CRR') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLSP') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CTL') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='ELIEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ELIEOC','ELIEVPL','ELIEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ELI') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLB') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FPT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='FRNBLG16'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('FRNEVPLPD','EVPLB','FRNBLG16','FRNSWC16','FRNEVPLXS') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FRN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='LUMEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('LUMEVPL','LUMEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='LUM') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );  
update legacy_spec_det_single_row set rate_deter_value='EVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPL','EVPLLIT','WSNLANLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='LV3') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='MOERT'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('MOERT','MOERT10','MOERT30','MOESP') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='SDNEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SDNEVPL','SDNEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SDN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='SNLEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SNLEVPL','SNLEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SNL') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='SUDEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SUDHFC','SUDEVPL','SUDEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SUD') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='TWCEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('TWCHFC','TWCEVPL','TWCEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='TWC') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='WINEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WINEOC','CES','WINEVPL','WINEVPPLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='WIN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='WOWEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WOWHFC','WOWEVPL','WOWEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='WOW') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='NATIVEZONE1'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EOC','NATIVEZONE1','NATIVEZONE2','NATIVELIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='XO') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );                   
update legacy_spec_det_single_row set rate_deter_value='ZAYEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ZAYEVPL','ZAYEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ZAY') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='WSNLAN'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WSNLAN','WSNLANLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='TWT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLBLG1','EVPLBLG3','EVPLSWC1') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Gold') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_APP_PERF_LEVEL' and rate_deter_value='Gold') and                    
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLB'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLB','EVPLBLG2','EVPLBLG4','EVPLSWC2') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Gold') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_APP_PERF_LEVEL' and rate_deter_value='Silver') and                      
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );    
update legacy_spec_det_single_row set rate_deter_value='Gold'
where rate_deter_id='SP_APP_PERF_LEVEL' and 
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_APP_PERF_LEVEL' and (rate_deter_value<>'Gold' or rate_deter_value is null)) and                      
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='Gold'
where rate_deter_id='SP_OPER_PERF_LEVEL' and 
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_OPER_PERF_LEVEL' and (rate_deter_value<>'Gold' or rate_deter_value is null)) and                      
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );  				   
				   				   
--------------LEGACY CIRCUIT-----------------------------------------------------------
update legacy_spec_det_single_row set rate_deter_value='Gold'
where rate_deter_id='SP_OPER_PERF_LEVEL' and 
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_OPER_PERF_LEVEL' and (rate_deter_value is null)) and                      
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );  
update legacy_spec_det_single_row set rate_deter_value='Gold'
where rate_deter_id='SP_OPER_PERF_LEVEL' and 
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_OPER_PERF_LEVEL' and (rate_deter_value is null)) and                      
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709LSR%' and li_id not like '201709LSRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );  	
-----------------New SR mapping rule-----------------
--If Access Technology = "Ethernet over TDM or DWDM" and Operational Performance = "Platinum" and Access Provider <> "VZB" then update Access Provider = 'VZB"
update legacy_spec_det_single_row set rate_deter_value='VZB'
where leg_li_id like '201709LSR%' and
      rate_deter_id='SP_ACC_PROVIDER' and 
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_TECH' and rate_deter_value='Ethernet over TDM or DWDM') and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_OPER_PERF_LEVEL' and rate_deter_value='Platinum') and                      
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value<>'VZB');
-----------------------------------------------------------------------------------------
--below logic is coded in java code				   
update legacy_spec_det_single_row set rate_deter_value='ALSEOC'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ALSEOC','ALSEOSA','EOCCLEC','NXDS1') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ALS') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='ATTSWC15'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ATTBLG15','ATTMUX16','ATTSWC15') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='BS') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );                   
update legacy_spec_det_single_row set rate_deter_value='ATTSWC15'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ATTBLG15','ATTMUX16','ATTSWC15') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ATT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='EPIPE'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EPIPE','CNBEVPL','CNBEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CNB') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='EPLZLIT'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EPLHFC','EPLHFCZ','EPLLIT','EPLZ','EPLZLIT','EPL') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='COM') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLBELITZ'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLBEHFC','EVPLBEHFCZ','EVPLBELIT','EVPLBE','EVPLBEZ','EVPLBELITZ','COXEOMC') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='COX') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='EVPLLIT'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPL','EVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CRR') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLSP') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='CTL') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='ELIEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ELIEOC','ELIEVPL','ELIEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ELI') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLB') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FPT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='FRNEVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('FRNEVPLPD','EVPLB','FRNBLG16','FRNSWC16','FRNEVPLXS') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FRN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3 where evc_los='PD')
                   );
update legacy_spec_det_single_row set rate_deter_value='EVPLB'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('FRNEVPLPD','EVPLB','FRNBLG16','FRNSWC16','FRNEVPLXS') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FRN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3 where evc_los='BASIC')
                   );
update legacy_spec_det_single_row set rate_deter_value='FRNEVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('FRNEVPLPD','EVPLB','FRNBLG16','FRNSWC16','FRNEVPLXS') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='FRN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3 where evc_los not in ('PD','BASIC'))
                   );				   
update legacy_spec_det_single_row set rate_deter_value='LUMEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('LUMEVPL','LUMEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='LUM') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );  
update legacy_spec_det_single_row set rate_deter_value='EVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPL','EVPLLIT','WSNLANLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='LV3') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='MOERT'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('MOERT','MOERT10','MOERT30','MOESP') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='QWT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='SDNEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SDNEVPL','SDNEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SDN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='SNLEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SNLEVPL','SNLEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SNL') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='SUDEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('SUDHFC','SUDEVPL','SUDEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='SUD') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='TWCEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('TWCHFC','TWCEVPL','TWCEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='TWC') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='WINEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WINEOC','CES','WINEVPL','WINEVPPLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='WIN') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );
update legacy_spec_det_single_row set rate_deter_value='WOWEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WOWHFC','WOWEVPL','WOWEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='WOW') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='NATIVEZONE1'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EOC','NATIVEZONE1','NATIVEZONE2','NATIVELIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='XO') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   );                   
update legacy_spec_det_single_row set rate_deter_value='ZAYEVPL'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('ZAYEVPL','ZAYEVPLLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='ZAY') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='WSNLAN'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('WSNLAN','WSNLANLIT') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='TWT') and
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3)
                   ); 
update legacy_spec_det_single_row set rate_deter_value='EVPLPD'
where rate_deter_id='SP_ACC_LEGACY_TPV' and (rate_deter_value not in ('EVPLPD','EVPLB','EVPLBLG1','EVPLBLG2','EVPLBLG3','EVPLBLG4','EVPLSWC1','EVPLSWC2') or rate_deter_value is null) and
      leg_li_id in (select leg_li_id from legacy_spec_det_single_row --
                    where rate_deter_id='SP_ACC_PROVIDER' and rate_deter_value='VZT') and                 
      leg_li_id in (select li_id from legacy_line_item_single_row 
                                    where li_id like '201709SR%' and li_id not like '201709SRv%' and
                                    cw_feat_item_id in (select cir_id from bi_type_feed3 where legacy_cea_type='2')
                   ); 
  