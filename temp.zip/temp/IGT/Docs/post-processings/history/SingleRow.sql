-------------------------------------------------------------------------------------------------
--for scenario like these, where SP_ACC_SPEED is greater than 100 Mbps, SP_UNI_SPEED should be 1G
-------------------------------------------------------------------------------------------------
update vprice_legacy.legacy_spec_det set rate_deter_value='1G'
where rate_deter_id='SP_UNI_SPEED' and leg_li_id like '201602%' and
leg_li_id in (
select leg_li_id from vprice_legacy.legacy_spec_det
where leg_li_id in (
select a.li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b
where a.is_vrd='N' and a.is_metered=0 and a.prod = 'PR_ACC' and a.li_id=b.leg_li_id
and b.rate_deter_id='SP_UNI_SPEED'
) and leg_li_id in (
select a.li_id from vprice_legacy.legacy_line_item a, vprice_legacy.legacy_spec_det b
where a.is_vrd='N' and a.is_metered=0 and a.prod = 'PR_ACC' and a.li_id=b.leg_li_id
and b.rate_deter_id='SP_CUST_HAND_OFF_TYPE' and b.rate_deter_value='Ethernet'
) and rate_deter_id='SP_ACC_SPEED' and rate_deter_value in ('1 Gbps',
'10 Gbps',
'150 Mbps',
'155 Mbps',
'200 Mbps',
'300 Mbps',
'400 Mbps',
'450 Mbps(Legacy)',
'500 Mbps',
'600 Mbps',
'700 Mbps(Legacy)',
'800 Mbps(Legacy)'));

commit;