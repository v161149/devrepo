--++++++++++++++++++++VRD ACCESS NxT1 issue++++++++++++++++++++++++++++--
select DISTINCT RPTG_CRCTP from V333651.PBLI_REPORT
where PROD_YR_MTH = 201709 and PRODUCT_ID = 'PR_ACC' and RPTG_CRCTP like '%x%' and
      (ACTIVE_CONFIG IS NULL OR ACTIVE_CONFIG = 'Y');

update vprice_legacy.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from V333651.PBLI_REPORT a, 
     vprice_legacy.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and b.year=2017 and b.month=9 and
      a.PROD_YR_MTH = 201709 and a.PRODUCT_ID = 'PR_ACC' and 
      b.prod=a.product_id and b.prod_featr='FET_LA' and
      trim(a.RPTG_CRCTP) = '2xDS1' and b.is_vrd='Y' and b.qty<>2 and
      (a.ACTIVE_CONFIG IS NULL OR a.ACTIVE_CONFIG = 'Y')      
);

update vprice_legacy.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from V333651.PBLI_REPORT a, 
     vprice_legacy.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and b.year=2017 and b.month=9 and
      a.PROD_YR_MTH = 201709 and a.PRODUCT_ID = 'PR_ACC' and 
      b.prod=a.product_id and b.prod_featr='FET_LA' and
      trim(a.RPTG_CRCTP) = '3xDS1' and b.is_vrd='Y' and b.qty<>3 and
      (a.ACTIVE_CONFIG IS NULL OR a.ACTIVE_CONFIG = 'Y')      
);

update vprice_legacy.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from V333651.PBLI_REPORT a, 
     vprice_legacy.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and b.year=2017 and b.month=9 and
      a.PROD_YR_MTH = 201709 and a.PRODUCT_ID = 'PR_ACC' and 
      b.prod=a.product_id and b.prod_featr='FET_LA' and
      trim(a.RPTG_CRCTP) = '4xDS1' and b.is_vrd='Y' and b.qty<>4 and
      (a.ACTIVE_CONFIG IS NULL OR a.ACTIVE_CONFIG = 'Y')      
);

update vprice_legacy.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from V333651.PBLI_REPORT a, 
     vprice_legacy.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and b.year=2017 and b.month=9 and
      a.PROD_YR_MTH = 201709 and a.PRODUCT_ID = 'PR_ACC' and 
      b.prod=a.product_id and b.prod_featr='FET_LA' and
      trim(a.RPTG_CRCTP) = '5xDS1' and b.is_vrd='Y' and b.qty<>5 and
      (a.ACTIVE_CONFIG IS NULL OR a.ACTIVE_CONFIG = 'Y')      
);

update vprice_legacy.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from V333651.PBLI_REPORT a, 
     vprice_legacy.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and b.year=2017 and b.month=9 and
      a.PROD_YR_MTH = 201709 and a.PRODUCT_ID = 'PR_ACC' and 
      b.prod=a.product_id and b.prod_featr='FET_LA' and
      trim(a.RPTG_CRCTP) = '6xDS1' and b.is_vrd='Y' and b.qty<>6 and
      (a.ACTIVE_CONFIG IS NULL OR a.ACTIVE_CONFIG = 'Y')      
);	  
-----------------------
--ACCESS : N x T1 issue 
-----------------------
update vprice_app.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=9 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '2xDS1'
);
	  
--++++++++++++++++++++Legacy NxT1 issue++++++++++++++++++++++++++++--
select distinct rptg_crctp from (
select a.cir_chrg_cat,a.rptg_crctp,a.rptg_cir_speed,a.orgnl_cir_speed,a.pip_port_speed, b.li_id,b.cw_feat_item_id,b.qty,b.ext_inv_literal_cd  
from legacy_data_prods a, legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.rptg_crctp like '%x%'
      );
-----------------------
--ACCESS : N x T1 issue 
-----------------------
update vprice_app.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=9 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '2xDS1'
);

update vprice_app.legacy_line_item set qty=3 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=9 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '3xDS1'
);

update vprice_app.legacy_line_item set qty=4 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=9 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '4xDS1'
);

update vprice_app.legacy_line_item set qty=5 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=9 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '5xDS1'
);

update vprice_app.legacy_line_item set qty=6 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '6xDS1'
);

update vprice_app.legacy_line_item set qty=7 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '7xDS1'
);

update vprice_app.legacy_line_item set qty=8 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_LA' and c.vprice_name='SP_ACC_SPEED' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'ACCESS%' and trim(a.rptg_crctp) = '8xDS1'
);
-----------------------
--Private IP : N x T1 issue 
-----------------------
update vprice_app.legacy_line_item set qty=2 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '2xDS1'
);

update vprice_app.legacy_line_item set qty=3 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '3xDS1'
);

update vprice_app.legacy_line_item set qty=4 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '4xDS1'
);

update vprice_app.legacy_line_item set qty=5 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '5xDS1'
);

update vprice_app.legacy_line_item set qty=6 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '6xDS1'
);

update vprice_app.legacy_line_item set qty=7 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '7xDS1'
);

update vprice_app.legacy_line_item set qty=8 where li_id in (
select distinct b.li_id  
from vprice_app.legacy_data_prods a, 
     vprice_app.legacy_line_item b, 
     vprice_app.legacy_mapping c
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      c.mapping_name='FET_PIP_COS' and c.vprice_name='SP_EF_REALTIME_CAR' and 
      trim(c.bcp_value)=trim(a.rptg_crctp) and c.vprice_value='1.5 Mbps' and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      a.cir_chrg_cat like 'PVC/CAR%' and b.prod='PR_PIP_SVC' and trim(a.rptg_crctp) = '8xDS1'
);

-----------------------
--Frame Relay - US : N x T1 issue 
-----------------------
update vprice_app.legacy_line_item set qty=2 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '2xDS1%'
);

update vprice_app.legacy_line_item set qty=3 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '3xDS1%'
);

update vprice_app.legacy_line_item set qty=4 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '4xDS1%'
);

update vprice_app.legacy_line_item set qty=5 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '5xDS1%'
);

update vprice_app.legacy_line_item set qty=6 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '6xDS1%'
);

update vprice_app.legacy_line_item set qty=7 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '7xDS1%'
);

update vprice_app.legacy_line_item set qty=8 where li_id in (
select b.li_id  
from vprice_app.legacy_data_prods a, vprice_app.legacy_line_item b
where a.cir_id=b.cw_feat_item_id and 
      a.year=b.year and a.month=b.month and a.year=2017 and a.month=8 and
      trim(a.cir_chrg_cat)=b.prod_feat_nme and
      (a.cir_chrg_cat like 'PORT%' or a.cir_chrg_cat like 'PVC/CAR%') and b.prod='PR_PAM_Frame_Relay' and a.rptg_crctp like '8xDS1%'
);
-------------------------------------------Use data_prods QTY and single row QTY to fix SR NxT1 issue
MERGE INTO VPRICE_LEGACY.LEGACY_RATE ca1
USING ( 
select * from 
(select a.li_id as LSR_LI_ID,a.qty as LSR_QTY,b.amount as LSR_AMOUNT 
from legacy_line_item a, legacy_rate b
where a.li_id=b.leg_li_id and a.year=2017 and a.month=9 and 
      a.li_id like '201709LSR%' 
      and a.li_id in (
'201709LSRabt1039',
'201709LSRabt1790',
'201709LSRabt2117',
'201709LSRabt2153',
'201709LSRab2161',
'201709LSRadr234018',
'201709LSRadr234030',
'201709LSRadr234067',
'201709LSRadr234068'     
      )
) a,
(select 
distinct regexp_replace(a.li_id, '201709', '201709LSR') as sr_li_id,
         a.li_id,a.qty,b.amount,b.amount*a.qty as sr_total
from legacy_line_item a, legacy_rate b
where a.year=2017 and a.month=9 and 
      a.prod_featr='FET_LA' and a.qty>1 and b.amount>0 and
      a.li_id=b.leg_li_id and a.li_id LIKE '201709%' and a.li_id NOT LIKE '201709LSR%'
       and a.li_id in (
'201709abt1039',
'201709abt1790',
'201709abt2117',
'201709abt2153',
'201709ab2161',
'201709adr234018',
'201709adr234030',
'201709adr234067',
'201709adr234068' 
       )
       ) b
where a.LSR_LI_ID=b.SR_LI_ID and a.LSR_QTY=b.qty and a.LSR_AMOUNT=b.sr_total
)ca2 
ON ( 
  ca1.leg_li_id = ca2.LSR_LI_ID AND ca1.leg_li_id like '201709%' 
) 
WHEN MATCHED THEN UPDATE SET AMOUNT = ca2.AMOUNT;

select * from 
(select a.prod_yy_mth, a.li_id as LSR_LI_ID,a.qty as LSR_QTY,b.amount as LSR_AMOUNT 
from legacy_line_item a, legacy_rate b
where a.li_id=b.leg_li_id and a.year=2017 and a.month=9 and 
      a.li_id like '201709LSR%' 
      and a.li_id in (
'201709LSRabt1039',
'201709LSRabt1790',
'201709LSRabt2117',
'201709LSRabt2153',
'201709LSRab2161',
'201709LSRadr234018',
'201709LSRadr234030',
'201709LSRadr234067',
'201709LSRadr234068'     
      )
) a,
(select 
distinct regexp_replace(a.li_id, '201709', '201709LSR') as sr_li_id,
         a.li_id,a.qty,b.amount,b.amount*a.qty as sr_total
from legacy_line_item a, legacy_rate b
where a.year=2017 and a.month=9 and 
      a.prod_featr='FET_LA' and a.qty>1 and b.amount>0 and
      a.li_id=b.leg_li_id and a.li_id LIKE '201709%' and a.li_id NOT LIKE '201709LSR%'
       and a.li_id in (
'201709abt1039',
'201709abt1790',
'201709abt2117',
'201709abt2153',
'201709ab2161',
'201709adr234018',
'201709adr234030',
'201709adr234067',
'201709adr234068' 
       )
       ) b
where a.LSR_LI_ID=b.SR_LI_ID and a.LSR_QTY=b.qty and a.LSR_AMOUNT=b.sr_total;
