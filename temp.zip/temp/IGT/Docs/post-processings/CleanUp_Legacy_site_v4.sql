update vprice_app.legacy_site set site_addr2 = replace(site_addr2,'NA,','') where site_addr2 like 'NA,%';
update vprice_app.legacy_site set site_addr2 =null where site_addr2='NA';
update vpricE_app.legacy_site set site_addr1=site_addr2,site_addr2=null
where legacy_site_id in (
select legacy_site_id 
from vpricE_app.legacy_site where site_addr1 like '%0000%' and
     legacy_site_id not in (5257234,5277843,5256422,3746891,2859091,3449681,5263674)
);  
update vprice_app.legacy_site set cntry_name='USA' where cntry_name in ('US','AK') or cntry_name is null;
update vprice_app.legacy_site set site_addr2=null where site_addr2='STE NA';
update vpricE_app.legacy_site set site_addr1 = 'NA' where site_addr1 is null;
commit;
