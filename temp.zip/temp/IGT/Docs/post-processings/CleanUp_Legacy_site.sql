--#1 in this case, we should remove 'CO' under column 'terr_code. 
--select * from vprice_app.legacy_site where terr_code='CO' and cntry_name <>'USA';
--update vprice_app.legacy_site set terr_code=null where terr_code='CO' and cntry_name <>'USA';
--#2 in this case, we should remove invalid sub-string 'NA,' under column - 'site_addr2'
--select * from vprice_app.legacy_site where site_addr2 like 'NA,%';
update vprice_app.legacy_site set site_addr2 = replace(site_addr2,'NA,','') where site_addr2 like 'NA,%';
--#3 in this case, we should replace 'NA' with empty string if any of sit_addr1 and site_addr2 has value as 'NA'
--select * from legacy_site where site_addr2 ='NA' or site_addr2='NA';
update vprice_app.legacy_site set site_addr2 =null where site_addr2='NA';
update vpricE_app.legacy_site set site_addr1 = 'NA' where site_addr1 is null;
--#5 set site_addr1 with the value of site_addr2 if site_addr1 contains '%0000%'
update legacy_site_validation_pending set site_addr1=site_addr2,site_addr2=null
where legacy_site_id in (
select legacy_site_id 
from legacy_site_validation_pending where site_addr1 like '%0000%' and
     legacy_site_id not in (5257234,5277843,5256422,3746891,2859091,3449681,5263674)
);  

--#6 set cntry_name with 'USA' cntry_name in ('US','AK') or cntry_name is null
update vprice_app.legacy_site set cntry_name='USA' where cntry_name in ('US','AK') or cntry_name is null;
--#7 select * from vprice_app.legacy_site where site_addr2='STE NA';
update vprice_app.legacy_site_validation_pending set site_addr2=null where site_addr2='STE NA';
