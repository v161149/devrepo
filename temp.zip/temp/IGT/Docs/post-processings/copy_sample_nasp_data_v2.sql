--1. load legacy_acct data
merge into vprice_app.legacy_acct a
using (
        select distinct b.LEGACY_ACCT_ID,b.ACCT_ID,b.NASP_ID,b.SUBNASP_ID,b.BAN,b.NPA,b.NXX
        from vprice_legacy.legacy_line_item a 
        inner join vprice_legacy.legacy_acct b
        on a.legacy_acct_id = b.legacy_acct_id and 
           b.nasp_id='10DCOV' and a.prod_yy_mth=201806
        inner join vprice_legacy.legacy_site c
        on a.legacy_site_id = c.legacy_site_id
       ) b
       on (a.legacy_acct_id= b.legacy_acct_id)
       when not matched then insert (a.LEGACY_ACCT_ID,a.ACCT_ID,a.NASP_ID,a.SUBNASP_ID,a.BAN,a.NPA,a.NXX)
       values(b.LEGACY_ACCT_ID,b.ACCT_ID,b.NASP_ID,b.SUBNASP_ID,b.BAN,b.NPA,b.NXX);

merge into vprice_app.LEGACY_ACCT_NASP_GATEWAY a
using (
        select distinct LEGACY_ACCT_NASP_GATEWAY_ID,ACCT_ID,GATEWAY_ID,NASP_ID,GW_NAME
        from vprice_legacy.LEGACY_ACCT_NASP_GATEWAY where nasp_id='10DCOV'
       ) b
       on (a.LEGACY_ACCT_NASP_GATEWAY_ID= b.LEGACY_ACCT_NASP_GATEWAY_ID and
           a.ACCT_ID= b.ACCT_ID and
           a.GATEWAY_ID= b.GATEWAY_ID and
           a.NASP_ID= b.NASP_ID
       )
       when not matched then insert (a.LEGACY_ACCT_NASP_GATEWAY_ID,a.ACCT_ID,a.GATEWAY_ID,a.NASP_ID,a.GW_NAME)
       values(b.LEGACY_ACCT_NASP_GATEWAY_ID,b.ACCT_ID,b.GATEWAY_ID,b.NASP_ID,b.GW_NAME);
	   
--2. load legacy_site data
merge into vprice_app.legacy_site a
using (
        select distinct c.LEGACY_SITE_ID,c.SITE_ADDR1,c.SITE_ADDR2,c.CITY,
                        c.TERR_CODE,c.TERR_CODE_DESC,c.POST_CDE,c.CNTRY_NAME
        from vprice_legacy.legacy_line_item a 
        inner join vprice_legacy.legacy_acct b
        on a.legacy_acct_id = b.legacy_acct_id and 
           b.nasp_id='10DCOV' and a.prod_yy_mth=201806
        inner join vprice_legacy.legacy_site c
        on a.legacy_site_id = c.legacy_site_id
       ) b
       on (a.legacy_site_id= b.legacy_site_id)
       when not matched then insert (a.legacy_site_id,a.site_addr1,a.site_addr2,a.city,a.terr_code,a.terr_code_desc,a.post_cde,a.cntry_name)
       values(b.legacy_site_id,b.site_addr1,b.site_addr2,b.city,b.terr_code,b.terr_code_desc,b.post_cde,b.cntry_name);

--3. load legacy_line_item data
INSERT INTO vprice_app.legacy_line_item (
LI_ID,
LEGACY_ACCT_ID,
LEGACY_SITE_ID,
PS_LI_STAT,
SITE,
PROD_YY_MTH,
PROD,
PROD_NME,
PROD_FEATR,
PROD_FEAT_NME,
CW_PROD_ITEM_ID,
CW_FEAT_ITEM_ID,
QTY,
REQ_CURR_CODE,
EXT_INV_LITERAL_CD,
EXT_INV_LITERAL_DESC,
INT_INV_LITERAL_CD,
INT_INV_LITERAL_DESC,
ORIG_TERM,
REMAINING_TERM,
IS_METERED,
IS_PRICEABLE,
FEED,
CIR_CMPNT_ID,
ACCS_CIR_ID,
RPTG_CNTRY_NAME,
IS_SUMMARIZED,
SUMMARIZED_QTY,
IS_VRD
) 
SELECT  DISTINCT
A.LI_ID,
A.LEGACY_ACCT_ID,
A.LEGACY_SITE_ID,
A.PS_LI_STAT,
A.SITE,
A.PROD_YY_MTH,
A.PROD,
A.PROD_NME,
A.PROD_FEATR,
A.PROD_FEAT_NME,
A.CW_PROD_ITEM_ID,
A.CW_FEAT_ITEM_ID,
A.QTY,
A.REQ_CURR_CODE,
A.EXT_INV_LITERAL_CD,
A.EXT_INV_LITERAL_DESC,
A.INT_INV_LITERAL_CD,
A.INT_INV_LITERAL_DESC,
A.ORIG_TERM,
A.REMAINING_TERM,
A.IS_METERED,
A.IS_PRICEABLE,
A.FEED,
A.CIR_CMPNT_ID,
A.ACCS_CIR_ID,
A.RPTG_CNTRY_NAME,
A.IS_SUMMARIZED,
A.SUMMARIZED_QTY,
A.IS_VRD
FROM vprice_legacy.LEGACY_LINE_ITEM A, vprice_legacy.LEGACY_ACCT C 
WHERE A.PROD_YY_MTH=201806 AND c.legacy_acct_id=a.legacy_acct_id AND c.nasp_id='10DCOV';

--4. load legacy_rate data
INSERT INTO vprice_app.LEGACY_RATE 
SELECT DISTINCT B.LEG_LI_ID,B.AMOUNT,B.USAGE_AMT,B.UNIT_OF_MEA,B.CHARGE_FREQ,B.CHARGE_TYPE,B.DISCOUNT 
FROM vprice_legacy.LEGACY_LINE_ITEM A, vprice_legacy.LEGACY_RATE B, vprice_legacy.LEGACY_ACCT C 
WHERE A.LI_ID=B.LEG_LI_ID AND A.PROD_YY_MTH=201806 AND 
      c.legacy_acct_id=a.legacy_acct_id AND c.nasp_id='10DCOV';
      
--5. load legacy_spec_det data 
INSERT INTO vprice_app.LEGACY_SPEC_DET 
SELECT DISTINCT B.LEG_LI_ID,B.RATE_DETER_ID,B.RATE_DETER_VALUE 
FROM vprice_legacy.LEGACY_LINE_ITEM A, vprice_legacy.LEGACY_SPEC_DET B, vprice_legacy.LEGACY_ACCT C 
WHERE A.LI_ID=B.LEG_LI_ID AND A.PROD_YY_MTH=201806 AND 
      c.legacy_acct_id=a.legacy_acct_id AND c.nasp_id='10DCOV';
      
--6. load legacy_err_log data      
INSERT INTO vprice_app.LEGACY_ERR_LOG 
SELECT DISTINCT B.LEGACY_ERR_ID,B.LEG_LI_ID,B.INPUT_DATA,B.QUERY_TEMPLATE_ID,B.PROCEDURE_NME,B.OUTPUT_TS,B.ERROR_ID 
FROM vprice_legacy.LEGACY_LINE_ITEM A, vprice_legacy.LEGACY_ERR_LOG B, vprice_legacy.LEGACY_ACCT C 
WHERE A.LI_ID=B.LEG_LI_ID AND A.PROD_YY_MTH=201806 AND 
      c.legacy_acct_id=a.legacy_acct_id AND c.nasp_id='10DCOV';
      
--7. load legacy_acct_products data
select * from LEGACY_ACCT_PRODUCTS;
INSERT INTO vprice_app.LEGACY_ACCT_PRODUCTS
SELECT DISTINCT C.LEGACY_ACCT_PRODUCTS_ID,C.LEGACY_ACCT_ID,C.PROD_CODE,C.BCP_PRODUCT_NAME,C.PROD_YY_MTH,C.PROD_NME 
FROM vprice_legacy.LEGACY_LINE_ITEM A, vprice_legacy.LEGACY_ACCT B, vprice_legacy.LEGACY_ACCT_PRODUCTS c
WHERE A.legacy_acct_id=B.legacy_acct_id AND A.legacy_acct_id=C.legacy_acct_id AND
      A.PROD_YY_MTH=201806 AND B.nasp_id='10DCOV';
