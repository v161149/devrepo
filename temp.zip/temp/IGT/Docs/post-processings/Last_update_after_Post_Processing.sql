------ updated 201805
merge into vprice_legacy.legacy_rate a  
using (select *   
       from vprice_legacy.legacy_rate_single_row) b  
       on (a.LEG_LI_ID=b.LEG_LI_ID)  
       when matched then update set a.amount=b.AMOUNT,a.discount=b.discount;
------ updated 201803
merge into vprice_legacy.legacy_spec_det a    
using (select *     
       from vprice_legacy.legacy_spec_det_single_row    
       where sr_trans_type='UPDATE') b    
       on (a.LEG_LI_ID=b.LEG_LI_ID and a.RATE_DETER_ID=b.RATE_DETER_ID)    
       when matched then update set a.rate_deter_value=b.RATE_DETER_VALUE;  