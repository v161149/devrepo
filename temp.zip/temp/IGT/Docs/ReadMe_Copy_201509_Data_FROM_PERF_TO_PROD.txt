We need to load 201509 inventory data from schema VPRICE_LEGACY@PERF to schema VPRICE_APP@PROD.

Please follow the steps below in order!!

1.	Export data from PERF (schema: VPRICE_LEGACY) in 4 files
	a.	File 1:
	
	    Please make sure export entire table when working on the file 1.
		
		i.		VPRICE_LEGACY.LEGACY_ACCT
		ii.		VPRICE_LEGACY.LEGACY_SITE
		iii.	VPRICE_LEGACY.LEGACY_ACCT_NASP_GATEWAY

				example parfile:
				userid="/ as sysdba"
				directory={output directory}
				dumpfile=file1.dmp
				logfile=file1.log
				tables=VPRICE_LEGACY.LEGACY_ACCT,VPRICE_LEGACY.LEGACY_SITE,VPRICE_LEGACY.LEGACY_ACCT_NASP_GATEWAY
				parallel=4

	b.	File 2:
	
	    Please note that the two tables below are partition tables. We need to export 201509 partition and subset of 111111 partitions of each table using EXPDP! (note: this is a subpartition)
		i.		VPRICE_LEGACY.LEGACY_ACCT_PRODUCTS (subpartition_name = 'Y2015_SEP')
				+ VPRICE_LEGACY.LEGACY_LINE_ITEM (subpartition_name = 'Y2015_SEP')
				
				example parfile:
				userid="/ as sysdba"
				directory={output directory}
				dumpfile=file2_Y2015_SEP.dmp
				logfile=file2_Y2015_SEP.log
				tables=VPRICE_LEGACY.LEGACY_ACCT_PRODUCTS:Y2015_SEP,VPRICE_LEGACY.LEGACY_LINE_ITEM:Y2015_SEP
				parallel=4


		ii.		VPRICE_LEGACY.LEGACY_ACCT_PRODUCTS (subpartition_name = 'Y1111_NOV' and query = 'where li_id like ''201509%''')
				+ VPRICE_LEGACY.LEGACY_LINE_ITEM (subpartition_name = 'Y1111_NOV' and query = 'where leg_li_id like ''201509%''')
				
				example parfile:
				userid="/ as sysdba"
				directory={output directory}
				dumpfile=file2_Y1111_NOV.dmp
				logfile=file2_Y1111_NOV.log
				tables=VPRICE_LEGACY.LEGACY_ACCT_PRODUCTS:Y1111_NOV,VPRICE_LEGACY.LEGACY_LINE_ITEM:Y1111_NOV
				query=VPRICE_LEGACY.LEGACY_ACCT_PRODUCTS:"where leg_li_id like '201509%'", VPRICE_LEGACY.LEGACY_LINE_ITEM:"where li_id like '201509%'"
				parallel=4


	c.	File 3:
	    
		Please note that the two tables below are also partition tables. We only need to export 201509 partition of each table using EXPDP! (note: this is a regular partition)

		i.		VPRICE_LEGACY.LEGACY_RATE (partition_name = 'Y2015_SEP')
				+ VPRICE_LEGACY.LEGACY_SPEC_DET (partition_name = 'Y2015_SEP')
				
				example parfile:
				userid="/ as sysdba"
				directory={output directory}
				dumpfile=file3_Y2015_SEP.dmp
				logfile=file3_Y2015_SEP.log
				tables=VPRICE_LEGACY.LEGACY_RATE:Y2015_SEP,VPRICE_LEGACY.LEGACY_SPEC_DET:Y2015_SEP
				parallel=4


		ii.		VPRICE_LEGACY.LEGACY_RATE (partition_name = 'Y1111_NOV' and query = 'where leg_li_id like ''201509%''')
				VPRICE_LEGACY.LEGACY_SPEC_DET (partition_name = 'Y1111_NOV and query = 'where leg_li_id like ''201509%''')
				
				example parfile:
				userid="/ as sysdba"
				directory={output directory}
				dumpfile=file3_Y1111_NOV.dmp
				logfile=file3_Y1111_NOV.log
				tables=VPRICE_LEGACY.LEGACY_RATE:Y1111_NOV,VPRICE_LEGACY.LEGACY_SPEC_DET:Y1111_NOV
				query=VPRICE_LEGACY.LEGACY_RATE:"where leg_li_id like '201509%'", VPRICE_LEGACY.LEGACY_SPEC_DET:"where li_id like '201509%'"
				parallel=4

	d.	File 4:		
	
	    Please make sure export entire table when working on the file 4.
		i.	VPRICE_LEGACY.LEGACY_ERR_LOG

			example parfile:
			userid="/ as sysdba"
			directory={output directory}
			dumpfile=file4.dmp
			logfile=file4.log
			tables=VPRICE_LEGACY.LEGACY_ERR_LOG
			parallel=4
		
3.	Pre-processing in PROD (schema: VPRICE_APP)

		--------------------------------------------------------
		--  PRE-DATA LOADING TASKS - DISABLE CONSTRAINTS   
		--------------------------------------------------------
		alter table VPRICE_APP.LEGACY_LINE_ITEM DISABLE constraint LEGACY_LINE_ITEM_FK01;
		alter table VPRICE_APP.LEGACY_LINE_ITEM DISABLE constraint LEGACY_LINE_ITEM_FK02;
		alter table VPRICE_APP.LEGACY_ACCT_PRODUCTS DISABLE constraint LEGACY_ACCT_PRODUCTS_FK1;		
		alter table VPRICE_APP.LEGACY_ERR_LOG DISABLE constraint LEGACY_ERR_LOG_FK1;
		alter table VPRICE_APP.LEGACY_ERR_LOG DISABLE constraint LEGACY_ERR_LOG_FK2;		
		--------------------------------------------------------
		--  PRE-DATA LOADING TASKS - TRUNCATE TABLES   
		--------------------------------------------------------
		truncate table VPRICE_APP.LEGACY_SITE;
		truncate table VPRICE_APP.LEGACY_ACCT;
		truncate table VPRICE_APP.LEGACY_ACCT_NASP_GATEWAY; 

		--------------------------------------------------------
		--  PRE-DATA LOADING TASKS - INSERT 201509 IN LEGACY_PROD_MONTH  
		--------------------------------------------------------		
		Insert into VPRICE_APP.LEGACY_PROD_MONTH (IS_METERED,PROD_YY_MTH) values (0,201509);
        Insert into VPRICE_APP.LEGACY_PROD_MONTH (IS_METERED,PROD_YY_MTH) values (1,201509);


4.	In PROD (schema: VPRICE_APP), import File 1 
	example parfile:
	userid="/ as sysdba"
	directory={import directory}
	dumpfile=file1.dmp
	remap_schema=VPRICE_LEGACY:VPRICE_APP
	content=data_only
	logfile=file1.log
	cluster=n
	parallel=4

5.	In PROD (schema: VPRICE_APP), import File 2 
    Please note that on import, you can choose to load partitions as is, merge them into corresponding single table.
	
	example parfile:
	userid="/ as sysdba"
	directory={import directory}
	dumpfile=file2_Y2015_SEP.dmp
	remap_schema=VPRICE_LEGACY:VPRICE_APP
	content=data_only
	logfile=file2_Y2015_SEP.log
	cluster=n
	parallel=4

	example parfile:
	userid="/ as sysdba"
	directory={import directory}
	dumpfile=file2_Y1111_NOV.dmp
	remap_schema=VPRICE_LEGACY:VPRICE_APP
	content=data_only
	logfile=file2_Y1111_NOV.log
	cluster=n
	parallel=4

6.	In PROD (schema: VPRICE_APP), import File 3 
    Please note that on import, you can choose to load partitions as is, merge them into corresponding single table.

	example parfile:
	userid="/ as sysdba"
	directory={import directory}
	dumpfile=file3_Y2015_SEP.dmp
	remap_schema=VPRICE_LEGACY:VPRICE_APP
	content=data_only
	logfile=file3_Y2015_SEP.log
	cluster=n
	parallel=4

	example parfile:
	userid="/ as sysdba"
	directory={import directory}
	dumpfile=file3_Y1111_NOV.dmp
	remap_schema=VPRICE_LEGACY:VPRICE_APP
	content=data_only
	logfile=file3_Y1111_NOV.log
	cluster=n
	parallel=4

	
7.	In PROD (schema: VPRICE_APP), import File 4 
	
	example parfile:
	userid="/ as sysdba"
	directory={import directory}
	dumpfile=file4.dmp
	remap_schema=VPRICE_LEGACY:VPRICE_APP
	content=data_only
	logfile=file4.log
	cluster=n
	parallel=4
	
8.	Post-processing in PROD (schema: VPRICE_APP)
		--------------------------------------------------------
		--  POST-DATA LOADING TASKS - ENABLE CONSTRAINTS   
		--------------------------------------------------------
		alter table VPRICE_APP.LEGACY_LINE_ITEM ENABLE novalidate constraint LEGACY_LINE_ITEM_FK01;
		alter table VPRICE_APP.LEGACY_LINE_ITEM ENABLE novalidate constraint LEGACY_LINE_ITEM_FK02;
		alter table VPRICE_APP.LEGACY_ACCT_PRODUCTS ENABLE novalidate constraint LEGACY_ACCT_PRODUCTS_FK1;		
        alter table VPRICE_APP.LEGACY_ERR_LOG ENABLE novalidate constraint LEGACY_ERR_LOG_FK1;	
        alter table VPRICE_APP.LEGACY_ERR_LOG ENABLE novalidate constraint LEGACY_ERR_LOG_FK2;	
-------------------------------------------------------------------------------
1. Source DB -> VPRICE_LEGACY @PERF

   Host name : f50fdtd3cluscan.ebiz.verizon.com
   Port : 1800
   Service name : VPRICEPERF
     
2. Target DB -> VPRICE_APP @PROD

   Host name : f50ompd1cluscan.verizon.com
   Port : 1800
   Service name : VPRICEPROD 
     

   
		  
