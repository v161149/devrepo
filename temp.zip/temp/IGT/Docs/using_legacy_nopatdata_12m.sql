
/* first load legacy_nopatdata for a given month as normal */

/* 
truncate table legacy_nopatdata
run java program that loads legacy_nopatdata from EDW
run stats on legacy_nopatdata
etc...
*/

set echo on timing on


/* 
 * The legacy_nopatdata_12m table is designed to hold just 12m (1 year) of NOPAT data.
 * To begin, you will need to truncate the partition corresponding to the month we're about 
 * to load data for. The data in legacy_nopatdata was year_month = '201503' as of this writing, so
 * we will be verifying and truncating the "MAR" partition of legacy_nopatdata_12m
 */
 
select distinct mod(year_month, 100) as month from legacy_nopatdata; -- as of this writing, currently MONTH 3 or March

select count(*) from legacy_nopatdata_12m where month = 3; -- count from previous year Mar data. Note: month is a pseudo column calculated internally

alter table legacy_nopatdata_12m truncate partition mar update global indexes; -- partition names are: jan, feb, mar, apr, ...

select count(*) from legacy_nopatdata_12m where month = 3; -- should return a count of zero

/*
 * now insert data from legacy_nopatdata. Again note: month is a pseudo-column and is not inserted into directly
 */
 
insert
into legacy_nopatdata_12m
	(
		port_speed, program_type_desc, location_name, gold_car_speed, is_icb, pip_model_loc_conc, cost_model_switch_location, cost_model_country, circuit_id, pe_code
		, region_name, switch_owner, car_value, gold_car, city_state_circuitid_pvcid, record_id, silver_car, port_type, country_name, pip_model_country, status_desc,
		silver_car_speed, year_month
	)
select port_speed, program_type_desc, location_name, gold_car_speed, is_icb, pip_model_loc_conc, cost_model_switch_location, cost_model_country, circuit_id,
	pe_code, region_name, switch_owner, car_value, gold_car, city_state_circuitid_pvcid, record_id, silver_car, port_type, country_name, pip_model_country,
	status_desc, silver_car_speed, year_month
from legacy_nopatdata; -- OR whatever the staging table is for loading this data

select count(*) from legacy_nopatdata_12m where month = 3; -- should return same number of rows as inserted

/*
 * After loading monthly data, run stats on the table -OR- just the affected partition
 */
execute dbms_stats.gather_table_stats(ownname=>'VPRICE_LEGACY', tabname=>'LEGACY_NOPATDATA_12M', cascade=>true, force=>true, no_invalidate=>false);


--- OR ---

execute dbms_stats.gather_table_stats(ownname=>'VPRICE_LEGACY', tabname=>'LEGACY_NOPATDATA_12M', partname=>'MAR', cascade=>true, force=>true, no_invalidate=>false);


 
/*
 * Any time you use this table to get circuit NOPAT data, you need to get just the most recent month's data for that circuit.
 * There is a primary key index on (month, circuit_id) so there will only ever be one row returned here.
 */

select * from (
	select * from legacy_nopatdata_12m where circuit_id = 'W0T43274' order by year_month desc
) where rownum = 1;



