------1. For Access, any feature other than FET_LA, needs to have user message "This Access feature needs to be included by PCM as Other products". . ------   Set Ignore flag so that product appears in "ignored list".
------   Example: 
------   FET_LNSD
------   FET_CARR_DIVER
------   FET_CCONN
------   FET_ACC_OVR_USAGE
------   FET_TSP_RESTOR
 
select distinct c.nasp_id,
       a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,                                                                       
       b.rate_deter_value as input_data, 
       'Y' ignore_flag, 
       'This Access feature needs to be included by PCM as Other products.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and 
a.is_vrd='Y' and  
a.year=xxxx and
a.month=xx and
a.prod='PR_ACC' and  
a.prod_featr not in ('FET_LA')
--and a.li_id ='<line_item_id>';

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------2. OCn, SONET related data mapping issues
-------- For Access, Local Access feature, SP_ACC_SPEED  values 155 Mbps / 622 Mbps are not supported. User message 
-------- "Access OCn speeds to be included by PCM as Other products"
-------- NA[OC192], NA[OC48] should have the same error msg as above. Set Ignore flag so that product appears in "ignored list".
																
select distinct c.nasp_id,a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,  
       b.rate_deter_value as input_data, 
       'Y' ignore_flag, 
       'Access OCn speeds to be included by PCM as Other products.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and  
a.is_vrd='N' and 
a.is_metered=0 and 
a.prod_featr='FET_LA' and  
a.rptg_cntry_name in ('UNITED STATES', 'USA') and 
b.rate_deter_id='SP_ACC_SPEED' and  
b.rate_deter_value in ('155 Mbps','622 Mbps','NA[OC192]','NA[OC48]') and
a.year=xxxx and
a.month=xx and
--and a.li_id ='<line_item_id>';

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------3. Multicast related data mapping issue

select distinct c.nasp_id,a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,  
       b.rate_deter_value as input_data, 
       'Y' ignore_flag, 
       'PIP Configuration needs to be included by PCM as other products.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and  
a.is_vrd='N' and 
a.prod = 'PR_PIP_SVC' and 
b.rate_deter_value like 'NA[PIP MULTIC%' and 
a.year=xxxx and
a.month=xx and
--and a.li_id ='<line_item_id>';

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------4. IDS  - Adtran CPE - To show in inventory but not as Invalid Config
--------   IDE related data mapping issue.
 
select distinct c.nasp_id,a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,  
       b.rate_deter_value as input_data, 
       'Y' ignore_flag, 
       'Internet Dedicated Configuration needs to be included by PCM as other products.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and  
a.is_vrd='N' and 
a.prod = 'PR_PAM_Internet_Dedicated' and 
(b.rate_deter_value like 'NA[MANAGED SERVICE%' or 
b.rate_deter_value like 'NA[TSP Restorations%' or 
b.rate_deter_value like 'NA[IDE%' or 
b.rate_deter_value like 'NA[NEWS%' or 
b.rate_deter_value like 'NA[Wholesale%' or 
b.rate_deter_value like 'NA[WS%' or 
b.rate_deter_value like 'NA[Cross Connect%' or 
b.rate_deter_value like 'NA[POP%' or
b.rate_deter_value like 'NA[Adtran%') and
a.year=xxxx and
a.month=xx and
--and a.li_id ='<line_item_id>';

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------5. Handling general data mapping issue related to NA[Other]

select distinct c.nasp_id,a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,  
       b.rate_deter_value as input_data, 
       'N' ignore_flag, 
       'AT/Sales to update configuration with actual speed value and validate.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and  
a.is_vrd='N' and 
b.rate_deter_value='NA[OTHER]' and
a.year=xxxx and
a.month=xx and
--and a.li_id ='<line_item_id>';

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------6. Handling general data mapping issue related to NA[*

select distinct c.nasp_id,a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,  
       b.rate_deter_value as input_data, 
       'N' ignore_flag, 
       'Check the configuration for this line item and update with corrected values.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and  
a.is_vrd='N' and  
(b.rate_deter_value like 'NA*[%' or b.rate_deter_value like 'NA[%') and 
b.rate_deter_value <> 'NA[OTHER]' and  
b.leg_li_id not in (select distinct leg_li_id from vprice_app.legacy_spec_det where rate_deter_id='SP_ACC_SPEED' and rate_deter_value in ('155 Mbps','622 Mbps','NA[OC192]','NA[OC48]')) and 
b.rate_deter_value not like 'NA[PIP MULTIC%' and 
b.rate_deter_value not like 'NA[MANAGED SERVICE%' and 
b.rate_deter_value not like 'NA[TSP Restorations%' and 
b.rate_deter_value not like 'NA[IDE%' and 
b.rate_deter_value not like 'NA[NEWS%' and 
b.rate_deter_value not like 'NA[Wholesale%' and 
b.rate_deter_value not like 'NA[WS%' and 
b.rate_deter_value not like 'NA[Cross Connect%' and 
b.rate_deter_value not like 'NA[POP%' and
a.year=xxxx and
a.month=xx and
--and a.li_id ='<line_item_id>';

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------7. Handling PIP Node ID and city issue
--------Scenario: There are many cases when circuit ID is not present in the NOPAT data. Under these circumstances NODEID and NODECITY will not be --------populated.  Validation is currently handled only in Excel upload, but not during �Validate�.
--------User error messages to be added in these scenario:
--------�PIP Node ID missing�
--------�PIP Node City missing�
--------�PIP Node ID and Node City missing�.
  
  
select c.nasp_id,a.prod,    
       a.prod_featr,    
       a.cw_feat_item_id as cir_id,   
       b.leg_li_id,    
       b.rate_deter_id,   
       b.rate_deter_value as input_data,  
       'N' ignore_flag,  
       'TBD' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c   
where a.li_id=b.leg_li_id and a.year=xxxx and a.month=xx and a.legacy_acct_id=c.legacy_acct_id and   
a.is_vrd='N' and a.prod = 'PR_PIP_SVC' and b.rate_deter_id not in ('SP_PIP_NLOC', 
'SP_INSTALL', 
'SP_DBW', 
'SP_COUNTRY', 
'SP_PIP_CLASS_OF_SERVICE', 
'SP_DCAR', 
'SP_EF_REALTIME_CAR', 
'SP_PIP_NODE_CARR', 
'SP_PORT_SPEED', 
'SP_PORT_TYPE', 
'SP_CONTRACT_TERM') and  
a.li_id in (select distinct leg_li_id from vprice_app.legacy_spec_det where (rate_deter_id='SP_PIP_NODE_ID' and rate_deter_value='NA') or (rate_deter_id='SP_PIP_NODE_CITY' and rate_deter_value='NA'))  
order by a.li_id,b.rate_deter_id

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------8. Handle other LD issues - Invalid Country / State - need to be ICB (UI and xls mssg). 
--------Defect # 1439 - 'NA*[GMSS]','NA*[THURAYA SATFONE]','NA*[TBD]','NA*[AVANTEL]','NA*[CIS]

select distinct c.nasp_id,a.prod,   
       a.prod_featr,   
       a.cw_feat_item_id as cir_id,  
       b.leg_li_id,   
       b.rate_deter_id,  
       b.rate_deter_value as input_data, 
       'N' ignore_flag, 
       'AT/Sales to update configuration with actual speed value and validate.' USER_TXT 
from vprice_app.legacy_line_item a, vprice_app.legacy_spec_det b, vprice_app.legacy_acct c  
where a.li_id=b.leg_li_id and a.legacy_acct_id=c.legacy_acct_id and  
a.is_vrd='N' and 
a.prod = 'PR_PAM_Long_Distance_Voice' and
b.rate_deter_value like 'NA*[%' and
a.year=xxxx and
a.month=xx and
--and a.li_id ='<line_item_id>';