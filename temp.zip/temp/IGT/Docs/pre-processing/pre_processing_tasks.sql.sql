-----------------------------------------------------
--As per the frequest from Srini/Biz, the BAN F1207134 needs to be mapped to NASP 10IRON
--UPDATE VPRICE_LEGACY.LEGACY_ACCT set NASP_ID = '10IRON' WHERE BAN ='F1207134';
--UPDATE VPRICE_LEGACY.LEGACY_ACCT_NASP_GATEWAY set NASP_ID = '10IRON' WHERE legacy_acct_nasp_gateway_id=787251; 
--DELETE VPRICE_LEGACY.LEGACY_ACCT_NASP_GATEWAY WHERE legacy_acct_nasp_gateway_id=5537341;
-----------------------------------------------------
UPDATE LEGACY_DATA_PRODS SET NASP_ID='10IRON', SUB_NASP_ID='10IRON0001' WHERE BAN='F1207134' AND YEAR=2015 AND MONTH=xx;
UPDATE LEGACY_VOICE_STAGE SET SUB_NASP_ID='10IRON0001' WHERE BAN='F1207134' AND YEAR=2015 AND MONTH=xx;
UPDATE LEGACY_CONF_PRODS SET SUB_NASP_ID='10IRON0001' WHERE BAN='F1207134' AND YEAR=2015 AND MONTH=xx; 
-----------------------------------------------------
--As per request from Srini/Biz, assigning all circuits under 10ABOX to 10ETDQ
-----------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET NASP_ID='10ETDQ', SUB_NASP_ID='10ETDQ0001' WHERE NASP_ID='10ABOX' AND YEAR=:year AND MONTH=:month;
UPDATE vprice_app.LEGACY_VOICE_STAGE SET SUB_NASP_ID='10ETDQ0001' WHERE SUB_NASP_ID LIKE '10ABOX%' AND YEAR=:year AND MONTH=:month;
UPDATE vprice_app.LEGACY_CONF_PRODS SET SUB_NASP_ID='10ETDQ0001' WHERE SUB_NASP_ID LIKE '10ABOX%' AND YEAR=:year AND MONTH=:month; 
-----------------------------------------------------
--Fix COUNTRY NA issue
-----------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET SVN_CNTRY_NAME='CZE', orig_iso_cntry_id=203, RPTG_CNTRY_NAME='Czech Republic' WHERE SVN_CITY_NAME='PRAHA 5' and year=:year and month =:month;
-------------------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET SVN_CNTRY_NAME='VIR',RPTG_CNTRY_NAME='VIRGIN ISLANDS (U.S.)',ORIG_ISO_CNTRY_ID=850 
WHERE ORIG_ISO_CNTRY_ID=840 AND RPTG_CNTRY_NAME='UNITED STATES' AND SVN_TERR_CODE LIKE 'VI%' and
and year=:year and month =:month;
------------------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET ORIG_ISO_CNTRY_ID=850, RPTG_CNTRY_NAME='VIRGIN ISLANDS (U.S.)' WHERE SVN_CNTRY_NAME ='VIR' and year=:year and month =:month;
------------------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET SVN_CNTRY_NAME='SRB', RPTG_CNTRY_NAME='Serbia' WHERE ORIG_ISO_CNTRY_ID=688 and year=:year and month =:month;
------------------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET SVN_CNTRY_NAME='PRI' WHERE ORIG_ISO_CNTRY_ID=630 and year=:year and month =:month;
------------------------------------------------------------
UPDATE vprice_app.LEGACY_DATA_PRODS SET SVN_CNTRY_NAME='USA' WHERE ORIG_ISO_CNTRY_ID=840 AND RPTG_CNTRY_NAME='UNITED STATES' and year=:year and month =:month;
commit;	   