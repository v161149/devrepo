alter table LEGACY_LINE_ITEM DISABLE constraint LEGACY_LINE_ITEM_FK01;
alter table LEGACY_LINE_ITEM DISABLE constraint LEGACY_LINE_ITEM_FK02;
alter table LEGACY_ACCT_PRODUCTS DISABLE constraint LEGACY_ACCT_PRODUCTS_FK1;

alter table legacy_spec_det truncate partition Y2016_DEC;
alter table legacy_rate truncate partition Y2016_DEC;
alter table legacy_acct_products truncate subpartition Y2016_DEC;
alter table legacy_line_item truncate subpartition Y2016_DEC;

alter index pk_legacy_spec_det rebuild;
alter index pk_legacy_rate rebuild;
alter index pk_legacy_line_item rebuild;
alter index legacy_line_item_fk01 rebuild;
alter index legacy_line_item_fk02 rebuild;
alter index pk_legacy_acct_products rebuild;
alter index legacy_acct_products_fk1 rebuild;

alter table LEGACY_LINE_ITEM enable constraint LEGACY_LINE_ITEM_FK01;
alter table LEGACY_LINE_ITEM enable constraint LEGACY_LINE_ITEM_FK02;
alter table LEGACY_ACCT_PRODUCTS enable constraint LEGACY_ACCT_PRODUCTS_FK1;

delete from legacy_spec_det where leg_li_id in (select li_id from legacy_line_item where year = 1111 and month = 11 and li_id like '201612%');
delete from legacy_rate where leg_li_id in (select li_id from legacy_line_item where year = 1111 and month = 11 and li_id like '201612%');
delete from legacy_line_item where year = 1111 and month = 11 and li_id like '201612%';

delete from legacy_err_log where leg_li_id like '201612%';

commit;
