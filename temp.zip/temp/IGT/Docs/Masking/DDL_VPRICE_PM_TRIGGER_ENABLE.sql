--------------------------------------------------------
--  DDL to Enable Triggers
--------------------------------------------------------
--Execute under VPRICE_PM

alter trigger VPRICE_PM.CPB_CUSTOMER_TRGV enable;
alter trigger VPRICE_PM.CPB_SOF_TRGV enable;
alter trigger VPRICE_PM.CPB_CUSTOMER_HISTORY_TRGV enable;
alter trigger VPRICE_PM.CPB_SOF_HISTORY_TRGV enable;

