-- Execute under VPRICE_SECURITY
--/*---------
--1. Tested on : 7/1/2014 
--2. Tested against : DANA 
--3. Purpose of the script : Mask sensitive data
--4. Anticipated Rows generated / affected: 3 rows
--5. Table / Data Size : 1 table with 25 rows
--6. Anticipated Duration : about 1 min
--7. Test by : Tim M.
--8. Deployment notes : 
--9. Post Production test notes : Successful execution indicating data updates
--10. Additional Comments if any : 
-----------*/

SET TIMING ON;
SET FEEDBACK ON;

spool VPRICE_SECURITY_MASK_COLUMNS.log;

select to_char(sysdate,'dd-MON-rrrr hh24:mi:ss') as "Start Time" from dual;

update VPRICE_SECURITY.EREF_DATA
   set CUSTOMER_NAME = vprice_security.PK_DATA_MASKING.f_mask2(CUSTOMER_NAME)
 where CUSTOMER_NAME   is not null
; 


commit;

select to_char(sysdate,'dd-MON-rrrr hh24:mi:ss') as "End Time" from dual;

spool off;
