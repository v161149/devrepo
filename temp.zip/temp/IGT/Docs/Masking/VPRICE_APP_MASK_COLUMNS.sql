-- Execute under VPRICE_APP
--/*---------
--1. Tested on : 7/1/2014 
--2. Tested against : DANA 
--3. Purpose of the script : Mask sensitive data
--4. Anticipated Rows generated / affected: 1,500,000 rows
--5. Table / Data Size approx: 
--   VPRICE_APP.ALL_NASP_BMPR  Table size: 204,307  Rows to update: 1
--   VPRICE_APP.PAS_REF_ALL_NASP  Table size: 314,802  Rows to update: 306,652
--   VPRICE_APP.TRN_CU_CONTRACT  Table size: 15,195  Rows to update: 15,195
--   VPRICE_APP.TRN_CU_SOF  Table size: 16,621  Rows to update: 16,615
--   VPRICE_APP.VPE_RFP_LI  Table size: 6,542,525  Rows to update: 31,143
--   VPRICE_APP.VPE_RTB_CLEVLE_CURR  Table size: 252  Rows to update: 252
--   VPRICE_APP.VPE_SITE  Table size: 785,637  Rows to update: 785,637
--6. Anticipated Duration : about 45 mins
--7. Test by : Tim M.
--8. Deployment notes : 
--9. Post Production test notes : Successful execution indicating data updates
--10. Additional Comments if any : 
-----------*/

SET TIMING ON;
SET FEEDBACK ON;

spool VPRICE_APP_MASK_COLUMNS.log;

select to_char(sysdate,'dd-MON-rrrr hh24:mi:ss') as "Start Time" from dual;

update VPRICE_APP.ALL_NASP_BMPR 
   set DUNS_NAME    =  vprice_app.PK_DATA_MASKING.f_mask2(DUNS_NAME),
       GU_DUNS_NAME =  vprice_app.PK_DATA_MASKING.f_mask2(GU_DUNS_NAME),
       NASP_NAME    =  vprice_app.PK_DATA_MASKING.f_mask2(NASP_NAME)
 where DUNS_NAME    is not null
    or GU_DUNS_NAME is not null
    or NASP_NAME    is not null 
;


update VPRICE_APP.PAS_REF_ALL_NASP
   set DUNS_NAME    =  vprice_app.PK_DATA_MASKING.f_mask2(DUNS_NAME),
       GU_DUNS_NAME =  vprice_app.PK_DATA_MASKING.f_mask2(GU_DUNS_NAME),
       NASP_NAME    =  vprice_app.PK_DATA_MASKING.f_mask2(NASP_NAME)
 where DUNS_NAME    is not null
    or GU_DUNS_NAME is not null
    or NASP_NAME    is not null 
; 


update VPRICE_APP.TRN_CU_CONTRACT
   set CUST_LEGAL_ENTITY = vprice_app.PK_DATA_MASKING.f_mask2(CUST_LEGAL_ENTITY)
 where CUST_LEGAL_ENTITY   is not null
; 


update VPRICE_APP.TRN_CU_SOF
   set CUST_LEGAL_ENT = vprice_app.PK_DATA_MASKING.f_mask2(CUST_LEGAL_ENT)
 where CUST_LEGAL_ENT   is not null
; 


update VPRICE_APP.VPE_RFP_LI
   set OVERRIDE_CLE_NAME = vprice_app.PK_DATA_MASKING.f_mask2(OVERRIDE_CLE_NAME)
 where OVERRIDE_CLE_NAME   is not null
; 


update VPRICE_APP.VPE_RTB_CLEVLE_CURR
   set CLE_NAME = vprice_app.PK_DATA_MASKING.f_mask2(CLE_NAME)
 where CLE_NAME   is not null
; 


update VPRICE_APP.VPE_SITE
   set SITE_ADDR1 = vprice_app.PK_DATA_MASKING.f_mask2(SITE_ADDR1),
       SITE_ADDR2 = vprice_app.PK_DATA_MASKING.f_mask2(SITE_ADDR2)
; 

update  VPRICE_APP.ALL_NASP_BMPR_BACKUP
   set DUNS_NAME =     vprice_dealdesk.PK_DATA_MASKING.f_mask2(DUNS_NAME),
       GU_DUNS_NAME =  vprice_dealdesk.PK_DATA_MASKING.f_mask2(GU_DUNS_NAME),
       NASP_NAME =     vprice_dealdesk.PK_DATA_MASKING.f_mask2(NASP_NAME)
 where DUNS_NAME    is not null
    or GU_DUNS_NAME is not null
    or NASP_NAME    is not null 
; 


update  VPRICE_APP.LOAD_ALL_NASP
   set DUNS_NAME =     vprice_dealdesk.PK_DATA_MASKING.f_mask2(DUNS_NAME),
       GU_DUNS_NAME =  vprice_dealdesk.PK_DATA_MASKING.f_mask2(GU_DUNS_NAME),
       NASP_NAME =     vprice_dealdesk.PK_DATA_MASKING.f_mask2(NASP_NAME)
 where DUNS_NAME    is not null
    or GU_DUNS_NAME is not null
    or NASP_NAME    is not null 
; 

commit;

select to_char(sysdate,'dd-MON-rrrr hh24:mi:ss') as "End Time" from dual;

spool off;
