set timing on
set echo on

update legacy_site set
  site_addr1 = pk_data_masking.f_mask2(site_addr1),
  site_addr2 = pk_data_masking.f_mask2(site_addr2),
  city = pk_data_masking.f_mask2(city),
  terr_code = pk_data_masking.f_mask2(terr_code),
  post_cde = pk_data_masking.f_mask2(post_cde),
  cntry_name = pk_data_masking.f_mask2(cntry_name);

commit;

update legacy_acct_nasp_gateway set
  gateway_id = pk_data_masking.f_mask2(gateway_id),
  gw_name = pk_data_masking.f_mask2(gw_name);

commit;

update /*+ parallel(degree 8) */ legacy_line_item set
  site = pk_data_masking.f_mask2(site);

commit;


  