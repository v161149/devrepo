--------------------------------------------------------
--  DDL to Disable Triggers
--------------------------------------------------------
--Execute under VPRICE_PM

alter trigger VPRICE_PM.CPB_CUSTOMER_TRGV disable;
alter trigger VPRICE_PM.CPB_SOF_TRGV disable;
alter trigger VPRICE_PM.CPB_CUSTOMER_HISTORY_TRGV disable;
alter trigger VPRICE_PM.CPB_SOF_HISTORY_TRGV disable;

