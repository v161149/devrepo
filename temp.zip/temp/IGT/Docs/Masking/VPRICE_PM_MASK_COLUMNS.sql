-- Execute under VPRICE_PM
--/*---------
--1. Tested on : 7/1/2014 
--2. Tested against : DANA 
--3. Purpose of the script : Mask sensitive data
--4. Anticipated Rows generated / affected: 25,000 rows
--5. Table / Data Size approx: 
--   VPRICE_PM.CPB_CUSTOMER   Table size: 3443  Rows to update: 3443
--   VPRICE_PM.CPB_CUSTOMER_HISTORY  Table size: 358  Rows to update: 358
--   VPRICE_PM.CPB_LEGAL_ENTITY  Table size: 22  Rows to update: 22
--   VPRICE_PM.CPB_SOF  Table size: 20955  Rows to update: 20955
--   VPRICE_PM.CPB_SOF_HISTORY  Table size: 4  Rows to update: 4
--6. Anticipated Duration : about 5 mins
--7. Test by : Tim M.
--8. Deployment notes : 
--9. Post Production test notes : Successful execution indicating data updates
--10. Additional Comments if any : 
-----------*/

SET TIMING ON;
SET FEEDBACK ON;

spool VPRICE_PM_MASK_COLUMNS.log;

select to_char(sysdate,'dd-MON-rrrr hh24:mi:ss') as "Start Time" from dual;

update VPRICE_PM.CPB_CUSTOMER 
   set CUSTOMER_NAME = vprice_pm.PK_DATA_MASKING.f_mask2(CUSTOMER_NAME)
 where CUSTOMER_NAME   is not null
;


update VPRICE_PM.CPB_CUSTOMER_HISTORY
   set CUSTOMER_NAME = vprice_pm.PK_DATA_MASKING.f_mask2(CUSTOMER_NAME)
 where CUSTOMER_NAME   is not null
; 


update VPRICE_PM.CPB_LEGAL_ENTITY
   set CLE_NAME = vprice_pm.PK_DATA_MASKING.f_mask2(CLE_NAME)
 where CLE_NAME   is not null
; 


update VPRICE_PM.CPB_SOF
   set CUSTOMER_NAME = vprice_pm.PK_DATA_MASKING.f_mask2(CUSTOMER_NAME)
 where CUSTOMER_NAME   is not null
; 


update VPRICE_PM.CPB_SOF_HISTORY
   set CUSTOMER_NAME = vprice_pm.PK_DATA_MASKING.f_mask2(CUSTOMER_NAME)
 where CUSTOMER_NAME   is not null
; 


commit;

select to_char(sysdate,'dd-MON-rrrr hh24:mi:ss') as "End Time" from dual;

spool off;
