"""
Test script for the MCP Client API
"""
import requests
import json
import sys

# API endpoint
API_URL = "http://localhost:8000"

def test_health_check():
    """Test the health check endpoint"""
    print("Testing health check endpoint...")
    try:
        response = requests.get(f"{API_URL}/health")
        response.raise_for_status()
        print("✓ Health check passed")
        print(json.dumps(response.json(), indent=2))
        return True
    except Exception as e:
        print(f"✗ Health check failed: {e}")
        return False

def test_enrich_schema():
    """Test the schema enrichment endpoint"""
    print("\nTesting schema enrichment endpoint...")
    
    # Test data
    test_request = {
        "request_id": "89299b82-95f7-412f-b413-44754cf53b21",
        "database_name": "inventory_db",
        "tables": [
            {
                "table_name": "users",
                "columns": [
                    {"column_name": "user_id"},
                    {"column_name": "username"},
                    {"column_name": "email"},
                    {"column_name": "created_at"}
                ]
            },
            {
                "table_name": "products",
                "columns": [
                    {"column_name": "product_id"},
                    {"column_name": "product_name"},
                    {"column_name": "price"},
                    {"column_name": "stock_quantity"}
                ]
            }
        ]
    }
    
    try:
        response = requests.post(
            f"{API_URL}/enrich-schema",
            json=test_request,
            headers={"Content-Type": "application/json"}
        )
        response.raise_for_status()
        
        print("✓ Schema enrichment successful")
        result = response.json()
        
        # Print formatted response
        print("\nEnriched Schema:")
        print("=" * 80)
        print(json.dumps(result, indent=2))
        print("=" * 80)
        
        # Validate response structure
        assert "request_id" in result
        assert "database_name" in result
        assert "business_name" in result
        assert "business_description" in result
        assert "tables" in result
        
        for table in result["tables"]:
            assert "table_name" in table
            assert "business_name" in table
            assert "business_description" in table
            assert "columns" in table
            
            for column in table["columns"]:
                assert "column_name" in column
                assert "business_name" in column
                assert "business_description" in column
                assert "classification" in column
        
        print("\n✓ Response structure validation passed")
        return True
        
    except requests.exceptions.HTTPError as e:
        print(f"✗ HTTP Error: {e}")
        if hasattr(e.response, 'text'):
            print(f"Response: {e.response.text}")
        return False
    except Exception as e:
        print(f"✗ Schema enrichment failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 80)
    print("MCP Client API Test Suite")
    print("=" * 80)
    
    # Check if services are running
    try:
        requests.get(API_URL, timeout=2)
    except requests.exceptions.RequestException:
        print(f"\n✗ Cannot connect to API at {API_URL}")
        print("Please ensure the MCP Client service is running on port 8000")
        sys.exit(1)
    
    # Run tests
    results = []
    results.append(("Health Check", test_health_check()))
    results.append(("Schema Enrichment", test_enrich_schema()))
    
    # Summary
    print("\n" + "=" * 80)
    print("Test Summary")
    print("=" * 80)
    
    for test_name, passed in results:
        status = "✓ PASSED" if passed else "✗ FAILED"
        print(f"{test_name}: {status}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n🎉 All tests passed!")
        sys.exit(0)
    else:
        print("\n❌ Some tests failed")
        sys.exit(1)

if __name__ == "__main__":
    main()