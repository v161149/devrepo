const SERVICE_TYPES = [
  {
    category: 'Web & Application Servers',
    types: [
      { id: 'web_server', name: 'Web Server', fields: ['url', 'status_endpoint'] },
      { id: 'application', name: 'Application', fields: ['url', 'health_endpoint'] },
      { id: 'api_gateway', name: 'API Gateway', fields: ['url', 'api_key', 'health_endpoint'] },
      { id: 'microservice', name: 'Microservice', fields: ['url', 'health_endpoint', 'authentication_type'] },
      { id: 'nginx', name: 'NGINX', fields: ['url', 'status_endpoint'] },
      { id: 'apache', name: 'Apache', fields: ['url', 'status_endpoint'] },
    ]
  },
  {
    category: 'Data Management',
    types: [
      { id: 'mysql', name: 'MySQL Database', fields: ['host', 'port', 'database', 'username', 'password'] },
      { id: 'postgresql', name: 'PostgreSQL Database', fields: ['host', 'port', 'database', 'username', 'password'] },
      { id: 'mongodb', name: 'MongoDB Database', fields: ['host', 'port', 'database', 'username', 'password'] },
      { id: 'oracle', name: 'Oracle Database', fields: ['host', 'port', 'service_name', 'username', 'password'] },
      { id: 'mssql', name: 'Microsoft SQL Server', fields: ['host', 'port', 'database', 'username', 'password'] },
      { id: 'db2', name: 'IBM DB2', fields: ['host', 'port', 'database', 'username', 'password'] },
      { id: 'aurora', name: 'AWS Aurora', fields: ['endpoint', 'port', 'database', 'username', 'password'] },
      { id: 'snowflake', name: 'Snowflake', fields: ['account', 'warehouse', 'database', 'username', 'password'] },
      { id: 'bigquery', name: 'BigQuery', fields: ['project_id', 'dataset', 'credentials_json'] },
    ]
  },
  {
    category: 'Application & Integration',
    types: [
      { id: 'esb', name: 'Enterprise Service Bus', fields: ['url', 'username', 'password'] },
    ]
  },
  {
    category: 'Data Processing',
    types: [
      { id: 'etl_batch', name: 'ETL Batch Job', fields: ['job_name', 'schedule', 'endpoint', 'api_key'] },
      { id: 'spark_streaming', name: 'Spark Streaming', fields: ['master_url', 'application_id', 'monitoring_port'] },
      { id: 'flink', name: 'Apache Flink', fields: ['jobmanager_url', 'job_id', 'api_port'] },
    ]
  },
  {
    category: 'Messaging Systems',
    types: [
      { id: 'kafka', name: 'Kafka', fields: ['bootstrap_servers', 'topic', 'consumer_group'] },
      { id: 'ibm_mq', name: 'IBM MQ', fields: ['host', 'port', 'queue_manager', 'channel', 'username', 'password'] },
      { id: 'rabbitmq', name: 'RabbitMQ', fields: ['host', 'port', 'vhost', 'username', 'password'] },
      { id: 'aws_sqs', name: 'AWS SQS', fields: ['queue_url', 'region', 'access_key', 'secret_key'] },
    ]
  }
];

export default SERVICE_TYPES;
