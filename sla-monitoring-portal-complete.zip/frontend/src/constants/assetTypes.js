/**
 * Asset Type Constants
 * Defines all supported application/asset types in the SLA Portal
 */

export const ASSET_TYPES = [
  { id: 'web_server', name: 'Web Server', icon: '🌐' },
  { id: 'database', name: 'Database', icon: '🗄️' },
  { id: 'application', name: 'Application', icon: '📱' },
  { id: 'application_server', name: 'Application Server', icon: '🖥️' },
  { id: 'application_service', name: 'Application Service', icon: '⚙️' },
  { id: 'api', name: 'API Service', icon: '🔌' },
  { id: 'message_queue', name: 'Message Queue', icon: '📬' },
  { id: 'cache', name: 'Cache Service', icon: '💾' },
  { id: 'storage', name: 'Storage Service', icon: '📦' },
  { id: 'other', name: 'Other', icon: '📋' }
];

export const getAssetTypeName = (id) => {
  const type = ASSET_TYPES.find(t => t.id === id);
  return type ? type.name : id;
};

export const getAssetTypeIcon = (id) => {
  const type = ASSET_TYPES.find(t => t.id === id);
  return type ? type.icon : '📋';
};
