/**
 * SLA Type Constants
 * Defines all supported SLA metric types in the SLA Portal
 * Updated to include 20 comprehensive SLA types
 */

export const SLA_TYPES = [
  // Original Types
  { 
    id: 'response_time', 
    name: 'Response Time',
    description: 'Time taken to respond to a request',
    category: 'performance',
    unit: 'seconds'
  },
  { 
    id: 'resolution_time', 
    name: 'Resolution Time',
    description: 'Time taken to fully resolve an incident',
    category: 'support',
    unit: 'hours'
  },
  { 
    id: 'uptime', 
    name: 'Uptime',
    description: 'Percentage of time service is operational',
    category: 'availability',
    unit: 'percentage'
  },
  { 
    id: 'success_rate', 
    name: 'Success Rate',
    description: 'Ratio of successful operations to total requests',
    category: 'reliability',
    unit: 'percentage'
  },
  { 
    id: 'throughput', 
    name: 'Throughput',
    description: 'Number of operations processed per unit time',
    category: 'performance',
    unit: 'ops/sec'
  },
  { 
    id: 'error_rate', 
    name: 'Error Rate',
    description: 'Percentage of failed requests or system errors',
    category: 'reliability',
    unit: 'percentage'
  },
  { 
    id: 'execution_window', 
    name: 'Execution Window',
    description: 'Scheduled time window for job execution',
    category: 'scheduling',
    unit: 'time'
  },
  
  // New Enhanced Types
  { 
    id: 'cpu_usage', 
    name: 'CPU Usage',
    description: 'Processor utilization threshold monitoring',
    category: 'resource',
    unit: 'percentage'
  },
  { 
    id: 'memory_usage', 
    name: 'Memory Usage',
    description: 'RAM consumption monitoring',
    category: 'resource',
    unit: 'percentage'
  },
  { 
    id: 'on_schedule', 
    name: 'On-Schedule',
    description: 'Adherence to promised timelines for batch jobs',
    category: 'scheduling',
    unit: 'boolean'
  },
  { 
    id: 'response_time_support', 
    name: 'Response Time (Support)',
    description: 'Time for support agent to acknowledge an issue',
    category: 'support',
    unit: 'minutes'
  },
  { 
    id: 'mttr', 
    name: 'Mean Time to Repair (MTTR)',
    description: 'Average time to fix a system after failure',
    category: 'support',
    unit: 'hours'
  },
  { 
    id: 'rto', 
    name: 'Recovery Time Objective (RTO)',
    description: 'Maximum acceptable service downtime after disaster',
    category: 'availability',
    unit: 'hours'
  },
  { 
    id: 'fcr', 
    name: 'First Contact Resolution (FCR)',
    description: 'Percentage of tickets resolved in first interaction',
    category: 'support',
    unit: 'percentage'
  },
  { 
    id: 'api_response_time', 
    name: 'API Response Time',
    description: 'Performance targets for API endpoints',
    category: 'performance',
    unit: 'milliseconds'
  },
  { 
    id: 'page_load_time', 
    name: 'Page Load Time',
    description: 'Time for web interface to become interactive',
    category: 'performance',
    unit: 'seconds'
  },
  { 
    id: 'iops', 
    name: 'IOPS (Input/Output Operations)',
    description: 'Guaranteed storage performance levels',
    category: 'resource',
    unit: 'ops/sec'
  },
  { 
    id: 'database_query_latency', 
    name: 'Database Query Latency',
    description: 'Time to execute and return database queries',
    category: 'performance',
    unit: 'milliseconds'
  },
  { 
    id: 'security_compliance', 
    name: 'Security & Compliance',
    description: 'Time-to-patch for vulnerabilities',
    category: 'security',
    unit: 'hours'
  },
  { 
    id: 'csat', 
    name: 'Customer Satisfaction (CSAT)',
    description: 'Target score based on user feedback',
    category: 'quality',
    unit: 'score'
  },
  { 
    id: 'custom', 
    name: 'Custom',
    description: 'Custom-defined SLA metric',
    category: 'custom',
    unit: 'custom'
  }
];

export const SLA_CATEGORIES = [
  { id: 'performance', name: 'Performance', color: 'blue' },
  { id: 'availability', name: 'Availability', color: 'green' },
  { id: 'reliability', name: 'Reliability', color: 'yellow' },
  { id: 'support', name: 'Support', color: 'purple' },
  { id: 'resource', name: 'Resource', color: 'orange' },
  { id: 'scheduling', name: 'Scheduling', color: 'teal' },
  { id: 'security', name: 'Security', color: 'red' },
  { id: 'quality', name: 'Quality', color: 'pink' },
  { id: 'custom', name: 'Custom', color: 'gray' }
];

export const getSLATypeName = (id) => {
  const type = SLA_TYPES.find(t => t.id === id);
  return type ? type.name : id;
};

export const getSLATypeDescription = (id) => {
  const type = SLA_TYPES.find(t => t.id === id);
  return type ? type.description : '';
};

export const getSLATypeCategory = (id) => {
  const type = SLA_TYPES.find(t => t.id === id);
  return type ? type.category : 'custom';
};

export const getSLATypesByCategory = (category) => {
  return SLA_TYPES.filter(t => t.category === category);
};
