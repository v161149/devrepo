/**
 * Log Server Setup Page
 * Manage centralized log server connections for monitoring
 * Services and jobs reference these connectors for log-based SLA monitoring
 */

import React, { useState, useEffect } from 'react';
import { 
  FiPlus, 
  FiRefreshCw, 
  FiCheckCircle, 
  FiXCircle, 
  FiAlertCircle,
  FiServer,
  FiEdit,
  FiTrash2,
  FiActivity,
  FiDatabase
} from 'react-icons/fi';
import Button from '../../components/Button';
import Card from '../../components/Card';
import AddLogConnectorModal from '../../components/AddLogConnectorModal';

const LogServerSetup = () => {
  const [connectors, setConnectors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [testingConnector, setTestingConnector] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingConnector, setEditingConnector] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  useEffect(() => {
    fetchConnectors();
  }, []);

  const fetchConnectors = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setConnectors(data.data || []);
      }
    } catch (error) {
      console.error('Error fetching log connectors:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (connector) => {
    setEditingConnector(connector);
    setShowEditModal(true);
  };

  const handleEditSuccess = () => {
    setShowEditModal(false);
    setEditingConnector(null);
    fetchConnectors();
  };

  const handleDelete = async (connector) => {
    const confirmMessage = `Are you sure you want to delete "${connector.connector_name}"?\n\nThis will affect all services and jobs using this connector.\n\nThis action cannot be undone.`;
    
    if (!window.confirm(confirmMessage)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/log-connectors/${connector.connector_id}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.ok) {
        alert(`✓ Log server connector "${connector.connector_name}" deleted successfully`);
        fetchConnectors();
      } else {
        const error = await response.json();
        alert(`✗ Failed to delete connector: ${error.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error deleting connector:', error);
      alert(`✗ Error deleting connector: ${error.message}`);
    }
  };

  const testConnection = async (connectorId) => {
    try {
      setTestingConnector(connectorId);
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/log-connectors/${connectorId}/test`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      const data = await response.json();
      
      if (data.success) {
        alert(`✓ Connection successful: ${data.connector_name}\n\n${data.message || 'Connection verified'}`);
        fetchConnectors(); // Refresh to update last_test_status
      } else {
        alert(`✗ Connection failed: ${data.connector_name}\n\n${data.message || 'Unknown error'}`);
      }
    } catch (error) {
      alert(`Error testing connection: ${error.message}`);
    } finally {
      setTestingConnector(null);
    }
  };

  const getConnectorIcon = (type) => {
    const iconClass = "text-2xl";
    switch(type) {
      case 'splunk':
        return <FiServer className={`${iconClass} text-orange-500`} />;
      case 'elk':
        return <FiDatabase className={`${iconClass} text-teal-500`} />;
      case 'cloudwatch':
        return <FiActivity className={`${iconClass} text-yellow-600`} />;
      case 'stackdriver':
        return <FiActivity className={`${iconClass} text-blue-500`} />;
      case 'datadog_logs':
        return <FiActivity className={`${iconClass} text-purple-600`} />;
      case 'azure_monitor':
        return <FiActivity className={`${iconClass} text-sky-500`} />;
      case 'custom':
        return <FiServer className={`${iconClass} text-gray-500`} />;
      default:
        return <FiServer className={`${iconClass} text-gray-500`} />;
    }
  };

  const getConnectorTypeName = (type) => {
    const typeMap = {
      'splunk': 'Splunk',
      'elk': 'ELK Stack',
      'cloudwatch': 'AWS CloudWatch',
      'stackdriver': 'Google Cloud Logging',
      'datadog_logs': 'Datadog Logs',
      'azure_monitor': 'Azure Monitor',
      'custom': 'Custom API'
    };
    return typeMap[type] || type;
  };

  const getStatusBadge = (connector) => {
    if (!connector.is_active) {
      return (
        <span className="px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
          Inactive
        </span>
      );
    }

    if (connector.last_test_status === 'success') {
      return (
        <span className="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
          ✓ Active
        </span>
      );
    } else if (connector.last_test_status === 'failed') {
      return (
        <span className="px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">
          ✗ Failed
        </span>
      );
    } else {
      return (
        <span className="px-2 py-1 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
          Not Tested
        </span>
      );
    }
  };

  const formatLastTestTime = (timestamp) => {
    if (!timestamp) return 'Never';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
  };

  // Calculate statistics
  const stats = {
    total: connectors.length,
    active: connectors.filter(c => c.is_active).length,
    tested: connectors.filter(c => c.last_test_status === 'success' && c.is_active).length
  };

  const activeConnectors = connectors.filter(c => c.is_active);
  const inactiveConnectors = connectors.filter(c => !c.is_active);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <p className="text-gray-600 mt-1">
            Manage centralized log server connections for monitoring
          </p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={fetchConnectors}
            icon={FiRefreshCw}
          >
            Refresh
          </Button>
          <Button
            onClick={() => setShowAddModal(true)}
            icon={FiPlus}
          >
            Add Connector
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-600 font-medium">Total Connectors</p>
              <p className="text-3xl font-bold text-blue-900">{stats.total}</p>
            </div>
            <FiDatabase className="text-4xl text-blue-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-600 font-medium">Active Connectors</p>
              <p className="text-3xl font-bold text-green-900">{stats.active}</p>
            </div>
            <FiCheckCircle className="text-4xl text-green-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-600 font-medium">Test Passed</p>
              <p className="text-3xl font-bold text-purple-900">{stats.tested}</p>
            </div>
            <FiActivity className="text-4xl text-purple-600 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Active Connectors */}
      {activeConnectors.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Active Connectors ({activeConnectors.length})
          </h2>
          <div className="space-y-4">
            {activeConnectors.map(connector => (
              <Card key={connector.connector_id} className="hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="mt-1">
                      {getConnectorIcon(connector.log_server_type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {connector.connector_name}
                        </h3>
                        {getStatusBadge(connector)}
                      </div>
                      
                      <div className="space-y-1 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Type:</span>
                          <span>{getConnectorTypeName(connector.log_server_type)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">URL:</span>
                          <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                            {connector.api_endpoint_url}
                          </span>
                        </div>
                        {connector.connector_description && (
                          <div className="flex items-start gap-2">
                            <span className="font-medium">Description:</span>
                            <span className="text-gray-500">{connector.connector_description}</span>
                          </div>
                        )}
                      </div>

                      <div className="mt-3 flex items-center gap-4 text-xs text-gray-500">
                        {connector.last_test_time && (
                          <div className="flex items-center gap-1">
                            <span>Last Test:</span>
                            <span className="font-medium">
                              {formatLastTestTime(connector.last_test_time)}
                            </span>
                            {connector.last_test_status === 'success' && (
                              <FiCheckCircle className="text-green-500 ml-1" />
                            )}
                            {connector.last_test_status === 'failed' && (
                              <FiXCircle className="text-red-500 ml-1" />
                            )}
                          </div>
                        )}
                        {connector.last_test_message && connector.last_test_status === 'failed' && (
                          <div className="text-red-600">
                            {connector.last_test_message}
                          </div>
                        )}
                      </div>

                      {/* Usage Statistics (placeholder - would be populated from DB) */}
                      <div className="mt-2 text-xs text-gray-500">
                        <span className="font-medium">Used by:</span> 
                        <span className="ml-1">Services & Jobs using this connector</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      icon={FiActivity}
                      onClick={() => testConnection(connector.connector_id)}
                      disabled={testingConnector === connector.connector_id}
                      title="Test connection"
                    >
                      {testingConnector === connector.connector_id ? 'Testing...' : 'Test'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      icon={FiEdit}
                      onClick={() => handleEdit(connector)}
                      title="Edit connector"
                    >
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      icon={FiTrash2}
                      onClick={() => handleDelete(connector)}
                      title="Delete connector"
                      className="text-red-600 hover:text-red-700 hover:border-red-300"
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Inactive Connectors */}
      {inactiveConnectors.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Inactive Connectors ({inactiveConnectors.length})
          </h2>
          <div className="space-y-4">
            {inactiveConnectors.map(connector => (
              <Card key={connector.connector_id} className="bg-gray-50 opacity-75">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="mt-1 opacity-50">
                      {getConnectorIcon(connector.log_server_type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-700">
                          {connector.connector_name}
                        </h3>
                        {getStatusBadge(connector)}
                      </div>
                      
                      <div className="space-y-1 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Type:</span>
                          <span>{getConnectorTypeName(connector.log_server_type)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">URL:</span>
                          <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                            {connector.api_endpoint_url}
                          </span>
                        </div>
                      </div>

                      {connector.last_test_time && (
                        <div className="mt-3 text-xs text-gray-500">
                          Last Test: {formatLastTestTime(connector.last_test_time)}
                          {connector.last_test_message && connector.last_test_status === 'failed' && (
                            <span className="ml-2 text-red-600">
                              - {connector.last_test_message}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      icon={FiActivity}
                      onClick={() => testConnection(connector.connector_id)}
                      disabled={testingConnector === connector.connector_id}
                    >
                      {testingConnector === connector.connector_id ? 'Testing...' : 'Test'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      icon={FiEdit}
                      onClick={() => handleEdit(connector)}
                    >
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      icon={FiTrash2}
                      onClick={() => handleDelete(connector)}
                      className="text-red-600 hover:text-red-700 hover:border-red-300"
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {connectors.length === 0 && (
        <Card className="bg-gray-50 border-2 border-dashed border-gray-300">
          <div className="text-center py-12">
            <FiServer className="mx-auto text-6xl text-gray-400 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              No Log Server Connectors
            </h3>
            <p className="text-gray-600 mb-6">
              Configure your first log server connection to start monitoring services and jobs
            </p>
            <Button onClick={() => setShowAddModal(true)} icon={FiPlus}>
              Add First Connector
            </Button>
          </div>
        </Card>
      )}

      {/* Add Connector Modal */}
      {showAddModal && (
        <AddLogConnectorModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            fetchConnectors();
          }}
        />
      )}

      {/* Edit Connector Modal */}
      {showEditModal && editingConnector && (
        <AddLogConnectorModal
          connector={editingConnector}
          onClose={() => {
            setShowEditModal(false);
            setEditingConnector(null);
          }}
          onSuccess={handleEditSuccess}
        />
      )}

      {/* Quick Start Guide */}
      <Card className="bg-blue-50 border-blue-200">
        <div className="flex items-start gap-4">
          <FiAlertCircle className="text-2xl text-blue-600 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">Quick Start Guide</h4>
            <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800">
              <li>Click "Add Connector" to configure a new log server connection</li>
              <li>Choose log server type (Splunk, ELK, CloudWatch, etc.)</li>
              <li>Enter connection details (URL, credentials, configuration)</li>
              <li>Test the connection to verify it works</li>
              <li>Save the connector - it's now available for services and jobs</li>
              <li>When creating services/jobs, select this connector from the dropdown</li>
              <li>Monitor daemons will use this configuration to query logs</li>
            </ol>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default LogServerSetup;
