/**
 * Integration Health Page
 * Monitor health and status of all external integrations
 */

import React, { useState, useEffect } from 'react';
import { 
  FiCheckCircle, 
  FiXCircle, 
  FiAlertCircle,
  FiRefreshCw,
  FiActivity,
  FiClock,
  FiTrendingUp,
  FiBarChart2
} from 'react-icons/fi';
import Button from '../../components/Button';
import Card from '../../components/Card';

const IntegrationHealth = () => {
  const [connectors, setConnectors] = useState([]);
  const [healthStatus, setHealthStatus] = useState({});
  const [loading, setLoading] = useState(true);
  const [testing, setTesting] = useState({});

  useEffect(() => {
    fetchIntegrationHealth();
    
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchIntegrationHealth, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchIntegrationHealth = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      // Fetch all connectors
      const response = await fetch('http://localhost:5000/api/v1/connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setConnectors(data.connectors || []);
        
        // Test each active connector
        const healthResults = {};
        for (const connector of data.connectors.filter(c => c.is_active)) {
          healthResults[connector.id] = {
            status: 'testing',
            lastChecked: new Date().toISOString()
          };
        }
        setHealthStatus(healthResults);
        
        // Test connections in background
        testAllConnections(data.connectors.filter(c => c.is_active));
      }
    } catch (error) {
      console.error('Error fetching integration health:', error);
    } finally {
      setLoading(false);
    }
  };

  const testAllConnections = async (activeConnectors) => {
    const token = localStorage.getItem('token');
    
    for (const connector of activeConnectors) {
      try {
        const response = await fetch(
          `http://localhost:5000/api/v1/connectors/${connector.id}/test`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            }
          }
        );
        
        const data = await response.json();
        
        setHealthStatus(prev => ({
          ...prev,
          [connector.id]: {
            status: data.success ? 'healthy' : 'unhealthy',
            lastChecked: new Date().toISOString(),
            message: data.message
          }
        }));
      } catch (error) {
        setHealthStatus(prev => ({
          ...prev,
          [connector.id]: {
            status: 'error',
            lastChecked: new Date().toISOString(),
            message: error.message
          }
        }));
      }
    }
  };

  const testSingleConnection = async (connectorId) => {
    setTesting(prev => ({ ...prev, [connectorId]: true }));
    
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}/test`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      const data = await response.json();
      
      setHealthStatus(prev => ({
        ...prev,
        [connectorId]: {
          status: data.success ? 'healthy' : 'unhealthy',
          lastChecked: new Date().toISOString(),
          message: data.message
        }
      }));
    } catch (error) {
      setHealthStatus(prev => ({
        ...prev,
        [connectorId]: {
          status: 'error',
          lastChecked: new Date().toISOString(),
          message: error.message
        }
      }));
    } finally {
      setTesting(prev => ({ ...prev, [connectorId]: false }));
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'healthy':
        return <FiCheckCircle className="text-2xl text-green-500" />;
      case 'unhealthy':
        return <FiXCircle className="text-2xl text-red-500" />;
      case 'testing':
        return <FiRefreshCw className="text-2xl text-blue-500 animate-spin" />;
      default:
        return <FiAlertCircle className="text-2xl text-yellow-500" />;
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      healthy: 'bg-green-100 text-green-800',
      unhealthy: 'bg-red-100 text-red-800',
      testing: 'bg-blue-100 text-blue-800',
      error: 'bg-yellow-100 text-yellow-800'
    };
    
    const labels = {
      healthy: 'Healthy',
      unhealthy: 'Unhealthy',
      testing: 'Testing...',
      error: 'Error'
    };
    
    return (
      <span className={`px-3 py-1 rounded-full text-sm font-medium ${styles[status] || styles.error}`}>
        {labels[status] || 'Unknown'}
      </span>
    );
  };

  const healthyCount = Object.values(healthStatus).filter(h => h.status === 'healthy').length;
  const unhealthyCount = Object.values(healthStatus).filter(h => h.status === 'unhealthy' || h.status === 'error').length;
  const activeCount = connectors.filter(c => c.is_active).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <p className="text-gray-600 mt-2">
            Monitor connectivity and health of all external integrations
          </p>
        </div>
        <Button
          onClick={fetchIntegrationHealth}
          icon={FiRefreshCw}
          disabled={loading}
        >
          Refresh All
        </Button>
      </div>

      {/* Health Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-600 font-medium">Total Integrations</p>
              <p className="text-3xl font-bold text-blue-900">{activeCount}</p>
            </div>
            <FiActivity className="text-4xl text-blue-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-600 font-medium">Healthy</p>
              <p className="text-3xl font-bold text-green-900">{healthyCount}</p>
            </div>
            <FiCheckCircle className="text-4xl text-green-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-red-600 font-medium">Unhealthy</p>
              <p className="text-3xl font-bold text-red-900">{unhealthyCount}</p>
            </div>
            <FiXCircle className="text-4xl text-red-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-600 font-medium">Uptime</p>
              <p className="text-3xl font-bold text-purple-900">
                {activeCount > 0 ? Math.round((healthyCount / activeCount) * 100) : 0}%
              </p>
            </div>
            <FiTrendingUp className="text-4xl text-purple-600 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Integration Status List */}
      {connectors.filter(c => c.is_active).length === 0 ? (
        <Card>
          <div className="text-center py-12">
            <FiActivity className="mx-auto text-6xl text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">No Active Integrations</h3>
            <p className="text-gray-600">
              Configure connectors in Metadata Retrieval to monitor their health
            </p>
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {connectors.filter(c => c.is_active).map((connector) => {
            const health = healthStatus[connector.id] || { status: 'unknown' };
            
            return (
              <Card key={connector.id} className="hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(health.status)}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {connector.connector_name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {connector.connector_type.replace('_', ' ').toUpperCase()} Connector
                        {connector.platform && ` • ${connector.platform.replace('_', ' ').toUpperCase()}`}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      {getStatusBadge(health.status)}
                      {health.lastChecked && (
                        <p className="text-xs text-gray-500 mt-1">
                          Last checked: {new Date(health.lastChecked).toLocaleTimeString()}
                        </p>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => testSingleConnection(connector.id)}
                      disabled={testing[connector.id]}
                      icon={testing[connector.id] ? FiRefreshCw : FiCheckCircle}
                    >
                      {testing[connector.id] ? 'Testing...' : 'Test'}
                    </Button>
                  </div>
                </div>

                {/* Connection Details */}
                <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Endpoint</p>
                    <p className="text-sm font-mono text-gray-700 truncate">
                      {connector.api_endpoint_url}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Status Message</p>
                    <p className="text-sm text-gray-700">
                      {health.message || 'No recent test results'}
                    </p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Health Check History (Mock) */}
      <Card>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <FiBarChart2 />
          Health Check History (Last 24 Hours)
        </h3>
        
        <div className="bg-gray-50 rounded-lg p-8">
          <div className="text-center text-gray-500">
            <FiClock className="mx-auto text-4xl mb-2" />
            <p>Historical health data will be displayed here</p>
            <p className="text-sm mt-2">Coming soon: Charts and trends</p>
          </div>
        </div>
      </Card>

      {/* Quick Actions */}
      <Card className="bg-blue-50 border-blue-200">
        <div className="flex items-start gap-4">
          <FiAlertCircle className="text-2xl text-blue-600 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">Troubleshooting Tips</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
              <li>If a connector shows unhealthy, verify the API endpoint is accessible</li>
              <li>Check API keys and authentication credentials in connector configuration</li>
              <li>Review firewall rules if connections are timing out</li>
              <li>Contact the platform administrator for platform-specific issues</li>
              <li>Check recent import history for pattern of failures</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default IntegrationHealth;
