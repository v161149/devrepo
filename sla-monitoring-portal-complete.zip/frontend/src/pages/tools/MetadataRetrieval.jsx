/**
 * Metadata Retrieval Page
 * Manage connectors and import data from external systems
 * (Autosys, Ansible Tower, Asset APIs, etc.)
 */

import React, { useState, useEffect } from 'react';
import { 
  FiPlus, 
  FiRefreshCw, 
  FiCheckCircle, 
  FiXCircle, 
  FiDownload,
  FiDatabase,
  FiEdit,
  FiTrash2,
  FiAlertCircle,
  FiServer,
  FiSettings
} from 'react-icons/fi';
import Button from '../../components/Button';
import Card from '../../components/Card';
import AddConnectorModal from '../../components/AddConnectorModal';

const MetadataRetrieval = () => {
  const [connectors, setConnectors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [testingConnector, setTestingConnector] = useState(null);
  const [importingFrom, setImportingFrom] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedConnector, setSelectedConnector] = useState(null);
  const [editingConnector, setEditingConnector] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const handleEdit = (connector) => {
    setEditingConnector(connector);
    setShowEditModal(true);
  };

  const handleEditSuccess = () => {
    setShowEditModal(false);
    setEditingConnector(null);
    fetchConnectors(); // Refresh list
  };

  const handleDelete = async (connector) => {
    // Confirmation dialog
    const confirmMessage = `Are you sure you want to delete "${connector.connector_name}"?\n\nThis action cannot be undone.`;
    
    if (!window.confirm(confirmMessage)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connector.connector_id || connector.id}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.ok) {
        alert(`✓ Connector "${connector.connector_name}" deleted successfully`);
        fetchConnectors(); // Refresh the list
      } else {
        const error = await response.json();
        alert(`✗ Failed to delete connector: ${error.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error deleting connector:', error);
      alert(`✗ Error deleting connector: ${error.message}`);
    }
  };

  useEffect(() => {
    fetchConnectors();
  }, []);

  const fetchConnectors = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setConnectors(data.data || []);
      }
    } catch (error) {
      console.error('Error fetching connectors:', error);
    } finally {
      setLoading(false);
    }
  };

  const testConnection = async (connectorId) => {
    try {
      setTestingConnector(connectorId);
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}/test`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      const data = await response.json();
      
      if (data.success) {
        alert(`✓ Connection successful: ${data.connector_name}`);
      } else {
        alert(`✗ Connection failed: ${data.message}`);
      }
    } catch (error) {
      alert(`Error testing connection: ${error.message}`);
    } finally {
      setTestingConnector(null);
    }
  };

  const startImport = (connector) => {
    setSelectedConnector(connector);
    setImportingFrom(connector.connector_id || connector.id);
  };

  const getConnectorIcon = (type) => {
    switch(type) {
      case 'asset':
        return <FiServer className="text-2xl text-blue-500" />;
      case 'service_job':
        return <FiDatabase className="text-2xl text-green-500" />;
      case 'sla':
        return <FiSettings className="text-2xl text-purple-500" />;
      default:
        return <FiDatabase className="text-2xl text-gray-500" />;
    }
  };

  const getConnectorTypeName = (type) => {
    switch(type) {
      case 'asset':
        return 'Asset Data';
      case 'service_job':
        return 'Services & Jobs';
      case 'sla':
        return 'SLA Definitions';
      default:
        return type;
    }
  };

  const getPlatformBadge = (platform) => {
    if (!platform) return null;
    
    const colors = {
      'autosys': 'bg-blue-100 text-blue-800',
      'ansible_tower': 'bg-red-100 text-red-800',
      'custom': 'bg-gray-100 text-gray-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded text-xs font-medium ${colors[platform] || colors.custom}`}>
        {platform.replace('_', ' ').toUpperCase()}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <p className="text-gray-600">
            Import assets, services, jobs, and SLAs from external systems
          </p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={fetchConnectors}
            icon={FiRefreshCw}
          >
            Refresh
          </Button>
          <Button
            onClick={() => {
              setShowAddModal(true);
            }}
            icon={FiPlus}
          >
            Add Connector
          </Button>
        </div>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-600 font-medium">Total Connectors</p>
              <p className="text-3xl font-bold text-blue-900">{connectors.length}</p>
            </div>
            <FiDatabase className="text-4xl text-blue-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-600 font-medium">Active Connectors</p>
              <p className="text-3xl font-bold text-green-900">
                {connectors.filter(c => c.is_active).length}
              </p>
            </div>
            <FiCheckCircle className="text-4xl text-green-600 opacity-50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-600 font-medium">Import Ready</p>
              <p className="text-3xl font-bold text-purple-900">
                {connectors.filter(c => c.is_active).length}
              </p>
            </div>
            <FiDownload className="text-4xl text-purple-600 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Connectors List */}
      {connectors.length === 0 ? (
        <Card>
          <div className="text-center py-12">
            <FiDatabase className="mx-auto text-6xl text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">No Connectors Configured</h3>
            <p className="text-gray-600 mb-6">
              Add your first connector to start importing data from external systems
            </p>
            <Button onClick={() => setShowAddModal(true)} icon={FiPlus}>
              Add Your First Connector
            </Button>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {connectors.map((connector) => (
            <Card key={connector.connector_id || connector.id} className="hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  {getConnectorIcon(connector.connector_type)}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {connector.connector_name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {getConnectorTypeName(connector.connector_type)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {connector.is_active ? (
                    <FiCheckCircle className="text-green-500" title="Active" />
                  ) : (
                    <FiXCircle className="text-red-500" title="Inactive" />
                  )}
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Platform:</span>
                  {getPlatformBadge(connector.platform)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Endpoint:</span>
                  <span className="text-sm font-mono text-gray-700 truncate">
                    {connector.api_endpoint_url}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Created:</span>
                  <span className="text-sm text-gray-700">
                    {new Date(connector.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => testConnection(connector.connector_id || connector.id)}
                  disabled={testingConnector === (connector.connector_id || connector.id) || !connector.is_active}
                  icon={testingConnector === (connector.connector_id || connector.id) ? FiRefreshCw : FiCheckCircle}
                  className={testingConnector === (connector.connector_id || connector.id) ? 'animate-pulse' : ''}
                >
                  {testingConnector === (connector.connector_id || connector.id) ? 'Testing...' : 'Test Connection'}
                </Button>
                <Button
                  size="sm"
                  onClick={() => startImport(connector)}
                  disabled={!connector.is_active}
                  icon={FiDownload}
                >
                  Import Data
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  icon={FiEdit}
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent card click
                    handleEdit(connector);
                  }}
                  title="Edit connector"
                >
                  Edit
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  icon={FiTrash2}
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent card click
                    handleDelete(connector);
                  }}
                  title="Delete connector"
                  className="text-red-600 hover:text-red-700 hover:border-red-300"
                >
                  Delete
                </Button>                
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Import Modal */}
      {importingFrom && selectedConnector && (
        <ImportModal
          connector={selectedConnector}
          onClose={() => {
            setImportingFrom(null);
            setSelectedConnector(null);
          }}
          onSuccess={() => {
            setImportingFrom(null);
            setSelectedConnector(null);
            alert('Import completed successfully!');
          }}
        />
      )}

      {/* Edit Connector Modal */}
      {showEditModal && editingConnector && (
        <AddConnectorModal
          connector={editingConnector}
          onClose={() => {
            setShowEditModal(false);
            setEditingConnector(null);
          }}
          onSuccess={handleEditSuccess}
        />
      )}

      {/* Add Connector Modal */}
      {showAddModal && (
          <AddConnectorModal
            onClose={() => setShowAddModal(false)}
            onSuccess={() => {
              setShowAddModal(false);
              fetchConnectors();
            }}
          />
      )}

      {/* Quick Start Guide */}
      <Card className="bg-blue-50 border-blue-200">
        <div className="flex items-start gap-4">
          <FiAlertCircle className="text-2xl text-blue-600 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">Quick Start Guide</h4>
            <ol className="list-decimal list-inside space-y-2 text-sm text-blue-800">
              <li>Click "Add Connector" to configure a new data source</li>
              <li>Choose connector type: Assets, Services, Jobs, or SLAs</li>
              <li>Select platform: Autosys, Ansible Tower, or Custom API</li>
              <li>Configure API endpoint and authentication</li>
              <li>Set up field mappings to transform data</li>
              <li>Test connection to verify configuration</li>
              <li>Click "Import Data" to fetch and import records</li>
            </ol>
          </div>
        </div>
      </Card>
    </div>
  );
};

// Import Modal Component
const ImportModal = ({ connector, onClose, onSuccess }) => {
  const [step, setStep] = useState(1); // 1: Fetch, 2: Preview, 3: Import
  const [data, setData] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connector.connector_id || connector.id}/fetch`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ filters: {} })
        }
      );
      
      const result = await response.json();
      setData(result.data || []);
      setSelectedItems(result.data || []);
      setStep(2);
    } catch (error) {
      alert(`Error fetching data: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const performImport = async () => {
    try {
      setImporting(true);
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connector.connector_id || connector.id}/import`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            selected_data: selectedItems,
            asset_mapping: {} // Can be enhanced for job imports
          })
        }
      );
      
      const result = await response.json();
      
      if (result.imported > 0) {
        onSuccess();
      } else {
        alert('No items were imported. Check console for details.');
        console.error('Import result:', result);
      }
    } catch (error) {
      alert(`Error importing data: ${error.message}`);
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b flex items-center justify-between">
          <h2 className="text-xl font-bold">
            Import from {connector.connector_name}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {step === 1 && (
            <div className="text-center py-12">
              <FiDownload className="mx-auto text-6xl text-primary-600 mb-4" />
              <h3 className="text-xl font-medium mb-2">Ready to fetch data</h3>
              <p className="text-gray-600 mb-6">
                Click below to retrieve data from {connector.connector_name}
              </p>
              <Button onClick={fetchData} disabled={loading} icon={FiDownload}>
                {loading ? 'Fetching...' : 'Fetch Data'}
              </Button>
            </div>
          )}

          {step === 2 && (
            <div>
              <div className="mb-4">
                <h3 className="text-lg font-medium mb-2">
                  Preview: {data.length} items found
                </h3>
                <p className="text-sm text-gray-600">
                  Review and select items to import
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
                {data.length === 0 ? (
                  <p className="text-center text-gray-500">No data available</p>
                ) : (
                  <div className="space-y-2">
                    {data.slice(0, 10).map((item, idx) => (
                      <div key={idx} className="bg-white p-3 rounded border text-sm">
                        <pre className="text-xs overflow-x-auto">
                          {JSON.stringify(item, null, 2)}
                        </pre>
                      </div>
                    ))}
                    {data.length > 10 && (
                      <p className="text-center text-gray-500 text-sm">
                        ... and {data.length - 10} more items
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          {step === 2 && (
            <Button onClick={performImport} disabled={importing || data.length === 0}>
              {importing ? 'Importing...' : `Import ${selectedItems.length} Items`}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MetadataRetrieval;
