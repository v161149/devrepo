/**
 * AssetDetail Page Component - ENHANCED WITH ASSOCIATED JOBS
 * 
 * View, create, update, delete asset
 * Manage associated services
 * 
 * NEW FEATURES:
 * - Associated Jobs section beneath Associated Services
 * - Add Job button to create jobs directly under asset
 * - Jobs table showing: Job Name, Type, Schedule, Status, Actions
 * - Clickable rows navigate to job detail page
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { FiServer, FiSave, FiTrash2, FiArrowLeft, FiPlus, FiEdit2, FiClock } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import CreateServiceModal from '../components/CreateServiceModal';
import CreateJobModal from '../components/CreateJobModal';
import apiService from '../services/api';
import SERVICE_TYPES from '../constants/serviceTypes';

const AssetDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';

  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [editMode, setEditMode] = useState(isNew);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    asset_name: '',
    asset_type: 'Server',
    asset_owner: '',
    description: '',
    onboarded_date: new Date().toISOString().split('T')[0],
    status: 'active'
  });

  const [services, setServices] = useState([]);
  const [jobs, setJobs] = useState([]); // ✅ NEW: Jobs state
  const [showAddServiceModal, setShowAddServiceModal] = useState(false);
  const [showAddJobModal, setShowAddJobModal] = useState(false); // ✅ NEW: Job modal state

  // Helper function to get service type display name
  const getServiceTypeName = (service) => {
    let serviceTypeId = null;
    
    // Try to get service_type from multiple possible locations
    // 1. Direct property
    if (service.service_type) {
      serviceTypeId = service.service_type;
    }
    // 2. From metadata (stored as JSON string in DB)
    else if (service.metadata) {
      try {
        const metadata = typeof service.metadata === 'string' 
          ? JSON.parse(service.metadata) 
          : service.metadata;
        serviceTypeId = metadata.service_type;
      } catch (e) {
        console.error('Error parsing service metadata:', e);
      }
    }
    
    if (!serviceTypeId) return 'N/A';
    
    // SERVICE_TYPES can be either flat array or nested categories
    if (Array.isArray(SERVICE_TYPES)) {
      // Try flat array first (Step2 format)
      const type = SERVICE_TYPES.find(t => t.id === serviceTypeId);
      if (type) return type.name;
      
      // Try nested categories (if they exist)
      for (const item of SERVICE_TYPES) {
        if (item.types && Array.isArray(item.types)) {
          const type = item.types.find(t => t.id === serviceTypeId);
          if (type) return type.name;
        }
      }
    }
    
    // If not found, return the ID with capitalization
    return serviceTypeId.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  useEffect(() => {
    if (!isNew) {
      fetchAssetDetails();
    }
  }, [id, isNew]);

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    
    // If already in YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}/.test(dateStr)) {
      return dateStr.split('T')[0];
    }
    
    // If in MM/DD/YYYY format
    if (/^\d{2}\/\d{2}\/\d{4}/.test(dateStr)) {
      const [month, day, year] = dateStr.split('/');
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    
    // Try to parse as Date
    try {
      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
    } catch (e) {
      console.error('Error parsing date:', dateStr, e);
    }
    
    return '';
  };

  const fetchAssetDetails = async () => {
    try {
      setLoading(true);
      const response = await apiService.assets.get(id);
      const asset = response.data;

      setFormData({
        asset_name: asset.asset_name || '',
        asset_type: asset.asset_type || 'Server',
        asset_owner: asset.asset_owner || '',
        description: asset.description || '',
        onboarded_date: formatDate(asset.onboarded_date),
        status: asset.status || 'active'
      });

      // Fetch associated services
      fetchServices();
      
      // ✅ NEW: Fetch associated jobs
      fetchJobs();

    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchServices = async () => {
    try {
      const response = await apiService.assets.getServices(id);
      setServices(response.data?.data || response.data || []);
    } catch (err) {
      console.error('Error fetching services:', err);
    }
  };

  // ✅ NEW: Fetch jobs associated with this asset
  const fetchJobs = async () => {
    try {
      const response = await apiService.jobs.getAll();
      const allJobs = response.data?.data || response.data || [];
      
      // Filter jobs that belong to this asset
      const assetJobs = allJobs.filter(job => job.asset_id === id);
      setJobs(assetJobs);
    } catch (err) {
      console.error('Error fetching jobs:', err);
      setJobs([]);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setSaving(true);

      if (isNew) {
        // Create new asset
        await apiService.assets.create(formData);
        navigate('/assets');
      } else {
        // Update existing asset
        await apiService.assets.update(id, formData);
        setEditMode(false);
        fetchAssetDetails();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this asset? This will also delete all associated services and jobs.')) {
      return;
    }

    try {
      setDeleting(true);
      await apiService.assets.delete(id);
      navigate('/assets');
    } catch (err) {
      setError(err.message);
    } finally {
      setDeleting(false);
    }
  };

  const handleServiceAdded = () => {
    fetchServices();
  };

  // ✅ NEW: Handle job added
  const handleJobAdded = () => {
    fetchJobs();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading asset details...</p>
        </div>
      </div>
    );
  }

  if (error && !isNew) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6">
        <Link to="/assets">
          <Button variant="outline" className="mb-4">
            <FiArrowLeft className="mr-2" />
            Back to Assets
          </Button>
        </Link>

        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">
            {isNew ? 'Create New Asset' : formData.asset_name}
          </h1>
          
          {!isNew && !editMode && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                icon={FiEdit2}
                onClick={() => setEditMode(true)}
              >
                Edit
              </Button>
              <Button
                variant="outline"
                icon={FiTrash2}
                onClick={handleDelete}
                loading={deleting}
                className="text-red-600 hover:text-red-700"
              >
                Delete
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Asset Information Card */}
      <Card className="mb-6">
        <h2 className="text-xl font-semibold mb-4">Asset Information</h2>
        
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-2 gap-4">
            {/* Asset Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asset Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="asset_name"
                value={formData.asset_name}
                onChange={handleInputChange}
                disabled={!editMode && !isNew}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
              />
            </div>

            {/* Asset Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asset Type <span className="text-red-500">*</span>
              </label>
              <select
                name="asset_type"
                value={formData.asset_type}
                onChange={handleInputChange}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
              >
                <option value="Server">Server</option>
                <option value="Database Server">Database Server</option>
                <option value="Application Server">Application Server</option>
                <option value="Web Server">Web Server</option>
                <option value="Storage">Storage</option>
                <option value="Network Device">Network Device</option>
                <option value="Virtual Machine">Virtual Machine</option>
                <option value="Container">Container</option>	
                <option value="Cloud Resource">Cloud Resource</option>
                <option value="Other">Other</option>	
              </select>
            </div>

            {/* Asset Owner */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asset Owner
              </label>
              <input
                type="text"
                name="asset_owner"
                value={formData.asset_owner}
                onChange={handleInputChange}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
              />
            </div>

            {/* Onboarded Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Onboarded Date
              </label>
              <input
                type="date"
                name="onboarded_date"
                value={formData.onboarded_date}
                onChange={handleInputChange}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                disabled={!editMode && !isNew}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>

            {/* Description */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                disabled={!editMode && !isNew}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
              />
            </div>
          </div>

          {/* Action Buttons */}
          {(editMode || isNew) && (
            <div className="flex gap-2 pt-4 border-t mt-4">
              <Button
                type="submit"
                icon={FiSave}
                loading={saving}
              >
                {isNew ? 'Create Asset' : 'Save Changes'}
              </Button>
              {!isNew && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setEditMode(false);
                    fetchAssetDetails();
                  }}
                >
                  Cancel
                </Button>
              )}
            </div>
          )}
        </form>
      </Card>

      {/* Associated Services */}
      {!isNew && (
        <Card className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Associated Services</h2>
            <Button 
              icon={FiPlus} 
              size="sm"
              onClick={() => setShowAddServiceModal(true)}
            >
              Add Service
            </Button>
          </div>

          {services.length === 0 ? (
            <div className="text-center py-8 text-gray-600">
              <p>No services associated with this asset yet.</p>
              <Button 
                icon={FiPlus} 
                className="mt-4"
                onClick={() => setShowAddServiceModal(true)}
              >
                Add First Service
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Service
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {services.map((service) => (
                    <tr 
                      key={service.service_id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigate(`/services/${service.service_id}`)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {service.name || service.service_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {getServiceTypeName(service)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          service.is_active !== false
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {service.is_active !== false ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-primary-600">
                        View Details →
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {/* ✅ NEW: Associated Jobs Section */}
      {!isNew && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Associated Jobs</h2>
            <Button 
              icon={FiPlus} 
              size="sm"
              onClick={() => setShowAddJobModal(true)}
            >
              Add Job
            </Button>
          </div>

          {jobs.length === 0 ? (
            <div className="text-center py-8 text-gray-600">
              <FiClock className="mx-auto text-6xl text-gray-300 mb-4" />
              <p>No jobs associated with this asset yet.</p>
              <Button 
                icon={FiPlus} 
                className="mt-4"
                onClick={() => setShowAddJobModal(true)}
              >
                Add First Job
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Job Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Schedule
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {jobs.map((job) => (
                    <tr 
                      key={job.job_id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigate(`/jobs/${job.job_id}`)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center bg-purple-100 rounded-lg">
                            <FiClock className="text-purple-600" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {job.job_name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {job.job_id}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {job.job_type || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                          {job.schedule || 'Not scheduled'}
                        </code>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          job.is_active
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {job.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-primary-600">
                        View Details →
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {/* Add Service Modal */}
      <CreateServiceModal
        isOpen={showAddServiceModal}
        onClose={() => setShowAddServiceModal(false)}
        onSuccess={handleServiceAdded}
        assetId={id}
      />

      {/* ✅ NEW: Add Job Modal */}
      <CreateJobModal
        isOpen={showAddJobModal}
        onClose={() => setShowAddJobModal(false)}
        onSuccess={handleJobAdded}
        preselectedAssetId={id}
      />
    </div>
  );
};

export default AssetDetail;
