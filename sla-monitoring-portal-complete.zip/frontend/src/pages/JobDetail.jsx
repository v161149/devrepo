import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FiClock, FiServer, FiDatabase, FiArrowLeft, FiAlertCircle, FiEdit2, FiTrash2, FiPlus } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import CreateSLAModal from '../components/CreateSLAModal';
import SLACompliancePanel from '../components/SLACompliancePanel';
import apiService from '../services/api';

// Job types matching manual onboarding
const JOB_TYPES = [
  { id: 'monitoring', name: 'Monitoring' },
  { id: 'backup', name: 'Backup' },
  { id: 'maintenance', name: 'Maintenance' },
  { id: 'deployment', name: 'Deployment' },
  { id: 'health_check', name: 'Health Check' },
  { id: 'security_scan', name: 'Security Scan' },
  { id: 'log_collection', name: 'Log Collection' },
  { id: 'data_sync', name: 'Data Synchronization' },
  { id: 'other', name: 'Other' }
];

// Legacy job type mapping for backwards compatibility
const JOB_TYPE_LEGACY_MAP = {
  'ETL': 'other',
  'Batch': 'backup',
  'Replication': 'data_sync',
  'Testing': 'other',
  'Report Generation': 'other',
  'Data Sync': 'data_sync'
};

// Reverse mapping for display
const JOB_TYPE_DISPLAY_MAP = {};
JOB_TYPES.forEach(type => {
  JOB_TYPE_DISPLAY_MAP[type.id] = type.name;
});

// Log template presets for jobs (matching Step3)
const JOB_LOG_TEMPLATE_PRESETS = {
  'job_execution': {
    name: 'Job Execution',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      duration_seconds: '{{duration}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    }
  },
  'data_processing': {
    name: 'Data Processing',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      duration_seconds: '{{duration}}',
      records_processed: '{{records}}',
      records_failed: '{{failed}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    }
  },
  'scheduled_task': {
    name: 'Scheduled Task',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      scheduled_time: '{{scheduled}}',
      actual_start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      on_time: '{{on_time}}',
      timestamp: '{{timestamp}}'
    }
  },
  'custom': {
    name: 'Custom Template',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      timestamp: '{{timestamp}}'
    }
  }
};

const JobDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [asset, setAsset] = useState(null);
  const [service, setService] = useState(null);
  const [slas, setSlas] = useState([]); // ✅ Initialize as empty array
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedJob, setEditedJob] = useState(null);
  const [showSLAModal, setShowSLAModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // NEW: Log monitoring states
  const [logConnectors, setLogConnectors] = useState([]);
  const [showLogConfig, setShowLogConfig] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState('');

  useEffect(() => {
    loadJobDetails();
    loadLogConnectors();
  }, [id]);

  const loadJobDetails = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load job details
      const jobResponse = await apiService.jobs.get(id);
      const jobData = jobResponse.data?.data || jobResponse.data;
      setJob(jobData);
      
      // Set editedJob with log fields from top-level properties
      // Normalize job_type for backwards compatibility
      const normalizedJobType = JOB_TYPE_LEGACY_MAP[jobData.job_type] || jobData.job_type;
      
      setEditedJob({
        ...jobData,
        job_type: normalizedJobType,
        job_identifier: jobData.job_identifier || '',
        log_server_type: jobData.log_server_type || '',
        log_template: jobData.log_template || ''
      });

      // Load related asset if exists
      if (jobData.asset_id) {
        try {
          const assetResponse = await apiService.assets.get(jobData.asset_id);
          setAsset(assetResponse.data);
        } catch (err) {
          console.error('Error loading asset:', err);
        }
      }

      // Load related service if exists
      if (jobData.service_id) {
        try {
          // ✅ Use the correct API call - services endpoint takes service_id in URL
          const serviceResponse = await fetch(`http://localhost:5000/api/v1/services/${jobData.service_id}`, {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`,
              'Content-Type': 'application/json'
            }
          });
          
          if (serviceResponse.ok) {
            const serviceData = await serviceResponse.json();
            setService(serviceData.data || serviceData);
          }
        } catch (err) {
          console.error('Error loading service:', err);
        }
      }

      // Load job SLAs
      try {
        const slasResponse = await apiService.jobs.getSLAs(id);
        const slaData = slasResponse.data?.data || slasResponse.data || [];
        console.log('Loaded SLAs:', slaData); // Debug log
        setSlas(Array.isArray(slaData) ? slaData : []);
      } catch (err) {
        console.error('Error loading SLAs:', err);
        setSlas([]); // Set empty array on error
      }

    } catch (err) {
      console.error('Error loading job details:', err);
      setError(err.response?.data?.error || err.message || 'Failed to load job details');
    } finally {
      setLoading(false);
    }
  };

  const loadLogConnectors = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        let connectors = [];
        if (Array.isArray(result)) {
          connectors = result;
        } else if (result.data && Array.isArray(result.data)) {
          connectors = result.data;
        }
        setLogConnectors(connectors);
      }
    } catch (err) {
      console.error('Error loading log connectors:', err);
      setLogConnectors([]);
    }
  };

  const handlePresetLoad = (presetKey) => {
    setSelectedPreset(presetKey);
    if (presetKey && JOB_LOG_TEMPLATE_PRESETS[presetKey]) {
      const preset = JOB_LOG_TEMPLATE_PRESETS[presetKey];
      handleInputChange('log_template', JSON.stringify(preset.template, null, 2));
    }
  };

  const validateLogTemplate = (template) => {
    if (!template) return true;
    try {
      JSON.parse(template);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
    setEditedJob({ ...job });
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedJob({ ...job });
  };

  const handleSaveEdit = async () => {
    try {
      const updateData = {
        job_name: editedJob.job_name,
        job_type: editedJob.job_type,
        schedule: editedJob.schedule,
        description: editedJob.description,
        expected_duration: editedJob.expected_duration,
        is_active: editedJob.is_active
      };
      
      // Add log monitoring fields as top-level properties (like services)
      if (editedJob.job_identifier) {
        updateData.job_identifier = editedJob.job_identifier;
      }
      if (editedJob.log_server_type) {
        updateData.log_server_type = editedJob.log_server_type;
      }
      if (editedJob.log_template) {
        updateData.log_template = editedJob.log_template;
      }

      await apiService.jobs.update(id, updateData);
      setJob(editedJob);
      setIsEditing(false);
      
      // Show success message
      alert('Job updated successfully!');
    } catch (err) {
      console.error('Error updating job:', err);
      alert('Failed to update job: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleDelete = async () => {
    try {
      await apiService.jobs.delete(id);
      alert('Job deleted successfully!');
      navigate('/jobs');
    } catch (err) {
      console.error('Error deleting job:', err);
      alert('Failed to delete job: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleInputChange = (field, value) => {
    setEditedJob(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading job details...</p>
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error || 'Job not found'}</p>
          <Button onClick={() => navigate('/jobs')} variant="outline" className="mt-2">
            Back to Jobs
          </Button>
        </div>
      </div>
    );
  }

  const displayJob = isEditing ? editedJob : job;

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6">
        <Button
          variant="outline"
          onClick={() => navigate('/jobs')}
          className="mb-4"
        >
          <FiArrowLeft className="mr-2" />
          Back to Jobs
        </Button>
        
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{displayJob.job_name}</h1>
            {!isEditing && displayJob.description && (
              <p className="mt-1 text-sm text-gray-600">{displayJob.description}</p>
            )}
          </div>
          
          {!isEditing ? (
            <div className="flex gap-2">
              <Button
                variant="outline"
                icon={FiEdit2}
                onClick={handleEdit}
              >
                Edit
              </Button>
              <Button
                variant="outline"
                icon={FiTrash2}
                onClick={() => setShowDeleteConfirm(true)}
                className="text-red-600 hover:text-red-700"
              >
                Delete
              </Button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={handleCancelEdit}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEdit}
              >
                Save Changes
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Job Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Job Information
            </h2>
            
            {isEditing ? (
              // Edit Mode
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Job Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={editedJob.job_name}
                    onChange={(e) => handleInputChange('job_name', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Job Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={editedJob.job_type}
                    onChange={(e) => handleInputChange('job_type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    required
                  >
                    <option value="">Select Type</option>
                    {JOB_TYPES.map(type => (
                      <option key={type.id} value={type.id}>{type.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={editedJob.description || ''}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Schedule (Cron Expression) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={editedJob.schedule || ''}
                    onChange={(e) => handleInputChange('schedule', e.target.value)}
                    placeholder="e.g., 0 2 * * *"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono"
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Example: "0 2 * * *" = Daily at 2:00 AM
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Expected Duration (minutes)
                  </label>
                  <input
                    type="number"
                    value={editedJob.expected_duration ? Math.floor(editedJob.expected_duration / 60) : ''}
                    onChange={(e) => {
                      const minutes = parseInt(e.target.value) || 0;
                      handleInputChange('expected_duration', minutes * 60); // Convert to seconds
                    }}
                    min="1"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="is_active"
                    checked={editedJob.is_active}
                    onChange={(e) => handleInputChange('is_active', e.target.checked)}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="is_active" className="ml-2 block text-sm text-gray-900">
                    Active
                  </label>
                </div>

                {/* Log Monitoring Configuration - Collapsible Section */}
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <button
                    type="button"
                    onClick={() => setShowLogConfig(!showLogConfig)}
                    className="flex items-center justify-between w-full text-left mb-3 hover:bg-gray-50 p-2 rounded transition-colors"
                  >
                    <span className="text-sm font-medium text-gray-700">
                      {showLogConfig ? '▼' : '▶'} Log Monitoring Configuration (Optional)
                    </span>
                  </button>

                  {showLogConfig && (
                    <div className="space-y-4 pl-4 border-l-2 border-primary-200">
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                        <div className="flex items-start gap-2">
                          <FiAlertCircle className="text-blue-600 mt-0.5 flex-shrink-0" />
                          <p className="text-sm text-blue-800">
                            Configure log-based monitoring for this job. Set up log server connectors in <strong>Tools → Log Server Setup</strong>.
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        {/* Job Identifier */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Job Identifier
                          </label>
                          <input
                            type="text"
                            value={editedJob.job_identifier || ''}
                            onChange={(e) => handleInputChange('job_identifier', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                            placeholder="e.g., ETL-DAILY-001"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            Unique identifier used in log entries
                          </p>
                        </div>

                        {/* Log Server Type */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Log Server Type
                          </label>
                          <select
                            value={editedJob.log_server_type || ''}
                            onChange={(e) => handleInputChange('log_server_type', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                          >
                            <option value="">Select log server...</option>
                            {logConnectors.length === 0 ? (
                              <option value="" disabled>No log servers configured</option>
                            ) : (
                              logConnectors
                                .filter(c => c.is_active)
                                .map(connector => (
                                  <option key={connector.connector_id} value={connector.log_server_type}>
                                    {connector.connector_name} ({connector.log_server_type})
                                  </option>
                                ))
                            )}
                          </select>
                          <p className="text-xs text-gray-500 mt-1">
                            Select the log server where this job sends logs
                          </p>
                        </div>

                        {/* Log Template */}
                        <div className="col-span-2">
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-sm font-medium text-gray-700">
                              Log Entry Template
                            </label>
                            <div className="flex items-center gap-2">
                              <select
                                value={selectedPreset}
                                onChange={(e) => handlePresetLoad(e.target.value)}
                                className="text-xs px-2 py-1 border border-gray-300 rounded"
                              >
                                <option value="">Load Preset...</option>
                                {Object.entries(JOB_LOG_TEMPLATE_PRESETS).map(([key, preset]) => (
                                  <option key={key} value={key}>{preset.name}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                          <textarea
                            value={editedJob.log_template || ''}
                            onChange={(e) => handleInputChange('log_template', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                            rows={10}
                            placeholder='{
  "identifier": "{{job_identifier}}",
  "status": "{{status}}",
  "start_time": "{{start_time}}",
  "end_time": "{{end_time}}",
  "timestamp": "{{timestamp}}"
}'
                          />
                          {editedJob.log_template && !validateLogTemplate(editedJob.log_template) && (
                            <p className="text-sm text-red-600 mt-1">Invalid JSON format</p>
                          )}
                          <p className="text-xs text-gray-500 mt-1">
                            This template must match the format your job uses in log entries
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              // View Mode
              <dl className="grid grid-cols-1 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Job ID</dt>
                  <dd className="mt-1 text-sm text-gray-900">{job.job_id}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Job Name</dt>
                  <dd className="mt-1 text-sm text-gray-900">{job.job_name}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Job Type</dt>
                  <dd className="mt-1 text-sm text-gray-900">{job.job_type}</dd>
                </div>
                {job.description && (
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Description</dt>
                    <dd className="mt-1 text-sm text-gray-900">{job.description}</dd>
                  </div>
                )}
                <div>
                  <dt className="text-sm font-medium text-gray-500">Schedule</dt>
                  <dd className="mt-1 text-sm text-gray-900 font-mono bg-gray-50 px-2 py-1 rounded">
                    {job.schedule || 'Not scheduled'}
                  </dd>
                </div>

                {job.expected_duration && (
                  <div>
                    <dt className="text-sm font-medium text-gray-500">
                      Expected Duration
                    </dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {job.expected_duration} minutes
                    </dd>
                  </div>
                )}
                <div>
                  <dt className="text-sm font-medium text-gray-500">Status</dt>
                  <dd className="mt-1">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        job.is_active
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {job.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </dd>
                </div>
              </dl>
            )}
          </Card>

          {/* Associated Asset */}
          {asset && !isEditing && (
            <Card>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Associated Asset
              </h2>
              <div
                className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
                onClick={() => navigate(`/assets/${asset.asset_id}`)}
              >
                <div className="bg-blue-100 p-2 rounded-lg">
                  <FiServer className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {asset.asset_name}
                  </p>
                  <p className="text-xs text-gray-500">{asset.asset_type}</p>
                </div>
              </div>
            </Card>
          )}

          {/* Associated Service */}
          {service && !isEditing && (
            <Card>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Associated Service
              </h2>
              <div
                className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
                onClick={() => navigate(`/services/${service.service_id}`)}
              >
                <div className="bg-green-100 p-2 rounded-lg">
                  <FiDatabase className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {service.name}
                  </p>
                  <p className="text-xs text-gray-500">Service</p>
                </div>
              </div>
            </Card>
          )}

          {/* Enhanced SLA Compliance Section */}
          {!isEditing && (
            <div className="space-y-4">
              <Card>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-900">SLA Compliance</h2>
                </div>
                
                {/* Enhanced SLA Compliance Panel */}
                <SLACompliancePanel 
                  jobId={id}
                  refreshTrigger={job?.updated_at}
                />
              </Card>
              
              {/* Traditional SLA Management (Edit/Delete) - Collapsible */}
              <details className="border rounded-lg overflow-hidden">
                <summary className="cursor-pointer font-medium text-gray-700 hover:text-gray-900 p-4 bg-gray-50 hover:bg-gray-100 transition-colors">
                  Manage SLAs (View Details/Edit/Delete)
                </summary>
                <div className="p-4 bg-white">
                  <Button
                    size="sm"
                    icon={FiPlus}
                    onClick={() => setShowSLAModal(true)}
                    className="mb-4"
                  >
                    Add SLA
                  </Button>
                  
                  {slas.length === 0 ? (
                    <div className="text-center py-8">
                      <FiAlertCircle className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500 mb-4">No SLAs configured for this job yet</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              SLA Name
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              SLA Type
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Target
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {slas.map((sla) => {
                            return (
                              <tr key={sla.sla_id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {sla.name || 'Unnamed SLA'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 capitalize">
                                  {sla.metric_type ? sla.metric_type.replace(/_/g, ' ') : '-'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                                  {sla.target_value || '-'}{sla.target_unit || ''}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                  <button
                                    onClick={() => navigate(`/slas`)}
                                    className="text-primary-600 hover:text-primary-800 font-medium"
                                  >
                                    View
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </details>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Delete Job
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Are you sure you want to delete this job? This action cannot be undone.
              All associated SLAs will also be deleted.
            </p>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowDeleteConfirm(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  handleDelete();
                }}
                className="bg-red-600 hover:bg-red-700"
              >
                Delete Job
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add SLA Modal */}
      {showSLAModal && (
        <CreateSLAModal
          isOpen={showSLAModal}
          onClose={() => setShowSLAModal(false)}
          onSuccess={() => {
            setShowSLAModal(false);
            loadJobDetails();
          }}
          preselectedJobId={id}
        />
      )}
    </div>
  );
};

export default JobDetail;
