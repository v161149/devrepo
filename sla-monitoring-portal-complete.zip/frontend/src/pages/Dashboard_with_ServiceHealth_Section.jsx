/**
 * Dashboard Page
 * Main dashboard with metrics, alerts, charts, and enhanced Service Health table
 * NOW WITH INDIRECT MONITORING VIEW
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiServer, FiDatabase, FiFileText, FiAlertTriangle, FiCheckCircle, FiSearch, FiFilter, FiClock } from 'react-icons/fi';
import MetricCard from '../components/MetricCard';
import Card from '../components/Card';
import Button from '../components/Button';
import apiService from '../services/api';
import AlertList from '../components/AlertList';
import SLAComplianceChart from '../components/SLAComplianceChart';
import EnhancedSLADashboard from '../components/EnhancedSLADashboard';

// Service type mapping for display names
const SERVICE_TYPE_NAMES = {
  'etl_batch': 'ETL Batch Job',
  'api_gateway': 'API Gateway',
  'microservice': 'Microservice',
  'mysql': 'MySQL Database',
  'postgresql': 'PostgreSQL Database',
  'mongodb': 'MongoDB Database',
  'oracle': 'Oracle Database',
  'mssql': 'Microsoft SQL Server',
  'kafka': 'Kafka',
  'ibm_mq': 'IBM MQ',
  'rabbitmq': 'RabbitMQ',
  'spark_streaming': 'Spark Streaming',
  'flink': 'Apache Flink'
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState(null);
  const [services, setServices] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  // Indirect monitoring state
  const [indirectServices, setIndirectServices] = useState([]);
  const [indirectPagination, setIndirectPagination] = useState({
    page: 1,
    limit: 10, // Changed to 10 rows per page
    total: 0,
    total_pages: 0
  });
  const [indirectLoading, setIndirectLoading] = useState(false);

  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterOwner, setFilterOwner] = useState('all');
  const [filterAsset, setFilterAsset] = useState('all');
  const [filterDeployment, setFilterDeployment] = useState('all');
  const [filterMonitoring, setFilterMonitoring] = useState('direct'); // Default to 'direct', removed 'all'
  
  // New filters for indirect monitoring
  const [filterAssetName, setFilterAssetName] = useState('all');
  const [filterServiceName, setFilterServiceName] = useState('all');
  const [filterJobName, setFilterJobName] = useState('all');
  const [filterJobType, setFilterJobType] = useState('all');
  const [filterOnTime, setFilterOnTime] = useState('all');

  // Load dashboard metrics
  const loadMetrics = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      setError(null);

      const response = await apiService.dashboard.getMetrics(30);
      setMetrics(response.data);
    } catch (err) {
      console.error('Error loading metrics:', err);
      setError('Failed to load dashboard metrics');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Load assets for filter
  const loadAssets = async () => {
    try {
      const response = await apiService.assets.list();
      setAssets(response.data?.data || []);
    } catch (err) {
      console.error('Error loading assets:', err);
    }
  };

  // Load services with health status (for direct monitoring)
  const loadServices = async () => {
    try {
      const response = await apiService.services.getAll();
      const servicesData = response.data?.data || [];
      
      // Parse metadata if it's a string
      const servicesWithParsedMetadata = servicesData.map(service => ({
        ...service,
        metadata: typeof service.metadata === 'string' 
          ? JSON.parse(service.metadata) 
          : service.metadata
      }));
      
      // Try to get alerts count for each service
      let servicesWithAlerts = servicesWithParsedMetadata;
      try {
        const alertsResponse = await apiService.alerts.getAll({ status: 'pending' });
        const alerts = alertsResponse.data?.alerts || [];
        
        // Map alerts to services
        servicesWithAlerts = servicesWithParsedMetadata.map(service => ({
          ...service,
          alertCount: alerts.filter(alert => alert.service_id === service.service_id).length
        }));
      } catch (alertErr) {
        console.warn('Could not load alerts, continuing without alert counts:', alertErr);
        // Continue with services without alert counts
        servicesWithAlerts = servicesWithParsedMetadata.map(service => ({
          ...service,
          alertCount: 0
        }));
      }
      
      setServices(servicesWithAlerts);
    } catch (err) {
      console.error('Error loading services:', err);
      setServices([]);
    }
  };

  // Load indirect monitoring services (scheduled jobs)
  const loadIndirectServices = async () => {
    if (filterMonitoring !== 'indirect') return;

    try {
      setIndirectLoading(true);
      
      const params = {
        page: indirectPagination.page,
        limit: indirectPagination.limit
      };
      
      if (filterDeployment !== 'all') {
        params.deployment_location = filterDeployment;
      }
      
      if (searchTerm) {
        params.search = searchTerm;
      }
      
      const response = await apiService.dashboard.getIndirectMonitoring(params);
      
      setIndirectServices(response.data?.data || []);
      setIndirectPagination({
        page: response.data?.page || 1,
        limit: response.data?.limit || 10,
        total: response.data?.total || 0,
        total_pages: response.data?.total_pages || 0
      });
    } catch (err) {
      console.error('Error loading indirect services:', err);
      setIndirectServices([]);
    } finally {
      setIndirectLoading(false);
    }
  };

  // Load jobs for filter
  const loadJobs = async () => {
    try {
      const response = await apiService.jobs.getAll();
      setJobs(response.data?.data || []);
    } catch (err) {
      console.error('Error loading jobs:', err);
    }
  };

  // Filter indirect services on client side
  const filteredIndirectServices = indirectServices.filter(job => {
    const matchesAsset = filterAssetName === 'all' || job.asset_name === filterAssetName;
    const matchesService = filterServiceName === 'all' || job.service_name === filterServiceName;
    const matchesJobName = filterJobName === 'all' || job.job_name === filterJobName;
    const matchesJobType = filterJobType === 'all' || job.job_type === filterJobType;
    const matchesOnTime = filterOnTime === 'all' || job.on_time_ind === filterOnTime;
    
    return matchesAsset && matchesService && matchesJobName && matchesJobType && matchesOnTime;
  });

  useEffect(() => {
    loadMetrics();
    loadServices();
    loadAssets();
    loadJobs();
  }, []);

  // Load indirect services when monitoring filter changes to indirect
  useEffect(() => {
    if (filterMonitoring === 'indirect') {
      loadIndirectServices();
    }
  }, [filterMonitoring, searchTerm, filterDeployment, indirectPagination.page, indirectPagination.limit]);

  // Helper function to get service type display name
  const getServiceTypeName = (service) => {
    const serviceTypeId = service.metadata?.service_type;
    if (!serviceTypeId) return 'N/A';
    
    // Look up display name
    if (SERVICE_TYPE_NAMES[serviceTypeId]) {
      return SERVICE_TYPE_NAMES[serviceTypeId];
    }
    
    // Fallback: capitalize the ID
    return serviceTypeId.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  // Get unique owner teams for filter
  const uniqueOwnerTeams = [...new Set(services.map(s => s.owner_team).filter(Boolean))];

  // Get unique deployment locations for filter (remove duplicates)
  const uniqueDeploymentLocations = [...new Set(services.map(s => s.deployment_location).filter(Boolean))];
  
  // Get unique values from indirect services for filters
  const uniqueAssetNames = [...new Set(indirectServices.map(s => s.asset_name).filter(Boolean))];
  const uniqueServiceNames = [...new Set(indirectServices.map(s => s.service_name).filter(Boolean))];
  const uniqueJobNames = [...new Set(indirectServices.map(s => s.job_name).filter(Boolean))];
  const uniqueJobTypes = [...new Set(indirectServices.map(s => s.job_type).filter(Boolean))];
  const uniqueOnTimeStatuses = [...new Set(indirectServices.map(s => s.on_time_ind).filter(Boolean))];

  // Filter services based on all criteria (for direct monitoring)
  const filteredServices = services.filter(service => {
    // Search filter
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Type filter
    const serviceTypeId = service.metadata?.service_type;
    const matchesType = filterType === 'all' || serviceTypeId === filterType;
    
    // Status filter (based on health_status)
    const matchesStatus = filterStatus === 'all' || 
      (filterStatus === 'healthy' && service.health_status === 'healthy') ||
      (filterStatus === 'unhealthy' && service.health_status === 'unhealthy') ||
      (filterStatus === 'unknown' && (!service.health_status || service.health_status === 'unknown'));
    
    // Owner team filter
    const matchesOwner = filterOwner === 'all' || service.owner_team === filterOwner;
    
    // Asset filter
    const matchesAsset = filterAsset === 'all' || service.asset_id === filterAsset;
    
    // Deployment location filter
    const matchesDeployment = filterDeployment === 'all' || service.deployment_location === filterDeployment;
    
    // For direct monitoring view, only show direct monitoring services
    const serviceMonitoring = service.monitoring_method || service.metadata?.monitoring_method || 'direct';
    const matchesMonitoring = serviceMonitoring === 'direct';
    
    return matchesSearch && matchesType && matchesStatus && matchesOwner && matchesAsset && matchesDeployment && matchesMonitoring;
  });

  // Get asset name by ID
  const getAssetName = (assetId) => {
    if (!assetId) return '-';
    const asset = assets.find(a => a.asset_id === assetId);
    return asset ? asset.asset_name : assetId;
  };

  // Helper function for on-time status color
  const getOnTimeColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'met': return 'text-green-700 bg-green-100';
      case 'unmet': return 'text-red-700 bg-red-100';
      case 'in progress': return 'text-blue-700 bg-blue-100';
      case 'failed': return 'text-red-900 bg-red-200';
      case 'unknown':
      default: return 'text-gray-700 bg-gray-100';
    }
  };

  // Format date/time
  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr) return '-';
    return new Date(dateTimeStr).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return '-';
    return new Date(timeStr).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const handlePageChange = (newPage) => {
    setIndirectPagination(prev => ({ ...prev, page: newPage }));
  };

  const handlePageSizeChange = (newSize) => {
    setIndirectPagination(prev => ({ 
      ...prev, 
      limit: parseInt(newSize),
      page: 1  // Reset to page 1 when changing page size
    }));
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error && !metrics) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          <h3 className="font-semibold">Error Loading Dashboard</h3>
          <p>{error}</p>
          <button 
            onClick={() => loadMetrics()}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Monitor your services and SLAs</p>
        </div>
        <Button onClick={() => loadMetrics(true)} loading={refreshing}>
          Refresh
        </Button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <MetricCard
          title="Total Assets"
          value={metrics?.total_assets || 0}
          icon={FiDatabase}
          color="purple"
          subtitle="Monitored assets"
          onClick={() => navigate('/assets')}
        />        
        <MetricCard
          title="Total Services"
          value={metrics?.total_services || 0}
          icon={FiServer}
          color="blue"
          subtitle="Active services"
          onClick={() => navigate('/services')}
        />
        <MetricCard
          title="Total Jobs"
          value={metrics?.total_jobs || 0}
          icon={FiClock}
          color="yellow"
          subtitle="Active jobs"
          onClick={() => navigate('/jobs')}
        />        
        <MetricCard
          title="Active SLAs"
          value={metrics?.total_slas || 0}
          icon={FiFileText}
          color="green"
          subtitle="Service level agreements"
          onClick={() => navigate('/slas')}
        />
        <MetricCard
          title="Active Alerts"
          value={metrics?.active_alerts || 0}
          icon={FiAlertTriangle}
          color="red"
          subtitle="Pending alerts"
          onClick={() => navigate('/alerts')}
        />
        {/*
        <MetricCard
          title="Overall SLA Compliance"
          value={`${metrics?.compliance_percentage || 0}%`}
          icon={FiCheckCircle}
          color={metrics?.compliance_percentage >= 95 ? 'green' : metrics?.compliance_percentage >= 80 ? 'yellow' : 'red'}
          subtitle="Overall SLA compliance"
          onClick={() => navigate('/slas')}
        /> 
        */}       
      </div>

      {/* Enhanced SLA Compliance Dashboard */}
      <div className="mt-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">SLA Compliance Overview</h2>
        <EnhancedSLADashboard />
      </div>

      {/* Charts and Alerts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts */}
        <Card title="Recent Alerts" subtitle="Latest SLA alerts and notifications">
          <AlertList limit={5} />
        </Card>

        {/* SLA Compliance Chart */}
        <Card title="SLA Compliance Trend" subtitle="30-day compliance overview">
          <SLAComplianceChart />
        </Card>
      </div>
      
      {/* Service Health Section */} 
      <Card title="Service Health" subtitle="Overview of all monitored services">
        {/* Search and Filters */}
        <div className="mb-6 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
            />
          </div>

          {/* Filters Row */}
          <div className="flex flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <FiFilter className="text-gray-400" />
              
              {/* Monitoring Method Filter - FIRST */}
              <select
                value={filterMonitoring}
                onChange={(e) => setFilterMonitoring(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm font-semibold"
              >
                <option value="direct">Direct Monitoring</option>
                <option value="indirect">Indirect Monitoring</option>
              </select>
            </div>

            {/* Show type/status/owner filters ONLY for direct monitoring */}
            {filterMonitoring === 'direct' && (
              <>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Types</option>
                  <option value="etl_batch">ETL Batch Job</option>
                  <option value="api_gateway">API Gateway</option>
                  <option value="microservice">Microservice</option>
                  <option value="mysql">MySQL Database</option>
                  <option value="postgresql">PostgreSQL Database</option>
                  <option value="mongodb">MongoDB Database</option>
                  <option value="oracle">Oracle Database</option>
                  <option value="mssql">Microsoft SQL Server</option>
                  <option value="kafka">Kafka</option>
                  <option value="ibm_mq">IBM MQ</option>
                  <option value="rabbitmq">RabbitMQ</option>
                  <option value="spark_streaming">Spark Streaming</option>
                  <option value="flink">Apache Flink</option>
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Status</option>
                  <option value="healthy">Healthy</option>
                  <option value="unhealthy">Unhealthy</option>
                  <option value="unknown">Unknown</option>
                </select>

                <select
                  value={filterOwner}
                  onChange={(e) => setFilterOwner(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Teams</option>
                  {uniqueOwnerTeams.map(team => (
                    <option key={team} value={team}>{team}</option>
                  ))}
                </select>

                <select
                  value={filterAsset}
                  onChange={(e) => setFilterAsset(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Assets</option>
                  {assets.map(asset => (
                    <option key={asset.asset_id} value={asset.asset_id}>
                      {asset.asset_name}
                    </option>
                  ))}
                </select>

                <select
                  value={filterDeployment}
                  onChange={(e) => setFilterDeployment(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Deployments</option>
                  {uniqueDeploymentLocations.map(location => (
                    <option key={location} value={location}>
                      {location === 'autosys' ? 'Autosys' : 
                       location === 'airflow' ? 'Airflow' : 
                       location === 'ansible_tower' ? 'Ansible Tower' : location}
                    </option>
                  ))}
                </select>
              </>
            )}

            {/* Show only deployment filter for indirect monitoring */}
            {filterMonitoring === 'indirect' && (
              <>
                <select
                  value={filterAssetName}
                  onChange={(e) => setFilterAssetName(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Assets</option>
                  {uniqueAssetNames.map(name => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>

                <select
                  value={filterServiceName}
                  onChange={(e) => setFilterServiceName(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Services</option>
                  {uniqueServiceNames.map(name => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>

                <select
                  value={filterJobName}
                  onChange={(e) => setFilterJobName(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Jobs</option>
                  {uniqueJobNames.map(name => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>

                <select
                  value={filterJobType}
                  onChange={(e) => setFilterJobType(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Job Types</option>
                  {uniqueJobTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>

                <select
                  value={filterDeployment}
                  onChange={(e) => setFilterDeployment(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All Deployments</option>
                  {uniqueDeploymentLocations.map(location => (
                    <option key={location} value={location}>
                      {location === 'autosys' ? 'Autosys' : 
                       location === 'airflow' ? 'Airflow' : 
                       location === 'ansible_tower' ? 'Ansible Tower' : location}
                    </option>
                  ))}
                </select>

                <select
                  value={filterOnTime}
                  onChange={(e) => setFilterOnTime(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 text-sm"
                >
                  <option value="all">All On-Time Status</option>
                  {uniqueOnTimeStatuses.map(status => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
              </>
            )}
          </div>

          {/* Active filters count */}
          {filterMonitoring === 'direct' && (searchTerm || filterType !== 'all' || filterStatus !== 'all' || filterOwner !== 'all' || filterAsset !== 'all' || filterDeployment !== 'all') && (
            <div className="text-sm text-gray-600">
              Showing {filteredServices.length} of {services.length} services
            </div>
          )}
          
          {filterMonitoring === 'indirect' && (
            <div className="text-sm text-gray-600">
              Showing {filteredIndirectServices.length} of {indirectServices.length} jobs 
              (Page {indirectPagination.page} of {indirectPagination.total_pages}, {indirectPagination.total} total records)
            </div>
          )}
        </div>

        {/* DIRECT MONITORING TABLE */}
        {filterMonitoring === 'direct' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Asset
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Health
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Uptime
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Owner
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Monitor Method
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Deployment
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    SLA Count
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Alerts
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredServices.length === 0 ? (
                  <tr>
                    <td colSpan="10" className="px-6 py-12 text-center text-gray-500">
                      No services found matching the filters
                    </td>
                  </tr>
                ) : (
                  filteredServices.map((service) => (
                    <tr 
                      key={service.service_id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => navigate(`/services/${service.service_id}`)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-primary-600 hover:text-primary-700">
                          {service.name}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{getServiceTypeName(service)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div 
                          className="text-sm text-primary-600 hover:text-primary-700 cursor-pointer"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (service.asset_id) navigate(`/assets/${service.asset_id}`);
                          }}
                        >
                          {getAssetName(service.asset_id)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full
                          ${service.health_status === 'healthy' ? 'bg-green-100 text-green-800' : 
                            service.health_status === 'unhealthy' ? 'bg-red-100 text-red-800' : 
                            'bg-gray-100 text-gray-800'}`}>
                          {service.health_status || 'Unknown'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.uptime_percentage ? `${service.uptime_percentage.toFixed(1)}%` : 'N/A'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.owner_team || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {service.monitoring_method || service.metadata?.monitoring_method || 'Direct'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.deployment_location || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {service.sla_count || 0}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {service.alertCount > 0 ? (
                          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                            {service.alertCount}
                          </span>
                        ) : (
                          <span className="text-sm text-gray-500">0</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* INDIRECT MONITORING TABLE */}
        {filterMonitoring === 'indirect' && (
          <>
            {indirectLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto"></div>
                <p className="mt-4 text-gray-600">Loading scheduled jobs...</p>
              </div>
            ) : (
              <>
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200" style={{ minWidth: '1800px' }}>
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Asset Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Service Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Job Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Job Type</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Deployment</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Schedule</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Sched. Date</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Sched. Start</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Sched. End</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Duration</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Start Time</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">End Time</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">On-Time</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Monitor Method</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">SLA Count</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Active Alerts</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredIndirectServices.length === 0 ? (
                        <tr>
                          <td colSpan="16" className="px-6 py-12 text-center text-gray-500">
                            {indirectServices.length === 0 
                              ? "No scheduled jobs found. Make sure job monitoring service is running and has populated data."
                              : "No jobs match the selected filters."}
                          </td>
                        </tr>
                      ) : (
                        filteredIndirectServices.map((job) => (
                          <tr key={job.id} className="hover:bg-gray-50">
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div 
                                className="text-sm text-primary-600 hover:text-primary-700 cursor-pointer"
                                onClick={() => job.asset_id && navigate(`/assets/${job.asset_id}`)}
                              >
                                {job.asset_name || '-'}
                              </div>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div 
                                className="text-sm font-medium text-primary-600 hover:text-primary-700 cursor-pointer"
                                onClick={() => navigate(`/services/${job.service_id}`)}
                              >
                                {job.service_name}
                              </div>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{job.job_name}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                                {job.job_type}
                              </span>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{job.deployment_location || '-'}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">{job.job_schedule}</code>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{formatDate(job.scheduled_execution_date)}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{formatTime(job.scheduled_start_time)}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{formatTime(job.scheduled_end_time)}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{job.scheduled_execution_duration}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{job.start_time ? formatTime(job.start_time) : '-'}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{job.end_time ? formatTime(job.end_time) : '-'}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getOnTimeColor(job.on_time_ind)}`}>
                                {job.on_time_ind || 'Unknown'}
                              </span>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                Indirect
                              </span>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{job.sla_count || 0}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {job.active_alerts > 0 ? (
                                <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                  {job.active_alerts}
                                </span>
                              ) : (
                                <span className="text-sm text-gray-500">0</span>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Pagination - Always show for indirect monitoring */}
                <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-200">
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-gray-700">
                      Showing page {indirectPagination.page} of {indirectPagination.total_pages || 1}
                      {' '}({indirectPagination.total} total records)
                    </div>
                    
                    {/* Page Size Selector */}
                    <div className="flex items-center gap-2">
                      <label htmlFor="pageSize" className="text-sm text-gray-700">
                        Rows per page:
                      </label>
                      <select
                        id="pageSize"
                        value={indirectPagination.limit}
                        onChange={(e) => handlePageSizeChange(e.target.value)}
                        className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => handlePageChange(indirectPagination.page - 1)}
                      disabled={indirectPagination.page === 1}
                      className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Previous
                    </button>
                    <button
                      onClick={() => handlePageChange(indirectPagination.page + 1)}
                      disabled={indirectPagination.page >= indirectPagination.total_pages}
                      className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </Card>
    </div>
  );
};

export default Dashboard;
