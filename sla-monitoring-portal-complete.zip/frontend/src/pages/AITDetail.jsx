import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Building2, Edit, Trash2, Plus } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';
import { getAssetTypeName, getAssetTypeIcon } from '../constants/assetTypes';

const AITDetail = () => {
  const { aitId } = useParams();
  const navigate = useNavigate();
  const [ait, setAit] = useState(null);
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    fetchAITDetails();
    fetchAITAssets();
  }, [aitId]);

  const fetchAITDetails = async () => {
    try {
      const response = await fetch(`/api/v1/aits/${aitId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      const data = await response.json();
      if (data.success) {
        setAit(data.ait);
        setFormData(data.ait);
      }
    } catch (error) {
      console.error('Error fetching AIT:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAITAssets = async () => {
    try {
      const response = await fetch(`/api/v1/aits/${aitId}/assets`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      const data = await response.json();
      if (data.success) {
        setAssets(data.assets);
      }
    } catch (error) {
      console.error('Error fetching assets:', error);
    }
  };

  const handleUpdateAIT = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`/api/v1/aits/${aitId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(formData)
      });
      
      const data = await response.json();
      if (data.success) {
        setShowEditModal(false);
        fetchAITDetails();
      }
    } catch (error) {
      console.error('Error updating AIT:', error);
    }
  };

  const handleDeleteAIT = async () => {
    if (!window.confirm('Are you sure you want to delete this AIT? This action cannot be undone.')) return;
    
    try {
      const response = await fetch(`/api/v1/aits/${aitId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      const data = await response.json();
      if (data.success) {
        navigate('/aits');
      } else {
        alert(data.error || 'Failed to delete AIT');
      }
    } catch (error) {
      console.error('Error deleting AIT:', error);
      alert('Failed to delete AIT');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading AIT details...</div>
      </div>
    );
  }

  if (!ait) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg">
          AIT not found
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={() => navigate('/aits')}
          className="flex items-center text-blue-600 hover:text-blue-800 mb-4"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to AITs
        </button>
        
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
              <Building2 size={32} />
              {ait.name}
            </h1>
            {ait.short_name && (
              <p className="text-gray-600 mt-2">({ait.short_name})</p>
            )}
            {ait.description && (
              <p className="text-gray-600 mt-2">{ait.description}</p>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              onClick={() => setShowEditModal(true)}
              className="flex items-center gap-2"
            >
              <Edit size={18} />
              Edit
            </Button>
            <Button
              variant="danger"
              onClick={handleDeleteAIT}
              className="flex items-center gap-2"
            >
              <Trash2 size={18} />
              Delete
            </Button>
          </div>
        </div>
      </div>

      {/* AIT Information */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <div className="p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">Cost Center</h3>
            <p className="text-lg font-semibold text-gray-800">
              {ait.cost_center || 'N/A'}
            </p>
          </div>
        </Card>
        
        <Card>
          <div className="p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">Tech Support</h3>
            <p className="text-lg font-semibold text-gray-800">
              {ait.tech_support_contact || 'N/A'}
            </p>
          </div>
        </Card>
        
        <Card>
          <div className="p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">Status</h3>
            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
              ait.status === 1 
                ? 'bg-green-100 text-green-800' 
                : 'bg-gray-100 text-gray-800'
            }`}>
              {ait.status === 1 ? 'Active' : 'Inactive'}
            </span>
          </div>
        </Card>
      </div>

      {/* Applications (Assets) */}
      <Card>
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Applications</h2>
            <Button
              onClick={() => navigate('/onboarding?step=2&ait_id=' + aitId)}
              className="flex items-center gap-2"
            >
              <Plus size={18} />
              Add Application
            </Button>
          </div>

          {assets.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <p>No applications found for this AIT.</p>
              <p className="text-sm mt-2">Add your first application to get started.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Owner
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {assets.map((asset) => (
                    <tr key={asset.asset_id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <span className="text-2xl mr-3">{getAssetTypeIcon(asset.asset_type)}</span>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {asset.asset_name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {asset.description}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {getAssetTypeName(asset.asset_type)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {asset.asset_owner || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          asset.status === 'active'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {asset.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => navigate(`/assets/${asset.asset_id}`)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </Card>

      {/* Edit Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Edit AIT</h2>
            <form onSubmit={handleUpdateAIT}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name *
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Short Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.short_name || ''}
                    onChange={(e) => setFormData({ ...formData, short_name: e.target.value })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Cost Center
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.cost_center || ''}
                    onChange={(e) => setFormData({ ...formData, cost_center: e.target.value })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tech Support Contact
                  </label>
                  <input
                    type="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.tech_support_contact || ''}
                    onChange={(e) => setFormData({ ...formData, tech_support_contact: e.target.value })}
                  />
                </div>
              </div>
              
              <div className="flex justify-end gap-4 mt-6">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => setShowEditModal(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">
                  Save Changes
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AITDetail;
