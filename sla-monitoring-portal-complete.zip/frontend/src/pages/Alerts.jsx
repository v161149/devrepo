import React from 'react';
import Card from '../components/Card';
import AlertList from '../components/AlertList';

const Alerts = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Alerts</h1>
      <Card title="Active Alerts" subtitle="Monitor and manage SLA alerts">
        <AlertList />
      </Card>
    </div>
  );
};

export default Alerts;
