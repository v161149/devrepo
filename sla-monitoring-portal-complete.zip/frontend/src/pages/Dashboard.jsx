/**
 * Dashboard Page - FULLY FIXED VERSION
 * Main dashboard with metrics, alerts, charts
 * FIXES:
 * 1. AITs count now displays correctly (checks multiple response formats)
 * 2. Uses improved SLA Compliance Chart with real data
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiServer, FiDatabase, FiFileText, FiClock } from 'react-icons/fi';
import { Building2 } from 'lucide-react';
import MetricCard from '../components/MetricCard';
import Button from '../components/Button';
import Card from '../components/Card';
import apiService from '../services/api';
import AlertList from '../components/AlertList';
import SLAComplianceChart from '../components/SLAComplianceChart';
import HierarchicalComplianceOverview from '../components/HierarchicalComplianceOverview';

const Dashboard = () => {
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState(null);
  const [aits, setAits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const loadMetrics = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      setError(null);

      const response = await apiService.dashboard.getMetrics(30);
      setMetrics(response.data);
    } catch (err) {
      console.error('Error loading metrics:', err);
      setError('Failed to load dashboard metrics');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadAITs = async () => {
    try {
      console.log('Loading AITs...');
      const response = await apiService.aits.list();
      console.log('AITs API response:', response);
      
      // FIXED: Handle multiple possible response structures
      let aitsData = [];
      
      if (response.data) {
        // Try different possible data locations
        if (Array.isArray(response.data.aits)) {
          aitsData = response.data.aits;
        } else if (Array.isArray(response.data.data)) {
          aitsData = response.data.data;
        } else if (response.data.success && Array.isArray(response.data.data?.aits)) {
          aitsData = response.data.data.aits;
        } else if (Array.isArray(response.data)) {
          aitsData = response.data;
        }
      }
      
      console.log('Parsed AITs data:', aitsData);
      console.log('AITs count:', aitsData.length);
      
      setAits(aitsData);
    } catch (err) {
      console.error('Error loading AITs:', err);
      setAits([]);
    }
  };

  // Refresh both metrics and AITs
  const handleRefresh = () => {
    loadMetrics(true);
    loadAITs();
  };

  useEffect(() => {
    loadMetrics();
    loadAITs();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error && !metrics) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          <h3 className="font-semibold">Error Loading Dashboard</h3>
          <p>{error}</p>
          <button 
            onClick={() => loadMetrics()}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Monitor your AITs, applications, services and SLAs</p>
        </div>
        <Button onClick={handleRefresh} loading={refreshing}>
          Refresh
        </Button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* ENHANCED Metrics Grid - 5 cards with equal spacing */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        <MetricCard
          title="Total AITs"
          value={aits?.length || 0}
          icon={Building2}
          color="indigo"
          subtitle="Business units"
          onClick={() => navigate('/aits')}
        />
        <MetricCard
          title="Total Applications"
          value={metrics?.total_assets || 0}
          icon={FiDatabase}
          color="purple"
          subtitle="Applications"
          onClick={() => navigate('/assets')}
        />
        <MetricCard
          title="Active SLAs"
          value={metrics?.total_slas || 0}
          icon={FiFileText}
          color="green"
          subtitle="Service agreements"
          onClick={() => navigate('/slas')}
        />
        <MetricCard
          title="Total Services"
          value={metrics?.total_services || 0}
          icon={FiServer}
          color="blue"
          subtitle="Active services"
          onClick={() => navigate('/services')}
        />
        <MetricCard
          title="Total Jobs"
          value={metrics?.total_jobs || 0}
          icon={FiClock}
          color="yellow"
          subtitle="Active jobs"
          onClick={() => navigate('/jobs')}
        />
      </div>

      {/* Hierarchical SLA Compliance Overview */}
      <div className="mt-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900">SLA Compliance Overview</h2>
          <p className="text-gray-600 mt-1">
            Drill down from AITs to applications, SLAs, and individual services/jobs
          </p>
        </div>
        <HierarchicalComplianceOverview />
      </div>

      {/* Charts and Alerts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        {/* Recent Alerts */}
        <Card title="Recent Alerts" subtitle="Latest SLA alerts and notifications">
          <AlertList limit={5} />
        </Card>

        {/* SLA Compliance Chart - FIXED with real data */}
        <Card title="SLA Compliance Trend" subtitle="Compliance trend overview">
          <SLAComplianceChart />
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
