/**
 * ServiceDetails Page - FIXED
 * View and edit service configuration
 * 
 * CHANGES:
 * - Added Link to Asset display (read-only)
 * - Added Log Monitoring Configuration section matching Step2
 * - Added log connectors loading from API
 * - Added log template presets
 * - Updated metadata saving to include log fields
 */

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiEdit2, FiSave, FiX, FiCheck, FiAlertCircle, FiTrash2, FiPlus, FiClock } from 'react-icons/fi';
import Card from '../components/Card';
import Button from '../components/Button';
import SLAList from '../components/SLAList';
import CreateJobModal from '../components/CreateJobModal';
import apiService from '../services/api';
import SLACompliancePanel from '../components/SLACompliancePanel';

// Service types matching Step2
const SERVICE_TYPES = [
  { id: 'web_service', name: 'Web Service' },
  { id: 'api', name: 'API' },
  { id: 'database', name: 'Database' },
  { id: 'application', name: 'Application' },
  { id: 'microservice', name: 'Microservice' },
  { id: 'batch_job', name: 'Batch Job' },
  { id: 'queue', name: 'Message Queue' },
  { id: 'cache', name: 'Cache Service' },
  { id: 'storage', name: 'Storage Service' },
  { id: 'other', name: 'Other' }
];

// Log template presets matching Step2
const LOG_TEMPLATE_PRESETS = {
  'uptime_availability': {
    name: 'Uptime / Availability',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    }
  },
  'performance': {
    name: 'Performance Metrics',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      response_time_ms: '{{response_time}}',
      cpu_usage: '{{cpu}}',
      memory_usage: '{{memory}}',
      timestamp: '{{timestamp}}'
    }
  },
  'error_tracking': {
    name: 'Error Tracking',
    template: {
      identifier: '{{service_identifier}}',
      status: '{{status}}',
      error_count: '{{errors}}',
      error_rate: '{{error_rate}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    }
  },
  'custom': {
    name: 'Custom Template',
    template: {
      identifier: '{{service_identifier}}',
      timestamp: '{{timestamp}}'
    }
  }
};

// Helper function to get service type display name
const getServiceTypeName = (serviceTypeId) => {
  if (!serviceTypeId) return 'N/A';
  const type = SERVICE_TYPES.find(t => t.id === serviceTypeId);
  return type ? type.name : serviceTypeId.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

const ServiceDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [service, setService] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  
  const [jobs, setJobs] = useState([]);
  const [slas, setSlas] = useState([]);
  const [showAddJobModal, setShowAddJobModal] = useState(false);
  
  // NEW: Log monitoring states
  const [logConnectors, setLogConnectors] = useState([]);
  const [showLogConfig, setShowLogConfig] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState('');
  const [linkedAsset, setLinkedAsset] = useState(null);

  const [editData, setEditData] = useState({
    name: '',
    description: '',
    service_type: '',
    status: 'active',
    // NEW: Log monitoring fields
    service_identifier: '',
    log_server_type: '',
    log_template: ''
  });

  useEffect(() => {
    if (id) {
      loadService();
      loadLogConnectors();
    }
  }, [id]);

  const loadService = async () => {
    try {
      setLoading(true);
      const response = await apiService.services.getById(id);
      const serviceData = response.data;
      
      // Parse metadata
      let metadata = {};
      try {
        metadata = typeof serviceData.metadata === 'string' 
          ? JSON.parse(serviceData.metadata) 
          : serviceData.metadata || {};
      } catch (e) {
        console.error('Error parsing service metadata:', e);
      }
      
      setService(serviceData);
      setEditData({
        name: serviceData.name || '',
        description: serviceData.description || '',
        service_type: metadata.service_type || '',
        status: serviceData.is_active !== false ? 'active' : 'inactive',
        // FIXED: Log fields from top-level properties (not metadata)
        service_identifier: serviceData.service_identifier || '',
        log_server_type: serviceData.log_server_type || '',
        log_template: serviceData.log_template || ''
      });
      
      // Check if log config exists (from top-level properties)
      if (serviceData.service_identifier || serviceData.log_server_type || serviceData.log_template) {
        setShowLogConfig(true);
      }
      
      // Load linked asset
      if (serviceData.asset_id) {
        loadLinkedAsset(serviceData.asset_id);
      }
      
      await fetchJobs();
      await fetchSLAs();
    } catch (err) {
      console.error('Error loading service:', err);
      setError('Failed to load service details');
    } finally {
      setLoading(false);
    }
  };

  const loadLinkedAsset = async (assetId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:5000/api/v1/assets/${assetId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setLinkedAsset(data);
      }
    } catch (err) {
      console.error('Error loading linked asset:', err);
    }
  };

  const loadLogConnectors = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        setLogConnectors(Array.isArray(result.data) ? result.data : []);
      }
    } catch (err) {
      console.error('Error loading log connectors:', err);
      setLogConnectors([]);
    }
  };

  const fetchJobs = async () => {
    try {
      const response = await apiService.jobs.getAll();
      const allJobs = response.data?.data || response.data || [];
      const serviceJobs = allJobs.filter(job => job.service_id === id);
      setJobs(serviceJobs);
    } catch (err) {
      console.error('Error fetching jobs:', err);
      setJobs([]);
    }
  };

  const fetchSLAs = async () => {
    try {
      const response = await apiService.slas.getAll();
      const allSLAs = response.data?.data || response.data || [];
      const serviceSLAs = allSLAs.filter(sla => sla.service_id === id && !sla.job_id);
      setSlas(serviceSLAs);
    } catch (err) {
      console.error('Error fetching SLAs:', err);
      setSlas([]);
    }
  };

  const handleJobAdded = () => {
    fetchJobs();
  };

  const handlePresetLoad = (presetKey) => {
    setSelectedPreset(presetKey);
    if (presetKey && LOG_TEMPLATE_PRESETS[presetKey]) {
      const preset = LOG_TEMPLATE_PRESETS[presetKey];
      setEditData({
        ...editData,
        log_template: JSON.stringify(preset.template, null, 2)
      });
    }
  };

  const validateLogTemplate = (template) => {
    if (!template) return true;
    try {
      JSON.parse(template);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');

    // Validate required fields
    if (!editData.name.trim()) {
      setError('Service name is required');
      setSaving(false);
      return;
    }

    if (!editData.service_type) {
      setError('Service type is required');
      setSaving(false);
      return;
    }

    // Validate log template if provided
    if (editData.log_template && !validateLogTemplate(editData.log_template)) {
      setError('Invalid log template JSON format');
      setSaving(false);
      return;
    }

    try {
      // Build payload with log fields as top-level properties
      const payload = {
        name: editData.name,
        description: editData.description,
        is_active: editData.status === 'active',
        metadata: {
          service_type: editData.service_type
        }
      };

      // Add log monitoring fields as top-level properties
      if (editData.service_identifier) {
        payload.service_identifier = editData.service_identifier;
      }
      if (editData.log_server_type) {
        payload.log_server_type = editData.log_server_type;
      }
      if (editData.log_template) {
        payload.log_template = editData.log_template;
      }

      await apiService.services.update(id, payload);

      await loadService();
      setEditing(false);
    } catch (err) {
      console.error('Error saving service:', err);
      setError(err.response?.data?.error || 'Failed to save service');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this service? This action cannot be undone.')) {
      return;
    }

    try {
      await apiService.services.delete(id);
      navigate('/services');
    } catch (err) {
      console.error('Error deleting service:', err);
      setError('Failed to delete service');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading service details...</div>
      </div>
    );
  }

  if (!service) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Service not found</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/services')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <FiArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{service.name}</h1>
            <p className="text-sm text-gray-500">{service.service_id}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {!editing ? (
            <>
              <Button
                variant="outline"
                icon={FiEdit2}
                onClick={() => setEditing(true)}
              >
                Edit
              </Button>
              <Button
                variant="danger"
                icon={FiTrash2}
                onClick={handleDelete}
              >
                Delete
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                icon={FiX}
                onClick={() => {
                  setEditing(false);
                  setError('');
                  loadService(); // Reload to reset changes
                }}
              >
                Cancel
              </Button>
              <Button
                icon={FiSave}
                onClick={handleSave}
                loading={saving}
              >
                Save Changes
              </Button>
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <FiAlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Error</p>
            <p className="text-sm text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}

      {/* Basic Information */}
      <Card title="Basic Information">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Service Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Service Name <span className="text-red-500">*</span>
            </label>
            {editing ? (
              <input
                type="text"
                value={editData.name}
                onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                required
              />
            ) : (
              <p className="text-gray-900">{service.name}</p>
            )}
          </div>

          {/* Service Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Service Type <span className="text-red-500">*</span>
            </label>
            {editing ? (
              <select
                value={editData.service_type}
                onChange={(e) => setEditData({ ...editData, service_type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                required
              >
                <option value="">Select type...</option>
                {SERVICE_TYPES.map(type => (
                  <option key={type.id} value={type.id}>{type.name}</option>
                ))}
              </select>
            ) : (
              <p className="text-gray-900">{getServiceTypeName(editData.service_type)}</p>
            )}
          </div>

          {/* Link to Asset (Read-only) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Link to Asset
            </label>
            <p className="text-gray-900">{linkedAsset?.asset_name || 'No asset linked'}</p>
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
            {editing ? (
              <select
                value={editData.status}
                onChange={(e) => setEditData({ ...editData, status: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            ) : (
              <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                service.is_active !== false
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {service.is_active !== false ? 'Active' : 'Inactive'}
              </span>
            )}
          </div>

          {/* Description */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            {editing ? (
              <textarea
                value={editData.description}
                onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                rows="3"
                placeholder="Optional description..."
              />
            ) : (
              <p className="text-gray-900">{service.description || 'No description'}</p>
            )}
          </div>
        </div>

        {/* Log Monitoring Configuration (Only show in edit mode) */}
        {editing && (
          <div className="border-t border-gray-200 pt-6 mt-6">
            <button
              type="button"
              onClick={() => setShowLogConfig(!showLogConfig)}
              className="flex items-center justify-between w-full text-left mb-3 hover:bg-gray-50 p-2 rounded transition-colors"
            >
              <span className="text-sm font-medium text-gray-700">
                {showLogConfig ? '▼' : '▶'} Log Monitoring Configuration (Optional)
              </span>
            </button>

            {showLogConfig && (
              <div className="space-y-4 pl-4 border-l-2 border-primary-200">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                  <div className="flex items-start gap-2">
                    <FiAlertCircle className="text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-blue-800">
                      Configure log-based monitoring for this service. Set up log server connectors in <strong>Tools → Log Server Setup</strong>.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Service Identifier */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Service Identifier
                    </label>
                    <input
                      type="text"
                      value={editData.service_identifier}
                      onChange={(e) => setEditData({ ...editData, service_identifier: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                      placeholder="e.g., WEB-SRV-001"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Unique identifier used in log entries
                    </p>
                  </div>

                  {/* Log Server Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Log Server Type
                    </label>
                    <select
                      value={editData.log_server_type}
                      onChange={(e) => setEditData({ ...editData, log_server_type: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="">Select log server...</option>
                      {logConnectors.length === 0 ? (
                        <option value="" disabled>No log servers configured</option>
                      ) : (
                        logConnectors
                          .filter(c => c.is_active)
                          .map(connector => (
                            <option key={connector.connector_id} value={connector.log_server_type}>
                              {connector.connector_name} ({connector.log_server_type})
                            </option>
                          ))
                      )}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">
                      Select the log server where this service sends logs
                    </p>
                  </div>

                  {/* Log Template */}
                  <div className="col-span-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-sm font-medium text-gray-700">
                        Log Entry Template
                      </label>
                      <div className="flex items-center gap-2">
                        <select
                          value={selectedPreset}
                          onChange={(e) => handlePresetLoad(e.target.value)}
                          className="text-xs px-2 py-1 border border-gray-300 rounded"
                        >
                          <option value="">Load Preset...</option>
                          {Object.entries(LOG_TEMPLATE_PRESETS).map(([key, preset]) => (
                            <option key={key} value={key}>{preset.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <textarea
                      value={editData.log_template}
                      onChange={(e) => setEditData({ ...editData, log_template: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                      rows={8}
                      placeholder='{\n  "identifier": "{{service_identifier}}",\n  "status": "{{status}}",\n  "timestamp": "{{timestamp}}"\n}'
                    />
                    {editData.log_template && !validateLogTemplate(editData.log_template) && (
                      <p className="text-sm text-red-600 mt-1">Invalid JSON format</p>
                    )}
                    <p className="text-xs text-gray-500 mt-1">
                      This template must match the format your service uses in log entries
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Associated Jobs */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Associated Jobs</h2>
          <Button 
            icon={FiPlus} 
            size="sm"
            onClick={() => setShowAddJobModal(true)}
          >
            Add Job
          </Button>
        </div>

        {jobs.length === 0 ? (
          <div className="text-center py-8 text-gray-600">
            <FiClock className="mx-auto text-6xl text-gray-300 mb-4" />
            <p>No jobs associated with this service yet.</p>
            <Button 
              icon={FiPlus} 
              className="mt-4"
              onClick={() => setShowAddJobModal(true)}
            >
              Add First Job
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Job Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Schedule
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {jobs.map((job) => (
                  <tr 
                    key={job.job_id}
                    className="hover:bg-gray-50 cursor-pointer"
                    onClick={() => navigate(`/jobs/${job.job_id}`)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {job.job_name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {job.job_type}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-mono">
                      {job.schedule || 'Not scheduled'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        job.is_active !== false
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {job.is_active !== false ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-primary-600">
                      View Details →
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* SLA Compliance */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">SLA Compliance</h2>
        </div>
        <SLACompliancePanel serviceId={id} />
      </Card>

      {/* SLA List */}
      <SLAList 
        serviceId={id}
        slas={slas}
        onSLAUpdated={fetchSLAs}
      />

      {/* Add Job Modal */}
      <CreateJobModal
        isOpen={showAddJobModal}
        onClose={() => setShowAddJobModal(false)}
        onSuccess={handleJobAdded}
        preselectedServiceId={id}
      />
    </div>
  );
};

export default ServiceDetails;
