/**
 * BulkStep3_SelectJobConnector.jsx
 * 
 * Step 3 of Bulk Onboarding Wizard (OPTIONAL)
 * - Lists available job connectors
 * - Educational message about asset_id XOR service_id requirement
 * - Allows user to skip this step
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiZap, FiAlertCircle, FiSettings, FiCheck, FiSkipForward } from 'react-icons/fi';
import Button from '../../components/Button';
import ConnectorSelector from './shared/ConnectorSelector';

const BulkStep3_SelectJobConnector = ({
  jobs,
  selectedConnector,
  existingAssets,
  existingServices,
  onDataImported,
  onSkip
}) => {
  const navigate = useNavigate();
  const [connectors, setConnectors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchJobConnectors();
  }, []);

  const fetchJobConnectors = async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        'http://localhost:5000/api/v1/connectors?type=job',
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch job connectors');
      }

      const data = await response.json();
      setConnectors(data.data || []);
    } catch (err) {
      console.error('Error fetching job connectors:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleImportData = async (connector) => {
    try {
      const token = localStorage.getItem('token');
      const connectorId = connector.id || connector.connector_id;
      
      console.log('Fetching data from connector:', connectorId);
      
      // Use /fetch endpoint to get data from connector (doesn't import to DB yet)
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}/fetch`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            filters: {} // Optional filters
          })
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to fetch data from connector');
      }

      const result = await response.json();
      console.log('Fetched data:', result);

      // Backend now applies field mappings, use data directly
      const fetchedJobs = result.data || [];

      if (fetchedJobs.length === 0) {
        throw new Error('No data returned from connector');
      }

      // Validate: Each job must have EITHER asset_id OR service_id (not both, not neither)
      const assetIds = existingAssets.map(a => a.asset_id);
      const serviceIds = existingServices.map(s => s.service_id);

      const invalidJobs = fetchedJobs.filter(job => {
        const hasAsset = job.asset_id && assetIds.includes(job.asset_id);
        const hasService = job.service_id && serviceIds.includes(job.service_id);

        // Must have exactly one (XOR logic)
        if (hasAsset && hasService) return true; // Both - invalid
        if (!hasAsset && !hasService) return true; // Neither - invalid
        return false; // Exactly one - valid
      });

      if (invalidJobs.length > 0) {
        throw new Error(
          `${invalidJobs.length} job(s) have invalid linking. Each job must have EITHER asset_id OR service_id (not both).`
        );
      }

      // Pass normalized data back to wizard (will be imported in Step 5)
      onDataImported(fetchedJobs, connector);
      
      return { success: true, count: fetchedJobs.length };
    } catch (err) {
      console.error('Error fetching data:', err);
      throw err;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading job connectors...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <div className="flex items-start">
          <FiAlertCircle className="text-red-600 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-red-900 mb-2">Error Loading Connectors</h3>
            <p className="text-red-700 mb-4">{error}</p>
            <Button onClick={fetchJobConnectors} variant="outline">
              Try Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Empty state
  if (connectors.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-orange-100 rounded-full mb-6">
          <FiZap className="w-10 h-10 text-orange-600" />
        </div>

        <h2 className="text-2xl font-semibold text-gray-900 mb-4">
          No Job Connectors Found
        </h2>

        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          To bulk import jobs, you need to create a job connector first.
        </p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 max-w-2xl mx-auto">
          <div className="flex items-start">
            <FiSettings className="text-blue-600 mr-3 mt-1 flex-shrink-0" />
            <div className="text-left">
              <h4 className="font-semibold text-gray-900 mb-2">Setup Required</h4>
              <p className="text-sm text-gray-700 mb-3">
                Go to <strong>Tools → Metadata Retrieval</strong> to create a job connector. 
                Available platforms:
              </p>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• <strong>Autosys</strong> - Import jobs from Autosys scheduler</li>
                <li>• <strong>Ansible Tower</strong> - Import job templates</li>
                <li>• <strong>Custom API</strong> - Connect to your REST API</li>
                <li>• <strong>Demo Simulators</strong> - Test with sample data</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center space-x-4">
          <Button variant="outline" onClick={onSkip}>
            <FiSkipForward className="mr-2" />
            Skip This Step
          </Button>
          <Button onClick={() => navigate('/tools/metadata-retrieval')}>
            <FiSettings className="mr-2" />
            Setup Job Connector
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Step 3: Import Jobs (Optional)
        </h2>
        <p className="text-gray-600">
          Select a job connector to import scheduled jobs and batch processes. This step is optional.
        </p>
      </div>

      {/* Success message */}
      {jobs.length > 0 && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <FiCheck className="text-green-600 mr-3 flex-shrink-0" />
            <div>
              <p className="font-medium text-green-900">
                {jobs.length} job{jobs.length !== 1 ? 's' : ''} imported successfully
              </p>
              {selectedConnector && (
                <p className="text-sm text-green-700 mt-1">
                  From: {selectedConnector.connector_name}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Educational Note - IMPORTANT */}
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <FiAlertCircle className="text-orange-600 mr-3 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-orange-900">
            <p className="font-medium mb-1">⚠️ Important: Job Linking Requirement</p>
            <p>
              <strong>Each job must link to EITHER an asset OR a service (not both).</strong>
            </p>
            <ul className="mt-2 space-y-1">
              <li>• Jobs linked to <strong>assets</strong>: Set asset_id, leave service_id empty</li>
              <li>• Jobs linked to <strong>services</strong>: Set service_id, leave asset_id empty</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Available References */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <p className="text-sm font-medium text-gray-900 mb-2">
            Available Assets ({existingAssets.length}):
          </p>
          <div className="space-y-1">
            {existingAssets.slice(0, 3).map((asset, idx) => (
              <div key={idx} className="text-xs text-gray-700">
                {asset.asset_name} ({asset.asset_id})
              </div>
            ))}
            {existingAssets.length > 3 && (
              <div className="text-xs text-gray-500">
                +{existingAssets.length - 3} more
              </div>
            )}
          </div>
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <p className="text-sm font-medium text-gray-900 mb-2">
            Available Services ({existingServices.length}):
          </p>
          {existingServices.length > 0 ? (
            <div className="space-y-1">
              {existingServices.slice(0, 3).map((service, idx) => (
                <div key={idx} className="text-xs text-gray-700">
                  {service.service_name || service.name} ({service.service_id})
                </div>
              ))}
              {existingServices.length > 3 && (
                <div className="text-xs text-gray-500">
                  +{existingServices.length - 3} more
                </div>
              )}
            </div>
          ) : (
            <div className="text-xs text-gray-500 italic">
              No services imported in Step 2
            </div>
          )}
        </div>
      </div>

      <ConnectorSelector
        connectors={connectors}
        selectedConnector={selectedConnector}
        onImportData={handleImportData}
        connectorType="job"
      />

      {/* Skip button */}
      <div className="mt-6 text-center">
        <Button variant="outline" onClick={onSkip}>
          <FiSkipForward className="mr-2" />
          Skip Job Import
        </Button>
      </div>
    </div>
  );
};

export default BulkStep3_SelectJobConnector;
