/**
 * BulkStep5_ReviewData.jsx
 * 
 * Step 5 of Bulk Onboarding Wizard
 * - Review all imported data in tables
 * - Expandable/collapsible sections
 * - Pagination support
 * - Only shows tables with data
 * - Final validation before submission
 */

import React, { useState } from 'react';
import { FiChevronDown, FiChevronRight, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';
import DataImportTable from './shared/DataImportTable';

const BulkStep5_ReviewData = ({
  assets,
  services,
  jobs,
  slas,
  validationErrors
}) => {
  const [expandedSections, setExpandedSections] = useState({
    assets: true,
    services: true,
    jobs: true,
    slas: true
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Asset columns
  const assetColumns = [
    { key: 'asset_name', label: 'Asset Name', width: '25%' },
    { key: 'asset_type', label: 'Type', width: '20%' },
    { key: 'asset_owner', label: 'Owner', width: '20%' },
    { key: 'onboarded_date', label: 'Onboarded Date' },
    { key: 'status', label: 'Status', width: '15%' },
    { key: 'description', label: 'Description', width: '20%' }
  ];

  // Service columns
  const serviceColumns = [
    { key: 'service_name', label: 'Service Name', width: '25%', altKey: 'name' },
    { key: 'service_type', label: 'Type', width: '20%', altKey: 'type' },
    { key: 'asset_id', label: 'Asset ID', width: '20%' },
    { key: 'status', label: 'Status', width: '15%' },
    { key: 'description', label: 'Description', width: '20%' }
  ];

  // Job columns
  const jobColumns = [
    { key: 'job_name', label: 'Job Name', width: '25%', altKey: 'name' },
    { key: 'job_type', label: 'Type', width: '15%', altKey: 'type' },
    { key: 'asset_id', label: 'Asset ID', width: '15%' },
    { key: 'service_id', label: 'Service ID', width: '15%' },
    { key: 'schedule', label: 'Schedule', width: '15%' },
    { key: 'description', label: 'Description', width: '15%' }
  ];

  // SLA columns
  const slaColumns = [
    { key: 'sla_name', label: 'SLA Name', width: '25%' },
    { key: 'sla_type', label: 'SLA Type', width: '15%' },
    { key: 'target_value_percentage', label: 'Target (%)', width: '10%' },
    { key: 'service_id', label: 'Service ID', width: '15%' },
    { key: 'job_id', label: 'Job ID', width: '15%' },
    { key: 'measurement_period', label: 'Measurement Period', width: '20%' }
  ];

  const totalRecords = assets.length + services.length + jobs.length + slas.length;

  return (
    <div className="py-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Step 5: Review & Complete
        </h2>
        <p className="text-gray-600">
          Review all imported data before completing the bulk onboarding process.
        </p>
      </div>

      {/* Summary Card */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
        <div className="flex items-start">
          <FiCheckCircle className="text-blue-600 text-2xl mr-4 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-semibold text-blue-900 mb-3">Import Summary</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg p-3">
                <div className="text-2xl font-bold text-blue-600">{assets.length}</div>
                <div className="text-sm text-gray-600">Assets</div>
              </div>
              <div className="bg-white rounded-lg p-3">
                <div className="text-2xl font-bold text-green-600">{services.length}</div>
                <div className="text-sm text-gray-600">Services</div>
              </div>
              <div className="bg-white rounded-lg p-3">
                <div className="text-2xl font-bold text-orange-600">{jobs.length}</div>
                <div className="text-sm text-gray-600">Jobs</div>
              </div>
              <div className="bg-white rounded-lg p-3">
                <div className="text-2xl font-bold text-purple-600">{slas.length}</div>
                <div className="text-sm text-gray-600">SLAs</div>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-blue-200">
              <p className="text-sm text-blue-900">
                <strong>Total Records:</strong> {totalRecords}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Validation Errors */}
      {validationErrors && Object.keys(validationErrors).some(key => validationErrors[key].length > 0) && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
          <div className="flex items-start">
            <FiAlertCircle className="text-red-600 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-red-900 mb-2">Validation Errors</h3>
              <div className="space-y-2">
                {Object.entries(validationErrors).map(([key, errors]) => (
                  errors.length > 0 && (
                    <div key={key}>
                      <p className="text-sm font-medium text-red-800 capitalize">{key}:</p>
                      <ul className="text-sm text-red-700 ml-4 list-disc">
                        {errors.map((error, idx) => (
                          <li key={idx}>{error}</li>
                        ))}
                      </ul>
                    </div>
                  )
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Data Tables */}
      <div className="space-y-4">
        {/* Assets Table */}
        {assets.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('assets')}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition"
            >
              <div className="flex items-center">
                {expandedSections.assets ? (
                  <FiChevronDown className="text-gray-400 mr-2" />
                ) : (
                  <FiChevronRight className="text-gray-400 mr-2" />
                )}
                <h3 className="font-semibold text-gray-900">
                  Assets ({assets.length})
                </h3>
              </div>
              <span className="text-sm text-gray-500">
                {expandedSections.assets ? 'Click to collapse' : 'Click to expand'}
              </span>
            </button>

            {expandedSections.assets && (
              <div className="border-t border-gray-200">
                <DataImportTable
                  data={assets}
                  columns={assetColumns}
                  entityType="asset"
                />
              </div>
            )}
          </div>
        )}

        {/* Services Table */}
        {services.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('services')}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition"
            >
              <div className="flex items-center">
                {expandedSections.services ? (
                  <FiChevronDown className="text-gray-400 mr-2" />
                ) : (
                  <FiChevronRight className="text-gray-400 mr-2" />
                )}
                <h3 className="font-semibold text-gray-900">
                  Services ({services.length})
                </h3>
              </div>
              <span className="text-sm text-gray-500">
                {expandedSections.services ? 'Click to collapse' : 'Click to expand'}
              </span>
            </button>

            {expandedSections.services && (
              <div className="border-t border-gray-200">
                <DataImportTable
                  data={services}
                  columns={serviceColumns}
                  entityType="service"
                />
              </div>
            )}
          </div>
        )}

        {/* Jobs Table */}
        {jobs.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('jobs')}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition"
            >
              <div className="flex items-center">
                {expandedSections.jobs ? (
                  <FiChevronDown className="text-gray-400 mr-2" />
                ) : (
                  <FiChevronRight className="text-gray-400 mr-2" />
                )}
                <h3 className="font-semibold text-gray-900">
                  Jobs ({jobs.length})
                </h3>
              </div>
              <span className="text-sm text-gray-500">
                {expandedSections.jobs ? 'Click to collapse' : 'Click to expand'}
              </span>
            </button>

            {expandedSections.jobs && (
              <div className="border-t border-gray-200">
                <DataImportTable
                  data={jobs}
                  columns={jobColumns}
                  entityType="job"
                />
              </div>
            )}
          </div>
        )}

        {/* SLAs Table */}
        {slas.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => toggleSection('slas')}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition"
            >
              <div className="flex items-center">
                {expandedSections.slas ? (
                  <FiChevronDown className="text-gray-400 mr-2" />
                ) : (
                  <FiChevronRight className="text-gray-400 mr-2" />
                )}
                <h3 className="font-semibold text-gray-900">
                  SLAs ({slas.length})
                </h3>
              </div>
              <span className="text-sm text-gray-500">
                {expandedSections.slas ? 'Click to collapse' : 'Click to expand'}
              </span>
            </button>

            {expandedSections.slas && (
              <div className="border-t border-gray-200">
                <DataImportTable
                  data={slas}
                  columns={slaColumns}
                  entityType="sla"
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* No Data Message */}
      {totalRecords === 0 && (
        <div className="text-center py-12">
          <FiAlertCircle className="mx-auto text-5xl text-gray-400 mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No Data to Review
          </h3>
          <p className="text-gray-600">
            Go back to previous steps to import data.
          </p>
        </div>
      )}
    </div>
  );
};

export default BulkStep5_ReviewData;
