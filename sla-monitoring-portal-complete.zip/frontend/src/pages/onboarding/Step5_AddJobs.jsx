/**
 * Step 5: Add Jobs (Optional)
 * Add jobs and link them to SLAs
 */

import React, { useState } from 'react';
import { Plus, Trash2, Clock } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const Step5_AddJobs = ({ slas, jobs, onAdd, onDelete, onNext, onBack }) => {
  const [showForm, setShowForm] = useState(false);
  const [newJob, setNewJob] = useState({
    sla_id: '',
    job_name: '',
    job_type: 'batch',
    schedule: '',
    description: '',
    expected_duration: '',
    job_identifier: '',
    parent_job_id: ''
  });

  const handleAddJob = (e) => {
    e.preventDefault();
    onAdd(newJob);
    setNewJob({
      sla_id: '',
      job_name: '',
      job_type: 'batch',
      schedule: '',
      description: '',
      expected_duration: '',
      job_identifier: '',
      parent_job_id: ''
    });
    setShowForm(false);
  };

  return (
    <Card>
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Clock size={32} className="text-yellow-600" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Add Jobs</h2>
              <p className="text-gray-600 mt-1">
                Add scheduled jobs under SLAs (Optional)
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2"
            disabled={slas.length === 0}
          >
            <Plus size={18} />
            Add Job
          </Button>
        </div>

        {slas.length === 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-yellow-800">
              Please define SLAs first before adding jobs
            </p>
          </div>
        )}

        {/* Add Job Form */}
        {showForm && (
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">New Job</h3>
            <form onSubmit={handleAddJob} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SLA <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.sla_id}
                    onChange={(e) => setNewJob({ ...newJob, sla_id: e.target.value })}
                  >
                    <option value="">Select SLA</option>
                    {slas.map(sla => (
                      <option key={sla.id} value={sla.id}>
                        {sla.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Job Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.job_name}
                    onChange={(e) => setNewJob({ ...newJob, job_name: e.target.value })}
                    placeholder="e.g., Daily Data Sync"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Job Type
                  </label>
                  <select
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.job_type}
                    onChange={(e) => setNewJob({ ...newJob, job_type: e.target.value })}
                  >
                    <option value="batch">Batch</option>
                    <option value="etl">ETL</option>
                    <option value="sync">Sync</option>
                    <option value="backup">Backup</option>
                    <option value="report">Report</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Schedule (Cron)
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.schedule}
                    onChange={(e) => setNewJob({ ...newJob, schedule: e.target.value })}
                    placeholder="0 2 * * *"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Expected Duration (mins)
                  </label>
                  <input
                    type="number"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.expected_duration}
                    onChange={(e) => setNewJob({ ...newJob, expected_duration: e.target.value })}
                    placeholder="60"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Job Identifier
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.job_identifier}
                    onChange={(e) => setNewJob({ ...newJob, job_identifier: e.target.value })}
                    placeholder="Unique job ID for log matching"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Parent Job (for dependencies)
                  </label>
                  <select
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newJob.parent_job_id}
                    onChange={(e) => setNewJob({ ...newJob, parent_job_id: e.target.value })}
                  >
                    <option value="">None (Independent Job)</option>
                    {jobs.map(job => (
                      <option key={job.id} value={job.id}>
                        {job.job_name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  value={newJob.description}
                  onChange={(e) => setNewJob({ ...newJob, description: e.target.value })}
                  placeholder="Describe the job..."
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="secondary" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Add Job
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* Jobs List */}
        {jobs.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg mb-6">
            <Clock size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-600">No jobs added yet</p>
            <p className="text-sm text-gray-500 mt-2">
              This step is optional. Skip if you don't have jobs to add.
            </p>
          </div>
        ) : (
          <div className="space-y-4 mb-6">
            {jobs.map((job) => {
              const sla = slas.find(s => s.id === job.sla_id);
              return (
                <div key={job.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-gray-900">{job.job_name}</h4>
                      <p className="text-sm text-gray-600">SLA: {sla?.name || 'Unknown'}</p>
                      <p className="text-sm text-gray-600">Type: {job.job_type} | Schedule: {job.schedule || 'N/A'}</p>
                      {job.description && <p className="text-sm text-gray-500 mt-2">{job.description}</p>}
                    </div>
                    <button
                      onClick={() => onDelete(job.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="flex justify-between pt-4 border-t">
          <Button variant="secondary" onClick={onBack}>
            Back
          </Button>
          <Button onClick={onNext}>
            Next: Review & Complete
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default Step5_AddJobs;
