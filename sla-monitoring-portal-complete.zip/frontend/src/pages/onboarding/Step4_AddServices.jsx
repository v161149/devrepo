/**
 * Step 4: Add Services (Optional)
 * Add services and link them to SLAs
 */

import React, { useState } from 'react';
import { Plus, Trash2, Server } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const Step4_AddServices = ({ slas, services, onAdd, onDelete, onNext, onBack }) => {
  const [showForm, setShowForm] = useState(false);
  const [newService, setNewService] = useState({
    sla_id: '',
    name: '',
    description: '',
    owner_team: '',
    service_identifier: '',
    parent_service_id: ''
  });

  const handleAddService = (e) => {
    e.preventDefault();
    onAdd(newService);
    setNewService({
      sla_id: '',
      name: '',
      description: '',
      owner_team: '',
      service_identifier: '',
      parent_service_id: ''
    });
    setShowForm(false);
  };

  return (
    <Card>
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Server size={32} className="text-blue-600" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Add Services</h2>
              <p className="text-gray-600 mt-1">
                Add services under SLAs (Optional)
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2"
            disabled={slas.length === 0}
          >
            <Plus size={18} />
            Add Service
          </Button>
        </div>

        {slas.length === 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-yellow-800">
              Please define SLAs first before adding services
            </p>
          </div>
        )}

        {/* Add Service Form */}
        {showForm && (
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">New Service</h3>
            <form onSubmit={handleAddService} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SLA <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newService.sla_id}
                    onChange={(e) => setNewService({ ...newService, sla_id: e.target.value })}
                  >
                    <option value="">Select SLA</option>
                    {slas.map(sla => (
                      <option key={sla.id} value={sla.id}>
                        {sla.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Service Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newService.name}
                    onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                    placeholder="e.g., Payment API"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Service Identifier
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newService.service_identifier}
                    onChange={(e) => setNewService({ ...newService, service_identifier: e.target.value })}
                    placeholder="Unique service ID for log matching"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Owner Team
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    value={newService.owner_team}
                    onChange={(e) => setNewService({ ...newService, owner_team: e.target.value })}
                    placeholder="e.g., Platform Team"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Parent Service (for dependencies)
                </label>
                <select
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  value={newService.parent_service_id}
                  onChange={(e) => setNewService({ ...newService, parent_service_id: e.target.value })}
                >
                  <option value="">None (Independent Service)</option>
                  {services.map(svc => (
                    <option key={svc.id} value={svc.id}>
                      {svc.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  value={newService.description}
                  onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                  placeholder="Describe the service..."
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="secondary" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Add Service
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* Services List */}
        {services.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg mb-6">
            <Server size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-600">No services added yet</p>
            <p className="text-sm text-gray-500 mt-2">
              This step is optional. Skip if you don't have services to add.
            </p>
          </div>
        ) : (
          <div className="space-y-4 mb-6">
            {services.map((svc) => {
              const sla = slas.find(s => s.id === svc.sla_id);
              return (
                <div key={svc.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-gray-900">{svc.name}</h4>
                      <p className="text-sm text-gray-600">SLA: {sla?.name || 'Unknown'}</p>
                      {svc.owner_team && <p className="text-sm text-gray-600">Team: {svc.owner_team}</p>}
                      {svc.description && <p className="text-sm text-gray-500 mt-2">{svc.description}</p>}
                    </div>
                    <button
                      onClick={() => onDelete(svc.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="flex justify-between pt-4 border-t">
          <Button variant="secondary" onClick={onBack}>
            Back
          </Button>
          <Button onClick={onNext}>
            Next: Add Jobs (Optional)
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default Step4_AddServices;
