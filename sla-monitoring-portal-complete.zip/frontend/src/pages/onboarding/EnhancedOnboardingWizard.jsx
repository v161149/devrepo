/**
 * Enhanced Onboarding Wizard - UPDATED FOR AIT WORKFLOW
 * 6-Step Process: AITs → Applications → SLAs → Services → Jobs → Review
 */

import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiCheck, FiChevronRight, FiChevronLeft } from 'react-icons/fi';
import Card from '../../components/Card';
import Button from '../../components/Button';

// Import step components
import Step1_CreateAIT from './Step1_CreateAIT';
import Step2_AddApplications from './Step2_AddApplications';
import Step3_DefineSLAs from './Step3_DefineSLAs';
import Step4_AddServices from './Step4_AddServices';
import Step5_AddJobs from './Step5_AddJobs';
import Step6_ReviewComplete from './Step6_ReviewComplete';

const STEPS = [
  { number: 1, title: 'Add AITs', description: 'Business Units', required: true },
  { number: 2, title: 'Add Applications', description: 'Assets', required: true },
  { number: 3, title: 'Define SLAs', description: 'Service Agreements', required: false },
  { number: 4, title: 'Add Services', description: 'Optional', required: false },
  { number: 5, title: 'Add Jobs', description: 'Optional', required: false },
  { number: 6, title: 'Review & Complete', description: 'Finalize', required: true }
];

const EnhancedOnboardingWizard = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  const getTodayFormatted = () => {
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const year = today.getFullYear();
    return `${month}/${day}/${year}`;
  };

  // Wizard state for new 6-step workflow
  const [wizardState, setWizardState] = useState({
    currentStep: 1,
    
    // Step 1: AIT (required)
    ait: {
      name: '',
      short_name: '',
      description: '',
      cost_center: '',
      tech_support_contact: '',
      status: 1
    },

    // Step 2: Applications/Assets (required, multiple)
    applications: [],

    // Step 3: SLAs (optional, multiple) - Now linked to applications
    slas: [],

    // Step 4: Services (optional, multiple) - Now linked to SLAs
    services: [],

    // Step 5: Jobs (optional, multiple) - Now linked to SLAs
    jobs: [],

    errors: {
      ait: {},
      applications: [],
      slas: [],
      services: [],
      jobs: []
    }
  });

  // ============================================================================
  // AIT ACTIONS (NEW)
  // ============================================================================

  const updateAIT = useCallback((field, value) => {
    setWizardState(prev => ({
      ...prev,
      ait: {
        ...prev.ait,
        [field]: value
      }
    }));
  }, []);

  const validateAIT = useCallback(() => {
    const errors = {};
    const { ait } = wizardState;

    if (!ait.name || ait.name.trim() === '') {
      errors.name = 'AIT name is required';
    }

    setWizardState(prev => ({
      ...prev,
      errors: { ...prev.errors, ait: errors }
    }));

    return Object.keys(errors).length === 0;
  }, [wizardState.ait]);

  // ============================================================================
  // APPLICATION ACTIONS
  // ============================================================================

  const addApplication = useCallback((application) => {
    setWizardState(prev => ({
      ...prev,
      applications: [...prev.applications, { ...application, id: Date.now() }]
    }));
  }, []);

  const updateApplication = useCallback((id, field, value) => {
    setWizardState(prev => ({
      ...prev,
      applications: prev.applications.map(app =>
        app.id === id ? { ...app, [field]: value } : app
      )
    }));
  }, []);

  const deleteApplication = useCallback((id) => {
    setWizardState(prev => ({
      ...prev,
      applications: prev.applications.filter(app => app.id !== id)
    }));
  }, []);

  // ============================================================================
  // SLA ACTIONS
  // ============================================================================

  const addSLA = useCallback((sla) => {
    setWizardState(prev => ({
      ...prev,
      slas: [...prev.slas, { ...sla, id: Date.now() }]
    }));
  }, []);

  const updateSLA = useCallback((id, field, value) => {
    setWizardState(prev => ({
      ...prev,
      slas: prev.slas.map(sla =>
        sla.id === id ? { ...sla, [field]: value } : sla
      )
    }));
  }, []);

  const deleteSLA = useCallback((id) => {
    setWizardState(prev => ({
      ...prev,
      slas: prev.slas.filter(sla => sla.id !== id)
    }));
  }, []);

  // ============================================================================
  // SERVICE ACTIONS
  // ============================================================================

  const addService = useCallback((service) => {
    setWizardState(prev => ({
      ...prev,
      services: [...prev.services, { ...service, id: Date.now() }]
    }));
  }, []);

  const updateService = useCallback((id, field, value) => {
    setWizardState(prev => ({
      ...prev,
      services: prev.services.map(svc =>
        svc.id === id ? { ...svc, [field]: value } : svc
      )
    }));
  }, []);

  const deleteService = useCallback((id) => {
    setWizardState(prev => ({
      ...prev,
      services: prev.services.filter(svc => svc.id !== id)
    }));
  }, []);

  // ============================================================================
  // JOB ACTIONS
  // ============================================================================

  const addJob = useCallback((job) => {
    setWizardState(prev => ({
      ...prev,
      jobs: [...prev.jobs, { ...job, id: Date.now() }]
    }));
  }, []);

  const updateJob = useCallback((id, field, value) => {
    setWizardState(prev => ({
      ...prev,
      jobs: prev.jobs.map(job =>
        job.id === id ? { ...job, [field]: value } : job
      )
    }));
  }, []);

  const deleteJob = useCallback((id) => {
    setWizardState(prev => ({
      ...prev,
      jobs: prev.jobs.filter(job => job.id !== id)
    }));
  }, []);

  // ============================================================================
  // NAVIGATION
  // ============================================================================

  const goToNextStep = useCallback(() => {
    // Validate current step before proceeding
    if (currentStep === 1 && !validateAIT()) {
      return;
    }

    if (currentStep === 2 && wizardState.applications.length === 0) {
      alert('Please add at least one application');
      return;
    }

    if (currentStep < STEPS.length) {
      setCurrentStep(prev => prev + 1);
    }
  }, [currentStep, validateAIT, wizardState.applications]);

  const goToPreviousStep = useCallback(() => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  }, [currentStep]);

  const goToStep = useCallback((step) => {
    setCurrentStep(step);
  }, []);

  // ============================================================================
  // SUBMIT
  // ============================================================================

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const token = localStorage.getItem('token');
      
      // Step 1: Create AIT
      const aitResponse = await fetch('/api/v1/aits', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(wizardState.ait)
      });

      if (!aitResponse.ok) throw new Error('Failed to create AIT');
      const aitData = await aitResponse.json();
      const aitId = aitData.ait_id;

      // Step 2: Create Applications
      const createdApplications = [];
      for (const app of wizardState.applications) {
        const appResponse = await fetch('/api/v1/assets', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            ...app,
            ait_id: aitId,
            onboarded_date: getTodayFormatted()
          })
        });

        if (!appResponse.ok) throw new Error('Failed to create application');
        const appData = await appResponse.json();
        createdApplications.push({ ...app, asset_id: appData.asset_id });
      }

      // Step 3: Create SLAs
      const createdSLAs = [];
      for (const sla of wizardState.slas) {
        const appId = createdApplications.find(a => a.id === sla.application_id)?.asset_id;
        
        const slaResponse = await fetch('/api/v1/slas', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            ...sla,
            asset_id: appId
          })
        });

        if (!slaResponse.ok) throw new Error('Failed to create SLA');
        const slaData = await slaResponse.json();
        createdSLAs.push({ ...sla, sla_id: slaData.sla_id });
      }

      // Step 4: Create Services
      for (const service of wizardState.services) {
        const slaId = createdSLAs.find(s => s.id === service.sla_id)?.sla_id;
        
        await fetch('/api/v1/services', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            ...service,
            sla_id: slaId
          })
        });
      }

      // Step 5: Create Jobs
      for (const job of wizardState.jobs) {
        const slaId = createdSLAs.find(s => s.id === job.sla_id)?.sla_id;
        
        await fetch('/api/v1/jobs', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            ...job,
            sla_id: slaId
          })
        });
      }

      // Success!
      navigate('/dashboard');
    } catch (error) {
      console.error('Onboarding error:', error);
      setSubmitError(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================================
  // RENDER CURRENT STEP
  // ============================================================================

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <Step1_CreateAIT
            ait={wizardState.ait}
            errors={wizardState.errors.ait}
            onUpdate={updateAIT}
            onNext={goToNextStep}
          />
        );

      case 2:
        return (
          <Step2_AddApplications
            ait={wizardState.ait}
            applications={wizardState.applications}
            onAdd={addApplication}
            onUpdate={updateApplication}
            onDelete={deleteApplication}
            onNext={goToNextStep}
            onBack={goToPreviousStep}
          />
        );

      case 3:
        return (
          <Step3_DefineSLAs
            applications={wizardState.applications}
            slas={wizardState.slas}
            onAdd={addSLA}
            onUpdate={updateSLA}
            onDelete={deleteSLA}
            onNext={goToNextStep}
            onBack={goToPreviousStep}
          />
        );

      case 4:
        return (
          <Step4_AddServices
            slas={wizardState.slas}
            services={wizardState.services}
            onAdd={addService}
            onUpdate={updateService}
            onDelete={deleteService}
            onNext={goToNextStep}
            onBack={goToPreviousStep}
          />
        );

      case 5:
        return (
          <Step5_AddJobs
            slas={wizardState.slas}
            jobs={wizardState.jobs}
            onAdd={addJob}
            onUpdate={updateJob}
            onDelete={deleteJob}
            onNext={goToNextStep}
            onBack={goToPreviousStep}
          />
        );

      case 6:
        return (
          <Step6_ReviewComplete
            wizardState={wizardState}
            onSubmit={handleSubmit}
            onBack={goToPreviousStep}
            isSubmitting={isSubmitting}
            submitError={submitError}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Onboarding Wizard</h1>
        <p className="text-gray-600 mt-2">
          Set up your AITs, applications, and SLAs in 6 easy steps
        </p>
      </div>

      {/* Progress Steps */}
      <Card className="mb-8">
        <div className="p-6">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => (
              <React.Fragment key={step.number}>
                <div 
                  className={`flex flex-col items-center cursor-pointer ${
                    currentStep >= step.number ? 'opacity-100' : 'opacity-50'
                  }`}
                  onClick={() => currentStep > step.number && goToStep(step.number)}
                >
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold ${
                      currentStep > step.number
                        ? 'bg-green-500'
                        : currentStep === step.number
                        ? 'bg-blue-500'
                        : 'bg-gray-300'
                    }`}
                  >
                    {currentStep > step.number ? (
                      <FiCheck size={24} />
                    ) : (
                      step.number
                    )}
                  </div>
                  <div className="text-center mt-2">
                    <div className="text-sm font-medium text-gray-900">
                      {step.title}
                    </div>
                    <div className="text-xs text-gray-500">
                      {step.description}
                    </div>
                  </div>
                </div>
                {index < STEPS.length - 1 && (
                  <div className="flex-1 h-1 mx-4 bg-gray-300 rounded">
                    <div
                      className={`h-full rounded transition-all ${
                        currentStep > step.number ? 'bg-green-500' : 'bg-gray-300'
                      }`}
                      style={{
                        width: currentStep > step.number ? '100%' : '0%'
                      }}
                    />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </Card>

      {/* Step Content */}
      <div>{renderStepContent()}</div>
    </div>
  );
};

export default EnhancedOnboardingWizard;
