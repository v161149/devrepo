/**
 * Step 3: Define SLAs
 * Define SLAs for applications with log templates
 */

import React, { useState } from 'react';
import { Plus, Trash2, FileText } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { SLA_TYPES } from '../../constants/slaTypes';

const Step3_DefineSLAs = ({ applications, slas, onAdd, onUpdate, onDelete, onNext, onBack }) => {
  const [showForm, setShowForm] = useState(false);
  const [newSLA, setNewSLA] = useState({
    application_id: '',
    name: '',
    metric_type: 'uptime',
    target_value: '',
    target_unit: 'percentage',
    log_template: '',
    log_server_type: 'splunk',
    priority: 'medium',
    description: ''
  });

  const handleAddSLA = (e) => {
    e.preventDefault();
    onAdd(newSLA);
    setNewSLA({
      application_id: '',
      name: '',
      metric_type: 'uptime',
      target_value: '',
      target_unit: 'percentage',
      log_template: '',
      log_server_type: 'splunk',
      priority: 'medium',
      description: ''
    });
    setShowForm(false);
  };

  const sampleLogTemplate = JSON.stringify({
    "job_id": "string",
    "status": "string",
    "start_time": "timestamp",
    "end_time": "timestamp",
    "duration_seconds": "number"
  }, null, 2);

  return (
    <Card>
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <FileText size={32} className="text-green-600" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Define SLAs</h2>
              <p className="text-gray-600 mt-1">
                Create SLA templates for your applications (Optional)
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2"
            disabled={applications.length === 0}
          >
            <Plus size={18} />
            Add SLA
          </Button>
        </div>

        {applications.length === 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-yellow-800">
              Please add applications first before defining SLAs
            </p>
          </div>
        )}

        {/* Add SLA Form */}
        {showForm && (
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">New SLA</h3>
            <form onSubmit={handleAddSLA} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Application <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.application_id}
                    onChange={(e) => setNewSLA({ ...newSLA, application_id: e.target.value })}
                  >
                    <option value="">Select Application</option>
                    {applications.map(app => (
                      <option key={app.id} value={app.id}>
                        {app.asset_name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SLA Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.name}
                    onChange={(e) => setNewSLA({ ...newSLA, name: e.target.value })}
                    placeholder="e.g., API Uptime SLA"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Metric Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.metric_type}
                    onChange={(e) => setNewSLA({ ...newSLA, metric_type: e.target.value })}
                  >
                    {SLA_TYPES.map(type => (
                      <option key={type.id} value={type.id}>
                        {type.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Target Value <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    step="0.01"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.target_value}
                    onChange={(e) => setNewSLA({ ...newSLA, target_value: e.target.value })}
                    placeholder="e.g., 99.9"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Priority
                  </label>
                  <select
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.priority}
                    onChange={(e) => setNewSLA({ ...newSLA, priority: e.target.value })}
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="critical">Critical</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Log Server Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.log_server_type}
                    onChange={(e) => setNewSLA({ ...newSLA, log_server_type: e.target.value })}
                  >
                    <option value="splunk">Splunk</option>
                    <option value="elk">ELK Stack</option>
                    <option value="cloudwatch">AWS CloudWatch</option>
                    <option value="datadog_logs">Datadog Logs</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Target Unit
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newSLA.target_unit}
                    onChange={(e) => setNewSLA({ ...newSLA, target_unit: e.target.value })}
                    placeholder="e.g., percentage, seconds, count"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Log Template (JSON) <span className="text-red-500">*</span>
                </label>
                <textarea
                  required
                  rows={6}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                  value={newSLA.log_template}
                  onChange={(e) => setNewSLA({ ...newSLA, log_template: e.target.value })}
                  placeholder={sampleLogTemplate}
                />
                <p className="mt-1 text-sm text-gray-500">
                  Define the log structure. All services/jobs under this SLA will use this template.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={newSLA.description}
                  onChange={(e) => setNewSLA({ ...newSLA, description: e.target.value })}
                  placeholder="Describe this SLA..."
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="secondary" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Add SLA
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* SLAs List */}
        {slas.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <FileText size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-600">No SLAs defined yet</p>
            <p className="text-sm text-gray-500 mt-2">
              This step is optional. Click "Add SLA" to create SLA templates.
            </p>
          </div>
        ) : (
          <div className="space-y-4 mb-6">
            {slas.map((sla) => {
              const app = applications.find(a => a.id === sla.application_id);
              return (
                <div key={sla.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-gray-900">{sla.name}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        Application: {app?.asset_name || 'Unknown'}
                      </p>
                      <p className="text-sm text-gray-600">
                        Type: {SLA_TYPES.find(t => t.id === sla.metric_type)?.name}
                      </p>
                      <p className="text-sm text-gray-600">
                        Target: {sla.target_value} {sla.target_unit} | Priority: {sla.priority}
                      </p>
                      <p className="text-sm text-gray-600">
                        Log Server: {sla.log_server_type}
                      </p>
                    </div>
                    <button
                      onClick={() => onDelete(sla.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Info Box */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-green-900 mb-2">
            ⚡ Key Benefit: Pre-configured Log Templates
          </h3>
          <p className="text-sm text-green-800">
            By defining log templates here, all services and jobs added under this SLA will 
            automatically inherit the log configuration. This eliminates the need to configure 
            log templates for each individual service/job—a huge time saver for bulk operations!
          </p>
        </div>

        {/* Actions */}
        <div className="flex justify-between pt-4 border-t">
          <Button variant="secondary" onClick={onBack}>
            Back
          </Button>
          <Button onClick={onNext}>
            Next: Add Services (Optional)
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default Step3_DefineSLAs;
