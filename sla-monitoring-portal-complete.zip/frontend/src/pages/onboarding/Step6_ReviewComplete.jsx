/**
 * Step 6: Review & Complete
 * Final review and submission
 */

import React from 'react';
import { Check, AlertCircle } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const Step6_ReviewComplete = ({ wizardState, onSubmit, onBack, isSubmitting, submitError }) => {
  const { ait, applications, slas, services, jobs } = wizardState;

  return (
    <Card>
      <div className="p-8">
        <div className="flex items-center gap-3 mb-6">
          <Check size={32} className="text-green-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Review & Complete</h2>
            <p className="text-gray-600 mt-1">
              Review your configuration before submitting
            </p>
          </div>
        </div>

        {submitError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-2">
              <AlertCircle className="text-red-600 mt-0.5" size={20} />
              <div>
                <h4 className="font-semibold text-red-900">Submission Error</h4>
                <p className="text-sm text-red-800 mt-1">{submitError}</p>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-6">
          {/* AIT Summary */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-3">AIT (Business Unit)</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-blue-700">Name:</span>
                <span className="ml-2 font-medium text-blue-900">{ait.name}</span>
              </div>
              {ait.short_name && (
                <div>
                  <span className="text-blue-700">Short Name:</span>
                  <span className="ml-2 font-medium text-blue-900">{ait.short_name}</span>
                </div>
              )}
              {ait.cost_center && (
                <div>
                  <span className="text-blue-700">Cost Center:</span>
                  <span className="ml-2 font-medium text-blue-900">{ait.cost_center}</span>
                </div>
              )}
              {ait.tech_support_contact && (
                <div>
                  <span className="text-blue-700">Tech Support:</span>
                  <span className="ml-2 font-medium text-blue-900">{ait.tech_support_contact}</span>
                </div>
              )}
            </div>
          </div>

          {/* Applications Summary */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <h3 className="font-semibold text-purple-900 mb-3">
              Applications ({applications.length})
            </h3>
            {applications.length > 0 ? (
              <div className="space-y-2">
                {applications.map((app) => (
                  <div key={app.id} className="text-sm text-purple-800">
                    • {app.asset_name} ({app.asset_type})
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-purple-600">No applications added</p>
            )}
          </div>

          {/* SLAs Summary */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="font-semibold text-green-900 mb-3">
              SLAs ({slas.length})
            </h3>
            {slas.length > 0 ? (
              <div className="space-y-2">
                {slas.map((sla) => (
                  <div key={sla.id} className="text-sm text-green-800">
                    • {sla.name} - {sla.metric_type} ({sla.target_value} {sla.target_unit})
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-green-600">No SLAs defined</p>
            )}
          </div>

          {/* Services Summary */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-3">
              Services ({services.length})
            </h3>
            {services.length > 0 ? (
              <div className="space-y-2">
                {services.map((svc) => (
                  <div key={svc.id} className="text-sm text-blue-800">
                    • {svc.name}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-blue-600">No services added</p>
            )}
          </div>

          {/* Jobs Summary */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="font-semibold text-yellow-900 mb-3">
              Jobs ({jobs.length})
            </h3>
            {jobs.length > 0 ? (
              <div className="space-y-2">
                {jobs.map((job) => (
                  <div key={job.id} className="text-sm text-yellow-800">
                    • {job.job_name} ({job.job_type})
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-yellow-600">No jobs added</p>
            )}
          </div>

          {/* Summary Stats */}
          <div className="bg-gray-100 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Summary</h3>
            <div className="grid grid-cols-5 gap-4 text-center">
              <div>
                <div className="text-3xl font-bold text-blue-600">1</div>
                <div className="text-sm text-gray-600 mt-1">AIT</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-600">{applications.length}</div>
                <div className="text-sm text-gray-600 mt-1">Applications</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600">{slas.length}</div>
                <div className="text-sm text-gray-600 mt-1">SLAs</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-600">{services.length}</div>
                <div className="text-sm text-gray-600 mt-1">Services</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-yellow-600">{jobs.length}</div>
                <div className="text-sm text-gray-600 mt-1">Jobs</div>
              </div>
            </div>
          </div>

          {/* Info Box */}
          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
            <h3 className="font-semibold text-indigo-900 mb-2">
              🎉 Ready to Submit!
            </h3>
            <p className="text-sm text-indigo-800">
              Once you submit, your AIT, applications, SLAs, services, and jobs will be created in the system. 
              You can always add more or modify them later from the dashboard.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-between pt-6 border-t mt-6">
          <Button variant="secondary" onClick={onBack} disabled={isSubmitting}>
            Back
          </Button>
          <Button 
            onClick={onSubmit} 
            loading={isSubmitting}
            disabled={isSubmitting || applications.length === 0}
          >
            {isSubmitting ? 'Creating...' : 'Complete Onboarding'}
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default Step6_ReviewComplete;
