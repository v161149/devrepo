/**
 * BulkStep4_SelectSLAConnector.jsx
 * 
 * Step 4 of Bulk Onboarding Wizard (OPTIONAL)
 * - Lists available SLA connectors
 * - Educational message about service_id XOR job_id requirement
 * - Allows user to skip this step
 */

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiCloud, FiAlertCircle, FiSettings, FiCheck, FiSkipForward } from 'react-icons/fi';
import Button from '../../components/Button';
import ConnectorSelector from './shared/ConnectorSelector';

const BulkStep4_SelectSLAConnector = ({
  slas,
  selectedConnector,
  existingServices,
  existingJobs,
  onDataImported,
  onSkip
}) => {
  const navigate = useNavigate();
  const [connectors, setConnectors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchSLAConnectors();
  }, []);

  const fetchSLAConnectors = async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        'http://localhost:5000/api/v1/connectors?type=sla',
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch SLA connectors');
      }

      const data = await response.json();
      setConnectors(data.data || []);
    } catch (err) {
      console.error('Error fetching SLA connectors:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleImportData = async (connector) => {
    try {
      const token = localStorage.getItem('token');
      const connectorId = connector.id || connector.connector_id;
      
      console.log('Fetching data from connector:', connectorId);
      
      // Use /fetch endpoint to get data from connector (doesn't import to DB yet)
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}/fetch`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            filters: {} // Optional filters
          })
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to fetch data from connector');
      }

      const result = await response.json();
      console.log('Fetched data:', result);

      // Backend now applies field mappings, use data directly
      const fetchedSLAs = result.data || [];

      if (fetchedSLAs.length === 0) {
        throw new Error('No data returned from connector');
      }

      // Validate: Each SLA must have EITHER service_id OR job_id (not both, not neither)
      const serviceIds = existingServices.map(s => s.service_id);
      const jobIds = existingJobs.map(j => j.job_id);

      const invalidSLAs = fetchedSLAs.filter(sla => {
        const hasService = sla.service_id && serviceIds.includes(sla.service_id);
        const hasJob = sla.job_id && jobIds.includes(sla.job_id);

        // Must have exactly one (XOR logic)
        if (hasService && hasJob) return true; // Both - invalid
        if (!hasService && !hasJob) return true; // Neither - invalid
        return false; // Exactly one - valid
      });

      if (invalidSLAs.length > 0) {
        throw new Error(
          `${invalidSLAs.length} SLA(s) have invalid linking. Each SLA must link to EITHER a service OR a job (not both).`
        );
      }

      // Pass normalized data back to wizard (will be imported in Step 5)
      onDataImported(fetchedSLAs, connector);
      
      return { success: true, count: fetchedSLAs.length };
    } catch (err) {
      console.error('Error fetching data:', err);
      throw err;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading SLA connectors...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <div className="flex items-start">
          <FiAlertCircle className="text-red-600 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-red-900 mb-2">Error Loading Connectors</h3>
            <p className="text-red-700 mb-4">{error}</p>
            <Button onClick={fetchSLAConnectors} variant="outline">
              Try Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Empty state
  if (connectors.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-purple-100 rounded-full mb-6">
          <FiCloud className="w-10 h-10 text-purple-600" />
        </div>

        <h2 className="text-2xl font-semibold text-gray-900 mb-4">
          No SLA Connectors Found
        </h2>

        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          To bulk import SLAs, you need to create an SLA connector first.
        </p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 max-w-2xl mx-auto">
          <div className="flex items-start">
            <FiSettings className="text-blue-600 mr-3 mt-1 flex-shrink-0" />
            <div className="text-left">
              <h4 className="font-semibold text-gray-900 mb-2">Setup Required</h4>
              <p className="text-sm text-gray-700 mb-3">
                Go to <strong>Tools → Metadata Retrieval</strong> to create an SLA connector. 
                Available platforms:
              </p>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• <strong>Custom API</strong> - Connect to your REST API</li>
                <li>• <strong>Demo SLA Simulator</strong> - Test with sample data</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center space-x-4">
          <Button variant="outline" onClick={onSkip}>
            <FiSkipForward className="mr-2" />
            Skip This Step
          </Button>
          <Button onClick={() => navigate('/tools/metadata-retrieval')}>
            <FiSettings className="mr-2" />
            Setup SLA Connector
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Step 4: Import SLAs (Optional)
        </h2>
        <p className="text-gray-600">
          Select an SLA connector to import Service Level Agreements. This step is optional.
        </p>
      </div>

      {/* Success message */}
      {slas.length > 0 && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <FiCheck className="text-green-600 mr-3 flex-shrink-0" />
            <div>
              <p className="font-medium text-green-900">
                {slas.length} SLA{slas.length !== 1 ? 's' : ''} imported successfully
              </p>
              {selectedConnector && (
                <p className="text-sm text-green-700 mt-1">
                  From: {selectedConnector.connector_name}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Educational Note - IMPORTANT */}
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <FiAlertCircle className="text-orange-600 mr-3 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-orange-900">
            <p className="font-medium mb-1">⚠️ Important: SLA Linking Requirement</p>
            <p>
              <strong>Each SLA must link to EITHER a service OR a job (not both).</strong>
            </p>
            <ul className="mt-2 space-y-1">
              <li>• <strong>Service-level SLAs</strong>: Set service_id, leave job_id empty</li>
              <li>• <strong>Job-level SLAs</strong>: Set job_id, leave service_id empty</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Available References */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <p className="text-sm font-medium text-gray-900 mb-2">
            Available Services ({existingServices.length}):
          </p>
          {existingServices.length > 0 ? (
            <div className="space-y-1">
              {existingServices.slice(0, 3).map((service, idx) => (
                <div key={idx} className="text-xs text-gray-700">
                  {service.service_name || service.name} ({service.service_id})
                </div>
              ))}
              {existingServices.length > 3 && (
                <div className="text-xs text-gray-500">
                  +{existingServices.length - 3} more
                </div>
              )}
            </div>
          ) : (
            <div className="text-xs text-gray-500 italic">
              No services imported
            </div>
          )}
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <p className="text-sm font-medium text-gray-900 mb-2">
            Available Jobs ({existingJobs.length}):
          </p>
          {existingJobs.length > 0 ? (
            <div className="space-y-1">
              {existingJobs.slice(0, 3).map((job, idx) => (
                <div key={idx} className="text-xs text-gray-700">
                  {job.job_name || job.name} ({job.job_id})
                </div>
              ))}
              {existingJobs.length > 3 && (
                <div className="text-xs text-gray-500">
                  +{existingJobs.length - 3} more
                </div>
              )}
            </div>
          ) : (
            <div className="text-xs text-gray-500 italic">
              No jobs imported
            </div>
          )}
        </div>
      </div>

      <ConnectorSelector
        connectors={connectors}
        selectedConnector={selectedConnector}
        onImportData={handleImportData}
        connectorType="sla"
      />

      {/* Skip button */}
      <div className="mt-6 text-center">
        <Button variant="outline" onClick={onSkip}>
          <FiSkipForward className="mr-2" />
          Skip SLA Import
        </Button>
      </div>
    </div>
  );
};

export default BulkStep4_SelectSLAConnector;
