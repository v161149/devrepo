/**
 * BulkOnboardingWizard.jsx
 * 
 * Main bulk onboarding wizard for importing multiple assets, services, jobs, and SLAs
 * via connectors from external systems
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiCheck, FiChevronRight, FiChevronLeft, FiUpload } from 'react-icons/fi';
import Card from '../../components/Card';
import Button from '../../components/Button';

// Import step components
import BulkStep1_SelectAssetConnector from './BulkStep1_SelectAssetConnector';
import BulkStep2_SelectServiceConnector from './BulkStep2_SelectServiceConnector';
import BulkStep3_SelectJobConnector from './BulkStep3_SelectJobConnector';
import BulkStep4_SelectSLAConnector from './BulkStep4_SelectSLAConnector';
import BulkStep5_ReviewData from './BulkStep5_ReviewData';

const STEPS = [
  { number: 1, title: 'Import Assets', required: true, icon: FiUpload },
  { number: 2, title: 'Import Services', required: false, icon: FiUpload },
  { number: 3, title: 'Import Jobs', required: false, icon: FiUpload },
  { number: 4, title: 'Import SLAs', required: false, icon: FiUpload },
  { number: 5, title: 'Review & Complete', required: true, icon: FiCheck }
];

const BulkOnboardingWizard = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  // Wizard state - stores imported data and selected connectors
  const [wizardState, setWizardState] = useState({
    // Imported data
    assets: [],
    services: [],
    jobs: [],
    slas: [],
    
    // Selected connectors (for tracking)
    selectedAssetConnector: null,
    selectedServiceConnector: null,
    selectedJobConnector: null,
    selectedSLAConnector: null,
    
    // Validation errors
    validationErrors: {
      services: [],
      jobs: [],
      slas: []
    }
  });

  // Update wizard state
  const updateWizardState = (updates) => {
    setWizardState(prev => ({ ...prev, ...updates }));
  };

  // Navigation handlers
  const canGoNext = () => {
    if (currentStep === 1) {
      // Assets are required
      return wizardState.assets.length > 0;
    }
    // Other steps are optional
    return true;
  };

  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkipStep = () => {
    // Skip optional steps (2, 3, 4)
    if (currentStep >= 2 && currentStep <= 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleComplete = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const token = localStorage.getItem('token');
      
      // Prepare payload
      const payload = {
        assets: wizardState.assets,
        services: wizardState.services,
        jobs: wizardState.jobs,
        slas: wizardState.slas
      };

      console.log('Submitting bulk onboarding:', payload);

      // Submit to backend
      const response = await fetch('http://localhost:5000/api/v1/bulk-onboarding/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to complete bulk onboarding');
      }

      const result = await response.json();
      console.log('Bulk onboarding successful:', result);

      // Success - redirect to process flow
      const firstAssetId = result.data?.assets?.[0]?.asset_id;
      if (firstAssetId) {
        navigate(`/process-flow?highlight=${firstAssetId}`);
      } else {
        navigate('/process-flow');
      }

    } catch (error) {
      console.error('Bulk onboarding error:', error);
      setSubmitError(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Render current step
  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <BulkStep1_SelectAssetConnector
            assets={wizardState.assets}
            selectedConnector={wizardState.selectedAssetConnector}
            onDataImported={(data, connector) => {
              updateWizardState({
                assets: data,
                selectedAssetConnector: connector
              });
            }}
          />
        );
      case 2:
        return (
          <BulkStep2_SelectServiceConnector
            services={wizardState.services}
            selectedConnector={wizardState.selectedServiceConnector}
            existingAssets={wizardState.assets}
            onDataImported={(data, connector) => {
              updateWizardState({
                services: data,
                selectedServiceConnector: connector
              });
            }}
            onSkip={handleSkipStep}
          />
        );
      case 3:
        return (
          <BulkStep3_SelectJobConnector
            jobs={wizardState.jobs}
            selectedConnector={wizardState.selectedJobConnector}
            existingAssets={wizardState.assets}
            existingServices={wizardState.services}
            onDataImported={(data, connector) => {
              updateWizardState({
                jobs: data,
                selectedJobConnector: connector
              });
            }}
            onSkip={handleSkipStep}
          />
        );
      case 4:
        return (
          <BulkStep4_SelectSLAConnector
            slas={wizardState.slas}
            selectedConnector={wizardState.selectedSLAConnector}
            existingServices={wizardState.services}
            existingJobs={wizardState.jobs}
            onDataImported={(data, connector) => {
              updateWizardState({
                slas: data,
                selectedSLAConnector: connector
              });
            }}
            onSkip={handleSkipStep}
          />
        );
      case 5:
        return (
          <BulkStep5_ReviewData
            assets={wizardState.assets}
            services={wizardState.services}
            jobs={wizardState.jobs}
            slas={wizardState.slas}
            validationErrors={wizardState.validationErrors}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Bulk Onboarding</h1>
          <p className="text-gray-600 mt-2">
            Import multiple assets, services, jobs, and SLAs using data connectors
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.number;
              const isCompleted = currentStep > step.number;
              const isLast = index === STEPS.length - 1;

              return (
                <React.Fragment key={step.number}>
                  <div className="flex flex-col items-center flex-1">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                        isCompleted
                          ? 'bg-green-500 text-white'
                          : isActive
                          ? 'bg-primary-500 text-white ring-4 ring-primary-100'
                          : 'bg-gray-200 text-gray-500'
                      }`}
                    >
                      {isCompleted ? (
                        <FiCheck className="w-6 h-6" />
                      ) : (
                        <Icon className="w-6 h-6" />
                      )}
                    </div>
                    <div className="mt-2 text-center">
                      <p
                        className={`text-sm font-medium ${
                          isActive || isCompleted ? 'text-gray-900' : 'text-gray-500'
                        }`}
                      >
                        {step.title}
                      </p>
                      {!step.required && (
                        <p className="text-xs text-gray-400">Optional</p>
                      )}
                    </div>
                  </div>

                  {/* Connector Line */}
                  {!isLast && (
                    <div
                      className={`h-1 flex-1 mx-4 transition-all ${
                        isCompleted ? 'bg-green-500' : 'bg-gray-200'
                      }`}
                      style={{ marginTop: '-40px' }}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Error Display */}
        {submitError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-800">
              <strong>Error:</strong> {submitError}
            </p>
          </div>
        )}

        {/* Step Content */}
        <Card className="mb-8">
          {renderStep()}
        </Card>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between">
          <div>
            {currentStep > 1 && (
              <Button variant="secondary" onClick={handlePrevious}>
                <FiChevronLeft className="mr-2" />
                Previous
              </Button>
            )}
          </div>

          <div className="flex items-center space-x-4">
            {/* Skip button for optional steps */}
            {currentStep >= 2 && currentStep <= 4 && (
              <Button variant="outline" onClick={handleSkipStep}>
                Skip This Step
              </Button>
            )}

            {/* Next/Complete button */}
            {currentStep < STEPS.length ? (
              <Button onClick={handleNext} disabled={!canGoNext()}>
                Next
                <FiChevronRight className="ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleComplete}
                disabled={isSubmitting || wizardState.assets.length === 0}
              >
                {isSubmitting ? 'Importing...' : 'Complete Onboarding'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BulkOnboardingWizard;
