/**
 * Step 2: Add Applications
 * Add applications/assets under the selected AIT
 */

import React, { useState } from 'react';
import { Plus, Trash2, Database } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { ASSET_TYPES, getAssetTypeIcon } from '../../constants/assetTypes';

const Step2_AddApplications = ({ ait, applications, onAdd, onUpdate, onDelete, onNext, onBack }) => {
  const [showForm, setShowForm] = useState(false);
  const [newApp, setNewApp] = useState({
    asset_name: '',
    asset_type: 'application',
    asset_owner: '',
    description: ''
  });

  const handleAddApplication = (e) => {
    e.preventDefault();
    onAdd(newApp);
    setNewApp({
      asset_name: '',
      asset_type: 'application',
      asset_owner: '',
      description: ''
    });
    setShowForm(false);
  };

  const handleNext = () => {
    if (applications.length === 0) {
      alert('Please add at least one application before proceeding');
      return;
    }
    onNext();
  };

  return (
    <Card>
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Database size={32} className="text-purple-600" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Add Applications</h2>
              <p className="text-gray-600 mt-1">
                Add applications for <strong>{ait.name}</strong>
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2"
          >
            <Plus size={18} />
            Add Application
          </Button>
        </div>

        {/* Add Application Form */}
        {showForm && (
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">New Application</h3>
            <form onSubmit={handleAddApplication} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Application Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newApp.asset_name}
                    onChange={(e) => setNewApp({ ...newApp, asset_name: e.target.value })}
                    placeholder="e.g., Customer Portal"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Asset Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={newApp.asset_type}
                    onChange={(e) => setNewApp({ ...newApp, asset_type: e.target.value })}
                  >
                    {ASSET_TYPES.map(type => (
                      <option key={type.id} value={type.id}>
                        {type.icon} {type.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Application Owner
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={newApp.asset_owner}
                  onChange={(e) => setNewApp({ ...newApp, asset_owner: e.target.value })}
                  placeholder="e.g., John Doe"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  value={newApp.description}
                  onChange={(e) => setNewApp({ ...newApp, description: e.target.value })}
                  placeholder="Describe the application..."
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="secondary" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Add Application
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* Applications List */}
        {applications.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <Database size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-600">No applications added yet</p>
            <p className="text-sm text-gray-500 mt-2">
              Click "Add Application" to get started
            </p>
          </div>
        ) : (
          <div className="space-y-4 mb-6">
            {applications.map((app) => (
              <div key={app.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="text-3xl">{getAssetTypeIcon(app.asset_type)}</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{app.asset_name}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        Type: {ASSET_TYPES.find(t => t.id === app.asset_type)?.name}
                      </p>
                      {app.asset_owner && (
                        <p className="text-sm text-gray-600">Owner: {app.asset_owner}</p>
                      )}
                      {app.description && (
                        <p className="text-sm text-gray-500 mt-2">{app.description}</p>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => onDelete(app.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Info Box */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-purple-900 mb-2">
            💡 Tip: Application Management
          </h3>
          <p className="text-sm text-purple-800">
            Add all applications that belong to this AIT. In the next step, you'll define SLAs 
            for these applications. Services and jobs will then be linked to those SLAs.
          </p>
        </div>

        {/* Actions */}
        <div className="flex justify-between pt-4 border-t">
          <Button variant="secondary" onClick={onBack}>
            Back
          </Button>
          <Button onClick={handleNext}>
            Next: Define SLAs
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default Step2_AddApplications;
