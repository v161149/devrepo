/**
 * Step 1: Create AIT (Business Unit)
 * First step in the enhanced onboarding workflow
 */

import React from 'react';
import { Building2 } from 'lucide-react';
import Card from '../../components/Card';
import Button from '../../components/Button';

const Step1_CreateAIT = ({ ait, errors, onUpdate, onNext }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    onNext();
  };

  return (
    <Card>
      <div className="p-8">
        <div className="flex items-center gap-3 mb-6">
          <Building2 size={32} className="text-blue-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Create AIT</h2>
            <p className="text-gray-600 mt-1">
              Define your Application Integration Team or Business Unit
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              AIT Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.name ? 'border-red-500' : 'border-gray-300'
              }`}
              value={ait.name}
              onChange={(e) => onUpdate('name', e.target.value)}
              placeholder="e.g., Finance Department"
            />
            {errors.name && (
              <p className="mt-1 text-sm text-red-600">{errors.name}</p>
            )}
          </div>

          {/* Short Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Short Name
            </label>
            <input
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={ait.short_name}
              onChange={(e) => onUpdate('short_name', e.target.value)}
              placeholder="e.g., FIN"
              maxLength={10}
            />
            <p className="mt-1 text-sm text-gray-500">
              Optional abbreviation (max 10 characters)
            </p>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <textarea
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={ait.description}
              onChange={(e) => onUpdate('description', e.target.value)}
              placeholder="Describe the purpose and scope of this AIT..."
            />
          </div>

          {/* Cost Center */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cost Center
            </label>
            <input
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={ait.cost_center}
              onChange={(e) => onUpdate('cost_center', e.target.value)}
              placeholder="e.g., CC-12345"
            />
          </div>

          {/* Tech Support Contact */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tech Support Contact
            </label>
            <input
              type="email"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={ait.tech_support_contact}
              onChange={(e) => onUpdate('tech_support_contact', e.target.value)}
              placeholder="support@example.com"
            />
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-2">
              What is an AIT?
            </h3>
            <p className="text-sm text-blue-800">
              An AIT (Application Integration Team) or Business Unit represents a organizational 
              division that owns and manages applications. This is the top level of your hierarchy: 
              <strong> AITs → Applications → SLAs → Services/Jobs</strong>
            </p>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-4 pt-4 border-t">
            <Button
              type="button"
              variant="secondary"
              onClick={() => window.location.href = '/dashboard'}
            >
              Cancel
            </Button>
            <Button type="submit">
              Next: Add Applications
            </Button>
          </div>
        </form>
      </div>
    </Card>
  );
};

export default Step1_CreateAIT;
