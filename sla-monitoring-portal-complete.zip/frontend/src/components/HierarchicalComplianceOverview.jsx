/**
 * Hierarchical SLA Compliance Overview Component - UPDATED
 * Supports drill-down from AIT -> Asset -> SLA -> Service/Job
 * With search and period selection
 * REMOVED: Child Entities column
 */

import React, { useState, useEffect } from 'react';
import { 
  FiChevronRight, FiChevronDown, FiSearch, FiAlertTriangle, 
  FiCheckCircle, FiTrendingDown, FiCalendar 
} from 'react-icons/fi';
import apiService from '../services/api';

const HierarchicalComplianceOverview = () => {
  const [period, setPeriod] = useState('day');
  const [customDates, setCustomDates] = useState({ start: '', end: '' });
  const [level, setLevel] = useState('ait');
  const [breadcrumb, setBreadcrumb] = useState([{ level: 'ait', id: null, name: 'All AITs' }]);
  const [summary, setSummary] = useState(null);
  const [entities, setEntities] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, [period, level, breadcrumb, search]);

  const loadData = async () => {
    setLoading(true);
    try {
      const currentLevel = breadcrumb[breadcrumb.length - 1];
      const params = {
        period,
        level,
        parent_id: currentLevel.id,
        search
      };

      if (period === 'custom') {
        params.start_date = customDates.start;
        params.end_date = customDates.end;
      }

      // Load summary
      const summaryRes = await apiService.compliance.getSummary(params);
      setSummary(summaryRes.data.data);

      // Load entities
      const entitiesRes = await apiService.compliance.getOverview(params);
      setEntities(entitiesRes.data.data || []);
    } catch (error) {
      console.error('Error loading compliance data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDrillDown = async (entity) => {
    const levelMap = {
      ait: { next: 'asset', label: 'Assets' },
      asset: { next: 'sla', label: 'SLAs' },
      sla: { next: 'service', label: 'Services/Jobs' },
    };

    const nextLevel = levelMap[level];
    if (!nextLevel) return;

    setBreadcrumb([...breadcrumb, { 
      level: nextLevel.next, 
      id: entity.id, 
      name: entity.name 
    }]);
    setLevel(nextLevel.next);
  };

  const handleBreadcrumbClick = (index) => {
    const newBreadcrumb = breadcrumb.slice(0, index + 1);
    setBreadcrumb(newBreadcrumb);
    setLevel(newBreadcrumb[newBreadcrumb.length - 1].level);
  };

  const getStatusBadge = (complianceRate) => {
    if (complianceRate >= 95) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
          <FiCheckCircle className="mr-1" />
          Healthy
        </span>
      );
    } else if (complianceRate >= 90) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
          <FiAlertTriangle className="mr-1" />
          At Risk
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
          <FiTrendingDown className="mr-1" />
          Breach
        </span>
      );
    }
  };

  const levelLabels = {
    ait: 'AITs',
    asset: 'Applications',
    sla: 'SLAs',
    service: 'Services',
    job: 'Jobs'
  };

  const canDrillDown = (entity) => {
    // Can drill down if not at service/job level AND entity has children
    return (level !== 'job' && level !== 'service' && entity.child_count > 0);
  };

  return (
    <div className="space-y-6">
      {/* Controls Bar */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Period Selector */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <FiCalendar className="inline mr-2" />
              Report Period
            </label>
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="day">Last 24 Hours</option>
              <option value="week">Last 7 Days</option>
              <option value="month">Last 30 Days</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>

          {/* Custom Date Range */}
          {period === 'custom' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <input
                  type="date"
                  value={customDates.start}
                  onChange={(e) => setCustomDates({ ...customDates, start: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date
                </label>
                <input
                  type="date"
                  value={customDates.end}
                  onChange={(e) => setCustomDates({ ...customDates, end: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
            </>
          )}

          {/* Search */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <FiSearch className="inline mr-2" />
              Search {levelLabels[level]}
            </label>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search ${levelLabels[level].toLowerCase()}...`}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Summary Metrics */}
      {summary && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Overall SLA Compliance</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {summary.overall_compliance_rate}%
                </p>
              </div>
              <div className={`p-3 rounded-full ${
                summary.overall_compliance_rate >= 95 
                  ? 'bg-green-100' 
                  : summary.overall_compliance_rate >= 90 
                  ? 'bg-yellow-100' 
                  : 'bg-red-100'
              }`}>
                <FiCheckCircle className={`text-2xl ${
                  summary.overall_compliance_rate >= 95 
                    ? 'text-green-600' 
                    : summary.overall_compliance_rate >= 90 
                    ? 'text-yellow-600' 
                    : 'text-red-600'
                }`} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{levelLabels[level]} at Risk</p>
                <p className="text-3xl font-bold text-yellow-600 mt-2">
                  {summary.entities_at_risk}
                </p>
              </div>
              <div className="p-3 rounded-full bg-yellow-100">
                <FiAlertTriangle className="text-2xl text-yellow-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Breaches</p>
                <p className="text-3xl font-bold text-red-600 mt-2">
                  {summary.active_breaches}
                </p>
              </div>
              <div className="p-3 rounded-full bg-red-100">
                <FiTrendingDown className="text-2xl text-red-600" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Breadcrumb */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <nav className="flex" aria-label="Breadcrumb">
          <ol className="flex items-center space-x-2">
            {breadcrumb.map((crumb, index) => (
              <li key={index} className="flex items-center">
                {index > 0 && <FiChevronRight className="text-gray-400 mx-2" />}
                <button
                  onClick={() => handleBreadcrumbClick(index)}
                  className={`text-sm font-medium ${
                    index === breadcrumb.length - 1
                      ? 'text-indigo-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {crumb.name}
                </button>
              </li>
            ))}
          </ol>
        </nav>
      </div>

      {/* Entities Table - REMOVED Child Entities Column */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Compliance Rate
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Compliant / Total
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan="5" className="px-6 py-4 text-center text-gray-500">
                    Loading...
                  </td>
                </tr>
              ) : entities.length === 0 ? (
                <tr>
                  <td colSpan="5" className="px-6 py-4 text-center text-gray-500">
                    No data available
                  </td>
                </tr>
              ) : (
                entities.map((entity) => (
                  <tr 
                    key={entity.id} 
                    className="hover:bg-gray-50 cursor-pointer"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="text-sm font-medium text-gray-900">
                          {entity.name}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(entity.compliance_rate)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="text-sm text-gray-900 font-semibold">
                          {entity.compliance_rate}%
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {entity.compliant_checks} / {entity.total_checks}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {canDrillDown(entity) && (
                        <button
                          onClick={() => handleDrillDown(entity)}
                          className="text-indigo-600 hover:text-indigo-900 flex items-center"
                        >
                          Drill Down
                          <FiChevronRight className="ml-1" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default HierarchicalComplianceOverview;
