/**
 * CreateJobModal Component - ENHANCED
 * 
 * CHANGES:
 * - Added "Parent" dropdown to select Asset or Service
 * - When creating from Asset Detail, shows all services under that asset
 * - Jobs can be linked to either asset directly OR to a specific service
 */

import React, { useState, useEffect } from 'react';
import { FiX, FiAlertCircle } from 'react-icons/fi';
import Button from './Button';
import apiService from '../services/api';

// Job types matching manual onboarding
const JOB_TYPES = [
  { id: 'monitoring', name: 'Monitoring' },
  { id: 'backup', name: 'Backup' },
  { id: 'maintenance', name: 'Maintenance' },
  { id: 'deployment', name: 'Deployment' },
  { id: 'health_check', name: 'Health Check' },
  { id: 'security_scan', name: 'Security Scan' },
  { id: 'log_collection', name: 'Log Collection' },
  { id: 'data_sync', name: 'Data Synchronization' },
  { id: 'other', name: 'Other' }
];

// Log template presets for jobs (matching Step3)
const JOB_LOG_TEMPLATE_PRESETS = {
  'job_execution': {
    name: 'Job Execution',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      duration_seconds: '{{duration}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    }
  },
  'data_processing': {
    name: 'Data Processing',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      duration_seconds: '{{duration}}',
      records_processed: '{{records}}',
      records_failed: '{{failed}}',
      message: '{{message}}',
      timestamp: '{{timestamp}}'
    }
  },
  'scheduled_task': {
    name: 'Scheduled Task',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      scheduled_time: '{{scheduled}}',
      actual_start_time: '{{start_time}}',
      end_time: '{{end_time}}',
      on_time: '{{on_time}}',
      timestamp: '{{timestamp}}'
    }
  },
  'custom': {
    name: 'Custom Template',
    template: {
      identifier: '{{job_identifier}}',
      status: '{{status}}',
      timestamp: '{{timestamp}}'
    }
  }
};

const CreateJobModal = ({ isOpen, onClose, onSuccess, preselectedAssetId, preselectedServiceId }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formErrors, setFormErrors] = useState({});
  const [services, setServices] = useState([]); // Services under the asset OR all services
  const [assets, setAssets] = useState([]); // All assets (for standalone mode)
  
  // NEW: Log monitoring states
  const [logConnectors, setLogConnectors] = useState([]);
  const [showLogConfig, setShowLogConfig] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState('');

  const [formData, setFormData] = useState({
    job_name: '',
    job_type: '',
    schedule: '',
    description: '',
    expected_duration: '',
    parent_type: 'service', // 'asset' or 'service' (for Asset Detail mode)
    link_to_type: '', // 'asset' or 'service' (for standalone mode)
    selected_asset_id: '', // Selected asset (standalone mode)
    selected_service_id: '', // Selected service ID
    is_active: true,
    // NEW: Log monitoring fields
    job_identifier: '',
    log_server_type: '',
    log_template: ''
  });

  // Load data when modal opens
  useEffect(() => {
    if (isOpen) {
      // Always load log connectors
      loadLogConnectors();
      
      if (!preselectedAssetId && !preselectedServiceId) {
        // Standalone mode - load all assets and services
        loadAllAssetsAndServices();
      } else if (preselectedAssetId && !preselectedServiceId) {
        // Asset Detail mode - load services under this asset
        loadServices();
      }
      // Service Detail mode - no loading needed, service is preselected
    }
  }, [isOpen, preselectedAssetId, preselectedServiceId]);

  const loadServices = async () => {
    try {
      const response = await apiService.assets.getServices(preselectedAssetId);
      const servicesList = response.data?.data || response.data || [];
      setServices(servicesList);
      
      // Auto-select first service if available
      if (servicesList.length > 0) {
        setFormData(prev => ({
          ...prev,
          selected_service_id: servicesList[0].service_id
        }));
      }
    } catch (err) {
      console.error('Error loading services:', err);
      setServices([]);
    }
  };

  const loadAllAssetsAndServices = async () => {
    try {
      const [assetsRes, servicesRes] = await Promise.all([
        apiService.assets.list(),
        apiService.services.getAll()
      ]);
      setAssets(assetsRes.data?.data || []);
      setServices(servicesRes.data?.data || []);
    } catch (err) {
      console.error('Error loading data:', err);
      setAssets([]);
      setServices([]);
    }
  };

  const loadLogConnectors = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/v1/log-connectors', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        let connectors = [];
        if (Array.isArray(result)) {
          connectors = result;
        } else if (result.data && Array.isArray(result.data)) {
          connectors = result.data;
        }
        setLogConnectors(connectors);
      }
    } catch (err) {
      console.error('Error loading log connectors:', err);
      setLogConnectors([]);
    }
  };

  const handlePresetLoad = (presetKey) => {
    setSelectedPreset(presetKey);
    if (presetKey && JOB_LOG_TEMPLATE_PRESETS[presetKey]) {
      const preset = JOB_LOG_TEMPLATE_PRESETS[presetKey];
      setFormData(prev => ({
        ...prev,
        log_template: JSON.stringify(preset.template, null, 2)
      }));
    }
  };

  const validateLogTemplate = (template) => {
    if (!template) return true;
    try {
      JSON.parse(template);
      return true;
    } catch (e) {
      return false;
    }
  };

  if (!isOpen) return null;

  const handleClose = () => {
    setFormData({
      job_name: '',
      job_type: '',
      schedule: '',
      description: '',
      deployment_location: '',
      expected_duration: '',
      parent_type: 'service',
      link_to_type: '',
      selected_asset_id: '',
      selected_service_id: '',
      is_active: true
    });
    setError('');
    setFormErrors({});
    setServices([]);
    setAssets([]);
    onClose();
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (formErrors[field]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
    setError('');
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.job_name || formData.job_name.trim() === '') {
      errors.job_name = 'Job name is required';
    }

    if (!formData.job_type || formData.job_type.trim() === '') {
      errors.job_type = 'Job type is required';
    }

    if (!formData.schedule || formData.schedule.trim() === '') {
      errors.schedule = 'Schedule is required';
    }

    // Standalone mode validation
    if (!preselectedAssetId && !preselectedServiceId) {
      if (!formData.link_to_type) {
        errors.link_to_type = 'Please select what to link to';
      } else if (formData.link_to_type === 'asset' && !formData.selected_asset_id) {
        errors.selected_asset_id = 'Please select an asset';
      } else if (formData.link_to_type === 'service' && !formData.selected_service_id) {
        errors.selected_service_id = 'Please select a service';
      }
    }
    // Asset Detail mode validation
    else if (preselectedAssetId && !preselectedServiceId) {
      if (formData.parent_type === 'service' && !formData.selected_service_id && services.length > 0) {
        errors.selected_service_id = 'Please select a service';
      }
    }

    return errors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Determine parent based on mode
      let finalAssetId = null;
      let finalServiceId = null;

      if (preselectedServiceId) {
        // Mode 1: Called from Service Detail page
        finalServiceId = preselectedServiceId;
      } else if (preselectedAssetId) {
        // Mode 2: Called from Asset Detail page
        if (formData.parent_type === 'asset') {
          finalAssetId = preselectedAssetId;
        } else {
          finalServiceId = formData.selected_service_id;
        }
      } else {
        // Mode 3: Standalone (from Jobs page)
        if (formData.link_to_type === 'asset') {
          finalAssetId = formData.selected_asset_id;
        } else {
          finalServiceId = formData.selected_service_id;
        }
      }

      // Prepare job data
      const jobData = {
        job_name: formData.job_name,
        job_type: formData.job_type,
        schedule: formData.schedule,
        description: formData.description || '',
        expected_duration: formData.expected_duration ? parseInt(formData.expected_duration) : null,
        is_active: formData.is_active,
        asset_id: finalAssetId,
        service_id: finalServiceId
      };
      
      // Add log monitoring fields as top-level properties (like services)
      if (formData.job_identifier) {
        jobData.job_identifier = formData.job_identifier;
      }
      if (formData.log_server_type) {
        jobData.log_server_type = formData.log_server_type;
      }
      if (formData.log_template) {
        jobData.log_template = formData.log_template;
      }

      console.log('Creating job:', jobData);

      const response = await apiService.jobs.create(jobData);
      
      console.log('Job created successfully:', response);

      // Call success callback
      if (onSuccess) {
        onSuccess(response.data);
      }

      // Close modal
      handleClose();

    } catch (err) {
      console.error('Error creating job:', err);
      setError(err.response?.data?.message || err.message || 'Failed to create job');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white">
          <h2 className="text-xl font-semibold text-gray-900">Add New Job</h2>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <FiX className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6">
          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            {/* Standalone Mode - Link To Selection (from Jobs page) */}
            {!preselectedAssetId && !preselectedServiceId && (
              <>
                {/* Link To dropdown */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Link To <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.link_to_type}
                    onChange={(e) => {
                      handleInputChange('link_to_type', e.target.value);
                      // Reset selections when type changes
                      handleInputChange('selected_asset_id', '');
                      handleInputChange('selected_service_id', '');
                    }}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                      formErrors.link_to_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                  >
                    <option value="">Select what to link to...</option>
                    <option value="asset">Asset</option>
                    <option value="service">Service</option>
                  </select>
                  {formErrors.link_to_type && (
                    <p className="text-sm text-red-600 mt-1">{formErrors.link_to_type}</p>
                  )}
                </div>

                {/* Asset Selection */}
                {formData.link_to_type === 'asset' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Select Asset <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.selected_asset_id}
                      onChange={(e) => handleInputChange('selected_asset_id', e.target.value)}
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                        formErrors.selected_asset_id ? 'border-red-300 bg-red-50' : 'border-gray-300'
                      }`}
                    >
                      <option value="">Select asset...</option>
                      {assets.map(asset => (
                        <option key={asset.asset_id} value={asset.asset_id}>
                          {asset.asset_name} ({asset.asset_type})
                        </option>
                      ))}
                    </select>
                    {formErrors.selected_asset_id && (
                      <p className="text-sm text-red-600 mt-1">{formErrors.selected_asset_id}</p>
                    )}
                  </div>
                )}

                {/* Service Selection */}
                {formData.link_to_type === 'service' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Select Service <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.selected_service_id}
                      onChange={(e) => handleInputChange('selected_service_id', e.target.value)}
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                        formErrors.selected_service_id ? 'border-red-300 bg-red-50' : 'border-gray-300'
                      }`}
                    >
                      <option value="">Select service...</option>
                      {services.map(service => (
                        <option key={service.service_id} value={service.service_id}>
                          {service.name}
                        </option>
                      ))}
                    </select>
                    {formErrors.selected_service_id && (
                      <p className="text-sm text-red-600 mt-1">{formErrors.selected_service_id}</p>
                    )}
                  </div>
                )}
              </>
            )}

            {/* Parent Selection - Only show if from Asset Detail and services exist */}
            {preselectedAssetId && !preselectedServiceId && services.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Add Job To <span className="text-red-500">*</span>
                </label>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="service"
                      checked={formData.parent_type === 'service'}
                      onChange={(e) => handleInputChange('parent_type', e.target.value)}
                      className="mr-2"
                    />
                    <span className="text-sm">Service (recommended)</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="asset"
                      checked={formData.parent_type === 'asset'}
                      onChange={(e) => handleInputChange('parent_type', e.target.value)}
                      className="mr-2"
                    />
                    <span className="text-sm">Asset directly</span>
                  </label>
                </div>
              </div>
            )}

            {/* Service Selection - Show when parent_type is service */}
            {preselectedAssetId && !preselectedServiceId && formData.parent_type === 'service' && services.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Service <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.selected_service_id}
                  onChange={(e) => handleInputChange('selected_service_id', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                    formErrors.selected_service_id ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  }`}
                >
                  <option value="">Select a service...</option>
                  {services.map(service => (
                    <option key={service.service_id} value={service.service_id}>
                      {service.name || service.service_name}
                    </option>
                  ))}
                </select>
                {formErrors.selected_service_id && (
                  <p className="text-sm text-red-600 mt-1">{formErrors.selected_service_id}</p>
                )}
              </div>
            )}

            {/* Job Name - MANDATORY */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.job_name}
                onChange={(e) => handleInputChange('job_name', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                  formErrors.job_name ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="e.g., Daily ETL Job"
              />
              {formErrors.job_name && (
                <p className="text-sm text-red-600 mt-1">{formErrors.job_name}</p>
              )}
            </div>

            {/* Job Type - MANDATORY */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job Type <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.job_type}
                onChange={(e) => handleInputChange('job_type', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent ${
                  formErrors.job_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
              >
                <option value="">Select type...</option>
                {JOB_TYPES.map(type => (
                  <option key={type.id} value={type.id}>{type.name}</option>
                ))}
              </select>
              {formErrors.job_type && (
                <p className="text-sm text-red-600 mt-1">{formErrors.job_type}</p>
              )}
            </div>

            {/* Schedule (Cron) - MANDATORY */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Schedule (Cron Expression) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.schedule}
                onChange={(e) => handleInputChange('schedule', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent font-mono ${
                  formErrors.schedule ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
                placeholder="e.g., 0 2 * * *"
              />
              {formErrors.schedule && (
                <p className="text-sm text-red-600 mt-1">{formErrors.schedule}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Example: "0 2 * * *" = Daily at 2:00 AM
              </p>
            </div>

            {/* Description - OPTIONAL */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                rows={3}
                placeholder="Optional description..."
              />
            </div>

            {/* Expected Duration - OPTIONAL */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Expected Duration (minutes)
              </label>
              <input
                type="number"
                value={formData.expected_duration ? Math.floor(formData.expected_duration / 60) : ''}
                onChange={(e) => {
                  const minutes = parseInt(e.target.value) || 0;
                  handleInputChange('expected_duration', minutes * 60); // Convert to seconds
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="e.g., 30"
                min="1"
              />
            </div>

            {/* Active Status */}
            <div className="flex items-center">
              <input
                type="checkbox"
                id="is_active"
                checked={formData.is_active}
                onChange={(e) => handleInputChange('is_active', e.target.checked)}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <label htmlFor="is_active" className="ml-2 block text-sm text-gray-900">
                Active
              </label>
            </div>
          </div>

          {/* Log Monitoring Configuration - Collapsible Section */}
          <div className="border-t border-gray-200 pt-4 mt-4">
            <button
              type="button"
              onClick={() => setShowLogConfig(!showLogConfig)}
              className="flex items-center justify-between w-full text-left mb-3 hover:bg-gray-50 p-2 rounded transition-colors"
            >
              <span className="text-sm font-medium text-gray-700">
                {showLogConfig ? '▼' : '▶'} Log Monitoring Configuration (Optional)
              </span>
            </button>

            {showLogConfig && (
              <div className="space-y-4 pl-4 border-l-2 border-primary-200">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                  <div className="flex items-start gap-2">
                    <FiAlertCircle className="text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-blue-800">
                      Configure log-based monitoring for this job. Set up log server connectors in <strong>Tools → Log Server Setup</strong>.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Job Identifier */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Job Identifier
                    </label>
                    <input
                      type="text"
                      value={formData.job_identifier}
                      onChange={(e) => handleInputChange('job_identifier', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                      placeholder="e.g., ETL-DAILY-001"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Unique identifier used in log entries
                    </p>
                  </div>

                  {/* Log Server Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Log Server Type
                    </label>
                    <select
                      value={formData.log_server_type}
                      onChange={(e) => handleInputChange('log_server_type', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="">Select log server...</option>
                      {logConnectors.length === 0 ? (
                        <option value="" disabled>No log servers configured</option>
                      ) : (
                        logConnectors
                          .filter(c => c.is_active)
                          .map(connector => (
                            <option key={connector.connector_id} value={connector.log_server_type}>
                              {connector.connector_name} ({connector.log_server_type})
                            </option>
                          ))
                      )}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">
                      Select the log server where this job sends logs
                    </p>
                  </div>

                  {/* Log Template */}
                  <div className="col-span-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-sm font-medium text-gray-700">
                        Log Entry Template
                      </label>
                      <div className="flex items-center gap-2">
                        <select
                          value={selectedPreset}
                          onChange={(e) => handlePresetLoad(e.target.value)}
                          className="text-xs px-2 py-1 border border-gray-300 rounded"
                        >
                          <option value="">Load Preset...</option>
                          {Object.entries(JOB_LOG_TEMPLATE_PRESETS).map(([key, preset]) => (
                            <option key={key} value={key}>{preset.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <textarea
                      value={formData.log_template}
                      onChange={(e) => handleInputChange('log_template', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                      rows={10}
                      placeholder='{
  "identifier": "{{job_identifier}}",
  "status": "{{status}}",
  "start_time": "{{start_time}}",
  "end_time": "{{end_time}}",
  "timestamp": "{{timestamp}}"
}'
                    />
                    {formData.log_template && !validateLogTemplate(formData.log_template) && (
                      <p className="text-sm text-red-600 mt-1">Invalid JSON format</p>
                    )}
                    <p className="text-xs text-gray-500 mt-1">
                      This template must match the format your job uses in log entries
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end space-x-3 mt-6 pt-6 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              loading={loading}
            >
              {loading ? 'Creating...' : 'Create Job'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateJobModal;
