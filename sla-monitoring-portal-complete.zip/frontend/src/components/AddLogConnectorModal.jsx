/**
 * Add/Edit Log Connector Modal
 * Modal for creating or editing log server connector configurations
 */

import React, { useState, useEffect } from 'react';
import { FiX, FiSave, FiServer } from 'react-icons/fi';
import Button from './Button';

const LOG_SERVER_TYPES = [
  { id: 'splunk', name: 'Splunk', requiresAuth: true, authType: 'basic' },
  { id: 'elk', name: 'ELK Stack (Elasticsearch)', requiresAuth: true, authType: 'basic_or_key' },
  { id: 'cloudwatch', name: 'AWS CloudWatch', requiresAuth: true, authType: 'aws' },
  { id: 'stackdriver', name: 'Google Cloud Logging', requiresAuth: true, authType: 'service_account' },
  { id: 'datadog_logs', name: 'Datadog Logs', requiresAuth: true, authType: 'api_key' },
  { id: 'azure_monitor', name: 'Azure Monitor', requiresAuth: true, authType: 'service_principal' },
  { id: 'custom', name: 'Custom REST API', requiresAuth: false, authType: 'custom' }
];

const DEFAULT_CONFIGS = {
  splunk: {
    index: 'main',
    search_timeout: 30,
    max_results: 1000
  },
  elk: {
    index: 'logstash-*',
    search_timeout: 30,
    max_results: 1000
  },
  cloudwatch: {
    region: 'us-east-1',
    log_group: '/aws/lambda/my-function'
  },
  stackdriver: {
    project_id: '',
    log_name: 'projects/PROJECT_ID/logs/LOG_NAME'
  },
  datadog_logs: {
    site: 'datadoghq.com',
    max_results: 1000
  },
  azure_monitor: {
    workspace_id: '',
    max_results: 1000
  },
  custom: {
    query_params: {},
    results_path: 'results'
  }
};

const AddLogConnectorModal = ({ connector, onClose, onSuccess }) => {
  const isEditMode = !!connector;
  
  const [formData, setFormData] = useState({
    connector_name: '',
    connector_description: '',
    log_server_type: '',
    api_endpoint_url: '',
    api_credentials: {
      username: '',
      password: '',
      token: '',
      api_key: '',
      access_key_id: '',
      secret_access_key: '',
      service_account_json: '',
      tenant_id: '',
      client_id: '',
      client_secret: ''
    },
    connection_config: {},
    is_active: true
  });

  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    if (connector) {
      // Parse credentials and config if they're JSON strings
      let credentials = {};
      let config = {};
      
      try {
        credentials = typeof connector.api_credentials === 'string' 
          ? JSON.parse(connector.api_credentials) 
          : (connector.api_credentials || {});
      } catch (e) {
        console.error('Error parsing credentials:', e);
      }

      try {
        config = typeof connector.connection_config === 'string'
          ? JSON.parse(connector.connection_config)
          : (connector.connection_config || {});
      } catch (e) {
        console.error('Error parsing config:', e);
      }

      setFormData({
        connector_name: connector.connector_name || '',
        connector_description: connector.connector_description || '',
        log_server_type: connector.log_server_type || '',
        api_endpoint_url: connector.api_endpoint_url || '',
        api_credentials: { ...formData.api_credentials, ...credentials },
        connection_config: config,
        is_active: connector.is_active !== undefined ? connector.is_active : true
      });

      // Show advanced if config has custom values
      if (Object.keys(config).length > 0) {
        setShowAdvanced(true);
      }
    }
  }, [connector]);

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleCredentialChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      api_credentials: {
        ...prev.api_credentials,
        [field]: value
      }
    }));
  };

  const handleConfigChange = (value) => {
    try {
      const parsed = JSON.parse(value);
      setFormData(prev => ({
        ...prev,
        connection_config: parsed
      }));
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.connection_config;
        return newErrors;
      });
    } catch (e) {
      setErrors(prev => ({
        ...prev,
        connection_config: 'Invalid JSON format'
      }));
    }
  };

  const handleLogServerTypeChange = (type) => {
    handleChange('log_server_type', type);
    // Set default config for this type
    if (DEFAULT_CONFIGS[type]) {
      setFormData(prev => ({
        ...prev,
        connection_config: DEFAULT_CONFIGS[type]
      }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.connector_name.trim()) {
      newErrors.connector_name = 'Connector name is required';
    }

    if (!formData.log_server_type) {
      newErrors.log_server_type = 'Log server type is required';
    }

    if (!formData.api_endpoint_url.trim()) {
      newErrors.api_endpoint_url = 'API endpoint URL is required';
    } else {
      // Basic URL validation
      try {
        new URL(formData.api_endpoint_url);
      } catch (e) {
        newErrors.api_endpoint_url = 'Invalid URL format';
      }
    }

    // Validate credentials based on type
    const serverType = LOG_SERVER_TYPES.find(t => t.id === formData.log_server_type);
    if (serverType && serverType.requiresAuth) {
      const creds = formData.api_credentials;
      
      if (serverType.authType === 'basic') {
        if (!creds.username || !creds.password) {
          newErrors.credentials = 'Username and password are required';
        }
      } else if (serverType.authType === 'basic_or_key') {
        if ((!creds.username || !creds.password) && !creds.api_key) {
          newErrors.credentials = 'Either username/password or API key is required';
        }
      } else if (serverType.authType === 'aws') {
        if (!creds.access_key_id || !creds.secret_access_key) {
          newErrors.credentials = 'AWS access key ID and secret access key are required';
        }
      } else if (serverType.authType === 'api_key') {
        if (!creds.api_key) {
          newErrors.credentials = 'API key is required';
        }
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) {
      return;
    }

    setSaving(true);

    try {
      const token = localStorage.getItem('token');
      
      // Prepare payload - only include non-empty credential fields
      const cleanedCredentials = {};
      Object.keys(formData.api_credentials).forEach(key => {
        if (formData.api_credentials[key]) {
          cleanedCredentials[key] = formData.api_credentials[key];
        }
      });

      const payload = {
        connector_name: formData.connector_name.trim(),
        connector_description: formData.connector_description.trim(),
        log_server_type: formData.log_server_type,
        api_endpoint_url: formData.api_endpoint_url.trim(),
        api_credentials: JSON.stringify(cleanedCredentials),
        connection_config: JSON.stringify(formData.connection_config),
        is_active: formData.is_active ? 1 : 0
      };

      const url = isEditMode
        ? `http://localhost:5000/api/v1/log-connectors/${connector.connector_id}`
        : 'http://localhost:5000/api/v1/log-connectors';

      const method = isEditMode ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (response.ok) {
        alert(`✓ Log server connector ${isEditMode ? 'updated' : 'created'} successfully!`);
        onSuccess();
      } else {
        alert(`✗ Failed to ${isEditMode ? 'update' : 'create'} connector: ${data.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error saving connector:', error);
      alert(`✗ Error saving connector: ${error.message}`);
    } finally {
      setSaving(false);
    }
  };

  const selectedServerType = LOG_SERVER_TYPES.find(t => t.id === formData.log_server_type);

  const renderAuthFields = () => {
    if (!selectedServerType || !selectedServerType.requiresAuth) {
      return null;
    }

    const authType = selectedServerType.authType;

    return (
      <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
        <h4 className="font-medium text-gray-900 mb-3">Authentication</h4>
        
        {authType === 'basic' && (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Username <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.api_credentials.username}
                onChange={(e) => handleCredentialChange('username', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="admin"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password <span className="text-red-500">*</span>
              </label>
              <input
                type="password"
                value={formData.api_credentials.password}
                onChange={(e) => handleCredentialChange('password', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="••••••••"
              />
            </div>
          </div>
        )}

        {authType === 'basic_or_key' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  value={formData.api_credentials.username}
                  onChange={(e) => handleCredentialChange('username', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="admin"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={formData.api_credentials.password}
                  onChange={(e) => handleCredentialChange('password', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="••••••••"
                />
              </div>
            </div>
            <div className="text-center text-sm text-gray-500">OR</div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                API Key
              </label>
              <input
                type="password"
                value={formData.api_credentials.api_key}
                onChange={(e) => handleCredentialChange('api_key', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="Enter API key"
              />
            </div>
          </div>
        )}

        {authType === 'aws' && (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Access Key ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.api_credentials.access_key_id}
                onChange={(e) => handleCredentialChange('access_key_id', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="AKIAIOSFODNN7EXAMPLE"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Secret Access Key <span className="text-red-500">*</span>
              </label>
              <input
                type="password"
                value={formData.api_credentials.secret_access_key}
                onChange={(e) => handleCredentialChange('secret_access_key', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="••••••••"
              />
            </div>
          </div>
        )}

        {authType === 'api_key' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              API Key <span className="text-red-500">*</span>
            </label>
            <input
              type="password"
              value={formData.api_credentials.api_key}
              onChange={(e) => handleCredentialChange('api_key', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="Enter API key"
            />
          </div>
        )}

        {authType === 'service_principal' && (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tenant ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.api_credentials.tenant_id}
                onChange={(e) => handleCredentialChange('tenant_id', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Client ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.api_credentials.client_id}
                onChange={(e) => handleCredentialChange('client_id', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Client Secret <span className="text-red-500">*</span>
              </label>
              <input
                type="password"
                value={formData.api_credentials.client_secret}
                onChange={(e) => handleCredentialChange('client_secret', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="••••••••"
              />
            </div>
          </div>
        )}

        {errors.credentials && (
          <p className="text-sm text-red-600 mt-2">{errors.credentials}</p>
        )}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b flex items-center justify-between bg-primary-50">
          <div className="flex items-center gap-3">
            <FiServer className="text-2xl text-primary-600" />
            <h2 className="text-xl font-bold text-gray-900">
              {isEditMode ? 'Edit Log Server Connector' : 'Add Log Server Connector'}
            </h2>
          </div>
          <button 
            onClick={onClose} 
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <FiX className="text-2xl" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="space-y-6">
            {/* Basic Information */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Connector Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.connector_name}
                    onChange={(e) => handleChange('connector_name', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                      errors.connector_name ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    placeholder="e.g., Splunk Production"
                  />
                  {errors.connector_name && (
                    <p className="text-sm text-red-600 mt-1">{errors.connector_name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={formData.connector_description}
                    onChange={(e) => handleChange('connector_description', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    rows={2}
                    placeholder="Optional description of this log server"
                  />
                </div>
              </div>
            </div>

            {/* Log Server Configuration */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Log Server Configuration</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Log Server Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.log_server_type}
                    onChange={(e) => handleLogServerTypeChange(e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                      errors.log_server_type ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                  >
                    <option value="">Select log server type...</option>
                    {LOG_SERVER_TYPES.map(type => (
                      <option key={type.id} value={type.id}>{type.name}</option>
                    ))}
                  </select>
                  {errors.log_server_type && (
                    <p className="text-sm text-red-600 mt-1">{errors.log_server_type}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    API Endpoint URL <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.api_endpoint_url}
                    onChange={(e) => handleChange('api_endpoint_url', e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm ${
                      errors.api_endpoint_url ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    placeholder="e.g., https://splunk.company.com:8089"
                  />
                  {errors.api_endpoint_url && (
                    <p className="text-sm text-red-600 mt-1">{errors.api_endpoint_url}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Full URL including protocol and port
                  </p>
                </div>
              </div>
            </div>

            {/* Authentication */}
            {renderAuthFields()}

            {/* Advanced Configuration */}
            <div>
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="text-sm font-medium text-primary-600 hover:text-primary-700 mb-3"
              >
                {showAdvanced ? '▼' : '▶'} Advanced Configuration (JSON)
              </button>
              
              {showAdvanced && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Connection Configuration
                  </label>
                  <textarea
                    value={JSON.stringify(formData.connection_config, null, 2)}
                    onChange={(e) => handleConfigChange(e.target.value)}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm ${
                      errors.connection_config ? 'border-red-300 bg-red-50' : 'border-gray-300'
                    }`}
                    rows={8}
                    placeholder='{"index": "main", "search_timeout": 30}'
                  />
                  {errors.connection_config && (
                    <p className="text-sm text-red-600 mt-1">{errors.connection_config}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Additional configuration parameters in JSON format
                  </p>
                </div>
              )}
            </div>

            {/* Status */}
            <div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => handleChange('is_active', e.target.checked)}
                  className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                />
                <span className="text-sm font-medium text-gray-700">
                  Active (connector is available for use)
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={saving}
            icon={FiSave}
          >
            {saving ? 'Saving...' : (isEditMode ? 'Update Connector' : 'Create Connector')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddLogConnectorModal;
