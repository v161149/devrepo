/**
 * EnhancedSLADashboard Component
 * 
 * Shows overall SLA compliance across all services and jobs
 * Displays recent breaches, compliance trends, and summary statistics
 * 
 * Location: frontend/src/components/EnhancedSLADashboard.jsx
 */

import React, { useState, useEffect } from 'react';
import { FiCheck, FiX, FiAlertTriangle, FiTrendingUp, FiActivity } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import apiService from '../services/api';
import Card from './Card';
import Button from './Button';

const EnhancedSLADashboard = () => {
  const navigate = useNavigate();
  const [dashboardData, setDashboardData] = useState(null);
  const [recentBreaches, setRecentBreaches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState(30);

  useEffect(() => {
    loadDashboardData();
  }, [timeRange]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      const [dashboardRes, breachesRes] = await Promise.all([
        apiService.slas.getDashboard(timeRange),
        apiService.slas.getRecentBreaches(7, 10)
      ]);
      
      setDashboardData(dashboardRes.data);
      setRecentBreaches(breachesRes.data?.breaches || []);
      
    } catch (err) {
      console.error('Error loading dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const getComplianceColor = (percentage) => {
    if (percentage >= 99) return 'text-green-600';
    if (percentage >= 95) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getComplianceBgColor = (percentage) => {
    if (percentage >= 99) return 'bg-green-100';
    if (percentage >= 95) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <Card>
        <div className="text-center py-8 text-gray-500">
          No SLA data available
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Overall Compliance */}
        <Card>
          <div className="flex items-center">
            <div className={`flex-shrink-0 rounded-full p-3 ${getComplianceBgColor(dashboardData.overall_compliance_percentage)}`}>
              <FiActivity className={`h-6 w-6 ${getComplianceColor(dashboardData.overall_compliance_percentage)}`} />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Overall Compliance</p>
              <p className={`text-2xl font-bold ${getComplianceColor(dashboardData.overall_compliance_percentage)}`}>
                {dashboardData.overall_compliance_percentage}%
              </p>
            </div>
          </div>
        </Card>

        {/* Total SLAs */}
        <Card>
          <div className="flex items-center">
            <div className="flex-shrink-0 rounded-full p-3 bg-blue-100">
              <FiTrendingUp className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Active SLAs</p>
              <p className="text-2xl font-bold text-gray-900">
                {dashboardData.total_slas}
              </p>
            </div>
          </div>
        </Card>

        {/* Passed Checks */}
        <Card>
          <div className="flex items-center">
            <div className="flex-shrink-0 rounded-full p-3 bg-green-100">
              <FiCheck className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Passed Checks</p>
              <p className="text-2xl font-bold text-green-600">
                {dashboardData.total_passed}
              </p>
            </div>
          </div>
        </Card>

        {/* Failed Checks */}
        <Card>
          <div className="flex items-center">
            <div className="flex-shrink-0 rounded-full p-3 bg-red-100">
              <FiX className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Failed Checks</p>
              <p className="text-2xl font-bold text-red-600">
                {dashboardData.total_failed}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Time Range Selector */}
      <div className="flex justify-end">
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(parseInt(e.target.value))}
          className="border-gray-300 rounded-md text-sm"
        >
          <option value={7}>Last 7 days</option>
          <option value={30}>Last 30 days</option>
          <option value={90}>Last 90 days</option>
        </select>
      </div>

      {/* Per-SLA Summary */}
      {dashboardData.sla_summaries && dashboardData.sla_summaries.length > 0 && (
        <Card>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">SLA Performance</h3>
            
            <div className="space-y-2">
              {dashboardData.sla_summaries.map((sla, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-gray-900">{sla.sla_name}</span>
                      <span className={`text-sm font-semibold ${getComplianceColor(sla.compliance_percentage)}`}>
                        {sla.compliance_percentage}%
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>{sla.sla_type}</span>
                      <span>•</span>
                      <span>{sla.total} checks</span>
                      <span>•</span>
                      <span className="text-green-600">{sla.passed} passed</span>
                      <span>•</span>
                      <span className="text-red-600">{sla.failed} failed</span>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-32 ml-4">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          sla.compliance_percentage >= 99
                            ? 'bg-green-500'
                            : sla.compliance_percentage >= 95
                            ? 'bg-yellow-500'
                            : 'bg-red-500'
                        }`}
                        style={{ width: `${Math.min(sla.compliance_percentage, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* Recent Breaches */}
      {recentBreaches.length > 0 && (
        <Card>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Recent SLA Breaches</h3>
              <span className="text-sm text-gray-500">Last 7 days</span>
            </div>
            
            <div className="space-y-2">
              {recentBreaches.map((breach, index) => (
                <div
                  key={index}
                  className="flex items-start p-3 bg-red-50 rounded-lg border border-red-200 cursor-pointer hover:bg-red-100 transition-colors"
                  onClick={() => {
                    if (breach.service_id) {
                      navigate(`/services/${breach.service_id}`);
                    } else if (breach.job_id) {
                      navigate(`/jobs/${breach.job_id}`);
                    }
                  }}
                >
                  <div className="flex-shrink-0">
                    <FiAlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-gray-900">
                        {breach.entity_name} - {breach.sla_name}
                      </p>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        breach.breach_severity === 'critical'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {breach.breach_severity}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">
                      Measured: {breach.measured_value} | Target: {breach.target_value}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(breach.breach_time).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            {recentBreaches.length >= 10 && (
              <div className="text-center">
                <Button
                  variant="secondary"
                  onClick={() => navigate('/alerts')}
                >
                  View All Breaches
                </Button>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
};

export default EnhancedSLADashboard;
