/**
 * AlertList Component
 * Displays a list of alerts with filtering and actions
 */

import React, { useState, useEffect } from 'react';
import { FiAlertCircle, FiCheck } from 'react-icons/fi';
import apiService from '../services/api';
import Button from './Button';

const AlertList = ({ limit, status }) => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadAlerts();
  }, [status]);

  const loadAlerts = async () => {
    try {
      setLoading(true);
      const params = {};
      if (status) params.status = status;
      if (limit) params.limit = limit;

      const response = await apiService.alerts.getAll(params);
      setAlerts(response.data.alerts || []);
    } catch (err) {
      console.error('Error loading alerts:', err);
      setError('Failed to load alerts');
    } finally {
      setLoading(false);
    }
  };

  const handleAcknowledge = async (alertId) => {
    try {
      await apiService.alerts.acknowledge(alertId);
      loadAlerts(); // Reload alerts
    } catch (err) {
      console.error('Error acknowledging alert:', err);
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      critical: 'bg-red-100 text-red-800 border-red-300',
      high: 'bg-orange-100 text-orange-800 border-orange-300',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      low: 'bg-blue-100 text-blue-800 border-blue-300',
    };
    return colors[severity] || colors.medium;
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-600">
        <FiAlertCircle className="text-4xl mx-auto mb-2" />
        <p>{error}</p>
      </div>
    );
  }

  if (alerts.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <FiCheck className="text-4xl mx-auto mb-2 text-green-500" />
        <p>No pending alerts</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {alerts.map((alert) => (
        <div
          key={alert.alert_id}
          className={`p-4 rounded-lg border ${getSeverityColor(alert.severity)}`}
        >
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center mb-1">
                <span className="font-semibold text-sm uppercase mr-2">
                  {alert.severity}
                </span>
                <span className="text-xs text-gray-600">
                  {new Date(alert.created_at).toLocaleString()}
                </span>
              </div>
              <p className="text-sm">{alert.message}</p>
              <p className="text-xs text-gray-600 mt-1">
                Service: {alert.service_id}
              </p>
            </div>
            {alert.status === 'pending' && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleAcknowledge(alert.alert_id)}
                className="ml-2"
              >
                Ack
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default AlertList;
