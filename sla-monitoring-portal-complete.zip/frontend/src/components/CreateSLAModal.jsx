/**
 * CreateSLAModal - Modal for creating new SLAs
 * Similar to Manual Onboarding Step 4 but with Link To field
 */

import React, { useState, useEffect } from 'react';
import { FiX } from 'react-icons/fi';
import Button from './Button';
import apiService from '../services/api';

const CreateSLAModal = ({ isOpen, onClose, onSuccess, preselectedServiceId, preselectedJobId, editingSLA }) => {
  const [formData, setFormData] = useState({
    name: '',
    metric_type: '',
    target_value: '',
    warning_threshold: '',
    critical_threshold: '',
    measurement_period: 'Monthly',
    description: '',
    link_to_type: '', // 'service' or 'job'
    service_id: '',
    job_id: '',
    effective_from: new Date().toISOString().split('T')[0],
    // NEW: Missing fields from Manual Onboarding
    log_field_criteria: '',
    log_field_status: '',
    evaluation_schedule: 'daily'
  });
  const [services, setServices] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadServicesAndJobs();
      
      if (editingSLA) {
        // Populate form with existing SLA data for editing
        const metadata = typeof editingSLA.metadata === 'string' 
          ? JSON.parse(editingSLA.metadata) 
          : editingSLA.metadata || {};
        
        setFormData({
          name: editingSLA.name || '',
          metric_type: editingSLA.metric_type || '',
          target_value: editingSLA.target_value || '',
          warning_threshold: metadata.warning_threshold || '',
          critical_threshold: metadata.critical_threshold || '',
          measurement_period: metadata.measurement_period || 'Monthly',
          description: editingSLA.description || '',
          link_to_type: editingSLA.job_id ? 'job' : editingSLA.service_id ? 'service' : '',
          service_id: editingSLA.service_id || '',
          job_id: editingSLA.job_id || '',
          effective_from: editingSLA.effective_from || new Date().toISOString().split('T')[0],
          log_field_criteria: metadata.log_field_criteria || '',
          log_field_status: metadata.log_field_status || '',
          evaluation_schedule: metadata.evaluation_schedule || 'daily'
        });
      } else {
        // Reset form with preselected values if provided
        setFormData({
          name: '',
          metric_type: '',
          target_value: '',
          warning_threshold: '',
          critical_threshold: '',
          measurement_period: 'Monthly',
          description: '',
          link_to_type: preselectedJobId ? 'job' : preselectedServiceId ? 'service' : '',
          service_id: preselectedServiceId || '',
          job_id: preselectedJobId || '',
          effective_from: new Date().toISOString().split('T')[0],
          log_field_criteria: '',
          log_field_status: '',
          evaluation_schedule: 'daily'
        });
      }
      setError('');
    }
  }, [isOpen, preselectedServiceId, preselectedJobId, editingSLA]);

  const loadServicesAndJobs = async () => {
    try {
      const [servicesRes, jobsRes] = await Promise.all([
        apiService.services.getAll(),
        apiService.jobs.getAll()
      ]);
      setServices(servicesRes.data?.data || []);
      setJobs(jobsRes.data?.data || jobsRes.data || []);
    } catch (err) {
      console.error('Error loading data:', err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      
      // Clear service/job when link type changes
      if (name === 'link_to_type') {
        if (!preselectedServiceId && !preselectedJobId) {
          newData.service_id = '';
          newData.job_id = '';
        }
      }
      
      return newData;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim()) {
      setError('SLA name is required');
      return;
    }
    if (!formData.metric_type) {
      setError('Metric type is required');
      return;
    }
    if (!formData.target_value) {
      setError('Target value is required');
      return;
    }
    if (!formData.link_to_type) {
      setError('Please select what to link this SLA to');
      return;
    }
    if (formData.link_to_type === 'service' && !formData.service_id) {
      setError('Please select a service');
      return;
    }
    if (formData.link_to_type === 'job' && !formData.job_id) {
      setError('Please select a job');
      return;
    }

    // Validate threshold logic
    const target = parseFloat(formData.target_value);
    const warning = parseFloat(formData.warning_threshold);
    const critical = parseFloat(formData.critical_threshold);

    if (warning && warning >= target) {
      setError('Warning threshold must be less than target value');
      return;
    }
    if (critical && critical >= warning) {
      setError('Critical threshold must be less than warning threshold');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Prepare SLA data
      const slaData = {
        name: formData.name,
        metric_type: formData.metric_type,
        target_value: parseFloat(formData.target_value),
        target_unit: '%',
        warning_threshold: formData.warning_threshold ? parseFloat(formData.warning_threshold) : null,
        critical_threshold: formData.critical_threshold ? parseFloat(formData.critical_threshold) : null,
        measurement_period: formData.measurement_period,
        description: formData.description,
        service_id: formData.link_to_type === 'service' ? formData.service_id : null,
        job_id: formData.link_to_type === 'job' ? formData.job_id : null,
        effective_from: formData.effective_from,
        start_condition: 'start',
        stop_condition: 'stop',
        // NEW: Add log field mapping and evaluation schedule
        log_field_criteria: formData.log_field_criteria || null,
        log_field_status: formData.log_field_status || null,
        evaluation_schedule: formData.evaluation_schedule || 'daily'
      };

      // Call UPDATE or CREATE based on whether we're editing
      if (editingSLA && editingSLA.sla_id) {
        await apiService.slas.update(editingSLA.sla_id, slaData);
      } else {
        await apiService.slas.create(slaData);
      }
      
      if (onSuccess) {
        onSuccess();
      }
      onClose();
    } catch (err) {
      console.error('Error creating SLA:', err);
      setError(err.response?.data?.error || editingSLA ? 'Failed to update SLA' : 'Failed to create SLA');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const isPreselected = !!preselectedServiceId || !!preselectedJobId;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {editingSLA ? 'Edit SLA' : 'Create SLA'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <FiX className="text-2xl" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-800">
              {error}
            </div>
          )}

          <div className="space-y-4">
            {/* SLA Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                SLA Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="e.g., 99.9% Uptime SLA"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>

            {/* SLA Type (Metric Type) */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                SLA Type <span className="text-red-500">*</span>
              </label>
              <select
                name="metric_type"
                value={formData.metric_type}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              >
                <option value="">Select type...</option>
                <option value="uptime">Uptime</option>
                <option value="availability">Availability</option>
                <option value="response_time">Response Time</option>
                <option value="success_rate">Success Rate</option>
                <option value="data_accuracy">Data Accuracy</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            {/* Link To - NEW FIELD */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Apply To (Link To) <span className="text-red-500">*</span>
              </label>
              <select
                name="link_to_type"
                value={formData.link_to_type}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
                disabled={isPreselected}
              >
                <option value="">Select what to link to...</option>
                <option value="service">Service</option>
                <option value="job">Job</option>
              </select>
              {isPreselected && (
                <p className="mt-1 text-sm text-gray-500">
                  {preselectedServiceId ? 'Pre-selected for this service' : 'Pre-selected for this job'}
                </p>
              )}
            </div>

            {/* Service Selection (shown when link_to_type is 'service') */}
            {formData.link_to_type === 'service' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Service <span className="text-red-500">*</span>
                </label>
                <select
                  name="service_id"
                  value={formData.service_id}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                  disabled={!!preselectedServiceId}
                >
                  <option value="">Select service...</option>
                  {services.map(service => (
                    <option key={service.service_id} value={service.service_id}>
                      {service.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Job Selection (shown when link_to_type is 'job') */}
            {formData.link_to_type === 'job' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Job <span className="text-red-500">*</span>
                </label>
                <select
                  name="job_id"
                  value={formData.job_id}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                  disabled={!!preselectedJobId}
                >
                  <option value="">Select job...</option>
                  {jobs.map(job => (
                    <option key={job.job_id} value={job.job_id}>
                      {job.job_name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Target Value */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Target Value (%) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                step="0.01"
                name="target_value"
                value={formData.target_value}
                onChange={handleChange}
                placeholder="e.g., 99.9"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Warning Threshold */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Warning Threshold (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  name="warning_threshold"
                  value={formData.warning_threshold}
                  onChange={handleChange}
                  placeholder="e.g., 95"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>

              {/* Critical Threshold */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Critical Threshold (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  name="critical_threshold"
                  value={formData.critical_threshold}
                  onChange={handleChange}
                  placeholder="e.g., 90"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
            </div>

            {/* Note about thresholds */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> Warning threshold should be higher than critical threshold.
                Example: Target 99.9%, Warning 95%, Critical 90%
              </p>
            </div>

            {/* NEW: First Mapping Configuration */}
            <div className="border-t border-gray-200 pt-4 mt-4">
              <h3 className="text-md font-semibold text-gray-900 mb-3">
                First Mapping Configuration
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Map SLA checks to log entry fields. These placeholders will be replaced with actual values from your log entries.
              </p>
              
              <div className="space-y-4">
                {/* Log Field Criteria */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Criteria
                  </label>
                  <input
                    type="text"
                    name="log_field_criteria"
                    value={formData.log_field_criteria}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                    placeholder="{{log}}"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Example values: running, active, healthy, ok
                  </p>
                </div>

                {/* Log Field Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <input
                    type="text"
                    name="log_field_status"
                    value={formData.log_field_status}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 font-mono text-sm"
                    placeholder="{{status}}"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Example values: running, stopped
                  </p>
                </div>
              </div>
            </div>

            {/* NEW: Schedule for SLA Checks */}
            <div className="border-t border-gray-200 pt-4 mt-4">
              <h3 className="text-md font-semibold text-gray-900 mb-3">
                Schedule for SLA Checks
              </h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Evaluation Schedule <span className="text-red-500">*</span>
                </label>
                <select
                  name="evaluation_schedule"
                  value={formData.evaluation_schedule}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  required
                >
                  <option value="hourly">Hourly</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  How often should this SLA be evaluated?
                </p>
              </div>
            </div>

            {/* Measurement Period */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Measurement Period
              </label>
              <select
                name="measurement_period"
                value={formData.measurement_period}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="Monthly">Monthly</option>
                <option value="Weekly">Weekly</option>
                <option value="Daily">Daily</option>
                <option value="Quarterly">Quarterly</option>
              </select>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Describe the purpose and scope of this SLA..."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>

            {/* Effective From */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Effective From
              </label>
              <input
                type="date"
                name="effective_from"
                value={formData.effective_from}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          </div>

          {/* Footer */}
          <div className="mt-6 flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
            >
              {loading ? 'Creating...' : 'Save SLA'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateSLAModal;
