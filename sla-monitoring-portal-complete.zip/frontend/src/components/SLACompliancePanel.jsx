/**
 * SLACompliancePanel Component
 * 
 * Displays detailed compliance information for a service or job
 * Shows per-SLA compliance status, history, and breach details
 * 
 * Location: frontend/src/components/SLACompliancePanel.jsx
 */

import React, { useState, useEffect } from 'react';
import { FiCheck, FiX, FiAlertTriangle, FiClock, FiTrendingUp, FiTrendingDown } from 'react-icons/fi';
import apiService from '../services/api';
import Card from './Card';
import Button from './Button';

const SLACompliancePanel = ({ serviceId, jobId, refreshTrigger }) => {
  const [slaStatuses, setSlaStatuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedSLA, setSelectedSLA] = useState(null);
  const [complianceHistory, setComplianceHistory] = useState([]);
  const [timeRange, setTimeRange] = useState(7); // days

  useEffect(() => {
    loadSLAStatuses();
  }, [serviceId, jobId, refreshTrigger]);

  useEffect(() => {
    if (selectedSLA) {
      loadComplianceHistory(selectedSLA.sla_id);
    }
  }, [selectedSLA, timeRange]);

  const loadSLAStatuses = async () => {
    try {
      setLoading(true);
      setError('');
      
      let response;
      if (serviceId) {
        response = await apiService.slas.getServiceSLAStatus(serviceId);
      } else if (jobId) {
        response = await apiService.slas.getJobSLAStatus(jobId);
      }
      
      const statuses = response.data?.sla_statuses || [];
      setSlaStatuses(statuses);
      
      // Auto-select first SLA if none selected
      if (statuses.length > 0 && !selectedSLA) {
        setSelectedSLA(statuses[0]);
      }
      
    } catch (err) {
      console.error('Error loading SLA statuses:', err);
      setError('Failed to load SLA compliance data');
    } finally {
      setLoading(false);
    }
  };

  const loadComplianceHistory = async (slaId) => {
    try {
      let response;
      if (serviceId) {
        response = await apiService.slas.getServiceCompliance(serviceId, {
          sla_id: slaId,
          limit: 100
        });
      } else if (jobId) {
        response = await apiService.slas.getJobCompliance(jobId, {
          sla_id: slaId,
          limit: 100
        });
      }
      
      const records = response.data?.compliance_records || [];
      
      // Filter by time range
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - timeRange);
      
      const filtered = records.filter(record => {
        const recordDate = new Date(record.evaluated_at);
        return recordDate >= cutoffDate;
      });
      
      setComplianceHistory(filtered);
      
    } catch (err) {
      console.error('Error loading compliance history:', err);
    }
  };

  const getCompliancePercentage = (sla) => {
    if (!sla.total_checks || sla.total_checks === 0) return 0;
    return ((sla.passed_checks / sla.total_checks) * 100).toFixed(1);
  };

  const getStatusBadge = (sla) => {
    const percentage = parseFloat(getCompliancePercentage(sla));
    const target = sla.target_value || 99;
    
    if (percentage >= target) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
          <FiCheck className="mr-1" />
          Meeting SLA
        </span>
      );
    } else if (percentage >= target * 0.95) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
          <FiAlertTriangle className="mr-1" />
          At Risk
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
          <FiX className="mr-1" />
          Breaching
        </span>
      );
    }
  };

  const getTrendIcon = (sla) => {
    if (!sla.recent_trend) return null;
    
    if (sla.recent_trend === 'improving') {
      return <FiTrendingUp className="text-green-500" />;
    } else if (sla.recent_trend === 'declining') {
      return <FiTrendingDown className="text-red-500" />;
    }
    return null;
  };

  if (loading) {
    return (
      <Card>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <div className="text-red-600">{error}</div>
      </Card>
    );
  }

  if (slaStatuses.length === 0) {
    return (
      <Card>
        <div className="text-center py-8 text-gray-500">
          No SLAs configured for this {serviceId ? 'service' : 'job'}
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* SLA Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {slaStatuses.map((sla) => (
          <Card
            key={sla.sla_id}
            className={`cursor-pointer transition-all ${
              selectedSLA?.sla_id === sla.sla_id
                ? 'ring-2 ring-blue-500 shadow-lg'
                : 'hover:shadow-md'
            }`}
            onClick={() => setSelectedSLA(sla)}
          >
            <div className="space-y-3">
              {/* SLA Name and Status */}
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{sla.sla_name}</h3>
                  <p className="text-sm text-gray-500">{sla.sla_type}</p>
                </div>
                {getTrendIcon(sla)}
              </div>
              
              {/* Compliance Percentage */}
              <div>
                <div className="flex items-baseline justify-between mb-1">
                  <span className="text-2xl font-bold text-gray-900">
                    {getCompliancePercentage(sla)}%
                  </span>
                  <span className="text-sm text-gray-500">
                    Target: {sla.target_value}%
                  </span>
                </div>
                
                {/* Progress Bar */}
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      getCompliancePercentage(sla) >= sla.target_value
                        ? 'bg-green-500'
                        : getCompliancePercentage(sla) >= sla.target_value * 0.95
                        ? 'bg-yellow-500'
                        : 'bg-red-500'
                    }`}
                    style={{ width: `${Math.min(getCompliancePercentage(sla), 100)}%` }}
                  />
                </div>
              </div>
              
              {/* Status Badge */}
              <div className="flex items-center justify-between">
                {getStatusBadge(sla)}
                <span className="text-xs text-gray-500">
                  {sla.total_checks} checks
                </span>
              </div>
              
              {/* Last Check */}
              {sla.last_check_time && (
                <div className="flex items-center text-xs text-gray-500">
                  <FiClock className="mr-1" />
                  {new Date(sla.last_check_time).toLocaleString()}
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Detailed Compliance History */}
      {selectedSLA && (
        <Card>
          <div className="space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">
                Compliance History: {selectedSLA.sla_name}
              </h3>
              <div className="flex items-center space-x-2">
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(parseInt(e.target.value))}
                  className="text-sm border-gray-300 rounded-md"
                >
                  <option value={1}>Last 24 hours</option>
                  <option value={7}>Last 7 days</option>
                  <option value={30}>Last 30 days</option>
                  <option value={90}>Last 90 days</option>
                </select>
              </div>
            </div>
            
            {/* Compliance Records Table */}
            {complianceHistory.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Time
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Measured
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Target
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Severity
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {complianceHistory.map((record, index) => (
                      <tr key={index} className={record.met_sla ? '' : 'bg-red-50'}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {new Date(record.evaluated_at).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {record.met_sla ? (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <FiCheck className="mr-1" /> Met
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              <FiX className="mr-1" /> Breached
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {record.measured_value.toFixed(2)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {record.target_value}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {record.breach_severity !== 'none' && (
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                              record.breach_severity === 'critical'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {record.breach_severity}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No compliance records found for the selected time range
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
};

export default SLACompliancePanel;
