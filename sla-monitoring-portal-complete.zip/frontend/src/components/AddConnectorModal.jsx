/**
 * AddConnectorModal.jsx - WITH FIELD MAPPING
 * Features:
 * - Demo simulator platforms (Autosys, Ansible, Asset)
 * - Test connection functionality
 * - Data preview with JSON view
 * - Field mapping configuration ⭐ NEW!
 * - Auto-mapping suggestions
 * - Mapped data preview
 * - Export functionality
 */

import React, { useState, useEffect } from 'react';
import { 
  FiX, 
  FiDatabase, 
  FiCloud, 
  FiServer, 
  FiGlobe,
  FiCheckCircle,
  FiXCircle,
  FiLoader,
  FiDownload,
  FiCopy,
  FiZap,
  FiAlertCircle
} from 'react-icons/fi';
import Button from './Button';

const AddConnectorModal = ({ connector, onClose, onSuccess }) => {
  const isEditMode = !!connector;
  const [step, setStep] = useState(1); // 1: Type, 2: Platform, 3: Config, 4: Preview, 5: Mapping
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [testStatus, setTestStatus] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [previewData, setPreviewData] = useState(null);
  const [fieldMappings, setFieldMappings] = useState({});
  const [availableFields, setAvailableFields] = useState([]);
  
  // State for date fields (onboarded_date defaults to today in MM/DD/YYYY format)
  const getTodayFormatted = () => {
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const year = today.getFullYear();
    return `${month}/${day}/${year}`;
  };
  const [onboardedDate, setOnboardedDate] = useState(getTodayFormatted());
  
  // State for status field (defaults to 'Active')
  const [assetStatus, setAssetStatus] = useState('Active');
  
  const [formData, setFormData] = useState({
    connector_name: '',
    connector_type: 'asset',
    platform: '',
    api_endpoint_url: '',
    api_key: '',
    is_demo: false
  });

  // Initialize form data from connector if editing
  useEffect(() => {
    if (connector) {
      // Edit mode - populate form with existing data
      
      // Map service_job to actual type based on platform
      let actualConnectorType = connector.connector_type;
      if (actualConnectorType === 'service_job') {
        const platform = connector.platform || '';
        if (platform.includes('job') || platform === 'autosys') {
          actualConnectorType = 'job';
        } else {
          actualConnectorType = 'service';
        }
      }
      
      setFormData({
        connector_name: connector.connector_name || '',
        connector_type: actualConnectorType,
        platform: connector.platform || '',
        api_endpoint_url: connector.api_endpoint_url || '',
        api_key: connector.api_key || '',
        is_demo: connector.platform?.includes('demo') || false
      });
      
      // Start at configuration step in edit mode
      setStep(3);
      
      // Load existing field mappings if available
      const connectorId = connector?.connector_id || connector?.id;
      if (connectorId) {
        loadFieldMappings(connectorId);
      }
    }
  }, [connector]);

  // Function to load existing field mappings
  const loadFieldMappings = async (connectorId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}/field-mappings`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      if (response.ok) {
        const data = await response.json();
        const mappings = {};
        
        data.mappings?.forEach(m => {
          mappings[m.target_field] = m.source_field;
          
          // For constant fields, also update the state variables
          if (m.target_field === 'onboarded_date' && m.source_field) {
            setOnboardedDate(m.source_field);
          }
          if (m.target_field === 'status' && m.source_field) {
            setAssetStatus(m.source_field);
          }
        });
        
        setFieldMappings(mappings);
        console.log('Loaded existing mappings:', mappings);
      }
    } catch (error) {
      console.error('Error loading field mappings:', error);
    }
  };

  // Required fields for each connector type
  const requiredFieldsByType = {
      asset: [
        { name: 'asset_id', label: 'Asset ID', required: true, description: 'Unique identifier for the asset (optional - system will generate if not provided)' },
        { name: 'asset_name', label: 'Asset Name', required: true, description: 'Unique name for the asset' },
        { name: 'asset_type', label: 'Asset Type', required: true, description: 'Type/category of the asset' },
        { name: 'asset_owner', label: 'Asset Owner', required: true, description: 'Team or person responsible for the asset' },
        { name: 'onboarded_date', label: 'Onboarded Date', required: false, type: 'date', description: 'Date when asset was onboarded (MM/DD/YYYY)' },
        { name: 'status', label: 'Status', required: false, type: 'select', options: ['Active', 'Inactive', 'Decommissioned'], description: 'Current status of the asset' },
        { name: 'description', label: 'Description', required: false, description: 'Additional details about the asset' }
      ],
      service: [
        { name: 'service_id', label: 'Service ID', required: true, description: 'Unique identifier for the service (optional - system will generate if not provided)' },
        { name: 'service_name', label: 'Service Name', required: true, description: 'Name of the service' },
        { name: 'service_type', label: 'Service Type', required: true, description: 'Type/category of service' },
        { name: 'asset_id', label: 'Asset ID', required: true, description: 'ID of the asset this service belongs to' },
        { name: 'description', label: 'Description', required: false, description: 'Service description' },
        { name: 'status', label: 'Status', required: false, description: 'Service status' },
        { name: 'service_identifier', label: 'Service Identifier', required: false, description: 'Unique identifier for log entries (e.g., WEB-SRV-001)' },
        { name: 'log_server_type', label: 'Log Server Type', required: false, description: 'Type of log server (splunk, elk, cloudwatch, etc.)' },
        { name: 'log_template', label: 'Log Template', required: false, type: 'json', description: 'JSON template for log entry structure' }
      ],
      job: [
        { name: 'job_id', label: 'Job ID', required: true, description: 'Unique identifier for the job (optional - system will generate if not provided)' },
        { name: 'job_name', label: 'Job Name', required: true, description: 'Name of the job' },
        { name: 'job_type', label: 'Job Type', required: true, description: 'Type/category of job' },
        { name: 'asset_id', label: 'Asset ID', required: false, description: 'Asset ID (if job belongs to asset)' },
        { name: 'service_id', label: 'Service ID', required: false, description: 'Service ID (if job belongs to service)' },
        { name: 'schedule', label: 'Schedule', required: false, description: 'Cron schedule or frequency' },
        { name: 'description', label: 'Description', required: false, description: 'Job description' },
        { name: 'job_identifier', label: 'Job Identifier', required: false, description: 'Unique identifier for log entries (e.g., ETL-DAILY-001)' },
        { name: 'log_server_type', label: 'Log Server Type', required: false, description: 'Type of log server (splunk, elk, cloudwatch, etc.)' },
        { name: 'log_template', label: 'Log Template', required: false, type: 'json', description: 'JSON template for log entry structure' }
      ],
      sla: [
        { name: 'sla_name', label: 'SLA Name', required: true, description: 'Name of the SLA' },
        { name: 'sla_type', label: 'SLA Type', required: true, description: 'Type of SLA (Uptime/Availability, Response Time, Success Rate)' },
        { name: 'service_id', label: 'Service ID', required: false, description: 'Service ID (if SLA for service)' },
        { name: 'job_id', label: 'Job ID', required: false, description: 'Job ID (if SLA for job)' },
        { name: 'target_value_percentage', label: 'Target Value (%)', required: true, description: 'Target percentage (e.g., 99.9)' },
        { name: 'warning_threshold_percentage', label: 'Warning Threshold (%)', required: false, description: 'Warning threshold percentage (e.g., 99.5)' },
        { name: 'critical_threshold_percentage', label: 'Critical Threshold (%)', required: false, description: 'Critical threshold percentage (e.g., 99.0)' },
        { name: 'measurement_period', label: 'Measurement Period', required: false, description: 'Measurement period (Monthly, Weekly, Daily)' }
      ]
    };

  // Connector Type Options
  const connectorTypeOptions = [
    { 
      value: 'asset', 
      name: 'Asset Connector',
      icon: FiServer,
      description: 'Import infrastructure assets',
      color: 'blue'
    },
    { 
      value: 'service', 
      name: 'Service Connector',
      icon: FiDatabase,
      description: 'Import services from external systems',
      color: 'green'
    },
    { 
      value: 'job', 
      name: 'Job Connector',
      icon: FiZap,
      description: 'Import scheduled jobs and batch processes',
      color: 'orange'
    },
    { 
      value: 'sla', 
      name: 'SLA Connector',
      icon: FiCloud,
      description: 'Import SLA definitions',
      color: 'purple'
    }
  ];

// Platform Options (filtered by connector type)
  const allPlatformOptions = {
    asset: [
      {
        value: 'custom',
        name: 'Custom API',
        icon: FiGlobe,
        description: 'Connect to custom REST API',
        color: 'purple',
        isDemo: false,
        fields: [
          { name: 'api_url', label: 'API URL', type: 'url', required: true, placeholder: 'https://api.company.com/assets' },
          { name: 'auth_type', label: 'Auth Type', type: 'select', required: true, options: ['Bearer Token', 'Basic Auth', 'API Key'] },
          { name: 'auth_value', label: 'Token/Key', type: 'password', required: true }
        ]
      },
      {
        value: 'demo_asset',
        name: 'Demo Asset Simulator',
        icon: FiServer,
        description: 'Test with sample asset data',
        subtitle: 'No auth needed',
        color: 'blue',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5003',
        healthEndpoint: '/api/health',
        dataEndpoint: '/api/assets',
        fields: []
      }
    ],
    service: [
      {
        value: 'autosys',
        name: 'Autosys',
        icon: FiServer,
        description: 'Import services from Autosys',
        color: 'blue',
        isDemo: false,
        fields: [
          { name: 'host', label: 'Host', type: 'text', required: true, placeholder: 'autosys.company.com' },
          { name: 'port', label: 'Port', type: 'number', required: true, placeholder: '9443' },
          { name: 'username', label: 'Username', type: 'text', required: true },
          { name: 'password', label: 'Password', type: 'password', required: true }
        ]
      },
      {
        value: 'ansible_tower',
        name: 'Ansible Tower',
        icon: FiCloud,
        description: 'Import services from Ansible Tower/AWX',
        color: 'teal',
        isDemo: false,
        fields: [
          { name: 'tower_url', label: 'Tower URL', type: 'text', required: true, placeholder: 'https://tower.company.com' },
          { name: 'token', label: 'API Token', type: 'password', required: true }
        ]
      },
      {
        value: 'custom',
        name: 'Custom API',
        icon: FiGlobe,
        description: 'Connect to custom REST API',
        color: 'purple',
        isDemo: false,
        fields: [
          { name: 'api_url', label: 'API URL', type: 'url', required: true, placeholder: 'https://api.company.com/services' },
          { name: 'auth_type', label: 'Auth Type', type: 'select', required: true, options: ['Bearer Token', 'Basic Auth', 'API Key'] },
          { name: 'auth_value', label: 'Token/Key', type: 'password', required: true }
        ]
      },
      {
        value: 'demo_autosys',
        name: 'Demo Autosys Simulator',
        icon: FiServer,
        description: 'Test with sample Autosys services',
        subtitle: 'No auth needed',
        color: 'blue',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5001',
        healthEndpoint: '/api/v1/health',
        dataEndpoint: '/api/v1/services',
        fields: []
      },
      {
        value: 'demo_ansible',
        name: 'Demo Ansible Tower Simulator',
        icon: FiCloud,
        description: 'Test with sample Ansible services',
        subtitle: 'No auth needed',
        color: 'teal',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5002',
        healthEndpoint: '/api/v2/ping/',
        dataEndpoint: '/api/v2/services/',
        fields: []
      },
      {
        value: 'demo_service',
        name: 'Demo Service Simulator',
        icon: FiDatabase,
        description: 'Test with sample service data',
        subtitle: 'No auth needed',
        color: 'green',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5004',
        healthEndpoint: '/api/health',
        dataEndpoint: '/api/services',
        fields: []
      }
    ],
    job: [
      {
        value: 'autosys',
        name: 'Autosys',
        icon: FiServer,
        description: 'Import jobs from Autosys scheduler',
        color: 'blue',
        isDemo: false,
        fields: [
          { name: 'host', label: 'Host', type: 'text', required: true, placeholder: 'autosys.company.com' },
          { name: 'port', label: 'Port', type: 'number', required: true, placeholder: '9443' },
          { name: 'username', label: 'Username', type: 'text', required: true },
          { name: 'password', label: 'Password', type: 'password', required: true }
        ]
      },
      {
        value: 'ansible_tower',
        name: 'Ansible Tower',
        icon: FiCloud,
        description: 'Import job templates from Ansible Tower',
        color: 'teal',
        isDemo: false,
        fields: [
          { name: 'tower_url', label: 'Tower URL', type: 'text', required: true, placeholder: 'https://tower.company.com' },
          { name: 'token', label: 'API Token', type: 'password', required: true }
        ]
      },
      {
        value: 'custom',
        name: 'Custom API',
        icon: FiGlobe,
        description: 'Connect to custom REST API',
        color: 'purple',
        isDemo: false,
        fields: [
          { name: 'api_url', label: 'API URL', type: 'url', required: true, placeholder: 'https://api.company.com/jobs' },
          { name: 'auth_type', label: 'Auth Type', type: 'select', required: true, options: ['Bearer Token', 'Basic Auth', 'API Key'] },
          { name: 'auth_value', label: 'Token/Key', type: 'password', required: true }
        ]
      },
      {
        value: 'demo_autosys',
        name: 'Demo Autosys Simulator',
        icon: FiServer,
        description: 'Test with sample Autosys jobs',
        subtitle: 'No auth needed',
        color: 'blue',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5001',
        healthEndpoint: '/api/v1/health',
        dataEndpoint: '/api/v1/jobs',
        fields: []
      },
      {
        value: 'demo_ansible',
        name: 'Demo Ansible Tower Simulator',
        icon: FiCloud,
        description: 'Test with sample Ansible job templates',
        subtitle: 'No auth needed',
        color: 'teal',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5002',
        healthEndpoint: '/api/v2/ping/',
        dataEndpoint: '/api/v2/job_templates/',
        fields: []
      },
      {
        value: 'demo_job',
        name: 'Demo Job Simulator',
        icon: FiZap,
        description: 'Test with sample job data',
        subtitle: 'No auth needed',
        color: 'orange',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5005',
        healthEndpoint: '/api/health',
        dataEndpoint: '/api/jobs',
        fields: []
      }
    ],
    sla: [
      {
        value: 'custom',
        name: 'Custom API',
        icon: FiGlobe,
        description: 'Connect to custom REST API',
        color: 'purple',
        isDemo: false,
        fields: [
          { name: 'api_url', label: 'API URL', type: 'url', required: true, placeholder: 'https://api.company.com/slas' },
          { name: 'auth_type', label: 'Auth Type', type: 'select', required: true, options: ['Bearer Token', 'Basic Auth', 'API Key'] },
          { name: 'auth_value', label: 'Token/Key', type: 'password', required: true }
        ]
      },
      {
        value: 'demo_sla',
        name: 'Demo SLA Simulator',
        icon: FiCloud,
        description: 'Test with sample SLA data',
        subtitle: 'No auth needed',
        color: 'purple',
        isDemo: true,
        defaultEndpoint: 'http://localhost:5006',
        healthEndpoint: '/api/health',
        dataEndpoint: '/api/slas',
        fields: []
      }
    ]
  };

  const platformOptions = allPlatformOptions[formData.connector_type] || [];

  const buildApiEndpointUrl = (platform, configFields) => {
    const platformConfig = platformOptions.find(p => p.value === platform);
    if (platformConfig?.defaultEndpoint) {
      return platformConfig.defaultEndpoint;
    }
    return configFields.api_url || configFields.tower_url || '';
  };

  const buildApiKey = (platform, fields) => {
    const platformConfig = platformOptions.find(p => p.value === platform);
    if (platformConfig?.isDemo) {
      return '';
    }

    if (platform === 'autosys') {
      return JSON.stringify({
        username: fields.username,
        password: fields.password
      });
    } else if (platform === 'ansible_tower') {
      return fields.token;
    } else if (platform === 'custom' || platform === 'demo_asset') {
      return JSON.stringify({
        auth_type: fields.auth_type,
        auth_value: fields.auth_value
      });
    }
    return '';
  };

  const testConnection = async () => {
    setTestStatus('testing');
    setTestResult(null);
    setError('');

    try {
      const platformConfig = platformOptions.find(p => p.value === formData.platform);
      const endpoint = formData.api_endpoint_url + (platformConfig?.healthEndpoint || '');

      console.log('Testing connection to:', endpoint);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(endpoint, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
        signal: controller.signal,
        mode: 'cors'
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid response format');
      }

      setTestStatus('success');
      setTestResult({
        status: data.status || data.health || 'healthy',
        platform: data.platform || data.service || 'Unknown',
        version: data.version || 'N/A',
        responseTime: '45ms'
      });

    } catch (err) {
      console.error('Connection test failed:', err);
      
      let errorMessage = err.message;
      
      if (err.name === 'AbortError') {
        errorMessage = 'Connection timeout - simulator not responding';
      } else if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError') || err.message.includes('network')) {
        errorMessage = 'Failed to connect - simulator may not be running';
      } else if (err.message.includes('ECONNREFUSED')) {
        errorMessage = 'Connection refused - simulator is not running';
      }
      
      setTestStatus('failed');
      setTestResult({
        error: errorMessage
      });
    }
  };

  const fetchPreviewData = async () => {
    setLoading(true);
    setError('');

    try {
      const platformConfig = platformOptions.find(p => p.value === formData.platform);
      const endpoint = formData.api_endpoint_url + (platformConfig?.dataEndpoint || '');

      console.log('Fetching preview data from:', endpoint);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(endpoint, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
        signal: controller.signal,
        mode: 'cors'
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch data`);
      }

      const data = await response.json();
      
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid response format');
      }

      setPreviewData(data);
      
      // Extract available fields from response
      extractAvailableFields(data);
      
      setStep(4);

    } catch (err) {
      console.error('Error fetching preview:', err);
      
      let errorMessage = err.message;
      
      if (err.name === 'AbortError') {
        errorMessage = 'Request timeout - simulator not responding';
      } else if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError') || err.message.includes('network')) {
        errorMessage = 'Failed to fetch data - simulator may not be running';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Extract available fields from preview data
  const extractAvailableFields = (data) => {
    const fields = new Set();
    
    // Handle different response structures
    let records = [];
    if (data.assets) records = data.assets;
    else if (data.services) records = data.services;
    else if (data.jobs) records = data.jobs;
    else if (data.results) records = data.results;
    else if (data.slas) records = data.slas;
    else if (Array.isArray(data)) records = data;
    
    // Extract all keys from first few records
    records.slice(0, 5).forEach(record => {
      Object.keys(record).forEach(key => fields.add(key));
    });
    
    setAvailableFields(Array.from(fields).sort());
  };

  // Auto-mapping suggestions based on field name similarity
  const autoMapFields = () => {
    const requiredFields = requiredFieldsByType[formData.connector_type];
    // Only auto-map mandatory fields
    const mandatoryFieldsToMap = requiredFields.filter(f => f.required === true);
    const newMappings = {};
    
    mandatoryFieldsToMap.forEach(field => {
      const fieldName = field.name;
      const fieldLabel = field.label.toLowerCase();
      
      // Try exact match first
      let matchedField = availableFields.find(f => f.toLowerCase() === fieldName);
      
      // Try partial match
      if (!matchedField) {
        matchedField = availableFields.find(f => {
          const lower = f.toLowerCase();
          return lower.includes(fieldName.split('_')[0]) || 
                 fieldLabel.split(' ').some(word => lower.includes(word));
        });
      }
      
      // Common mappings
      if (!matchedField) {
        const commonMappings = {
          'asset_id': ['asset_id', 'id', 'asset_identifier', 'assetid'],
          'asset_name': ['host_name', 'hostname', 'name', 'asset_name', 'server_name'],
          'asset_type': ['machine_type', 'type', 'asset_type', 'category'],
          'asset_owner': ['responsible_team', 'owner', 'team', 'owner_email'],
          'service_id': ['service_id', 'id', 'service_identifier', 'serviceid'],
          'service_name': ['name', 'service_name', 'template_name'],
          'service_type': ['type', 'service_type', 'kind'],
          'job_id': ['job_id', 'id', 'job_identifier', 'jobid'],
          'job_name': ['name', 'job_name', 'task_name'],
          'job_type': ['type', 'job_type', 'task_type'],
          'owner': ['owner', 'responsible_team', 'team', 'owner_email'],
          'description': ['description', 'desc', 'summary', 'comment'],
          'status': ['status', 'state', 'health'],
          'sla_name': ['name', 'sla_name', 'title'],
          'sla_type': ['sla_type', 'type', 'metric_type', 'category'],
          'target_value_percentage': ['target_value_percentage', 'target_value', 'target', 'percentage'],
          'warning_threshold_percentage': ['warning_threshold_percentage', 'warning_threshold', 'warning'],
          'critical_threshold_percentage': ['critical_threshold_percentage', 'critical_threshold', 'critical'],
          'measurement_period': ['measurement_period', 'period', 'frequency', 'interval'],
          'service_identifier': ['service_identifier', 'service_id', 'identifier'],
          'job_identifier': ['job_identifier', 'job_id', 'identifier'],
          'log_server_type': ['log_server_type', 'log_type', 'server_type'],
          'log_template': ['log_template', 'template', 'log_format']
        };
        
        const possibleFields = commonMappings[fieldName] || [];
        matchedField = availableFields.find(f => 
          possibleFields.some(p => f.toLowerCase().includes(p))
        );
      }
      
      if (matchedField) {
        newMappings[fieldName] = matchedField;
      }
    });
    
    setFieldMappings(newMappings);
  };

  // Preview mapped data
  const previewMappedData = () => {
    if (!previewData) return [];
    
    let records = [];
    if (previewData.assets) records = previewData.assets;
    else if (previewData.services) records = previewData.services;
    else if (previewData.jobs) records = previewData.jobs;
    else if (previewData.results) records = previewData.results;
    else if (previewData.slas) records = previewData.slas;
    else if (Array.isArray(previewData)) records = previewData;
    
    return records.slice(0, 5).map(record => {
      const mapped = {};
      Object.entries(fieldMappings).forEach(([targetField, sourceField]) => {
        // For onboarded_date and status, use user-selected values instead of source data
        if (targetField === 'onboarded_date' && formData.connector_type === 'asset') {
          mapped[targetField] = onboardedDate;
        } else if (targetField === 'status' && formData.connector_type === 'asset') {
          mapped[targetField] = assetStatus;
        } else {
          // For all other fields, map from source data
          mapped[targetField] = record[sourceField] || 'N/A';
        }
      });
      return mapped;
    });
  };

  // Validate that all required fields are mapped
  const validateMappings = () => {
    const requiredFields = requiredFieldsByType[formData.connector_type];
    const unmappedRequired = requiredFields
      .filter(f => f.required && !fieldMappings[f.name])
      .map(f => f.label);
    
    return unmappedRequired;
  };

  const downloadJSON = () => {
    const dataStr = JSON.stringify(previewData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${formData.connector_name.replace(/\s+/g, '_')}_sample_data.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportCSV = () => {
    const rows = [];
    
    if (formData.platform.includes('autosys')) {
      const jobs = previewData?.jobs || [];
      rows.push(['Job Name', 'Type', 'Machine', 'Owner', 'Status', 'Schedule'].join(','));
      jobs.forEach(j => {
        rows.push([
          j.name,
          j.job_type,
          j.machine,
          j.owner,
          j.status,
          j.start_times?.join(';') || ''
        ].join(','));
      });
    } else if (formData.platform.includes('ansible')) {
      const templates = previewData?.results || [];
      rows.push(['Template Name', 'Project', 'Playbook', 'Inventory', 'Enabled'].join(','));
      templates.forEach(t => {
        rows.push([
          t.name,
          t.project_name,
          t.playbook,
          t.inventory,
          t.enabled
        ].join(','));
      });
    } else if (formData.platform.includes('asset')) {
      const assets = previewData?.assets || [];
      rows.push(['Asset ID', 'Host Name', 'Type', 'Team', 'Datacenter', 'Environment', 'Status'].join(','));
      assets.forEach(a => {
        rows.push([
          a.asset_id,
          a.host_name,
          a.machine_type,
          a.responsible_team,
          a.datacenter,
          a.environment,
          a.status
        ].join(','));
      });
    } else if (formData.platform === 'demo_service') {
      const services = previewData?.services || [];
      rows.push(['Service ID', 'Service Name', 'Asset ID', 'Asset Name', 'Service Type', 'Description', 'Status'].join(','));
      services.forEach(s => {
        rows.push([
          s.service_id || '',
          s.service_name || '',
          s.asset_id || '',
          s.asset_name || '',
          s.service_type || '',
          s.service_description || '',
          s.status || ''
        ].join(','));
      });
    } else if (formData.platform === 'demo_job') {
      const jobs = previewData?.jobs || [];
      rows.push(['Job ID', 'Job Name', 'Asset ID', 'Service Name', 'Job Type', 'Schedule', 'Description', 'Status'].join(','));
      jobs.forEach(j => {
        rows.push([
          j.job_id || '',
          j.job_name || '',
          j.asset_id || '',
          j.service_name || '',
          j.job_type || '',
          j.job_schedule || '',
          j.job_description || '',
          j.status || ''
        ].join(','));
      });
    } else if (formData.platform === 'demo_sla') {
      const slas = previewData?.slas || [];
      rows.push(['SLA ID', 'SLA Name', 'Asset ID', 'Service Name', 'Job Name', 'SLA Type', 'Target Value', 'Warning Threshold', 'Critical Threshold', 'Measurement Period'].join(','));
      slas.forEach(s => {
        rows.push([
          s.sla_id || '',
          s.sla_name || '',
          s.asset_id || '',
          s.service_name || '',
          s.job_name || '',
          s.sla_type || '',
          s.target_value_percentage || '',
          s.warning_threshold_percentage || '',
          s.critical_threshold_percentage || '',
          s.measurement_period || ''
        ].join(','));
      });
    }

    const csvContent = rows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${formData.connector_name.replace(/\s+/g, '_')}_sample_data.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = () => {
    const dataStr = JSON.stringify(previewData, null, 2);
    navigator.clipboard.writeText(dataStr).then(() => {
      alert('✓ JSON copied to clipboard!');
    }).catch(err => {
      alert('Failed to copy: ' + err.message);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('token');
      
      const platformConfig = platformOptions.find(p => p.value === formData.platform);
      const configFields = {};
      
      if (!platformConfig?.isDemo) {
        platformConfig?.fields.forEach(field => {
          const input = document.querySelector(`[name="${field.name}"]`);
          if (input) {
            configFields[field.name] = input.value;
          }
        });
      }

      const apiEndpoint = buildApiEndpointUrl(formData.platform, configFields);
      const apiKey = buildApiKey(formData.platform, configFields);

      // Map frontend connector types to backend types
      // Backend expects: 'asset', 'service_job', 'sla'
      // Frontend uses: 'asset', 'service', 'job', 'sla'
      const mapConnectorType = (frontendType) => {
        if (frontendType === 'service' || frontendType === 'job') {
          return 'service_job';
        }
        return frontendType; // 'asset' or 'sla' remain the same
      };

      // Filter out empty/unmapped field mappings
      // Only include fields that have a valid source field selected
      const validFieldMappings = Object.entries(fieldMappings)
        .filter(([targetField, sourceField]) => sourceField && sourceField.trim() !== '')
        .reduce((acc, [targetField, sourceField]) => {
          acc[targetField] = sourceField;
          return acc;
        }, {});

      const payload = {
        connector_name: formData.connector_name,
        connector_type: mapConnectorType(formData.connector_type),
        platform: formData.platform,
        api_endpoint_url: apiEndpoint,
        api_key: apiKey,
        is_active: true,
        field_mappings: validFieldMappings // Send only valid mappings
      };

      console.log(isEditMode ? 'Updating connector:' : 'Creating connector:', payload);
      
      // Use PUT for edit, POST for create
      const url = isEditMode 
        ? `http://localhost:5000/api/v1/connectors/${connector?.connector_id || connector?.id}`
        : 'http://localhost:5000/api/v1/connectors';
      
      const method = isEditMode ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to ${isEditMode ? 'update' : 'create'} connector`);
      }

      const data = await response.json();
      console.log(isEditMode ? 'Connector updated:' : 'Connector created:', data);
      
      alert(isEditMode ? '✓ Connector updated successfully!' : '✓ Connector created successfully!');
      
      onSuccess && onSuccess();
      handleClose();
      
    } catch (err) {
      console.error(`Error ${isEditMode ? 'updating' : 'creating'} connector:`, err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!connector) return;
    
    const confirmDelete = window.confirm(
      `Are you sure you want to delete the connector "${connector.connector_name}"? This action cannot be undone.`
    );
    
    if (!confirmDelete) return;
    
    setLoading(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      
      // Handle both possible ID field names (id or connector_id)
      const connectorId = connector?.id || connector?.connector_id;
      
      if (!connectorId) {
        throw new Error('Connector ID not found');
      }
      
      console.log('Deleting connector:', connectorId);
      
      const response = await fetch(
        `http://localhost:5000/api/v1/connectors/${connectorId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || errorData.message || 'Failed to delete connector');
      }
      
      const result = await response.json();
      console.log('Delete response:', result);
      
      alert('✓ Connector deleted successfully!');
      
      // Trigger parent component refresh
      if (onSuccess) {
        onSuccess();
      }
      
      // Close modal
      handleClose();
      
    } catch (err) {
      console.error('Delete error:', err);
      setError(err.message);
      alert(`Error deleting connector: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };
  const handleClose = () => {
    setStep(1);
    setFormData({
      connector_name: '',
      connector_type: 'service_job',
      platform: '',
      api_endpoint_url: '',
      api_key: '',
      is_demo: false
    });
    setTestStatus(null);
    setTestResult(null);
    setPreviewData(null);
    setFieldMappings({});
    setAvailableFields([]);
    setError('');
    onClose();
  };

  const selectedPlatform = platformOptions.find(p => p.value === formData.platform);
  const isDemo = selectedPlatform?.isDemo || false;
  const requiredFields = requiredFieldsByType[formData.connector_type];
  
  // Filter to show only mandatory fields in mapping table
  const mandatoryFields = requiredFields || [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {isEditMode ? `Edit Connector - ${
              step === 3 ? 'Configuration' :
              step === 4 ? 'Preview Data' :
              step === 5 ? 'Field Mapping' : 'Edit'
            }` :
              step === 1 ? 'Select Connector Type' :
              step === 2 ? 'Select Platform' :
              step === 3 ? 'Configure Connector' :
              step === 4 ? 'Preview Data' :
              'Configure Field Mapping'
            }
          </h2>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <FiX size={24} />
          </button>
        </div>

        {/* Progress Steps */}
        <div className="px-6 py-3 bg-gray-50 border-b">
          <div className="flex items-center justify-between">
            {['Type', 'Platform', 'Configure', 'Preview', 'Mapping']
              .filter((_, idx) => !isEditMode || idx >= 2)
              .map((label, idx) => {
              const stepNum = isEditMode ? idx + 3 : idx + 1;
              const isActive = step === stepNum;
              const isComplete = step > stepNum;
              
              return (
                <div key={stepNum} className="flex items-center flex-1">
                  <div className={`flex items-center ${idx > 0 ? 'w-full' : ''}`}>
                    {idx > 0 && (
                      <div className={`flex-1 h-1 mx-2 ${isComplete ? 'bg-primary-600' : 'bg-gray-200'}`} />
                    )}
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                        isComplete ? 'bg-primary-600 text-white' :
                        isActive ? 'bg-primary-100 text-primary-600 border-2 border-primary-600' :
                        'bg-gray-200 text-gray-500'
                      }`}>
                        {isComplete ? '✓' : stepNum}
                      </div>
                      <span className={`text-xs mt-1 ${isActive ? 'text-primary-600 font-medium' : 'text-gray-500'}`}>
                        {label}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
              {error}
            </div>
          )}

          {/* Step 1: Select Connector Type */}
          {step === 1 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {connectorTypeOptions.map((type) => {
                const Icon = type.icon;
                const isSelected = formData.connector_type === type.value;
                
                return (
                  <div
                    key={type.value}
                    onClick={() => setFormData({ ...formData, connector_type: type.value, platform: '' })}
                    className={`p-6 border-2 rounded-lg cursor-pointer transition-all ${
                      isSelected
                        ? 'border-primary-600 bg-primary-50'
                        : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                    }`}
                  >
                    <Icon className={`text-4xl mb-3 ${
                      type.color === 'blue' ? 'text-blue-600' :
                      type.color === 'green' ? 'text-green-600' :
                      'text-purple-600'
                    }`} />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{type.name}</h3>
                    <p className="text-sm text-gray-600">{type.description}</p>
                  </div>
                );
              })}
            </div>
          )}

          {/* Step 2: Select Platform */}
          {step === 2 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platformOptions.map((platform) => {
                const Icon = platform.icon;
                const isSelected = formData.platform === platform.value;
                
                return (
                  <div
                    key={platform.value}
                    onClick={() => {
                      setFormData({
                        ...formData,
                        platform: platform.value,
                        api_endpoint_url: platform.defaultEndpoint || '',
                        is_demo: platform.isDemo
                      });
                    }}
                    className={`p-6 rounded-lg cursor-pointer transition-all ${
                      platform.isDemo
                        ? 'border-2 border-dashed border-blue-300 bg-gradient-to-br from-blue-50 to-blue-100'
                        : 'border-2 border-gray-200 bg-white hover:border-gray-300 hover:shadow-md'
                    } ${isSelected ? 'ring-2 ring-primary-500' : ''}`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <Icon className={`text-3xl ${
                        platform.color === 'blue' ? 'text-blue-600' :
                        platform.color === 'teal' ? 'text-teal-600' :
                        'text-purple-600'
                      }`} />
                      {platform.isDemo && (
                        <span className="px-2 py-1 bg-blue-600 text-white text-xs font-bold rounded">
                          🧪 DEMO
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">{platform.name}</h3>
                    {platform.subtitle && (
                      <p className="text-xs text-blue-600 font-medium mb-2">{platform.subtitle}</p>
                    )}
                    <p className="text-sm text-gray-600">{platform.description}</p>
                  </div>
                );
              })}
            </div>
          )}

          {/* Step 3: Configure Connector */}
          {step === 3 && selectedPlatform && (
            <form onSubmit={(e) => { e.preventDefault(); }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Connector Name *
                  </label>
                  <input
                    type="text"
                    value={formData.connector_name}
                    onChange={(e) => setFormData({ ...formData, connector_name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="My Asset Connector"
                    required
                  />
                </div>

                {isDemo ? (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        API Endpoint URL *
                      </label>
                      <input
                        type="url"
                        value={formData.api_endpoint_url}
                        onChange={(e) => setFormData({ ...formData, api_endpoint_url: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                        required
                        readOnly
                      />
                    </div>
                    
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                      <p className="text-sm text-blue-700 mb-2">
                        ℹ️ This is a demo simulator running locally. No authentication required.
                      </p>
                      <p className="text-xs text-blue-600 font-mono">
                        📋 Available Endpoints:<br/>
                        • Health: {selectedPlatform.healthEndpoint}<br/>
                        • Data: {selectedPlatform.dataEndpoint}
                      </p>
                    </div>
                  </>
                ) : (
                  selectedPlatform.fields.map((field) => (
                    <div key={field.name} className="mb-4">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {field.label} {field.required && '*'}
                      </label>
                      
                      {field.type === 'select' ? (
                        <select
                          name={field.name}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          required={field.required}
                        >
                          <option value="">Select {field.label}</option>
                          {field.options.map(option => (
                            <option key={option} value={option}>{option}</option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type={field.type}
                          name={field.name}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          placeholder={field.placeholder}
                          required={field.required}
                        />
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Connection Test Section */}
              {formData.api_endpoint_url && (
                <div className="border-t pt-4 mt-4">
                  <h3 className="text-sm font-semibold text-gray-900 mb-3">Connection Test</h3>
                  
                  {testStatus === 'testing' && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                      <div className="flex items-center space-x-3">
                        <FiLoader className="animate-spin text-blue-600" size={20} />
                        <span className="text-blue-700">Testing connection...</span>
                      </div>
                    </div>
                  )}

                  {testStatus === 'success' && testResult && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                      <div className="flex items-start space-x-3">
                        <FiCheckCircle className="text-green-600 mt-0.5" size={20} />
                        <div className="flex-1">
                          <p className="text-green-700 font-semibold">✅ Connection Successful!</p>
                          <div className="mt-2 text-sm text-green-600 space-y-1">
                            <p>Status: {testResult.status}</p>
                            <p>Platform: {testResult.platform}</p>
                            <p>Version: {testResult.version}</p>
                            <p>Response Time: {testResult.responseTime}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {testStatus === 'failed' && testResult && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                      <div className="flex items-start space-x-3">
                        <FiXCircle className="text-red-600 mt-0.5" size={20} />
                        <div className="flex-1">
                          <p className="text-red-700 font-semibold">❌ Connection Failed</p>
                          <p className="mt-2 text-sm text-red-600">{testResult.error}</p>
                          {isDemo && (
                            <div className="mt-3 text-sm text-red-600 bg-red-100 p-3 rounded">
                              <p className="font-semibold">⚠️ Make sure the simulator is running:</p>
                              <p className="font-mono mt-1">
                                {formData.platform === 'demo_autosys' && 'python autosys_simulator.py'}
                                {formData.platform === 'demo_ansible' && 'python ansible_simulator.py'}
                                {formData.platform === 'demo_asset' && 'python asset_provider_simulator.py'}
                                {formData.platform === 'demo_service' && 'python service_provider_simulator.py'}
                                {formData.platform === 'demo_job' && 'python job_provider_simulator.py'}
                                {formData.platform === 'demo_sla' && 'python sla_provider_simulator.py'}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={testConnection}
                      disabled={testStatus === 'testing'}
                    >
                      {testStatus === 'testing' ? 'Testing...' : testStatus === 'failed' ? 'Retry Test' : 'Test Connection'}
                    </Button>

                    {testStatus === 'success' && isDemo && (
                      <Button
                        type="button"
                        onClick={fetchPreviewData}
                        disabled={loading}
                      >
                        Preview Data
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </form>
          )}

          {/* Step 4: Preview Data */}
          {step === 4 && previewData && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Sample Data Preview</h3>
                  <p className="text-sm text-gray-600">
                    Endpoint: {formData.api_endpoint_url}{selectedPlatform?.dataEndpoint}
                  </p>
                </div>
              </div>

              {/* JSON View */}
              <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto max-h-96">
                <pre>{JSON.stringify(previewData, null, 2)}</pre>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-700">
                  💡 Next step: Configure field mappings to match this data with your portal's required fields.
                </p>
              </div>

              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copyToClipboard}
                >
                  <FiCopy className="mr-2" size={16} />
                  Copy JSON
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={downloadJSON}
                >
                  <FiDownload className="mr-2" size={16} />
                  Download JSON
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={exportCSV}
                >
                  <FiDownload className="mr-2" size={16} />
                  Export CSV
                </Button>
              </div>
            </div>
          )}

          {/* Step 5: Configure Field Mapping */}
          {step === 5 && (
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <FiAlertCircle className="text-blue-600 flex-shrink-0 mt-0.5" size={20} />
                  <div className="flex-1">
                    <h4 className="font-semibold text-blue-900 mb-1">About Field Mapping</h4>
                    <p className="text-sm text-blue-700">
                      Map the fields from your data source to the required fields in the SLA Monitoring Portal.
                      This ensures data is imported correctly during bulk import operations.
                    </p>
                  </div>
                </div>
              </div>

              {/* Auto-Map Button */}
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={autoMapFields}
                  icon={FiZap}
                >
                  Auto-Map Fields
                </Button>
              </div>

              {/* Field Mappings */}
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Portal Field</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Source Field</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {mandatoryFields.map((field, idx) => (
                      <tr key={field.name} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium text-gray-900">
                              {field.label}
                            </span>
                            {field.required && (
                              <span className="text-red-600 text-sm">*</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          {field.type === 'date' ? (
                            // Date picker for date fields
                            <div className="relative">
                              <input
                                type="date"
                                value={onboardedDate ? (() => {
                                  // Convert MM/DD/YYYY to YYYY-MM-DD
                                  const parts = onboardedDate.split('/');
                                  if (parts.length === 3) {
                                    const [month, day, year] = parts;
                                    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
                                  }
                                  return '';
                                })() : ''}
                                onChange={(e) => {
                                  // Convert YYYY-MM-DD to MM/DD/YYYY
                                  const dateParts = e.target.value.split('-');
                                  if (dateParts.length === 3) {
                                    const [year, month, day] = dateParts;
                                    const formatted = `${month}/${day}/${year}`;
                                    setOnboardedDate(formatted);
                                    setFieldMappings({
                                      ...fieldMappings,
                                      [field.name]: formatted
                                    });
                                  }
                                }}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 pr-10"
                              />
                              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                                📅
                              </div>
                            </div>
                          ) : field.type === 'select' ? (
                            // Dropdown with predefined options (for status, etc.)
                            <select
                              value={field.name === 'status' ? assetStatus : (fieldMappings[field.name] || '')}
                              onChange={(e) => {
                                if (field.name === 'status') {
                                  setAssetStatus(e.target.value);
                                }
                                setFieldMappings({
                                  ...fieldMappings,
                                  [field.name]: e.target.value
                                });
                              }}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                            >
                              {field.options?.map(option => (
                                <option key={option} value={option}>{option}</option>
                              ))}
                            </select>
                          ) : (
                            // Dropdown for regular fields (source field mapping)
                            <select
                              value={fieldMappings[field.name] || ''}
                              onChange={(e) => setFieldMappings({
                                ...fieldMappings,
                                [field.name]: e.target.value
                              })}
                              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500 ${
                                field.required && !fieldMappings[field.name]
                                  ? 'border-red-300 bg-red-50'
                                  : 'border-gray-300'
                              }`}
                            >
                              <option value="">Select source field...</option>
                              {availableFields.map(f => (
                                <option key={f} value={f}>{f}</option>
                              ))}
                            </select>
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {field.description}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Validation Warning */}
              {validateMappings().length > 0 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <FiAlertCircle className="text-yellow-600 flex-shrink-0 mt-0.5" size={20} />
                    <div>
                      <h4 className="font-semibold text-yellow-900 mb-1">Required Fields Not Mapped</h4>
                      <p className="text-sm text-yellow-700">
                        The following required fields are not mapped: {validateMappings().join(', ')}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Preview Mapped Data */}
              {Object.keys(fieldMappings).length > 0 && (
                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-3 border-b">
                    <h4 className="font-semibold text-gray-900">📋 Preview Mapped Data (First 5 records)</h4>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-100">
                        <tr>
                          {mandatoryFields.filter(f => fieldMappings[f.name]).map(f => (
                            <th key={f.name} className="px-4 py-2 text-left text-sm font-medium text-gray-700">
                              {f.label}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {previewMappedData().map((row, idx) => (
                          <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            {mandatoryFields.filter(f => fieldMappings[f.name]).map(f => (
                              <td key={f.name} className="px-4 py-2 text-sm text-gray-900">
                                {row[f.name]}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between bg-gray-50">
          <div>
            {step > 1 && (
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
              >
                ← Back
              </Button>
            )}
          </div>
          <div className="flex space-x-2">
            {step === 1 && (
              <Button
                onClick={() => setStep(2)}
                disabled={!formData.connector_type}
              >
                Next: Select Platform →
              </Button>
            )}
            {step === 2 && (
              <Button
                onClick={() => setStep(3)}
                disabled={!formData.platform}
              >
                Next: Configure →
              </Button>
            )}
            {step === 3 && testStatus === 'success' && !isDemo && (
              <Button onClick={() => {
                // Initialize date and status fields when entering mapping step
                if (formData.connector_type === 'asset') {
                  const updates = {};
                  if (!fieldMappings['onboarded_date']) {
                    updates.onboarded_date = onboardedDate;
                  }
                  if (!fieldMappings['status']) {
                    updates.status = assetStatus;
                  }
                  if (Object.keys(updates).length > 0) {
                    setFieldMappings({
                      ...fieldMappings,
                      ...updates
                    });
                  }
                }
                setStep(5);
              }}>
                Next: Configure Mapping →
              </Button>
            )}
            {step === 4 && (
              <Button onClick={() => {
                // Initialize date and status fields when entering mapping step
                if (formData.connector_type === 'asset') {
                  const updates = {};
                  if (!fieldMappings['onboarded_date']) {
                    updates.onboarded_date = onboardedDate;
                  }
                  if (!fieldMappings['status']) {
                    updates.status = assetStatus;
                  }
                  if (Object.keys(updates).length > 0) {
                    setFieldMappings({
                      ...fieldMappings,
                      ...updates
                    });
                  }
                }
                setStep(5);
              }}>
                Next: Configure Mapping →
              </Button>
            )}
            {step === 5 && (
              <Button
                onClick={handleSubmit}
                disabled={loading || validateMappings().length > 0}
              >
                {loading 
                  ? (isEditMode ? 'Updating...' : 'Creating...') 
                  : (isEditMode ? 'Update Connector' : 'Create Connector')
                }
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddConnectorModal;
