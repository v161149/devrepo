/**
 * App Component
 * Main application component with routing
 * UPDATED: Added Bulk Onboarding route
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import AITs from './pages/AITs';
import AITDetail from './pages/AITDetail';
import Assets from './pages/Assets';
import AssetDetail from './pages/AssetDetail';
import Services from './pages/Services';
import ServiceDetails from './pages/ServiceDetails';
import Jobs from './pages/Jobs';
import JobDetail from './pages/JobDetail';
import SLAsPage from './pages/SLAsPage';
import Alerts from './pages/Alerts';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import ProcessFlow from './pages/ProcessFlow';
import ManualOnboarding from './pages/onboarding/EnhancedOnboardingWizard';
import BulkOnboarding from './pages/onboarding/BulkOnboardingWizard'; // NEW
import MetadataRetrieval from './pages/tools/MetadataRetrieval';
import IntegrationHealth from './pages/tools/IntegrationHealth';
import LogServerSetup from './pages/tools/LogServerSetup'; // NEW
import SystemSettings from './pages/SystemSettings';
import HelpBot from './components/HelpBot';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

// App Routes Component
const AppRoutes = () => {
  const { isAuthenticated } = useAuth();

  return (
    <>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Layout>
                <Dashboard />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/process-flow"
          element={
            <ProtectedRoute>
              <Layout>
                <ProcessFlow />
              </Layout>
            </ProtectedRoute>
          }
        />
        
        {/* Onboarding Routes - NEW: Split into Manual and Bulk */}
        <Route
          path="/onboarding/manual"
          element={
            <ProtectedRoute>
              <Layout>
                <ManualOnboarding />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/onboarding/bulk"
          element={
            <ProtectedRoute>
              <Layout>
                <BulkOnboarding />
              </Layout>
            </ProtectedRoute>
          }
        />
        {/* Redirect /onboarding to /onboarding/manual for backward compatibility */}
        <Route
          path="/onboarding"
          element={<Navigate to="/onboarding/manual" replace />}
        />
        
        {/* Tools Routes */}
        <Route
          path="/tools/metadata-retrieval"
          element={
            <ProtectedRoute>
              <Layout>
                <MetadataRetrieval />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/tools/integration-health"
          element={
            <ProtectedRoute>
              <Layout>
                <IntegrationHealth />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/tools/log-server-setup"
          element={
            <ProtectedRoute>
              <Layout>
                <LogServerSetup />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/tools/system-settings"
          element={
            <ProtectedRoute>
              <Layout>
                <SystemSettings />
              </Layout>
            </ProtectedRoute>
          }
        />

        {/* AITs Routes */}
        <Route
          path="/aits"
          element={
            <ProtectedRoute>
              <Layout>
                <AITs />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/aits/:aitid"
          element={
            <ProtectedRoute>
              <Layout>
                <AITDetail />
              </Layout>
            </ProtectedRoute>
          }
        />

        {/* Asset Routes */}
        <Route
          path="/assets"
          element={
            <ProtectedRoute>
              <Layout>
                <Assets />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/assets/:id"
          element={
            <ProtectedRoute>
              <Layout>
                <AssetDetail />
              </Layout>
            </ProtectedRoute>
          }
        />
        
        {/* Service Routes */}
        <Route
          path="/services"
          element={
            <ProtectedRoute>
              <Layout>
                <Services />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/services/:id"
          element={
            <ProtectedRoute>
              <Layout>
                <ServiceDetails />
              </Layout>
            </ProtectedRoute>
          }
        />

        {/* Job Routes */}
        <Route
          path="/jobs"
          element={
            <ProtectedRoute>
              <Layout>
                <Jobs />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/jobs/:id"
          element={
            <ProtectedRoute>
              <Layout>
                <JobDetail />
              </Layout>
            </ProtectedRoute>
          }
        />

        {/* SLA Routes */}
        <Route
          path="/slas"
          element={
            <ProtectedRoute>
              <Layout>
                <SLAsPage />
              </Layout>
            </ProtectedRoute>
          }
        />
        
        {/* Other Routes */}
        <Route
          path="/alerts"
          element={
            <ProtectedRoute>
              <Layout>
                <Alerts />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/reports"
          element={
            <ProtectedRoute>
              <Layout>
                <Reports />
              </Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <Layout>
                <Settings />
              </Layout>
            </ProtectedRoute>
          }
        />

        {/* Default Route */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>

      {/* Help Bot - Only show when authenticated */}
      {isAuthenticated && <HelpBot />}
    </>
  );
};

// Main App Component
const App = () => {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
};

export default App;
