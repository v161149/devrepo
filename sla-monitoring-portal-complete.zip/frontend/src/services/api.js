/**
 * API Client Service - ENHANCED WITH AITs
 * Handles all HTTP requests to the backend API
 */

import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

const apiService = {
  // ============= Authentication =============
  auth: {
    login: (email, password) =>
      apiClient.post('/auth/login', { email, password }),
    
    logout: () =>
      apiClient.post('/auth/logout'),
    
    getCurrentUser: () =>
      apiClient.get('/auth/me'),
  },

  // ============= AITs (NEW) =============
  aits: {
    list: (params = {}) =>
      apiClient.get('/aits', { params }),
    
    get: (id) =>
      apiClient.get(`/aits/${id}`),
    
    create: (data) =>
      apiClient.post('/aits', data),
    
    update: (id, data) =>
      apiClient.put(`/aits/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/aits/${id}`),
    
    getAssets: (aitId) =>
      apiClient.get(`/aits/${aitId}/assets`),
  },

  // ============= Services =============
  services: {
    list: (params = {}) =>
      apiClient.get('/services', { params }),
    
    getAll: (params = {}) =>
      apiClient.get('/services', { params }),
    
    listWithHealth: () =>
      apiClient.get('/services/with-health'),
    
    getById: (id) =>
      apiClient.get(`/services/${id}`),
    
    create: (data) =>
      apiClient.post('/services', data),
    
    update: (id, data) =>
      apiClient.put(`/services/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/services/${id}`),
    
    getSLAs: (serviceId) =>
      apiClient.get(`/services/${serviceId}/slas`),
  },

  // ============= SLAs =============
  slas: {
    getAll: (params = {}) =>
      apiClient.get('/slas', { params }),
    
    list: (params = {}) =>
      apiClient.get('/slas', { params }),
    
    getById: (id) =>
      apiClient.get(`/slas/${id}`),
    
    getByService: (serviceId) =>
      apiClient.get(`/services/${serviceId}/slas`),
    
    getByAsset: (assetId) =>
      apiClient.get(`/assets/${assetId}/slas`),
    
    create: (data) =>
      apiClient.post('/slas', data),
    
    update: (id, data) =>
      apiClient.put(`/slas/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/slas/${id}`),
    
    getEvaluations: (slaId) =>
      apiClient.get(`/slas/${slaId}/evaluations`),
    
    getCompliance: (slaId) =>
      apiClient.get(`/slas/${slaId}/compliance`),

    getDashboard: () =>
      apiClient.get('/slas'),
  },

  // ============= Assets =============
  assets: {
    list: (params = {}) =>
      apiClient.get('/assets', { params }),

    get: (id) =>
      apiClient.get(`/assets/${id}`),

    create: (data) =>
      apiClient.post('/assets', data),

    update: (id, data) =>
      apiClient.put(`/assets/${id}`, data),

    delete: (id) =>
      apiClient.delete(`/assets/${id}`),

    getServices: (assetId) =>
      apiClient.get(`/assets/${assetId}/services`),

    addService: (assetId, data) =>
      apiClient.post(`/assets/${assetId}/services`, data),
    
    getSLAs: (assetId) =>
      apiClient.get(`/assets/${assetId}/slas`),
  },

  // ============= Jobs =============
  jobs: {
    list: (params = {}) =>
      apiClient.get('/jobs', { params }),
    
    getAll: (params = {}) =>
      apiClient.get('/jobs', { params }), 
    
    get: (id) =>
      apiClient.get(`/jobs/${id}`), 
    
    create: (data) =>
      apiClient.post('/jobs', data),
    
    update: (id, data) =>
      apiClient.put(`/jobs/${id}`, data), 
    
    delete: (id) =>
      apiClient.delete(`/jobs/${id}`),
    
    getSLAs: (jobId) =>
      apiClient.get(`/jobs/${jobId}/slas`),
  },

  // ============= Alerts =============
  alerts: {
    getAll: (params = {}) =>
      apiClient.get('/alerts', { params }),
    
    getById: (id) =>
      apiClient.get(`/alerts/${id}`),
    
    acknowledge: (id) =>
      apiClient.post(`/alerts/${id}/acknowledge`),
    
    dismiss: (id) =>
      apiClient.post(`/alerts/${id}/dismiss`),
  },

  // ============= Dashboard =============
  dashboard: {
    getMetrics: (days = 30) =>
      apiClient.get('/dashboard/metrics', { params: { days } }),
    
    getSLACompliance: () =>
      apiClient.get('/dashboard/sla-compliance'),
    
    getRecentAlerts: (limit = 10) =>
      apiClient.get('/dashboard/alerts', { params: { limit } }),
  },

  // ============= Compliance =============
  compliance: {
    /**
     * Get compliance overview at specified level
     */
    getOverview: (params = {}) =>
      apiClient.get('/compliance/overview', { params }),

    /**
     * Get compliance summary metrics
     */
    getSummary: (params = {}) =>
      apiClient.get('/compliance/summary', { params }),

    /**
     * Get drill-down data for specific entity
     */
    getDrillDown: (entityType, entityId, params = {}) =>
      apiClient.get(`/compliance/drill-down/${entityType}/${entityId}`, { params }),
  },

  // ============= Events =============
  events: {
    getAll: (params = {}) =>
      apiClient.get('/events', { params }),
    
    getById: (id) =>
      apiClient.get(`/events/${id}`),
    
    create: (data) =>
      apiClient.post('/events', data),
  },

  // ============= Reports =============
  reports: {
    generate: (data) =>
      apiClient.post('/reports', data),
    
    getAll: () =>
      apiClient.get('/reports'),
    
    getById: (id) =>
      apiClient.get(`/reports/${id}`),
    
    download: (id) =>
      apiClient.get(`/reports/${id}/download`, { responseType: 'blob' }),
  },

  // ============= Integrations =============
  integrations: {
    getAll: () =>
      apiClient.get('/integrations'),
    
    getById: (id) =>
      apiClient.get(`/integrations/${id}`),
    
    create: (data) =>
      apiClient.post('/integrations', data),
    
    update: (id, data) =>
      apiClient.put(`/integrations/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/integrations/${id}`),
    
    test: (id) =>
      apiClient.post(`/integrations/${id}/test`),
  },

  // ============= Onboarding =============
  onboarding: {
    getProgress: () =>
      apiClient.get('/onboarding/progress'),
    
    updateProgress: (data) =>
      apiClient.put('/onboarding/progress', data),
    
    complete: () =>
      apiClient.post('/onboarding/complete'),
  },

  // ============= Connectors =============
  connectors: {
    list: (type = null) =>
      apiClient.get('/connectors', { params: { type } }),
    
    get: (id) =>
      apiClient.get(`/connectors/${id}`),
    
    create: (data) =>
      apiClient.post('/connectors', data),
    
    update: (id, data) =>
      apiClient.put(`/connectors/${id}`, data),
    
    delete: (id) =>
      apiClient.delete(`/connectors/${id}`),
    
    test: (id) =>
      apiClient.post(`/connectors/${id}/test`),
    
    fetchData: (id) =>
      apiClient.post(`/connectors/${id}/fetch`),
  },
};

export default apiService;
export { apiClient, API_BASE_URL };
