# SLA Monitoring Portal - Frontend

Modern React-based frontend application for the SLA Monitoring Portal.

## 🏗️ Architecture

### Tech Stack
- **React 18** - UI library
- **React Router** - Client-side routing
- **Axios** - HTTP client
- **Tailwind CSS** - Utility-first CSS framework
- **Vite** - Build tool and dev server
- **React Icons** - Icon library

### Project Structure

```
frontend/
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── Button.jsx
│   │   ├── Card.jsx
│   │   ├── MetricCard.jsx
│   │   ├── AlertList.jsx
│   │   ├── SLAComplianceChart.jsx
│   │   └── Layout.jsx
│   ├── pages/               # Page components
│   │   ├── Login.jsx
│   │   ├── Dashboard.jsx
│   │   ├── Services.jsx
│   │   ├── Alerts.jsx
│   │   ├── Reports.jsx
│   │   └── Settings.jsx
│   ├── services/            # API services
│   │   └── api.js          # API client with all endpoints
│   ├── contexts/            # React contexts
│   │   └── AuthContext.jsx # Authentication state
│   ├── hooks/               # Custom React hooks
│   ├── utils/               # Utility functions
│   ├── styles/              # Global styles
│   │   └── index.css
│   ├── App.jsx             # Main app component
│   └── main.jsx            # Entry point
├── index.html
├── package.json
├── vite.config.js
└── tailwind.config.js
```

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ and npm
- Backend API running on `http://localhost:5000`

### Installation

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

The application will open at `http://localhost:3000`

### Build for Production

```bash
# Create production build
npm run build

# Preview production build
npm run preview
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the frontend directory:

```env
VITE_API_URL=http://localhost:5000/api/v1
```

### API Proxy

Vite is configured to proxy API requests to avoid CORS issues in development:

```javascript
// vite.config.js
proxy: {
  '/api': {
    target: 'http://localhost:5000',
    changeOrigin: true,
  },
}
```

## 📋 Features

### Authentication
- JWT-based authentication
- Auto token refresh
- Protected routes
- Session management

### Components

#### Reusable Components
- **Button** - Multiple variants (primary, secondary, outline, etc.)
- **Card** - Container component with header/footer support
- **MetricCard** - Dashboard metrics with icons and trends
- **AlertList** - Alert management with filtering
- **Layout** - Sidebar navigation and header

#### Pages
- **Login** - User authentication
- **Dashboard** - Metrics and overview
- **Services** - Service management
- **Alerts** - Alert monitoring
- **Reports** - Analytics and reports
- **Settings** - User preferences

### API Integration

All API calls are centralized in `src/services/api.js`:

```javascript
import apiService from '../services/api';

// Example usage
const response = await apiService.dashboard.getMetrics(30);
const services = await apiService.services.getAll();
const alerts = await apiService.alerts.getAll({ status: 'pending' });
```

### State Management

- **AuthContext** - Global authentication state
- React hooks for component-level state
- LocalStorage for persistence

## 🎨 Styling

### Tailwind CSS

The project uses Tailwind CSS for styling with custom theme configuration:

```javascript
// tailwind.config.js
theme: {
  extend: {
    colors: {
      primary: {
        500: '#667eea',
        600: '#5568d3',
        // ...
      },
    },
  },
}
```

### Custom Styles

Additional styles in `src/styles/index.css`:
- Custom animations
- Scrollbar styling
- Component utilities

## 🔒 Security

### Authentication Flow

1. User logs in with credentials
2. Backend returns JWT token
3. Token stored in localStorage
4. Token added to all API requests via interceptor
5. Auto-logout on 401 responses

### Protected Routes

```javascript
<ProtectedRoute>
  <Dashboard />
</ProtectedRoute>
```

## 📱 Responsive Design

- Mobile-first approach
- Responsive grid layouts
- Collapsible sidebar navigation
- Touch-friendly interfaces

## 🧪 Development

### Code Organization Principles

1. **Modularity** - Components are small and focused
2. **Separation of Concerns** - API logic separate from UI
3. **Reusability** - DRY principles throughout
4. **Maintainability** - Clear naming and documentation
5. **Performance** - Lazy loading and optimization
6. **Extensibility** - Easy to add new features

### Adding a New Page

1. Create page component in `src/pages/`
2. Add route in `App.jsx`
3. Add navigation item in `Layout.jsx`
4. Create any needed API endpoints in `api.js`

Example:

```javascript
// src/pages/NewPage.jsx
import React from 'react';
import Card from '../components/Card';

const NewPage = () => {
  return (
    <div>
      <h1>New Page</h1>
      <Card>Content here</Card>
    </div>
  );
};

export default NewPage;
```

```javascript
// App.jsx
<Route path="/new-page" element={
  <ProtectedRoute>
    <Layout><NewPage /></Layout>
  </ProtectedRoute>
} />
```

### Adding a New Component

1. Create component in `src/components/`
2. Document props with JSDoc comments
3. Export component
4. Use in pages

Example:

```javascript
/**
 * MyComponent
 * @param {string} title - Component title
 * @param {ReactNode} children - Child elements
 */
const MyComponent = ({ title, children }) => {
  return (
    <div>
      <h3>{title}</h3>
      {children}
    </div>
  );
};

export default MyComponent;
```

## 🔧 Customization

### Colors

Edit `tailwind.config.js`:

```javascript
colors: {
  primary: {
    // Your brand colors
  },
}
```

### Layout

Modify `src/components/Layout.jsx`:
- Sidebar width
- Navigation items
- Header content

### API Endpoints

Update `src/services/api.js`:
- Base URL
- Endpoint paths
- Request/response handling

## 📊 Performance Optimization

- Code splitting with React.lazy()
- Image optimization
- Minification and bundling
- Tree shaking
- Gzip compression
- CDN for static assets (production)

## 🐛 Debugging

### Dev Tools
- React Developer Tools
- Redux DevTools (if added)
- Network tab for API calls
- Console for errors

### Common Issues

**Issue**: API calls failing
- **Solution**: Check backend is running and CORS is configured

**Issue**: Routes not working
- **Solution**: Verify React Router configuration

**Issue**: Styles not applying
- **Solution**: Check Tailwind CSS build process

## 📦 Dependencies

### Core
- react: ^18.2.0
- react-dom: ^18.2.0
- react-router-dom: ^6.20.0

### Data & API
- axios: ^1.6.2

### UI & Styling
- tailwindcss: ^3.3.6
- react-icons: ^4.12.0

### Build Tools
- vite: ^5.0.8
- @vitejs/plugin-react: ^4.2.1

## 🔄 Updates & Maintenance

### Updating Dependencies

```bash
# Check for updates
npm outdated

# Update all dependencies
npm update

# Update specific package
npm install package-name@latest
```

### Version Management

Follow semantic versioning:
- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

## 📝 License

See main project LICENSE file.

## 🤝 Contributing

1. Follow existing code style
2. Write meaningful commit messages
3. Update documentation
4. Add tests for new features
5. Submit pull request

## 📞 Support

For issues or questions:
- Check documentation
- Review code comments
- Contact development team

---

**Built with ❤️ using React and Tailwind CSS**
