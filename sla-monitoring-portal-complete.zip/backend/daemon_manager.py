#!/usr/bin/env python3
"""
Daemon Manager - Manage Service and Job Monitor Daemons

This script provides a unified interface to manage both monitoring daemons:
- Start/stop/restart daemons
- Check daemon status
- View daemon logs
- Configure daemon settings

Usage:
    python daemon_manager.py [command] [options]
    
Commands:
    start [service|job|all]     Start daemon(s)
    stop [service|job|all]      Stop daemon(s)
    restart [service|job|all]   Restart daemon(s)
    status                      Show status of all daemons
    logs [service|job]          Tail daemon logs
    config                      Show daemon configuration
"""

import os
import sys
import subprocess
import signal
import time
import argparse
from typing import Optional

# Daemon configuration
DAEMON_CONFIG = {
    'service': {
        'name': 'Service Monitor',
        'script': 'service_monitor_daemon.py',
        'pidfile': 'service_monitor.pid',
        'logfile': 'service_monitor_daemon.log',
        'interval': 300  # 5 minutes
    },
    'job': {
        'name': 'Job Monitor',
        'script': 'job_monitor_daemon.py',
        'pidfile': 'job_monitor.pid',
        'logfile': 'job_monitor_daemon.log',
        'interval': 300  # 5 minutes
    }
}

class DaemonManager:
    """Manager for monitoring daemons"""
    
    def __init__(self, base_dir: Optional[str] = None):
        """
        Initialize daemon manager
        
        Args:
            base_dir: Base directory for daemon scripts (default: current dir)
        """
        self.base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
        
    def _get_pid(self, daemon_type: str) -> Optional[int]:
        """
        Get PID of running daemon
        
        Args:
            daemon_type: 'service' or 'job'
            
        Returns:
            PID or None if not running
        """
        pidfile = os.path.join(self.base_dir, DAEMON_CONFIG[daemon_type]['pidfile'])
        
        if not os.path.exists(pidfile):
            return None
        
        try:
            with open(pidfile, 'r') as f:
                pid = int(f.read().strip())
            
            # Check if process is actually running
            os.kill(pid, 0)
            return pid
        except (OSError, ValueError, ProcessLookupError):
            # PID file exists but process is not running
            if os.path.exists(pidfile):
                os.remove(pidfile)
            return None
    
    def _write_pid(self, daemon_type: str, pid: int):
        """Write PID to file"""
        pidfile = os.path.join(self.base_dir, DAEMON_CONFIG[daemon_type]['pidfile'])
        with open(pidfile, 'w') as f:
            f.write(str(pid))
    
    def _remove_pid(self, daemon_type: str):
        """Remove PID file"""
        pidfile = os.path.join(self.base_dir, DAEMON_CONFIG[daemon_type]['pidfile'])
        if os.path.exists(pidfile):
            os.remove(pidfile)
    
    def is_running(self, daemon_type: str) -> bool:
        """Check if daemon is running"""
        return self._get_pid(daemon_type) is not None
    
    def start(self, daemon_type: str, interval: Optional[int] = None):
        """
        Start a daemon
        
        Args:
            daemon_type: 'service' or 'job'
            interval: Override default check interval
        """
        config = DAEMON_CONFIG[daemon_type]
        
        if self.is_running(daemon_type):
            print(f"✗ {config['name']} is already running (PID: {self._get_pid(daemon_type)})")
            return False
        
        script_path = os.path.join(self.base_dir, config['script'])
        
        if not os.path.exists(script_path):
            print(f"✗ Daemon script not found: {script_path}")
            return False
        
        # Build command
        cmd = ['python3', script_path]
        
        if interval:
            cmd.extend(['--interval', str(interval)])
        else:
            cmd.extend(['--interval', str(config['interval'])])
        
        # Start daemon as background process
        print(f"Starting {config['name']}...")
        
        try:
            process = subprocess.Popen(
                cmd,
                cwd=self.base_dir,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
            
            # Give it a moment to start
            time.sleep(2)
            
            # Check if it's actually running
            if process.poll() is None:
                self._write_pid(daemon_type, process.pid)
                print(f"✓ {config['name']} started (PID: {process.pid})")
                return True
            else:
                print(f"✗ {config['name']} failed to start")
                return False
                
        except Exception as e:
            print(f"✗ Error starting {config['name']}: {str(e)}")
            return False
    
    def stop(self, daemon_type: str):
        """
        Stop a daemon
        
        Args:
            daemon_type: 'service' or 'job'
        """
        config = DAEMON_CONFIG[daemon_type]
        pid = self._get_pid(daemon_type)
        
        if not pid:
            print(f"✗ {config['name']} is not running")
            return False
        
        print(f"Stopping {config['name']} (PID: {pid})...")
        
        try:
            # Try graceful shutdown first
            os.kill(pid, signal.SIGTERM)
            
            # Wait up to 10 seconds for process to stop
            for i in range(10):
                time.sleep(1)
                try:
                    os.kill(pid, 0)
                except OSError:
                    # Process has stopped
                    self._remove_pid(daemon_type)
                    print(f"✓ {config['name']} stopped")
                    return True
            
            # If still running, force kill
            print(f"Process did not stop gracefully, forcing...")
            os.kill(pid, signal.SIGKILL)
            time.sleep(1)
            self._remove_pid(daemon_type)
            print(f"✓ {config['name']} stopped (forced)")
            return True
            
        except Exception as e:
            print(f"✗ Error stopping {config['name']}: {str(e)}")
            self._remove_pid(daemon_type)
            return False
    
    def restart(self, daemon_type: str, interval: Optional[int] = None):
        """Restart a daemon"""
        self.stop(daemon_type)
        time.sleep(1)
        return self.start(daemon_type, interval)
    
    def status(self):
        """Show status of all daemons"""
        print("\n" + "=" * 60)
        print("Monitoring Daemon Status")
        print("=" * 60)
        
        for daemon_type, config in DAEMON_CONFIG.items():
            pid = self._get_pid(daemon_type)
            
            print(f"\n{config['name']}:")
            print(f"  Status: {'✓ Running' if pid else '✗ Stopped'}")
            
            if pid:
                print(f"  PID: {pid}")
            
            print(f"  Script: {config['script']}")
            print(f"  Log File: {config['logfile']}")
            print(f"  Check Interval: {config['interval']}s")
            
            # Show last few log lines
            logfile = os.path.join(self.base_dir, config['logfile'])
            if os.path.exists(logfile):
                print(f"  Last Log Entry:")
                try:
                    with open(logfile, 'r') as f:
                        lines = f.readlines()
                        if lines:
                            last_line = lines[-1].strip()
                            if len(last_line) > 80:
                                last_line = last_line[:77] + "..."
                            print(f"    {last_line}")
                except:
                    pass
        
        print("\n" + "=" * 60)
    
    def tail_logs(self, daemon_type: str, lines: int = 50):
        """
        Tail daemon log file
        
        Args:
            daemon_type: 'service' or 'job'
            lines: Number of lines to show
        """
        config = DAEMON_CONFIG[daemon_type]
        logfile = os.path.join(self.base_dir, config['logfile'])
        
        if not os.path.exists(logfile):
            print(f"✗ Log file not found: {logfile}")
            return
        
        print(f"\nShowing last {lines} lines of {config['name']} log:\n")
        print("=" * 60)
        
        try:
            subprocess.run(['tail', f'-n{lines}', logfile])
        except Exception as e:
            print(f"✗ Error reading log: {str(e)}")
    
    def show_config(self):
        """Show daemon configuration"""
        print("\n" + "=" * 60)
        print("Monitoring Daemon Configuration")
        print("=" * 60)
        
        for daemon_type, config in DAEMON_CONFIG.items():
            print(f"\n{config['name']}:")
            for key, value in config.items():
                print(f"  {key}: {value}")
        
        print("\n" + "=" * 60)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Manage Service and Job Monitor Daemons',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Start command
    start_parser = subparsers.add_parser('start', help='Start daemon(s)')
    start_parser.add_argument(
        'target',
        choices=['service', 'job', 'all'],
        help='Which daemon to start'
    )
    start_parser.add_argument(
        '--interval',
        type=int,
        help='Override default check interval (seconds)'
    )
    
    # Stop command
    stop_parser = subparsers.add_parser('stop', help='Stop daemon(s)')
    stop_parser.add_argument(
        'target',
        choices=['service', 'job', 'all'],
        help='Which daemon to stop'
    )
    
    # Restart command
    restart_parser = subparsers.add_parser('restart', help='Restart daemon(s)')
    restart_parser.add_argument(
        'target',
        choices=['service', 'job', 'all'],
        help='Which daemon to restart'
    )
    restart_parser.add_argument(
        '--interval',
        type=int,
        help='Override default check interval (seconds)'
    )
    
    # Status command
    subparsers.add_parser('status', help='Show daemon status')
    
    # Logs command
    logs_parser = subparsers.add_parser('logs', help='Show daemon logs')
    logs_parser.add_argument(
        'target',
        choices=['service', 'job'],
        help='Which daemon logs to show'
    )
    logs_parser.add_argument(
        '--lines',
        type=int,
        default=50,
        help='Number of lines to show (default: 50)'
    )
    
    # Config command
    subparsers.add_parser('config', help='Show daemon configuration')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    manager = DaemonManager()
    
    # Execute command
    if args.command == 'start':
        if args.target == 'all':
            manager.start('service', args.interval)
            manager.start('job', args.interval)
        else:
            manager.start(args.target, args.interval)
    
    elif args.command == 'stop':
        if args.target == 'all':
            manager.stop('service')
            manager.stop('job')
        else:
            manager.stop(args.target)
    
    elif args.command == 'restart':
        if args.target == 'all':
            manager.restart('service', args.interval)
            manager.restart('job', args.interval)
        else:
            manager.restart(args.target, args.interval)
    
    elif args.command == 'status':
        manager.status()
    
    elif args.command == 'logs':
        manager.tail_logs(args.target, args.lines)
    
    elif args.command == 'config':
        manager.show_config()


if __name__ == '__main__':
    main()
