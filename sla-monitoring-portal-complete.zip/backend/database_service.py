"""
Database Service Microservice
Handles all database operations with connection pooling and error handling
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
from contextlib import contextmanager
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseService:
    def __init__(self, db_path: str = 'sla_portal.db'):
        self.db_path = db_path
        
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Database error: {e}")
            raise
        finally:
            conn.close()
    
    def dict_factory(self, row):
        """Convert sqlite3.Row to dict"""
        return {key: row[key] for key in row.keys()}
    
    # ===== ORGANIZATION OPERATIONS =====
    
    def get_organization(self, org_id: str) -> Optional[Dict]:
        """Get organization by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM organizations WHERE org_id = ?", (org_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    # ===== USER OPERATIONS =====
    
    def create_user(self, user_data: Dict) -> str:
        """Create new user"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO users (user_id, org_id, email, username, password_hash, role)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_data['user_id'], user_data['org_id'], user_data['email'],
                  user_data['username'], user_data['password_hash'], user_data['role']))
            logger.info(f"Created user: {user_data['email']}")
            return user_data['user_id']
    
    def get_user_by_email(self, email: str) -> Optional[Dict]:
        """Get user by email"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM users WHERE email = ? AND is_active = 1", (email,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_users_by_org(self, org_id: str) -> List[Dict]:
        """Get all users in organization"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM users WHERE org_id = ? AND is_active = 1 ORDER BY created_at DESC",
                (org_id,)
            )
            return [dict(row) for row in cursor.fetchall()]

    # ===== AIT OPERATIONS =====
    
    def create_ait(self, ait_data: Dict) -> str:
        """Create new AIT (Business Unit)"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO aits (ait_id, name, short_name, description, cost_center,
                                 tech_support_contact, status, org_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (ait_data['ait_id'], ait_data['name'], ait_data.get('short_name'),
                  ait_data.get('description'), ait_data.get('cost_center'),
                  ait_data.get('tech_support_contact'), ait_data.get('status', 1),
                  ait_data['org_id']))
            logger.info(f"Created AIT: {ait_data['name']}")
            return ait_data['ait_id']
    
    def get_ait(self, ait_id: str) -> Optional[Dict]:
        """Get AIT by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM aits WHERE ait_id = ?", (ait_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_aits_by_org(self, org_id: str, active_only: bool = True) -> List[Dict]:
        """Get all AITs in organization"""
        with self.get_connection() as conn:
            if active_only:
                cursor = conn.execute(
                    "SELECT * FROM aits WHERE org_id = ? AND status = 1 ORDER BY name",
                    (org_id,)
                )
            else:
                cursor = conn.execute(
                    "SELECT * FROM aits WHERE org_id = ? ORDER BY name",
                    (org_id,)
                )
            return [dict(row) for row in cursor.fetchall()]
    
    def update_ait(self, ait_id: str, updates: Dict) -> bool:
        """Update AIT"""
        update_fields = []
        values = []
        
        for key, value in updates.items():
            if key not in ['ait_id', 'org_id', 'created_at']:
                update_fields.append(f"{key} = ?")
                values.append(value)
        
        if not update_fields:
            return False
        
        update_fields.append("updated_at = ?")
        values.append(datetime.now().isoformat())
        values.append(ait_id)
        
        with self.get_connection() as conn:
            conn.execute(f"""
                UPDATE aits 
                SET {', '.join(update_fields)}
                WHERE ait_id = ?
            """, values)
            logger.info(f"Updated AIT: {ait_id}")
            return True
    
    def delete_ait(self, ait_id: str) -> bool:
        """Soft delete AIT (set status to 0)"""
        with self.get_connection() as conn:
            conn.execute(
                "UPDATE aits SET status = 0, updated_at = ? WHERE ait_id = ?",
                (datetime.now().isoformat(), ait_id)
            )
            logger.info(f"Deleted AIT: {ait_id}")
            return True
    
    def hard_delete_ait(self, ait_id: str) -> bool:
        """Hard delete AIT from database"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM aits WHERE ait_id = ?", (ait_id,))
            logger.info(f"Hard deleted AIT: {ait_id}")
            return True

    # ===== ASSET OPERATIONS (ENHANCED FOR AITS) =====
    
    def create_asset(self, asset_data: Dict) -> str:
        """Create new asset (Application)"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO assets (asset_id, org_id, ait_id, asset_name, asset_type,
                                   asset_owner, description, onboarded_date, status, created_by, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (asset_data['asset_id'], asset_data['org_id'], asset_data['ait_id'],
                  asset_data['asset_name'], asset_data['asset_type'],
                  asset_data.get('asset_owner'), asset_data.get('description'),
                  asset_data.get('onboarded_date', datetime.now().isoformat()),
                  asset_data.get('status', 'active'), asset_data.get('created_by'),
                  json.dumps(asset_data.get('metadata', {}))))
            logger.info(f"Created asset: {asset_data['asset_name']} under AIT: {asset_data['ait_id']}")
            return asset_data['asset_id']
    
    def get_asset(self, asset_id: str) -> Optional[Dict]:
        """Get asset by ID with AIT information"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT a.*, ai.name as ait_name, ai.short_name as ait_short_name
                FROM assets a
                LEFT JOIN aits ai ON a.ait_id = ai.ait_id
                WHERE a.asset_id = ?
            """, (asset_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_assets_by_org(self, org_id: str, active_only: bool = True) -> List[Dict]:
        """Get all assets in organization with AIT information"""
        with self.get_connection() as conn:
            if active_only:
                cursor = conn.execute("""
                    SELECT a.*, ai.name as ait_name, ai.short_name as ait_short_name
                    FROM assets a
                    LEFT JOIN aits ai ON a.ait_id = ai.ait_id
                    WHERE a.org_id = ? AND a.status = 'active'
                    ORDER BY a.asset_name
                """, (org_id,))
            else:
                cursor = conn.execute("""
                    SELECT a.*, ai.name as ait_name, ai.short_name as ait_short_name
                    FROM assets a
                    LEFT JOIN aits ai ON a.ait_id = ai.ait_id
                    WHERE a.org_id = ?
                    ORDER BY a.asset_name
                """, (org_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_assets_by_ait(self, ait_id: str, active_only: bool = True) -> List[Dict]:
        """Get all assets for a specific AIT"""
        with self.get_connection() as conn:
            if active_only:
                cursor = conn.execute("""
                    SELECT * FROM assets 
                    WHERE ait_id = ? AND status = 'active'
                    ORDER BY asset_name
                """, (ait_id,))
            else:
                cursor = conn.execute("""
                    SELECT * FROM assets 
                    WHERE ait_id = ?
                    ORDER BY asset_name
                """, (ait_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def update_asset(self, asset_id: str, updates: Dict) -> bool:
        """Update asset"""
        update_fields = []
        values = []
        
        for key, value in updates.items():
            if key not in ['asset_id', 'org_id', 'created_at']:
                if key == 'metadata' and isinstance(value, dict):
                    value = json.dumps(value)
                update_fields.append(f"{key} = ?")
                values.append(value)
        
        if not update_fields:
            return False
        
        update_fields.append("updated_at = ?")
        values.append(datetime.now().isoformat())
        values.append(asset_id)
        
        with self.get_connection() as conn:
            conn.execute(f"""
                UPDATE assets 
                SET {', '.join(update_fields)}
                WHERE asset_id = ?
            """, values)
            logger.info(f"Updated asset: {asset_id}")
            return True
    
    def delete_asset(self, asset_id: str) -> bool:
        """Soft delete asset"""
        with self.get_connection() as conn:
            conn.execute(
                "UPDATE assets SET status = 'inactive', updated_at = ? WHERE asset_id = ?",
                (datetime.now().isoformat(), asset_id)
            )
            logger.info(f"Deleted asset: {asset_id}")
            return True
    
    def hard_delete_asset(self, asset_id: str) -> bool:
        """Hard delete asset from database"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM assets WHERE asset_id = ?", (asset_id,))
            logger.info(f"Hard deleted asset: {asset_id}")
            return True

    # ===== SERVICE OPERATIONS =====
    
    def create_service(self, service_data: Dict) -> str:
        """Create new service"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO services (service_id, org_id, customer_id, name, description, 
                                      owner_team, asset_id, monitoring_method, deployment_location, 
                                      tags, metadata, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (service_data['service_id'], service_data['org_id'], 
                  service_data.get('customer_id'), service_data['name'],
                  service_data.get('description'), service_data.get('owner_team'),
                  service_data.get('asset_id'),
                  service_data.get('monitoring_method', 'direct'),
                  service_data.get('deployment_location'),
                  json.dumps(service_data.get('tags', [])),
                  json.dumps(service_data.get('metadata', {})),
                  1))  # Explicitly set is_active = 1
            logger.info(f"Created service: {service_data['name']} (monitoring: {service_data.get('monitoring_method', 'direct')}, deployment: {service_data.get('deployment_location', 'N/A')}, execution_time: {service_data.get('execution_time', 'N/A')})")
            return service_data['service_id']
    
    def get_service(self, service_id: str) -> Optional[Dict]:
        """Get service by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM services WHERE service_id = ? AND is_active = 1", (service_id,)
            )
            row = cursor.fetchone()
            if row:
                service = dict(row)
                # Parse JSON fields
                service['tags'] = json.loads(service['tags']) if service['tags'] else []
                service['metadata'] = json.loads(service['metadata']) if service['metadata'] else {}
                return service
            return None
    
    def get_job(self, job_id: str):
        """
        Get job by ID
        
        Args:
            job_id: Job ID
            
        Returns:
            Job dictionary or None
        """
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM jobs WHERE job_id = ?",
                (job_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_services_by_org(self, org_id: str, customer_id: Optional[str] = None) -> List[Dict]:
        """Get all services for organization, optionally filtered by customer"""
        with self.get_connection() as conn:
            if customer_id:
                cursor = conn.execute(
                    "SELECT * FROM services WHERE org_id = ? AND customer_id = ? AND is_active = 1",
                    (org_id, customer_id)
                )
            else:
                cursor = conn.execute(
                    "SELECT * FROM services WHERE org_id = ? AND is_active = 1",
                    (org_id,)
                )
            services = [dict(row) for row in cursor.fetchall()]
            for service in services:
                # Parse JSON fields
                service['tags'] = json.loads(service['tags']) if service['tags'] else []
                service['metadata'] = json.loads(service['metadata']) if service['metadata'] else {}
            return services
    
    def update_service(self, service_id: str, updates: Dict) -> bool:
        """Update service"""
        with self.get_connection() as conn:
            set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
            set_clause += ", updated_at = ?"
            values = list(updates.values()) + [datetime.now().isoformat(), service_id]
            conn.execute(
                f"UPDATE services SET {set_clause} WHERE service_id = ?",
                values
            )
            return True
    
    # ===== SLA OPERATIONS =====
    
    def create_sla(self, sla_data: Dict) -> str:
        """Create new SLA - Updated to support job_id"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO slas (
                    sla_id, org_id, service_id, job_id, customer_id, name, metric_type,
                    target_value, target_unit, priority, business_hours_id,
                    escalation_policy_id, start_condition, stop_condition,
                    effective_from, version, created_by, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                sla_data['sla_id'], 
                sla_data['org_id'], 
                sla_data['service_id'],
                sla_data.get('job_id'),  # ← NEW: Add job_id here (position 4)
                sla_data.get('customer_id'), 
                sla_data['name'], 
                sla_data['metric_type'],
                sla_data['target_value'], 
                sla_data['target_unit'], 
                sla_data.get('priority'),
                sla_data.get('business_hours_id'), 
                sla_data.get('escalation_policy_id'),
                json.dumps(sla_data['start_condition']), 
                json.dumps(sla_data['stop_condition']),
                sla_data['effective_from'], 
                sla_data.get('version', 1),
                sla_data.get('created_by'), 
                json.dumps(sla_data.get('metadata', {}))
            ))
            
            sla_type = "job-level" if sla_data.get('job_id') else "service-level"
            logger.info(f"Created {sla_type} SLA: {sla_data['name']}")
            return sla_data['sla_id']
    
    def get_sla(self, sla_id: str) -> Optional[Dict]:
        """Get SLA by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM slas WHERE sla_id = ?", (sla_id,)
            )
            row = cursor.fetchone()
            if row:
                sla = dict(row)
                
                # Parse JSON fields safely
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                return sla
            return None
    
    def get_slas_by_service(self, service_id: str, active_only: bool = True) -> List[Dict]:
        """Get all SLAs for a service with compliance data"""
        with self.get_connection() as conn:
            query = "SELECT * FROM slas WHERE service_id = ?"
            params = [service_id]
            if active_only:
                query += " AND is_active = 1"
            
            cursor = conn.execute(query, params)
            
            slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Get latest health check for this service
                health_cursor = conn.execute("""
                    SELECT status FROM service_health_checks
                    WHERE service_id = ?
                    ORDER BY checked_at DESC
                    LIMIT 1
                """, (service_id,))
                
                health_row = health_cursor.fetchone()
                
                # Calculate compliance based on health status
                if health_row:
                    if health_row['status'] == 'healthy':
                        sla['current_compliance'] = 99.95
                        sla['service_health_status'] = 'healthy'
                    elif health_row['status'] == 'unhealthy':
                        sla['current_compliance'] = 0.0
                        sla['service_health_status'] = 'unhealthy'
                    else:
                        sla['current_compliance'] = None
                        sla['service_health_status'] = health_row['status']
                else:
                    sla['current_compliance'] = None
                    sla['service_health_status'] = 'unknown'
                
                # Parse JSON fields safely
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                slas.append(sla)
            
            return slas
    
    # ===== EVENT OPERATIONS =====
    
    def create_event(self, event_data: Dict) -> str:
        """Create new event"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO events (
                    event_id, org_id, service_id, customer_id, timestamp,
                    event_type, status, priority, duration, source, payload, normalized_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                event_data['event_id'], event_data['org_id'], event_data['service_id'],
                event_data.get('customer_id'), event_data['timestamp'], event_data['event_type'],
                event_data.get('status'), event_data.get('priority'), event_data.get('duration'),
                event_data.get('source'), json.dumps(event_data['payload']),
                json.dumps(event_data.get('normalized_data', {}))
            ))
            return event_data['event_id']
    
    def get_events(self, org_id: str, filters: Optional[Dict] = None, 
                   limit: int = 100, offset: int = 0) -> List[Dict]:
        """Get events with optional filters"""
        with self.get_connection() as conn:
            query = "SELECT * FROM events WHERE org_id = ?"
            params = [org_id]
            
            if filters:
                if 'service_id' in filters:
                    query += " AND service_id = ?"
                    params.append(filters['service_id'])
                if 'event_type' in filters:
                    query += " AND event_type = ?"
                    params.append(filters['event_type'])
                if 'start_date' in filters:
                    query += " AND timestamp >= ?"
                    params.append(filters['start_date'])
                if 'end_date' in filters:
                    query += " AND timestamp <= ?"
                    params.append(filters['end_date'])
            
            query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            cursor = conn.execute(query, params)
            events = [dict(row) for row in cursor.fetchall()]
            for event in events:
                event['payload'] = json.loads(event['payload'])
                event['normalized_data'] = json.loads(event['normalized_data']) if event['normalized_data'] else {}
            return events
    
    # ===== EVALUATION OPERATIONS =====
    
    def create_evaluation(self, eval_data: Dict) -> str:
        """Create new SLA evaluation"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO evaluations (
                    evaluation_id, org_id, sla_id, event_id, service_id, customer_id,
                    start_timestamp, stop_timestamp, total_duration, business_duration,
                    is_breach, breach_percentage, status, details
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                eval_data['evaluation_id'], eval_data['org_id'], eval_data['sla_id'],
                eval_data.get('event_id'), eval_data['service_id'], eval_data.get('customer_id'),
                eval_data['start_timestamp'], eval_data.get('stop_timestamp'),
                eval_data.get('total_duration'), eval_data.get('business_duration'),
                eval_data.get('is_breach', False), eval_data.get('breach_percentage'),
                eval_data.get('status', 'active'), json.dumps(eval_data.get('details', {}))
            ))
            return eval_data['evaluation_id']
    
    def update_evaluation(self, evaluation_id: str, updates: Dict) -> bool:
        """Update evaluation"""
        with self.get_connection() as conn:
            set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
            set_clause += ", updated_at = ?"
            values = list(updates.values()) + [datetime.now().isoformat(), evaluation_id]
            conn.execute(
                f"UPDATE evaluations SET {set_clause} WHERE evaluation_id = ?",
                values
            )
            return True
    
    def get_evaluations(self, org_id: str, filters: Optional[Dict] = None) -> List[Dict]:
        """Get evaluations with filters"""
        with self.get_connection() as conn:
            query = "SELECT * FROM evaluations WHERE org_id = ?"
            params = [org_id]
            
            if filters:
                if 'sla_id' in filters:
                    query += " AND sla_id = ?"
                    params.append(filters['sla_id'])
                if 'service_id' in filters:
                    query += " AND service_id = ?"
                    params.append(filters['service_id'])
                if 'is_breach' in filters:
                    query += " AND is_breach = ?"
                    params.append(filters['is_breach'])
            
            query += " ORDER BY start_timestamp DESC"
            cursor = conn.execute(query, params)
            evaluations = [dict(row) for row in cursor.fetchall()]
            for evaluation in evaluations:
                evaluation['details'] = json.loads(evaluation['details']) if evaluation['details'] else {}
            return evaluations
    
    # ===== ALERT OPERATIONS =====
    
    def create_alert(self, alert_data: Dict) -> str:
        """Create new alert"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO alerts (
                    alert_id, org_id, evaluation_id, sla_id, service_id,
                    alert_type, severity, message, channels, status, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                alert_data['alert_id'], alert_data['org_id'], alert_data['evaluation_id'],
                alert_data['sla_id'], alert_data['service_id'], alert_data['alert_type'],
                alert_data['severity'], alert_data['message'], json.dumps(alert_data['channels']),
                alert_data.get('status', 'pending'), json.dumps(alert_data.get('metadata', {}))
            ))
            return alert_data['alert_id']
    
    def get_alerts(self, org_id: str, status: Optional[str] = None) -> List[Dict]:
        """Get alerts"""
        with self.get_connection() as conn:
            query = "SELECT * FROM alerts WHERE org_id = ?"
            params = [org_id]
            if status:
                query += " AND status = ?"
                params.append(status)
            query += " ORDER BY created_at DESC"
            cursor = conn.execute(query, params)
            alerts = [dict(row) for row in cursor.fetchall()]
            for alert in alerts:
                # Parse channels
                if alert.get('channels') and isinstance(alert['channels'], str):
                    try:
                        alert['channels'] = json.loads(alert['channels'])
                    except:
                        alert['channels'] = []
                
                # Parse metadata - handle both JSON and string representation
                if alert.get('metadata') and isinstance(alert['metadata'], str):
                    try:
                        # Try parsing as JSON first
                        alert['metadata'] = json.loads(alert['metadata'])
                    except:
                        # If that fails, try eval (for Python dict string representation)
                        try:
                            import ast
                            alert['metadata'] = ast.literal_eval(alert['metadata'])
                        except:
                            # If both fail, just set to empty dict
                            alert['metadata'] = {}
                elif not alert.get('metadata'):
                    alert['metadata'] = {}
            return alerts
    
    # ===== AUDIT LOG OPERATIONS =====
    
    def create_audit_log(self, log_data: Dict) -> str:
        """Create audit log entry"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO audit_logs (
                    log_id, org_id, user_id, action, resource_type, resource_id,
                    ip_address, user_agent, changes, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                log_data['log_id'], log_data['org_id'], log_data.get('user_id'),
                log_data['action'], log_data.get('resource_type'), log_data.get('resource_id'),
                log_data.get('ip_address'), log_data.get('user_agent'),
                json.dumps(log_data.get('changes', {})), json.dumps(log_data.get('metadata', {}))
            ))
            return log_data['log_id']
    
    # ===== METRICS & REPORTING =====
    
    def get_sla_compliance_summary(self, org_id: str, service_id: Optional[str] = None) -> List[Dict]:
        """Get SLA compliance summary"""
        with self.get_connection() as conn:
            query = "SELECT * FROM sla_compliance_summary WHERE org_id = ?"
            params = [org_id]
            if service_id:
                query += " AND service_id = ?"
                params.append(service_id)
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_dashboard_metrics(self, org_id: str, period_days: int = 30) -> Dict:
        """
        Get dashboard metrics for organization
        """
        from datetime import datetime, timedelta
        
        with self.get_connection() as conn:
            cutoff_date = (datetime.now() - timedelta(days=period_days)).isoformat()
            
            try:
                # Total active SLAs (linked to assets)
                slas = conn.execute("""
                    SELECT s.*, a.asset_name
                    FROM slas s
                    LEFT JOIN assets a ON s.asset_id = a.asset_id
                    WHERE s.org_id = ? AND s.is_active = 1
                """, (org_id,)).fetchall()
                
                total_slas = len(slas)
                
            except Exception as e:
                logger.error(f"Error querying SLAs: {e}")
                total_slas = 0
            
            # Total services
            try:
                total_services = conn.execute(
                    "SELECT COUNT(*) as count FROM services WHERE org_id = ? AND is_active = 1",
                    (org_id,)
                ).fetchone()['count']
            except:
                total_services = 0
            
            # Total jobs
            try:
                total_jobs = conn.execute(
                    "SELECT COUNT(*) as count FROM jobs WHERE org_id = ? AND is_active = 1",
                    (org_id,)
                ).fetchone()['count']
            except:
                total_jobs = 0
            
            # Total assets (active)
            try:
                total_assets = conn.execute(
                    "SELECT COUNT(*) as count FROM assets WHERE org_id = ? AND status = 'active'",
                    (org_id,)
                ).fetchone()['count']
            except:
                total_assets = 0
            
            # Active alerts
            try:
                active_alerts = conn.execute(
                    "SELECT COUNT(*) as count FROM alerts WHERE org_id = ? AND status IN ('pending', 'sent')",
                    (org_id,)
                ).fetchone()['count']
            except:
                active_alerts = 0
            
            # Recent evaluations (last period_days)
            try:
                recent_evaluations = conn.execute("""
                    SELECT 
                        COUNT(*) as total_evaluations,
                        SUM(CASE WHEN is_breach = 1 THEN 1 ELSE 0 END) as total_breaches
                    FROM evaluations
                    WHERE org_id = ? AND created_at >= ?
                """, (org_id, cutoff_date)).fetchone()
                
                total_evaluations = recent_evaluations['total_evaluations'] or 0
                total_breaches = recent_evaluations['total_breaches'] or 0
                
                # Calculate compliance rate
                if total_evaluations > 0:
                    compliance_rate = ((total_evaluations - total_breaches) / total_evaluations) * 100
                else:
                    compliance_rate = 100.0
            except:
                total_evaluations = 0
                total_breaches = 0
                compliance_rate = 100.0
            
            return {
                'total_slas': total_slas,
                'total_services': total_services,
                'total_jobs': total_jobs,
                'total_assets': total_assets,
                'active_alerts': active_alerts,
                'total_evaluations': total_evaluations,
                'total_breaches': total_breaches,
                'compliance_rate': round(compliance_rate, 2),
                'period_days': period_days
            }
    
    # ===== HEALTH CHECK OPERATIONS =====
    
    def get_service_health(self, service_id: str) -> Optional[Dict]:
        """Get latest health check for a service"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_health_checks
                WHERE service_id = ?
                ORDER BY checked_at DESC
                LIMIT 1
            """, (service_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_services_with_health(self, org_id: str) -> List[Dict]:
        """Get all services with their latest health status and SLA count"""
        with self.get_connection() as conn:
            # Get services with latest health check and SLA count
            cursor = conn.execute("""
                SELECT 
                    s.*,
                    h.health_check_id,
                    h.status as health_status,
                    h.message as health_message,
                    h.response_time,
                    h.checked_at as health_checked_at,
                    (SELECT COUNT(*) FROM slas WHERE service_id = s.service_id AND is_active = 1) as sla_count
                FROM services s
                LEFT JOIN (
                    SELECT service_id, MAX(checked_at) as max_checked_at
                    FROM service_health_checks
                    GROUP BY service_id
                ) latest ON s.service_id = latest.service_id
                LEFT JOIN service_health_checks h ON s.service_id = h.service_id 
                    AND h.checked_at = latest.max_checked_at
                WHERE s.org_id = ? AND s.is_active = 1
                ORDER BY s.created_at DESC
            """, (org_id,))
            
            services = []
            for row in cursor.fetchall():
                service = dict(row)
                # Parse JSON fields
                service['tags'] = json.loads(service['tags']) if service['tags'] else []
                service['metadata'] = json.loads(service['metadata']) if service['metadata'] else {}
                services.append(service)
            
            return services
    
    # ===== ADDITIONAL SLA OPERATIONS =====
    
    def get_slas_by_org(self, org_id: str) -> List[Dict]:
        """Get all SLAs for an organization with service info and compliance"""
        with self.get_connection() as conn:
            # First get all SLAs with service info
            cursor = conn.execute("""
                SELECT 
                    s.*,
                    a.asset_name as application_name,
                    a.description as application_description
                FROM slas s
                LEFT JOIN assets a ON s.asset_id = a.asset_id
                WHERE s.org_id = ?
                ORDER BY s.created_at DESC
            """, (org_id,))
            
            slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Get latest health check for this service
                health_cursor = conn.execute("""
                    SELECT status FROM service_health_checks
                    WHERE service_id = ?
                    ORDER BY checked_at DESC
                    LIMIT 1
                """, (sla['service_id'],))
                
                health_row = health_cursor.fetchone()
                
                # Calculate compliance based on health status
                if health_row:
                    if health_row['status'] == 'healthy':
                        sla['current_compliance'] = 99.95
                        sla['service_health_status'] = 'healthy'
                    elif health_row['status'] == 'unhealthy':
                        sla['current_compliance'] = 0.0
                        sla['service_health_status'] = 'unhealthy'
                    else:
                        sla['current_compliance'] = None
                        sla['service_health_status'] = health_row['status']
                else:
                    # No health check data
                    sla['current_compliance'] = None
                    sla['service_health_status'] = 'unknown'
                
                # Parse JSON metadata if it exists
                if sla.get('metadata') and isinstance(sla['metadata'], str):
                    try:
                        sla['metadata'] = json.loads(sla['metadata'])
                    except:
                        pass
                
                # Parse JSON fields
                for field in ['start_condition', 'stop_condition']:
                    if sla.get(field) and isinstance(sla[field], str):
                        try:
                            sla[field] = json.loads(sla[field])
                        except:
                            pass
                
                slas.append(sla)
            
            return slas
    
    def update_sla(self, sla_id: str, updates: Dict):
        """Update SLA"""
        if not updates:
            return
        
        # Don't add updated_at - column doesn't exist in table
        # updates['updated_at'] = datetime.now().isoformat()
        
        set_clause = ", ".join([f"{key} = ?" for key in updates.keys()])
        values = list(updates.values()) + [sla_id]
        
        with self.get_connection() as conn:
            conn.execute(
                f"UPDATE slas SET {set_clause} WHERE sla_id = ?",
                values
            )
            logger.info(f"Updated SLA: {sla_id}")
    
    def hard_delete_sla(self, sla_id: str):
        """Permanently delete SLA from database (hard delete)"""
        with self.get_connection() as conn:
            # Delete the SLA permanently
            conn.execute("DELETE FROM slas WHERE sla_id = ?", (sla_id,))
            logger.warning(f"HARD DELETED SLA (permanent): {sla_id}")
    
    def create_business_hours(self, hours_data: Dict) -> str:
        """Create business hours calendar"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO business_hours (
                    business_hours_id, org_id, name, timezone,
                    monday_start, monday_end,
                    tuesday_start, tuesday_end,
                    wednesday_start, wednesday_end,
                    thursday_start, thursday_end,
                    friday_start, friday_end,
                    saturday_start, saturday_end,
                    sunday_start, sunday_end,
                    holidays, blackout_windows
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                hours_data['business_hours_id'],
                hours_data['org_id'],
                hours_data['name'],
                hours_data['timezone'],
                hours_data.get('monday_start'),
                hours_data.get('monday_end'),
                hours_data.get('tuesday_start'),
                hours_data.get('tuesday_end'),
                hours_data.get('wednesday_start'),
                hours_data.get('wednesday_end'),
                hours_data.get('thursday_start'),
                hours_data.get('thursday_end'),
                hours_data.get('friday_start'),
                hours_data.get('friday_end'),
                hours_data.get('saturday_start'),
                hours_data.get('saturday_end'),
                hours_data.get('sunday_start'),
                hours_data.get('sunday_end'),
                hours_data.get('holidays', '[]'),
                hours_data.get('blackout_windows', '[]')
            ))
            logger.info(f"Created business hours: {hours_data['business_hours_id']}")
            return hours_data['business_hours_id']
    
    def create_escalation_policy(self, policy_data: Dict) -> str:
        """Create escalation policy"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO escalation_policies (
                    escalation_policy_id, org_id, name, levels
                ) VALUES (?, ?, ?, ?)
            """, (
                policy_data['escalation_policy_id'],
                policy_data['org_id'],
                policy_data['name'],
                policy_data['levels']
            ))
            logger.info(f"Created escalation policy: {policy_data['escalation_policy_id']}")
            return policy_data['escalation_policy_id']
    
    def get_sla_compliance(self, sla_id: str) -> Optional[Dict]:
        """
        Get current compliance for SLA
        This is a simplified version - in production, this would calculate
        compliance based on recent evaluations and health check data
        """
        # Get the SLA
        sla = self.get_sla(sla_id)
        if not sla:
            return None
        
        # Get service health to calculate compliance
        try:
            service_health = self.get_service_health(sla['service_id'])
            
            # For uptime SLAs, use health check data
            if sla['metric_type'] == 'uptime' and service_health:
                # This is simplified - real implementation would aggregate over time period
                if service_health['status'] == 'healthy':
                    current_value = 99.95  # Placeholder
                elif service_health['status'] == 'unhealthy':
                    current_value = 95.0  # Placeholder
                else:
                    current_value = None
            else:
                # For other metrics, would need different calculation
                current_value = None
            
            return {
                'sla_id': sla_id,
                'current_value': current_value,
                'target_value': sla['target_value'],
                'status': 'compliant' if current_value and current_value >= sla['target_value'] else 'at_risk'
            }
        except Exception as e:
            logger.warning(f"Could not calculate SLA compliance for {sla_id}: {e}")
            return {
                'sla_id': sla_id,
                'current_value': None,
                'target_value': sla['target_value'],
                'status': 'unknown'
            }
    
    def get_sla_evaluations(self, sla_id: str, breached_only: bool = False, limit: int = 100) -> List[Dict]:
        """Get evaluations for SLA"""
        with self.get_connection() as conn:
            query = "SELECT * FROM evaluations WHERE sla_id = ?"
            params = [sla_id]
            
            if breached_only:
                query += " AND is_breach = 1"
            
            query += " ORDER BY start_timestamp DESC LIMIT ?"
            params.append(limit)
            
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    # ============================================================================
    # Job Monitoring Methods
    # ============================================================================
    
    def get_scheduled_jobs_in_window(self, window_start: str, window_end: str) -> List[Dict]:
        """
        Get all scheduled job executions within a time window
        
        Args:
            window_start: Start time (YYYY-MM-DD HH:MM:SS)
            window_end: End time (YYYY-MM-DD HH:MM:SS)
            
        Returns:
            List of scheduled job dictionaries
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_log
                WHERE scheduled_start_time >= ?
                  AND scheduled_start_time < ?
                ORDER BY scheduled_start_time ASC
            """, (window_start, window_end))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_scheduled_jobs_by_service(self, service_id: str, limit: int = 100) -> List[Dict]:
        """
        Get scheduled job executions for a specific service
        
        Args:
            service_id: Service ID
            limit: Maximum number of records to return
            
        Returns:
            List of scheduled job dictionaries
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_log
                WHERE service_id = ?
                ORDER BY scheduled_start_time DESC
                LIMIT ?
            """, (service_id, limit))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_scheduled_jobs_by_date(self, execution_date: str) -> List[Dict]:
        """
        Get all scheduled job executions for a specific date
        
        Args:
            execution_date: Execution date (YYYY-MM-DD)
            
        Returns:
            List of scheduled job dictionaries
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_log
                WHERE scheduled_execution_date = ?
                ORDER BY scheduled_start_time ASC
            """, (execution_date,))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def update_job_execution_status(self, record_id: int, start_time: str = None, 
                                    end_time: str = None, on_time_ind: str = None) -> bool:
        """
        Update job execution status
        
        Args:
            record_id: Monitoring log record ID
            start_time: Actual start time (YYYY-MM-DD HH:MM:SS)
            end_time: Actual end time (YYYY-MM-DD HH:MM:SS)
            on_time_ind: On-time indicator (Met/Unmet/Unknown/In Progress/Failed)
            
        Returns:
            True if successful
        """
        try:
            with self.get_connection() as conn:
                updates = []
                params = []
                
                if start_time:
                    updates.append("start_time = ?")
                    params.append(start_time)
                
                if end_time:
                    updates.append("end_time = ?")
                    params.append(end_time)
                
                if on_time_ind:
                    updates.append("on_time_ind = ?")
                    params.append(on_time_ind)
                
                if not updates:
                    return False
                
                params.append(record_id)
                
                conn.execute(f"""
                    UPDATE service_monitoring_log
                    SET {', '.join(updates)}
                    WHERE id = ?
                """, params)
                
                return True
                
        except Exception as e:
            logger.error(f"Error updating job execution status: {str(e)}")
            return False
    
    def get_job_monitoring_stats(self) -> Dict:
        """
        Get statistics about job monitoring
        
        Returns:
            Dictionary with monitoring statistics
        """
        with self.get_connection() as conn:
            stats = {}
            
            # Total scheduled executions
            cursor = conn.execute("SELECT COUNT(*) FROM service_monitoring_log")
            stats['total_scheduled'] = cursor.fetchone()[0]
            
            # Scheduled for today
            from datetime import datetime
            today = datetime.now().strftime('%Y-%m-%d')
            cursor = conn.execute("""
                SELECT COUNT(*) FROM service_monitoring_log
                WHERE scheduled_execution_date = ?
            """, (today,))
            stats['scheduled_today'] = cursor.fetchone()[0]
            
            # By status
            cursor = conn.execute("""
                SELECT on_time_ind, COUNT(*) 
                FROM service_monitoring_log
                GROUP BY on_time_ind
            """)
            stats['by_status'] = {row[0]: row[1] for row in cursor.fetchall()}
            
            # Unique jobs being monitored
            cursor = conn.execute("""
                SELECT COUNT(DISTINCT service_id) 
                FROM service_monitoring_log
            """)
            stats['unique_jobs'] = cursor.fetchone()[0]
            
            return stats
        
    def get_service_level_slas(self, service_id: str, active_only: bool = True) -> List[Dict]:
        """Get only service-level SLAs (no job_id) - These apply to entire service"""
        with self.get_connection() as conn:
            query = "SELECT * FROM slas WHERE service_id = ? AND job_id IS NULL"
            params = [service_id]
            if active_only:
                query += " AND is_active = 1"
            
            cursor = conn.execute(query, params)
            
            slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Parse JSON fields
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                sla['sla_type'] = 'service'
                slas.append(sla)
            
            return slas

    def get_job_level_slas(self, job_id: str, active_only: bool = True) -> List[Dict]:
        """Get only job-level SLAs (with specific job_id) - These apply to specific job"""
        with self.get_connection() as conn:
            query = "SELECT * FROM slas WHERE job_id = ?"
            params = [job_id]
            if active_only:
                query += " AND is_active = 1"
            
            cursor = conn.execute(query, params)
            
            slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Parse JSON fields
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                sla['sla_type'] = 'job'
                slas.append(sla)
            
            return slas

    def get_all_slas_for_service_and_jobs(self, service_id: str, active_only: bool = True) -> Dict[str, List[Dict]]:
        """
        Get organized SLAs for a service
        Returns dictionary with 'service_level' and 'job_level' SLAs
        """
        service_level_slas = self.get_service_level_slas(service_id, active_only)
        
        # Get all job-level SLAs for this service
        with self.get_connection() as conn:
            query = """
                SELECT s.* FROM slas s
                INNER JOIN jobs j ON s.job_id = j.job_id
                WHERE j.service_id = ? AND s.job_id IS NOT NULL
            """
            params = [service_id]
            if active_only:
                query += " AND s.is_active = 1"
            
            cursor = conn.execute(query, params)
            
            job_level_slas = []
            for row in cursor.fetchall():
                sla = dict(row)
                
                # Parse JSON fields
                if sla.get('start_condition') and isinstance(sla['start_condition'], str):
                    try:
                        sla['start_condition'] = json.loads(sla['start_condition'])
                    except:
                        pass
                
                if sla.get('stop_condition') and isinstance(sla['stop_condition'], str):
                    try:
                        sla['stop_condition'] = json.loads(sla['stop_condition'])
                    except:
                        pass
                
                if sla.get('metadata'):
                    if isinstance(sla['metadata'], str):
                        try:
                            sla['metadata'] = json.loads(sla['metadata'])
                        except:
                            sla['metadata'] = {}
                else:
                    sla['metadata'] = {}
                
                sla['sla_type'] = 'job'
                job_level_slas.append(sla)
        
        return {
            'service_level': service_level_slas,
            'job_level': job_level_slas
        }
    
    def get_field_mappings(self, connector_id):
        """
        Get field mappings for a connector
        
        Args:
            connector_id: ID of the connector
            
        Returns:
            Dictionary mapping target fields to source fields
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT target_field, source_field, transformation_rule, is_required
                FROM field_mappings
                WHERE connector_config_id = ?
                ORDER BY field_order
            """, (connector_id,))
            
            mappings = {}
            for row in cursor.fetchall():
                target_field = row[0]
                source_field = row[1]
                transformation_rule = row[2]
                is_required = bool(row[3])
                
                mappings[target_field] = {
                    'source_field': source_field,
                    'transformation_rule': transformation_rule,
                    'is_required': is_required
                }
            
            return mappings


    def apply_field_mappings(self, data, mappings):
        """
        Apply field mappings to transform source data to target format
        
        Args:
            data: Source data dictionary
            mappings: Field mappings dictionary from get_field_mappings()
            
        Returns:
            Transformed data dictionary
        """
        transformed = {}
        
        for target_field, mapping_info in mappings.items():
            source_field = mapping_info['source_field']
            transformation_rule = mapping_info.get('transformation_rule')
            
            # Get value from source data
            value = data.get(source_field)
            
            # Apply transformation if specified
            if transformation_rule:
                try:
                    # Simple transformations (can be extended)
                    if transformation_rule.startswith('upper:'):
                        value = str(value).upper() if value else value
                    elif transformation_rule.startswith('lower:'):
                        value = str(value).lower() if value else value
                    elif transformation_rule.startswith('default:'):
                        default_value = transformation_rule.split(':', 1)[1]
                        value = value if value else default_value
                except Exception as e:
                    logger.warning(f"Failed to apply transformation '{transformation_rule}': {e}")
            
            transformed[target_field] = value if value is not None else 'N/A'
        
        return transformed


    def create_field_mappings(self, connector_id, mappings):
        """
        Create field mappings for a connector
        
        Args:
            connector_id: ID of the connector
            mappings: Dictionary mapping target fields to source fields
            
        Returns:
            Number of mappings created
        """
        with self.get_connection() as conn:
            field_order = 0
            for target_field, source_field in mappings.items():
                conn.execute("""
                    INSERT INTO field_mappings (
                        connector_config_id, source_field, target_field,
                        is_required, field_order, created_at
                    )
                    VALUES (?, ?, ?, 0, ?, CURRENT_TIMESTAMP)
                """, (connector_id, source_field, target_field, field_order))
                field_order += 1
            
            return len(mappings)


    def update_field_mapping(self, mapping_id, source_field=None, target_field=None, 
                            transformation_rule=None, is_required=None):
        """
        Update a field mapping
        
        Args:
            mapping_id: ID of the field mapping
            source_field: New source field (optional)
            target_field: New target field (optional)
            transformation_rule: New transformation rule (optional)
            is_required: New required status (optional)
        """
        updates = []
        params = []
        
        if source_field is not None:
            updates.append("source_field = ?")
            params.append(source_field)
        
        if target_field is not None:
            updates.append("target_field = ?")
            params.append(target_field)
        
        if transformation_rule is not None:
            updates.append("transformation_rule = ?")
            params.append(transformation_rule)
        
        if is_required is not None:
            updates.append("is_required = ?")
            params.append(1 if is_required else 0)
        
        if not updates:
            return
        
        params.append(mapping_id)
        
        with self.get_connection() as conn:
            conn.execute(f"""
                UPDATE field_mappings
                SET {', '.join(updates)}
                WHERE id = ?
            """, params)


    def delete_field_mapping(self, mapping_id):
        """Delete a field mapping"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM field_mappings WHERE id = ?", (mapping_id,))
    
    # ===== LOG SERVER CONNECTOR OPERATIONS =====
    
    def create_log_connector(self, connector_data: Dict) -> str:
        """Create new log server connector"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO log_server_connectors (
                    connector_id, org_id, connector_name, connector_description,
                    log_server_type, api_endpoint_url, api_credentials,
                    connection_config, is_active, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                connector_data['connector_id'],
                connector_data['org_id'],
                connector_data['connector_name'],
                connector_data.get('connector_description'),
                connector_data['log_server_type'],
                connector_data['api_endpoint_url'],
                connector_data.get('api_credentials'),
                connector_data.get('connection_config'),
                connector_data.get('is_active', 1),
                connector_data.get('created_by')
            ))
            logger.info(f"Created log connector: {connector_data['connector_name']}")
            return connector_data['connector_id']
    
    def get_log_connector(self, connector_id: str) -> Optional[Dict]:
        """Get log connector by ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "SELECT * FROM log_server_connectors WHERE connector_id = ?",
                (connector_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_log_connectors_by_org(self, org_id: str) -> List[Dict]:
        """Get all log connectors for an organization"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                """SELECT * FROM log_server_connectors 
                   WHERE org_id = ? 
                   ORDER BY is_active DESC, connector_name ASC""",
                (org_id,)
            )
            return [dict(row) for row in cursor.fetchall()]
    
    def get_active_log_server_connector(self, org_id: str, log_server_type: str) -> Optional[Dict]:
        """
        Get active log server connector by type
        
        Strategy:
        1. First try: org-specific connector (preferred)
        2. Fallback: any active connector of this type (for shared infrastructure)
        
        This allows connectors to work in both single-org and multi-org setups.
        Most log servers are shared infrastructure, so fallback is appropriate.
        
        Args:
            org_id: Organization ID
            log_server_type: Type of log server (e.g., 'custom', 'splunk', 'elk')
            
        Returns:
            Connector configuration or None
        """
        with self.get_connection() as conn:
            # Strategy 1: Try org-specific connector first
            cursor = conn.execute("""
                SELECT * FROM log_server_connectors
                WHERE org_id = ? AND log_server_type = ? AND is_active = 1
                ORDER BY created_at DESC
                LIMIT 1
            """, (org_id, log_server_type))
            
            row = cursor.fetchone()
            if row:
                logger.debug(f"Found org-specific {log_server_type} connector for org {org_id}")
                return dict(row)
            
            # Strategy 2: Fallback to any active connector (shared infrastructure)
            logger.debug(f"No org-specific connector found, trying shared {log_server_type} connector")
            cursor = conn.execute("""
                SELECT * FROM log_server_connectors
                WHERE log_server_type = ? AND is_active = 1
                ORDER BY created_at DESC
                LIMIT 1
            """, (log_server_type,))
            
            row = cursor.fetchone()
            if row:
                logger.info(f"Using shared {log_server_type} connector (org_id={org_id} fallback)")
                return dict(row)
            
            logger.warning(f"No active {log_server_type} connector found for org {org_id}")
            return None
    
    def update_log_connector(self, connector_id: str, updates: Dict) -> bool:
        """Update log connector"""
        if not updates:
            return False
        
        # Build SET clause dynamically
        set_clauses = []
        params = []
        
        allowed_fields = [
            'connector_name', 'connector_description', 'log_server_type',
            'api_endpoint_url', 'api_credentials', 'connection_config',
            'is_active', 'last_test_time', 'last_test_status',
            'last_test_message', 'updated_by'
        ]
        
        for field in allowed_fields:
            if field in updates:
                set_clauses.append(f"{field} = ?")
                params.append(updates[field])
        
        if not set_clauses:
            return False
        
        # Add updated_at
        set_clauses.append("updated_at = CURRENT_TIMESTAMP")
        params.append(connector_id)
        
        with self.get_connection() as conn:
            conn.execute(
                f"UPDATE log_server_connectors SET {', '.join(set_clauses)} WHERE connector_id = ?",
                params
            )
            logger.info(f"Updated log connector: {connector_id}")
            return True
    
    def delete_log_connector(self, connector_id: str) -> bool:
        """Delete log connector"""
        with self.get_connection() as conn:
            conn.execute(
                "DELETE FROM log_server_connectors WHERE connector_id = ?",
                (connector_id,)
            )
            logger.info(f"Deleted log connector: {connector_id}")
            return True
    
    # ===== SERVICE MONITORING OPERATIONS =====
    
    def get_all_active_services_with_log_monitoring(self) -> List[Dict]:
        """Get all active services with log monitoring configured"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM services
                WHERE is_active = 1
                AND service_identifier IS NOT NULL
                AND log_template IS NOT NULL
                AND log_server_type IS NOT NULL
            """)
            return [dict(row) for row in cursor.fetchall()]
    
    def create_service_monitoring_result(self, result: Dict) -> str:
        """Create service monitoring result"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO service_monitoring_results (
                    result_id, service_id, org_id, check_time, status,
                    response_time_ms, log_entry, parsed_data, is_healthy,
                    error_message, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result['result_id'],
                result['service_id'],
                result['org_id'],
                result.get('check_time'),
                result.get('status'),
                result.get('response_time_ms'),
                result.get('log_entry'),
                result.get('parsed_data'),
                result.get('is_healthy'),
                result.get('error_message'),
                result.get('metadata')
            ))
            return result['result_id']
    
    def get_service_monitoring_results_since(
        self,
        service_id: str,
        since: str,
        limit: int = 1000
    ) -> List[Dict]:
        """Get service monitoring results since a timestamp"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_results
                WHERE service_id = ? AND check_time >= ?
                ORDER BY check_time DESC
                LIMIT ?
            """, (service_id, since, limit))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_latest_service_monitoring_result(self, service_id: str) -> Optional[Dict]:
        """Get the most recent monitoring result for a service"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM service_monitoring_results
                WHERE service_id = ?
                ORDER BY check_time DESC
                LIMIT 1
            """, (service_id,))
            
            row = cursor.fetchone()
            return dict(row) if row else None
    
    # ===== JOB MONITORING OPERATIONS =====
    
    def get_all_active_jobs_with_log_monitoring(self) -> List[Dict]:
        """Get all active jobs with log monitoring configured"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM jobs
                WHERE is_active = 1
                AND job_identifier IS NOT NULL
                AND log_template IS NOT NULL
                AND log_server_type IS NOT NULL
            """)
            return [dict(row) for row in cursor.fetchall()]
    
    def create_job_monitoring_result(self, result: Dict) -> str:
        """Create job monitoring result"""
        with self.get_connection() as conn:
            conn.execute("""
                INSERT INTO job_monitoring_results (
                    result_id, job_id, org_id, check_time, status,
                    execution_start_time, execution_end_time, duration_seconds,
                    records_processed, log_entry, parsed_data,
                    error_message, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result['result_id'],
                result['job_id'],
                result['org_id'],
                result.get('check_time'),
                result.get('status'),
                result.get('execution_start_time'),
                result.get('execution_end_time'),
                result.get('duration_seconds'),
                result.get('records_processed'),
                result.get('log_entry'),
                result.get('parsed_data'),
                result.get('error_message'),
                result.get('metadata')
            ))
            return result['result_id']
    
    def get_job_monitoring_results_since(
        self,
        job_id: str,
        since: str,
        limit: int = 1000
    ) -> List[Dict]:
        """Get job monitoring results since a timestamp"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM job_monitoring_results
                WHERE job_id = ? AND check_time >= ?
                ORDER BY check_time DESC
                LIMIT ?
            """, (job_id, since, limit))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_latest_job_monitoring_result(self, job_id: str) -> Optional[Dict]:
        """Get the most recent monitoring result for a job"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM job_monitoring_results
                WHERE job_id = ?
                ORDER BY check_time DESC
                LIMIT 1
            """, (job_id,))
            
            row = cursor.fetchone()
            return dict(row) if row else None
    
    # ===== SLA OPERATIONS FOR LOG MONITORING =====
    
    def get_slas_by_service(self, service_id: str) -> List[Dict]:
        """Get SLAs for a service"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM slas
                WHERE service_id = ? AND is_active = 1
            """, (service_id,))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_slas_by_job(self, job_id: str) -> List[Dict]:
        """Get SLAs for a job"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM slas
                WHERE job_id = ? AND is_active = 1
            """, (job_id,))
            
            return [dict(row) for row in cursor.fetchall()]
        
    # ===== ENHANCED SLA COMPLIANCE METHODS =====
    def get_sla_type_definitions(self, entity_type=None):
        """
        Get SLA type definitions
        
        Args:
            entity_type: Optional filter by 'service' or 'job'
            
        Returns:
            List of SLA type definitions
        """
        with self.get_connection() as conn:
            if entity_type:
                cursor = conn.execute("""
                    SELECT * FROM sla_type_definitions
                    WHERE entity_type = ?
                    ORDER BY sla_type_name
                """, (entity_type,))
            else:
                cursor = conn.execute("""
                    SELECT * FROM sla_type_definitions
                    ORDER BY entity_type, sla_type_name
                """)
            
            return [dict(row) for row in cursor.fetchall()]


    def get_sla_with_field_mapping(self, sla_id):
        """
        Get SLA with field mapping configuration
        
        Args:
            sla_id: SLA ID
            
        Returns:
            SLA dict with field mapping
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM slas WHERE sla_id = ?
            """, (sla_id,))
            
            row = cursor.fetchone()
            if row:
                sla = dict(row)
                # Parse JSON fields
                if sla.get('log_field_mapping'):
                    try:
                        import json
                        sla['log_field_mapping'] = json.loads(sla['log_field_mapping'])
                    except:
                        pass
                if sla.get('evaluation_config'):
                    try:
                        import json
                        sla['evaluation_config'] = json.loads(sla['evaluation_config'])
                    except:
                        pass
                return sla
            return None


    def update_sla_field_mapping(self, sla_id, log_field_mapping, evaluation_config=None):
        """
        Update SLA field mapping configuration
        
        Args:
            sla_id: SLA ID
            log_field_mapping: Dict mapping SLA fields to log fields
            evaluation_config: Optional evaluation configuration
            
        Returns:
            True if successful
        """
        import json
        
        with self.get_connection() as conn:
            conn.execute("""
                UPDATE slas
                SET log_field_mapping = ?,
                    evaluation_config = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE sla_id = ?
            """, (
                json.dumps(log_field_mapping) if log_field_mapping else None,
                json.dumps(evaluation_config) if evaluation_config else None,
                sla_id
            ))
            return True


    def get_service_sla_compliance(self, service_id, start_date=None, end_date=None, sla_id=None):
        """
        Get SLA compliance records for a service
        
        Args:
            service_id: Service ID
            start_date: Optional start date filter
            end_date: Optional end date filter
            sla_id: Optional specific SLA filter
            
        Returns:
            List of compliance records
        """
        with self.get_connection() as conn:
            query = """
                SELECT 
                    ssc.*,
                    sla.name as sla_name,
                    sla.metric_type as sla_type,
                    smr.check_time
                FROM service_sla_compliance ssc
                JOIN slas sla ON ssc.sla_id = sla.sla_id
                JOIN service_monitoring_results smr ON ssc.result_id = smr.result_id
                WHERE smr.service_id = ?
            """
            
            params = [service_id]
            
            if sla_id:
                query += " AND ssc.sla_id = ?"
                params.append(sla_id)
            
            if start_date:
                query += " AND smr.check_time >= ?"
                params.append(start_date)
            
            if end_date:
                query += " AND smr.check_time <= ?"
                params.append(end_date)
            
            query += " ORDER BY smr.check_time DESC"
            
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]


    def get_job_sla_compliance(self, job_id, start_date=None, end_date=None, sla_id=None):
        """
        Get SLA compliance records for a job
        
        Args:
            job_id: Job ID
            start_date: Optional start date filter
            end_date: Optional end date filter
            sla_id: Optional specific SLA filter
            
        Returns:
            List of compliance records
        """
        with self.get_connection() as conn:
            query = """
                SELECT 
                    jsc.*,
                    sla.name as sla_name,
                    sla.metric_type as sla_type,
                    jmr.check_time
                FROM job_sla_compliance jsc
                JOIN slas sla ON jsc.sla_id = sla.sla_id
                JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
                WHERE jmr.job_id = ?
            """
            
            params = [job_id]
            
            if sla_id:
                query += " AND jsc.sla_id = ?"
                params.append(sla_id)
            
            if start_date:
                query += " AND jmr.check_time >= ?"
                params.append(start_date)
            
            if end_date:
                query += " AND jmr.check_time <= ?"
                params.append(end_date)
            
            query += " ORDER BY jmr.check_time DESC"
            
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]


    def get_sla_compliance_summary(self, sla_id, days=30):
        """
        Get compliance summary for an SLA
        
        Args:
            sla_id: SLA ID
            days: Number of days to include (default 30)
            
        Returns:
            Summary dict with total, passed, failed, compliance percentage
        """
        from datetime import datetime, timedelta
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        with self.get_connection() as conn:
            # Try service SLA compliance
            cursor = conn.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN met_sla = 1 THEN 1 ELSE 0 END) as passed,
                    SUM(CASE WHEN met_sla = 0 THEN 1 ELSE 0 END) as failed
                FROM service_sla_compliance ssc
                JOIN service_monitoring_results smr ON ssc.result_id = smr.result_id
                WHERE ssc.sla_id = ?
                AND smr.check_time >= ?
            """, (sla_id, start_date))
            
            result = cursor.fetchone()
            
            if result and result['total'] > 0:
                return {
                    'total': result['total'],
                    'passed': result['passed'],
                    'failed': result['failed'],
                    'compliance_percentage': round((result['passed'] / result['total']) * 100, 2)
                }
            
            # Try job SLA compliance
            cursor = conn.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN met_sla = 1 THEN 1 ELSE 0 END) as passed,
                    SUM(CASE WHEN met_sla = 0 THEN 1 ELSE 0 END) as failed
                FROM job_sla_compliance jsc
                JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
                WHERE jsc.sla_id = ?
                AND jmr.check_time >= ?
            """, (sla_id, start_date))
            
            result = cursor.fetchone()
            
            if result and result['total'] > 0:
                return {
                    'total': result['total'],
                    'passed': result['passed'],
                    'failed': result['failed'],
                    'compliance_percentage': round((result['passed'] / result['total']) * 100, 2)
                }
            
            return {
                'total': 0,
                'passed': 0,
                'failed': 0,
                'compliance_percentage': 0
            }


    def get_recent_sla_breaches(self, org_id, days=7, limit=50):
        """
        Get recent SLA breaches across all services and jobs
        
        Args:
            org_id: Organization ID
            days: Number of days to look back (default 7)
            limit: Maximum number of breaches to return (default 50)
            
        Returns:
            List of recent breaches
        """
        from datetime import datetime, timedelta
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM v_recent_sla_breaches
                WHERE breach_time >= ?
                LIMIT ?
            """, (start_date, limit))
            
            return [dict(row) for row in cursor.fetchall()]


    def get_sla_status_by_service(self, service_id):
        """
        Get SLA status summary for a service (uses view)
        
        Args:
            service_id: Service ID
            
        Returns:
            List of SLA statuses
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM v_service_sla_status
                WHERE service_id = ?
            """, (service_id,))
            
            return [dict(row) for row in cursor.fetchall()]


    def get_sla_status_by_job(self, job_id):
        """
        Get SLA status summary for a job (uses view)
        
        Args:
            job_id: Job ID
            
        Returns:
            List of SLA statuses
        """
        with self.get_connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM v_job_sla_status
                WHERE job_id = ?
            """, (job_id,))
            
            return [dict(row) for row in cursor.fetchall()] 

    def get_compliance_summary(self, org_id: str, level: str, start_date: str, 
                               end_date: str, parent_id: Optional[str] = None) -> Dict:
        """
        Get overall compliance summary
        Returns: overall_compliance_rate, entities_at_risk, active_breaches
        """
        with self.get_connection() as conn:
            try:
                # Build query based on level
                if level == 'ait':
                    # Overall AIT-level summary
                    query = """
                        WITH ait_compliance AS (
                            SELECT 
                                a.ait_id,
                                a.name as ait_name,
                                COUNT(DISTINCT CASE 
                                    WHEN ssc.met_sla = 1 OR jsc.met_sla = 1 
                                    THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                                END) as compliant_checks,
                                COUNT(DISTINCT CASE 
                                    WHEN ssc.met_sla = 0 OR jsc.met_sla = 0 
                                    THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                                END) as breach_checks,
                                COUNT(DISTINCT COALESCE(ssc.compliance_id, jsc.compliance_id)) as total_checks
                            FROM aits a
                            LEFT JOIN assets ast ON a.ait_id = ast.ait_id
                            LEFT JOIN slas s ON ast.asset_id = s.asset_id
                            LEFT JOIN services srv ON s.sla_id = srv.sla_id
                            LEFT JOIN jobs j ON s.sla_id = j.sla_id
                            LEFT JOIN service_sla_compliance ssc ON s.sla_id = ssc.sla_id 
                                AND ssc.evaluated_at BETWEEN ? AND ?
                            LEFT JOIN job_sla_compliance jsc ON s.sla_id = jsc.sla_id 
                                AND jsc.evaluated_at BETWEEN ? AND ?
                            WHERE a.org_id = ? AND a.status = 1
                            GROUP BY a.ait_id, a.name
                        )
                        SELECT 
                            ROUND(
                                CAST(SUM(compliant_checks) AS FLOAT) / 
                                NULLIF(SUM(total_checks), 0) * 100, 2
                            ) as overall_compliance_rate,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.95 
                                THEN 1 
                            END) as entities_at_risk,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.90 
                                THEN 1 
                            END) as active_breaches
                        FROM ait_compliance
                    """
                    params = (start_date, end_date, start_date, end_date, org_id)
                    
                elif level == 'asset':
                    # Asset-level summary under an AIT
                    query = """
                        WITH asset_compliance AS (
                            SELECT 
                                ast.asset_id,
                                ast.asset_name,
                                COUNT(DISTINCT CASE 
                                    WHEN ssc.met_sla = 1 OR jsc.met_sla = 1 
                                    THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                                END) as compliant_checks,
                                COUNT(DISTINCT CASE 
                                    WHEN ssc.met_sla = 0 OR jsc.met_sla = 0 
                                    THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                                END) as breach_checks,
                                COUNT(DISTINCT COALESCE(ssc.compliance_id, jsc.compliance_id)) as total_checks
                            FROM assets ast
                            LEFT JOIN slas s ON ast.asset_id = s.asset_id
                            LEFT JOIN services srv ON s.sla_id = srv.sla_id
                            LEFT JOIN jobs j ON s.sla_id = j.sla_id
                            LEFT JOIN service_sla_compliance ssc ON s.sla_id = ssc.sla_id 
                                AND ssc.evaluated_at BETWEEN ? AND ?
                            LEFT JOIN job_sla_compliance jsc ON s.sla_id = jsc.sla_id 
                                AND jsc.evaluated_at BETWEEN ? AND ?
                            WHERE ast.org_id = ? 
                                AND ast.status = 'active'
                                AND (? IS NULL OR ast.ait_id = ?)
                            GROUP BY ast.asset_id, ast.asset_name
                        )
                        SELECT 
                            ROUND(
                                CAST(SUM(compliant_checks) AS FLOAT) / 
                                NULLIF(SUM(total_checks), 0) * 100, 2
                            ) as overall_compliance_rate,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.95 
                                THEN 1 
                            END) as entities_at_risk,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.90 
                                THEN 1 
                            END) as active_breaches
                        FROM asset_compliance
                    """
                    params = (start_date, end_date, start_date, end_date, org_id, parent_id, parent_id)
                    
                elif level == 'sla':
                    # SLA-level summary under an asset
                    query = """
                        WITH sla_compliance AS (
                            SELECT 
                                s.sla_id,
                                s.name as sla_name,
                                COUNT(DISTINCT CASE 
                                    WHEN ssc.met_sla = 1 OR jsc.met_sla = 1 
                                    THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                                END) as compliant_checks,
                                COUNT(DISTINCT CASE 
                                    WHEN ssc.met_sla = 0 OR jsc.met_sla = 0 
                                    THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                                END) as breach_checks,
                                COUNT(DISTINCT COALESCE(ssc.compliance_id, jsc.compliance_id)) as total_checks
                            FROM slas s
                            LEFT JOIN services srv ON s.sla_id = srv.sla_id
                            LEFT JOIN jobs j ON s.sla_id = j.sla_id
                            LEFT JOIN service_sla_compliance ssc ON s.sla_id = ssc.sla_id 
                                AND ssc.evaluated_at BETWEEN ? AND ?
                            LEFT JOIN job_sla_compliance jsc ON s.sla_id = jsc.sla_id 
                                AND jsc.evaluated_at BETWEEN ? AND ?
                            WHERE s.org_id = ? 
                                AND s.is_active = 1
                                AND (? IS NULL OR s.asset_id = ?)
                            GROUP BY s.sla_id, s.name
                        )
                        SELECT 
                            ROUND(
                                CAST(SUM(compliant_checks) AS FLOAT) / 
                                NULLIF(SUM(total_checks), 0) * 100, 2
                            ) as overall_compliance_rate,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.95 
                                THEN 1 
                            END) as entities_at_risk,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.90 
                                THEN 1 
                            END) as active_breaches
                        FROM sla_compliance
                    """
                    params = (start_date, end_date, start_date, end_date, org_id, parent_id, parent_id)
                    
                elif level == 'service':
                    # Service-level summary under an SLA
                    query = """
                        WITH service_compliance AS (
                            SELECT 
                                srv.service_id,
                                srv.name as service_name,
                                COUNT(CASE WHEN ssc.met_sla = 1 THEN 1 END) as compliant_checks,
                                COUNT(CASE WHEN ssc.met_sla = 0 THEN 1 END) as breach_checks,
                                COUNT(*) as total_checks
                            FROM services srv
                            LEFT JOIN service_sla_compliance ssc ON srv.sla_id = ssc.sla_id 
                                AND ssc.evaluated_at BETWEEN ? AND ?
                            LEFT JOIN service_monitoring_results smr ON ssc.result_id = smr.result_id
                                AND smr.service_id = srv.service_id
                            WHERE srv.org_id = ? 
                                AND srv.is_active = 1
                                AND (? IS NULL OR srv.sla_id = ?)
                            GROUP BY srv.service_id, srv.name
                        )
                        SELECT 
                            ROUND(
                                CAST(SUM(compliant_checks) AS FLOAT) / 
                                NULLIF(SUM(total_checks), 0) * 100, 2
                            ) as overall_compliance_rate,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.95 
                                THEN 1 
                            END) as entities_at_risk,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.90 
                                THEN 1 
                            END) as active_breaches
                        FROM service_compliance
                    """
                    params = (start_date, end_date, org_id, parent_id, parent_id)
                    
                else:  # job level
                    query = """
                        WITH job_compliance AS (
                            SELECT 
                                j.job_id,
                                j.job_name,
                                COUNT(CASE WHEN jsc.met_sla = 1 THEN 1 END) as compliant_checks,
                                COUNT(CASE WHEN jsc.met_sla = 0 THEN 1 END) as breach_checks,
                                COUNT(*) as total_checks
                            FROM jobs j
                            LEFT JOIN job_sla_compliance jsc ON j.sla_id = jsc.sla_id 
                                AND jsc.evaluated_at BETWEEN ? AND ?
                            LEFT JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
                                AND jmr.job_id = j.job_id
                            WHERE j.org_id = ? 
                                AND j.is_active = 1
                                AND (? IS NULL OR j.sla_id = ?)
                            GROUP BY j.job_id, j.job_name
                        )
                        SELECT 
                            ROUND(
                                CAST(SUM(compliant_checks) AS FLOAT) / 
                                NULLIF(SUM(total_checks), 0) * 100, 2
                            ) as overall_compliance_rate,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.95 
                                THEN 1 
                            END) as entities_at_risk,
                            COUNT(CASE 
                                WHEN CAST(compliant_checks AS FLOAT) / NULLIF(total_checks, 0) < 0.90 
                                THEN 1 
                            END) as active_breaches
                        FROM job_compliance
                    """
                    params = (start_date, end_date, org_id, parent_id, parent_id)
                
                result = conn.execute(query, params).fetchone()
                
                return {
                    'overall_compliance_rate': result['overall_compliance_rate'] or 100.0,
                    'entities_at_risk': result['entities_at_risk'] or 0,
                    'active_breaches': result['active_breaches'] or 0
                }
                
            except Exception as e:
                logger.error(f"Error getting compliance summary: {e}")
                return {
                    'overall_compliance_rate': 0.0,
                    'entities_at_risk': 0,
                    'active_breaches': 0
                }
    
    def get_compliance_by_level(self, org_id: str, level: str, start_date: str, 
                               end_date: str, parent_id: Optional[str] = None,
                               search: str = '') -> List[Dict]:
        """Get detailed compliance data for each entity at the specified level"""
        with self.get_connection() as conn:
            try:
                if level == 'ait':
                    query = """
                        SELECT 
                            a.ait_id as id,
                            a.name,
                            a.short_name,
                            a.description,
                            COUNT(DISTINCT ast.asset_id) as child_count,
                            COUNT(DISTINCT CASE 
                                WHEN ssc.met_sla = 1 OR jsc.met_sla = 1 
                                THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                            END) as compliant_checks,
                            COUNT(DISTINCT CASE 
                                WHEN ssc.met_sla = 0 OR jsc.met_sla = 0 
                                THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                            END) as breach_checks,
                            COUNT(DISTINCT COALESCE(ssc.compliance_id, jsc.compliance_id)) as total_checks
                        FROM aits a
                        LEFT JOIN assets ast ON a.ait_id = ast.ait_id
                        LEFT JOIN slas s ON ast.asset_id = s.asset_id
                        LEFT JOIN services srv ON s.sla_id = srv.sla_id
                        LEFT JOIN jobs j ON s.sla_id = j.sla_id
                        LEFT JOIN service_sla_compliance ssc ON s.sla_id = ssc.sla_id 
                            AND ssc.evaluated_at BETWEEN ? AND ?
                        LEFT JOIN job_sla_compliance jsc ON s.sla_id = jsc.sla_id 
                            AND jsc.evaluated_at BETWEEN ? AND ?
                        WHERE a.org_id = ? AND a.status = 1
                            AND (? = '' OR a.name LIKE '%' || ? || '%')
                        GROUP BY a.ait_id, a.name, a.short_name, a.description
                        ORDER BY a.name
                    """
                    params = (start_date, end_date, start_date, end_date, org_id, search, search)
                    
                elif level == 'asset':
                    query = """
                        SELECT 
                            ast.asset_id as id,
                            ast.asset_name as name,
                            ast.asset_type,
                            ast.ait_id as parent_id,
                            a.name as parent_name,
                            COUNT(DISTINCT s.sla_id) as child_count,
                            COUNT(DISTINCT CASE 
                                WHEN ssc.met_sla = 1 OR jsc.met_sla = 1 
                                THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                            END) as compliant_checks,
                            COUNT(DISTINCT CASE 
                                WHEN ssc.met_sla = 0 OR jsc.met_sla = 0 
                                THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                            END) as breach_checks,
                            COUNT(DISTINCT COALESCE(ssc.compliance_id, jsc.compliance_id)) as total_checks
                        FROM assets ast
                        JOIN aits a ON ast.ait_id = a.ait_id
                        LEFT JOIN slas s ON ast.asset_id = s.asset_id
                        LEFT JOIN services srv ON s.sla_id = srv.sla_id
                        LEFT JOIN jobs j ON s.sla_id = j.sla_id
                        LEFT JOIN service_sla_compliance ssc ON s.sla_id = ssc.sla_id 
                            AND ssc.evaluated_at BETWEEN ? AND ?
                        LEFT JOIN job_sla_compliance jsc ON s.sla_id = jsc.sla_id 
                            AND jsc.evaluated_at BETWEEN ? AND ?
                        WHERE ast.org_id = ? 
                            AND ast.status = 'active'
                            AND (? IS NULL OR ast.ait_id = ?)
                            AND (? = '' OR ast.asset_name LIKE '%' || ? || '%')
                        GROUP BY ast.asset_id, ast.asset_name, ast.asset_type, ast.ait_id, a.name
                        ORDER BY ast.asset_name
                    """
                    params = (start_date, end_date, start_date, end_date, org_id, parent_id, parent_id, search, search)
                    
                elif level == 'sla':
                    query = """
                        SELECT 
                            s.sla_id as id,
                            s.name,
                            s.metric_type,
                            s.target_value,
                            s.target_unit,
                            s.asset_id as parent_id,
                            ast.asset_name as parent_name,
                            COUNT(DISTINCT COALESCE(srv.service_id, j.job_id)) as child_count,
                            COUNT(DISTINCT CASE 
                                WHEN ssc.met_sla = 1 OR jsc.met_sla = 1 
                                THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                            END) as compliant_checks,
                            COUNT(DISTINCT CASE 
                                WHEN ssc.met_sla = 0 OR jsc.met_sla = 0 
                                THEN COALESCE(ssc.compliance_id, jsc.compliance_id)
                            END) as breach_checks,
                            COUNT(DISTINCT COALESCE(ssc.compliance_id, jsc.compliance_id)) as total_checks
                        FROM slas s
                        JOIN assets ast ON s.asset_id = ast.asset_id
                        LEFT JOIN services srv ON s.sla_id = srv.sla_id
                        LEFT JOIN jobs j ON s.sla_id = j.sla_id
                        LEFT JOIN service_sla_compliance ssc ON s.sla_id = ssc.sla_id 
                            AND ssc.evaluated_at BETWEEN ? AND ?
                        LEFT JOIN job_sla_compliance jsc ON s.sla_id = jsc.sla_id 
                            AND jsc.evaluated_at BETWEEN ? AND ?
                        WHERE s.org_id = ? 
                            AND s.is_active = 1
                            AND (? IS NULL OR s.asset_id = ?)
                            AND (? = '' OR s.name LIKE '%' || ? || '%')
                        GROUP BY s.sla_id, s.name, s.metric_type, s.target_value, s.target_unit, s.asset_id, ast.asset_name
                        ORDER BY s.name
                    """
                    params = (start_date, end_date, start_date, end_date, org_id, parent_id, parent_id, search, search)
                    
                elif level == 'service':
                    query = """
                        SELECT 
                            srv.service_id as id,
                            srv.name,
                            srv.service_identifier,
                            srv.sla_id as parent_id,
                            s.name as parent_name,
                            0 as child_count,
                            COUNT(CASE WHEN ssc.met_sla = 1 THEN 1 END) as compliant_checks,
                            COUNT(CASE WHEN ssc.met_sla = 0 THEN 1 END) as breach_checks,
                            COUNT(*) as total_checks
                        FROM services srv
                        JOIN slas s ON srv.sla_id = s.sla_id
                        LEFT JOIN service_sla_compliance ssc ON srv.sla_id = ssc.sla_id 
                            AND ssc.evaluated_at BETWEEN ? AND ?
                        LEFT JOIN service_monitoring_results smr ON ssc.result_id = smr.result_id
                            AND smr.service_id = srv.service_id
                        WHERE srv.org_id = ? 
                            AND srv.is_active = 1
                            AND (? IS NULL OR srv.sla_id = ?)
                            AND (? = '' OR srv.name LIKE '%' || ? || '%')
                        GROUP BY srv.service_id, srv.name, srv.service_identifier, srv.sla_id, s.name
                        ORDER BY srv.name
                    """
                    params = (start_date, end_date, org_id, parent_id, parent_id, search, search)
                    
                else:  # job
                    query = """
                        SELECT 
                            j.job_id as id,
                            j.job_name as name,
                            j.job_identifier,
                            j.job_type,
                            j.sla_id as parent_id,
                            s.name as parent_name,
                            0 as child_count,
                            COUNT(CASE WHEN jsc.met_sla = 1 THEN 1 END) as compliant_checks,
                            COUNT(CASE WHEN jsc.met_sla = 0 THEN 1 END) as breach_checks,
                            COUNT(*) as total_checks
                        FROM jobs j
                        JOIN slas s ON j.sla_id = s.sla_id
                        LEFT JOIN job_sla_compliance jsc ON j.sla_id = jsc.sla_id 
                            AND jsc.evaluated_at BETWEEN ? AND ?
                        LEFT JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
                            AND jmr.job_id = j.job_id
                        WHERE j.org_id = ? 
                            AND j.is_active = 1
                            AND (? IS NULL OR j.sla_id = ?)
                            AND (? = '' OR j.job_name LIKE '%' || ? || '%')
                        GROUP BY j.job_id, j.job_name, j.job_identifier, j.job_type, j.sla_id, s.name
                        ORDER BY j.job_name
                    """
                    params = (start_date, end_date, org_id, parent_id, parent_id, search, search)
                
                results = conn.execute(query, params).fetchall()
                
                # Calculate compliance rate for each entity
                entities = []
                for row in results:
                    row_dict = dict(row)
                    total = row_dict['total_checks'] or 0
                    compliant = row_dict['compliant_checks'] or 0
                    
                    compliance_rate = (compliant / total * 100) if total > 0 else 100.0
                    is_at_risk = compliance_rate < 95.0
                    is_breach = compliance_rate < 90.0
                    
                    entities.append({
                        **row_dict,
                        'compliance_rate': round(compliance_rate, 2),
                        'is_at_risk': is_at_risk,
                        'is_breach': is_breach
                    })
                
                return entities
                
            except Exception as e:
                logger.error(f"Error getting compliance by level: {e}")
                return []
    
    def get_drill_down_data(self, org_id: str, entity_type: str, entity_id: str,
                           start_date: str, end_date: str) -> Dict:
        """Get drill-down data for a specific entity"""
        # Determine child level
        level_map = {
            'ait': 'asset',
            'asset': 'sla',
            'sla': 'service'  # or 'job', we'll get both
        }
        
        child_level = level_map.get(entity_type)
        if not child_level:
            return {'entities': [], 'summary': {}}
        
        # Get children data
        children = self.get_compliance_by_level(
            org_id=org_id,
            level=child_level,
            start_date=start_date,
            end_date=end_date,
            parent_id=entity_id
        )
        
        # If SLA level, also get jobs
        if entity_type == 'sla':
            jobs = self.get_compliance_by_level(
                org_id=org_id,
                level='job',
                start_date=start_date,
                end_date=end_date,
                parent_id=entity_id
            )
            children.extend(jobs)
        
        # Calculate summary
        total_entities = len(children)
        at_risk = sum(1 for c in children if c.get('is_at_risk'))
        breaches = sum(1 for c in children if c.get('is_breach'))
        avg_compliance = sum(c.get('compliance_rate', 0) for c in children) / total_entities if total_entities > 0 else 100.0
        
        return {
            'entities': children,
            'summary': {
                'total_entities': total_entities,
                'entities_at_risk': at_risk,
                'active_breaches': breaches,
                'average_compliance_rate': round(avg_compliance, 2)
            }
        }           