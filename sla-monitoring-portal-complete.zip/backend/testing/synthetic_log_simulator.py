#!/usr/bin/env python3
"""
Synthetic Log Simulator
Generates realistic log data for services and jobs based on their templates
Respects job schedules and simulates various scenarios
"""

import json
import random
import time
from datetime import datetime, timedelta
from croniter import croniter
from typing import Dict, List, Any
import logging
import argparse
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('LogSimulator')


class SyntheticLogSimulator:
    """Generates synthetic logs for services and jobs"""
    
    def __init__(self, services_file: str, jobs_file: str, output_dir: str = '../synthetic_logs'):
        """
        Initialize the simulator
        
        Args:
            services_file: Path to services.json
            jobs_file: Path to jobs.json
            output_dir: Directory to write log files
        """
        self.services_file = services_file
        self.jobs_file = jobs_file
        self.output_dir = output_dir
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Load services and jobs
        self.services = self._load_json(services_file)
        self.jobs = self._load_json(jobs_file)
        
        # Track last execution times for jobs
        self.job_last_execution = {}
        
        logger.info(f"Loaded {len(self.services)} services and {len(self.jobs)} jobs")
    
    def _load_json(self, filepath: str) -> List[Dict]:
        """Load JSON file"""
        with open(filepath, 'r') as f:
            return json.load(f)
    
    def _write_log(self, log_type: str, identifier: str, log_entry: Dict):
        """Write log entry to file"""
        # Create log file per service/job
        log_file = os.path.join(
            self.output_dir,
            f"{log_type}_{identifier}.log"
        )
        
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
    
    def _generate_service_log(self, service: Dict) -> Dict:
        """
        Generate a synthetic log entry for a service
        
        Args:
            service: Service configuration
            
        Returns:
            Log entry dictionary
        """
        template = service.get('log_template', {})
        service_id = service['service_identifier']
        
        # Randomly determine if service is healthy
        is_healthy = random.random() > 0.1  # 90% healthy
        
        # Generate log entry based on template
        log_entry = {
            'identifier': service_id,
            'timestamp': datetime.now().isoformat(),
            'service_name': service['service_name']
        }
        
        # Add template fields with realistic values
        if 'status' in template:
            if is_healthy:
                log_entry['status'] = random.choice(['up', 'running', 'active', 'ok', 'healthy'])
            else:
                log_entry['status'] = random.choice(['down', 'degraded', 'warning', 'error'])
        
        if 'response_time_ms' in template or 'response_time' in template:
            if is_healthy:
                # Normal response time: 50-500ms
                log_entry['response_time_ms'] = random.randint(50, 500)
            else:
                # Degraded: 500-5000ms
                log_entry['response_time_ms'] = random.randint(500, 5000)
        
        if 'cpu_usage' in template:
            log_entry['cpu_usage'] = random.uniform(10, 90)
        
        if 'memory_usage' in template:
            log_entry['memory_usage'] = random.uniform(30, 80)
        
        if 'replication_lag_ms' in template or 'lag' in template:
            if is_healthy:
                log_entry['replication_lag_ms'] = random.randint(0, 100)
            else:
                log_entry['replication_lag_ms'] = random.randint(500, 5000)
        
        if 'sync_status' in template:
            log_entry['sync_status'] = 'synced' if is_healthy else 'lagging'
        
        if 'pipeline_status' in template:
            log_entry['pipeline_status'] = 'running' if is_healthy else 'stalled'
        
        if 'throughput' in template:
            log_entry['throughput'] = random.randint(100, 10000)
        
        if 'test_status' in template:
            log_entry['test_status'] = 'passed' if is_healthy else 'failed'
        
        if 'coverage_pct' in template or 'coverage' in template:
            log_entry['coverage_pct'] = random.uniform(75, 95)
        
        if 'report_status' in template:
            log_entry['report_status'] = 'completed' if is_healthy else 'failed'
        
        if 'records_processed' in template or 'records' in template:
            log_entry['records_processed'] = random.randint(1000, 100000)
        
        if 'message' in template:
            if is_healthy:
                log_entry['message'] = f"{service['service_name']} operating normally"
            else:
                log_entry['message'] = f"{service['service_name']} experiencing issues"
        
        return log_entry
    
    def _generate_job_log(self, job: Dict, execution_time: datetime) -> Dict:
        """
        Generate a synthetic log entry for a job execution
        
        Args:
            job: Job configuration
            execution_time: Scheduled execution time
            
        Returns:
            Log entry dictionary
        """
        template = job.get('log_template', {})
        job_id = job['job_identifier']
        
        # Randomly determine if job succeeds
        is_success = random.random() > 0.05  # 95% success rate
        
        # Generate realistic execution duration
        if is_success:
            # Normal execution: 30 seconds to 30 minutes
            duration_seconds = random.randint(30, 1800)
        else:
            # Failed jobs might be faster (early failure) or timeout
            duration_seconds = random.choice([
                random.randint(5, 60),  # Quick failure
                random.randint(3600, 7200)  # Timeout
            ])
        
        start_time = execution_time
        end_time = start_time + timedelta(seconds=duration_seconds)
        
        # Generate log entry
        log_entry = {
            'identifier': job_id,
            'timestamp': execution_time.isoformat(),
            'job_name': job['job_name']
        }
        
        # Add template fields
        if 'status' in template:
            if is_success:
                log_entry['status'] = random.choice(['success', 'completed', 'done', 'finished', 'ok'])
            else:
                log_entry['status'] = random.choice(['failed', 'error', 'failure', 'exception'])
        
        if 'start_time' in template:
            log_entry['start_time'] = start_time.isoformat()
        
        if 'end_time' in template:
            log_entry['end_time'] = end_time.isoformat()
        
        if 'duration_seconds' in template or 'duration' in template:
            log_entry['duration_seconds'] = duration_seconds
        
        if 'records_processed' in template or 'records' in template:
            if is_success:
                log_entry['records_processed'] = random.randint(1000, 100000)
            else:
                log_entry['records_processed'] = random.randint(0, 1000)
        
        if 'records_failed' in template or 'failed' in template:
            if is_success:
                log_entry['records_failed'] = random.randint(0, 10)
            else:
                log_entry['records_failed'] = random.randint(100, 10000)
        
        if 'rows_synced' in template or 'rows' in template:
            log_entry['rows_synced'] = random.randint(1000, 1000000)
        
        if 'sync_lag_ms' in template or 'lag' in template:
            log_entry['sync_lag_ms'] = random.randint(0, 500)
        
        if 'records_extracted' in template or 'extracted' in template:
            log_entry['records_extracted'] = random.randint(10000, 1000000)
        
        if 'records_transformed' in template or 'transformed' in template:
            log_entry['records_transformed'] = log_entry.get('records_extracted', 10000)
        
        if 'records_loaded' in template or 'loaded' in template:
            log_entry['records_loaded'] = log_entry.get('records_transformed', 10000)
        
        if 'tests_run' in template:
            total_tests = random.randint(100, 1000)
            log_entry['tests_run'] = total_tests
            
            if 'tests_passed' in template:
                if is_success:
                    log_entry['tests_passed'] = total_tests - random.randint(0, 5)
                else:
                    log_entry['tests_passed'] = random.randint(0, total_tests // 2)
            
            if 'tests_failed' in template:
                log_entry['tests_failed'] = total_tests - log_entry.get('tests_passed', 0)
        
        if 'reports_generated' in template or 'reports' in template:
            log_entry['reports_generated'] = random.randint(1, 50)
        
        if 'validation_status' in template or 'validation' in template:
            log_entry['validation_status'] = 'passed' if is_success else 'failed'
        
        if 'message' in template:
            if is_success:
                log_entry['message'] = f"{job['job_name']} completed successfully"
            else:
                log_entry['message'] = f"{job['job_name']} failed with errors"
        
        return log_entry
    
    def _should_job_run(self, job: Dict, current_time: datetime) -> bool:
        """
        Check if job should run based on schedule
        
        Args:
            job: Job configuration
            current_time: Current time
            
        Returns:
            True if job should run
        """
        job_id = job['job_id']
        schedule = job.get('job_schedule')
        
        if not schedule:
            return False
        
        # Initialize last execution if not tracked
        if job_id not in self.job_last_execution:
            # Set to a time in the past to allow first execution
            self.job_last_execution[job_id] = current_time - timedelta(days=1)
        
        last_execution = self.job_last_execution[job_id]
        
        try:
            # Get next scheduled time after last execution
            cron = croniter(schedule, last_execution)
            next_execution = cron.get_next(datetime)
            
            # Job should run if current time is past next execution
            if current_time >= next_execution:
                return True
        except Exception as e:
            logger.error(f"Error parsing cron for job {job_id}: {e}")
        
        return False
    
    def _get_next_job_execution(self, job: Dict, current_time: datetime) -> datetime:
        """Get the exact scheduled execution time for a job"""
        job_id = job['job_id']
        schedule = job.get('job_schedule')
        
        if job_id not in self.job_last_execution:
            self.job_last_execution[job_id] = current_time - timedelta(days=1)
        
        last_execution = self.job_last_execution[job_id]
        
        try:
            cron = croniter(schedule, last_execution)
            return cron.get_next(datetime)
        except Exception as e:
            logger.error(f"Error parsing cron for job {job_id}: {e}")
            return current_time
    
    def generate_service_logs(self):
        """Generate logs for all services"""
        logger.info("Generating service logs...")
        
        for service in self.services:
            log_entry = self._generate_service_log(service)
            self._write_log(
                'service',
                service['service_identifier'],
                log_entry
            )
            logger.debug(f"Generated log for service {service['service_identifier']}")
    
    def generate_job_logs(self, current_time: datetime):
        """Generate logs for jobs that should run"""
        logger.info("Checking job schedules...")
        
        jobs_run = 0
        for job in self.jobs:
            if self._should_job_run(job, current_time):
                # Get exact execution time
                execution_time = self._get_next_job_execution(job, current_time)
                
                # Generate log
                log_entry = self._generate_job_log(job, execution_time)
                self._write_log(
                    'job',
                    job['job_identifier'],
                    log_entry
                )
                
                # Update last execution
                self.job_last_execution[job['job_id']] = execution_time
                
                logger.info(f"Generated log for job {job['job_identifier']} (scheduled: {execution_time})")
                jobs_run += 1
        
        if jobs_run == 0:
            logger.debug("No jobs scheduled to run at this time")
    
    def run_continuous(self, service_interval: int = 60, check_interval: int = 60):
        """
        Run simulator continuously
        
        Args:
            service_interval: Seconds between service log generation
            check_interval: Seconds between job schedule checks
        """
        logger.info(f"Starting continuous simulation...")
        logger.info(f"Service logs every {service_interval}s, job checks every {check_interval}s")
        
        last_service_time = datetime.now()
        
        try:
            while True:
                current_time = datetime.now()
                
                # Generate service logs at interval
                if (current_time - last_service_time).total_seconds() >= service_interval:
                    self.generate_service_logs()
                    last_service_time = current_time
                
                # Check job schedules
                self.generate_job_logs(current_time)
                
                # Sleep for check interval
                time.sleep(check_interval)
                
        except KeyboardInterrupt:
            logger.info("Simulation stopped by user")
    
    def run_once(self):
        """Run simulation once (for testing)"""
        logger.info("Running one-time simulation...")
        
        current_time = datetime.now()
        
        # Generate service logs
        self.generate_service_logs()
        
        # Generate job logs
        self.generate_job_logs(current_time)
        
        logger.info("One-time simulation complete")
    
    def run_backfill(self, days: int = 7):
        """
        Backfill logs for past days
        
        Args:
            days: Number of days to backfill
        """
        logger.info(f"Backfilling logs for past {days} days...")
        
        current_time = datetime.now()
        start_time = current_time - timedelta(days=days)
        
        # Generate service logs (one per day)
        sim_time = start_time
        while sim_time <= current_time:
            logger.info(f"Generating logs for {sim_time.date()}")
            
            # Services (multiple times per day)
            for _ in range(24):  # Hourly
                for service in self.services:
                    log_entry = self._generate_service_log(service)
                    log_entry['timestamp'] = sim_time.isoformat()
                    self._write_log('service', service['service_identifier'], log_entry)
                
                sim_time += timedelta(hours=1)
            
            # Check jobs for this day
            day_start = sim_time.replace(hour=0, minute=0, second=0)
            day_end = day_start + timedelta(days=1)
            
            for job in self.jobs:
                schedule = job.get('job_schedule')
                if not schedule:
                    continue
                
                try:
                    cron = croniter(schedule, day_start)
                    while True:
                        next_time = cron.get_next(datetime)
                        if next_time >= day_end:
                            break
                        
                        log_entry = self._generate_job_log(job, next_time)
                        self._write_log('job', job['job_identifier'], log_entry)
                        logger.debug(f"Backfilled job {job['job_identifier']} at {next_time}")
                except Exception as e:
                    logger.error(f"Error backfilling job {job['job_id']}: {e}")
        
        logger.info(f"Backfill complete! Generated logs from {start_time} to {current_time}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Synthetic Log Simulator')
    parser.add_argument(
        '--services',
        default='services.json',
        help='Path to services.json file'
    )
    parser.add_argument(
        '--jobs',
        default='jobs.json',
        help='Path to jobs.json file'
    )
    parser.add_argument(
        '--output-dir',
        default='synthetic_logs',
        help='Directory for output log files'
    )
    parser.add_argument(
        '--mode',
        choices=['continuous', 'once', 'backfill'],
        default='continuous',
        help='Simulation mode'
    )
    parser.add_argument(
        '--service-interval',
        type=int,
        default=60,
        help='Seconds between service log generation (default: 60)'
    )
    parser.add_argument(
        '--check-interval',
        type=int,
        default=60,
        help='Seconds between job schedule checks (default: 60)'
    )
    parser.add_argument(
        '--backfill-days',
        type=int,
        default=7,
        help='Days to backfill (for backfill mode, default: 7)'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    if args.debug:
        logger.setLevel(logging.DEBUG)
    
    # Create simulator
    simulator = SyntheticLogSimulator(
        services_file=args.services,
        jobs_file=args.jobs,
        output_dir=args.output_dir
    )
    
    # Run based on mode
    if args.mode == 'once':
        simulator.run_once()
    elif args.mode == 'backfill':
        simulator.run_backfill(args.backfill_days)
    else:  # continuous
        simulator.run_continuous(
            service_interval=args.service_interval,
            check_interval=args.check_interval
        )


if __name__ == '__main__':
    main()
