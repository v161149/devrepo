# 🧪 End-to-End Testing Guide - Synthetic Log Simulator

## 📋 **Overview**

This guide shows you how to test your **entire SLA monitoring system** end-to-end without needing real log servers like Splunk!

**What you'll test:**
1. ✅ Synthetic log generation
2. ✅ Service monitoring daemon
3. ✅ Job monitoring daemon
4. ✅ SLA compliance evaluation
5. ✅ Frontend display

---

## 📦 **Files Provided**

| File | Purpose |
|------|---------|
| `synthetic_log_simulator.py` | Generates realistic logs |
| `mock_log_connector.py` | Reads synthetic logs (replaces Splunk/ELK) |
| `services.json` | Your 5 services |
| `jobs.json` | Your 5 jobs |

---

## 🚀 **Quick Start (5 Minutes)**

### **Step 1: Setup** (1 min)

```bash
cd backend

# Copy the testing files
cp /path/to/outputs/enhanced-sla-compliance/testing/synthetic_log_simulator.py .
cp /path/to/outputs/enhanced-sla-compliance/testing/mock_log_connector.py .

# Make sure you have services.json and jobs.json in backend/
# (You already uploaded them!)
```

### **Step 2: Generate Synthetic Logs** (1 min)

```bash
# Generate initial logs
python synthetic_log_simulator.py --mode once

# You should see:
# ✅ Loaded 5 services and 5 jobs
# ✅ Generating service logs...
# ✅ Checking job schedules...
```

**Check output:**
```bash
ls synthetic_logs/
# Should see files like:
# service_HR-SVC-001.log
# service_DB-REPL-002.log
# job_PAYROLL-DAILY-001.log
# etc.
```

### **Step 3: Configure Monitoring to Use Mock Logs** (2 min)

**Option A: Modify log_connector.py** (Quick & Dirty)

Add this at the top of `backend/log_connector.py`:

```python
from mock_log_connector import MockLogConnector

def get_log_connector(config):
    """Get appropriate log connector based on type"""
    # TESTING MODE: Always use mock connector
    return MockLogConnector({
        'log_directory': 'synthetic_logs',
        'server_type': config.get('server_type', 'mock')
    })
    
    # Original code below (commented out for testing)
    # server_type = config.get('server_type')
    # if server_type == 'splunk':
    #     ...
```

**Option B: Update Database Connectors** (Proper Way)

Update your log server connector records in the database:
```sql
UPDATE log_server_connectors
SET connection_config = json_object(
    'log_directory', 'synthetic_logs',
    'server_type', 'mock'
)
WHERE is_active = 1;
```

### **Step 4: Run Monitoring Daemons** (1 min)

```bash
# Terminal 1: Service monitoring
python health_monitoring_service.py

# OR if using daemon:
python service_monitor_daemon.py --once --debug

# Terminal 2: Job monitoring
python job_monitor_daemon.py --once --debug
```

**Expected output:**
```
INFO:ServiceMonitor:Enhanced SLA Evaluator initialized
INFO:ServiceMonitor:Starting service monitoring cycle...
INFO:ServiceMonitor:Found 5 services to monitor
INFO:ServiceMonitor:Monitoring service: HR Data Processing Service (SVC-001)
INFO:ServiceMonitor:Service HR Data Processing Service: status=up, duration=120s
INFO:ServiceMonitor:Service HR Data Processing Service: All 3 SLAs met
```

---

## 📊 **Testing Modes**

### **Mode 1: One-Time Generation**

```bash
python synthetic_log_simulator.py --mode once
```

**Use for:**
- Quick testing
- Debugging
- Verifying setup

### **Mode 2: Continuous Generation**

```bash
python synthetic_log_simulator.py --mode continuous \
    --service-interval 60 \
    --check-interval 60
```

**Use for:**
- Realistic simulation
- Stress testing
- Demo to stakeholders

**What it does:**
- Generates service logs every 60 seconds
- Checks job schedules every 60 seconds
- Runs jobs at their actual scheduled times!

### **Mode 3: Backfill Historical Data**

```bash
python synthetic_log_simulator.py --mode backfill \
    --backfill-days 7
```

**Use for:**
- Generating historical compliance data
- Testing dashboard charts
- Creating demo data

**What it does:**
- Creates logs for past 7 days
- Services: Hourly logs for 7 days = 168 logs per service
- Jobs: Runs at scheduled times for 7 days
- Example: Daily job = 7 executions, Hourly job = 168 executions

---

## 🧪 **Complete Testing Scenario**

### **Day 1: Generate Historical Data**

```bash
# Generate 7 days of history
python synthetic_log_simulator.py --mode backfill --backfill-days 7

# This creates:
# - 168 service logs per service (5 services = 840 logs)
# - Multiple job executions based on schedules:
#   - Daily Payroll (0 2 * * *): 7 executions
#   - Hourly DB Sync (0 * * * *): 168 executions
#   - Nightly ETL (0 1 * * *): 7 executions
#   - Weekly Tests (0 0 * * 0): 1 execution
#   - Monthly Report (0 3 1 * *): 0-1 executions (depends on dates)
```

### **Day 2: Run Monitoring**

```bash
# Run service monitoring
python service_monitor_daemon.py --once --debug

# Run job monitoring
python job_monitor_daemon.py --once --debug
```

**Check database:**
```sql
-- Service monitoring results
SELECT COUNT(*) FROM service_monitoring_results;
-- Should see 5 records (one per service)

-- Service SLA compliance
SELECT COUNT(*) FROM service_sla_compliance;
-- Should see records for each SLA

-- Job monitoring results
SELECT COUNT(*) FROM job_monitoring_results;
-- Should see records for recently completed jobs

-- Job SLA compliance
SELECT COUNT(*) FROM job_sla_compliance;
-- Should see compliance records per job SLA
```

### **Day 3: View in Frontend**

```bash
cd frontend
npm run dev
```

Navigate to:
- `http://localhost:5173/` - Dashboard should show SLA compliance!
- `http://localhost:5173/services/SVC-001` - See service compliance cards
- `http://localhost:5173/jobs/JOB-001` - See job compliance cards

---

## 📈 **Simulating Different Scenarios**

### **Scenario 1: All Services Healthy**

Edit `synthetic_log_simulator.py` line ~97:
```python
# Change from:
is_healthy = random.random() > 0.1  # 90% healthy

# To:
is_healthy = True  # Always healthy
```

### **Scenario 2: Service Degradation**

```python
is_healthy = random.random() > 0.3  # 70% healthy
```

### **Scenario 3: Job Failures**

Edit line ~140:
```python
# Change from:
is_success = random.random() > 0.05  # 95% success

# To:
is_success = random.random() > 0.2  # 80% success
```

### **Scenario 4: SLA Breaches**

Modify response times (line ~110):
```python
# Make response times breach SLA
if is_healthy:
    # Slow response (breach 200ms SLA)
    log_entry['response_time_ms'] = random.randint(500, 2000)
```

---

## 🔍 **Verification Steps**

### **1. Check Generated Logs**

```bash
# View service log
cat synthetic_logs/service_HR-SVC-001.log | jq '.'

# Expected output:
{
  "identifier": "HR-SVC-001",
  "timestamp": "2026-01-05T20:30:00.123456",
  "service_name": "HR Data Processing Service",
  "status": "up",
  "response_time_ms": 150,
  "cpu_usage": 45.2,
  "memory_usage": 62.8,
  "message": "HR Data Processing Service operating normally"
}
```

### **2. Check Job Logs**

```bash
# View job log
cat synthetic_logs/job_PAYROLL-DAILY-001.log | jq '.'

# Expected output:
{
  "identifier": "PAYROLL-DAILY-001",
  "timestamp": "2026-01-05T02:00:00.000000",
  "job_name": "Daily Payroll Processing Job",
  "status": "success",
  "start_time": "2026-01-05T02:00:00.000000",
  "end_time": "2026-01-05T02:15:00.000000",
  "duration_seconds": 900,
  "records_processed": 5000,
  "records_failed": 2,
  "message": "Daily Payroll Processing Job completed successfully"
}
```

### **3. Check Database Tables**

```sql
-- Service monitoring
SELECT 
    s.service_name,
    smr.status,
    smr.response_time_ms,
    smr.check_time
FROM service_monitoring_results smr
JOIN services s ON smr.service_id = s.service_id
ORDER BY smr.check_time DESC
LIMIT 5;

-- Service SLA compliance
SELECT 
    sla.name,
    ssc.met_sla,
    ssc.measured_value,
    ssc.target_value,
    ssc.evaluated_at
FROM service_sla_compliance ssc
JOIN slas sla ON ssc.sla_id = sla.sla_id
ORDER BY ssc.evaluated_at DESC
LIMIT 10;
```

### **4. Check API Endpoints**

```bash
# Test API
curl http://localhost:5000/api/v1/sla-types
curl http://localhost:5000/api/v1/services/SVC-001/sla-status
curl http://localhost:5000/api/v1/sla-compliance/dashboard
```

---

## 🎯 **Complete Test Workflow**

```bash
# === SETUP ===
cd backend

# 1. Generate 7 days of historical data
python synthetic_log_simulator.py --mode backfill --backfill-days 7

# 2. Start continuous log generation
python synthetic_log_simulator.py --mode continuous &

# === RUN MONITORING ===
# 3. Run service monitoring
python service_monitor_daemon.py --once --debug

# 4. Run job monitoring
python job_monitor_daemon.py --once --debug

# === VERIFY ===
# 5. Check database
sqlite3 database/sla_portal.db << EOF
SELECT COUNT(*) as service_compliance FROM service_sla_compliance;
SELECT COUNT(*) as job_compliance FROM job_sla_compliance;
SELECT * FROM v_recent_sla_breaches LIMIT 5;
EOF

# 6. Start API server
python api_service.py &

# 7. Start frontend
cd ../frontend
npm run dev

# === VIEW IN BROWSER ===
# Open http://localhost:5173/
# Navigate to services and jobs to see SLA compliance!
```

---

## 📝 **Troubleshooting**

### **Issue: No logs generated**

**Check:**
```bash
ls synthetic_logs/
python synthetic_log_simulator.py --mode once --debug
```

### **Issue: Monitoring daemon can't find logs**

**Check:**
```python
# In log_connector.py, verify mock connector is used
# Check log_directory path matches where logs are generated
```

### **Issue: No SLA compliance records**

**Check:**
1. SLAs created for services/jobs?
2. Monitoring daemons ran successfully?
3. Check logs for errors:
   ```bash
   grep "ERROR" service_monitor_daemon.log
   grep "SLA" service_monitor_daemon.log
   ```

---

## 🎉 **Success Criteria**

You've successfully tested the system when you see:

✅ **Synthetic logs generated** in `synthetic_logs/`
✅ **Service monitoring runs** without errors
✅ **Job monitoring runs** without errors  
✅ **Database has compliance records**
✅ **API returns SLA data**
✅ **Frontend displays compliance cards**
✅ **SLA breaches highlighted in red**
✅ **Compliance history shows data**

---

## 🚀 **Next Steps**

After successful testing with synthetic logs:

1. **Switch to real log servers** - Update connectors to use actual Splunk/ELK
2. **Configure real SLAs** - Set actual targets based on business needs
3. **Set up alerting** - Configure email/Slack notifications for breaches
4. **Schedule daemons** - Run monitoring continuously in production

---

**You now have a complete testing environment without needing any real log servers!** 🎊
