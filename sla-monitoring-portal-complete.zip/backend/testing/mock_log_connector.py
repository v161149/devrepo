"""
Mock Log Connector for Testing
Reads synthetic logs from file system instead of real log servers
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any


class MockLogConnector:
    """Mock connector that reads from synthetic log files"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize mock connector
        
        Args:
            config: Configuration dictionary with log_directory path
        """
        self.log_directory = config.get('log_directory', 'synthetic_logs')
        self.connector_type = config.get('server_type', 'mock')
    
    def query_logs(self, query: str, time_range_minutes: int = 60) -> List[Dict]:
        """
        Query logs from synthetic log files
        
        Args:
            query: Search query (e.g., "HR-SVC-001" or "PAYROLL-DAILY-001")
            time_range_minutes: Time range to search
            
        Returns:
            List of matching log entries
        """
        # Extract identifier from query
        identifier = self._extract_identifier(query)
        
        if not identifier:
            return []
        
        # Find log files matching identifier
        log_files = self._find_log_files(identifier)
        
        if not log_files:
            return []
        
        # Read logs from files
        logs = []
        cutoff_time = datetime.now() - timedelta(minutes=time_range_minutes)
        
        for log_file in log_files:
            file_logs = self._read_log_file(log_file, cutoff_time)
            logs.extend(file_logs)
        
        # Sort by timestamp descending (most recent first)
        logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        return logs
    
    def _extract_identifier(self, query: str) -> str:
        """Extract identifier from query string"""
        # Handle quoted strings
        if '"' in query:
            parts = query.split('"')
            if len(parts) >= 2:
                return parts[1]
        
        # Handle colon-separated (e.g., identifier:"HR-SVC-001")
        if ':' in query:
            parts = query.split(':')
            if len(parts) >= 2:
                return parts[1].strip('"')
        
        # Otherwise use the whole query
        return query.strip('"')
    
    def _find_log_files(self, identifier: str) -> List[str]:
        """Find log files matching the identifier"""
        if not os.path.exists(self.log_directory):
            return []
        
        matching_files = []
        
        for filename in os.listdir(self.log_directory):
            if not filename.endswith('.log'):
                continue
            
            # Check if identifier is in filename
            if identifier in filename:
                matching_files.append(
                    os.path.join(self.log_directory, filename)
                )
        
        return matching_files
    
    def _read_log_file(self, filepath: str, cutoff_time: datetime) -> List[Dict]:
        """Read log entries from file within time range"""
        logs = []
        
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        log_entry = json.loads(line)
                        
                        # Check timestamp
                        timestamp_str = log_entry.get('timestamp', '')
                        if timestamp_str:
                            try:
                                timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                                
                                # Only include logs within time range
                                if timestamp >= cutoff_time:
                                    logs.append(log_entry)
                            except:
                                # If can't parse timestamp, include the log
                                logs.append(log_entry)
                        else:
                            # No timestamp, include it
                            logs.append(log_entry)
                    
                    except json.JSONDecodeError:
                        continue
        
        except Exception as e:
            print(f"Error reading log file {filepath}: {e}")
        
        return logs
    
    def parse_log_entry(self, log_entry: Dict, template: Dict) -> Dict:
        """
        Parse log entry according to template
        
        Args:
            log_entry: Raw log entry
            template: Log template
            
        Returns:
            Parsed data dictionary
        """
        # For mock logs, the entries are already in the correct format
        # Just ensure all template fields exist
        parsed = {}
        
        for field, template_var in template.items():
            # Get value from log entry (try both the field name and the template variable)
            value = log_entry.get(field)
            
            if value is None:
                # Try to extract from template variable name
                var_name = template_var.replace('{{', '').replace('}}', '').strip()
                value = log_entry.get(var_name)
            
            parsed[field] = value
        
        # Also include any additional fields from log entry
        for key, value in log_entry.items():
            if key not in parsed:
                parsed[key] = value
        
        return parsed
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection to log source"""
        if os.path.exists(self.log_directory):
            log_count = len([f for f in os.listdir(self.log_directory) if f.endswith('.log')])
            return {
                'success': True,
                'message': f'Connected to mock log directory: {self.log_directory}',
                'log_files': log_count
            }
        else:
            return {
                'success': False,
                'message': f'Log directory not found: {self.log_directory}'
            }


def get_mock_log_connector(config: Dict[str, Any]) -> MockLogConnector:
    """Factory function to create mock log connector"""
    return MockLogConnector(config)
