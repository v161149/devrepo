#!/usr/bin/env python3
"""
Service Monitor Daemon - Log-Based Service Monitoring

This daemon:
1. Queries all active services with log monitoring enabled
2. For each service, connects to its configured log server
3. Queries logs using the service's log template
4. Parses log entries and determines service health
5. Stores monitoring results in service_monitoring_results table
6. Runs continuously at configured intervals

Usage:
    python service_monitor_daemon.py [--interval SECONDS] [--once]
    
Options:
    --interval SECONDS  Check interval in seconds (default: 300 = 5 minutes)
    --once              Run once and exit (for testing)
    --debug             Enable debug logging
"""

import sys
import os
import time
import json
import logging
import argparse
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

# Add parent directory to path to import from backend
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database_service import DatabaseService
from log_connector import get_log_connector

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('service_monitor_daemon.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('ServiceMonitor')


class ServiceMonitorDaemon:
    """Daemon to monitor services via log queries"""
    
    def __init__(self, db_service: DatabaseService, check_interval: int = 300):
        """
        Initialize the service monitor daemon
        
        Args:
            db_service: Database service instance
            check_interval: Seconds between monitoring checks (default 5 min)
        """
        self.db = db_service
        self.check_interval = check_interval
        self.running = True
        
    def stop(self):
        """Stop the daemon gracefully"""
        logger.info("Stopping service monitor daemon...")
        self.running = False
        
    def monitor_service(self, service: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Monitor a single service by querying its logs
        
        Args:
            service: Service dictionary with log configuration
            
        Returns:
            Monitoring result dictionary or None if monitoring failed
        """
        service_id = service['service_id']
        service_name = service['service_name']
        org_id = service['org_id']
        
        logger.info(f"Monitoring service: {service_name} ({service_id})")
        
        try:
            # Get log server connector configuration
            log_server_type = service.get('log_server_type')
            if not log_server_type:
                logger.warning(f"Service {service_id} has no log_server_type configured")
                return None
                
            # Get active connector for this log server type
            connector_config = self.db.get_active_log_server_connector(org_id, log_server_type)
            if not connector_config:
                logger.error(f"No active connector found for type: {log_server_type}")
                return self._create_error_result(
                    service,
                    f"No active log connector configured for {log_server_type}"
                )
            
            # Get log connector instance
            log_connector = get_log_connector(connector_config)
            
            # Parse log template
            log_template = service.get('log_template')
            if not log_template:
                logger.warning(f"Service {service_id} has no log_template configured")
                return None
                
            if isinstance(log_template, str):
                log_template = json.loads(log_template)
            
            # Build query to find recent log entries for this service
            service_identifier = service.get('service_identifier')
            if not service_identifier:
                logger.warning(f"Service {service_id} has no service_identifier")
                return None
            
            # Query logs from last check interval (with 10% buffer)
            time_range_minutes = int(self.check_interval / 60 * 1.1)
            
            # Build log query based on template
            query = self._build_service_query(
                service_identifier=service_identifier,
                log_template=log_template,
                time_range_minutes=time_range_minutes
            )
            
            logger.debug(f"Querying logs with: {query}")
            
            # Query the log server
            log_entries = log_connector.query_logs(query, time_range_minutes)
            
            if not log_entries:
                logger.warning(f"No log entries found for service {service_id}")
                return self._create_unknown_result(
                    service,
                    "No log entries found in time range"
                )
            
            # Parse the most recent log entry
            latest_entry = log_entries[0]  # Assuming sorted by timestamp DESC
            parsed_data = log_connector.parse_log_entry(latest_entry, log_template)
            
            # Determine service health based on parsed data
            health_result = self._determine_service_health(parsed_data, service)
            
            # Create monitoring result
            result = {
                'service_id': service_id,
                'org_id': org_id,
                'check_time': datetime.utcnow(),
                'status': health_result['status'],
                'response_time_ms': parsed_data.get('response_time_ms'),
                'log_entry': json.dumps(latest_entry),
                'parsed_data': json.dumps(parsed_data),
                'is_healthy': health_result['is_healthy'],
                'error_message': health_result.get('error_message'),
                'metadata': json.dumps({
                    'entries_found': len(log_entries),
                    'connector_type': log_server_type,
                    'query': query
                })
            }
            
            logger.info(
                f"Service {service_name}: status={result['status']}, "
                f"healthy={result['is_healthy']}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error monitoring service {service_id}: {str(e)}", exc_info=True)
            return self._create_error_result(service, str(e))
    
    def _build_service_query(
        self,
        service_identifier: str,
        log_template: Dict[str, str],
        time_range_minutes: int
    ) -> str:
        """
        Build log query string based on service configuration
        
        Args:
            service_identifier: Unique service identifier in logs
            log_template: Log entry template with field mappings
            time_range_minutes: Time range for query in minutes
            
        Returns:
            Query string for log server
        """
        # For most log systems, search for the service identifier
        # This is a simplified query - actual implementation may vary by log server type
        
        # Get the identifier field from template
        identifier_field = None
        for field, value in log_template.items():
            if '{{service_identifier}}' in str(value) or field == 'identifier':
                identifier_field = field
                break
        
        if identifier_field:
            return f'{identifier_field}:"{service_identifier}"'
        else:
            # Fallback: search in all fields
            return f'"{service_identifier}"'
    
    def _determine_service_health(
        self,
        parsed_data: Dict[str, Any],
        service: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Determine service health from parsed log data
        
        Args:
            parsed_data: Parsed fields from log entry
            service: Service configuration
            
        Returns:
            Dictionary with status, is_healthy, and optional error_message
        """
        # Check if status field exists
        status = parsed_data.get('status', '').lower()
        
        # Map log status to our health status
        if status in ['up', 'running', 'active', 'ok', 'healthy', 'success']:
            return {
                'status': 'up',
                'is_healthy': True
            }
        elif status in ['down', 'stopped', 'failed', 'error', 'critical']:
            return {
                'status': 'down',
                'is_healthy': False,
                'error_message': parsed_data.get('message', 'Service is down')
            }
        elif status in ['degraded', 'warning', 'slow']:
            return {
                'status': 'degraded',
                'is_healthy': False,
                'error_message': parsed_data.get('message', 'Service is degraded')
            }
        else:
            # Unknown status - check for error indicators
            error_msg = parsed_data.get('error_message') or parsed_data.get('message')
            if error_msg and any(word in error_msg.lower() for word in ['error', 'fail', 'exception']):
                return {
                    'status': 'down',
                    'is_healthy': False,
                    'error_message': error_msg
                }
            else:
                return {
                    'status': 'unknown',
                    'is_healthy': False,
                    'error_message': 'Unable to determine status from log entry'
                }
    
    def _create_error_result(self, service: Dict[str, Any], error_msg: str) -> Dict[str, Any]:
        """Create an error monitoring result"""
        return {
            'service_id': service['service_id'],
            'org_id': service['org_id'],
            'check_time': datetime.utcnow(),
            'status': 'unknown',
            'response_time_ms': None,
            'log_entry': None,
            'parsed_data': None,
            'is_healthy': False,
            'error_message': error_msg,
            'metadata': json.dumps({'error': 'monitoring_failed'})
        }
    
    def _create_unknown_result(self, service: Dict[str, Any], reason: str) -> Dict[str, Any]:
        """Create an unknown status monitoring result"""
        return {
            'service_id': service['service_id'],
            'org_id': service['org_id'],
            'check_time': datetime.utcnow(),
            'status': 'unknown',
            'response_time_ms': None,
            'log_entry': None,
            'parsed_data': None,
            'is_healthy': False,
            'error_message': reason,
            'metadata': json.dumps({'reason': 'no_data'})
        }
    
    def monitor_all_services(self):
        """Monitor all active services with log monitoring enabled"""
        logger.info("Starting service monitoring cycle...")
        
        try:
            # Get all active services with log monitoring
            services = self.db.get_all_active_services_with_log_monitoring()
            
            logger.info(f"Found {len(services)} services to monitor")
            
            if not services:
                logger.info("No services configured for log monitoring")
                return
            
            success_count = 0
            error_count = 0
            
            for service in services:
                try:
                    # Monitor the service
                    result = self.monitor_service(service)
                    
                    if result:
                        # Store the result
                        self.db.create_service_monitoring_result(result)
                        success_count += 1
                    else:
                        error_count += 1
                        
                except Exception as e:
                    logger.error(
                        f"Failed to monitor service {service.get('service_id')}: {str(e)}",
                        exc_info=True
                    )
                    error_count += 1
            
            logger.info(
                f"Monitoring cycle complete: {success_count} successful, "
                f"{error_count} errors"
            )
            
        except Exception as e:
            logger.error(f"Error in monitoring cycle: {str(e)}", exc_info=True)
    
    def run(self):
        """Main daemon loop"""
        logger.info(f"Service Monitor Daemon started (interval: {self.check_interval}s)")
        
        while self.running:
            try:
                # Run monitoring cycle
                self.monitor_all_services()
                
                # Wait for next cycle
                logger.info(f"Sleeping for {self.check_interval} seconds...")
                time.sleep(self.check_interval)
                
            except KeyboardInterrupt:
                logger.info("Received interrupt signal")
                break
            except Exception as e:
                logger.error(f"Unexpected error in daemon loop: {str(e)}", exc_info=True)
                # Sleep before retrying to avoid tight error loop
                time.sleep(60)
        
        logger.info("Service Monitor Daemon stopped")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Service Monitor Daemon')
    parser.add_argument(
        '--interval',
        type=int,
        default=300,
        help='Check interval in seconds (default: 300 = 5 minutes)'
    )
    parser.add_argument(
        '--once',
        action='store_true',
        help='Run once and exit (for testing)'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    if args.debug:
        logger.setLevel(logging.DEBUG)
        logging.getLogger('log_connector').setLevel(logging.DEBUG)
    
    # Initialize database service
    db_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'database',
        'sla_portal.db'
    )
    db = DatabaseService(db_path)
    
    # Create daemon
    daemon = ServiceMonitorDaemon(db, args.interval)
    
    try:
        if args.once:
            logger.info("Running in single-shot mode")
            daemon.monitor_all_services()
        else:
            daemon.run()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        daemon.stop()
    finally:
        db.close()


if __name__ == '__main__':
    main()
