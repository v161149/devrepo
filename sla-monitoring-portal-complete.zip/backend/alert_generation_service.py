"""
Alert Generation Service
Monitors SLAs and creates alerts when breaches are detected
"""

import logging
import uuid
from datetime import datetime
from typing import Dict, List

logger = logging.getLogger(__name__)


class AlertGenerationService:
    """Service to generate alerts for SLA breaches"""
    
    def __init__(self, db_service):
        self.db = db_service
    
    def check_and_create_alerts(self, org_id: str):
        """
        Check SLAs and create alerts for breaches
        FIXED: Updated to use asset_id instead of service_id
        """
        with self.db.get_connection() as conn:
            try:
                # Get all active SLAs for this organization
                # FIXED: Join with assets instead of services
                slas = conn.execute("""
                    SELECT s.*, a.asset_name as application_name
                    FROM slas s
                    LEFT JOIN assets a ON s.asset_id = a.asset_id
                    WHERE s.org_id = ? AND s.is_active = 1
                """, (org_id,)).fetchall()
                
                for sla in slas:
                    sla_dict = dict(sla)
                    
                    # Check for recent breaches
                    # Get services linked to this SLA
                    services = conn.execute("""
                        SELECT service_id, name
                        FROM services
                        WHERE sla_id = ? AND is_active = 1
                    """, (sla_dict['sla_id'],)).fetchall()
                    
                    # Get jobs linked to this SLA
                    jobs = conn.execute("""
                        SELECT job_id, job_name
                        FROM jobs
                        WHERE sla_id = ? AND is_active = 1
                    """, (sla_dict['sla_id'],)).fetchall()
                    
                    # Check for breaches in evaluations for services
                    for service in services:
                        self._check_service_breaches(conn, org_id, sla_dict, dict(service))
                    
                    # Check for breaches in job monitoring results
                    for job in jobs:
                        self._check_job_breaches(conn, org_id, sla_dict, dict(job))
                        
            except Exception as e:
                logger.error(f"Error checking for alerts: {e}")

    def _check_service_breaches(self, conn, org_id: str, sla: dict, service: dict):
        """Check for service-related breaches"""
        try:
            # Get recent evaluations with breaches
            breaches = conn.execute("""
                SELECT *
                FROM evaluations
                WHERE org_id = ? 
                AND sla_id = ? 
                AND service_id = ?
                AND is_breach = 1
                AND created_at >= datetime('now', '-1 hour')
                ORDER BY created_at DESC
                LIMIT 1
            """, (org_id, sla['sla_id'], service['service_id'])).fetchall()
            
            for breach in breaches:
                # Check if alert already exists
                existing = conn.execute("""
                    SELECT alert_id
                    FROM alerts
                    WHERE org_id = ? 
                    AND sla_id = ?
                    AND service_id = ?
                    AND created_at >= datetime('now', '-1 hour')
                """, (org_id, sla['sla_id'], service['service_id'])).fetchone()
                
                if not existing:
                    # Create alert
                    alert_id = f"alert-{uuid.uuid4().hex[:12]}"
                    conn.execute("""
                        INSERT INTO alerts (
                            alert_id, org_id, evaluation_id, sla_id, service_id,
                            alert_type, severity, message, channels, status
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        alert_id, org_id, dict(breach)['evaluation_id'], 
                        sla['sla_id'], service['service_id'],
                        'breach', 'high',
                        f"SLA breach detected for {service['name']}",
                        json.dumps(['email']), 'pending'
                    ))
                    logger.info(f"Created alert {alert_id} for SLA breach")
        except Exception as e:
            logger.error(f"Error checking service breaches: {e}")

    def _check_job_breaches(self, conn, org_id: str, sla: dict, job: dict):
        """Check for job-related breaches"""
        try:
            # Get recent job monitoring results with SLA violations
            breaches = conn.execute("""
                SELECT jsc.*
                FROM job_sla_compliance jsc
                JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
                WHERE jsc.org_id = ? 
                AND jsc.sla_id = ?
                AND jmr.job_id = ?
                AND jsc.met_sla = 0
                AND jsc.evaluated_at >= datetime('now', '-1 hour')
                ORDER BY jsc.evaluated_at DESC
                LIMIT 1
            """, (org_id, sla['sla_id'], job['job_id'])).fetchall()
            
            for breach in breaches:
                # Create alert if needed
                # Similar logic to service breaches
                pass
        except Exception as e:
            logger.error(f"Error checking job breaches: {e}")
