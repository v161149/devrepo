#!/usr/bin/env python3
"""
Diagnostic script to verify job monitor setup
Run from backend directory: python check_setup.py
"""

import os
import sys
import sqlite3
import json

def check_files():
    """Check if required files exist"""
    print("=" * 80)
    print("FILE STRUCTURE CHECK")
    print("=" * 80)
    print()
    
    files_to_check = [
        'api_service.py',
        'job_monitor_daemon.py',
        'database_service.py',
        'enhanced_sla_evaluator.py',
        'log_connector.py',
        'log_connector_api.py',
        'sla_portal.db',
        'synthetic_logs/job_DB-SYNC-HOURLY-002.log'
    ]
    
    all_ok = True
    for file in files_to_check:
        exists = os.path.exists(file)
        status = "✅" if exists else "❌"
        print(f"{status} {file}")
        if not exists:
            all_ok = False
    
    return all_ok

def check_database():
    """Check database configuration"""
    print()
    print("=" * 80)
    print("DATABASE CHECK")
    print("=" * 80)
    print()
    
    if not os.path.exists('sla_portal.db'):
        print("❌ sla_portal.db not found")
        return False
    
    try:
        conn = sqlite3.connect('sla_portal.db')
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        # Check job
        print("1. Job Configuration:")
        c.execute("SELECT job_id, job_name, org_id, job_identifier, log_server_type FROM jobs LIMIT 1")
        job = c.fetchone()
        if job:
            print(f"   ✅ Job: {job['job_name']} ({job['job_id']})")
            print(f"      org_id: {job['org_id']}")
            print(f"      job_identifier: {job['job_identifier']}")
            print(f"      log_server_type: {job['log_server_type']}")
        else:
            print("   ❌ No jobs found")
            return False
        
        print()
        
        # Check connector
        print("2. Log Connector Configuration:")
        c.execute("SELECT connector_id, org_id, log_server_type, connection_config FROM log_server_connectors WHERE is_active = 1")
        conn_row = c.fetchone()
        if conn_row:
            print(f"   ✅ Connector: {conn_row['connector_id']}")
            print(f"      org_id: {conn_row['org_id']}")
            print(f"      log_server_type: {conn_row['log_server_type']}")
            print(f"      connection_config: {conn_row['connection_config']}")
            
            # Parse config
            try:
                config = json.loads(conn_row['connection_config'])
                log_dir = config.get('log_directory', '')
                print(f"      log_directory: {log_dir}")
                
                # Check if directory exists
                if os.path.exists(log_dir):
                    print(f"      ✅ Directory exists")
                    files = [f for f in os.listdir(log_dir) if f.endswith('.log')]
                    print(f"      ✅ Found {len(files)} log files")
                else:
                    print(f"      ❌ Directory not found: {log_dir}")
            except json.JSONDecodeError:
                print(f"      ⚠️  Invalid JSON in connection_config")
        else:
            print("   ❌ No active connector found")
            return False
        
        print()
        
        # Check org_id match
        print("3. Org ID Verification:")
        job_org = job['org_id']
        conn_org = conn_row['org_id']
        
        if job_org == conn_org:
            print(f"   ✅ Match: {job_org}")
        else:
            print(f"   ❌ MISMATCH!")
            print(f"      Job org_id: {job_org}")
            print(f"      Connector org_id: {conn_org}")
            return False
        
        print()
        
        # Check SLAs
        print("4. SLA Configuration:")
        c.execute("SELECT sla_id, name, metric_type FROM slas WHERE job_id = ?", (job['job_id'],))
        slas = c.fetchall()
        if slas:
            print(f"   ✅ Found {len(slas)} SLA(s)")
            for sla in slas:
                print(f"      - {sla['name']} ({sla['metric_type']})")
        else:
            print("   ⚠️  No SLAs configured for this job")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Database error: {e}")
        import traceback
        traceback.print_exc()
        return False

def check_log_files():
    """Check log files"""
    print()
    print("=" * 80)
    print("LOG FILES CHECK")
    print("=" * 80)
    print()
    
    log_dir = 'synthetic_logs'
    
    if not os.path.exists(log_dir):
        print(f"❌ Directory not found: {log_dir}")
        return False
    
    print(f"Log directory: {log_dir}")
    
    # List all log files
    log_files = [f for f in os.listdir(log_dir) if f.endswith('.log')]
    
    if not log_files:
        print("❌ No log files found")
        return False
    
    print(f"✅ Found {len(log_files)} log file(s):")
    
    for log_file in log_files:
        log_path = os.path.join(log_dir, log_file)
        size = os.path.getsize(log_path)
        
        # Count lines
        with open(log_path, 'r') as f:
            lines = len(f.readlines())
        
        print(f"   - {log_file}")
        print(f"     Size: {size} bytes, Lines: {lines}")
        
        # Check for job identifier
        if log_file == 'job_DB-SYNC-HOURLY-002.log':
            print(f"     ✅ This is the job we're monitoring!")
    
    return True

def check_methods():
    """Check if required methods exist"""
    print()
    print("=" * 80)
    print("CODE METHODS CHECK")
    print("=" * 80)
    print()
    
    checks = []
    
    # Check database_service.py
    if os.path.exists('database_service.py'):
        with open('database_service.py', 'r') as f:
            content = f.read()
        
        has_get_job = 'def get_job(' in content
        has_get_connector = 'def get_active_log_server_connector(' in content
        no_met_sla = 'records_processed, log_entry, parsed_data, met_sla,' not in content
        
        print("1. database_service.py:")
        print(f"   {'✅' if has_get_job else '❌'} get_job() method")
        print(f"   {'✅' if has_get_connector else '❌'} get_active_log_server_connector() method")
        print(f"   {'✅' if no_met_sla else '❌'} met_sla bug fixed")
        
        checks.append(has_get_job and has_get_connector and no_met_sla)
    else:
        print("❌ database_service.py not found")
        checks.append(False)
    
    print()
    
    # Check enhanced_sla_evaluator.py
    if os.path.exists('enhanced_sla_evaluator.py'):
        with open('enhanced_sla_evaluator.py', 'r') as f:
            content = f.read()
        
        has_method = 'def _create_compliance_result(' in content
        
        print("2. enhanced_sla_evaluator.py:")
        print(f"   {'✅' if has_method else '❌'} _create_compliance_result() method")
        
        checks.append(has_method)
    else:
        print("❌ enhanced_sla_evaluator.py not found")
        checks.append(False)
    
    print()
    
    # Check log_connector_api.py
    if os.path.exists('log_connector_api.py'):
        with open('log_connector_api.py', 'r') as f:
            content = f.read()
        
        has_function = 'def setup_log_connector_routes(' in content
        uses_get_user_org = 'get_user_org()' in content
        no_hardcode = "org_id = '1'  # TODO" not in content
        
        print("3. log_connector_api.py:")
        print(f"   {'✅' if has_function else '❌'} setup_log_connector_routes() function")
        print(f"   {'✅' if uses_get_user_org else '❌'} Uses get_user_org()")
        print(f"   {'✅' if no_hardcode else '❌'} No hardcoded org_id='1'")
        
        checks.append(has_function)
    else:
        print("❌ log_connector_api.py not found")
        checks.append(False)
    
    return all(checks)

def main():
    print()
    print("╔" + "=" * 78 + "╗")
    print("║" + " " * 20 + "JOB MONITOR SETUP DIAGNOSTIC" + " " * 30 + "║")
    print("╚" + "=" * 78 + "╝")
    print()
    
    if not os.path.exists('job_monitor_daemon.py'):
        print("❌ Not in backend directory!")
        print("   Please run from: backend/")
        sys.exit(1)
    
    print("Current directory:", os.getcwd())
    print()
    
    # Run checks
    files_ok = check_files()
    db_ok = check_database()
    logs_ok = check_log_files()
    methods_ok = check_methods()
    
    # Summary
    print()
    print("=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print()
    
    checks = [
        ("File structure", files_ok),
        ("Database config", db_ok),
        ("Log files", logs_ok),
        ("Code methods", methods_ok)
    ]
    
    all_ok = all(result for _, result in checks)
    
    for check, result in checks:
        status = "✅" if result else "❌"
        print(f"{status} {check}")
    
    print()
    
    if all_ok:
        print("╔" + "=" * 78 + "╗")
        print("║" + " " * 25 + "✅ ALL CHECKS PASSED!" + " " * 32 + "║")
        print("╚" + "=" * 78 + "╝")
        print()
        print("You can now run:")
        print("  python job_monitor_daemon.py --once --debug")
        print()
    else:
        print("╔" + "=" * 78 + "╗")
        print("║" + " " * 22 + "⚠️  SOME CHECKS FAILED" + " " * 33 + "║")
        print("╚" + "=" * 78 + "╝")
        print()
        print("Please fix the issues marked with ❌ above")
        print()

if __name__ == "__main__":
    main()
