"""
Log Connector Module
Provides unified interface for querying different log server types
"""

from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json
import requests
import logging

logger = logging.getLogger(__name__)


class LogConnector(ABC):
    """Abstract base class for log server connectors"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize log connector
        
        Args:
            config: Configuration dictionary containing:
                - api_endpoint_url: URL of the log server
                - api_credentials: Authentication credentials (JSON string)
                - connection_config: Additional connection parameters (JSON string)
        """
        self.api_endpoint = config.get('api_endpoint_url')
        
        # Parse credentials
        try:
            credentials_str = config.get('api_credentials', '{}')
            self.credentials = json.loads(credentials_str) if isinstance(credentials_str, str) else credentials_str
        except json.JSONDecodeError:
            logger.error("Failed to parse api_credentials")
            self.credentials = {}
        
        # Parse connection config
        try:
            config_str = config.get('connection_config', '{}')
            self.connection_config = json.loads(config_str) if isinstance(config_str, str) else config_str
        except json.JSONDecodeError:
            logger.error("Failed to parse connection_config")
            self.connection_config = {}
    
    @abstractmethod
    def test_connection(self) -> tuple[bool, str]:
        """
        Test connection to log server
        
        Returns:
            Tuple of (success: bool, message: str)
        """
        pass
    
    @abstractmethod
    def query_logs(
        self, 
        identifier: str, 
        log_template: Dict[str, str],
        time_range: tuple[datetime, datetime],
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Query logs for a specific identifier
        
        Args:
            identifier: Service/Job identifier to search for
            log_template: Template defining expected log structure
            time_range: Tuple of (start_time, end_time)
            max_results: Maximum number of results to return
            
        Returns:
            List of parsed log entries matching the template
        """
        pass
    
    def parse_log_entry(self, raw_log: Dict[str, Any], template: Dict[str, str]) -> Dict[str, Any]:
        """
        Parse raw log entry using template
        
        Args:
            raw_log: Raw log entry from log server
            template: Template defining field mappings
            
        Returns:
            Parsed log entry with template fields mapped
        """
        parsed = {}
        
        for key, placeholder in template.items():
            # Extract field from raw log
            # Placeholder format: {{field_name}}
            field_name = placeholder.replace('{{', '').replace('}}', '')
            
            if field_name in raw_log:
                parsed[key] = raw_log[field_name]
            else:
                parsed[key] = None
        
        return parsed


class SplunkConnector(LogConnector):
    """Splunk log server connector"""
    
    def test_connection(self) -> tuple[bool, str]:
        """Test Splunk connection"""
        try:
            url = f"{self.api_endpoint}/services/server/info"
            auth = (self.credentials.get('username'), self.credentials.get('password'))
            
            response = requests.get(url, auth=auth, verify=False, timeout=10)
            
            if response.status_code == 200:
                return True, "Connection successful"
            else:
                return False, f"Authentication failed: HTTP {response.status_code}"
                
        except requests.exceptions.Timeout:
            return False, "Connection timeout after 10 seconds"
        except requests.exceptions.ConnectionError:
            return False, "Could not connect to Splunk server"
        except Exception as e:
            return False, f"Connection error: {str(e)}"
    
    def query_logs(
        self,
        identifier: str,
        log_template: Dict[str, str],
        time_range: tuple[datetime, datetime],
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """Query Splunk logs (simplified implementation)"""
        try:
            # This is a simplified implementation
            # Production version would use Splunk's search API
            logger.info(f"Querying Splunk for identifier: {identifier}")
            
            # For now, return empty list
            # Full implementation in monitoring daemons will include actual Splunk search
            return []
            
        except Exception as e:
            logger.error(f"Error querying Splunk logs: {e}")
            return []


class ELKConnector(LogConnector):
    """ELK (Elasticsearch) log server connector"""
    
    def test_connection(self) -> tuple[bool, str]:
        """Test ELK connection"""
        try:
            url = f"{self.api_endpoint}/_cluster/health"
            
            # Build auth headers
            headers = {}
            if self.credentials.get('username'):
                import base64
                credentials = f"{self.credentials['username']}:{self.credentials['password']}"
                encoded = base64.b64encode(credentials.encode()).decode()
                headers['Authorization'] = f'Basic {encoded}'
            elif self.credentials.get('api_key'):
                headers['Authorization'] = f"ApiKey {self.credentials['api_key']}"
            
            response = requests.get(url, headers=headers, verify=False, timeout=10)
            
            if response.status_code == 200:
                return True, "Connection successful"
            else:
                return False, f"Connection failed: HTTP {response.status_code}"
                
        except requests.exceptions.Timeout:
            return False, "Connection timeout after 10 seconds"
        except requests.exceptions.ConnectionError:
            return False, "Could not connect to Elasticsearch server"
        except Exception as e:
            return False, f"Connection error: {str(e)}"
    
    def query_logs(
        self,
        identifier: str,
        log_template: Dict[str, str],
        time_range: tuple[datetime, datetime],
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """Query ELK logs (simplified implementation)"""
        try:
            logger.info(f"Querying ELK for identifier: {identifier}")
            # Simplified implementation
            return []
            
        except Exception as e:
            logger.error(f"Error querying ELK logs: {e}")
            return []


class CloudWatchConnector(LogConnector):
    """AWS CloudWatch Logs connector"""
    
    def test_connection(self) -> tuple[bool, str]:
        """Test CloudWatch connection"""
        try:
            # Try to import boto3
            try:
                import boto3
            except ImportError:
                return False, "boto3 library not installed. Install with: pip install boto3"
            
            # Create CloudWatch Logs client
            session = boto3.Session(
                aws_access_key_id=self.credentials.get('access_key_id'),
                aws_secret_access_key=self.credentials.get('secret_access_key'),
                region_name=self.connection_config.get('region', 'us-east-1')
            )
            
            client = session.client('logs')
            
            # Test by listing log groups (limit 1 to keep it fast)
            response = client.describe_log_groups(limit=1)
            
            return True, "Connection successful"
            
        except Exception as e:
            return False, f"Connection error: {str(e)}"
    
    def query_logs(
        self,
        identifier: str,
        log_template: Dict[str, str],
        time_range: tuple[datetime, datetime],
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """Query CloudWatch logs (simplified implementation)"""
        try:
            logger.info(f"Querying CloudWatch for identifier: {identifier}")
            # Simplified implementation
            return []
            
        except Exception as e:
            logger.error(f"Error querying CloudWatch logs: {e}")
            return []


class CustomConnector(LogConnector):
    """Custom HTTP/REST API log server connector"""
    
    def test_connection(self) -> tuple[bool, str]:
        """Test custom API connection"""
        try:
            headers = {}
            if self.credentials.get('api_key'):
                headers['Authorization'] = f"Bearer {self.credentials['api_key']}"
            
            response = requests.get(
                self.api_endpoint,
                headers=headers,
                verify=False,
                timeout=10
            )
            
            if response.status_code in [200, 401, 403]:
                # Even 401/403 means we can reach the server
                return True, "Connection successful"
            else:
                return False, f"Unexpected status: HTTP {response.status_code}"
                
        except requests.exceptions.Timeout:
            return False, "Connection timeout after 10 seconds"
        except requests.exceptions.ConnectionError:
            return False, "Could not connect to server"
        except Exception as e:
            return False, f"Connection error: {str(e)}"
    
    def query_logs(
        self,
        query_or_identifier: str,
        time_range_minutes_or_tuple: Any,
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Query custom API logs or local file system
        
        Flexible signature to support both calling patterns:
        1. query_logs(identifier, time_range_minutes) - from job_monitor_daemon
        2. query_logs(identifier, log_template, time_range, max_results) - from base class
        """
        try:
            # Detect calling pattern
            if isinstance(time_range_minutes_or_tuple, (int, float)):
                # Pattern 1: query_logs(identifier, time_range_minutes)
                identifier = query_or_identifier
                time_range_minutes = time_range_minutes_or_tuple
                
                # Build time range
                end_time = datetime.utcnow()
                start_time = end_time - timedelta(minutes=time_range_minutes)
                time_range = (start_time, end_time)
            else:
                # Pattern 2: query_logs(identifier, log_template, time_range, max_results)
                identifier = query_or_identifier
                time_range = time_range_minutes_or_tuple
            
            # Check if this is a file-based connector (Splunk Simulator)
            log_directory = self.connection_config.get('log_directory')
            server_type = self.connection_config.get('server_type')
            
            if log_directory and server_type in ['mock', 'simulator']:
                # File-based connector - read from local directory
                return self._query_logs_from_files(identifier, time_range, max_results)
            else:
                # HTTP API connector - make REST API call
                return self._query_logs_from_api(identifier, time_range, max_results)
            
        except Exception as e:
            logger.error(f"Error querying logs: {e}")
            return []
    
    def _query_logs_from_files(
        self,
        identifier: str,
        time_range: tuple[datetime, datetime],
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """Read logs from local file system"""
        import os
        import json
        
        log_directory = self.connection_config.get('log_directory', 'synthetic_logs')
        logs = []
        
        try:
            if not os.path.exists(log_directory):
                logger.warning(f"Log directory not found: {log_directory}")
                return []
            
            # Find log files matching the identifier
            log_files = self._find_log_files(log_directory, identifier)
            
            if not log_files:
                logger.warning(f"No log files found for identifier: {identifier}")
                return []
            
            # Read logs from files
            for log_file in log_files:
                file_logs = self._read_log_file(log_file, time_range)
                logs.extend(file_logs)
                
                if len(logs) >= max_results:
                    break
            
            # Sort by timestamp (descending - most recent first)
            logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
            logs = logs[:max_results]
            
            logger.info(f"Fetched {len(logs)} logs for {identifier} from files")
            return logs
            
        except Exception as e:
            logger.error(f"Error reading logs from files: {e}")
            return []
    
    def _find_log_files(self, log_directory: str, identifier: str) -> List[str]:
        """Find log files matching the identifier"""
        import os
        
        log_files = []
        
        try:
            # Look for files containing the identifier
            for filename in os.listdir(log_directory):
                if identifier in filename and filename.endswith('.log'):
                    log_files.append(os.path.join(log_directory, filename))
            
            # Also try standard naming patterns
            patterns = [
                f"service_{identifier}.log",
                f"job_{identifier}.log",
                f"{identifier}.log"
            ]
            
            for pattern in patterns:
                log_path = os.path.join(log_directory, pattern)
                if os.path.exists(log_path) and log_path not in log_files:
                    log_files.append(log_path)
            
            return log_files
            
        except Exception as e:
            logger.error(f"Error finding log files: {e}")
            return []
    
    def _read_log_file(
        self,
        log_file: str,
        time_range: tuple[datetime, datetime]
    ) -> List[Dict[str, Any]]:
        """Read and parse a log file"""
        import json
        
        logs = []
        start_time, end_time = time_range
        
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        log_entry = json.loads(line)
                        
                        # Apply time filters
                        log_time = self._parse_timestamp(log_entry.get('timestamp'))
                        if log_time:
                            if log_time < start_time or log_time > end_time:
                                continue
                        
                        logs.append(log_entry)
                        
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse log line: {line[:100]}")
                        continue
            
            return logs
            
        except Exception as e:
            logger.error(f"Error reading log file {log_file}: {e}")
            return []
    
    def _parse_timestamp(self, timestamp_str: str) -> Optional[datetime]:
        """Parse timestamp from log entry"""
        if not timestamp_str:
            return None
        
        try:
            # Try ISO format
            return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        except:
            try:
                # Try other common formats
                return datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
            except:
                return None
    
    def _query_logs_from_api(
        self,
        identifier: str,
        time_range: tuple[datetime, datetime],
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """Query logs from HTTP API"""
        try:
            logger.info(f"Querying custom API for identifier: {identifier}")
            # TODO: Implement actual API query
            # This would make HTTP requests to the custom log server
            return []
            
        except Exception as e:
            logger.error(f"Error querying custom API logs: {e}")
            return []


def get_log_connector(connector_config: Dict[str, Any]) -> LogConnector:
    """
    Factory function to create appropriate log connector
    
    Args:
        connector_config: Log server connector configuration from database
        
    Returns:
        LogConnector instance
    """
    log_server_type = connector_config.get('log_server_type')
    
    connector_map = {
        'splunk': SplunkConnector,
        'elk': ELKConnector,
        'cloudwatch': CloudWatchConnector,
        'stackdriver': CustomConnector,  # Can be specialized later
        'datadog_logs': CustomConnector,  # Can be specialized later
        'azure_monitor': CustomConnector,  # Can be specialized later
        'custom': CustomConnector
    }
    
    connector_class = connector_map.get(log_server_type, CustomConnector)
    return connector_class(connector_config)
