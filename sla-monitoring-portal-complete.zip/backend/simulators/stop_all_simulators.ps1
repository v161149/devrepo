# Stop All Simulators - Windows PowerShell Version
# Stops all running simulator processes

Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Stopping SLA Portal Simulators" -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptPath

# Try to read PIDs from file
$PidsFile = "simulator_pids.txt"

if (Test-Path $PidsFile) {
    Write-Host "Reading process IDs from $PidsFile..." -ForegroundColor Yellow
    $PidString = Get-Content $PidsFile
    $Pids = $PidString -split ','
    
    Write-Host "Found PIDs: $($Pids -join ', ')" -ForegroundColor White
    Write-Host ""
    
    $StoppedCount = 0
    foreach ($ProcessId in $Pids) {
        $ProcessId = $ProcessId.Trim()
        if ($ProcessId -match '^\d+$') {
            try {
                $Process = Get-Process -Id $ProcessId -ErrorAction Stop
                Write-Host "Stopping process $ProcessId ($($Process.Name))..." -ForegroundColor Yellow
                Stop-Process -Id $ProcessId -Force
                Write-Host "  * Process $ProcessId stopped" -ForegroundColor Green
                $StoppedCount++
            }
            catch {
                Write-Host "  * Process $ProcessId not found (may have already stopped)" -ForegroundColor DarkYellow
            }
        }
    }
    
    # Remove PID file
    Remove-Item $PidsFile -ErrorAction SilentlyContinue
    Write-Host ""
    Write-Host "* Stopped $StoppedCount simulator(s)" -ForegroundColor Green
}
else {
    Write-Host "* PID file not found. Searching for Python processes..." -ForegroundColor Yellow
    Write-Host ""
    
    # Find Python processes
    $PythonProcesses = Get-Process -Name python -ErrorAction SilentlyContinue
    
    if ($PythonProcesses) {
        Write-Host "Found $($PythonProcesses.Count) Python process(es):" -ForegroundColor White
        foreach ($Process in $PythonProcesses) {
            Write-Host "  * PID $($Process.Id): $($Process.Name)" -ForegroundColor White
        }
        Write-Host ""
        
        $Confirm = Read-Host "Stop all Python processes? (y/n)"
        if ($Confirm -eq 'y' -or $Confirm -eq 'Y') {
            foreach ($Process in $PythonProcesses) {
                Write-Host "Stopping process $($Process.Id)..." -ForegroundColor Yellow
                Stop-Process -Id $Process.Id -Force
                Write-Host "  * Process stopped" -ForegroundColor Green
            }
        }
        else {
            Write-Host "* Cancelled" -ForegroundColor Red
            exit
        }
    }
    else {
        Write-Host "* No Python processes found" -ForegroundColor DarkYellow
        Write-Host ""
        Write-Host "To manually stop by port:" -ForegroundColor Yellow
        Write-Host "  1. Find processes using ports:" -ForegroundColor White
        Write-Host "     netstat -ano | findstr `":5001`"" -ForegroundColor Gray
        Write-Host "     netstat -ano | findstr `":5002`"" -ForegroundColor Gray
        Write-Host "     netstat -ano | findstr `":5003`"" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  2. Stop process by ID:" -ForegroundColor White
        Write-Host "     Stop-Process -Id PROCESS_ID -Force" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "Done!" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""