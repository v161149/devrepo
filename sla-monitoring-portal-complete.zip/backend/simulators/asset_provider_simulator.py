"""
Asset Metadata Provider Simulator
Simulates generic asset management API for testing
Port: 5003
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config/assets.json')

def load_assets():
    """Load dummy assets from config file"""
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'asset_provider_simulator',
        'version': '1.0'
    })

@app.route('/api/assets', methods=['GET'])
def get_assets():
    """
    Get all assets with optional filters
    
    Query Parameters:
    - asset_type: Filter by type (server, database, cloud)
    - environment: Filter by environment (production, staging, dev)
    - datacenter: Filter by datacenter
    """
    assets = load_assets()
    
    # Apply filters
    asset_type = request.args.get('asset_type')
    environment = request.args.get('environment')
    datacenter = request.args.get('datacenter')
    
    if asset_type:
        assets = [a for a in assets if a.get('machine_type', '').lower() == asset_type.lower()]
    if environment:
        assets = [a for a in assets if a.get('environment') == environment]
    if datacenter:
        assets = [a for a in assets if a.get('datacenter') == datacenter]
    
    return jsonify({
        'assets': assets,
        'total': len(assets),
        'timestamp': '2025-12-18T10:00:00Z'
    })

@app.route('/api/assets/<asset_id>', methods=['GET'])
def get_asset(asset_id):
    """Get specific asset by ID"""
    assets = load_assets()
    asset = next((a for a in assets if a['asset_id'] == asset_id), None)
    
    if asset:
        return jsonify(asset)
    return jsonify({'error': 'Asset not found'}), 404

if __name__ == '__main__':
    print("=" * 60)
    print("Asset Provider Simulator Starting...")
    print("=" * 60)
    print(f"Endpoint: http://localhost:5003")
    print(f"Health Check: http://localhost:5003/api/health")
    print(f"Get Assets: http://localhost:5003/api/assets")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5003, debug=True)