"""
Ansible Tower Platform Simulator
Simulates Ansible Tower REST API for testing
Port: 5002
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config/ansible_templates.json')

def load_templates():
    """Load dummy job templates from config file"""
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

@app.route('/api/v2/ping/', methods=['GET'])
def ping():
    """Ping endpoint"""
    return jsonify({
        'status': 'ok',
        'platform': 'ansible_tower_simulator',
        'version': '3.8.0'
    })

@app.route('/api/v2/job_templates/', methods=['GET'])
def get_job_templates():
    """
    Get all job templates with optional filters
    
    Query Parameters:
    - project: Filter by project name
    - name: Filter by template name
    """
    templates = load_templates()
    
    # Apply filters
    project = request.args.get('project')
    name_filter = request.args.get('name')
    
    if project:
        templates = [t for t in templates if t.get('project_name') == project]
    if name_filter:
        templates = [t for t in templates if name_filter.lower() in t.get('name', '').lower()]
    
    return jsonify({
        'results': templates,
        'count': len(templates)
    })

@app.route('/api/v2/job_templates/<int:template_id>/', methods=['GET'])
def get_job_template(template_id):
    """Get specific template by ID"""
    templates = load_templates()
    template = next((t for t in templates if t['id'] == template_id), None)
    
    if template:
        return jsonify(template)
    return jsonify({'error': 'Template not found'}), 404

@app.route('/api/v2/job_templates/<int:template_id>/schedules/', methods=['GET'])
def get_template_schedules(template_id):
    """Get schedules for specific template"""
    # Return dummy schedule
    return jsonify({
        'results': [
            {
                'id': 1,
                'name': 'Daily Schedule',
                'rrule': 'FREQ=DAILY;INTERVAL=1',
                'enabled': True,
                'dtstart': '2025-01-01T00:00:00Z'
            }
        ]
    })

@app.route('/api/v2/inventories/<int:inventory_id>/hosts/', methods=['GET'])
def get_inventory_hosts(inventory_id):
    """Get hosts for inventory"""
    # Return dummy hosts
    hosts_map = {
        10: [
            {'id': 1, 'name': 'web-server-01', 'enabled': True},
            {'id': 2, 'name': 'web-server-02', 'enabled': True},
            {'id': 3, 'name': 'web-server-03', 'enabled': True}
        ],
        20: [
            {'id': 4, 'name': 'db-primary', 'enabled': True},
            {'id': 5, 'name': 'db-replica-01', 'enabled': True}
        ],
        30: [
            {'id': 6, 'name': 'app-server-01', 'enabled': True},
            {'id': 7, 'name': 'app-server-02', 'enabled': True},
            {'id': 8, 'name': 'app-server-03', 'enabled': True}
        ]
    }
    
    return jsonify({
        'results': hosts_map.get(inventory_id, [])
    })

if __name__ == '__main__':
    print("=" * 60)
    print("Ansible Tower Simulator Starting...")
    print("=" * 60)
    print(f"Endpoint: http://localhost:5002")
    print(f"Ping: http://localhost:5002/api/v2/ping/")
    print(f"Templates: http://localhost:5002/api/v2/job_templates/")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5002, debug=True)