"""
Autosys Platform Simulator
Simulates Autosys REST API for testing
Port: 5001
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend testing

CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config/autosys_jobs.json')

def load_jobs():
    """Load dummy jobs from config file"""
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

@app.route('/api/v1/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'platform': 'autosys_simulator',
        'version': '1.0'
    })

@app.route('/api/v1/jobs', methods=['GET'])
def get_jobs():
    """
    Get all jobs with optional filters
    
    Query Parameters:
    - job_type: Filter by job type (CMD, BOX, FW)
    - status: Filter by status (ACTIVATED, INACTIVE)
    - owner: Filter by owner
    """
    jobs = load_jobs()
    
    # Apply filters if provided
    job_type = request.args.get('job_type')
    status = request.args.get('status')
    owner = request.args.get('owner')
    
    if job_type:
        jobs = [j for j in jobs if j.get('job_type') == job_type]
    if status:
        jobs = [j for j in jobs if j.get('status') == status]
    if owner:
        jobs = [j for j in jobs if j.get('owner') == owner]
    
    return jsonify({
        'jobs': jobs,
        'count': len(jobs),
        'timestamp': '2025-12-18T10:00:00Z'
    })

@app.route('/api/v1/jobs/<job_name>', methods=['GET'])
def get_job(job_name):
    """Get specific job by name"""
    jobs = load_jobs()
    job = next((j for j in jobs if j['name'] == job_name), None)
    
    if job:
        return jsonify(job)
    return jsonify({'error': 'Job not found'}), 404

if __name__ == '__main__':
    print("=" * 60)
    print("Autosys Simulator Starting...")
    print("=" * 60)
    print(f"Endpoint: http://localhost:5001")
    print(f"Health Check: http://localhost:5001/api/v1/health")
    print(f"Get Jobs: http://localhost:5001/api/v1/jobs")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5001, debug=True)