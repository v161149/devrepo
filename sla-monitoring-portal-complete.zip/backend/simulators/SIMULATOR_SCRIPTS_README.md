# Simulator Management Scripts - Windows PowerShell

**Location:** `backend/simulators/`

---

## 📋 **Scripts Included**

| Script | Purpose |
|--------|---------|
| `start_all_simulators.ps1` | Start all 3 simulators in background |
| `stop_all_simulators.ps1` | Stop all running simulators |
| `test_simulators.ps1` | Test that all simulators are responding |

---

## 🚀 **Quick Start**

### **1. Navigate to Simulators Directory**
```powershell
cd backend\simulators
```

### **2. Start All Simulators**
```powershell
.\start_all_simulators.ps1
```

**Output:**
```
=========================================
Starting SLA Portal Simulators
=========================================

Starting Autosys Simulator on port 5001...
  ✓ Autosys Simulator started (PID: 12345)
Starting Ansible Tower Simulator on port 5002...
  ✓ Ansible Tower Simulator started (PID: 12346)
Starting Asset Provider Simulator on port 5003...
  ✓ Asset Provider Simulator started (PID: 12347)

=========================================
All simulators started successfully!
=========================================

Simulator Endpoints:
  • Autosys Simulator:        http://localhost:5001
  • Ansible Tower Simulator:  http://localhost:5002
  • Asset Provider Simulator: http://localhost:5003
```

### **3. Test Simulators**
```powershell
# Test Autosys Simulator
curl http://localhost:5001/api/v1/health

# Test Ansible Tower Simulator  
curl http://localhost:5002/api/v2/ping/

# Test Asset Provider Simulator
curl http://localhost:5003/api/health
```

### **4. Stop All Simulators**
```powershell
.\stop_all_simulators.ps1
```

---

## 📝 **Detailed Usage**

### **Starting Simulators**

```powershell
# Basic start
.\start_all_simulators.ps1

# The script will:
# 1. Start each simulator as a background process
# 2. Display process IDs
# 3. Save PIDs to simulator_pids.txt for later stopping
# 4. Show endpoints and test commands
```

**What happens:**
- **Autosys Simulator** starts on port 5001
- **Ansible Tower Simulator** starts on port 5002  
- **Asset Provider Simulator** starts on port 5003
- All run in background (no new windows)
- Process IDs saved to `simulator_pids.txt`

---

### **Stopping Simulators**

```powershell
# Stop using saved PIDs (recommended)
.\stop_all_simulators.ps1
```

**The script will:**
1. Read PIDs from `simulator_pids.txt`
2. Stop each process gracefully
3. Remove PID file
4. Report results

**If PID file not found:**
- Script searches for Python processes running simulators
- Asks for confirmation before stopping
- Provides manual instructions if needed

---

### **Manual Process Management**

#### **Find Running Simulators**
```powershell
# Get all Python processes
Get-Process python

# Find processes by port
netstat -ano | findstr ":5001"
netstat -ano | findstr ":5002"
netstat -ano | findstr ":5003"
```

#### **Stop Specific Simulator**
```powershell
# Stop by PID
Stop-Process -Id 12345 -Force

# Stop all Python processes (CAUTION!)
Get-Process python | Stop-Process -Force
```

#### **Check If Ports Are in Use**
```powershell
# Check port 5001
Test-NetConnection -ComputerName localhost -Port 5001

# Or use netstat
netstat -ano | findstr ":5001"
```

---

## 🧪 **Testing Simulators**

### **Health Checks**

**Autosys Simulator:**
```powershell
curl http://localhost:5001/api/v1/health

# Expected Response:
# {"status":"healthy","platform":"autosys_simulator"}
```

**Ansible Tower Simulator:**
```powershell
curl http://localhost:5002/api/v2/ping/

# Expected Response:
# {"status":"ok","platform":"ansible_tower_simulator"}
```

**Asset Provider Simulator:**
```powershell
curl http://localhost:5003/api/health

# Expected Response:
# {"status":"healthy","service":"asset_provider_simulator"}
```

### **Data Retrieval Tests**

**Get Autosys Jobs:**
```powershell
curl http://localhost:5001/api/v1/jobs

# Returns list of jobs from config/autosys_jobs.json
```

**Get Ansible Templates:**
```powershell
curl http://localhost:5002/api/v2/job_templates/

# Returns list of templates from config/ansible_templates.json
```

**Get Assets:**
```powershell
curl http://localhost:5003/api/assets

# Returns list of assets from config/assets.json
```

---

## ⚙️ **Configuration**

### **Config Files Location**
```
backend/simulators/config/
├── autosys_jobs.json          # Autosys job definitions
├── ansible_templates.json     # Ansible Tower templates
└── assets.json                # Asset metadata
```

### **Customize Data**

**Add More Autosys Jobs:**
```powershell
# Edit config file
notepad backend\simulators\config\autosys_jobs.json

# Add new job entry
{
  "name": "MY_NEW_JOB",
  "job_type": "CMD",
  "description": "My custom job",
  "machine": "my-server",
  "owner": "my_team",
  "status": "ACTIVATED",
  "start_times": ["08:00"],
  "days_of_week": ["mo", "we", "fr"],
  "max_run_alarm": "60",
  "command": "/path/to/script.sh"
}

# Restart Autosys Simulator to reload
.\stop_all_simulators.ps1
.\start_all_simulators.ps1
```

### **Change Ports**

**Edit simulator files:**
```python
# In autosys_simulator.py
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)  # Change port here
```

**Update start script:**
```powershell
# In start_all_simulators.ps1
Write-Host "Autosys Simulator:        http://localhost:NEW_PORT"
```

---

## 🐛 **Troubleshooting**

### **Issue: Port Already in Use**

**Error:**
```
OSError: [WinError 10048] Only one usage of each socket address is normally permitted
```

**Solution:**
```powershell
# Find process using port
netstat -ano | findstr ":5001"

# Stop process
Stop-Process -Id <PID> -Force

# Or kill all on port (requires admin)
Get-NetTCPConnection -LocalPort 5001 | 
    Select-Object -ExpandProperty OwningProcess | 
    Stop-Process -Force
```

---

### **Issue: Python Not Found**

**Error:**
```
'python' is not recognized as an internal or external command
```

**Solution:**
```powershell
# Check Python installation
python --version

# If not found, try
python3 --version

# Or use full path
C:\Python39\python.exe autosys_simulator.py

# Or add Python to PATH
$env:PATH += ";C:\Python39"
```

---

### **Issue: Module Not Found**

**Error:**
```
ModuleNotFoundError: No module named 'flask'
```

**Solution:**
```powershell
# Install required packages
pip install flask

# Or if you have requirements.txt
pip install -r requirements.txt
```

---

### **Issue: Simulators Don't Stop**

**Solution 1: Use Stop Script**
```powershell
.\stop_all_simulators.ps1
```

**Solution 2: Kill All Python**
```powershell
Get-Process python | Stop-Process -Force
```

**Solution 3: Kill by Port**
```powershell
# Get PIDs using ports
$Pids = @()
foreach ($Port in @(5001, 5002, 5003)) {
    $Connections = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue
    $Pids += $Connections.OwningProcess
}

# Stop processes
$Pids | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
```

---

### **Issue: Can't See Process Output**

**Solution: Run in foreground for debugging**
```powershell
# Run individual simulator to see logs
python autosys_simulator.py

# Or with verbose output
$env:FLASK_ENV = "development"
python autosys_simulator.py
```

---

## 📊 **Monitoring Simulators**

### **Check Status**
```powershell
# Quick health check all simulators
@(5001, 5002, 5003) | ForEach-Object {
    $Port = $_
    try {
        $Response = Invoke-WebRequest -Uri "http://localhost:$Port" -TimeoutSec 2
        Write-Host "Port $Port : ✓ Running" -ForegroundColor Green
    }
    catch {
        Write-Host "Port $Port : ✗ Not responding" -ForegroundColor Red
    }
}
```

### **View Logs**
```powershell
# Simulators log to console
# To capture logs, run in foreground and redirect:
python autosys_simulator.py > autosys.log 2>&1
```

### **Monitor Resource Usage**
```powershell
# Get Python processes with resource info
Get-Process python | Select-Object Id, Name, CPU, WorkingSet, StartTime

# Continuous monitoring
while ($true) {
    Clear-Host
    Get-Process python | Select-Object Id, CPU, WorkingSet
    Start-Sleep -Seconds 2
}
```

---

## 🔄 **Restart Simulators**

```powershell
# Quick restart
.\stop_all_simulators.ps1
.\start_all_simulators.ps1

# Or in one line
.\stop_all_simulators.ps1; .\start_all_simulators.ps1
```

---

## 📚 **Additional Resources**

### **Simulator Endpoints Reference**

| Simulator | Base URL | Health Endpoint | Data Endpoint |
|-----------|----------|-----------------|---------------|
| Autosys | http://localhost:5001 | /api/v1/health | /api/v1/jobs |
| Ansible Tower | http://localhost:5002 | /api/v2/ping/ | /api/v2/job_templates/ |
| Asset Provider | http://localhost:5003 | /api/health | /api/assets |

### **Environment Variables**

```powershell
# Set Flask debug mode
$env:FLASK_ENV = "development"

# Set custom port
$env:AUTOSYS_PORT = "5010"

# Disable debug mode
$env:FLASK_ENV = "production"
```

---

## ✅ **Success Checklist**

After starting simulators, verify:

- [ ] All 3 simulators started (check console output)
- [ ] Process IDs saved to `simulator_pids.txt`
- [ ] All health endpoints respond with 200 OK
- [ ] Data endpoints return JSON
- [ ] No port conflicts
- [ ] Processes running in background

---

## 🎯 **Next Steps**

Once simulators are running:

1. **Test API Endpoints** - Use curl or Postman
2. **Configure Connectors** - In SLA Portal UI
3. **Test Data Import** - Import sample data
4. **Develop Features** - Build against simulator APIs
5. **Switch to Production** - Change connector URLs when ready

---

**Questions?** Check the main implementation guide or simulator source code for details.
