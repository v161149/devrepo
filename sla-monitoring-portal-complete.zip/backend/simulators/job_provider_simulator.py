"""
Job Metadata Provider Simulator
Simulates job/batch management API for testing
Port: 5005
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config/jobs.json')

def load_jobs():
    """Load dummy jobs from config file"""
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'job_provider_simulator',
        'version': '1.0'
    })

@app.route('/api/jobs', methods=['GET'])
def get_jobs():
    """
    Get all jobs with optional filters
    
    Query Parameters:
    - asset_id: Filter by asset ID
    - service_name: Filter by service name
    - job_type: Filter by job type
    - status: Filter by status
    """
    jobs = load_jobs()
    
    # Apply filters
    asset_id = request.args.get('asset_id')
    service_name = request.args.get('service_name')
    job_type = request.args.get('job_type')
    status = request.args.get('status')
    
    if asset_id:
        jobs = [j for j in jobs if j.get('asset_id') == asset_id]
    if service_name:
        jobs = [j for j in jobs if j.get('service_name') == service_name]
    if job_type:
        jobs = [j for j in jobs if j.get('job_type', '').lower() == job_type.lower()]
    if status:
        jobs = [j for j in jobs if j.get('status') == status]
    
    return jsonify({
        'jobs': jobs,
        'total': len(jobs),
        'timestamp': '2025-12-26T10:00:00Z'
    })

@app.route('/api/jobs/<job_id>', methods=['GET'])
def get_job(job_id):
    """Get specific job by ID"""
    jobs = load_jobs()
    job = next((j for j in jobs if j['job_id'] == job_id), None)
    
    if job:
        return jsonify(job)
    return jsonify({'error': 'Job not found'}), 404

if __name__ == '__main__':
    print("=" * 60)
    print("Job Provider Simulator Starting...")
    print("=" * 60)
    print(f"Endpoint: http://localhost:5005")
    print(f"Health Check: http://localhost:5005/api/health")
    print(f"Get Jobs: http://localhost:5005/api/jobs")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5005, debug=True)
