"""
SLA Provider Simulator
Provides sample SLA data for testing
"""

from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Sample SLA data - each SLA links to EITHER a service OR a job
SAMPLE_SLAS = [
    {
        "sla_id": "SLA-001",
        "sla_name": "HR Service Uptime SLA",
        "sla_type": "Availability",
        "service_id": "SVC-001",  # Links to service
        "job_id": "",  # Empty - not linked to job
        "target_value_percentage": 99.9,
        "warning_threshold_percentage": 99.5,
        "critical_threshold_percentage": 99.0,
        "measurement_period": "Monthly",
        "description": "Ensures HR Data Processing Service maintains 99.9% uptime"
    },
    {
        "sla_id": "SLA-002",
        "sla_name": "Daily Payroll Job Completion SLA",
        "sla_type": "Completion Rate",
        "service_id": "",  # Empty - not linked to service
        "job_id": "JOB-001",  # Links to job
        "target_value_percentage": 100.0,
        "warning_threshold_percentage": 99.0,
        "critical_threshold_percentage": 95.0,
        "measurement_period": "Daily",
        "description": "Ensures Daily Payroll Processing Job completes successfully"
    },
    {
        "sla_id": "SLA-003",
        "sla_name": "Asset Database Service Performance SLA",
        "sla_type": "Response Time",
        "service_id": "SVC-002",  # Links to service
        "job_id": "",  # Empty - not linked to job
        "target_value_percentage": 95.0,
        "warning_threshold_percentage": 90.0,
        "critical_threshold_percentage": 85.0,
        "measurement_period": "Hourly",
        "description": "Maintains response time under 500ms for 95% of requests"
    },
    {
        "sla_id": "SLA-004",
        "sla_name": "Hourly Database Sync Job Success SLA",
        "sla_type": "Success Rate",
        "service_id": "",  # Empty - not linked to service
        "job_id": "JOB-002",  # Links to job
        "target_value_percentage": 99.5,
        "warning_threshold_percentage": 98.0,
        "critical_threshold_percentage": 95.0,
        "measurement_period": "Hourly",
        "description": "Ensures Hourly Database Sync Job maintains 99.5% success rate"
    },
    {
        "sla_id": "SLA-005",
        "sla_name": "ETL Pipeline Service SLA",
        "sla_type": "Processing Time",
        "service_id": "SVC-003",  # Links to service
        "job_id": "",  # Empty - not linked to job
        "target_value_percentage": 97.0,
        "warning_threshold_percentage": 93.0,
        "critical_threshold_percentage": 90.0,
        "measurement_period": "Daily",
        "description": "Ensures ETL Pipeline Service processes within time window"
    }
]

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'sla_provider_simulator',
        'version': '1.0',
        'platform': 'demo_sla'
    })

@app.route('/api/slas', methods=['GET'])
def get_slas():
    """Get all SLAs"""
    return jsonify({
        'slas': SAMPLE_SLAS,
        'total': len(SAMPLE_SLAS)
    })

@app.route('/api/slas/<sla_id>', methods=['GET'])
def get_sla(sla_id):
    """Get specific SLA by ID"""
    sla = next((s for s in SAMPLE_SLAS if s['sla_id'] == sla_id), None)
    if sla:
        return jsonify(sla)
    return jsonify({'error': 'SLA not found'}), 404

if __name__ == '__main__':
    print("=" * 60)
    print("SLA Provider Simulator")
    print("=" * 60)
    print("Starting SLA simulator on http://localhost:5006")
    print()
    print("Available endpoints:")
    print("  - GET /api/health      - Health check")
    print("  - GET /api/slas        - Get all SLAs")
    print("  - GET /api/slas/<id>   - Get specific SLA")
    print()
    print("Sample SLAs:")
    for sla in SAMPLE_SLAS:
        linked_to = f"Service: {sla['service_id']}" if sla['service_id'] else f"Job: {sla['job_id']}"
        print(f"  - {sla['sla_id']}: {sla['sla_name']} ({linked_to})")
    print()
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5006, debug=True)
