# Start All Simulators - Windows PowerShell Version (FINAL)
# Starts Autosys, Ansible Tower, and Asset Provider simulators in background

# Change to simulators directory
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptPath

Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Starting SLA Portal Simulators" -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

# Start Autosys Simulator (Port 5001)
Write-Host "Starting Autosys Simulator on port 5001..." -ForegroundColor Yellow
$AutosysJob = Start-Process -FilePath "python" -ArgumentList "autosys_simulator.py" -WindowStyle Hidden -PassThru
$AutosysPID = $AutosysJob.Id
Write-Host "  * Autosys Simulator started (PID: $AutosysPID)" -ForegroundColor Green

# Wait a moment for port to bind
Start-Sleep -Milliseconds 1000

# Start Ansible Tower Simulator (Port 5002)
Write-Host "Starting Ansible Tower Simulator on port 5002..." -ForegroundColor Yellow
$AnsibleJob = Start-Process -FilePath "python" -ArgumentList "ansible_simulator.py" -WindowStyle Hidden -PassThru
$AnsiblePID = $AnsibleJob.Id
Write-Host "  * Ansible Tower Simulator started (PID: $AnsiblePID)" -ForegroundColor Green

# Wait a moment for port to bind
Start-Sleep -Milliseconds 1000

# Start Asset Provider Simulator (Port 5003)
Write-Host "Starting Asset Provider Simulator on port 5003..." -ForegroundColor Yellow
$AssetJob = Start-Process -FilePath "python" -ArgumentList "asset_provider_simulator.py" -WindowStyle Hidden -PassThru
$AssetPID = $AssetJob.Id
Write-Host "  * Asset Provider Simulator started (PID: $AssetPID)" -ForegroundColor Green
# Wait a moment for port to bind
Start-Sleep -Milliseconds 1000

# Start Service Provider Simulator (Port 5004)
Write-Host "Starting Service Provider Simulator on port 5004..." -ForegroundColor Yellow
$ServiceJob = Start-Process -FilePath "python" -ArgumentList "service_provider_simulator.py" -WindowStyle Hidden -PassThru
$ServicePID = $ServiceJob.Id
Write-Host "  * Service Provider Simulator started (PID: $ServicePID)" -ForegroundColor Green
# Wait a moment for port to bind
Start-Sleep -Milliseconds 1000

# Start Job Provider Simulator (Port 5005)
Write-Host "Starting Job Provider Simulator on port 5005..." -ForegroundColor Yellow
$JobJob = Start-Process -FilePath "python" -ArgumentList "job_provider_simulator.py" -WindowStyle Hidden -PassThru
$JobPID = $JobJob.Id
Write-Host "  * Job Provider Simulator started (PID: $JobPID)" -ForegroundColor Green
# Wait a moment for port to bind
Start-Sleep -Milliseconds 1000

# Start SLA Provider Simulator (Port 5006)
Write-Host "Starting SLA Provider Simulator on port 5006..." -ForegroundColor Yellow
$SLAJob = Start-Process -FilePath "python" -ArgumentList "sla_provider_simulator.py" -WindowStyle Hidden -PassThru
$SLAPID = $SLAJob.Id
Write-Host "  * SLA Provider Simulator started (PID: $SLAPID)" -ForegroundColor Green
# Wait a moment for port to bind
Start-Sleep -Milliseconds 1000

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "All simulators started successfully!" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Simulator Endpoints:" -ForegroundColor Cyan
Write-Host "  * Autosys Simulator:        http://localhost:5001" -ForegroundColor White
Write-Host "  * Ansible Tower Simulator:  http://localhost:5002" -ForegroundColor White
Write-Host "  * Asset Provider Simulator: http://localhost:5003" -ForegroundColor White
Write-Host "  * Service Provider Simulator: http://localhost:5004" -ForegroundColor White
Write-Host "  * Job Provider Simulator: http://localhost:5005" -ForegroundColor White
Write-Host "  * SLA Provider Simulator: http://localhost:5006" -ForegroundColor White
Write-Host ""
Write-Host "Process IDs:" -ForegroundColor Cyan
Write-Host "  * Autosys:  $AutosysPID" -ForegroundColor White
Write-Host "  * Ansible:  $AnsiblePID" -ForegroundColor White
Write-Host "  * Asset:    $AssetPID" -ForegroundColor White
Write-Host "  * Asset:    $AssetPID" -ForegroundColor White
Write-Host "  * Service:  $ServicePID" -ForegroundColor White
Write-Host "  * Job:      $JobPID" -ForegroundColor White
Write-Host "  * SLA:      $SLAPID" -ForegroundColor White
Write-Host ""
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host "To test simulators, run:" -ForegroundColor Yellow
Write-Host "  curl http://localhost:5001/api/v1/health" -ForegroundColor White
Write-Host "  curl http://localhost:5002/api/v2/ping/" -ForegroundColor White
Write-Host "  curl http://localhost:5003/api/health" -ForegroundColor White
Write-Host "  curl http://localhost:5004/api/health" -ForegroundColor White
Write-Host "  curl http://localhost:5005/api/health" -ForegroundColor White
Write-Host "  curl http://localhost:5006/api/health" -ForegroundColor White
Write-Host ""
Write-Host "To stop all simulators, run:" -ForegroundColor Yellow
Write-Host "  .\stop_all_simulators.ps1" -ForegroundColor White
Write-Host ""
Write-Host "Or manually kill processes:" -ForegroundColor Yellow
Write-Host "  Stop-Process -Id $AutosysPID" -ForegroundColor White
Write-Host "  Stop-Process -Id $AnsiblePID" -ForegroundColor White
Write-Host "  Stop-Process -Id $AssetPID" -ForegroundColor White
Write-Host "  Stop-Process -Id $ServicePID" -ForegroundColor White
Write-Host "  Stop-Process -Id $JobPID" -ForegroundColor White
Write-Host "  Stop-Process -Id $SLAPID" -ForegroundColor White
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host ""

# Keep track of PIDs in a file for stop script
$PidsFile = "simulator_pids.txt"
"$AutosysPID,$AnsiblePID,$AssetPID,$ServicePID,$JobPID,$SLAPID" | Out-File -FilePath $PidsFile -Encoding ASCII

Write-Host "* Process IDs saved to $PidsFile" -ForegroundColor Green
Write-Host ""

# Wait a moment then verify they started
Write-Host "Verifying simulators are running..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

$AllRunning = $true
foreach ($ProcessId in @($AutosysPID, $AnsiblePID, $AssetPID, $ServicePID, $JobPID, $SLAPID)) {
    $Process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if ($Process) {
        Write-Host "  * PID $ProcessId - Running" -ForegroundColor Green
    } else {
        Write-Host "  * PID $ProcessId - NOT RUNNING" -ForegroundColor Red
        $AllRunning = $false
    }
}

if ($AllRunning) {
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Green
    Write-Host "Success! All simulators are running." -ForegroundColor Green
    Write-Host "=========================================" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Yellow
    Write-Host "Warning: Some simulators may have failed to start." -ForegroundColor Yellow
    Write-Host "Check for port conflicts or missing dependencies." -ForegroundColor Yellow
    Write-Host "=========================================" -ForegroundColor Yellow
}
Write-Host ""
