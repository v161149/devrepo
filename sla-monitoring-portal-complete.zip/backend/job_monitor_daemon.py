#!/usr/bin/env python3
"""
Job Monitor Daemon - Log-Based Job Execution Monitoring

This daemon:
1. Queries all active jobs with log monitoring enabled
2. For each job, connects to its configured log server
3. Queries logs using the job's log template
4. Parses log entries to track job executions
5. Stores monitoring results in job_monitoring_results table
6. Runs continuously at configured intervals

Usage:
    python job_monitor_daemon.py [--interval SECONDS] [--once]
    
Options:
    --interval SECONDS  Check interval in seconds (default: 300 = 5 minutes)
    --once              Run once and exit (for testing)
    --debug             Enable debug logging
"""

import sys
import os
import time
import json
import logging
import argparse
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

# Add parent directory to path to import from backend
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database_service import DatabaseService
from log_connector import get_log_connector
from enhanced_sla_evaluator import EnhancedSLAEvaluator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('job_monitor_daemon.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('JobMonitor')


class JobMonitorDaemon:
    """Daemon to monitor job executions via log queries"""
    
    def __init__(self, db_service: DatabaseService, check_interval: int = 300):
        """
        Initialize the job monitor daemon
        
        Args:
            db_service: Database service instance
            check_interval: Seconds between monitoring checks (default 5 min)
        """
        self.db = db_service
        self.check_interval = check_interval
        self.running = True
        
        # ===== NEW: Initialize Enhanced SLA Evaluator =====
        self.sla_evaluator = EnhancedSLAEvaluator(db_service)
        logger.info("Enhanced SLA Evaluator initialized")
        
    def stop(self):
        """Stop the daemon gracefully"""
        logger.info("Stopping job monitor daemon...")
        self.running = False
        
    def monitor_job(self, job: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Monitor a single job by querying its execution logs
        
        Args:
            job: Job dictionary with log configuration
            
        Returns:
            Monitoring result dictionary or None if monitoring failed
        """
        job_id = job['job_id']
        job_name = job['job_name']
        org_id = job['org_id']
        
        logger.info(f"Monitoring job: {job_name} ({job_id})")
        
        try:
            # Get log server connector configuration
            log_server_type = job.get('log_server_type')
            if not log_server_type:
                logger.warning(f"Job {job_id} has no log_server_type configured")
                return None
                
            # Get active connector for this log server type
            connector_config = self.db.get_active_log_server_connector(org_id, log_server_type)
            if not connector_config:
                logger.error(f"No active connector found for type: {log_server_type}")
                return self._create_error_result(
                    job,
                    f"No active log connector configured for {log_server_type}"
                )
            
            # Get log connector instance
            log_connector = get_log_connector(connector_config)
            
            # Parse log template
            log_template = job.get('log_template')
            if not log_template:
                logger.warning(f"Job {job_id} has no log_template configured")
                return None
                
            if isinstance(log_template, str):
                log_template = json.loads(log_template)
            
            # Build query to find recent log entries for this job
            job_identifier = job.get('job_identifier')
            if not job_identifier:
                logger.warning(f"Job {job_id} has no job_identifier")
                return None
            
            # Query logs from last check interval (with 10% buffer)
            time_range_minutes = int(self.check_interval / 60 * 1.1)
            
            # Build log query based on template
            query = self._build_job_query(
                job_identifier=job_identifier,
                log_template=log_template,
                time_range_minutes=time_range_minutes
            )
            
            logger.debug(f"Querying logs for identifier: {job_identifier}")

            # Query the log server (pass identifier directly, not formatted query)
            log_entries = log_connector.query_logs(job_identifier, time_range_minutes)
            
            if not log_entries:
                logger.warning(f"No log entries found for job {job_id}")
                return self._create_not_run_result(
                    job,
                    "No log entries found in time range"
                )
            
            # Parse the most recent log entry
            latest_entry = log_entries[0]  # Assuming sorted by timestamp DESC
            parsed_data = log_connector.parse_log_entry(latest_entry, log_template)
            
            # Determine job execution status and SLA compliance
            execution_result = self._analyze_job_execution(parsed_data, job)
            
            # Create monitoring result
            result = {
                'job_id': job_id,
                'org_id': org_id,
                'check_time': datetime.utcnow(),
                'status': execution_result['status'],
                'execution_start_time': self._parse_timestamp(
                    parsed_data.get('start_time')
                ),
                'execution_end_time': self._parse_timestamp(
                    parsed_data.get('end_time')
                ),
                'duration_seconds': parsed_data.get('duration_seconds') or 
                                   execution_result.get('calculated_duration'),
                'records_processed': parsed_data.get('records_processed'),
                'log_entry': json.dumps(latest_entry),
                'parsed_data': json.dumps(parsed_data),
                'error_message': execution_result.get('error_message'),
                'metadata': json.dumps({
                    'entries_found': len(log_entries),
                    'connector_type': log_server_type,
                    'query': query,
                    'records_failed': parsed_data.get('records_failed')
                })
            }
            
            logger.info(
                f"Job {job_name}: status={result['status']}, "
                  f"duration={result['duration_seconds']}s"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error monitoring job {job_id}: {str(e)}", exc_info=True)
            return self._create_error_result(job, str(e))
    
    def _build_job_query(
        self,
        job_identifier: str,
        log_template: Dict[str, str],
        time_range_minutes: int
    ) -> str:
        """
        Build log query string based on job configuration
        
        Args:
            job_identifier: Unique job identifier in logs
            log_template: Log entry template with field mappings
            time_range_minutes: Time range for query in minutes
            
        Returns:
            Query string for log server
        """
        # For most log systems, search for the job identifier
        # This is a simplified query - actual implementation may vary by log server type
        
        # Get the identifier field from template
        identifier_field = None
        for field, value in log_template.items():
            if '{{job_identifier}}' in str(value) or field == 'identifier':
                identifier_field = field
                break
        
        if identifier_field:
            return f'{identifier_field}:"{job_identifier}"'
        else:
            # Fallback: search in all fields
            return f'"{job_identifier}"'
    
    def _parse_timestamp(self, timestamp_str: Optional[str]) -> Optional[datetime]:
        """
        Parse timestamp string to datetime
        
        Args:
            timestamp_str: Timestamp string in various formats
            
        Returns:
            datetime object or None
        """
        if not timestamp_str:
            return None
        
        # Try common timestamp formats
        formats = [
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%SZ',
            '%Y-%m-%d %H:%M:%S',
            '%Y-%m-%dT%H:%M:%S.%f',
            '%Y-%m-%dT%H:%M:%S.%fZ',
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
        
        # If all formats fail, try ISO format parse
        try:
            from dateutil import parser
            return parser.parse(timestamp_str)
        except:
            logger.warning(f"Failed to parse timestamp: {timestamp_str}")
            return None
    
    def _analyze_job_execution(
        self,
        parsed_data: Dict[str, Any],
        job: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze job execution and determine SLA compliance
        
        Args:
            parsed_data: Parsed fields from log entry
            job: Job configuration
            
        Returns:
            Dictionary with status, met_sla, and optional error_message
        """
        # Determine execution status
        status = parsed_data.get('status', '').lower()
        
        # Map log status to our job status
        if status in ['success', 'completed', 'done', 'finished', 'ok']:
            execution_status = 'success'
            met_sla = True
            error_message = None
        elif status in ['failed', 'error', 'failure', 'exception']:
            execution_status = 'failed'
            met_sla = False
            error_message = parsed_data.get('message', 'Job execution failed')
        elif status in ['running', 'in_progress', 'executing']:
            execution_status = 'running'
            met_sla = None  # Can't determine yet
            error_message = None
        elif status in ['not_run', 'skipped', 'cancelled']:
            execution_status = 'not_run'
            met_sla = False
            error_message = parsed_data.get('message', 'Job did not run')
        else:
            execution_status = 'unknown'
            met_sla = None
            error_message = 'Unable to determine execution status'
        
        # Calculate duration if we have start and end times
        calculated_duration = None
        start_time = self._parse_timestamp(parsed_data.get('start_time'))
        end_time = self._parse_timestamp(parsed_data.get('end_time'))
        
        if start_time and end_time:
            calculated_duration = (end_time - start_time).total_seconds()
        
        # Check SLA compliance based on additional criteria
        if met_sla is True:
            # Check if there's a duration SLA
            duration = parsed_data.get('duration_seconds') or calculated_duration
            
            # Get job SLAs to check duration limits
            slas = self.db.get_slas_by_job(job['job_id'])
            for sla in slas:
                if sla.get('sla_type') == 'execution_time':
                    # Check if duration exceeds SLA threshold
                    # This is a simplified check - actual implementation may vary
                    if duration and sla.get('target_value'):
                        if duration > float(sla['target_value']):
                            met_sla = False
                            error_message = f"Execution time ({duration}s) exceeded SLA target"
                            break
        
        return {
            'status': execution_status,
            'error_message': error_message,
            'calculated_duration': calculated_duration
        }
    
    def _create_error_result(self, job: Dict[str, Any], error_msg: str) -> Dict[str, Any]:
        """Create an error monitoring result"""
        return {
            'job_id': job['job_id'],
            'org_id': job['org_id'],
            'check_time': datetime.utcnow(),
            'status': 'unknown',
            'execution_start_time': None,
            'execution_end_time': None,
            'duration_seconds': None,
            'records_processed': None,
            'log_entry': None,
            'parsed_data': None,
            'error_message': error_msg,
            'metadata': json.dumps({'error': 'monitoring_failed'})
        }
    
    def _create_not_run_result(self, job: Dict[str, Any], reason: str) -> Dict[str, Any]:
        """Create a not-run monitoring result"""
        return {
            'job_id': job['job_id'],
            'org_id': job['org_id'],
            'check_time': datetime.utcnow(),
            'status': 'not_run',
            'execution_start_time': None,
            'execution_end_time': None,
            'duration_seconds': None,
            'records_processed': None,
            'log_entry': None,
            'parsed_data': None,
            'error_message': reason,
            'metadata': json.dumps({'reason': 'no_data'})
        }
    
    def monitor_all_jobs(self):
        """Monitor all active jobs with log monitoring enabled"""
        logger.info("Starting job monitoring cycle...")
        
        try:
            # Get all active jobs with log monitoring
            jobs = self.db.get_all_active_jobs_with_log_monitoring()
            
            logger.info(f"Found {len(jobs)} jobs to monitor")
            
            if not jobs:
                logger.info("No jobs configured for log monitoring")
                return
            
            success_count = 0
            error_count = 0
            
            for job in jobs:
                try:
                    # Monitor the job
                    result = self.monitor_job(job)
                    
                    if result:
                        # Generate result_id if not present
                        import uuid
                        if 'result_id' not in result:
                            result['result_id'] = f"RES-{uuid.uuid4().hex[:16].upper()}"
                        
                        # Store the result
                        result_id = self.db.create_job_monitoring_result(result)
                        
                        # Use result_id from result if database doesn't return it
                        if not result_id:
                            result_id = result['result_id']
                        
                        success_count += 1
                        
                        # ===== NEW: ENHANCED SLA EVALUATION =====
                        try:
                            # Get parsed_data from result
                            parsed_data_str = result.get('parsed_data')

                            # Skip SLA evaluation if no log data
                            if not parsed_data_str:
                                logger.info(f"Skipping SLA evaluation for {job['job_name']} - no log data")
                                return

                            parsed_data = json.loads(parsed_data_str) if isinstance(parsed_data_str, str) else parsed_data_str

                            # Evaluate ALL SLAs for this job
                            compliance_results = self.sla_evaluator.evaluate_job_slas(
                                job_id=job['job_id'],
                                monitoring_result_id=result_id,
                                parsed_log_data=parsed_data,
                                org_id=job['org_id']
                            )
                            
                            # Log summary
                            if compliance_results:
                                breached = [c for c in compliance_results if not c['met_sla']]
                                if breached:
                                    logger.warning(
                                        f"Job {job['job_name']}: "
                                        f"{len(breached)}/{len(compliance_results)} SLAs BREACHED"
                                    )
                                else:
                                    logger.info(
                                        f"Job {job['job_name']}: "
                                        f"All {len(compliance_results)} SLAs met"
                                    )
                                    
                        except Exception as e:
                            logger.error(f"Error evaluating SLAs for job {job.get('job_name')}: {e}")
                        # ===== END ENHANCED SLA EVALUATION =====
                    else:
                        error_count += 1
                        
                except Exception as e:
                    logger.error(
                        f"Failed to monitor job {job.get('job_id')}: {str(e)}",
                        exc_info=True
                    )
                    error_count += 1
            
            logger.info(
                f"Monitoring cycle complete: {success_count} successful, "
                f"{error_count} errors"
            )
            
        except Exception as e:
            logger.error(f"Error in monitoring cycle: {str(e)}", exc_info=True)
    
    def run(self):
        """Main daemon loop"""
        logger.info(f"Job Monitor Daemon started (interval: {self.check_interval}s)")
        
        while self.running:
            try:
                # Run monitoring cycle
                self.monitor_all_jobs()
                
                # Wait for next cycle
                logger.info(f"Sleeping for {self.check_interval} seconds...")
                time.sleep(self.check_interval)
                
            except KeyboardInterrupt:
                logger.info("Received interrupt signal")
                break
            except Exception as e:
                logger.error(f"Unexpected error in daemon loop: {str(e)}", exc_info=True)
                # Sleep before retrying to avoid tight error loop
                time.sleep(60)
        
        logger.info("Job Monitor Daemon stopped")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Job Monitor Daemon')
    parser.add_argument(
        '--interval',
        type=int,
        default=300,
        help='Check interval in seconds (default: 300 = 5 minutes)'
    )
    parser.add_argument(
        '--once',
        action='store_true',
        help='Run once and exit (for testing)'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    if args.debug:
        logger.setLevel(logging.DEBUG)
        logging.getLogger('log_connector').setLevel(logging.DEBUG)
    
    # Initialize database service
    db_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'database',
        'sla_portal.db'
    )
    db = DatabaseService(db_path)
    
    # Create daemon
    daemon = JobMonitorDaemon(db, args.interval)
    
    try:
        if args.once:
            logger.info("Running in single-shot mode")
            daemon.monitor_all_jobs()
        else:
            daemon.run()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        daemon.stop()
    finally:
        #db.close()
        # DatabaseService doesn't have a close() method
        # Connections are managed with context managers
        pass


if __name__ == '__main__':
    main()
