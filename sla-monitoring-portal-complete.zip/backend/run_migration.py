#!/usr/bin/env python3
"""
Database Migration Runner
Applies migration 001: Add Log-Based Monitoring Schema
"""

import sqlite3
import os
import sys
from datetime import datetime

def apply_migration(db_path='../database/sla_portal.db'):
    """Apply the log monitoring schema migration"""
    
    migration_file = '001_add_log_monitoring_schema.sql'
    
    if not os.path.exists(migration_file):
        print(f"❌ Error: Migration file '{migration_file}' not found")
        print(f"   Current directory: {os.getcwd()}")
        sys.exit(1)
    
    if not os.path.exists(db_path):
        print(f"❌ Error: Database file '{db_path}' not found")
        sys.exit(1)
    
    print(f"🔄 Starting migration: {migration_file}")
    print(f"📁 Database: {db_path}")
    print(f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("-" * 60)
    
    # Read migration SQL
    with open(migration_file, 'r') as f:
        migration_sql = f.read()
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Execute migration
        print("📊 Applying migration...")
        cursor.executescript(migration_sql)
        conn.commit()
        
        print("✅ Migration applied successfully!")
        print("-" * 60)
        
        # Verify tables were created
        print("\n🔍 Verifying migration...")
        
        tables_to_check = [
            'log_server_connectors',
            'service_monitoring_results',
            'job_monitoring_results'
        ]
        
        for table in tables_to_check:
            cursor.execute(f"SELECT count(*) FROM sqlite_master WHERE type='table' AND name='{table}'")
            count = cursor.fetchone()[0]
            if count > 0:
                print(f"   ✓ Table '{table}' exists")
            else:
                print(f"   ✗ Table '{table}' NOT found")
        
        # Check if columns were added to services table
        cursor.execute("PRAGMA table_info(services)")
        service_columns = [col[1] for col in cursor.fetchall()]
        
        new_service_columns = ['service_identifier', 'log_template', 'log_server_type']
        print(f"\n   Services table columns:")
        for col in new_service_columns:
            if col in service_columns:
                print(f"   ✓ Column '{col}' added")
            else:
                print(f"   ✗ Column '{col}' NOT found")
        
        # Check if columns were added to jobs table
        cursor.execute("PRAGMA table_info(jobs)")
        job_columns = [col[1] for col in cursor.fetchall()]
        
        new_job_columns = ['job_identifier', 'log_template', 'log_server_type']
        print(f"\n   Jobs table columns:")
        for col in new_job_columns:
            if col in job_columns:
                print(f"   ✓ Column '{col}' added")
            else:
                print(f"   ✗ Column '{col}' NOT found")
        
        # Check indexes
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_log%'")
        indexes = cursor.fetchall()
        print(f"\n   Indexes created: {len(indexes)}")
        for idx in indexes:
            print(f"   ✓ {idx[0]}")
        
        print("\n" + "=" * 60)
        print("✅ Migration completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ Error applying migration: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    finally:
        conn.close()

def rollback_migration(db_path='../database/sla_portal.db'):
    """Rollback the migration (drop tables and columns)"""
    
    print(f"⚠️  WARNING: Rolling back migration")
    print(f"📁 Database: {db_path}")
    
    response = input("Are you sure you want to rollback? This will delete data! (yes/no): ")
    if response.lower() != 'yes':
        print("❌ Rollback cancelled")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("🔄 Rolling back migration...")
        
        # Drop tables
        cursor.execute("DROP TABLE IF EXISTS job_monitoring_results")
        cursor.execute("DROP TABLE IF EXISTS service_monitoring_results")
        cursor.execute("DROP TABLE IF EXISTS log_server_connectors")
        
        print("   ✓ Dropped monitoring results tables")
        print("   ✓ Dropped log_server_connectors table")
        
        # Note: SQLite doesn't support DROP COLUMN directly
        # You would need to recreate the tables without those columns
        print("\n⚠️  Note: Cannot drop columns from services and jobs tables in SQLite")
        print("   Columns added: service_identifier, log_template, log_server_type")
        print("   These columns will remain but can be ignored")
        
        conn.commit()
        print("\n✅ Rollback completed")
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ Error during rollback: {str(e)}")
        sys.exit(1)
    
    finally:
        conn.close()

def show_status(db_path='../database/sla_portal.db'):
    """Show current migration status"""
    
    if not os.path.exists(db_path):
        print(f"❌ Error: Database file '{db_path}' not found")
        sys.exit(1)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Check if schema_migrations table exists
        cursor.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='schema_migrations'")
        if cursor.fetchone()[0] == 0:
            print("❌ schema_migrations table not found")
            return
        
        # Get migration history
        cursor.execute("""
            SELECT migration_id, migration_name, version, applied_at, status 
            FROM schema_migrations 
            ORDER BY applied_at DESC
        """)
        
        migrations = cursor.fetchall()
        
        print("\n📋 Migration History")
        print("=" * 80)
        
        if migrations:
            for mig in migrations:
                print(f"ID: {mig[0]}")
                print(f"   Name: {mig[1]}")
                print(f"   Version: {mig[2]}")
                print(f"   Applied: {mig[3]}")
                print(f"   Status: {mig[4]}")
                print("-" * 80)
        else:
            print("No migrations applied yet")
        
        # Check table existence
        print("\n📊 Current Schema Status")
        print("=" * 80)
        
        tables = [
            'log_server_connectors',
            'service_monitoring_results',
            'job_monitoring_results'
        ]
        
        for table in tables:
            cursor.execute(f"SELECT count(*) FROM sqlite_master WHERE type='table' AND name='{table}'")
            exists = cursor.fetchone()[0] > 0
            
            if exists:
                cursor.execute(f"SELECT count(*) FROM {table}")
                count = cursor.fetchone()[0]
                print(f"✓ {table}: {count} records")
            else:
                print(f"✗ {table}: not found")
        
    finally:
        conn.close()

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Database Migration Tool')
    parser.add_argument('action', choices=['apply', 'rollback', 'status'], 
                       help='Action to perform')
    parser.add_argument('--db', default='../database/sla_portal.db',
                       help='Path to database file (default: ../database/sla_portal.db)')
    
    args = parser.parse_args()
    
    if args.action == 'apply':
        apply_migration(args.db)
    elif args.action == 'rollback':
        rollback_migration(args.db)
    elif args.action == 'status':
        show_status(args.db)
