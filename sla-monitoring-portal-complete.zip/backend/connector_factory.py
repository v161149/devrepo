"""
Connector Factory
Centralized factory for creating connector instances

Simplifies connector instantiation and configuration
Supports: asset, service, job, and sla connectors
"""

from typing import Dict, Any, Optional
import logging

from base_connector import BaseConnector
from asset_data_connector import AssetDataConnector
from service_data_connector import ServiceDataConnector
from job_data_connector import JobDataConnector
from sla_data_connector import SLADataConnector

logger = logging.getLogger(__name__)


def get_connector(
    connector_type: str,
    config: Dict[str, Any]
) -> BaseConnector:
    """
    Factory function to create appropriate connector instance
    
    Args:
        connector_type: Type of connector ('asset', 'service', 'job', or 'sla')
        config: Configuration dictionary with:
            - id: Connector configuration ID
            - api_endpoint: Base URL for API
            - api_key: Optional API key
            
    Returns:
        Configured connector instance
        
    Raises:
        ValueError: If connector_type is invalid
        
    Example:
        # Create asset connector
        config = {
            'id': 1,
            'api_endpoint': 'http://localhost:5003/api',
            'api_key': 'optional-key'
        }
        connector = get_connector('asset', config)
        
        # Create service connector
        config = {
            'id': 2,
            'api_endpoint': 'http://localhost:5004/api',
            'api_key': None
        }
        connector = get_connector('service', config)
        
        # Create job connector
        config = {
            'id': 3,
            'api_endpoint': 'http://localhost:5005/api'
        }
        connector = get_connector('job', config)
        
        # Create SLA connector
        config = {
            'id': 4,
            'api_endpoint': 'http://localhost:5006/api'
        }
        connector = get_connector('sla', config)
    """
    connector_type = connector_type.lower()
    
    logger.info(f"Creating {connector_type} connector with config: {config}")
    
    if connector_type == 'asset':
        return AssetDataConnector(
            config_id=config['id'],
            api_endpoint=config['api_endpoint'],
            api_key=config.get('api_key')
        )
    
    elif connector_type == 'service':
        return ServiceDataConnector(
            config_id=config['id'],
            api_endpoint=config['api_endpoint'],
            api_key=config.get('api_key')
        )
    
    elif connector_type == 'job':
        return JobDataConnector(
            config_id=config['id'],
            api_endpoint=config['api_endpoint'],
            api_key=config.get('api_key')
        )
    
    elif connector_type == 'sla':
        return SLADataConnector(
            config_id=config['id'],
            api_endpoint=config['api_endpoint'],
            api_key=config.get('api_key')
        )
    
    else:
        raise ValueError(
            f"Unknown connector type: {connector_type}. "
            f"Must be 'asset', 'service', 'job', or 'sla'"
        )


def get_connector_from_db(connector_id: int, db_path: str = None) -> BaseConnector:
    """
    Create connector instance from database configuration
    
    Loads connector configuration from database and instantiates
    the appropriate connector
    
    Args:
        connector_id: ID from connector_configurations table
        db_path: Optional database path
        
    Returns:
        Configured connector instance
        
    Raises:
        Exception: If connector not found or configuration invalid
        
    Example:
        connector = get_connector_from_db(connector_id=1)
        if connector.test_connection():
            data = connector.fetch_data()
    """
    import sqlite3
    import os
    
    if db_path is None:
        db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT id, connector_type, connector_name, platform,
                   api_endpoint_url, api_key, is_active
            FROM connector_configurations
            WHERE id = ?
        ''', (connector_id,))
        
        row = cursor.fetchone()
        
        if not row:
            raise Exception(f"Connector configuration {connector_id} not found")
        
        config = {
            'id': row[0],
            'connector_type': row[1],
            'connector_name': row[2],
            'platform': row[3],
            'api_endpoint': row[4],
            'api_key': row[5],
            'is_active': row[6]
        }
        
        if not config['is_active']:
            logger.warning(f"Connector {connector_id} is inactive")
        
        # Create connector
        connector = get_connector(config['connector_type'], config)
        
        logger.info(f"Created connector from DB: {config['connector_name']} (ID: {connector_id})")
        
        return connector
        
    finally:
        conn.close()


def list_available_connectors(db_path: str = None, connector_type: str = None) -> list:
    """
    Get list of all configured connectors from database
    
    Args:
        db_path: Optional database path
        connector_type: Optional filter by connector type ('asset', 'service', 'job', 'sla')
        
    Returns:
        List of connector configuration dictionaries
        
    Example:
        # Get all connectors
        connectors = list_available_connectors()
        
        # Get only asset connectors
        asset_connectors = list_available_connectors(connector_type='asset')
        
        for conn in connectors:
            print(f"{conn['connector_name']}: {conn['connector_type']}")
    """
    import sqlite3
    import os
    
    if db_path is None:
        db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        if connector_type:
            cursor.execute('''
                SELECT id, connector_type, connector_name, platform,
                       api_endpoint_url, is_active
                FROM connector_configurations
                WHERE connector_type = ?
                ORDER BY connector_name
            ''', (connector_type.lower(),))
        else:
            cursor.execute('''
                SELECT id, connector_type, connector_name, platform,
                       api_endpoint_url, is_active
                FROM connector_configurations
                ORDER BY connector_type, connector_name
            ''')
        
        rows = cursor.fetchall()
        
        connectors = []
        for row in rows:
            connectors.append({
                'id': row[0],
                'connector_type': row[1],
                'connector_name': row[2],
                'platform': row[3],
                'api_endpoint': row[4],
                'is_active': bool(row[5])
            })
        
        return connectors
        
    finally:
        conn.close()


def test_all_connectors(db_path: str = None, connector_type: str = None) -> Dict[int, bool]:
    """
    Test connection for all configured connectors
    
    Args:
        db_path: Optional database path
        connector_type: Optional filter by connector type
        
    Returns:
        Dictionary mapping connector IDs to connection status
        
    Example:
        # Test all connectors
        results = test_all_connectors()
        
        # Test only service connectors
        results = test_all_connectors(connector_type='service')
        
        for connector_id, is_connected in results.items():
            status = "✓" if is_connected else "✗"
            print(f"{status} Connector {connector_id}")
    """
    connectors = list_available_connectors(db_path, connector_type)
    results = {}
    
    for config in connectors:
        if not config['is_active']:
            logger.info(f"Skipping inactive connector: {config['connector_name']}")
            results[config['id']] = False
            continue
        
        try:
            connector = get_connector_from_db(config['id'], db_path)
            is_connected = connector.test_connection()
            results[config['id']] = is_connected
            connector.close()
            
            status = "✓" if is_connected else "✗"
            logger.info(f"{status} {config['connector_name']}: {'connected' if is_connected else 'failed'}")
            
        except Exception as e:
            logger.error(f"Error testing {config['connector_name']}: {str(e)}")
            results[config['id']] = False
    
    return results


def get_connector_with_mappings(connector_id: int, db_path: str = None):
    """
    Create connector instance with field mappings loaded
    
    Args:
        connector_id: ID from connector_configurations table
        db_path: Optional database path
        
    Returns:
        Tuple of (connector instance, field mappings list)
    """
    import sqlite3
    import os
    
    if db_path is None:
        db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Get connector configuration
        cursor.execute('''
            SELECT id, connector_type, connector_name, platform,
                   api_endpoint_url, api_key, is_active
            FROM connector_configurations
            WHERE id = ?
        ''', (connector_id,))
        
        row = cursor.fetchone()
        
        if not row:
            raise Exception(f"Connector configuration {connector_id} not found")
        
        config = {
            'id': row[0],
            'connector_type': row[1],
            'connector_name': row[2],
            'platform': row[3],
            'api_endpoint': row[4],
            'api_key': row[5],
            'is_active': row[6]
        }
        
        # Get field mappings
        cursor.execute('''
            SELECT source_field, target_field, transformation_rule, is_required
            FROM field_mappings
            WHERE connector_config_id = ?
            ORDER BY field_order
        ''', (connector_id,))
        
        field_mappings = []
        for map_row in cursor.fetchall():
            field_mappings.append({
                'source_field': map_row[0],
                'target_field': map_row[1],
                'transformation_rule': map_row[2],
                'is_required': bool(map_row[3])
            })
        
        # Create connector
        connector = get_connector(config['connector_type'], config)
        
        logger.info(f"Created connector with {len(field_mappings)} field mappings: {config['connector_name']} (ID: {connector_id})")
        
        return connector, field_mappings
        
    finally:
        conn.close()


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=" * 60)
    print("Connector Factory - Test Mode")
    print("=" * 60)
    print()
    
    # Example 1: Create all connector types directly
    print("Example 1: Creating all connector types")
    print("-" * 60)
    
    connectors_to_test = [
        ('asset', {'id': 1, 'api_endpoint': 'http://localhost:5003/api'}),
        ('service', {'id': 2, 'api_endpoint': 'http://localhost:5004/api'}),
        ('job', {'id': 3, 'api_endpoint': 'http://localhost:5005/api'}),
        ('sla', {'id': 4, 'api_endpoint': 'http://localhost:5006/api'})
    ]
    
    for conn_type, config in connectors_to_test:
        try:
            conn = get_connector(conn_type, config)
            print(f"✓ Created {conn_type} connector: {conn}")
            
            # Test connection
            if conn.test_connection():
                print(f"  ✓ Connection successful!")
                
                # Fetch sample data
                data = conn.fetch_data()
                print(f"  ✓ Fetched {len(data)} records")
            else:
                print(f"  ✗ Connection failed (simulator may not be running)")
            
            conn.close()
        except Exception as e:
            print(f"✗ Error with {conn_type} connector: {e}")
        
        print()
    
    # Example 2: Test error handling
    print("Example 2: Testing error handling")
    print("-" * 60)
    
    try:
        invalid_conn = get_connector('invalid_type', {})
    except ValueError as e:
        print(f"✓ Correctly caught error: {e}")
    
    print()
    
    # Example 3: List available connectors from database
    print("Example 3: Listing connectors from database")
    print("-" * 60)
    
    try:
        connectors = list_available_connectors()
        if connectors:
            print(f"Found {len(connectors)} configured connector(s):")
            for conn in connectors:
                active = "✓" if conn['is_active'] else "✗"
                print(f"  {active} [{conn['id']}] {conn['connector_name']} ({conn['connector_type']})")
                print(f"      Endpoint: {conn['api_endpoint']}")
        else:
            print("No connectors configured in database yet")
    except Exception as e:
        print(f"Database not accessible: {e}")
        print("(This is expected if database hasn't been created yet)")
    
    print()
    
    # Example 4: List by type
    print("Example 4: Listing connectors by type")
    print("-" * 60)
    
    for conn_type in ['asset', 'service', 'job', 'sla']:
        try:
            type_connectors = list_available_connectors(connector_type=conn_type)
            print(f"{conn_type.upper()}: {len(type_connectors)} connector(s)")
        except Exception as e:
            print(f"{conn_type.upper()}: Database not accessible")
    
    print()
    print("=" * 60)
    print("Factory test complete!")
    print("=" * 60)
