"""
Service Data Connector
Imports service metadata from external service management APIs

Supports importing services and their relationships to assets.
"""

import sqlite3
import os
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from base_connector import BaseConnector

logger = logging.getLogger(__name__)


class ServiceDataConnector(BaseConnector):
    """
    Connector for importing services from external service management systems
    
    Handles fetching service data and bulk importing into the portal database
    with field mapping and transformation support.
    """
    
    def test_connection(self) -> bool:
        """
        Test connection to service API
        
        Returns:
            True if health check succeeds, False otherwise
        """
        try:
            response = self._make_request('GET', '/api/health', timeout=5)
            data = response.json()
            
            # Check if response indicates healthy status
            status = data.get('status', '').lower()
            is_healthy = status in ['healthy', 'ok', 'up']
            
            if is_healthy:
                logger.info(f"✓ Service API connection successful: {data}")
            else:
                logger.warning(f"Service API returned unhealthy status: {data}")
            
            return is_healthy
            
        except Exception as e:
            logger.error(f"Service API connection test failed: {str(e)}")
            return False
    
    def fetch_data(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch services from API (wrapper for fetch_services)
        
        Args:
            filters: Optional filter parameters
            
        Returns:
            List of service objects
        """
        return self.fetch_services(filters)
    
    def fetch_services(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch services from external API
        
        Args:
            filters: Optional filters such as:
                - asset_id: Filter by asset ID
                - service_type: Filter by service type
                - status: Filter by status (active, inactive)
                
        Returns:
            List of service dictionaries
            
        Example:
            services = connector.fetch_services({
                'asset_id': 'ASSET-001',
                'status': 'active'
            })
        """
        try:
            logger.info(f"Fetching services with filters: {filters}")
            
            response = self._make_request('GET', '/api/services', params=filters or {})
            data = response.json()
            
            # Handle different response formats
            if 'services' in data:
                services = data['services']
            elif isinstance(data, list):
                services = data
            else:
                logger.warning(f"Unexpected response format: {data}")
                services = []
            
            logger.info(f"Fetched {len(services)} services")
            return services
            
        except Exception as e:
            logger.error(f"Failed to fetch services: {str(e)}")
            raise Exception(f"Failed to fetch services: {str(e)}")
    
    def fetch_service_by_id(self, service_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch a specific service by ID
        
        Args:
            service_id: Unique identifier for the service
            
        Returns:
            Service dictionary or None if not found
        """
        try:
            logger.info(f"Fetching service: {service_id}")
            
            response = self._make_request('GET', f'/api/services/{service_id}')
            service = response.json()
            
            logger.info(f"Retrieved service: {service.get('service_id')}")
            return service
            
        except Exception as e:
            logger.error(f"Failed to fetch service {service_id}: {str(e)}")
            return None
    
    def bulk_import_services(
        self, 
        org_id: int, 
        services: List[Dict[str, Any]], 
        field_mappings: List[Dict[str, Any]],
        asset_mapping: Dict[str, str] = None,
        db_path: str = None
    ) -> Dict[str, Any]:
        """
        Bulk import services into portal database
        
        Args:
            org_id: Organization ID for imported services
            services: List of service objects from API
            field_mappings: List of field mapping rules
            asset_mapping: Optional mapping of connector asset IDs to portal asset IDs
            db_path: Optional database path (defaults to ../database/sla_portal.db)
            
        Returns:
            Dictionary with import results:
                - imported: Number of successfully imported services
                - failed: Number of failed imports
                - errors: List of error details
                - service_ids: List of created service IDs
        """
        results = {
            'imported': 0,
            'failed': 0,
            'errors': [],
            'service_ids': []
        }
        
        logger.info(f"Starting bulk import of {len(services)} services")
        
        for i, service in enumerate(services, 1):
            try:
                # Apply field mappings
                mapped_service = self._apply_field_mappings(service, field_mappings)
                
                # Validate required fields
                if not mapped_service.get('name'):
                    raise Exception("Service name is required")
                
                # Map asset_id if mapping provided
                if asset_mapping and 'asset_id' in service:
                    connector_asset_id = service['asset_id']
                    portal_asset_id = asset_mapping.get(connector_asset_id)
                    if portal_asset_id:
                        mapped_service['asset_id'] = portal_asset_id
                
                # Insert into database
                service_id = self._insert_service(org_id, mapped_service, db_path)
                
                results['imported'] += 1
                results['service_ids'].append(service_id)
                
                logger.info(f"Imported service {i}/{len(services)}: {mapped_service.get('name')} (ID: {service_id})")
                
            except Exception as e:
                results['failed'] += 1
                error_detail = {
                    'service': service.get('service_name', 'Unknown'),
                    'error': str(e)
                }
                results['errors'].append(error_detail)
                logger.error(f"Failed to import service {i}/{len(services)}: {str(e)}")
        
        logger.info(f"Bulk import completed: {results['imported']} imported, {results['failed']} failed")
        return results
    
    def _insert_service(self, org_id: int, service_data: Dict[str, Any], db_path: str = None) -> str:
        """
        Insert a single service into the database
        
        Args:
            org_id: Organization ID
            service_data: Mapped service data
            db_path: Optional database path
            
        Returns:
            Generated service_id
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        import uuid
        service_id = f"SVC-{uuid.uuid4().hex[:8].upper()}"
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO services (
                    service_id, org_id, asset_id, name,
                    description, is_active,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (
                service_id,
                org_id,
                service_data.get('asset_id'),
                service_data.get('name'),
                service_data.get('description', ''),
                service_data.get('is_active', True)
            ))
            
            conn.commit()
            return service_id
            
        except sqlite3.IntegrityError as e:
            raise Exception(f"Database integrity error: {str(e)}")
        except Exception as e:
            raise Exception(f"Database error: {str(e)}")
        finally:
            conn.close()


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=" * 60)
    print("Service Data Connector - Test Mode")
    print("=" * 60)
    print()
    
    # Create connector instance
    connector = ServiceDataConnector(
        config_id=1,
        api_endpoint='http://localhost:5004/api',
        api_key=None
    )
    
    # Test connection
    print("Testing connection...")
    if connector.test_connection():
        print("✓ Connection successful!")
        
        # Fetch services
        print("\nFetching all services...")
        services = connector.fetch_services()
        print(f"✓ Retrieved {len(services)} services")
        
        if services:
            print("\nFirst service:")
            for key, value in services[0].items():
                print(f"  {key}: {value}")
        
        # Test filtering
        print("\nFetching services for ASSET-001...")
        filtered_services = connector.fetch_services({'asset_id': 'ASSET-001'})
        print(f"✓ Retrieved {len(filtered_services)} services for ASSET-001")
        
    else:
        print("✗ Connection failed")
        print("Make sure service_provider_simulator.py is running on port 5004")
    
    # Close connection
    connector.close()
    
    print()
    print("=" * 60)
    print("Test complete!")
    print("=" * 60)
