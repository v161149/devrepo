"""
Base Connector Class
Foundation for all metadata retrieval connectors

This abstract base class defines the interface that all connectors must implement.
"""

import requests
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BaseConnector(ABC):
    """
    Abstract base class for all data connectors
    
    Attributes:
        config_id (int): Database ID of connector configuration
        api_endpoint (str): Base URL for API endpoint
        api_key (str): Optional API key for authentication
        session (requests.Session): HTTP session for API calls
    """
    
    def __init__(self, config_id: int, api_endpoint: str, api_key: Optional[str] = None):
        """
        Initialize the base connector
        
        Args:
            config_id: ID from connector_configurations table
            api_endpoint: Base URL for the API (e.g., http://localhost:5003/api)
            api_key: Optional API key for authentication
        """
        self.config_id = config_id
        self.api_endpoint = api_endpoint.rstrip('/')  # Remove trailing slash
        self.api_key = api_key
        
        # Create HTTP session with common headers
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'SLA-Portal-Connector/1.0',
            'Accept': 'application/json'
        })
        
        # Add authentication if API key provided
        if api_key:
            self.session.headers.update({
                'Authorization': f'Bearer {api_key}'
            })
        
        logger.info(f"Initialized {self.__class__.__name__} (ID: {config_id})")
    
    @abstractmethod
    def test_connection(self) -> bool:
        """
        Test connection to the API endpoint
        
        Must be implemented by subclasses to test their specific API
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        raise NotImplementedError("Subclasses must implement test_connection()")
    
    @abstractmethod
    def fetch_data(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch data from the API
        
        Must be implemented by subclasses to fetch their specific data type
        
        Args:
            filters: Optional dictionary of filter parameters
            
        Returns:
            List of data objects as dictionaries
        """
        raise NotImplementedError("Subclasses must implement fetch_data()")
    
    def _make_request(
        self, 
        method: str, 
        endpoint: str, 
        params: Optional[Dict] = None,
        timeout: int = 30
    ) -> requests.Response:
        """
        Make HTTP request with error handling
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path (will be appended to base URL)
            params: Optional query parameters
            timeout: Request timeout in seconds
            
        Returns:
            requests.Response object
            
        Raises:
            Exception: If request fails
        """
        url = f"{self.api_endpoint}/{endpoint.lstrip('/')}"
        
        try:
            logger.debug(f"{method} {url} (params: {params})")
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                timeout=timeout
            )
            response.raise_for_status()
            return response
            
        except requests.exceptions.Timeout:
            raise Exception(f"Request timeout after {timeout} seconds")
        except requests.exceptions.ConnectionError:
            raise Exception(f"Connection failed to {url}")
        except requests.exceptions.HTTPError as e:
            raise Exception(f"HTTP error: {e.response.status_code} - {e.response.text}")
        except Exception as e:
            raise Exception(f"Request failed: {str(e)}")
    
    def _apply_field_mappings(
        self, 
        source_data: Dict[str, Any], 
        mappings: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Apply field mappings and transformations to source data
        
        Transforms API response fields into portal database fields using
        configured mapping rules.
        
        Args:
            source_data: Original data object from API
            mappings: List of mapping rules with:
                - source_field: Field name in API response
                - target_field: Field name in portal database
                - transformation_rule: Optional Python expression for transformation
                - is_required: Whether field is required
                
        Returns:
            Dictionary with mapped and transformed data
            
        Example mappings:
            [
                {
                    "source_field": "host_name",
                    "target_field": "asset_name",
                    "transformation_rule": "value.upper()",
                    "is_required": True
                },
                {
                    "source_field": "machine_type",
                    "target_field": "asset_type",
                    "transformation_rule": None,
                    "is_required": True
                }
            ]
        """
        mapped = {}
        
        for mapping in mappings:
            source_field = mapping['source_field']
            target_field = mapping['target_field']
            transformation = mapping.get('transformation_rule')
            is_required = mapping.get('is_required', False)
            
            try:
                # Get value from source data
                value = source_data.get(source_field)
                
                # Check required fields
                if is_required and value is None:
                    logger.warning(f"Required field '{source_field}' is missing")
                    continue
                
                # Apply transformation if specified
                if transformation and value is not None:
                    value = self._apply_transformation(value, transformation, source_data)
                
                # Store mapped value
                mapped[target_field] = value
                
            except Exception as e:
                logger.error(f"Error mapping field '{source_field}': {str(e)}")
                # Skip this field but continue processing
                continue
        
        return mapped
    
    def _apply_transformation(
        self, 
        value: Any, 
        transformation: str, 
        source_data: Dict[str, Any]
    ) -> Any:
        """
        Apply transformation rule to a value
        
        Safely evaluates transformation expressions with limited scope
        
        Args:
            value: The value to transform
            transformation: Python expression (e.g., "value.upper()")
            source_data: Full source object (for accessing other fields)
            
        Returns:
            Transformed value
            
        Example transformations:
            "value.upper()" - Convert to uppercase
            "value.strip()" - Remove whitespace
            "int(value)" - Convert to integer
            "value if value else 'Unknown'" - Provide default
            "response['hostname'] + '-' + response['env']" - Concatenate fields
        """
        # Define safe functions and variables available in transformations
        safe_globals = {
            # Built-in type conversions
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict,
            
            # String operations
            'upper': lambda x: str(x).upper(),
            'lower': lambda x: str(x).lower(),
            'strip': lambda x: str(x).strip(),
            'replace': lambda x, old, new: str(x).replace(old, new),
            
            # Utility functions
            'len': len,
            'max': max,
            'min': min,
        }
        
        # Make value and full response available
        safe_locals = {
            'value': value,
            'response': source_data
        }
        
        try:
            # Evaluate transformation
            result = eval(transformation, safe_globals, safe_locals)
            logger.debug(f"Transformation '{transformation}': {value} -> {result}")
            return result
            
        except Exception as e:
            logger.warning(f"Transformation failed '{transformation}': {str(e)}")
            # Return original value if transformation fails
            return value
    
    def close(self):
        """Close the HTTP session"""
        if self.session:
            self.session.close()
            logger.info(f"Closed session for {self.__class__.__name__}")
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close session"""
        self.close()
    
    def __repr__(self):
        return f"{self.__class__.__name__}(config_id={self.config_id}, endpoint={self.api_endpoint})"


# Example usage:
if __name__ == "__main__":
    print("BaseConnector is an abstract class and cannot be instantiated directly.")
    print("Use AssetDataConnector, ServiceDataConnector, JobDataConnector, SLADataConnector, or SLADataConnector instead.")
    print("\nExample:")
    print("  from asset_data_connector import AssetDataConnector")
    print("  connector = AssetDataConnector(")
    print("      config_id=1,")
    print("      api_endpoint='http://localhost:5003/api'")
    print("  )")
    print("  if connector.test_connection():")
    print("      assets = connector.fetch_assets()")
