"""
Service/Job Data Connector
Imports services and jobs from job orchestration platforms

Supports: Autosys, Ansible Tower, and Custom APIs
Automatically converts platform-specific formats to portal standard format
"""

import sqlite3
import os
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from base_connector import BaseConnector

logger = logging.getLogger(__name__)


class ServiceJobDataConnector(BaseConnector):
    """
    Connector for importing services and jobs from job orchestration platforms
    
    Supports multiple platforms:
    - Autosys: Job scheduling platform
    - Ansible Tower: Automation platform
    - Custom: Generic job APIs
    """
    
    def __init__(
        self, 
        config_id: int, 
        platform: str, 
        api_endpoint: str, 
        api_key: Optional[str] = None
    ):
        """
        Initialize service/job connector
        
        Args:
            config_id: Database configuration ID
            platform: Platform type ('autosys', 'ansible_tower', or 'custom')
            api_endpoint: API base URL
            api_key: Optional API authentication key
        """
        super().__init__(config_id, api_endpoint, api_key)
        
        self.platform = platform.lower()
        
        if self.platform not in ['autosys', 'ansible_tower', 'custom']:
            raise ValueError(f"Unsupported platform: {platform}. Must be autosys, ansible_tower, or custom")
        
        logger.info(f"Initialized {self.platform} connector")
    
    def test_connection(self) -> bool:
        """
        Test connection based on platform
        
        Each platform has different health check endpoints
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            if self.platform == 'autosys':
                response = self._make_request('GET', '/api/v1/health', timeout=5)
            elif self.platform == 'ansible_tower':
                response = self._make_request('GET', '/api/v2/ping/', timeout=5)
            else:  # custom
                response = self._make_request('GET', '/health', timeout=5)
            
            data = response.json()
            status = data.get('status', '').lower()
            is_healthy = status in ['healthy', 'ok', 'up']
            
            if is_healthy:
                logger.info(f"{self.platform} API connection successful")
            else:
                logger.warning(f"{self.platform} API returned unhealthy status: {data}")
            
            return is_healthy
            
        except Exception as e:
            logger.error(f"{self.platform} API connection test failed: {str(e)}")
            return False
    
    def fetch_data(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch jobs from API (wrapper for fetch_jobs)
        
        Args:
            filters: Optional filter parameters
            
        Returns:
            List of standardized job objects
        """
        return self.fetch_jobs(filters)
    
    def fetch_jobs(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch jobs based on platform
        
        Automatically routes to correct platform-specific method
        and standardizes the response format
        
        Args:
            filters: Platform-specific filters
            
        Returns:
            List of standardized job objects
        """
        if self.platform == 'autosys':
            return self._fetch_autosys_jobs(filters)
        elif self.platform == 'ansible_tower':
            return self._fetch_ansible_jobs(filters)
        else:  # custom
            return self._fetch_custom_jobs(filters)
    
    # ==========================================
    # AUTOSYS PLATFORM METHODS
    # ==========================================
    
    def _fetch_autosys_jobs(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch jobs from Autosys platform
        
        Args:
            filters: Autosys-specific filters:
                - job_type: CMD, BOX, FW
                - status: ACTIVATED, INACTIVE
                - owner: Job owner/team
                
        Returns:
            List of standardized job objects
        """
        try:
            logger.info(f"Fetching Autosys jobs with filters: {filters}")
            
            response = self._make_request('GET', '/api/v1/jobs', params=filters or {})
            data = response.json()
            
            jobs = data.get('jobs', [])
            logger.info(f"Fetched {len(jobs)} Autosys jobs")
            
            # Standardize format
            standardized = [self._standardize_autosys_job(job) for job in jobs]
            
            return standardized
            
        except Exception as e:
            logger.error(f"Failed to fetch Autosys jobs: {str(e)}")
            raise Exception(f"Failed to fetch Autosys jobs: {str(e)}")
    
    def _standardize_autosys_job(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert Autosys job format to portal standard format
        
        Args:
            job: Raw Autosys job object
            
        Returns:
            Standardized job object
        """
        return {
            'job_name': job.get('name'),
            'job_type': self._map_autosys_job_type(job.get('job_type')),
            'description': job.get('description', ''),
            'schedule': self._convert_autosys_schedule(job),
            'execution_time': self._parse_autosys_duration(job.get('max_run_alarm')),
            'owner_team': job.get('owner', 'Unknown'),
            'deployment_location': job.get('machine', 'autosys'),
            'platform': 'autosys',
            'platform_job_id': job.get('name'),
            'status': job.get('status', 'UNKNOWN'),
            'last_start': job.get('last_start'),
            'last_end': job.get('last_end'),
            'last_status': job.get('last_status'),
            'command': job.get('command'),
            'run_calendar': job.get('run_calendar')
        }
    
    def _map_autosys_job_type(self, autosys_type: str) -> str:
        """
        Map Autosys job types to portal job types
        
        Args:
            autosys_type: Autosys job type (CMD, BOX, FW)
            
        Returns:
            Portal job type
        """
        mapping = {
            'CMD': 'etl_batch',
            'BOX': 'box',
            'FW': 'file_watcher'
        }
        return mapping.get(autosys_type, 'etl_batch')
    
    def _convert_autosys_schedule(self, job: Dict[str, Any]) -> str:
        """
        Convert Autosys schedule format to cron format
        
        Args:
            job: Autosys job object
            
        Returns:
            Cron expression string
        """
        start_times = job.get('start_times', ['00:00'])
        hour, minute = start_times[0].split(':')
        
        # Convert days of week
        days_of_week = job.get('days_of_week', [])
        if not days_of_week or 'all' in str(job.get('run_calendar', '')).lower():
            weekday = '*'
        else:
            day_map = {
                'mo': '1', 'tu': '2', 'we': '3', 'th': '4',
                'fr': '5', 'sa': '6', 'su': '0'
            }
            weekday = ','.join([day_map.get(d.lower(), '*') for d in days_of_week])
        
        # Cron format: minute hour day month weekday
        return f"{minute} {hour} * * {weekday}"
    
    def _parse_autosys_duration(self, max_run_alarm: str) -> str:
        """
        Convert Autosys max_run_alarm (minutes) to HH:MM:SS
        
        Args:
            max_run_alarm: Duration in minutes as string
            
        Returns:
            Duration in HH:MM:SS format
        """
        if not max_run_alarm:
            return "01:00:00"
        
        try:
            minutes = int(max_run_alarm)
            hours = minutes // 60
            mins = minutes % 60
            return f"{hours:02d}:{mins:02d}:00"
        except:
            return "01:00:00"
    
    # ==========================================
    # ANSIBLE TOWER PLATFORM METHODS
    # ==========================================
    
    def _fetch_ansible_jobs(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch job templates from Ansible Tower
        
        Args:
            filters: Ansible-specific filters:
                - project: Filter by project name
                - name: Filter by template name
                
        Returns:
            List of standardized job objects
        """
        try:
            logger.info(f"Fetching Ansible Tower job templates with filters: {filters}")
            
            response = self._make_request('GET', '/api/v2/job_templates/', params=filters or {})
            data = response.json()
            
            templates = data.get('results', [])
            logger.info(f"Fetched {len(templates)} Ansible Tower job templates")
            
            # Standardize format
            standardized = [self._standardize_ansible_job(t) for t in templates]
            
            return standardized
            
        except Exception as e:
            logger.error(f"Failed to fetch Ansible Tower jobs: {str(e)}")
            raise Exception(f"Failed to fetch Ansible Tower jobs: {str(e)}")
    
    def _standardize_ansible_job(self, template: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert Ansible Tower job template to portal standard format
        
        Args:
            template: Raw Ansible Tower job template
            
        Returns:
            Standardized job object
        """
        return {
            'job_name': template.get('name'),
            'job_type': 'ansible_playbook',
            'description': template.get('description', ''),
            'schedule': '0 0 * * *',  # Default daily, can fetch from schedules API
            'execution_time': '00:30:00',  # Default 30 minutes
            'owner_team': 'Ansible Team',
            'deployment_location': 'ansible',
            'platform': 'ansible_tower',
            'platform_job_id': str(template.get('id')),
            'playbook': template.get('playbook'),
            'project_name': template.get('project_name'),
            'inventory': template.get('inventory'),
            'enabled': template.get('enabled', True)
        }
    
    # ==========================================
    # CUSTOM PLATFORM METHODS
    # ==========================================
    
    def _fetch_custom_jobs(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch jobs from custom API
        
        Args:
            filters: Custom API filters
            
        Returns:
            List of job objects (assumes already in standard format)
        """
        try:
            logger.info(f"Fetching custom API jobs with filters: {filters}")
            
            response = self._make_request('GET', '/jobs', params=filters or {})
            jobs = response.json()
            
            if not isinstance(jobs, list):
                jobs = jobs.get('jobs', jobs.get('data', []))
            
            logger.info(f"Fetched {len(jobs)} custom API jobs")
            return jobs
            
        except Exception as e:
            logger.error(f"Failed to fetch custom API jobs: {str(e)}")
            raise Exception(f"Failed to fetch custom API jobs: {str(e)}")
    
    # ==========================================
    # BULK IMPORT METHODS
    # ==========================================
    
    def bulk_import_services_jobs(
        self,
        org_id: int,
        jobs: List[Dict[str, Any]],
        asset_mapping: Dict[str, int],
        field_mappings: List[Dict[str, Any]],
        db_path: str = None
    ) -> Dict[str, Any]:
        """
        Bulk import services and jobs into portal database
        
        Creates a service for each asset, then adds jobs to those services
        
        Args:
            org_id: Organization ID
            jobs: List of job objects from API
            asset_mapping: Maps job_name to asset_id (e.g., {"job1": 123, "job2": 456})
            field_mappings: Field mapping rules
            db_path: Optional database path
            
        Returns:
            Dictionary with results:
                - services_created: Number of services created
                - jobs_created: Number of jobs created
                - failed: Number of failed imports
                - errors: List of error details
                - service_ids: List of created service IDs
        """
        results = {
            'services_created': 0,
            'jobs_created': 0,
            'failed': 0,
            'errors': [],
            'service_ids': []
        }
        
        logger.info(f"Starting bulk import of {len(jobs)} jobs")
        
        # Group jobs by asset
        asset_groups = {}
        for job in jobs:
            job_name = job.get('job_name')
            asset_id = asset_mapping.get(job_name)
            
            if not asset_id:
                logger.warning(f"No asset mapping for job: {job_name}")
                results['failed'] += 1
                results['errors'].append({
                    'job': job_name,
                    'error': 'No asset mapping provided'
                })
                continue
            
            if asset_id not in asset_groups:
                asset_groups[asset_id] = []
            asset_groups[asset_id].append(job)
        
        # Process each asset group
        for asset_id, job_list in asset_groups.items():
            try:
                # Create service for this asset/platform combination
                service_data = {
                    'name': f"{job_list[0].get('platform', 'Unknown').title()} Jobs",
                    'service_type': job_list[0].get('job_type', 'etl_batch'),
                    'owner_team': job_list[0].get('owner_team', 'Unknown'),
                    'deployment_location': job_list[0].get('deployment_location', 'unknown'),
                    'monitoring_method': 'indirect',
                    'asset_id': asset_id
                }
                
                service_id = self._insert_service(org_id, service_data, db_path)
                results['services_created'] += 1
                results['service_ids'].append(service_id)
                
                logger.info(f"Created service {service_id} for asset {asset_id}")
                
                # Create each job under this service
                for job in job_list:
                    try:
                        # Apply field mappings if provided
                        if field_mappings:
                            mapped_job = self._apply_field_mappings(job, field_mappings)
                        else:
                            mapped_job = job
                        
                        mapped_job['service_id'] = service_id
                        
                        job_id = self._insert_job(mapped_job, db_path)
                        results['jobs_created'] += 1
                        
                        logger.info(f"Created job: {mapped_job.get('job_name')} (ID: {job_id})")
                        
                    except Exception as e:
                        results['failed'] += 1
                        results['errors'].append({
                            'job': job.get('job_name'),
                            'error': str(e)
                        })
                        logger.error(f"Failed to import job {job.get('job_name')}: {str(e)}")
                
            except Exception as e:
                results['failed'] += len(job_list)
                results['errors'].append({
                    'asset_id': asset_id,
                    'job_count': len(job_list),
                    'error': str(e)
                })
                logger.error(f"Failed to process asset {asset_id}: {str(e)}")
        
        logger.info(f"Bulk import complete: {results['services_created']} services, " +
                   f"{results['jobs_created']} jobs created, {results['failed']} failed")
        
        return results
    
    def _insert_service(
        self,
        org_id: int,
        service_data: Dict[str, Any],
        db_path: str = None
    ) -> int:
        """
        Insert service into database
        
        Args:
            org_id: Organization ID
            service_data: Service data dictionary
            db_path: Optional database path
            
        Returns:
            Created service ID
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO services (
                    org_id, name, service_type, owner_team,
                    deployment_location, monitoring_method, asset_id,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            ''', (
                org_id,
                service_data['name'],
                service_data['service_type'],
                service_data['owner_team'],
                service_data['deployment_location'],
                service_data['monitoring_method'],
                service_data['asset_id']
            ))
            
            service_id = cursor.lastrowid
            conn.commit()
            
            return service_id
            
        except Exception as e:
            conn.rollback()
            raise Exception(f"Failed to insert service: {str(e)}")
        finally:
            conn.close()
    
    def _insert_job(self, job_data: Dict[str, Any], db_path: str = None) -> int:
        """
        Insert job into database
        
        Args:
            job_data: Job data dictionary (must include service_id)
            db_path: Optional database path
            
        Returns:
            Created job ID
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO jobs (
                    job_name, job_type, schedule, execution_time,
                    description, service_id, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            ''', (
                job_data.get('job_name'),
                job_data.get('job_type'),
                job_data.get('schedule'),
                job_data.get('execution_time'),
                job_data.get('description', ''),
                job_data.get('service_id')
            ))
            
            job_id = cursor.lastrowid
            conn.commit()
            
            return job_id
            
        except Exception as e:
            conn.rollback()
            raise Exception(f"Failed to insert job: {str(e)}")
        finally:
            conn.close()


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=" * 60)
    print("Service/Job Data Connector - Test Mode")
    print("=" * 60)
    print()
    
    # Test Autosys connector
    print("Testing Autosys Connector...")
    autosys = ServiceJobDataConnector(
        config_id=1,
        platform='autosys',
        api_endpoint='http://localhost:5001'
    )
    
    if autosys.test_connection():
        print("✓ Autosys connection successful!")
        
        jobs = autosys.fetch_jobs()
        print(f"✓ Fetched {len(jobs)} Autosys jobs")
        
        if jobs:
            print("\nFirst Autosys job (standardized):")
            for key, value in list(jobs[0].items())[:5]:
                print(f"  {key}: {value}")
    else:
        print("✗ Autosys connection failed!")
    
    print()
    
    # Test Ansible Tower connector
    print("Testing Ansible Tower Connector...")
    ansible = ServiceJobDataConnector(
        config_id=2,
        platform='ansible_tower',
        api_endpoint='http://localhost:5002'
    )
    
    if ansible.test_connection():
        print("✓ Ansible Tower connection successful!")
        
        templates = ansible.fetch_jobs()
        print(f"✓ Fetched {len(templates)} Ansible job templates")
        
        if templates:
            print("\nFirst Ansible job (standardized):")
            for key, value in list(templates[0].items())[:5]:
                print(f"  {key}: {value}")
    else:
        print("✗ Ansible Tower connection failed!")
    
    print()
    print("=" * 60)
    print("Test complete!")
    print("=" * 60)
    
    # Close connectors
    autosys.close()
    ansible.close()
