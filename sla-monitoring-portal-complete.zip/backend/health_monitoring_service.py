"""
Health Monitoring Service - Enhanced with SLA Evaluation
Periodically checks the health of all registered services
NOW INCLUDES: Per-SLA compliance tracking for each service health check
"""

import threading
import time
import logging
import requests
from datetime import datetime
from typing import Dict, Optional
import json
import uuid

# Import enhanced SLA evaluator
from enhanced_sla_evaluator import EnhancedSLAEvaluator

logger = logging.getLogger(__name__)

class HealthMonitoringService:
    def __init__(self, db_service, check_interval=60):
        """
        Initialize health monitoring service
        
        Args:
            db_service: Database service instance
            check_interval: Interval in seconds between health checks (default: 60)
        """
        self.db_service = db_service
        self.check_interval = check_interval
        self.running = False
        self.thread = None
        
        # ===== NEW: Initialize Enhanced SLA Evaluator =====
        self.sla_evaluator = EnhancedSLAEvaluator(db_service)
        logger.info("Enhanced SLA Evaluator initialized")
        
    def start(self):
        """Start the health monitoring service"""
        if self.running:
            logger.warning("Health monitoring service is already running")
            return
            
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        logger.info(f"Health monitoring service started (interval: {self.check_interval}s)")
        
    def stop(self):
        """Stop the health monitoring service"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Health monitoring service stopped")
        
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                self._check_all_services()
            except Exception as e:
                logger.error(f"Error in health monitoring loop: {e}")
            
            # Sleep until next check
            time.sleep(self.check_interval)
            
    def _check_all_services(self):
        """Check health of all services"""
        # Get all services from all organizations
        with self.db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT service_id, org_id, name, metadata 
                FROM services 
                WHERE is_active = 1
            """)
            services = cursor.fetchall()
            
        logger.info(f"Checking health of {len(services)} services...")
        
        for service_row in services:
            service_id = service_row['service_id']
            org_id = service_row['org_id']
            name = service_row['name']
            metadata_raw = service_row['metadata']
            
            try:
                # Parse metadata
                if not metadata_raw:
                    continue
                    
                metadata = json.loads(metadata_raw)
                service_type = metadata.get('service_type')
                config = metadata.get('config', {})
                
                # Check health based on service type
                health_status = self._check_service_health(service_type, config)
                
                # Update service health status
                self._update_service_health(service_id, org_id, health_status)
                
                # ===== NEW: CREATE MONITORING RESULT FOR SLA EVALUATION =====
                try:
                    monitoring_result_id = self._create_monitoring_result_for_sla(
                        service_id, org_id, health_status
                    )
                    
                    if monitoring_result_id:
                        # Prepare parsed data for SLA evaluation
                        parsed_data = {
                            'status': self._map_health_status_to_sla_status(health_status['status']),
                            'response_time_ms': health_status.get('response_time', 0) * 1000,  # Convert to ms
                            'message': health_status.get('message', ''),
                            'checked_at': health_status.get('checked_at'),
                            'service_type': service_type
                        }
                        
                        # Evaluate ALL SLAs for this service
                        compliance_results = self.sla_evaluator.evaluate_service_slas(
                            service_id=service_id,
                            monitoring_result_id=monitoring_result_id,
                            parsed_log_data=parsed_data,
                            org_id=org_id
                        )
                        
                        # Log summary
                        if compliance_results:
                            breached = [c for c in compliance_results if not c['met_sla']]
                            if breached:
                                logger.warning(
                                    f"Service {name}: {len(breached)}/{len(compliance_results)} SLAs BREACHED"
                                )
                            else:
                                logger.info(
                                    f"Service {name}: All {len(compliance_results)} SLAs met"
                                )
                                
                except Exception as e:
                    logger.error(f"Error evaluating SLAs for service {name}: {e}")
                # ===== END NEW CODE =====
                
                logger.debug(f"Service {name} ({service_id}): {health_status['status']}")
                
            except Exception as e:
                logger.error(f"Error checking service {name} ({service_id}): {e}")
                self._update_service_health(service_id, org_id, {
                    'status': 'unknown',
                    'message': f'Health check error: {str(e)}',
                    'checked_at': datetime.now().isoformat()
                })
    
    def _map_health_status_to_sla_status(self, health_status: str) -> str:
        """
        Map health monitoring status to SLA evaluation status
        
        Args:
            health_status: 'healthy', 'unhealthy', 'unknown'
            
        Returns:
            SLA-compatible status
        """
        status_map = {
            'healthy': 'up',
            'unhealthy': 'down',
            'unknown': 'unknown'
        }
        return status_map.get(health_status, 'unknown')
    
    def _create_monitoring_result_for_sla(
        self,
        service_id: str,
        org_id: str,
        health_status: Dict
    ) -> Optional[str]:
        """
        Create a monitoring result record for SLA evaluation
        
        Args:
            service_id: Service ID
            org_id: Organization ID
            health_status: Health status dict
            
        Returns:
            Monitoring result ID or None
        """
        try:
            result_id = f"RES-{uuid.uuid4().hex[:16].upper()}"
            
            # Map health status to service monitoring status
            status_map = {
                'healthy': 'up',
                'unhealthy': 'down',
                'unknown': 'unknown'
            }
            status = status_map.get(health_status['status'], 'unknown')
            
            # Store monitoring result
            with self.db_service.get_connection() as conn:
                conn.execute("""
                    INSERT INTO service_monitoring_results (
                        result_id, service_id, org_id, check_time,
                        status, response_time_ms, log_entry, parsed_data
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    result_id,
                    service_id,
                    org_id,
                    datetime.now().isoformat(),
                    status,
                    health_status.get('response_time', 0) * 1000 if health_status.get('response_time') else None,
                    json.dumps({'health_check': True, 'message': health_status.get('message')}),
                    json.dumps({
                        'status': status,
                        'message': health_status.get('message'),
                        'response_time': health_status.get('response_time')
                    })
                ))
            
            logger.debug(f"Created monitoring result {result_id} for service {service_id}")
            return result_id
            
        except Exception as e:
            logger.error(f"Error creating monitoring result: {e}")
            return None
                
    def _check_service_health(self, service_type: str, config: Dict) -> Dict:
        """
        Check health of a specific service
        
        Returns:
            Dict with 'status' ('healthy', 'unhealthy', 'unknown'), 'message', 'checked_at'
        """
        checked_at = datetime.now().isoformat()
        
        # HTTP-based services
        if service_type in ['api_gateway', 'microservice', 'nginx', 'apache', 'esb']:
            url = config.get('url')
            endpoint = config.get('health_endpoint') or config.get('status_endpoint')
            
            if not url:
                return {
                    'status': 'unknown',
                    'message': 'No URL configured',
                    'checked_at': checked_at
                }
                
            try:
                # Construct full URL
                test_url = url
                if endpoint:
                    if not url.endswith('/'):
                        test_url += '/'
                    if endpoint.startswith('/'):
                        endpoint = endpoint[1:]
                    test_url += endpoint
                    
                # Make HTTP request with short timeout
                response = requests.get(test_url, timeout=5, verify=False)
                
                if response.status_code in [200, 201, 204]:
                    return {
                        'status': 'healthy',
                        'message': f'HTTP {response.status_code}',
                        'response_time': response.elapsed.total_seconds(),
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'HTTP {response.status_code}',
                        'checked_at': checked_at
                    }
                    
            except requests.exceptions.Timeout:
                return {
                    'status': 'unhealthy',
                    'message': 'Connection timeout',
                    'checked_at': checked_at
                }
            except requests.exceptions.ConnectionError:
                return {
                    'status': 'unhealthy',
                    'message': 'Connection refused',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)}',
                    'checked_at': checked_at
                }
        
        # MySQL / Aurora Database
        elif service_type in ['mysql', 'aurora']:
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import pymysql
                start_time = datetime.now()
                
                connection = pymysql.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                with connection.cursor() as cursor:
                    cursor.execute("SELECT 1")
                
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'pymysql driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e)
                if 'Access denied' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif "Can't connect" in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
        
        # PostgreSQL Database
        elif service_type == 'postgresql':
            host = config.get('host') or config.get('endpoint')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            if not all([host, port, database, username, password]):
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import psycopg2
                start_time = datetime.now()
                
                connection = psycopg2.connect(
                    host=host,
                    port=int(port),
                    user=username,
                    password=password,
                    database=database,
                    connect_timeout=5
                )
                
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                cursor.close()
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'psycopg2 driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                error_msg = str(e).lower()
                if 'authentication failed' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Authentication failed',
                        'checked_at': checked_at
                    }
                elif 'could not connect' in error_msg:
                    return {
                        'status': 'unhealthy',
                        'message': 'Connection refused',
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': f'Error: {str(e)[:50]}',
                        'checked_at': checked_at
                    }
        
        # MongoDB
        elif service_type == 'mongodb':
            host = config.get('host') or config.get('connection_string')
            port = config.get('port')
            database = config.get('database')
            username = config.get('username')
            password = config.get('password')
            
            try:
                from pymongo import MongoClient
                import pymongo
                
                start_time = datetime.now()
                
                # Build connection string
                if host and host.startswith('mongodb://'):
                    connection_string = host
                else:
                    if username and password:
                        connection_string = f"mongodb://{username}:{password}@{host}:{port}"
                    else:
                        connection_string = f"mongodb://{host}:{port}"
                
                client = MongoClient(connection_string, serverSelectionTimeoutMS=5000)
                # Ping to verify connection
                client.admin.command('ping')
                
                response_time = (datetime.now() - start_time).total_seconds()
                client.close()
                
                return {
                    'status': 'healthy',
                    'message': 'Database responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'pymongo driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)[:50]}',
                    'checked_at': checked_at
                }
        
        # Redis
        elif service_type == 'redis':
            host = config.get('host')
            port = config.get('port')
            password = config.get('password')
            
            if not host or not port:
                return {
                    'status': 'unknown',
                    'message': 'Incomplete configuration',
                    'checked_at': checked_at
                }
            
            try:
                import redis
                start_time = datetime.now()
                
                r = redis.Redis(
                    host=host,
                    port=int(port),
                    password=password,
                    socket_connect_timeout=5
                )
                
                # Ping to verify connection
                r.ping()
                
                response_time = (datetime.now() - start_time).total_seconds()
                r.close()
                
                return {
                    'status': 'healthy',
                    'message': 'Cache responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'redis driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)[:50]}',
                    'checked_at': checked_at
                }
        
        # Kafka
        elif service_type == 'kafka':
            bootstrap_servers = config.get('bootstrap_servers') or config.get('brokers')
            
            if not bootstrap_servers:
                return {
                    'status': 'unknown',
                    'message': 'No bootstrap servers configured',
                    'checked_at': checked_at
                }
            
            try:
                from kafka import KafkaAdminClient
                start_time = datetime.now()
                
                # Convert string to list if necessary
                if isinstance(bootstrap_servers, str):
                    bootstrap_servers = [s.strip() for s in bootstrap_servers.split(',')]
                
                admin_client = KafkaAdminClient(
                    bootstrap_servers=bootstrap_servers,
                    request_timeout_ms=5000
                )
                
                # List topics to verify connection
                topics = admin_client.list_topics()
                
                response_time = (datetime.now() - start_time).total_seconds()
                admin_client.close()
                
                return {
                    'status': 'healthy',
                    'message': f'Kafka responding ({len(topics)} topics)',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'kafka-python driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)[:50]}',
                    'checked_at': checked_at
                }
        
        # RabbitMQ
        elif service_type == 'rabbitmq':
            host = config.get('host')
            port = config.get('port', 5672)
            username = config.get('username')
            password = config.get('password')
            vhost = config.get('vhost', '/')
            
            if not host:
                return {
                    'status': 'unknown',
                    'message': 'No host configured',
                    'checked_at': checked_at
                }
            
            try:
                import pika
                start_time = datetime.now()
                
                credentials = pika.PlainCredentials(username, password) if username and password else None
                
                parameters = pika.ConnectionParameters(
                    host=host,
                    port=int(port),
                    virtual_host=vhost,
                    credentials=credentials,
                    connection_attempts=1,
                    socket_timeout=5
                )
                
                connection = pika.BlockingConnection(parameters)
                connection.close()
                
                response_time = (datetime.now() - start_time).total_seconds()
                
                return {
                    'status': 'healthy',
                    'message': 'Message broker responding',
                    'response_time': response_time,
                    'checked_at': checked_at
                }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'pika driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)[:50]}',
                    'checked_at': checked_at
                }
        
        # Elasticsearch
        elif service_type == 'elasticsearch':
            hosts = config.get('hosts') or config.get('host')
            
            if not hosts:
                return {
                    'status': 'unknown',
                    'message': 'No hosts configured',
                    'checked_at': checked_at
                }
            
            try:
                from elasticsearch import Elasticsearch
                start_time = datetime.now()
                
                # Convert string to list if necessary
                if isinstance(hosts, str):
                    hosts = [hosts]
                
                es = Elasticsearch(hosts, timeout=5)
                
                # Ping to verify connection
                if es.ping():
                    response_time = (datetime.now() - start_time).total_seconds()
                    es.close()
                    
                    return {
                        'status': 'healthy',
                        'message': 'Search engine responding',
                        'response_time': response_time,
                        'checked_at': checked_at
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': 'Ping failed',
                        'checked_at': checked_at
                    }
                
            except ImportError:
                return {
                    'status': 'unknown',
                    'message': 'elasticsearch driver not installed',
                    'checked_at': checked_at
                }
            except Exception as e:
                return {
                    'status': 'unhealthy',
                    'message': f'Error: {str(e)[:50]}',
                    'checked_at': checked_at
                }
        
        # Unknown service type
        else:
            return {
                'status': 'unknown',
                'message': f'Unsupported service type: {service_type}',
                'checked_at': checked_at
            }
                
    def _update_service_health(self, service_id: str, org_id: str, health_status: Dict):
        """
        Update service health status in database
        
        Args:
            service_id: ID of the service
            org_id: Organization ID
            health_status: Health status dict with 'status', 'message', 'checked_at'
        """
        with self.db_service.get_connection() as conn:
            # Check if record exists
            cursor = conn.execute("""
                SELECT health_check_id FROM service_health_checks 
                WHERE service_id = ? AND org_id = ?
            """, (service_id, org_id))
            
            existing = cursor.fetchone()
            
            if existing:
                # Update existing record
                conn.execute("""
                    UPDATE service_health_checks 
                    SET status = ?, 
                        message = ?, 
                        response_time = ?,
                        checked_at = ?,
                        updated_at = ?
                    WHERE service_id = ? AND org_id = ?
                """, (
                    health_status['status'],
                    health_status['message'],
                    health_status.get('response_time'),
                    health_status['checked_at'],
                    datetime.now().isoformat(),
                    service_id,
                    org_id
                ))
            else:
                # Insert new record
                import uuid
                health_check_id = f"hc-{uuid.uuid4().hex[:8]}"
                conn.execute("""
                    INSERT INTO service_health_checks 
                    (health_check_id, service_id, org_id, status, message, response_time, checked_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    health_check_id,
                    service_id,
                    org_id,
                    health_status['status'],
                    health_status['message'],
                    health_status.get('response_time'),
                    health_status['checked_at']
                ))
                
    def check_service_now(self, service_id: str) -> Optional[Dict]:
        """
        Manually trigger health check for a specific service
        
        Args:
            service_id: ID of service to check
            
        Returns:
            Health status dict or None if service not found
        """
        with self.db_service.get_connection() as conn:
            cursor = conn.execute("""
                SELECT service_id, org_id, name, metadata 
                FROM services 
                WHERE service_id = ? AND is_active = 1
            """, (service_id,))
            
            service_row = cursor.fetchone()
            
            if not service_row:
                return None
                
            metadata_raw = service_row['metadata']
            if not metadata_raw:
                return None
                
            metadata = json.loads(metadata_raw)
            service_type = metadata.get('service_type')
            config = metadata.get('config', {})
            
            # Check health
            health_status = self._check_service_health(service_type, config)
            
            # Update database
            self._update_service_health(service_id, service_row['org_id'], health_status)
            
            return health_status
