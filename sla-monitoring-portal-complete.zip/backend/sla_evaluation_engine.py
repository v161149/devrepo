"""
SLA Evaluation Engine Microservice
Evaluates SLA compliance based on incoming events and SLA definitions
"""

import uuid
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging
from database_service import DatabaseService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SLAEvaluationEngine:
    def __init__(self, db_service: DatabaseService):
        self.db = db_service
    
    def process_event(self, event_data: Dict) -> List[Dict]:
        """
        Process incoming event and evaluate against applicable SLAs
        Returns list of created/updated evaluations
        """
        evaluations = []
        
        # Get applicable SLAs for this service
        slas = self.db.get_slas_by_service(event_data['service_id'])
        
        for sla in slas:
            # Check if event matches SLA conditions
            if self._matches_start_condition(event_data, sla):
                evaluation = self._start_evaluation(event_data, sla)
                evaluations.append(evaluation)
                logger.info(f"Started evaluation {evaluation['evaluation_id']} for SLA {sla['sla_id']}")
            
            elif self._matches_stop_condition(event_data, sla):
                evaluation = self._stop_evaluation(event_data, sla)
                if evaluation:
                    evaluations.append(evaluation)
                    logger.info(f"Stopped evaluation {evaluation['evaluation_id']} for SLA {sla['sla_id']}")
        
        return evaluations
    
    def _matches_start_condition(self, event: Dict, sla: Dict) -> bool:
        """Check if event matches SLA start condition"""
        start_cond = sla['start_condition']
        
        # Match event type
        if start_cond.get('event_type') != event['event_type']:
            return False
        
        # Match priority if specified
        if 'priority' in start_cond:
            if start_cond['priority'] != event.get('priority'):
                return False
        
        # Match any additional conditions
        if 'attributes' in start_cond:
            for key, value in start_cond['attributes'].items():
                event_attrs = event.get('normalized_data', {})
                if event_attrs.get(key) != value:
                    return False
        
        return True
    
    def _matches_stop_condition(self, event: Dict, sla: Dict) -> bool:
        """Check if event matches SLA stop condition"""
        stop_cond = sla['stop_condition']
        
        # Match event type
        if stop_cond.get('event_type') != event['event_type']:
            return False
        
        return True
    
    def _start_evaluation(self, event: Dict, sla: Dict) -> Dict:
        """Start a new SLA evaluation"""
        evaluation_id = f"eval-{uuid.uuid4().hex[:12]}"
        
        evaluation_data = {
            'evaluation_id': evaluation_id,
            'org_id': event['org_id'],
            'sla_id': sla['sla_id'],
            'event_id': event['event_id'],
            'service_id': event['service_id'],
            'customer_id': event.get('customer_id'),
            'start_timestamp': event['timestamp'],
            'status': 'active',
            'details': {
                'start_event': event['event_id'],
                'start_event_type': event['event_type']
            }
        }
        
        self.db.create_evaluation(evaluation_data)
        return evaluation_data
    
    def _stop_evaluation(self, event: Dict, sla: Dict) -> Optional[Dict]:
        """Stop an active SLA evaluation and calculate results"""
        # Find active evaluation for this SLA and service
        evaluations = self.db.get_evaluations(
            event['org_id'],
            filters={'sla_id': sla['sla_id'], 'service_id': event['service_id']}
        )
        
        # Find most recent active evaluation
        active_eval = None
        for evaluation in evaluations:
            if evaluation['status'] == 'active' and not evaluation['stop_timestamp']:
                active_eval = evaluation
                break
        
        if not active_eval:
            logger.warning(f"No active evaluation found for SLA {sla['sla_id']}")
            return None
        
        # Calculate duration
        start_time = datetime.fromisoformat(active_eval['start_timestamp'])
        stop_time = datetime.fromisoformat(event['timestamp'])
        total_duration = (stop_time - start_time).total_seconds()
        
        # Calculate business duration if business hours defined
        business_duration = total_duration
        if sla.get('business_hours_id'):
            business_duration = self._calculate_business_duration(
                start_time, stop_time, sla['business_hours_id']
            )
        
        # Determine if breach occurred
        target_seconds = self._convert_to_seconds(sla['target_value'], sla['target_unit'])
        is_breach = business_duration > target_seconds
        breach_percentage = (business_duration / target_seconds * 100) if target_seconds > 0 else 0
        
        # Update evaluation
        # Parse existing details
        existing_details = active_eval['details']
        if isinstance(existing_details, str):
            existing_details = json.loads(existing_details)
        
        # Merge with new details
        updated_details = {
            **existing_details,
            'stop_event': event['event_id'],
            'stop_event_type': event['event_type'],
            'target_seconds': target_seconds
        }
        
        updates = {
            'stop_timestamp': event['timestamp'],
            'total_duration': total_duration,
            'business_duration': business_duration,
            'is_breach': is_breach,
            'breach_percentage': breach_percentage,
            'status': 'breached' if is_breach else 'completed',
            'details': json.dumps(updated_details)
        }
        
        self.db.update_evaluation(active_eval['evaluation_id'], updates)
        
        # Create alert if breach occurred
        if is_breach:
            self._create_breach_alert(active_eval['evaluation_id'], sla, event, breach_percentage)
        
        return {**active_eval, **updates}
    
    def _calculate_business_duration(self, start_time: datetime, stop_time: datetime, 
                                     business_hours_id: str) -> float:
        """Calculate duration considering only business hours"""
        # This is a simplified implementation
        # In production, this should properly handle business hours, holidays, and timezones
        
        # For now, return total duration
        # TODO: Implement proper business hours calculation
        total_duration = (stop_time - start_time).total_seconds()
        
        # Assume 8 business hours per day (9 AM - 5 PM)
        business_hours_per_day = 8
        total_hours_per_day = 24
        
        # Simple approximation: scale by business hours ratio
        business_ratio = business_hours_per_day / total_hours_per_day
        return total_duration * business_ratio
    
    def _convert_to_seconds(self, value: float, unit: str) -> float:
        """Convert time value to seconds"""
        conversions = {
            'seconds': 1,
            'minutes': 60,
            'hours': 3600,
            'days': 86400
        }
        return value * conversions.get(unit, 60)  # Default to minutes
    
    def _create_breach_alert(self, evaluation_id: str, sla: Dict, event: Dict, 
                            breach_percentage: float) -> str:
        """Create alert for SLA breach"""
        alert_id = f"alert-{uuid.uuid4().hex[:12]}"
        
        severity = self._determine_severity(breach_percentage, sla.get('priority'))
        
        alert_data = {
            'alert_id': alert_id,
            'org_id': event['org_id'],
            'evaluation_id': evaluation_id,
            'sla_id': sla['sla_id'],
            'service_id': event['service_id'],
            'alert_type': 'breach',
            'severity': severity,
            'message': f"SLA '{sla['name']}' breached by {breach_percentage:.1f}%",
            'channels': ['email', 'slack'],  # Default channels
            'status': 'pending',
            'metadata': {
                'breach_percentage': breach_percentage,
                'target': f"{sla['target_value']} {sla['target_unit']}"
            }
        }
        
        self.db.create_alert(alert_data)
        logger.warning(f"Created breach alert {alert_id} for SLA {sla['sla_id']}")
        return alert_id
    
    def _determine_severity(self, breach_percentage: float, priority: Optional[str]) -> str:
        """Determine alert severity based on breach percentage and priority"""
        if breach_percentage > 150 or priority == 'P1':
            return 'critical'
        elif breach_percentage > 120 or priority == 'P2':
            return 'high'
        elif breach_percentage > 100:
            return 'medium'
        else:
            return 'low'
    
    def evaluate_uptime_sla(self, service_id: str, sla_id: str, 
                           period_start: datetime, period_end: datetime) -> Dict:
        """Evaluate uptime SLA for a given period"""
        # Get uptime check events
        events = self.db.get_events(
            org_id=self.db.get_service(service_id)['org_id'],
            filters={
                'service_id': service_id,
                'event_type': 'uptime.check',
                'start_date': period_start.isoformat(),
                'end_date': period_end.isoformat()
            }
        )
        
        if not events:
            return {'uptime_percentage': 100.0, 'total_checks': 0}
        
        successful_checks = sum(1 for e in events if e.get('status') == 'up')
        total_checks = len(events)
        uptime_percentage = (successful_checks / total_checks * 100) if total_checks > 0 else 100.0
        
        # Get SLA target
        sla = self.db.get_sla(sla_id)
        is_breach = uptime_percentage < sla['target_value']
        
        return {
            'uptime_percentage': round(uptime_percentage, 2),
            'total_checks': total_checks,
            'successful_checks': successful_checks,
            'failed_checks': total_checks - successful_checks,
            'target': sla['target_value'],
            'is_breach': is_breach
        }
    
    def calculate_mttr(self, service_id: str, period_days: int = 30) -> float:
        """Calculate Mean Time To Resolution"""
        period_start = datetime.now() - timedelta(days=period_days)
        
        evaluations = self.db.get_evaluations(
            org_id=self.db.get_service(service_id)['org_id'],
            filters={'service_id': service_id}
        )
        
        # Filter completed evaluations in period
        completed = [
            e for e in evaluations 
            if e['status'] in ['completed', 'breached'] 
            and e['stop_timestamp']
            and datetime.fromisoformat(e['stop_timestamp']) >= period_start
        ]
        
        if not completed:
            return 0.0
        
        total_duration = sum(e['business_duration'] or 0 for e in completed)
        return total_duration / len(completed)
    
    def get_response_time_percentiles(self, service_id: str, period_days: int = 30) -> Dict:
        """Calculate response time percentiles"""
        period_start = datetime.now() - timedelta(days=period_days)
        
        evaluations = self.db.get_evaluations(
            org_id=self.db.get_service(service_id)['org_id'],
            filters={'service_id': service_id}
        )
        
        # Filter evaluations with business_duration
        durations = [
            e['business_duration'] 
            for e in evaluations 
            if e['business_duration'] is not None
            and datetime.fromisoformat(e['start_timestamp']) >= period_start
        ]
        
        if not durations:
            return {'p50': 0, 'p95': 0, 'p99': 0}
        
        durations.sort()
        n = len(durations)
        
        return {
            'p50': durations[int(n * 0.50)] if n > 0 else 0,
            'p95': durations[int(n * 0.95)] if n > 0 else 0,
            'p99': durations[int(n * 0.99)] if n > 0 else 0
        }
    
    def batch_evaluate(self, org_id: str) -> Dict:
        """Run batch evaluation for all active SLAs"""
        logger.info(f"Starting batch evaluation for org {org_id}")
        
        # Get all active SLAs
        services = self.db.get_services_by_org(org_id)
        total_evaluated = 0
        total_breaches = 0
        
        for service in services:
            slas = self.db.get_slas_by_service(service['service_id'])
            
            for sla in slas:
                if sla['metric_type'] == 'uptime':
                    # Evaluate uptime SLAs
                    period_end = datetime.now()
                    period_start = period_end - timedelta(days=1)
                    result = self.evaluate_uptime_sla(
                        service['service_id'], sla['sla_id'],
                        period_start, period_end
                    )
                    total_evaluated += 1
                    if result.get('is_breach'):
                        total_breaches += 1
        
        logger.info(f"Batch evaluation complete: {total_evaluated} SLAs evaluated, {total_breaches} breaches")
        
        return {
            'total_evaluated': total_evaluated,
            'total_breaches': total_breaches,
            'timestamp': datetime.now().isoformat()
        }
