"""
Job Data Connector
Imports job/batch metadata from external job management APIs

Supports importing jobs and their relationships to assets and services.
"""

import sqlite3
import os
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from base_connector import BaseConnector

logger = logging.getLogger(__name__)


class JobDataConnector(BaseConnector):
    """
    Connector for importing jobs from external job/batch management systems
    
    Handles fetching job data and bulk importing into the portal database
    with field mapping and transformation support.
    """
    
    def test_connection(self) -> bool:
        """
        Test connection to job API
        
        Returns:
            True if health check succeeds, False otherwise
        """
        try:
            response = self._make_request('GET', '/api/health', timeout=5)
            data = response.json()
            
            # Check if response indicates healthy status
            status = data.get('status', '').lower()
            is_healthy = status in ['healthy', 'ok', 'up']
            
            if is_healthy:
                logger.info(f"✓ Job API connection successful: {data}")
            else:
                logger.warning(f"Job API returned unhealthy status: {data}")
            
            return is_healthy
            
        except Exception as e:
            logger.error(f"Job API connection test failed: {str(e)}")
            return False
    
    def fetch_data(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch jobs from API (wrapper for fetch_jobs)
        
        Args:
            filters: Optional filter parameters
            
        Returns:
            List of job objects
        """
        return self.fetch_jobs(filters)
    
    def fetch_jobs(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Fetch jobs from external API
        
        Args:
            filters: Optional filters such as:
                - asset_id: Filter by asset ID
                - service_name: Filter by service name
                - job_type: Filter by job type (Batch, ETL, Replication, etc.)
                - status: Filter by status (active, inactive)
                
        Returns:
            List of job dictionaries
            
        Example:
            jobs = connector.fetch_jobs({
                'service_name': 'HR Data Processing Service',
                'status': 'active'
            })
        """
        try:
            logger.info(f"Fetching jobs with filters: {filters}")
            
            response = self._make_request('GET', '/api/jobs', params=filters or {})
            data = response.json()
            
            # Handle different response formats
            if 'jobs' in data:
                jobs = data['jobs']
            elif isinstance(data, list):
                jobs = data
            else:
                logger.warning(f"Unexpected response format: {data}")
                jobs = []
            
            logger.info(f"Fetched {len(jobs)} jobs")
            return jobs
            
        except Exception as e:
            logger.error(f"Failed to fetch jobs: {str(e)}")
            raise Exception(f"Failed to fetch jobs: {str(e)}")
    
    def fetch_job_by_id(self, job_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch a specific job by ID
        
        Args:
            job_id: Unique identifier for the job
            
        Returns:
            Job dictionary or None if not found
        """
        try:
            logger.info(f"Fetching job: {job_id}")
            
            response = self._make_request('GET', f'/api/jobs/{job_id}')
            job = response.json()
            
            logger.info(f"Retrieved job: {job.get('job_id')}")
            return job
            
        except Exception as e:
            logger.error(f"Failed to fetch job {job_id}: {str(e)}")
            return None
    
    def bulk_import_jobs(
        self, 
        org_id: int, 
        jobs: List[Dict[str, Any]], 
        field_mappings: List[Dict[str, Any]],
        asset_mapping: Dict[str, str] = None,
        service_mapping: Dict[str, str] = None,
        db_path: str = None
    ) -> Dict[str, Any]:
        """
        Bulk import jobs into portal database
        
        Args:
            org_id: Organization ID for imported jobs
            jobs: List of job objects from API
            field_mappings: List of field mapping rules
            asset_mapping: Optional mapping of connector asset IDs to portal asset IDs
            service_mapping: Optional mapping of connector service IDs to portal service IDs
            db_path: Optional database path (defaults to ../database/sla_portal.db)
            
        Returns:
            Dictionary with import results:
                - imported: Number of successfully imported jobs
                - failed: Number of failed imports
                - errors: List of error details
                - job_ids: List of created job IDs
        """
        results = {
            'imported': 0,
            'failed': 0,
            'errors': [],
            'job_ids': []
        }
        
        logger.info(f"Starting bulk import of {len(jobs)} jobs")
        
        for i, job in enumerate(jobs, 1):
            try:
                # Apply field mappings
                mapped_job = self._apply_field_mappings(job, field_mappings)
                
                # Validate required fields
                if not mapped_job.get('job_name'):
                    raise Exception("Job name is required")
                
                # Map asset_id if mapping provided
                if asset_mapping and 'asset_id' in job:
                    connector_asset_id = job['asset_id']
                    portal_asset_id = asset_mapping.get(connector_asset_id)
                    if portal_asset_id:
                        mapped_job['asset_id'] = portal_asset_id
                
                # Map service_id if mapping provided
                if service_mapping and 'service_id' in job:
                    connector_service_id = job['service_id']
                    portal_service_id = service_mapping.get(connector_service_id)
                    if portal_service_id:
                        mapped_job['service_id'] = portal_service_id
                
                # Insert into database
                job_id = self._insert_job(org_id, mapped_job, db_path)
                
                results['imported'] += 1
                results['job_ids'].append(job_id)
                
                logger.info(f"Imported job {i}/{len(jobs)}: {mapped_job.get('job_name')} (ID: {job_id})")
                
            except Exception as e:
                results['failed'] += 1
                error_detail = {
                    'job': job.get('job_name', 'Unknown'),
                    'error': str(e)
                }
                results['errors'].append(error_detail)
                logger.error(f"Failed to import job {i}/{len(jobs)}: {str(e)}")
        
        logger.info(f"Bulk import completed: {results['imported']} imported, {results['failed']} failed")
        return results
    
    def _insert_job(self, org_id: int, job_data: Dict[str, Any], db_path: str = None) -> str:
        """
        Insert a single job into the database
        
        Args:
            org_id: Organization ID
            job_data: Mapped job data
            db_path: Optional database path
            
        Returns:
            Generated job_id
        """
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '../database/sla_portal.db')
        
        import uuid
        job_id = f"JOB-{uuid.uuid4().hex[:8].upper()}"
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO jobs (
                    job_id, org_id, asset_id, service_id,
                    job_name, job_type, schedule, description,
                    is_active, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (
                job_id,
                org_id,
                job_data.get('asset_id'),
                job_data.get('service_id'),
                job_data.get('job_name'),
                job_data.get('job_type', ''),
                job_data.get('schedule', ''),
                job_data.get('description', ''),
                job_data.get('is_active', True)
            ))
            
            conn.commit()
            return job_id
            
        except sqlite3.IntegrityError as e:
            raise Exception(f"Database integrity error: {str(e)}")
        except Exception as e:
            raise Exception(f"Database error: {str(e)}")
        finally:
            conn.close()


# Example usage and testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=" * 60)
    print("Job Data Connector - Test Mode")
    print("=" * 60)
    print()
    
    # Create connector instance
    connector = JobDataConnector(
        config_id=1,
        api_endpoint='http://localhost:5005/api',
        api_key=None
    )
    
    # Test connection
    print("Testing connection...")
    if connector.test_connection():
        print("✓ Connection successful!")
        
        # Fetch jobs
        print("\nFetching all jobs...")
        jobs = connector.fetch_jobs()
        print(f"✓ Retrieved {len(jobs)} jobs")
        
        if jobs:
            print("\nFirst job:")
            for key, value in jobs[0].items():
                print(f"  {key}: {value}")
        
        # Test filtering
        print("\nFetching jobs for 'HR Data Processing Service'...")
        filtered_jobs = connector.fetch_jobs({'service_name': 'HR Data Processing Service'})
        print(f"✓ Retrieved {len(filtered_jobs)} jobs")
        
    else:
        print("✗ Connection failed")
        print("Make sure job_provider_simulator.py is running on port 5005")
    
    # Close connection
    connector.close()
    
    print()
    print("=" * 60)
    print("Test complete!")
    print("=" * 60)
