"""
AI Help Service
Provides intelligent help using pluggable LLM providers

This service uses an abstracted LLM provider interface to allow flexibility
in choosing the AI backend (Claude, ChatGPT, local models, etc.) without
changing the core help service logic.
"""

import os
from abc import ABC, abstractmethod
from datetime import datetime
import json

# ============================================
# ABSTRACTED LLM PROVIDER INTERFACE
# ============================================

class BaseLLMProvider(ABC):
    """
    Abstract base class for LLM providers.
    This allows us to switch between different AI providers
    (Claude, ChatGPT, local models, etc.) without changing
    the help service logic.
    """
    
    @abstractmethod
    def generate_response(self, question, system_prompt, conversation_history):
        """
        Generate response from LLM
        
        Args:
            question: User's current question
            system_prompt: System instructions for the LLM
            conversation_history: List of previous messages
            
        Returns:
            dict: {'answer': str, 'timestamp': str}
        """
        pass
    
    @abstractmethod
    def test_connection(self):
        """Test if LLM provider is accessible"""
        pass


# ============================================
# PLACEHOLDER LLM PROVIDERS
# ============================================

class ClaudeLLMProvider(BaseLLMProvider):
    """
    Placeholder for Anthropic Claude API integration
    
    TODO: Implement when Claude API is selected
    - Install: pip install anthropic
    - Configure API key
    - Implement generate_response() method
    """
    
    def __init__(self, api_key=None):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        # TODO: Initialize Claude client when implemented
        # self.client = anthropic.Anthropic(api_key=self.api_key)
    
    def generate_response(self, question, system_prompt, conversation_history):
        """
        TODO: Implement Claude API integration
        
        Example implementation:
        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            system=system_prompt,
            messages=conversation_history + [{"role": "user", "content": question}]
        )
        return {
            'answer': response.content[0].text,
            'timestamp': datetime.now().isoformat()
        }
        """
        raise NotImplementedError("Claude provider not yet implemented")
    
    def test_connection(self):
        """TODO: Test Claude API connection"""
        return False


class ChatGPTProvider(BaseLLMProvider):
    """
    Placeholder for OpenAI ChatGPT API integration
    
    TODO: Implement when ChatGPT is selected
    - Install: pip install openai
    - Configure API key
    - Implement generate_response() method
    """
    
    def __init__(self, api_key=None):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        # TODO: Initialize OpenAI client when implemented
        # self.client = openai.OpenAI(api_key=self.api_key)
    
    def generate_response(self, question, system_prompt, conversation_history):
        """
        TODO: Implement ChatGPT API integration
        
        Example implementation:
        response = self.client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt}
            ] + conversation_history + [
                {"role": "user", "content": question}
            ]
        )
        return {
            'answer': response.choices[0].message.content,
            'timestamp': datetime.now().isoformat()
        }
        """
        raise NotImplementedError("ChatGPT provider not yet implemented")
    
    def test_connection(self):
        """TODO: Test OpenAI API connection"""
        return False


class CustomLLMProvider(BaseLLMProvider):
    """
    Placeholder for custom/local LLM integration
    
    TODO: Implement for local LLMs (Ollama, LLaMA, etc.)
    - Configure local model endpoint
    - Implement generate_response() method
    """
    
    def __init__(self, endpoint_url=None):
        self.endpoint_url = endpoint_url or os.environ.get("CUSTOM_LLM_ENDPOINT")
    
    def generate_response(self, question, system_prompt, conversation_history):
        """
        TODO: Implement custom LLM integration
        
        Example for local Ollama:
        import requests
        response = requests.post(f"{self.endpoint_url}/api/generate", json={
            "model": "llama2",
            "prompt": f"{system_prompt}\\n\\nUser: {question}",
            "stream": False
        })
        return {
            'answer': response.json()['response'],
            'timestamp': datetime.now().isoformat()
        }
        """
        raise NotImplementedError("Custom LLM provider not yet implemented")
    
    def test_connection(self):
        """TODO: Test custom LLM endpoint connection"""
        return False


class MockLLMProvider(BaseLLMProvider):
    """
    Mock provider for testing and development
    Returns predefined responses for common questions
    """
    
    def __init__(self):
        self.mock_responses = {
            "how do i create an sla": "To create an SLA, go to Services → Select Service → Click 'Add SLA' → Fill form → Save.",
            "what is direct monitoring": "Direct monitoring checks service health in real-time via API. Indirect monitoring tracks scheduled job execution.",
            "what is indirect monitoring": "Indirect monitoring tracks scheduled job execution. For batch jobs that run on a schedule.",
            "how do i import jobs": "Go to Tools → Metadata Retrieval → Select Service/Job Connector → Configure platform → Import.",
            "default": "I'm a mock LLM provider. Please configure a real LLM provider (Claude, ChatGPT, or custom) to get intelligent help responses."
        }
    
    def generate_response(self, question, system_prompt, conversation_history):
        """Return mock response based on question"""
        question_lower = question.lower()
        
        for key, response in self.mock_responses.items():
            if key in question_lower:
                return {
                    'answer': response,
                    'timestamp': datetime.now().isoformat()
                }
        
        return {
            'answer': self.mock_responses['default'],
            'timestamp': datetime.now().isoformat()
        }
    
    def test_connection(self):
        """Mock provider is always available"""
        return True


# ============================================
# MAIN HELP SERVICE
# ============================================

class HelpService:
    """
    Main help service that uses pluggable LLM providers
    """
    
    def __init__(self, provider: BaseLLMProvider = None):
        """
        Initialize help service with LLM provider
        
        Args:
            provider: Instance of BaseLLMProvider (Claude, ChatGPT, Custom, Mock)
                     If None, uses MockLLMProvider by default
        """
        self.provider = provider or MockLLMProvider()
        
        self.system_prompt = """You are a helpful assistant for an SLA Monitoring Portal.

Portal Structure:
- Asset → Service → Job → SLA (hierarchical relationship)
- Assets: Infrastructure components (servers, databases, etc.)
- Services: Applications/jobs running on assets
- Jobs: Scheduled work with cron expressions
- SLAs: Performance targets and monitoring rules

Your role:
- Help users understand how to create and manage Assets, Services, Jobs, and SLAs
- Explain portal features and navigation
- Provide step-by-step instructions
- Help interpret dashboards and reports
- Troubleshoot common issues
- Explain concepts clearly

Available features:
- Dashboard: View SLA metrics and compliance
- Process Flow: Visual hierarchy diagram
- Onboarding: Guided setup wizard for new users
- Assets: Manage infrastructure components
- Services: Manage applications and jobs
- Alerts: View and manage SLA violations
- Reports: Generate compliance reports
- Tools → Metadata Retrieval: Bulk import from external platforms

Guidelines:
- Keep answers concise (2-4 paragraphs max)
- Provide actionable next steps
- Offer to show step-by-step if needed
- Include direct links when relevant
- Be friendly and encouraging
- If you don't know something, say so and suggest contacting support

Never:
- Make up features that don't exist
- Provide inaccurate technical information
- Be condescending or impatient
"""
    
    def set_provider(self, provider: BaseLLMProvider):
        """Switch to a different LLM provider"""
        self.provider = provider
    
    def get_help_response(self, user_question, current_page=None, conversation_history=[]):
        """
        Get AI-powered help response
        
        Args:
            user_question: User's question
            current_page: Current page URL (for context)
            conversation_history: Previous messages in conversation
        
        Returns:
            dict: {'answer': str, 'timestamp': str, 'provider': str}
        """
        
        # Add current page context
        system_prompt = self.system_prompt
        if current_page:
            system_prompt += f"\\n\\nUser is currently on: {current_page}"
        
        try:
            # Call LLM provider
            response = self.provider.generate_response(
                user_question,
                system_prompt,
                conversation_history
            )
            
            # Add provider info
            response['provider'] = self.provider.__class__.__name__
            
            return response
            
        except NotImplementedError as e:
            return {
                'answer': "The selected LLM provider is not yet configured. Please contact your administrator to set up the AI help system, or use the static FAQ for assistance.",
                'timestamp': datetime.now().isoformat(),
                'error': str(e),
                'provider': 'None'
            }
        except Exception as e:
            return {
                'answer': "I'm sorry, I encountered an error. Please try again or contact support if the problem persists.",
                'timestamp': datetime.now().isoformat(),
                'error': str(e),
                'provider': self.provider.__class__.__name__
            }
    
    def test_provider_connection(self):
        """Test if current LLM provider is accessible"""
        return self.provider.test_connection()
    
    def log_question(self, question, answer, user_id):
        """Log questions for analytics and improvement"""
        # TODO: Store in database for analysis
        log_entry = {
            'question': question,
            'answer': answer,
            'user_id': user_id,
            'provider': self.provider.__class__.__name__,
            'timestamp': datetime.now().isoformat()
        }
        # Save to database or file
        pass


# ============================================
# CONFIGURATION AND INITIALIZATION
# ============================================

def get_configured_help_service():
    """
    Factory function to create HelpService with configured provider
    
    Configuration priority:
    1. Environment variable: LLM_PROVIDER (claude/chatgpt/custom/mock)
    2. Config file
    3. Default to MockLLMProvider
    """
    
    provider_type = os.environ.get('LLM_PROVIDER', 'mock').lower()
    
    if provider_type == 'claude':
        # TODO: Configure Claude when selected
        # provider = ClaudeLLMProvider()
        print("WARNING: Claude provider not yet implemented, using Mock provider")
        provider = MockLLMProvider()
        
    elif provider_type == 'chatgpt':
        # TODO: Configure ChatGPT when selected
        # provider = ChatGPTProvider()
        print("WARNING: ChatGPT provider not yet implemented, using Mock provider")
        provider = MockLLMProvider()
        
    elif provider_type == 'custom':
        # TODO: Configure custom LLM when selected
        # provider = CustomLLMProvider()
        print("WARNING: Custom LLM provider not yet implemented, using Mock provider")
        provider = MockLLMProvider()
        
    else:  # mock or unknown
        provider = MockLLMProvider()
    
    return HelpService(provider)


# Example usage
if __name__ == "__main__":
    # Initialize help service with mock provider
    help_service = get_configured_help_service()
    
    # Test questions
    questions = [
        "How do I create an SLA?",
        "What is direct monitoring?",
        "How do I import jobs from Autosys?"
    ]
    
    for q in questions:
        print(f"\\nQ: {q}")
        response = help_service.get_help_response(q, current_page="/services")
        print(f"A: {response['answer']}")
        print(f"Provider: {response['provider']}")
