"""
Quick Database Schema Verification Script
Run this to verify your database has the correct schema after migration
"""

import sqlite3
import sys

DB_PATH = '../database/sla_portal.db'

def verify_schema():
    """Verify the database schema is correct"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("=" * 70)
    print("Database Schema Verification")
    print("=" * 70)
    
    # Check slas table schema
    print("\n1. Checking 'slas' table columns...")
    cursor.execute("PRAGMA table_info(slas)")
    sla_columns = {row[1] for row in cursor.fetchall()}
    
    expected_cols = {'sla_id', 'org_id', 'asset_id', 'name', 'metric_type', 
                     'target_value', 'log_template', 'log_server_type'}
    unexpected_cols = {'service_id', 'job_id'}
    
    print(f"   Found columns: {', '.join(sorted(sla_columns))}")
    
    if 'asset_id' in sla_columns and 'log_template' in sla_columns:
        print("   ✅ New columns present (asset_id, log_template)")
    else:
        print("   ❌ Missing new columns!")
        
    if 'service_id' not in sla_columns and 'job_id' not in sla_columns:
        print("   ✅ Old columns removed (service_id, job_id)")
    else:
        print("   ❌ Old columns still present! Migration may not have run.")
        
    # Check services table
    print("\n2. Checking 'services' table columns...")
    cursor.execute("PRAGMA table_info(services)")
    service_columns = {row[1] for row in cursor.fetchall()}
    
    if 'sla_id' in service_columns and 'parent_service_id' in service_columns:
        print("   ✅ New columns present (sla_id, parent_service_id)")
    else:
        print("   ❌ Missing new columns!")
        
    # Check jobs table
    print("\n3. Checking 'jobs' table columns...")
    cursor.execute("PRAGMA table_info(jobs)")
    job_columns = {row[1] for row in cursor.fetchall()}
    
    if 'sla_id' in job_columns and 'parent_job_id' in job_columns:
        print("   ✅ New columns present (sla_id, parent_job_id)")
    else:
        print("   ❌ Missing new columns!")
        
    # Check aits table
    print("\n4. Checking 'aits' table...")
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='aits'")
    if cursor.fetchone():
        print("   ✅ 'aits' table exists")
        cursor.execute("SELECT COUNT(*) FROM aits")
        count = cursor.fetchone()[0]
        print(f"   AITs in database: {count}")
    else:
        print("   ❌ 'aits' table does not exist!")
        
    # Check assets table
    print("\n5. Checking 'assets' table columns...")
    cursor.execute("PRAGMA table_info(assets)")
    asset_columns = {row[1] for row in cursor.fetchall()}
    
    if 'ait_id' in asset_columns and 'asset_type' in asset_columns:
        print("   ✅ New columns present (ait_id, asset_type)")
    else:
        print("   ❌ Missing new columns!")
    
    conn.close()
    
    print("\n" + "=" * 70)
    print("Verification Complete")
    print("=" * 70)

if __name__ == "__main__":
    try:
        verify_schema()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)
