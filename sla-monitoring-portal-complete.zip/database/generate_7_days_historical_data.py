"""
Generate 7 Days of Historical Data
Adds monitoring and compliance data for services, jobs, and alerts
WITHOUT modifying existing aits, assets, slas, services, or jobs
"""

import sqlite3
import uuid
import json
import random
from datetime import datetime, timedelta

def generate_historical_data(db_path='sla_portal.db', days=7):
    """Generate 7 days of historical monitoring and compliance data"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get org_id and user_id
    cursor.execute("SELECT org_id FROM organizations LIMIT 1")
    org_id = cursor.fetchone()[0]
    
    cursor.execute("SELECT user_id FROM users LIMIT 1")
    user_id = cursor.fetchone()[0]
    
    print(f"Using org_id: {org_id}")
    print(f"Using user_id: {user_id}")
    
    # Get earliest existing date
    cursor.execute("SELECT MIN(check_time) FROM service_monitoring_results")
    earliest_date = cursor.fetchone()[0]
    if earliest_date:
        earliest_date = datetime.fromisoformat(earliest_date)
        print(f"Existing data starts: {earliest_date}")
    else:
        earliest_date = datetime.now()
    
    # Calculate date range for new historical data (7 days BEFORE existing data)
    end_date = earliest_date - timedelta(days=1)  # Day before existing data starts
    start_date = end_date - timedelta(days=days - 1)  # 7 days before that
    
    print(f"\nGenerating historical data from {start_date.date()} to {end_date.date()}")
    print("=" * 60)
    
    # Get all services with their SLAs
    cursor.execute("""
        SELECT s.service_id, s.name, s.sla_id, sla.metric_type, sla.target_value
        FROM services s
        JOIN slas sla ON s.sla_id = sla.sla_id
        WHERE sla.metric_type = 'uptime'
    """)
    services = cursor.fetchall()
    print(f"\nFound {len(services)} services to generate data for")
    
    # Get all jobs with their SLAs
    cursor.execute("""
        SELECT j.job_id, j.job_name, j.sla_id, sla.metric_type, sla.target_value
        FROM jobs j
        JOIN slas sla ON j.sla_id = sla.sla_id
        WHERE sla.metric_type IN ('on_schedule', 'success_rate')
    """)
    jobs = cursor.fetchall()
    print(f"Found {len(jobs)} jobs to generate data for")
    
    # Generate service monitoring data (24 checks per day per service)
    print(f"\nGenerating service monitoring data...")
    service_monitoring_count = 0
    service_compliance_count = 0
    
    for service_id, service_name, sla_id, metric_type, target_value in services:
        for day in range(days):
            check_date = start_date + timedelta(days=day)
            
            # 24 hourly checks per day
            for hour in range(24):
                check_time = check_date + timedelta(hours=hour)
                
                # Random response time between 50-500ms
                response_time = random.randint(50, 500)
                
                # 98-100% chance of healthy (to create realistic uptime)
                is_healthy = random.random() < 0.99
                
                # Create monitoring result
                result_id = f"result-{uuid.uuid4().hex[:12]}"
                
                cursor.execute("""
                    INSERT INTO service_monitoring_results (
                        result_id, service_id, org_id, check_time,
                        response_time_ms, is_healthy, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    result_id, service_id, org_id, check_time.isoformat(),
                    response_time, is_healthy, json.dumps({"source": "historical"})
                ))
                service_monitoring_count += 1
                
                # Create compliance record
                measured_value = 100.0 if is_healthy else 0.0
                met_sla = is_healthy
                
                compliance_id = f"comp-{uuid.uuid4().hex[:12]}"
                
                cursor.execute("""
                    INSERT INTO service_sla_compliance (
                        compliance_id, result_id, sla_id, org_id,
                        met_sla, measured_value, target_value,
                        measurement_type, breach_severity,
                        breach_details, evaluated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    compliance_id, result_id, sla_id, org_id,
                    met_sla, measured_value, target_value,
                    'uptime', 'none' if met_sla else 'critical',
                    json.dumps({"is_healthy": is_healthy}), check_time.isoformat()
                ))
                service_compliance_count += 1
    
    print(f"  Generated {service_monitoring_count} service monitoring results")
    print(f"  Generated {service_compliance_count} service compliance records")
    
    # Generate job monitoring data (1 run per day per job)
    print(f"\nGenerating job monitoring data...")
    job_monitoring_count = 0
    job_compliance_count = 0
    
    for job_id, job_name, sla_id, metric_type, target_value in jobs:
        for day in range(days):
            check_date = start_date + timedelta(days=day)
            
            # Job runs once per day at 2 AM
            check_time = check_date + timedelta(hours=2)
            
            # Random execution time (2000-4500 seconds)
            duration_seconds = random.randint(2000, 4500)
            
            # Start and end times
            execution_start = check_time
            execution_end = execution_start + timedelta(seconds=duration_seconds)
            
            # Random records processed
            records_processed = random.randint(1000, 10000)
            
            # 99.5% success rate
            success = random.random() < 0.995
            status = 'success' if success else 'failed'
            
            # Create monitoring result
            result_id = f"result-{uuid.uuid4().hex[:12]}"
            
            cursor.execute("""
                INSERT INTO job_monitoring_results (
                    result_id, job_id, org_id, check_time,
                    execution_start_time, execution_end_time,
                    duration_seconds, records_processed, status, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result_id, job_id, org_id, check_time.isoformat(),
                execution_start.isoformat(), execution_end.isoformat(),
                duration_seconds, records_processed, status,
                json.dumps({"source": "historical"})
            ))
            job_monitoring_count += 1
            
            # Create compliance record
            if metric_type == 'on_schedule':
                # Expected duration: 3600 seconds (1 hour)
                expected_duration = 3600
                met_sla = duration_seconds <= expected_duration
                measured_value = (expected_duration / duration_seconds * 100) if duration_seconds > 0 else 100
            else:  # success_rate
                met_sla = success
                measured_value = 100.0 if success else 0.0
            
            compliance_id = f"comp-{uuid.uuid4().hex[:12]}"
            
            cursor.execute("""
                INSERT INTO job_sla_compliance (
                    compliance_id, result_id, sla_id, org_id,
                    met_sla, measured_value, target_value,
                    measurement_type, breach_severity,
                    breach_details, evaluated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                compliance_id, result_id, sla_id, org_id,
                met_sla, measured_value, target_value,
                metric_type, 'none' if met_sla else 'critical',
                json.dumps({
                    "status": status,
                    "duration": duration_seconds,
                    "records": records_processed
                }), check_time.isoformat()
            ))
            job_compliance_count += 1
    
    print(f"  Generated {job_monitoring_count} job monitoring results")
    print(f"  Generated {job_compliance_count} job compliance records")
    
    # Generate alerts for breaches in the new historical data
    print(f"\nGenerating historical alerts...")
    alert_count = 0
    
    # Get service breaches from new historical data
    cursor.execute("""
        SELECT DISTINCT
            ssc.compliance_id, ssc.sla_id, smr.service_id,
            ssc.evaluated_at, ssc.measured_value, ssc.target_value
        FROM service_sla_compliance ssc
        JOIN service_monitoring_results smr ON ssc.result_id = smr.result_id
        WHERE ssc.met_sla = 0 
        AND ssc.evaluated_at >= ?
        AND ssc.evaluated_at <= ?
        AND ssc.org_id = ?
        ORDER BY RANDOM()
        LIMIT 10
    """, (start_date.isoformat(), end_date.isoformat(), org_id))
    
    service_breaches = cursor.fetchall()
    
    for breach in service_breaches:
        alert_id = f"alert-{uuid.uuid4().hex[:12]}"
        compliance_id, sla_id, service_id, breach_time, measured, target = breach
        
        diff = target - measured
        severity = 'critical' if diff > 5 else 'high' if diff > 2 else 'medium'
        alert_type = 'breach'
        
        # Get SLA and service names
        cursor.execute("SELECT name FROM slas WHERE sla_id = ?", (sla_id,))
        sla_name = cursor.fetchone()[0]
        
        cursor.execute("SELECT name FROM services WHERE service_id = ?", (service_id,))
        service_name = cursor.fetchone()[0]
        
        message = f"SLA breach detected: {service_name} - {sla_name}. Measured: {measured:.2f}%, Target: {target:.2f}%"
        
        # Random status
        status = random.choice(['sent', 'sent', 'acknowledged'])
        sent_timestamp = breach_time
        acknowledged_by = user_id if status == 'acknowledged' else None
        acknowledged_at = None
        if status == 'acknowledged':
            ack_time = datetime.fromisoformat(breach_time) + timedelta(hours=random.randint(1, 6))
            acknowledged_at = ack_time.isoformat()
        
        cursor.execute("""
            INSERT INTO alerts (
                alert_id, org_id, evaluation_id, sla_id, service_id,
                alert_type, severity, message, channels, sent_timestamp,
                status, acknowledged_by, acknowledged_at, metadata, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alert_id, org_id, compliance_id, sla_id, service_id,
            alert_type, severity, message, json.dumps(['email', 'slack']),
            sent_timestamp, status, acknowledged_by, acknowledged_at,
            json.dumps({"source": "historical", "breach_percentage": diff}),
            breach_time
        ))
        alert_count += 1
    
    # Get job breaches
    cursor.execute("""
        SELECT DISTINCT
            jsc.compliance_id, jsc.sla_id, jmr.job_id,
            jsc.evaluated_at, jsc.measured_value, jsc.target_value
        FROM job_sla_compliance jsc
        JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
        WHERE jsc.met_sla = 0 
        AND jsc.evaluated_at >= ?
        AND jsc.evaluated_at <= ?
        AND jsc.org_id = ?
        ORDER BY RANDOM()
        LIMIT 5
    """, (start_date.isoformat(), end_date.isoformat(), org_id))
    
    job_breaches = cursor.fetchall()
    
    for breach in job_breaches:
        alert_id = f"alert-{uuid.uuid4().hex[:12]}"
        compliance_id, sla_id, job_id, breach_time, measured, target = breach
        
        # Get a related service_id (alerts table requires it)
        cursor.execute("""
            SELECT s.service_id 
            FROM services s
            JOIN jobs j ON s.asset_id = j.asset_id
            WHERE j.job_id = ?
            LIMIT 1
        """, (job_id,))
        
        service_result = cursor.fetchone()
        if not service_result:
            continue
        service_id = service_result[0]
        
        diff = target - measured
        severity = 'critical' if measured == 0 else 'high' if diff > 10 else 'medium'
        alert_type = 'breach'
        
        # Get SLA and job names
        cursor.execute("SELECT name FROM slas WHERE sla_id = ?", (sla_id,))
        sla_name = cursor.fetchone()[0]
        
        cursor.execute("SELECT job_name FROM jobs WHERE job_id = ?", (job_id,))
        job_name = cursor.fetchone()[0]
        
        message = f"SLA breach detected: {job_name} - {sla_name}. Success rate: {measured:.2f}%, Target: {target:.2f}%"
        
        status = random.choice(['sent', 'acknowledged'])
        sent_timestamp = breach_time
        acknowledged_by = user_id if status == 'acknowledged' else None
        acknowledged_at = None
        if status == 'acknowledged':
            ack_time = datetime.fromisoformat(breach_time) + timedelta(hours=random.randint(1, 8))
            acknowledged_at = ack_time.isoformat()
        
        cursor.execute("""
            INSERT INTO alerts (
                alert_id, org_id, evaluation_id, sla_id, service_id,
                alert_type, severity, message, channels, sent_timestamp,
                status, acknowledged_by, acknowledged_at, metadata, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alert_id, org_id, compliance_id, sla_id, service_id,
            alert_type, severity, message, json.dumps(['email']),
            sent_timestamp, status, acknowledged_by, acknowledged_at,
            json.dumps({"source": "historical", "job_id": job_id, "breach_percentage": diff}),
            breach_time
        ))
        alert_count += 1
    
    print(f"  Generated {alert_count} historical alerts")
    
    # Commit all changes
    conn.commit()
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Historical data generated for: {start_date.date()} to {end_date.date()}")
    print(f"  Service Monitoring Results:  {service_monitoring_count}")
    print(f"  Service Compliance Records:  {service_compliance_count}")
    print(f"  Job Monitoring Results:      {job_monitoring_count}")
    print(f"  Job Compliance Records:      {job_compliance_count}")
    print(f"  Alerts:                      {alert_count}")
    print(f"\nTotal new records:             {service_monitoring_count + service_compliance_count + job_monitoring_count + job_compliance_count + alert_count}")
    
    # Verify new counts
    print("\n" + "=" * 60)
    print("UPDATED DATABASE TOTALS")
    print("=" * 60)
    
    cursor.execute("SELECT COUNT(*) FROM service_monitoring_results")
    print(f"Service Monitoring Results:    {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM service_sla_compliance")
    print(f"Service Compliance Records:    {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM job_monitoring_results")
    print(f"Job Monitoring Results:        {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM job_sla_compliance")
    print(f"Job Compliance Records:        {cursor.fetchone()[0]}")
    
    cursor.execute("SELECT COUNT(*) FROM alerts")
    print(f"Alerts:                        {cursor.fetchone()[0]}")
    
    # Show new date range
    print("\n" + "=" * 60)
    print("DATA DATE RANGE")
    print("=" * 60)
    
    cursor.execute("""
        SELECT 
            MIN(check_time) as earliest,
            MAX(check_time) as latest,
            COUNT(DISTINCT DATE(check_time)) as unique_days
        FROM service_monitoring_results
    """)
    service_dates = cursor.fetchone()
    print(f"Service Data: {service_dates[0][:10]} to {service_dates[1][:10]}")
    print(f"  Total days with data: {service_dates[2]}")
    
    cursor.execute("""
        SELECT 
            MIN(check_time) as earliest,
            MAX(check_time) as latest,
            COUNT(DISTINCT DATE(check_time)) as unique_days
        FROM job_monitoring_results
    """)
    job_dates = cursor.fetchone()
    print(f"Job Data: {job_dates[0][:10]} to {job_dates[1][:10]}")
    print(f"  Total days with data: {job_dates[2]}")
    
    conn.close()
    
    print("\n✓ Historical data generation complete!")
    print("\nNote: Existing services, jobs, SLAs, assets, and AITs were NOT modified.")

if __name__ == "__main__":
    import sys
    db_path = sys.argv[1] if len(sys.argv) > 1 else 'sla_portal.db'
    days = int(sys.argv[2]) if len(sys.argv) > 2 else 7
    
    generate_historical_data(db_path, days)
