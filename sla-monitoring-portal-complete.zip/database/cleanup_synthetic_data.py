"""
Database Cleanup Script for Synthetic Data
Removes all data created by generate_synthetic_data.py
"""

import sqlite3
import sys

def cleanup_synthetic_data(db_path='sla_portal.db'):
    """
    Clean up all synthetic data from the database
    WARNING: This will delete data from multiple tables!
    """
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("=" * 60)
    print("DATABASE CLEANUP - Removing Synthetic Data")
    print("=" * 60)
    print()
    
    # Get counts before deletion
    print("Current record counts:")
    tables_to_check = [
        'aits',
        'assets', 
        'slas',
        'services',
        'jobs',
        'service_monitoring_results',
        'service_sla_compliance',
        'job_monitoring_results',
        'job_sla_compliance',
        'alerts'
    ]
    
    counts_before = {}
    for table in tables_to_check:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            counts_before[table] = count
            print(f"  {table:35} {count:6} records")
        except Exception as e:
            print(f"  {table:35} Error: {e}")
    
    print()
    
    # Confirm deletion
    response = input("Do you want to DELETE all this data? (yes/no): ")
    if response.lower() != 'yes':
        print("Cleanup cancelled.")
        conn.close()
        return
    
    print()
    print("Deleting data...")
    print()
    
    try:
        # Delete in reverse order of foreign key dependencies
        
        # 1. Alerts (references evaluations, slas, services)
        cursor.execute("DELETE FROM alerts WHERE metadata LIKE '%synthetic%'")
        deleted_alerts = cursor.rowcount
        print(f"  Deleted {deleted_alerts} alerts")
        
        # 2. Compliance records
        cursor.execute("DELETE FROM service_sla_compliance")
        deleted_service_compliance = cursor.rowcount
        print(f"  Deleted {deleted_service_compliance} service compliance records")
        
        cursor.execute("DELETE FROM job_sla_compliance")
        deleted_job_compliance = cursor.rowcount
        print(f"  Deleted {deleted_job_compliance} job compliance records")
        
        # 3. Monitoring results
        cursor.execute("DELETE FROM service_monitoring_results")
        deleted_service_monitoring = cursor.rowcount
        print(f"  Deleted {deleted_service_monitoring} service monitoring results")
        
        cursor.execute("DELETE FROM job_monitoring_results")
        deleted_job_monitoring = cursor.rowcount
        print(f"  Deleted {deleted_job_monitoring} job monitoring results")
        
        # 4. Services and Jobs
        cursor.execute("DELETE FROM services")
        deleted_services = cursor.rowcount
        print(f"  Deleted {deleted_services} services")
        
        cursor.execute("DELETE FROM jobs")
        deleted_jobs = cursor.rowcount
        print(f"  Deleted {deleted_jobs} jobs")
        
        # 5. SLAs
        cursor.execute("DELETE FROM slas")
        deleted_slas = cursor.rowcount
        print(f"  Deleted {deleted_slas} SLAs")
        
        # 6. Assets
        cursor.execute("DELETE FROM assets")
        deleted_assets = cursor.rowcount
        print(f"  Deleted {deleted_assets} assets")
        
        # 7. AITs
        cursor.execute("DELETE FROM aits")
        deleted_aits = cursor.rowcount
        print(f"  Deleted {deleted_aits} AITs")
        
        # Note: We don't delete organizations or users as they might be needed
        
        conn.commit()
        
        print()
        print("=" * 60)
        print("CLEANUP COMPLETE")
        print("=" * 60)
        print()
        print("Summary:")
        print(f"  AITs:                      {deleted_aits}")
        print(f"  Assets:                    {deleted_assets}")
        print(f"  SLAs:                      {deleted_slas}")
        print(f"  Services:                  {deleted_services}")
        print(f"  Jobs:                      {deleted_jobs}")
        print(f"  Service Monitoring:        {deleted_service_monitoring}")
        print(f"  Service Compliance:        {deleted_service_compliance}")
        print(f"  Job Monitoring:            {deleted_job_monitoring}")
        print(f"  Job Compliance:            {deleted_job_compliance}")
        print(f"  Alerts:                    {deleted_alerts}")
        print()
        print(f"Total records deleted:       {deleted_aits + deleted_assets + deleted_slas + deleted_services + deleted_jobs + deleted_service_monitoring + deleted_service_compliance + deleted_job_monitoring + deleted_job_compliance + deleted_alerts}")
        
    except Exception as e:
        print(f"Error during cleanup: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    db_path = sys.argv[1] if len(sys.argv) > 1 else 'sla_portal.db'
    cleanup_synthetic_data(db_path)
