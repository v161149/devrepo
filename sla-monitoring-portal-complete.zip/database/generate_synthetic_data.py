"""
Synthetic Data Generator for SLA Compliance Overview - TRULY FINAL
Generates realistic test data for hierarchical SLA monitoring
With correct table schemas
"""

import sqlite3
import uuid
from datetime import datetime, timedelta
import random
import json

def generate_synthetic_data(db_path='sla_portal.db'):
    """Generate comprehensive synthetic data"""
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get org_id (assuming first org)
    cursor.execute("SELECT org_id FROM organizations LIMIT 1")
    org = cursor.fetchone()
    if not org:
        print("No organization found. Creating default org...")
        org_id = f"org-{uuid.uuid4().hex[:12]}"
        cursor.execute("""
            INSERT INTO organizations (org_id, name, domain, created_at)
            VALUES (?, ?, ?, ?)
        """, (org_id, "Demo Organization", "demo.com", datetime.now().isoformat()))
    else:
        org_id = org[0]
    
    print(f"Using org_id: {org_id}")
    
    # Get or create user
    cursor.execute("SELECT user_id FROM users WHERE org_id = ? LIMIT 1", (org_id,))
    user = cursor.fetchone()
    if not user:
        user_id = f"user-{uuid.uuid4().hex[:12]}"
        cursor.execute("""
            INSERT INTO users (user_id, org_id, email, password_hash, first_name, last_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (user_id, org_id, "admin@demo.com", "hash", "Admin", "User", datetime.now().isoformat()))
    else:
        user_id = user[0]
    
    # 1. Create 2 AITs (Business Units)
    aits = []
    ait_names = [
        ("AIT_3193", "Enterprise Data Integration Platforms", "CC-1001", "edptms@demo.com"),
        ("AI_73252", "Data Analytics and Platform Services", "CC-2001", "daps@demo.com")
    ]
    
    for name, short_name, cost_center, contact in ait_names:
        ait_id = f"ait-{uuid.uuid4().hex[:12]}"
        cursor.execute("""
            INSERT INTO aits (ait_id, name, short_name, description, cost_center, 
                            tech_support_contact, status, org_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ait_id, name, short_name, f"Business unit for {name}",
            cost_center, contact, 1, org_id,
            datetime.now().isoformat(), datetime.now().isoformat()
        ))
        aits.append({'ait_id': ait_id, 'name': name})
        print(f"Created AIT: {name} ({ait_id})")
    
    # 2. Create 2-3 applications per AIT
    assets = []
    asset_types = ["application", "application_server", "application_service", "api", "database", "web_server"]
    
    for ait in aits:
        num_apps = random.randint(2, 3)
        for i in range(num_apps):
            asset_id = f"appID-{uuid.uuid4().hex[:12]}"
            asset_name = f"{ait['name']} - App {i+1}"
            asset_type = random.choice(asset_types)
            
            cursor.execute("""
                INSERT INTO assets (asset_id, org_id, ait_id, asset_name, asset_type,
                                  asset_owner, description, onboarded_date, status,
                                  created_at, created_by, updated_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                asset_id, org_id, ait['ait_id'], asset_name, asset_type,
                f"owner-{i}@demo.com", f"Application for {asset_name}",
                datetime.now().isoformat(), 'active',
                datetime.now().isoformat(), user_id, datetime.now().isoformat(),
                json.dumps({"criticality": "high"})
            ))
            assets.append({'asset_id': asset_id, 'asset_name': asset_name, 'ait_id': ait['ait_id']})
            print(f"  Created Asset: {asset_name} ({asset_id})")
    
    # 3. Create 3 types of SLAs per application
    slas = []
    sla_types = [
        {'name': 'On Schedule SLA', 'metric_type': 'on_schedule', 'target_value': 95.0, 'target_unit': 'percentage', 'for': 'jobs'},
        {'name': 'Success Rate SLA', 'metric_type': 'success_rate', 'target_value': 99.5, 'target_unit': 'percentage', 'for': 'jobs'},
        {'name': 'Service Uptime SLA', 'metric_type': 'uptime', 'target_value': 99.9, 'target_unit': 'percentage', 'for': 'services'}
    ]
    
    for asset in assets:
        for sla_type in sla_types:
            sla_id = f"sla-{uuid.uuid4().hex[:12]}"
            sla_name = f"{asset['asset_name']} - {sla_type['name']}"
            
            cursor.execute("""
                INSERT INTO slas (sla_id, org_id, asset_id, name, metric_type,
                                target_value, target_unit, priority,
                                start_condition, stop_condition,
                                effective_from, is_active, created_at, created_by,
                                description, updated_at, version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                sla_id, org_id, asset['asset_id'], sla_name, sla_type['metric_type'],
                sla_type['target_value'], sla_type['target_unit'], 'high',
                'automatic', 'automatic',
                datetime.now().isoformat(), 1, datetime.now().isoformat(), user_id,
                f"SLA for {sla_name}", datetime.now().isoformat(), 1
            ))
            
            slas.append({
                'sla_id': sla_id, 'name': sla_name, 'asset_id': asset['asset_id'],
                'ait_id': asset['ait_id'], 'type': sla_type['for'],
                'metric_type': sla_type['metric_type'], 'target_value': sla_type['target_value']
            })
            print(f"    Created SLA: {sla_name} ({sla_id})")
    
    # 4. Create 5 services per "Service Uptime SLA"
    services = []
    service_slas = [s for s in slas if s['type'] == 'services']
    
    for sla in service_slas:
        for i in range(5):
            service_id = f"svc-{uuid.uuid4().hex[:12]}"
            service_name = f"Service-{i+1} for {sla['name']}"
            
            cursor.execute("""
                INSERT INTO services (service_id, org_id, sla_id, asset_id, name,
                                    description, owner_team, monitoring_method,
                                    is_active, service_identifier, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                service_id, org_id, sla['sla_id'], sla['asset_id'], service_name,
                f"Service monitoring for {service_name}", "DevOps Team", "http_check",
                1, f"SVC-{i+1}", datetime.now().isoformat(), datetime.now().isoformat()
            ))
            
            services.append({
                'service_id': service_id, 'name': service_name,
                'sla_id': sla['sla_id'], 'asset_id': sla['asset_id'], 'ait_id': sla['ait_id']
            })
            print(f"      Created Service: {service_name} ({service_id})")
    
    # 5. Create 5 jobs per "On Schedule SLA" and "Success Rate SLA"
    jobs = []
    job_slas = [s for s in slas if s['type'] == 'jobs']
    
    for sla in job_slas:
        for i in range(5):
            job_id = f"job-{uuid.uuid4().hex[:12]}"
            job_name = f"Job-{i+1} for {sla['name']}"
            job_type = random.choice(['batch', 'etl', 'reporting'])
            
            cursor.execute("""
                INSERT INTO jobs (job_id, org_id, sla_id, asset_id, job_name,
                                job_type, description, schedule, expected_duration,
                                is_active, job_identifier, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                job_id, org_id, sla['sla_id'], sla['asset_id'], job_name,
                job_type, f"Job monitoring for {job_name}", "0 2 * * *", 3600,
                1, f"JOB-{i+1}", datetime.now().isoformat(), datetime.now().isoformat()
            ))
            
            jobs.append({
                'job_id': job_id, 'name': job_name, 'sla_id': sla['sla_id'],
                'asset_id': sla['asset_id'], 'ait_id': sla['ait_id'],
                'metric_type': sla['metric_type']
            })
            print(f"      Created Job: {job_name} ({job_id})")
    
    # 6. Generate compliance data for services (last 30 days)
    # FIXED: Use correct column names from actual schema
    print("\nGenerating service compliance data...")
    service_count = 0
    for service in services:
        for day_offset in range(30):
            date = datetime.now() - timedelta(days=day_offset)
            
            # Generate 24 hourly checks per day
            for hour in range(24):
                check_time = date.replace(hour=hour, minute=0, second=0, microsecond=0)
                result_id = f"svc-result-{uuid.uuid4().hex[:12]}"
                compliance_id = f"comp-{uuid.uuid4().hex[:12]}"
                
                # Create monitoring result
                uptime_pct = random.uniform(98.0, 100.0)
                is_healthy = uptime_pct >= 99.0
                
                # FIXED: Use actual column names: check_time, response_time_ms, is_healthy
                cursor.execute("""
                    INSERT INTO service_monitoring_results 
                    (result_id, service_id, org_id, check_time, status,
                     response_time_ms, is_healthy, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    result_id, service['service_id'], org_id, check_time.isoformat(),
                    'up' if is_healthy else 'down', random.randint(50, 500), is_healthy,
                    json.dumps({"source": "synthetic", "uptime_pct": uptime_pct})
                ))
                
                # Create compliance record
                cursor.execute("SELECT target_value FROM slas WHERE sla_id = ?", (service['sla_id'],))
                target = cursor.fetchone()[0]
                
                met_sla = uptime_pct >= target
                
                cursor.execute("""
                    INSERT INTO service_sla_compliance
                    (compliance_id, result_id, sla_id, org_id, met_sla,
                     measured_value, target_value, threshold_value,
                     measurement_type, breach_severity, breach_details, evaluated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    compliance_id, result_id, service['sla_id'], org_id, met_sla,
                    uptime_pct, target, target - 1.0, 'uptime',
                    'none' if met_sla else 'critical',
                    json.dumps({}) if met_sla else json.dumps({"reason": "below_threshold"}),
                    check_time.isoformat()
                ))
                service_count += 1
    
    print(f"  Generated {service_count} service compliance records")
    
    # 7. Generate compliance data for jobs (last 30 days)
    # FIXED: Use correct column names from actual schema
    print("Generating job compliance data...")
    job_count = 0
    for job in jobs:
        for day_offset in range(30):
            date = datetime.now() - timedelta(days=day_offset)
            run_time = date.replace(hour=2, minute=0, second=0, microsecond=0)
            
            result_id = f"job-result-{uuid.uuid4().hex[:12]}"
            compliance_id = f"comp-{uuid.uuid4().hex[:12]}"
            
            # Get SLA info
            cursor.execute("SELECT metric_type, target_value FROM slas WHERE sla_id = ?", (job['sla_id'],))
            sla_info = cursor.fetchone()
            metric_type = sla_info[0]
            target_value = sla_info[1]
            
            # Create job monitoring result
            if metric_type == 'on_schedule':
                expected_duration = 3600  # 1 hour
                actual_duration = random.randint(2000, 4500)
                on_schedule = actual_duration <= expected_duration
                measured_value = (1 if on_schedule else 0) * 100
                status = 'success' if on_schedule else 'failed'
                records_processed = random.randint(1000, 10000)
            else:  # success_rate
                is_success = random.random() < 0.995
                measured_value = 100.0 if is_success else 0.0
                status = 'success' if is_success else 'failed'
                actual_duration = random.randint(2000, 3800)
                records_processed = random.randint(1000, 10000)
            
            end_time = run_time + timedelta(seconds=actual_duration)
            
            # FIXED: Use actual column names from schema
            cursor.execute("""
                INSERT INTO job_monitoring_results
                (result_id, job_id, org_id, check_time, status,
                 execution_start_time, execution_end_time, duration_seconds,
                 records_processed, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result_id, job['job_id'], org_id, run_time.isoformat(), status,
                run_time.isoformat(), end_time.isoformat(), actual_duration,
                records_processed, json.dumps({"source": "synthetic"})
            ))
            
            # Create compliance record
            met_sla = measured_value >= target_value
            
            cursor.execute("""
                INSERT INTO job_sla_compliance
                (compliance_id, result_id, sla_id, org_id, met_sla,
                 measured_value, target_value, threshold_value,
                 measurement_type, breach_severity, breach_details, evaluated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                compliance_id, result_id, job['sla_id'], org_id, met_sla,
                measured_value, target_value, target_value - 5.0, metric_type,
                'none' if met_sla else 'critical',
                json.dumps({}) if met_sla else json.dumps({"reason": "threshold_breach"}),
                run_time.isoformat()
            ))
            job_count += 1
    
    print(f"  Generated {job_count} job compliance records")

    # 8. Generate synthetic alerts based on breaches
    print("Generating synthetic alerts...")
    alert_count = 0

    # Get breaches from service compliance (last 7 days for active alerts)
    cursor.execute("""
        SELECT DISTINCT
            ssc.compliance_id,
            ssc.sla_id,
            smr.service_id,
            ssc.evaluated_at,
            ssc.measured_value,
            ssc.target_value
        FROM service_sla_compliance ssc
        JOIN service_monitoring_results smr ON ssc.result_id = smr.result_id
        WHERE ssc.met_sla = 0 
        AND ssc.evaluated_at >= datetime('now', '-7 days')
        AND ssc.org_id = ?
        ORDER BY RANDOM()
        LIMIT 20
    """, (org_id,))

    service_breaches = cursor.fetchall()

    for breach in service_breaches:
        alert_id = f"alert-{uuid.uuid4().hex[:12]}"
        compliance_id = breach[0]
        sla_id = breach[1]
        service_id = breach[2]
        breach_time = breach[3]
        measured = breach[4]
        target = breach[5]
        
        # Determine severity based on how far below target
        diff = target - measured
        if diff > 5:
            severity = 'critical'
            alert_type = 'breach'
        elif diff > 2:
            severity = 'high'
            alert_type = 'breach'
        else:
            severity = 'medium'
            alert_type = 'warning'
        
        # Get SLA and service names
        cursor.execute("SELECT name FROM slas WHERE sla_id = ?", (sla_id,))
        sla_name = cursor.fetchone()[0]
        
        cursor.execute("SELECT name FROM services WHERE service_id = ?", (service_id,))
        service_name = cursor.fetchone()[0]
        
        message = f"SLA breach detected: {service_name} - {sla_name}. Measured: {measured:.2f}%, Target: {target:.2f}%"
        
        # Random status for realism
        status = random.choice(['pending', 'sent', 'sent', 'sent', 'acknowledged'])
        sent_timestamp = breach_time if status in ['sent', 'acknowledged'] else None
        acknowledged_by = user_id if status == 'acknowledged' else None
        acknowledged_at = datetime.fromisoformat(breach_time) + timedelta(hours=random.randint(1, 6)) if status == 'acknowledged' else None
        
        cursor.execute("""
            INSERT INTO alerts (
                alert_id, org_id, evaluation_id, sla_id, service_id,
                alert_type, severity, message, channels, sent_timestamp,
                status, acknowledged_by, acknowledged_at, metadata, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alert_id, org_id, compliance_id, sla_id, service_id,
            alert_type, severity, message, json.dumps(['email', 'slack']),
            sent_timestamp, status, acknowledged_by,
            acknowledged_at.isoformat() if acknowledged_at else None,
            json.dumps({"source": "synthetic", "breach_percentage": diff}),
            breach_time
        ))
        alert_count += 1

    # Get breaches from job compliance (last 7 days)
    cursor.execute("""
        SELECT DISTINCT
            jsc.compliance_id,
            jsc.sla_id,
            jmr.job_id,
            jsc.evaluated_at,
            jsc.measured_value,
            jsc.target_value
        FROM job_sla_compliance jsc
        JOIN job_monitoring_results jmr ON jsc.result_id = jmr.result_id
        WHERE jsc.met_sla = 0 
        AND jsc.evaluated_at >= datetime('now', '-7 days')
        AND jsc.org_id = ?
        ORDER BY RANDOM()
        LIMIT 15
    """, (org_id,))

    job_breaches = cursor.fetchall()

    for breach in job_breaches:
        alert_id = f"alert-{uuid.uuid4().hex[:12]}"
        compliance_id = breach[0]
        sla_id = breach[1]
        job_id = breach[2]
        breach_time = breach[3]
        measured = breach[4]
        target = breach[5]
        
        # For jobs, we need to get a related service_id (alerts table requires it)
        # Get service from the same asset as the job
        cursor.execute("""
            SELECT s.service_id 
            FROM services s
            JOIN jobs j ON s.asset_id = j.asset_id
            WHERE j.job_id = ?
            LIMIT 1
        """, (job_id,))
        
        service_result = cursor.fetchone()
        if not service_result:
            continue
        service_id = service_result[0]
        
        # Determine severity
        diff = target - measured
        if measured == 0:  # Complete failure
            severity = 'critical'
            alert_type = 'breach'
        elif diff > 10:
            severity = 'high'
            alert_type = 'breach'
        else:
            severity = 'medium'
            alert_type = 'warning'
        
        # Get SLA and job names
        cursor.execute("SELECT name FROM slas WHERE sla_id = ?", (sla_id,))
        sla_name = cursor.fetchone()[0]
        
        cursor.execute("SELECT job_name FROM jobs WHERE job_id = ?", (job_id,))
        job_name = cursor.fetchone()[0]
        
        message = f"SLA breach detected: {job_name} - {sla_name}. Success rate: {measured:.2f}%, Target: {target:.2f}%"
        
        # Random status
        status = random.choice(['pending', 'sent', 'sent', 'acknowledged'])
        sent_timestamp = breach_time if status in ['sent', 'acknowledged'] else None
        acknowledged_by = user_id if status == 'acknowledged' else None
        acknowledged_at = datetime.fromisoformat(breach_time) + timedelta(hours=random.randint(1, 8)) if status == 'acknowledged' else None
        
        cursor.execute("""
            INSERT INTO alerts (
                alert_id, org_id, evaluation_id, sla_id, service_id,
                alert_type, severity, message, channels, sent_timestamp,
                status, acknowledged_by, acknowledged_at, metadata, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alert_id, org_id, compliance_id, sla_id, service_id,
            alert_type, severity, message, json.dumps(['email']),
            sent_timestamp, status, acknowledged_by,
            acknowledged_at.isoformat() if acknowledged_at else None,
            json.dumps({"source": "synthetic", "job_id": job_id, "breach_percentage": diff}),
            breach_time
        ))
        alert_count += 1

    print(f"  Generated {alert_count} synthetic alerts")

    # Update the final summary print to include alerts
    # Modify the final print section to add:
    print(f"  - {alert_count} Alerts")

    conn.commit()
    conn.close()
    
    print("\n" + "="*60)
    print("SYNTHETIC DATA GENERATION COMPLETE")
    print("="*60)
    print(f"Created:")
    print(f"  - {len(aits)} AITs")
    print(f"  - {len(assets)} Assets/Applications")
    print(f"  - {len(slas)} SLAs")
    print(f"  - {len(services)} Services")
    print(f"  - {len(jobs)} Jobs")
    print(f"  - {service_count} Service compliance records")
    print(f"  - {job_count} Job compliance records")
    print("="*60)

if __name__ == "__main__":
    import sys
    db_path = sys.argv[1] if len(sys.argv) > 1 else 'sla_portal.db'
    generate_synthetic_data(db_path)
