package edu.jasper.research.ai;

import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.neural.networks.BasicNetwork;
import org.encog.util.arrayutil.NormalizationAction;
import org.encog.util.arrayutil.NormalizedField;

public class AISelfPilotProcessor {
	private BasicNetwork network;
	private RocketThrottleController throttleController;
	private boolean track;
    private NormalizedField fuelStats;
    private NormalizedField altitudeStats;
    private NormalizedField velocityStats;
    
    //Collect initial flying parameters of the first stage at certain moment when it starts falling.
	public AISelfPilotProcessor(BasicNetwork network, boolean track,int fuelSesor, double altitudeSensor, double velocitySensor)
	{
		throttleController = new RocketThrottleController();
		throttleController.enableSelfPilotMode(fuelSesor,altitudeSensor, velocitySensor);
        fuelStats = new NormalizedField(NormalizationAction.Normalize, "fuel", fuelSesor, 0, -0.9, 0.9);
        altitudeStats = new NormalizedField(NormalizationAction.Normalize, "altitude", altitudeSensor, 0, -0.9, 0.9);
        velocityStats = new NormalizedField(NormalizationAction.Normalize, "velocity", RocketThrottleController.EARTH_TERMINAL_VELOCITY, -RocketThrottleController.EARTH_TERMINAL_VELOCITY, -0.9, 0.9);

		this.track = track;
		this.network = network;
	}
	
	public int evaluateAISelfPilotPerfMetric()
	{
		try {
			while(throttleController.flying())
			{
				MLData input = new BasicMLData(3);
				input.setData(0, this.fuelStats.normalize(throttleController.readFuel()));
				input.setData(1, this.altitudeStats.normalize(throttleController.readAltitude()));
				input.setData(2, this.velocityStats.normalize(throttleController.readtVelocity()));
				MLData output = this.network.compute(input);
				double value = output.getData(0);

				boolean thrust;
				
				if( value > 0 ) {
					thrust = true;
					if( track )
						System.out.println("THRUST");
						//Thread.sleep(1000);
				} else {
					thrust = false;
				}
				throttleController.turn(thrust);
				if( track ) {
					System.out.println(throttleController.readRocketFlyingParameters());
				}
		    }
		} catch (Exception e) {
		  e.printStackTrace();
	    }
		return(throttleController.score());
	}    
}
