package edu.jasper.research.ai;

import org.encog.ml.CalculateScore;
import org.encog.ml.MLMethod;
import org.encog.neural.networks.BasicNetwork;

public class AISelfPilotPerfMetric implements CalculateScore {
	
	private int fuelSesor=0;
	private double altitudeSensor=0;
	private double velocitySensor=0;
	
	public AISelfPilotPerfMetric(int fuelSesor, double altitudeSensor, double velocitySensor) {
		this.fuelSesor=fuelSesor;
		this.altitudeSensor=altitudeSensor;
		this.velocitySensor=velocitySensor;
	}
	
	//@Override
	public double calculateScore(MLMethod network) {
		AISelfPilotProcessor pilot = new AISelfPilotProcessor((BasicNetwork)network, false,this.fuelSesor,this.altitudeSensor,this.velocitySensor);
		return pilot.evaluateAISelfPilotPerfMetric();
	}


	public boolean shouldMinimize() {
		return false;
	}


	//@Override
	public boolean requireSingleThreaded() {
		return false;
	}
}
