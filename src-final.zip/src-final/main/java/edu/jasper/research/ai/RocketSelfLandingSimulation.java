package edu.jasper.research.ai;

import org.encog.Encog;
import org.encog.ml.MLMethod;
import org.encog.ml.MLResettable;
import org.encog.ml.MethodFactory;
import org.encog.ml.genetic.MLMethodGeneticAlgorithm;
import org.encog.ml.train.MLTrain;
import org.encog.neural.networks.BasicNetwork;

public class RocketSelfLandingSimulation {
	
	public static void main(String args[])
	{
		  try {
			    System.out.println("*=======================================================================================================*");
				System.out.println("*This program simulates how reusable orbital rocket use Deep Learning Neural Network Algorithms         *");
				System.out.println("*back to Earth for a soft touchdown (-2 m/s ~ +2 ms).                                                                    *");
				System.out.println("*-------------------------------------------------------------------------------------------------------*");
				System.out.println("*The orbital rocket starts with 200 liters and the altitude is set to 10,000 meters above Earth surface.*");
				System.out.println("*The fuel variable holds the amount of fuel remaining.                                                  *");
				System.out.println("*The time variable holds the number of seconds aloft.                                                   *");
				System.out.println("*The altitude variable holds the current altitude in meters.                                            *");
				System.out.println("*The velocity variable holds the current velocity.                                                      *");
				System.out.println("*Positive numbers indicate that the craft is moving upwards.                                            *");
				System.out.println("*Negative numbers indicate that the craft is moving downwards.                                          *");
				System.out.println("*The thrust parameter indicates whether the orbital rocket needs to thrust during this turn             *");
				System.out.println("*-------------------------------------------------------------------------------------------------------*");
				System.out.println("*The simulator sets the values to reasonable starting values in the following :                         *");
				System.out.println("*             f u e l         = 200   liters                                                            *");
				System.out.println("*             timer           = 0     seconds                                                           *");
				System.out.println("*             a l t i t u d e = 125000 meters                                                            *");
				System.out.println("*=======================================================================================================*");
				Thread.sleep(10000);
				
				//we start the simulation when the first stage captures the below flying parameters values through the system sensors
				int initialFuel=200;
				double initialAltitude=125000;
				double initialVelocity=0;
				MLTrain train;
				
				train = new MLMethodGeneticAlgorithm(new MethodFactory(){
					//@Override
					public MLMethod factor() {
						//create an AI Deep Learning network
						AIDeepLearningNetworkCreator aiCreator = new AIDeepLearningNetworkCreator();
						final BasicNetwork result = aiCreator.createAIDeepLearningNetwork();
						((MLResettable)result).reset();
						return result;
					}},new AISelfPilotPerfMetric(initialFuel,initialAltitude,initialVelocity),800);
				
				int epoch = 1;

				for(int i=0;i<100;i++) {
					train.iteration();
					System.out.println("Epoch #" + epoch + " Score:" + train.getError());
					epoch++;
				} 
				train.finishTraining();

				System.out.println("\nHow the winning network landed:");
				BasicNetwork network = (BasicNetwork)train.getMethod();
				AISelfPilotProcessor pilot = new AISelfPilotProcessor(network,true,initialFuel,initialAltitude,initialVelocity);
				System.out.println(pilot.evaluateAISelfPilotPerfMetric());
				Encog.getInstance().shutdown();
				//Thread.sleep(10000);
		  } catch(Exception exp) {
			  exp.printStackTrace();
		  }
	}
}
