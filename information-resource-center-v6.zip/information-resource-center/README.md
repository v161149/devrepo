# Information Resource Center

A comprehensive React-based web portal for managing data resources, IT operations, and AI-powered solutions. This portal supports 19 different platforms and databases with a microservices backend architecture.

## Features

### Implemented Features

1. **Home Page** - Landing page with news carousel, announcements, and quick links
2. **Communication & Support** - Help center with search functionality and popular topics
3. **Contact Us** - Three contact options: Email, Chat, and Demo requests
4. **About Us** - Company information with mission and story sections
5. **Management Team** - Tabbed interface for Management, Development, and Operation teams
6. **Products & Services** - Category-based product browsing with three main categories:
   - Data Management and Storage Solutions (11 products)
   - IT Operations and Orchestration Tools (3 products)
   - AI Large Language Models and Related Products (5 products)
7. **Product Details** - Collapsible service categories with detailed functionality listings
8. **Global Search** - Search overlay accessible from header
9. **Admin Menu** - News management (Create, Edit, Delete, Publish) for admin users
10. **User Authentication** - Login/logout with role-based access control

### Placeholder Features (To Be Migrated Later)

- SLA Management
- Asset Management
- Data Pipeline Management
- Operations Dashboard

## Supported Products/Platforms

### Data Management and Storage Solutions
- Teradata Platform and Databases
- Oracle Platform and Databases
- SQL Server Databases
- Mainframe DB2
- MySQL
- PostgreSQL
- Cassandra
- MongoDB
- Hadoop Hive
- Hadoop HDFS
- Snowflake

### IT Operations and Orchestration Tools
- Airflow
- Splunk
- Dynatrace

### AI Large Language Models (LLMs)
- Microsoft Copilot
- GPT series (OpenAI)
- Gemini models (Google DeepMind)
- Llama series (Meta AI)
- Grok (xAI)

## Technology Stack

### Frontend
- React 18
- React Router DOM 6
- Axios for API calls
- Lucide React for icons

### Backend
- Python 3
- Flask
- Flask-CORS
- SQLite3

## Project Structure

```
information-resource-center/
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   └── Header.js
│   │   ├── contexts/
│   │   │   └── AuthContext.js
│   │   ├── data/
│   │   │   └── products.js
│   │   ├── pages/
│   │   │   ├── Home.js
│   │   │   ├── CommunicationSupport.js
│   │   │   ├── ContactUs.js
│   │   │   ├── AboutUs.js
│   │   │   ├── ManagementTeam.js
│   │   │   ├── ProductsServices.js
│   │   │   └── ProductDetails.js
│   │   ├── App.js
│   │   ├── App.css
│   │   └── index.js
│   └── package.json
├── backend/
│   ├── app.py
│   └── populate_services.py
├── database/
│   └── schema.sql
└── README.md
```

## Installation & Setup

### Prerequisites
- Node.js 16+ and npm
- Python 3.8+
- pip

### Backend Setup

1. Navigate to the project directory:
```bash
cd information-resource-center
```

2. Install Python dependencies:
```bash
pip install flask flask-cors pandas openpyxl
```

3. Initialize the database:
```bash
cd backend
python app.py
```
The database will be automatically created with sample data.

4. (Optional) Populate service categories from Excel:
```bash
python populate_services.py
```

### Frontend Setup

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Running Both Together

Terminal 1 - Backend:
```bash
cd backend
python app.py
```

Terminal 2 - Frontend:
```bash
cd frontend
npm start
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout

### News
- `GET /api/news` - Get published news
- `GET /api/news/:id` - Get specific news item
- `GET /api/admin/news` - Get all news (admin)
- `POST /api/admin/news` - Create news (admin)
- `PUT /api/admin/news/:id` - Update news (admin)
- `DELETE /api/admin/news/:id` - Delete news (admin)
- `POST /api/admin/news/:id/publish` - Publish news (admin)

### Teams
- `GET /api/teams/:teamType` - Get team content and members
- `PUT /api/admin/teams/:teamType` - Update team content (admin)
- `POST /api/admin/team-members` - Add team member (admin)
- `PUT /api/admin/team-members/:id` - Update team member (admin)
- `DELETE /api/admin/team-members/:id` - Delete team member (admin)

### Products & Services
- `GET /api/product-categories` - Get all product categories
- `GET /api/products` - Get all products
- `GET /api/products?category_id=:id` - Get products by category
- `GET /api/products/:id` - Get product with service categories
- `GET /api/products/:id/services` - Get services for a product

### About & Contact
- `GET /api/about` - Get about us content
- `PUT /api/admin/about` - Update about content (admin)
- `POST /api/contact` - Submit contact request

### Search
- `GET /api/search?q=:query` - Global search

## Demo Users

### Admin User
- Username: `admin`
- Role: Administrator (can access Admin menu)

### Regular User
- Username: `user`
- Role: Standard user

Click "Log in" in the header to simulate login as admin user.

## Development Notes

### Adding New Products
Products are defined in `/frontend/src/data/products.js`. Each product includes:
- Basic info (name, description, icon)
- Service categories with sub-categories
- Functionalities for each service

### Styling
All styles are in `/frontend/src/App.css`. The design follows the mockup specifications with:
- Orange brand color: #e84e36
- Dark teal accent: #2d4a4a
- Clean, modern UI with card-based layouts

### Future Enhancements
1. Implement actual search functionality
2. Add email/chat/demo request handling
3. Migrate SLA, Asset, Pipeline, and Dashboard modules
4. Add user registration and password management
5. Implement real authentication with JWT
6. Add product icons from official sources
7. Implement admin CRUD interfaces

## License

MIT License

## Support

For questions or issues, please use the Communication & Support page in the portal or contact the development team.
