"""
Script to populate the database with service categories and services from the Excel file
"""

import pandas as pd
import sqlite3
import os

# Paths
EXCEL_PATH = '/mnt/user-data/uploads/All_Products_Requirements_Comprehensive.xlsx'
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'irc.db')

# Product mapping from Excel sheet names to database product short names
PRODUCT_MAPPING = {
    'Teradata Database': 'Teradata',
    'Oracle Database': 'Oracle',
    'SQL Server Database': 'SQL Server',
    'Mainframe DB2': 'DB2',
    'MySQL': 'MySQL',
    'PostgreSQL': 'PostgreSQL',
    'Cassandra': 'Cassandra',
    'MongoDB': 'MongoDB',
    'Hadoop Hive': 'Hive',
    'Hadoop HDFS': 'HDFS',
    'Airflow': 'Airflow',
    'Snowflake': 'Snowflake',
    'Splunk': 'Splunk',
    'Dynatrace': 'Dynatrace',
    'Microsoft Copilot': 'Copilot',
    'GPT series (OpenAI)': 'GPT',
    'Gemini models (Google DeepMind)': 'Gemini',
    'Llama series (Meta AI)': 'Llama',
    'Grok (xAI)': 'Grok'
}

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def parse_excel_sheet(sheet_name):
    """Parse an Excel sheet and extract categories and services"""
    df = pd.read_excel(EXCEL_PATH, sheet_name=sheet_name)
    
    categories = []
    current_category = None
    
    for idx, row in df.iterrows():
        col_a = str(row.iloc[0]) if pd.notna(row.iloc[0]) else ""
        col_b = str(row.iloc[1]) if pd.notna(row.iloc[1]) else ""
        col_c = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""
        
        # Skip header rows
        if 'Category #' in col_a or col_a == 'nan' or col_b == 'nan':
            continue
        
        # Check if it's a main category (integer number like 1, 2, 3)
        try:
            col_a_stripped = col_a.strip()
            if '.' not in col_a_stripped and col_a_stripped.isdigit():
                current_category = {
                    'number': col_a_stripped,
                    'name': col_b.strip(),
                    'services': []
                }
                categories.append(current_category)
            elif '.' in col_a_stripped and current_category:
                # It's a sub-category/service
                current_category['services'].append({
                    'number': col_a_stripped,
                    'name': col_b.strip(),
                    'functionalities': col_c.strip() if col_c != 'nan' else ''
                })
        except Exception as e:
            continue
    
    return categories

def populate_services():
    """Populate service categories and services in the database"""
    conn = get_db_connection()
    
    # First, clear existing service data
    conn.execute('DELETE FROM services')
    conn.execute('DELETE FROM service_categories')
    
    xl = pd.ExcelFile(EXCEL_PATH)
    
    for sheet_name in xl.sheet_names:
        short_name = PRODUCT_MAPPING.get(sheet_name)
        if not short_name:
            print(f"Skipping unknown sheet: {sheet_name}")
            continue
        
        # Get product ID
        product = conn.execute(
            'SELECT id FROM products WHERE short_name = ?', (short_name,)
        ).fetchone()
        
        if not product:
            print(f"Product not found for: {short_name}")
            continue
        
        product_id = product['id']
        
        # Parse categories from Excel
        categories = parse_excel_sheet(sheet_name)
        
        for cat_idx, category in enumerate(categories):
            # Insert service category
            cursor = conn.execute(
                '''INSERT INTO service_categories (product_id, category_number, name, display_order)
                   VALUES (?, ?, ?, ?)''',
                (product_id, category['number'], category['name'], cat_idx + 1)
            )
            category_id = cursor.lastrowid
            
            # Insert services
            for svc_idx, service in enumerate(category['services']):
                conn.execute(
                    '''INSERT INTO services (service_category_id, service_number, name, functionalities, display_order)
                       VALUES (?, ?, ?, ?, ?)''',
                    (category_id, service['number'], service['name'], 
                     service['functionalities'], svc_idx + 1)
                )
        
        print(f"Populated services for: {sheet_name}")
    
    conn.commit()
    conn.close()
    print("\nDatabase population complete!")

if __name__ == '__main__':
    populate_services()
