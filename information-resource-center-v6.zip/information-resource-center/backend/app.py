"""
Information Resource Center - Backend API
Flask-based microservices for the IRC portal
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import os
import json
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app)

# Database path
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'irc.db')

def get_db_connection():
    """Create a database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database with schema"""
    schema_path = os.path.join(os.path.dirname(__file__), '..', 'database', 'schema.sql')
    if not os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        with open(schema_path, 'r') as f:
            conn.executescript(f.read())
        conn.commit()
        conn.close()
        print("Database initialized successfully")

# Initialize database on startup
init_db()

# ==================== Authentication Routes ====================

@app.route('/api/auth/login', methods=['POST'])
def login():
    """User login endpoint"""
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE username = ? AND is_active = 1', 
                       (username,)).fetchone()
    conn.close()
    
    if user:
        # For demo purposes, accept any password
        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'firstName': user['first_name'],
                'lastName': user['last_name'],
                'role': user['role']
            }
        })
    
    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """User logout endpoint"""
    return jsonify({'success': True})

# ==================== News Routes ====================

@app.route('/api/news', methods=['GET'])
def get_news():
    """Get all published news"""
    news_type = request.args.get('type')
    
    conn = get_db_connection()
    if news_type:
        news = conn.execute(
            'SELECT * FROM news WHERE status = "published" AND news_type = ? ORDER BY published_at DESC',
            (news_type,)
        ).fetchall()
    else:
        news = conn.execute(
            'SELECT * FROM news WHERE status = "published" ORDER BY published_at DESC'
        ).fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in news])

@app.route('/api/news/<int:news_id>', methods=['GET'])
def get_news_item(news_id):
    """Get a specific news item"""
    conn = get_db_connection()
    news = conn.execute('SELECT * FROM news WHERE id = ?', (news_id,)).fetchone()
    conn.close()
    
    if news:
        return jsonify(dict(news))
    return jsonify({'error': 'News not found'}), 404

@app.route('/api/admin/news', methods=['GET'])
def get_all_news():
    """Get all news (admin only)"""
    conn = get_db_connection()
    news = conn.execute('SELECT * FROM news ORDER BY created_at DESC').fetchall()
    conn.close()
    return jsonify([dict(row) for row in news])

@app.route('/api/admin/news', methods=['POST'])
def create_news():
    """Create a new news item (admin only)"""
    data = request.get_json()
    
    conn = get_db_connection()
    cursor = conn.execute(
        '''INSERT INTO news (title, content, news_type, status, image_url, author_id, published_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)''',
        (data['title'], data['content'], data['news_type'], 
         data.get('status', 'draft'), data.get('image_url'),
         data.get('author_id'), 
         datetime.now() if data.get('status') == 'published' else None)
    )
    conn.commit()
    news_id = cursor.lastrowid
    conn.close()
    
    return jsonify({'success': True, 'id': news_id}), 201

@app.route('/api/admin/news/<int:news_id>', methods=['PUT'])
def update_news(news_id):
    """Update a news item (admin only)"""
    data = request.get_json()
    
    conn = get_db_connection()
    conn.execute(
        '''UPDATE news SET title = ?, content = ?, news_type = ?, status = ?, 
           image_url = ?, updated_at = ?, published_at = ?
           WHERE id = ?''',
        (data['title'], data['content'], data['news_type'], data['status'],
         data.get('image_url'), datetime.now(),
         datetime.now() if data['status'] == 'published' else None, news_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/admin/news/<int:news_id>', methods=['DELETE'])
def delete_news(news_id):
    """Delete a news item (admin only)"""
    conn = get_db_connection()
    conn.execute('DELETE FROM news WHERE id = ?', (news_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/admin/news/<int:news_id>/publish', methods=['POST'])
def publish_news(news_id):
    """Publish a news item (admin only)"""
    conn = get_db_connection()
    conn.execute(
        'UPDATE news SET status = "published", published_at = ? WHERE id = ?',
        (datetime.now(), news_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

# ==================== Team Content Routes ====================

@app.route('/api/teams/<team_type>', methods=['GET'])
def get_team_content(team_type):
    """Get team content and members"""
    conn = get_db_connection()
    
    # Get team content
    content = conn.execute(
        'SELECT * FROM team_content WHERE team_type = ? AND status = "published" ORDER BY created_at DESC LIMIT 1',
        (team_type,)
    ).fetchone()
    
    # Get team members
    members = conn.execute(
        'SELECT * FROM team_members WHERE team_type = ? AND is_active = 1 ORDER BY display_order',
        (team_type,)
    ).fetchall()
    
    conn.close()
    
    return jsonify({
        'content': dict(content) if content else None,
        'members': [dict(row) for row in members]
    })

@app.route('/api/admin/teams/<team_type>', methods=['PUT'])
def update_team_content(team_type):
    """Update team content (admin only)"""
    data = request.get_json()
    
    conn = get_db_connection()
    
    # Check if content exists
    existing = conn.execute(
        'SELECT id FROM team_content WHERE team_type = ?', (team_type,)
    ).fetchone()
    
    if existing:
        conn.execute(
            '''UPDATE team_content SET content = ?, title = ?, status = ?, updated_at = ?
               WHERE team_type = ?''',
            (data['content'], data.get('title'), data.get('status', 'published'),
             datetime.now(), team_type)
        )
    else:
        conn.execute(
            '''INSERT INTO team_content (team_type, title, content, status)
               VALUES (?, ?, ?, ?)''',
            (team_type, data.get('title'), data['content'], data.get('status', 'published'))
        )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/admin/team-members', methods=['POST'])
def add_team_member():
    """Add a team member (admin only)"""
    data = request.get_json()
    
    conn = get_db_connection()
    cursor = conn.execute(
        '''INSERT INTO team_members (team_type, name, title, bio, image_url, email, linkedin_url, display_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
        (data['team_type'], data['name'], data.get('title'), data.get('bio'),
         data.get('image_url'), data.get('email'), data.get('linkedin_url'),
         data.get('display_order', 0))
    )
    conn.commit()
    member_id = cursor.lastrowid
    conn.close()
    
    return jsonify({'success': True, 'id': member_id}), 201

@app.route('/api/admin/team-members/<int:member_id>', methods=['PUT'])
def update_team_member(member_id):
    """Update a team member (admin only)"""
    data = request.get_json()
    
    conn = get_db_connection()
    conn.execute(
        '''UPDATE team_members SET name = ?, title = ?, bio = ?, image_url = ?,
           email = ?, linkedin_url = ?, display_order = ?, updated_at = ?
           WHERE id = ?''',
        (data['name'], data.get('title'), data.get('bio'), data.get('image_url'),
         data.get('email'), data.get('linkedin_url'), data.get('display_order', 0),
         datetime.now(), member_id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/admin/team-members/<int:member_id>', methods=['DELETE'])
def delete_team_member(member_id):
    """Delete a team member (admin only)"""
    conn = get_db_connection()
    conn.execute('DELETE FROM team_members WHERE id = ?', (member_id,))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

# ==================== Products & Services Routes ====================

@app.route('/api/product-categories', methods=['GET'])
def get_product_categories():
    """Get all product categories"""
    conn = get_db_connection()
    categories = conn.execute(
        'SELECT * FROM product_categories ORDER BY display_order'
    ).fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in categories])

@app.route('/api/products', methods=['GET'])
def get_products():
    """Get products, optionally filtered by category"""
    category_id = request.args.get('category_id')
    
    conn = get_db_connection()
    if category_id:
        products = conn.execute(
            'SELECT * FROM products WHERE category_id = ? AND is_active = 1 ORDER BY display_order',
            (category_id,)
        ).fetchall()
    else:
        products = conn.execute(
            'SELECT * FROM products WHERE is_active = 1 ORDER BY category_id, display_order'
        ).fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in products])

@app.route('/api/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Get a specific product with its service categories"""
    conn = get_db_connection()
    
    product = conn.execute(
        'SELECT * FROM products WHERE id = ?', (product_id,)
    ).fetchone()
    
    if not product:
        conn.close()
        return jsonify({'error': 'Product not found'}), 404
    
    # Get service categories for this product
    categories = conn.execute(
        'SELECT * FROM service_categories WHERE product_id = ? ORDER BY display_order',
        (product_id,)
    ).fetchall()
    
    # Get services for each category
    result = dict(product)
    result['service_categories'] = []
    
    for cat in categories:
        cat_dict = dict(cat)
        services = conn.execute(
            'SELECT * FROM services WHERE service_category_id = ? ORDER BY display_order',
            (cat['id'],)
        ).fetchall()
        cat_dict['services'] = [dict(s) for s in services]
        result['service_categories'].append(cat_dict)
    
    conn.close()
    return jsonify(result)

@app.route('/api/products/<int:product_id>/services', methods=['GET'])
def get_product_services(product_id):
    """Get all service categories and services for a product"""
    conn = get_db_connection()
    
    categories = conn.execute(
        'SELECT * FROM service_categories WHERE product_id = ? ORDER BY display_order',
        (product_id,)
    ).fetchall()
    
    result = []
    for cat in categories:
        cat_dict = dict(cat)
        services = conn.execute(
            'SELECT * FROM services WHERE service_category_id = ? ORDER BY display_order',
            (cat['id'],)
        ).fetchall()
        cat_dict['services'] = [dict(s) for s in services]
        result.append(cat_dict)
    
    conn.close()
    return jsonify(result)

# ==================== About Us Routes ====================

@app.route('/api/about', methods=['GET'])
def get_about_content():
    """Get all about us content"""
    conn = get_db_connection()
    content = conn.execute(
        'SELECT * FROM about_content WHERE status = "published" ORDER BY display_order'
    ).fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in content])

@app.route('/api/admin/about', methods=['PUT'])
def update_about_content():
    """Update about us content (admin only)"""
    data = request.get_json()
    
    conn = get_db_connection()
    conn.execute(
        '''UPDATE about_content SET title = ?, content = ?, updated_at = ?
           WHERE section_type = ?''',
        (data.get('title'), data['content'], datetime.now(), data['section_type'])
    )
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

# ==================== Contact Routes ====================

@app.route('/api/contact', methods=['POST'])
def submit_contact():
    """Submit a contact request"""
    data = request.get_json()
    
    conn = get_db_connection()
    cursor = conn.execute(
        '''INSERT INTO contact_requests (request_type, name, email, company, message)
           VALUES (?, ?, ?, ?, ?)''',
        (data['request_type'], data.get('name'), data.get('email'),
         data.get('company'), data.get('message'))
    )
    conn.commit()
    request_id = cursor.lastrowid
    conn.close()
    
    return jsonify({'success': True, 'id': request_id}), 201

@app.route('/api/admin/contacts', methods=['GET'])
def get_contact_requests():
    """Get all contact requests (admin only)"""
    conn = get_db_connection()
    requests = conn.execute(
        'SELECT * FROM contact_requests ORDER BY created_at DESC'
    ).fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in requests])

# ==================== Search Routes ====================

@app.route('/api/search', methods=['GET'])
def search():
    """Global search endpoint"""
    query = request.args.get('q', '')
    
    if not query or len(query) < 2:
        return jsonify([])
    
    conn = get_db_connection()
    results = []
    
    # Search in news
    news = conn.execute(
        '''SELECT id, title, content, 'news' as type FROM news 
           WHERE status = 'published' AND (title LIKE ? OR content LIKE ?)''',
        (f'%{query}%', f'%{query}%')
    ).fetchall()
    results.extend([dict(row) for row in news])
    
    # Search in products
    products = conn.execute(
        '''SELECT id, name as title, description as content, 'product' as type FROM products 
           WHERE is_active = 1 AND (name LIKE ? OR description LIKE ?)''',
        (f'%{query}%', f'%{query}%')
    ).fetchall()
    results.extend([dict(row) for row in products])
    
    # Search in services
    services = conn.execute(
        '''SELECT id, name as title, description as content, 'service' as type FROM services 
           WHERE is_active = 1 AND (name LIKE ? OR description LIKE ?)''',
        (f'%{query}%', f'%{query}%')
    ).fetchall()
    results.extend([dict(row) for row in services])
    
    conn.close()
    return jsonify(results)

# ==================== Health Check ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
