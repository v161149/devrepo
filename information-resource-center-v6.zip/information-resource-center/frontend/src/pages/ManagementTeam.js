import React, { useState } from 'react';
import { User } from 'lucide-react';

const ManagementTeam = () => {
  const [activeTab, setActiveTab] = useState('management');

  const teamData = {
    management: {
      title: 'Management Team',
      members: [
        {
          name: 'John Smith',
          title: 'Chief Executive Officer',
          bio: 'John brings over 20 years of experience in enterprise software and data management. He leads our strategic vision and company direction.'
        },
        {
          name: 'Sarah Johnson',
          title: 'Chief Technology Officer',
          bio: 'Sarah oversees all technical aspects of our platform, ensuring we deliver cutting-edge solutions to our users.'
        },
        {
          name: 'Michael Chen',
          title: 'Chief Operations Officer',
          bio: 'Michael manages our day-to-day operations and ensures smooth delivery of all services.'
        },
        {
          name: 'Emily Rodriguez',
          title: 'Chief Financial Officer',
          bio: 'Emily brings extensive financial expertise and ensures our fiscal health and growth strategy.'
        }
      ]
    },
    development: {
      title: 'Development Team',
      members: [
        {
          name: 'Emily Davis',
          title: 'Lead Software Architect',
          bio: 'Emily designs the overall architecture of our platform and leads the development team in building robust solutions.'
        },
        {
          name: 'David Wilson',
          title: 'Senior Backend Developer',
          bio: 'David specializes in Python microservices and database optimization.'
        },
        {
          name: 'Lisa Anderson',
          title: 'Senior Frontend Developer',
          bio: 'Lisa creates intuitive user interfaces using React and modern web technologies.'
        },
        {
          name: 'James Lee',
          title: 'DevOps Engineer',
          bio: 'James manages our CI/CD pipelines and cloud infrastructure for optimal performance.'
        },
        {
          name: 'Maria Garcia',
          title: 'QA Lead',
          bio: 'Maria ensures the quality and reliability of all our software releases.'
        }
      ]
    },
    operation: {
      title: 'Operation Team',
      members: [
        {
          name: 'Robert Taylor',
          title: 'Operations Manager',
          bio: 'Robert ensures all systems run smoothly and maintains our high availability standards.'
        },
        {
          name: 'Jennifer Martinez',
          title: 'Support Lead',
          bio: 'Jennifer leads our support team and ensures users get timely assistance with their queries.'
        },
        {
          name: 'William Brown',
          title: 'Infrastructure Engineer',
          bio: 'William manages our cloud infrastructure and ensures optimal performance.'
        },
        {
          name: 'Amanda White',
          title: 'Database Administrator',
          bio: 'Amanda oversees database maintenance, optimization, and backup procedures.'
        }
      ]
    }
  };

  const currentTeam = teamData[activeTab];

  return (
    <div className="management-team-page">
      <div className="team-header">
        <h1>Our Management Team</h1>
        <p>
          If you've read our <a href="#" style={{ color: '#2d4a4a', textDecoration: 'underline' }}>Culture Code</a>, 
          you know we're unreasonably picky about our peers — our executives included. The 
          Information Resource Center management team is made up of savvy entrepreneurs and industry experts, 
          bringing years of experience to a young company. They cultivate our strong culture and work 
          tirelessly to help our team scale, grow, and succeed.
        </p>
      </div>

      <div className="team-tabs">
        <button 
          className={`team-tab ${activeTab === 'management' ? 'active' : ''}`}
          onClick={() => setActiveTab('management')}
        >
          Management Team
        </button>
        <button 
          className={`team-tab ${activeTab === 'development' ? 'active' : ''}`}
          onClick={() => setActiveTab('development')}
        >
          Development Team
        </button>
        <button 
          className={`team-tab ${activeTab === 'operation' ? 'active' : ''}`}
          onClick={() => setActiveTab('operation')}
        >
          Operation Team
        </button>
      </div>

      <div className="team-members">
        {currentTeam.members.map((member, index) => (
          <div key={index} className="team-member-card">
            <div className="member-avatar">
              <User size={32} />
            </div>
            <h3>{member.name}</h3>
            <p className="member-title">{member.title}</p>
            <p className="member-bio">{member.bio}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ManagementTeam;
