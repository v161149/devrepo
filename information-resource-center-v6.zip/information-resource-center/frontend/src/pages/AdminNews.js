import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Save, Trash2, Send, Edit, Plus } from 'lucide-react';

const AdminNews = () => {
  const { action } = useParams(); // create, edit, delete, publish
  const navigate = useNavigate();
  const { isAuthenticated, isAdmin } = useAuth();
  
  const [news, setNews] = useState([]);
  const [selectedNews, setSelectedNews] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    news_type: 'organization',
    status: 'draft',
    image_url: ''
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  // Redirect if not admin
  useEffect(() => {
    if (!isAuthenticated || !isAdmin()) {
      navigate('/');
    }
  }, [isAuthenticated, isAdmin, navigate]);

  // Fetch news list
  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    try {
      // In production, this would be an API call
      // For demo, using mock data
      const mockNews = [
        {
          id: 1,
          title: 'Welcome to Information Resource Center',
          content: 'We are excited to launch our new Information Resource Center portal. This platform will serve as your one-stop destination for all data management and IT operations needs.',
          news_type: 'organization',
          status: 'published',
          created_at: '2024-01-15T10:00:00Z'
        },
        {
          id: 2,
          title: 'New Snowflake Integration Available',
          content: 'We have added full support for Snowflake cloud data warehouse. Users can now provision, manage, and optimize their Snowflake resources directly through our portal.',
          news_type: 'product_release',
          status: 'published',
          created_at: '2024-01-14T09:00:00Z'
        },
        {
          id: 3,
          title: 'Scheduled Maintenance - November 25',
          content: 'The support phone line will be closed from 9am - 6pm EST on Monday 11/25 for scheduled maintenance. Please use email or chat for support during this time.',
          news_type: 'maintenance',
          status: 'draft',
          created_at: '2024-01-13T08:00:00Z'
        }
      ];
      setNews(mockNews);
    } catch (error) {
      console.error('Error fetching news:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectNews = (newsItem) => {
    setSelectedNews(newsItem);
    setFormData({
      title: newsItem.title,
      content: newsItem.content,
      news_type: newsItem.news_type,
      status: newsItem.status,
      image_url: newsItem.image_url || ''
    });
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // In production, this would be an API call
      // POST /api/admin/news
      console.log('Creating news:', formData);
      setMessage({ type: 'success', text: 'News created successfully!' });
      setFormData({
        title: '',
        content: '',
        news_type: 'organization',
        status: 'draft',
        image_url: ''
      });
      fetchNews();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to create news.' });
    }
    setLoading(false);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    if (!selectedNews) return;
    setLoading(true);
    try {
      // In production, this would be an API call
      // PUT /api/admin/news/:id
      console.log('Updating news:', selectedNews.id, formData);
      setMessage({ type: 'success', text: 'News updated successfully!' });
      fetchNews();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update news.' });
    }
    setLoading(false);
  };

  const handleDelete = async (newsId) => {
    if (!window.confirm('Are you sure you want to delete this news item?')) return;
    setLoading(true);
    try {
      // In production, this would be an API call
      // DELETE /api/admin/news/:id
      console.log('Deleting news:', newsId);
      setMessage({ type: 'success', text: 'News deleted successfully!' });
      setSelectedNews(null);
      fetchNews();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to delete news.' });
    }
    setLoading(false);
  };

  const handlePublish = async (newsId) => {
    setLoading(true);
    try {
      // In production, this would be an API call
      // POST /api/admin/news/:id/publish
      console.log('Publishing news:', newsId);
      setMessage({ type: 'success', text: 'News published successfully!' });
      fetchNews();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to publish news.' });
    }
    setLoading(false);
  };

  const getPageTitle = () => {
    switch (action) {
      case 'create': return 'Create News';
      case 'edit': return 'Edit News';
      case 'delete': return 'Delete News';
      case 'publish': return 'Publish News';
      default: return 'News Management';
    }
  };

  const getNewsTypeLabel = (type) => {
    switch (type) {
      case 'organization': return 'Organization News';
      case 'product_release': return 'Product/Project Release News';
      case 'maintenance': return 'Maintenance News';
      default: return type;
    }
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <button 
          onClick={() => navigate('/')}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center'
          }}
        >
          <ArrowLeft size={20} />
        </button>
        <h1 style={{ margin: 0 }}>{getPageTitle()}</h1>
      </div>

      {/* Message */}
      {message.text && (
        <div style={{
          padding: '1rem',
          marginBottom: '1rem',
          borderRadius: '8px',
          background: message.type === 'success' ? '#d4edda' : '#f8d7da',
          color: message.type === 'success' ? '#155724' : '#721c24'
        }}>
          {message.text}
        </div>
      )}

      {/* Create News Form */}
      {action === 'create' && (
        <form onSubmit={handleCreate} style={{ maxWidth: '600px' }}>
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              News Type
            </label>
            <select
              name="news_type"
              value={formData.news_type}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            >
              <option value="organization">Organization News</option>
              <option value="product_release">Product/Project Release News</option>
              <option value="maintenance">Maintenance News</option>
            </select>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Title
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              required
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Content
            </label>
            <textarea
              name="content"
              value={formData.content}
              onChange={handleInputChange}
              required
              rows={6}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem',
                resize: 'vertical'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Status
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            >
              <option value="draft">Draft</option>
              <option value="published">Published</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              background: '#e84e36',
              color: '#fff',
              border: 'none',
              padding: '0.75rem 1.5rem',
              borderRadius: '6px',
              fontSize: '1rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Plus size={18} />
            {loading ? 'Creating...' : 'Create News'}
          </button>
        </form>
      )}

      {/* Edit/Delete/Publish - News List */}
      {(action === 'edit' || action === 'delete' || action === 'publish') && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
          {/* News List */}
          <div>
            <h3 style={{ marginBottom: '1rem' }}>Select News Item</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {news.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleSelectNews(item)}
                  style={{
                    padding: '1rem',
                    border: `2px solid ${selectedNews?.id === item.id ? '#e84e36' : '#ddd'}`,
                    borderRadius: '8px',
                    cursor: 'pointer',
                    background: selectedNews?.id === item.id ? '#fff5f3' : '#fff'
                  }}
                >
                  <div style={{ 
                    display: 'inline-block',
                    padding: '0.25rem 0.5rem',
                    background: item.news_type === 'maintenance' ? '#fef3cd' : 
                               item.news_type === 'product_release' ? '#d4edda' : '#cce5ff',
                    borderRadius: '4px',
                    fontSize: '0.7rem',
                    marginBottom: '0.5rem',
                    textTransform: 'uppercase'
                  }}>
                    {item.news_type.replace('_', ' ')}
                  </div>
                  <h4 style={{ margin: '0 0 0.25rem 0', fontSize: '0.9rem' }}>{item.title}</h4>
                  <div style={{ fontSize: '0.75rem', color: '#666' }}>
                    Status: <span style={{ 
                      color: item.status === 'published' ? '#28a745' : '#ffc107',
                      fontWeight: '500'
                    }}>
                      {item.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Panel */}
          <div>
            {selectedNews ? (
              <>
                {action === 'edit' && (
                  <form onSubmit={handleUpdate}>
                    <h3 style={{ marginBottom: '1rem' }}>Edit News</h3>
                    
                    <div style={{ marginBottom: '1rem' }}>
                      <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                        News Type
                      </label>
                      <select
                        name="news_type"
                        value={formData.news_type}
                        onChange={handleInputChange}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #ddd',
                          borderRadius: '6px'
                        }}
                      >
                        <option value="organization">Organization News</option>
                        <option value="product_release">Product/Project Release News</option>
                        <option value="maintenance">Maintenance News</option>
                      </select>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                        Title
                      </label>
                      <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleInputChange}
                        required
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #ddd',
                          borderRadius: '6px'
                        }}
                      />
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                        Content
                      </label>
                      <textarea
                        name="content"
                        value={formData.content}
                        onChange={handleInputChange}
                        required
                        rows={6}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #ddd',
                          borderRadius: '6px',
                          resize: 'vertical'
                        }}
                      />
                    </div>

                    <div style={{ marginBottom: '1.5rem' }}>
                      <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                        Status
                      </label>
                      <select
                        name="status"
                        value={formData.status}
                        onChange={handleInputChange}
                        style={{
                          width: '100%',
                          padding: '0.75rem',
                          border: '1px solid #ddd',
                          borderRadius: '6px'
                        }}
                      >
                        <option value="draft">Draft</option>
                        <option value="published">Published</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      style={{
                        background: '#e84e36',
                        color: '#fff',
                        border: 'none',
                        padding: '0.75rem 1.5rem',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem'
                      }}
                    >
                      <Save size={18} />
                      {loading ? 'Saving...' : 'Save Changes'}
                    </button>
                  </form>
                )}

                {action === 'delete' && (
                  <div>
                    <h3 style={{ marginBottom: '1rem' }}>Delete News</h3>
                    <div style={{ 
                      background: '#f8f9fa', 
                      padding: '1rem', 
                      borderRadius: '8px',
                      marginBottom: '1rem'
                    }}>
                      <p><strong>Title:</strong> {selectedNews.title}</p>
                      <p><strong>Type:</strong> {getNewsTypeLabel(selectedNews.news_type)}</p>
                      <p><strong>Status:</strong> {selectedNews.status}</p>
                    </div>
                    <p style={{ color: '#dc3545', marginBottom: '1rem' }}>
                      Are you sure you want to delete this news item? This action cannot be undone.
                    </p>
                    <button
                      onClick={() => handleDelete(selectedNews.id)}
                      disabled={loading}
                      style={{
                        background: '#dc3545',
                        color: '#fff',
                        border: 'none',
                        padding: '0.75rem 1.5rem',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem'
                      }}
                    >
                      <Trash2 size={18} />
                      {loading ? 'Deleting...' : 'Delete News'}
                    </button>
                  </div>
                )}

                {action === 'publish' && (
                  <div>
                    <h3 style={{ marginBottom: '1rem' }}>Publish News</h3>
                    <div style={{ 
                      background: '#f8f9fa', 
                      padding: '1rem', 
                      borderRadius: '8px',
                      marginBottom: '1rem'
                    }}>
                      <p><strong>Title:</strong> {selectedNews.title}</p>
                      <p><strong>Type:</strong> {getNewsTypeLabel(selectedNews.news_type)}</p>
                      <p><strong>Current Status:</strong> {selectedNews.status}</p>
                    </div>
                    {selectedNews.status === 'published' ? (
                      <p style={{ color: '#28a745' }}>This news item is already published.</p>
                    ) : (
                      <>
                        <p style={{ marginBottom: '1rem' }}>
                          Click the button below to publish this news item. It will become visible to all users.
                        </p>
                        <button
                          onClick={() => handlePublish(selectedNews.id)}
                          disabled={loading}
                          style={{
                            background: '#28a745',
                            color: '#fff',
                            border: 'none',
                            padding: '0.75rem 1.5rem',
                            borderRadius: '6px',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem'
                          }}
                        >
                          <Send size={18} />
                          {loading ? 'Publishing...' : 'Publish News'}
                        </button>
                      </>
                    )}
                  </div>
                )}
              </>
            ) : (
              <div style={{ 
                textAlign: 'center', 
                color: '#666', 
                padding: '2rem',
                background: '#f8f9fa',
                borderRadius: '8px'
              }}>
                <p>Select a news item from the list to {action} it.</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminNews;
