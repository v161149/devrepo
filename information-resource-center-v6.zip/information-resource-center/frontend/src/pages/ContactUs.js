import React from 'react';
import { Mail, MessageSquare, Calendar } from 'lucide-react';

const ContactUs = () => {
  const handleEmailUs = () => {
    // Email functionality to be implemented later
    console.log('Email Us clicked');
  };

  const handleChatWithUs = () => {
    // Chat functionality to be implemented later
    console.log('Chat with Us clicked');
  };

  const handleGetDemo = () => {
    // Demo request functionality to be implemented later
    console.log('Get a Demo clicked');
  };

  return (
    <div className="contact-us-page">
      <h1>Contact Us About Products and Services We Offer.</h1>
      <p>Here are the few ways to reach out our team.</p>

      <div className="contact-options">
        {/* Email Us Card */}
        <div className="contact-card">
          <div className="contact-icon">
            <Mail size={48} strokeWidth={1.5} />
          </div>
          <h3>Email us</h3>
          <button className="contact-btn" onClick={handleEmailUs}>
            Email Us
          </button>
        </div>

        {/* Chat with Us Card */}
        <div className="contact-card">
          <div className="contact-icon">
            <MessageSquare size={48} strokeWidth={1.5} />
          </div>
          <h3>Chat with our team</h3>
          <button className="contact-btn" onClick={handleChatWithUs}>
            Chat with us
          </button>
        </div>

        {/* Get a Demo Card */}
        <div className="contact-card">
          <div className="contact-icon">
            <Calendar size={48} strokeWidth={1.5} />
          </div>
          <h3>Get a Demo</h3>
          <button className="contact-btn" onClick={handleGetDemo}>
            Get a demo
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
