import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Save, Trash2, Plus, User } from 'lucide-react';

const AdminTeam = () => {
  const { action } = useParams(); // create, edit, delete
  const navigate = useNavigate();
  const { isAuthenticated, isAdmin } = useAuth();
  
  const [teamMembers, setTeamMembers] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [selectedTeamType, setSelectedTeamType] = useState('management');
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    bio: '',
    email: '',
    team_type: 'management',
    image_url: '',
    linkedin_url: ''
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  // Redirect if not admin
  useEffect(() => {
    if (!isAuthenticated || !isAdmin()) {
      navigate('/');
    }
  }, [isAuthenticated, isAdmin, navigate]);

  // Fetch team members
  useEffect(() => {
    fetchTeamMembers();
  }, []);

  const fetchTeamMembers = async () => {
    try {
      // In production, this would be an API call
      // For demo, using mock data
      const mockMembers = [
        // Management Team
        {
          id: 1,
          name: 'John Smith',
          title: 'Chief Executive Officer',
          bio: 'John brings over 20 years of experience in enterprise software and data management.',
          team_type: 'management',
          email: 'john.smith@irc.com'
        },
        {
          id: 2,
          name: 'Sarah Johnson',
          title: 'Chief Technology Officer',
          bio: 'Sarah oversees all technical aspects of our platform.',
          team_type: 'management',
          email: 'sarah.johnson@irc.com'
        },
        {
          id: 3,
          name: 'Michael Chen',
          title: 'Chief Operations Officer',
          bio: 'Michael manages our day-to-day operations.',
          team_type: 'management',
          email: 'michael.chen@irc.com'
        },
        // Development Team
        {
          id: 4,
          name: 'Emily Davis',
          title: 'Lead Software Architect',
          bio: 'Emily designs the overall architecture of our platform.',
          team_type: 'development',
          email: 'emily.davis@irc.com'
        },
        {
          id: 5,
          name: 'David Wilson',
          title: 'Senior Backend Developer',
          bio: 'David specializes in Python microservices and database optimization.',
          team_type: 'development',
          email: 'david.wilson@irc.com'
        },
        // Operation Team
        {
          id: 6,
          name: 'Robert Taylor',
          title: 'Operations Manager',
          bio: 'Robert ensures all systems run smoothly.',
          team_type: 'operation',
          email: 'robert.taylor@irc.com'
        },
        {
          id: 7,
          name: 'Jennifer Martinez',
          title: 'Support Lead',
          bio: 'Jennifer leads our support team.',
          team_type: 'operation',
          email: 'jennifer.martinez@irc.com'
        }
      ];
      setTeamMembers(mockMembers);
    } catch (error) {
      console.error('Error fetching team members:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectMember = (member) => {
    setSelectedMember(member);
    setFormData({
      name: member.name,
      title: member.title,
      bio: member.bio,
      email: member.email || '',
      team_type: member.team_type,
      image_url: member.image_url || '',
      linkedin_url: member.linkedin_url || ''
    });
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // In production, this would be an API call
      // POST /api/admin/team-members
      console.log('Creating team member:', formData);
      setMessage({ type: 'success', text: 'Team member profile created successfully!' });
      setFormData({
        name: '',
        title: '',
        bio: '',
        email: '',
        team_type: 'management',
        image_url: '',
        linkedin_url: ''
      });
      fetchTeamMembers();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to create team member profile.' });
    }
    setLoading(false);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    if (!selectedMember) return;
    setLoading(true);
    try {
      // In production, this would be an API call
      // PUT /api/admin/team-members/:id
      console.log('Updating team member:', selectedMember.id, formData);
      setMessage({ type: 'success', text: 'Team member profile updated successfully!' });
      fetchTeamMembers();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update team member profile.' });
    }
    setLoading(false);
  };

  const handleDelete = async (memberId) => {
    if (!window.confirm('Are you sure you want to delete this team member profile?')) return;
    setLoading(true);
    try {
      // In production, this would be an API call
      // DELETE /api/admin/team-members/:id
      console.log('Deleting team member:', memberId);
      setMessage({ type: 'success', text: 'Team member profile deleted successfully!' });
      setSelectedMember(null);
      fetchTeamMembers();
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to delete team member profile.' });
    }
    setLoading(false);
  };

  const getPageTitle = () => {
    switch (action) {
      case 'create': return 'Create Team Member Profile';
      case 'edit': return 'Edit Team Member Profile';
      case 'delete': return 'Delete Team Member Profile';
      default: return 'Team Management';
    }
  };

  const getTeamTypeLabel = (type) => {
    switch (type) {
      case 'management': return 'Management Team';
      case 'development': return 'Development Team';
      case 'operation': return 'Operation Team';
      default: return type;
    }
  };

  const filteredMembers = teamMembers.filter(m => m.team_type === selectedTeamType);

  return (
    <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <button 
          onClick={() => navigate('/')}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center'
          }}
        >
          <ArrowLeft size={20} />
        </button>
        <h1 style={{ margin: 0 }}>{getPageTitle()}</h1>
      </div>

      {/* Message */}
      {message.text && (
        <div style={{
          padding: '1rem',
          marginBottom: '1rem',
          borderRadius: '8px',
          background: message.type === 'success' ? '#d4edda' : '#f8d7da',
          color: message.type === 'success' ? '#155724' : '#721c24'
        }}>
          {message.text}
        </div>
      )}

      {/* Create Team Member Form */}
      {action === 'create' && (
        <form onSubmit={handleCreate} style={{ maxWidth: '600px' }}>
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Team Category
            </label>
            <select
              name="team_type"
              value={formData.team_type}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            >
              <option value="management">Management Team</option>
              <option value="development">Development Team</option>
              <option value="operation">Operation Team</option>
            </select>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Full Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Job Title
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              required
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Bio
            </label>
            <textarea
              name="bio"
              value={formData.bio}
              onChange={handleInputChange}
              required
              rows={4}
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem',
                resize: 'vertical'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              LinkedIn URL (optional)
            </label>
            <input
              type="url"
              name="linkedin_url"
              value={formData.linkedin_url}
              onChange={handleInputChange}
              placeholder="https://linkedin.com/in/username"
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '1rem'
              }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              background: '#e84e36',
              color: '#fff',
              border: 'none',
              padding: '0.75rem 1.5rem',
              borderRadius: '6px',
              fontSize: '1rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Plus size={18} />
            {loading ? 'Creating...' : 'Create Profile'}
          </button>
        </form>
      )}

      {/* Edit/Delete - Team Member List */}
      {(action === 'edit' || action === 'delete') && (
        <div>
          {/* Team Type Filter */}
          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
              Select Team Category
            </label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              {['management', 'development', 'operation'].map((type) => (
                <button
                  key={type}
                  onClick={() => {
                    setSelectedTeamType(type);
                    setSelectedMember(null);
                  }}
                  style={{
                    padding: '0.5rem 1rem',
                    border: `2px solid ${selectedTeamType === type ? '#e84e36' : '#ddd'}`,
                    borderRadius: '6px',
                    background: selectedTeamType === type ? '#fff5f3' : '#fff',
                    cursor: 'pointer',
                    fontWeight: selectedTeamType === type ? '600' : '400'
                  }}
                >
                  {getTeamTypeLabel(type)}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            {/* Member List */}
            <div>
              <h3 style={{ marginBottom: '1rem' }}>Select Team Member</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {filteredMembers.map((member) => (
                  <div
                    key={member.id}
                    onClick={() => handleSelectMember(member)}
                    style={{
                      padding: '1rem',
                      border: `2px solid ${selectedMember?.id === member.id ? '#e84e36' : '#ddd'}`,
                      borderRadius: '8px',
                      cursor: 'pointer',
                      background: selectedMember?.id === member.id ? '#fff5f3' : '#fff',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '1rem'
                    }}
                  >
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      background: '#f0f0f0',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <User size={20} color="#666" />
                    </div>
                    <div>
                      <h4 style={{ margin: '0 0 0.25rem 0', fontSize: '0.9rem' }}>{member.name}</h4>
                      <div style={{ fontSize: '0.75rem', color: '#666' }}>{member.title}</div>
                    </div>
                  </div>
                ))}
                {filteredMembers.length === 0 && (
                  <p style={{ color: '#666', fontStyle: 'italic' }}>No team members in this category.</p>
                )}
              </div>
            </div>

            {/* Action Panel */}
            <div>
              {selectedMember ? (
                <>
                  {action === 'edit' && (
                    <form onSubmit={handleUpdate}>
                      <h3 style={{ marginBottom: '1rem' }}>Edit Profile</h3>
                      
                      <div style={{ marginBottom: '1rem' }}>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                          Team Category
                        </label>
                        <select
                          name="team_type"
                          value={formData.team_type}
                          onChange={handleInputChange}
                          style={{
                            width: '100%',
                            padding: '0.75rem',
                            border: '1px solid #ddd',
                            borderRadius: '6px'
                          }}
                        >
                          <option value="management">Management Team</option>
                          <option value="development">Development Team</option>
                          <option value="operation">Operation Team</option>
                        </select>
                      </div>

                      <div style={{ marginBottom: '1rem' }}>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                          Full Name
                        </label>
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                          style={{
                            width: '100%',
                            padding: '0.75rem',
                            border: '1px solid #ddd',
                            borderRadius: '6px'
                          }}
                        />
                      </div>

                      <div style={{ marginBottom: '1rem' }}>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                          Job Title
                        </label>
                        <input
                          type="text"
                          name="title"
                          value={formData.title}
                          onChange={handleInputChange}
                          required
                          style={{
                            width: '100%',
                            padding: '0.75rem',
                            border: '1px solid #ddd',
                            borderRadius: '6px'
                          }}
                        />
                      </div>

                      <div style={{ marginBottom: '1rem' }}>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                          Email
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          style={{
                            width: '100%',
                            padding: '0.75rem',
                            border: '1px solid #ddd',
                            borderRadius: '6px'
                          }}
                        />
                      </div>

                      <div style={{ marginBottom: '1rem' }}>
                        <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>
                          Bio
                        </label>
                        <textarea
                          name="bio"
                          value={formData.bio}
                          onChange={handleInputChange}
                          required
                          rows={4}
                          style={{
                            width: '100%',
                            padding: '0.75rem',
                            border: '1px solid #ddd',
                            borderRadius: '6px',
                            resize: 'vertical'
                          }}
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        style={{
                          background: '#e84e36',
                          color: '#fff',
                          border: 'none',
                          padding: '0.75rem 1.5rem',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.5rem'
                        }}
                      >
                        <Save size={18} />
                        {loading ? 'Saving...' : 'Save Changes'}
                      </button>
                    </form>
                  )}

                  {action === 'delete' && (
                    <div>
                      <h3 style={{ marginBottom: '1rem' }}>Delete Profile</h3>
                      <div style={{ 
                        background: '#f8f9fa', 
                        padding: '1rem', 
                        borderRadius: '8px',
                        marginBottom: '1rem'
                      }}>
                        <p><strong>Name:</strong> {selectedMember.name}</p>
                        <p><strong>Title:</strong> {selectedMember.title}</p>
                        <p><strong>Team:</strong> {getTeamTypeLabel(selectedMember.team_type)}</p>
                        <p><strong>Bio:</strong> {selectedMember.bio}</p>
                      </div>
                      <p style={{ color: '#dc3545', marginBottom: '1rem' }}>
                        Are you sure you want to delete this team member profile? This action cannot be undone.
                      </p>
                      <button
                        onClick={() => handleDelete(selectedMember.id)}
                        disabled={loading}
                        style={{
                          background: '#dc3545',
                          color: '#fff',
                          border: 'none',
                          padding: '0.75rem 1.5rem',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.5rem'
                        }}
                      >
                        <Trash2 size={18} />
                        {loading ? 'Deleting...' : 'Delete Profile'}
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div style={{ 
                  textAlign: 'center', 
                  color: '#666', 
                  padding: '2rem',
                  background: '#f8f9fa',
                  borderRadius: '8px'
                }}>
                  <p>Select a team member from the list to {action} their profile.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminTeam;
