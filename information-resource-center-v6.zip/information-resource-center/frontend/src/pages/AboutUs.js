import React from 'react';

const AboutUs = () => {
  return (
    <div className="about-us-page">
      <div className="about-content">
        <h1>About Us</h1>
        <p>
          The Information Resource Center's company and culture are a lot like our product. 
          They're crafted, not cobbled, for a delightful experience.
        </p>

        <div className="about-section">
          <h2>Our Mission: Helping Millions of Organizations Grow Better</h2>
          <p>
            We believe not just in growing bigger, but in growing better. And growing better means 
            aligning the success of your own business with the success of your customers. Win-win!
          </p>
        </div>

        <div className="about-section">
          <h2>Our Story</h2>
          <p>
            Founded with a vision to democratize access to enterprise data management tools, 
            the Information Resource Center has evolved into a comprehensive platform serving 
            organizations of all sizes. Our journey began with a simple idea: make complex data 
            operations accessible to everyone. Today, we support 19 different platforms and databases, 
            serving thousands of users who depend on our services for their daily operations.
          </p>
        </div>

        <div className="about-section">
          <h2>Our Values</h2>
          <p>
            We are committed to transparency, reliability, and innovation. Our platform is built 
            on the foundation of user-centric design, ensuring that every feature we develop serves 
            the real needs of our users. We believe in continuous improvement and actively seek 
            feedback to make our services better every day.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
