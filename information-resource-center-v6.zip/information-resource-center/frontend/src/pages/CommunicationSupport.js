import React, { useState } from 'react';
import { Search } from 'lucide-react';

const CommunicationSupport = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      // Search functionality will be implemented later
      console.log('Searching for:', searchQuery);
    }
  };

  return (
    <div className="communication-support-page">
      {/* Banner */}
      <div className="news-banner">
        <p>The support phone line will be closed from 9am - 6pm EST on Monday 11/03 for a regional holiday.</p>
      </div>

      {/* Hero Section */}
      <div className="support-hero">
        <h1>How can we help?</h1>
        <div className="support-search">
          <Search size={20} color="#999" />
          <input 
            type="text" 
            placeholder="Search all help and learning resources"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearch}
          />
        </div>
      </div>

      {/* Content Section */}
      <div style={{ padding: '3rem 2rem', maxWidth: '1200px', margin: '0 auto' }}>
        <h2 style={{ marginBottom: '2rem' }}>Popular Topics</h2>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: '1.5rem'
        }}>
          {[
            { title: 'Getting Started', desc: 'New to the platform? Start here for onboarding guides and tutorials.' },
            { title: 'Account Management', desc: 'Learn how to manage your account, permissions, and access.' },
            { title: 'Database Services', desc: 'Guides for working with Teradata, Oracle, SQL Server, and more.' },
            { title: 'Security & Compliance', desc: 'Information about security policies and compliance requirements.' },
            { title: 'Troubleshooting', desc: 'Common issues and their solutions.' },
            { title: 'API Documentation', desc: 'Technical documentation for developers.' }
          ].map((topic, index) => (
            <div 
              key={index}
              style={{
                background: '#fff',
                border: '1px solid #e0e0e0',
                borderRadius: '8px',
                padding: '1.5rem',
                cursor: 'pointer',
                transition: 'all 0.3s'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <h3 style={{ marginBottom: '0.5rem', color: '#333' }}>{topic.title}</h3>
              <p style={{ fontSize: '0.875rem', color: '#666' }}>{topic.desc}</p>
            </div>
          ))}
        </div>

        <div style={{ marginTop: '3rem' }}>
          <h2 style={{ marginBottom: '1rem' }}>Need more help?</h2>
          <p style={{ color: '#666', marginBottom: '1rem' }}>
            Can't find what you're looking for? Our support team is here to help.
          </p>
          <a 
            href="/contact-us"
            style={{
              display: 'inline-block',
              background: '#e84e36',
              color: '#fff',
              padding: '0.75rem 1.5rem',
              borderRadius: '6px',
              textDecoration: 'none',
              fontWeight: '500'
            }}
          >
            Contact Support
          </a>
        </div>
      </div>
    </div>
  );
};

export default CommunicationSupport;
