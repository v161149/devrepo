import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { productCategories, products, getProductsByCategory } from '../data/products';

const ProductsServices = () => {
  const [selectedCategoryId, setSelectedCategoryId] = useState(1);
  const navigate = useNavigate();

  const filteredProducts = getProductsByCategory(selectedCategoryId);

  const handleProductClick = (productId) => {
    navigate(`/products-services/${productId}`);
  };

  // Product icon mapping - using placeholder text logos
  const getProductIcon = (shortName) => {
    const iconColors = {
      'Teradata': '#f7941d',
      'Oracle': '#f80000',
      'SQL Server': '#0078d4',
      'DB2': '#054ada',
      'MySQL': '#00758f',
      'PostgreSQL': '#336791',
      'Cassandra': '#1287b1',
      'MongoDB': '#47a248',
      'Hive': '#fdee21',
      'HDFS': '#66ccff',
      'Snowflake': '#29b5e8',
      'Airflow': '#017cee',
      'Splunk': '#65a637',
      'Dynatrace': '#1496ff',
      'Copilot': '#0078d4',
      'GPT': '#412991',
      'Gemini': '#4285f4',
      'Llama': '#0668e1',
      'Grok': '#000000'
    };

    return (
      <div 
        className="product-icon-placeholder"
        style={{ color: iconColors[shortName] || '#e84e36' }}
      >
        {shortName}
      </div>
    );
  };

  return (
    <div className="products-services-page">
      {/* Left Sidebar - Categories */}
      <div className="products-sidebar">
        <ul className="category-list">
          {productCategories.map((category) => (
            <li key={category.id} className="category-item">
              <button
                className={`category-btn ${selectedCategoryId === category.id ? 'active' : ''}`}
                onClick={() => setSelectedCategoryId(category.id)}
              >
                <span>{category.name}</span>
                <ChevronRight size={16} />
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Right Content - Products Grid */}
      <div className="products-content">
        <div className="products-grid">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="product-card"
              onClick={() => handleProductClick(product.id)}
            >
              <div className="product-icon">
                {getProductIcon(product.shortName)}
              </div>
              <h3>{product.name}</h3>
              <p>{product.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductsServices;
