import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronDown, ChevronRight, Star, CheckCircle, Clock, FileText } from 'lucide-react';
import { getProductById, productCategories } from '../data/products';

const ProductDetails = () => {
  const { productId } = useParams();
  const product = getProductById(parseInt(productId));
  
  const [expandedCategories, setExpandedCategories] = useState([1]); // First category expanded by default
  const [selectedService, setSelectedService] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);

  // Set initial selected service - must be before any conditional returns
  React.useEffect(() => {
    if (product && product.serviceCategories.length > 0) {
      const firstCategory = product.serviceCategories[0];
      setSelectedCategory(firstCategory);
      if (firstCategory.services.length > 0) {
        setSelectedService(firstCategory.services[0]);
      }
    }
  }, [product]);

  if (!product) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center' }}>
        <h1>Product not found</h1>
        <Link to="/products-services">Back to Products & Services</Link>
      </div>
    );
  }

  const toggleCategory = (categoryId) => {
    setExpandedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleServiceClick = (category, service) => {
    setSelectedCategory(category);
    setSelectedService(service);
  };

  const getCategoryForProduct = () => {
    const category = productCategories.find(c => c.id === product.categoryId);
    return category ? category.name : '';
  };

  return (
    <div className="product-details-page">
      {/* Breadcrumb - spans full width above both panels */}
      <div className="breadcrumb" style={{ 
        padding: '0.75rem 2rem', 
        borderBottom: '1px solid #e0e0e0',
        fontSize: '0.875rem',
        background: '#fff'
      }}>
        <Link to="/products-services" style={{ color: '#333', textDecoration: 'underline' }}>
          {getCategoryForProduct()}
        </Link>
        {' > '}
        <span>{product.name}</span>
      </div>

      <div className="product-details-container">
        {/* Left Sidebar - Service Categories */}
        <div className="service-sidebar">
          {product.serviceCategories.map((category) => (
            <div key={category.id} className="service-category">
              <button
                className="service-category-header"
                onClick={() => toggleCategory(category.id)}
              >
                <span>{category.name}</span>
                {expandedCategories.includes(category.id) ? (
                  <ChevronDown size={16} />
                ) : (
                  <ChevronRight size={16} />
                )}
              </button>
              
              {expandedCategories.includes(category.id) && (
                <ul className="service-list">
                  {category.services.map((service) => (
                    <li
                      key={service.id}
                      className={`service-item ${selectedService?.id === service.id && selectedCategory?.id === category.id ? 'active' : ''}`}
                      onClick={() => handleServiceClick(category, service)}
                    >
                      {service.name}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>

        {/* Right Content - Service Details */}
        <div className="service-details">
          {selectedCategory && selectedService ? (
            <>
              <h1>{selectedCategory.name}</h1>
              <h2>{selectedService.name}</h2>

              {/* Functionality Cards */}
              {selectedService.functionalities && selectedService.functionalities.map((func, index) => (
                <div key={index} className="functionality-card">
                  <h3>
                    <span className="functionality-icon">
                      {index === 0 && <Star size={20} />}
                      {index === 1 && <CheckCircle size={20} />}
                      {index === 2 && <Clock size={20} />}
                      {index === 3 && <FileText size={20} />}
                      {index > 3 && <Star size={20} />}
                    </span>
                    {func}
                  </h3>
                </div>
              ))}

              {/* If there are no specific functionalities, show a placeholder */}
              {(!selectedService.functionalities || selectedService.functionalities.length === 0) && (
                <div className="functionality-card">
                  <h3>
                    <span className="functionality-icon">
                      <Star size={20} />
                    </span>
                    Service functionality coming soon
                  </h3>
                </div>
              )}
            </>
          ) : (
            <div style={{ textAlign: 'center', color: '#666', padding: '2rem' }}>
              <p>Select a service from the sidebar to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
