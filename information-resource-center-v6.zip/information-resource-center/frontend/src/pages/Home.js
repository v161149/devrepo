import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const Home = () => {
  const [currentNewsIndex, setCurrentNewsIndex] = useState(0);
  const [news, setNews] = useState([
    {
      id: 1,
      title: 'Welcome to Information Resource Center',
      content: 'We are excited to launch our new Information Resource Center portal. This platform will serve as your one-stop destination for all data management and IT operations needs.',
      type: 'organization'
    },
    {
      id: 2,
      title: 'New Snowflake Integration Available',
      content: 'We have added full support for Snowflake cloud data warehouse. Users can now provision, manage, and optimize their Snowflake resources directly through our portal.',
      type: 'product_release'
    },
    {
      id: 3,
      title: 'Scheduled Maintenance - November 25',
      content: 'The support phone line will be closed from 9am - 6pm EST on Monday 11/25 for scheduled maintenance. Please use email or chat for support during this time.',
      type: 'maintenance'
    }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentNewsIndex((prev) => (prev + 1) % news.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [news.length]);

  const nextNews = () => {
    setCurrentNewsIndex((prev) => (prev + 1) % news.length);
  };

  const prevNews = () => {
    setCurrentNewsIndex((prev) => (prev - 1 + news.length) % news.length);
  };

  return (
    <div className="home-page">
      {/* News Cards Section */}
      <div style={{ padding: '3rem 2rem', maxWidth: '1200px', margin: '0 auto' }}>
        <h2 style={{ marginBottom: '2rem' }}>Latest News & Announcements</h2>
        
        <div style={{ position: 'relative' }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '1rem',
            overflow: 'hidden'
          }}>
            <button 
              onClick={prevNews}
              style={{
                background: '#f5f5f5',
                border: 'none',
                borderRadius: '50%',
                width: '40px',
                height: '40px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                flexShrink: 0
              }}
            >
              <ChevronLeft size={20} />
            </button>

            <div style={{
              flex: 1,
              background: '#fff',
              border: '1px solid #e0e0e0',
              borderRadius: '12px',
              padding: '2rem',
              minHeight: '200px'
            }}>
              <div style={{
                display: 'inline-block',
                padding: '0.25rem 0.75rem',
                background: news[currentNewsIndex].type === 'maintenance' ? '#fef3cd' : 
                           news[currentNewsIndex].type === 'product_release' ? '#d4edda' : '#cce5ff',
                borderRadius: '4px',
                fontSize: '0.75rem',
                marginBottom: '1rem',
                textTransform: 'uppercase'
              }}>
                {news[currentNewsIndex].type.replace('_', ' ')}
              </div>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.5rem' }}>
                {news[currentNewsIndex].title}
              </h3>
              <p style={{ color: '#666', lineHeight: '1.8' }}>
                {news[currentNewsIndex].content}
              </p>
            </div>

            <button 
              onClick={nextNews}
              style={{
                background: '#f5f5f5',
                border: 'none',
                borderRadius: '50%',
                width: '40px',
                height: '40px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                flexShrink: 0
              }}
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Dots indicator */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '0.5rem',
            marginTop: '1rem'
          }}>
            {news.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentNewsIndex(index)}
                style={{
                  width: '10px',
                  height: '10px',
                  borderRadius: '50%',
                  border: 'none',
                  background: index === currentNewsIndex ? '#e84e36' : '#ddd',
                  cursor: 'pointer'
                }}
              />
            ))}
          </div>
        </div>

        {/* Quick Links Section */}
        <div style={{ marginTop: '3rem' }}>
          <h2 style={{ marginBottom: '2rem' }}>Quick Links</h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
            gap: '1.5rem'
          }}>
            {[
              { title: 'Products & Services', desc: 'Browse all available platforms and databases', link: '/products-services' },
              { title: 'Communication & Support', desc: 'Get help with your questions', link: '/communication-support' },
              { title: 'About Us', desc: 'Learn more about our organization', link: '/about-us' },
              { title: 'Contact Us', desc: 'Reach out to our team', link: '/contact-us' }
            ].map((item, index) => (
              <a 
                key={index}
                href={item.link}
                style={{
                  display: 'block',
                  background: '#fff',
                  border: '1px solid #e0e0e0',
                  borderRadius: '8px',
                  padding: '1.5rem',
                  textDecoration: 'none',
                  color: 'inherit',
                  transition: 'all 0.3s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.boxShadow = 'none';
                  e.currentTarget.style.transform = 'none';
                }}
              >
                <h3 style={{ marginBottom: '0.5rem', color: '#e84e36' }}>{item.title}</h3>
                <p style={{ fontSize: '0.875rem', color: '#666' }}>{item.desc}</p>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
