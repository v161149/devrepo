import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Header';
import Home from './pages/Home';
import CommunicationSupport from './pages/CommunicationSupport';
import ContactUs from './pages/ContactUs';
import AboutUs from './pages/AboutUs';
import ManagementTeam from './pages/ManagementTeam';
import ProductsServices from './pages/ProductsServices';
import ProductDetails from './pages/ProductDetails';
import AdminNews from './pages/AdminNews';
import AdminTeam from './pages/AdminTeam';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Header />
          <main className="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/communication-support" element={<CommunicationSupport />} />
              <Route path="/contact-us" element={<ContactUs />} />
              <Route path="/about-us" element={<AboutUs />} />
              <Route path="/management-team" element={<ManagementTeam />} />
              <Route path="/products-services" element={<ProductsServices />} />
              <Route path="/products-services/:productId" element={<ProductDetails />} />
              <Route path="/admin/news/:action" element={<AdminNews />} />
              <Route path="/admin/team/:action" element={<AdminTeam />} />
              <Route path="/sla-management" element={<div className="placeholder-page"><h1>SLA Management</h1><p>Coming soon - will be migrated from existing portal.</p></div>} />
              <Route path="/asset-management" element={<div className="placeholder-page"><h1>Asset Management</h1><p>Coming soon - will be migrated from existing portal.</p></div>} />
              <Route path="/data-pipeline-management" element={<div className="placeholder-page"><h1>Data Pipeline Management</h1><p>Coming soon - will be migrated from existing portal.</p></div>} />
              <Route path="/operations-dashboard" element={<div className="placeholder-page"><h1>Operations Dashboard</h1><p>Coming soon - will be migrated from existing portal.</p></div>} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
