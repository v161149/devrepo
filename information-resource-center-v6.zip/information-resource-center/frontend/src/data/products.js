// Complete products and services data for the Information Resource Center

export const productCategories = [
  {
    id: 1,
    name: 'Data Management and Storage Solutions',
    description: 'Comprehensive data management platforms and database solutions for enterprise data storage and analytics'
  },
  {
    id: 2,
    name: 'IT Operations and Orchestration Tools',
    description: 'Tools for IT operations monitoring, workflow orchestration, and system management'
  },
  {
    id: 3,
    name: 'AI Large Language Models (LLMs) and Related Products',
    description: 'Advanced AI language models and related products for intelligent automation and natural language processing'
  }
];

export const products = [
  // Data Management and Storage Solutions
  {
    id: 1,
    categoryId: 1,
    name: 'Teradata Platform and Databases',
    shortName: 'Teradata',
    description: 'Teradata Vantage is an analytics platform designed for running complex queries and managing large-scale data analytics.',
    icon: 'teradata',
    serviceCategories: [
      {
        id: 1,
        number: '1',
        name: 'User Onboarding & Initial Setup',
        description: 'Getting new users started with Teradata access',
        services: [
          { id: 1, number: '1.1', name: 'Teradata Onboarding Service', functionalities: ['Submit onboarding request', 'Onboarding request approval', 'Request status tracking and lookup', 'Reporting services'] },
          { id: 2, number: '1.2', name: 'Teradata Access Management - Initial ID Request', functionalities: ['Submit request for new Teradata ID', 'Request approval workflow (manager/approver approval)', 'View request status'] },
          { id: 3, number: '1.3', name: 'Service ID Creation Service', functionalities: ['Create service IDs on Teradata', 'Reporting manager approval/denial', 'Questionnaire completion for approved requests', 'Questionnaire approval process', 'Request status tracking and lookup'] }
        ]
      },
      {
        id: 2,
        number: '2',
        name: 'Access Provisioning & Management',
        description: 'Managing data access rights after initial setup',
        services: [
          { id: 4, number: '2.1', name: 'Teradata Access Management - Additional Access', functionalities: ['Request additional access to data objects (databases/tables/views)', 'Access category-based permission requests', 'View access request status'] },
          { id: 5, number: '2.2', name: 'Access Category Management Service', functionalities: ['Create new access categories', 'Update existing access categories', 'Approve access category creation/update requests', 'Lookup access categories'] },
          { id: 6, number: '2.3', name: 'Access Lookup Service', functionalities: ['View access to Teradata databases, tables, and views', 'View access to Hadoop Hive databases and tables', 'Access reporting services'] }
        ]
      },
      {
        id: 3,
        number: '3',
        name: 'Password & Credential Management',
        description: 'Managing passwords and credentials',
        services: [
          { id: 7, number: '3.1', name: 'Change Password Service', functionalities: ['Change Teradata password', 'Password policy compliance', 'Password history management'] },
          { id: 8, number: '3.2', name: 'Non-Standard ID Password Management', functionalities: ['Reset passwords for non-standard IDs', 'Emergency access procedures'] },
          { id: 9, number: '3.3', name: 'Standard ID Password Management', functionalities: ['Reset passwords for standard IDs', 'Self-service password reset'] }
        ]
      },
      {
        id: 4,
        number: '4',
        name: 'Database & Environment Provisioning',
        description: 'Creating and configuring database environments',
        services: [
          { id: 10, number: '4.1', name: 'Database Creation Service', functionalities: ['Request new database creation', 'Database configuration', 'Space allocation'] },
          { id: 11, number: '4.2', name: 'Initial Environment Configuration Service', functionalities: ['Configure initial environment settings', 'Set up user spaces', 'Define access permissions'] }
        ]
      },
      {
        id: 5,
        number: '5',
        name: 'Asset Ownership & Compliance',
        description: 'Managing asset ownership for audit and compliance',
        services: [
          { id: 12, number: '5.1', name: 'Asset Ownership Management', functionalities: ['Define asset owners', 'Transfer ownership', 'Ownership reporting'] },
          { id: 13, number: '5.2', name: 'Asset Data Synchronization', functionalities: ['Sync asset data across systems', 'Data reconciliation'] },
          { id: 14, number: '5.3', name: 'Access Category Mapping', functionalities: ['Map access categories to assets', 'Category compliance reporting'] }
        ]
      },
      {
        id: 6,
        number: '6',
        name: 'Data Pipeline Management',
        description: 'Managing data pipelines and workflows',
        services: [
          { id: 15, number: '6.1', name: 'Data Pipeline Monitoring', functionalities: ['Monitor pipeline status', 'Alert on failures', 'Performance metrics'] }
        ]
      },
      {
        id: 7,
        number: '7',
        name: 'Performance & Optimization',
        description: 'Optimizing query and system performance',
        services: [
          { id: 16, number: '7.1', name: 'Query Analysis Service', functionalities: ['Analyze query performance', 'Optimization recommendations', 'Resource usage reports'] }
        ]
      },
      {
        id: 8,
        number: '8',
        name: 'Reporting & Analytics',
        description: 'Operational reporting and dashboards',
        services: [
          { id: 17, number: '8.1', name: 'Platform Operational Reporting Service', functionalities: ['Generate operational reports', 'Usage statistics', 'Trend analysis'] },
          { id: 18, number: '8.2', name: 'Platform Operations Dashboard', functionalities: ['Real-time operations dashboard', 'KPI monitoring', 'Alert management'] }
        ]
      },
      {
        id: 9,
        number: '9',
        name: 'Communication & Support',
        description: 'Support and communication services',
        services: [
          { id: 19, number: '9.1', name: 'Bulletin Service', functionalities: ['View system bulletins', 'Maintenance notifications', 'Update announcements'] },
          { id: 20, number: '9.2', name: 'Help Desk Service', functionalities: ['Submit support tickets', 'Track ticket status', 'Knowledge base access'] }
        ]
      }
    ]
  },
  {
    id: 2,
    categoryId: 1,
    name: 'Oracle Platform and Databases',
    shortName: 'Oracle',
    description: 'Oracle Database is a multi-model database management system known for enterprise-grade performance and reliability.',
    icon: 'oracle',
    serviceCategories: [
      {
        id: 1, number: '1', name: 'User Onboarding & Initial Setup', description: 'Getting new users started with Oracle Database',
        services: [
          { id: 1, number: '1.1', name: 'Oracle Database User Provisioning', functionalities: ['Submit user account creation request', 'DBA review and approval workflow', 'Oracle user profile creation', 'Initial privileges assignment'] },
          { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['First-time login setup', 'User profile configuration', 'Default tablespace assignment', 'Quota allocation'] },
          { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Create service accounts', 'Approval workflow', 'Credential management', 'Documentation and ownership assignment'] }
        ]
      },
      {
        id: 2, number: '2', name: 'Access Provisioning & Management', description: 'Managing access rights and permissions',
        services: [
          { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Request system privileges', 'Request object privileges', 'Role-based access control', 'GRANT and REVOKE workflows'] },
          { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Request access to specific resources', 'Resource-level permissions', 'Cross-environment access'] },
          { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['View granted permissions', 'Access reports and audits', 'Permission history', 'Compliance reporting'] }
        ]
      },
      {
        id: 3, number: '3', name: 'Password & Credential Management', description: 'Managing passwords and authentication',
        services: [
          { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password reset', 'Password policy compliance', 'Password expiration management'] },
          { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Configure authentication methods', 'Multi-factor authentication', 'SSO integration'] },
          { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Account lockout management', 'Security alerts', 'Suspicious activity monitoring'] }
        ]
      },
      {
        id: 4, number: '4', name: 'Database & Environment Provisioning', description: 'Creating and configuring environments',
        services: [
          { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Request new database', 'Resource allocation', 'Configuration'] },
          { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Create schemas', 'Manage database objects', 'Object permissions'] },
          { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Migrate between environments', 'Data transfer', 'Configuration sync'] }
        ]
      },
      {
        id: 5, number: '5', name: 'Asset Ownership & Compliance', description: 'Asset management and compliance',
        services: [
          { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Define owners', 'Transfer ownership', 'Ownership tracking'] },
          { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Asset cataloging', 'Inventory reports', 'Asset lifecycle'] },
          { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance checks', 'Audit trails', 'Regulatory reporting'] }
        ]
      },
      {
        id: 6, number: '6', name: 'Data Operations', description: 'Day-to-day data operations',
        services: [
          { id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Data import/export', 'Backup operations', 'Maintenance tasks'] }
        ]
      },
      {
        id: 7, number: '7', name: 'Performance & Optimization', description: 'Performance monitoring and optimization',
        services: [
          { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Query analysis', 'Execution plans', 'Bottleneck identification'] },
          { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Real-time monitoring', 'Alerts', 'Metrics collection'] },
          { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Index recommendations', 'Query tuning', 'Resource optimization'] }
        ]
      },
      {
        id: 8, number: '8', name: 'Reporting & Analytics', description: 'Operational reporting',
        services: [
          { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Usage reports', 'Performance reports', 'Trend analysis'] },
          { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Real-time dashboards', 'KPI tracking', 'Custom reports'] }
        ]
      },
      {
        id: 9, number: '9', name: 'Communication & Support', description: 'Support services',
        services: [
          { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['System notifications', 'Maintenance alerts', 'Updates'] },
          { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Submit tickets', 'Track issues', 'Knowledge base'] }
        ]
      }
    ]
  },
  {
    id: 3,
    categoryId: 1,
    name: 'SQL Server Databases',
    shortName: 'SQL Server',
    description: 'Microsoft SQL Server is a relational database management system for enterprise data management.',
    icon: 'sqlserver',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', description: 'Getting new users started', services: [
        { id: 1, number: '1.1', name: 'SQL Server Database User Provisioning', functionalities: ['Submit request for new SQL Server login', 'Windows/SQL Authentication', 'Login request approval'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['First-time login setup', 'User profile configuration', 'Default permissions'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Create service accounts', 'Approval workflow', 'Credential management'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', description: 'Managing access rights', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Request server-level roles', 'Request database roles', 'Custom role creation'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Request resource access', 'Cross-environment access'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['View permissions', 'Access reports', 'Compliance reporting'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', description: 'Password management', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password reset', 'Policy compliance'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Configure authentication', 'MFA setup'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Account lockout', 'Security monitoring'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', description: 'Environment setup', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Request new database', 'Resource allocation'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema creation', 'Object management'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Environment migration', 'Data transfer'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', description: 'Compliance management', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Define owners', 'Transfer ownership'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Asset cataloging', 'Inventory reports'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance checks', 'Audit trails'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', description: 'Operational tasks', services: [
        { id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Data operations', 'Backup tasks'] }
      ]},
      { id: 7, number: '7', name: 'Performance & Optimization', description: 'Performance tuning', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Query analysis', 'Performance reports'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Real-time monitoring', 'Alerts'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Index optimization', 'Query tuning'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', description: 'Reporting', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Usage reports', 'Analytics'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards', 'KPIs'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', description: 'Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications', 'Alerts'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support tickets', 'Knowledge base'] }
      ]}
    ]
  },
  {
    id: 4,
    categoryId: 1,
    name: 'Mainframe DB2',
    shortName: 'DB2',
    description: 'IBM DB2 for z/OS is a high-performance relational database for mainframe environments.',
    icon: 'db2',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', description: 'Getting new users started with Mainframe DB2', services: [
        { id: 1, number: '1.1', name: 'Mainframe DB2 User Provisioning', functionalities: ['Submit user account creation request', 'Account approval workflow', 'Initial access setup'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['First-time login and setup', 'User profile configuration'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Create service accounts', 'Approval workflow'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', description: 'Managing access rights', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Request and grant permissions', 'Role-based access control'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Request access to specific resources'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['View granted permissions', 'Access reports'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', description: 'Credentials management', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password reset', 'Policy compliance'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Configure authentication'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Account security management'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', description: 'Environment provisioning', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Request new database'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema management'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Environment migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', description: 'Compliance', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Define owners'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Asset cataloging'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance checks'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', description: 'Operations', services: [
        { id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Data operations'] }
      ]},
      { id: 7, number: '7', name: 'Performance & Optimization', description: 'Performance', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Query analysis'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', description: 'Reporting', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', description: 'Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 5, categoryId: 1, name: 'MySQL', shortName: 'MySQL',
    description: 'MySQL is an open-source relational database management system widely used for web applications.',
    icon: 'mysql',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', description: 'Getting new users started', services: [
        { id: 1, number: '1.1', name: 'MySQL User Provisioning', functionalities: ['Submit user account creation request', 'Account approval workflow'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['First-time login and setup'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Create service accounts'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', description: 'Managing access', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Grant permissions'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Access auditing'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', description: 'Credentials', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password reset'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', description: 'Provisioning', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Create database'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema management'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', description: 'Compliance', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', description: 'Operations', services: [
        { id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Operations'] }
      ]},
      { id: 7, number: '7', name: 'Performance & Optimization', description: 'Performance', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', description: 'Reporting', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', description: 'Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 6, categoryId: 1, name: 'PostgreSQL', shortName: 'PostgreSQL',
    description: 'PostgreSQL is a powerful, open-source object-relational database system with strong standards compliance.',
    icon: 'postgresql',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'PostgreSQL User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Service accounts'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Creation'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', services: [{ id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Operations'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 7, categoryId: 1, name: 'Cassandra', shortName: 'Cassandra',
    description: 'Apache Cassandra is a distributed NoSQL database for handling large amounts of data across multiple servers.',
    icon: 'cassandra',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Cassandra User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Service accounts'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Creation'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', services: [{ id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Operations'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 8, categoryId: 1, name: 'MongoDB', shortName: 'MongoDB',
    description: 'MongoDB is a document-oriented NoSQL database designed for scalability and flexibility.',
    icon: 'mongodb',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'MongoDB User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Service accounts'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Creation'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', services: [{ id: 16, number: '6.1', name: 'Operational Tasks', functionalities: ['Operations'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 9, categoryId: 1, name: 'Hadoop Hive', shortName: 'Hive',
    description: 'Apache Hive is a data warehouse infrastructure for providing data query and analysis.',
    icon: 'hive',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Hadoop Hive User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 3, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 4, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 5, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 6, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 7, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 8, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', services: [
        { id: 9, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Creation'] },
        { id: 10, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema'] },
        { id: 11, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 12, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 13, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 14, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Pipeline Management', services: [{ id: 15, number: '6.1', name: 'Pipeline Orchestration', functionalities: ['Orchestration'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 16, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 17, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 19, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 20, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 21, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 22, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 10, categoryId: 1, name: 'Hadoop HDFS', shortName: 'HDFS',
    description: 'Hadoop Distributed File System provides high-throughput access to application data.',
    icon: 'hdfs',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Hadoop HDFS User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 3, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 4, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 5, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 6, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 7, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 8, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', services: [
        { id: 9, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Creation'] },
        { id: 10, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema'] },
        { id: 11, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 12, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 13, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 14, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Pipeline Management', services: [{ id: 15, number: '6.1', name: 'Pipeline Orchestration', functionalities: ['Orchestration'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 16, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 17, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 19, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 20, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 21, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 22, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 11, categoryId: 1, name: 'Snowflake', shortName: 'Snowflake',
    description: 'Snowflake is a cloud-based data warehousing platform for analytics and data sharing.',
    icon: 'snowflake',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Snowflake User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] },
        { id: 3, number: '1.3', name: 'Service Account Setup', functionalities: ['Service accounts'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 5, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 6, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 7, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 8, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 9, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Database & Environment Provisioning', services: [
        { id: 10, number: '4.1', name: 'Database/Resource Creation', functionalities: ['Creation'] },
        { id: 11, number: '4.2', name: 'Schema and Object Management', functionalities: ['Schema'] },
        { id: 12, number: '4.3', name: 'Environment Migration', functionalities: ['Migration'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 15, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Pipeline Management', services: [{ id: 16, number: '6.1', name: 'Pipeline Orchestration', functionalities: ['Orchestration'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 17, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 18, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 19, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 20, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 21, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 22, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 23, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  // IT Operations and Orchestration Tools
  {
    id: 12, categoryId: 2, name: 'Airflow', shortName: 'Airflow',
    description: 'Apache Airflow is a platform to programmatically author, schedule, and monitor workflows.',
    icon: 'airflow',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Airflow User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 3, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 4, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 5, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 6, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 7, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 8, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Resource Provisioning', services: [
        { id: 9, number: '4.1', name: 'Resource Configuration', functionalities: ['Configuration'] },
        { id: 10, number: '4.2', name: 'Deployment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 11, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 12, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 13, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Pipeline Management', services: [{ id: 14, number: '6.1', name: 'Pipeline Orchestration', functionalities: ['Orchestration'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 15, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 16, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 17, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 18, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 19, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 20, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 21, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 13, categoryId: 2, name: 'Splunk', shortName: 'Splunk',
    description: 'Splunk is a software platform for searching, monitoring, and analyzing machine-generated data.',
    icon: 'splunk',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Splunk User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 3, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 4, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 5, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 6, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 7, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 8, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Resource Provisioning', services: [
        { id: 9, number: '4.1', name: 'Resource Configuration', functionalities: ['Configuration'] },
        { id: 10, number: '4.2', name: 'Deployment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 11, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 12, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 13, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', services: [{ id: 14, number: '6.1', name: 'Operational Tasks', functionalities: ['Operations'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 15, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 16, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 17, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 18, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 19, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 20, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 21, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  {
    id: 14, categoryId: 2, name: 'Dynatrace', shortName: 'Dynatrace',
    description: 'Dynatrace is a software intelligence platform providing application performance management and monitoring.',
    icon: 'dynatrace',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Dynatrace User Provisioning', functionalities: ['User provisioning'] },
        { id: 2, number: '1.2', name: 'Initial Configuration', functionalities: ['Configuration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 3, number: '2.1', name: 'Permission Management', functionalities: ['Permissions'] },
        { id: 4, number: '2.2', name: 'Resource Access Management', functionalities: ['Resource access'] },
        { id: 5, number: '2.3', name: 'Access Audit and Lookup', functionalities: ['Audit'] }
      ]},
      { id: 3, number: '3', name: 'Password & Credential Management', services: [
        { id: 6, number: '3.1', name: 'Password Management', functionalities: ['Password'] },
        { id: 7, number: '3.2', name: 'Authentication Methods', functionalities: ['Authentication'] },
        { id: 8, number: '3.3', name: 'Account Security', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Resource Provisioning', services: [
        { id: 9, number: '4.1', name: 'Resource Configuration', functionalities: ['Configuration'] },
        { id: 10, number: '4.2', name: 'Deployment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 11, number: '5.1', name: 'Ownership Management', functionalities: ['Ownership'] },
        { id: 12, number: '5.2', name: 'Asset Inventory', functionalities: ['Inventory'] },
        { id: 13, number: '5.3', name: 'Compliance and Auditing', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Data Operations', services: [{ id: 14, number: '6.1', name: 'Operational Tasks', functionalities: ['Operations'] }]},
      { id: 7, number: '7', name: 'Performance & Optimization', services: [
        { id: 15, number: '7.1', name: 'Performance Analysis', functionalities: ['Analysis'] },
        { id: 16, number: '7.2', name: 'Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 17, number: '7.3', name: 'Optimization Services', functionalities: ['Optimization'] }
      ]},
      { id: 8, number: '8', name: 'Reporting & Analytics', services: [
        { id: 18, number: '8.1', name: 'Operational Reporting', functionalities: ['Reports'] },
        { id: 19, number: '8.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] }
      ]},
      { id: 9, number: '9', name: 'Communication & Support', services: [
        { id: 20, number: '9.1', name: 'Notification Service', functionalities: ['Notifications'] },
        { id: 21, number: '9.2', name: 'Help Desk and Support', functionalities: ['Support'] }
      ]}
    ]
  },
  // AI Large Language Models
  {
    id: 15, categoryId: 3, name: 'Microsoft Copilot', shortName: 'Copilot',
    description: 'Microsoft Copilot is an AI assistant powered by large language models for productivity enhancement.',
    icon: 'copilot',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Microsoft Account Creation Service', functionalities: ['Account creation'] },
        { id: 2, number: '1.2', name: 'Model Access and Onboarding', functionalities: ['Model access'] },
        { id: 3, number: '1.3', name: 'Integration Setup', functionalities: ['Integration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'API Key and Access Management', functionalities: ['API keys'] },
        { id: 5, number: '2.2', name: 'Organization and Team Management', functionalities: ['Team management'] },
        { id: 6, number: '2.3', name: 'Model Access Control', functionalities: ['Model access'] }
      ]},
      { id: 3, number: '3', name: 'Credential & Authentication Management', services: [
        { id: 7, number: '3.1', name: 'Account Authentication', functionalities: ['Authentication'] },
        { id: 8, number: '3.2', name: 'API Authentication Methods', functionalities: ['API auth'] },
        { id: 9, number: '3.3', name: 'Security and Compliance', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Model & Resource Provisioning', services: [
        { id: 10, number: '4.1', name: 'Model Selection and Configuration', functionalities: ['Model config'] },
        { id: 11, number: '4.2', name: 'Fine-tuning and Custom Models', functionalities: ['Fine-tuning'] },
        { id: 12, number: '4.3', name: 'Deployment and Environment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Model and Data Ownership', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Usage Tracking and Inventory', functionalities: ['Tracking'] },
        { id: 15, number: '5.3', name: 'Compliance and Governance', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Performance & Optimization', services: [
        { id: 16, number: '6.1', name: 'Latency and Throughput Optimization', functionalities: ['Optimization'] },
        { id: 17, number: '6.2', name: 'Model Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '6.3', name: 'Quality and Accuracy Optimization', functionalities: ['Quality'] }
      ]},
      { id: 7, number: '7', name: 'Reporting & Analytics', services: [
        { id: 19, number: '7.1', name: 'Usage and Cost Reporting', functionalities: ['Usage reports'] },
        { id: 20, number: '7.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] },
        { id: 21, number: '7.3', name: 'Model Analytics', functionalities: ['Analytics'] }
      ]},
      { id: 8, number: '8', name: 'Communication & Support', services: [
        { id: 22, number: '8.1', name: 'Notification and Alert Services', functionalities: ['Notifications'] },
        { id: 23, number: '8.2', name: 'Developer Support and Resources', functionalities: ['Support'] },
        { id: 24, number: '8.3', name: 'Developer Community', functionalities: ['Community'] }
      ]}
    ]
  },
  {
    id: 16, categoryId: 3, name: 'GPT series (OpenAI)', shortName: 'GPT',
    description: 'OpenAI GPT series are advanced language models for natural language understanding and generation.',
    icon: 'openai',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'OpenAI Account Creation Service', functionalities: ['Account creation'] },
        { id: 2, number: '1.2', name: 'Model Access and Onboarding', functionalities: ['Model access'] },
        { id: 3, number: '1.3', name: 'Integration Setup', functionalities: ['Integration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'API Key and Access Management', functionalities: ['API keys'] },
        { id: 5, number: '2.2', name: 'Organization and Team Management', functionalities: ['Team management'] },
        { id: 6, number: '2.3', name: 'Model Access Control', functionalities: ['Model access'] }
      ]},
      { id: 3, number: '3', name: 'Credential & Authentication Management', services: [
        { id: 7, number: '3.1', name: 'Account Authentication', functionalities: ['Authentication'] },
        { id: 8, number: '3.2', name: 'API Authentication Methods', functionalities: ['API auth'] },
        { id: 9, number: '3.3', name: 'Security and Compliance', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Model & Resource Provisioning', services: [
        { id: 10, number: '4.1', name: 'Model Selection and Configuration', functionalities: ['Model config'] },
        { id: 11, number: '4.2', name: 'Fine-tuning and Custom Models', functionalities: ['Fine-tuning'] },
        { id: 12, number: '4.3', name: 'Deployment and Environment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Model and Data Ownership', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Usage Tracking and Inventory', functionalities: ['Tracking'] },
        { id: 15, number: '5.3', name: 'Compliance and Governance', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Performance & Optimization', services: [
        { id: 16, number: '6.1', name: 'Latency and Throughput Optimization', functionalities: ['Optimization'] },
        { id: 17, number: '6.2', name: 'Model Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '6.3', name: 'Quality and Accuracy Optimization', functionalities: ['Quality'] }
      ]},
      { id: 7, number: '7', name: 'Reporting & Analytics', services: [
        { id: 19, number: '7.1', name: 'Usage and Cost Reporting', functionalities: ['Usage reports'] },
        { id: 20, number: '7.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] },
        { id: 21, number: '7.3', name: 'Model Analytics', functionalities: ['Analytics'] }
      ]},
      { id: 8, number: '8', name: 'Communication & Support', services: [
        { id: 22, number: '8.1', name: 'Notification and Alert Services', functionalities: ['Notifications'] },
        { id: 23, number: '8.2', name: 'Developer Support and Resources', functionalities: ['Support'] },
        { id: 24, number: '8.3', name: 'Developer Community', functionalities: ['Community'] }
      ]}
    ]
  },
  {
    id: 17, categoryId: 3, name: 'Gemini models (Google DeepMind)', shortName: 'Gemini',
    description: 'Google Gemini is a multimodal AI model for various language and reasoning tasks.',
    icon: 'gemini',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Google DeepMind Account Creation Service', functionalities: ['Account creation'] },
        { id: 2, number: '1.2', name: 'Model Access and Onboarding', functionalities: ['Model access'] },
        { id: 3, number: '1.3', name: 'Integration Setup', functionalities: ['Integration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'API Key and Access Management', functionalities: ['API keys'] },
        { id: 5, number: '2.2', name: 'Organization and Team Management', functionalities: ['Team management'] },
        { id: 6, number: '2.3', name: 'Model Access Control', functionalities: ['Model access'] }
      ]},
      { id: 3, number: '3', name: 'Credential & Authentication Management', services: [
        { id: 7, number: '3.1', name: 'Account Authentication', functionalities: ['Authentication'] },
        { id: 8, number: '3.2', name: 'API Authentication Methods', functionalities: ['API auth'] },
        { id: 9, number: '3.3', name: 'Security and Compliance', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Model & Resource Provisioning', services: [
        { id: 10, number: '4.1', name: 'Model Selection and Configuration', functionalities: ['Model config'] },
        { id: 11, number: '4.2', name: 'Fine-tuning and Custom Models', functionalities: ['Fine-tuning'] },
        { id: 12, number: '4.3', name: 'Deployment and Environment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Model and Data Ownership', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Usage Tracking and Inventory', functionalities: ['Tracking'] },
        { id: 15, number: '5.3', name: 'Compliance and Governance', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Performance & Optimization', services: [
        { id: 16, number: '6.1', name: 'Latency and Throughput Optimization', functionalities: ['Optimization'] },
        { id: 17, number: '6.2', name: 'Model Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '6.3', name: 'Quality and Accuracy Optimization', functionalities: ['Quality'] }
      ]},
      { id: 7, number: '7', name: 'Reporting & Analytics', services: [
        { id: 19, number: '7.1', name: 'Usage and Cost Reporting', functionalities: ['Usage reports'] },
        { id: 20, number: '7.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] },
        { id: 21, number: '7.3', name: 'Model Analytics', functionalities: ['Analytics'] }
      ]},
      { id: 8, number: '8', name: 'Communication & Support', services: [
        { id: 22, number: '8.1', name: 'Notification and Alert Services', functionalities: ['Notifications'] },
        { id: 23, number: '8.2', name: 'Developer Support and Resources', functionalities: ['Support'] },
        { id: 24, number: '8.3', name: 'Developer Community', functionalities: ['Community'] }
      ]}
    ]
  },
  {
    id: 18, categoryId: 3, name: 'Llama series (Meta AI)', shortName: 'Llama',
    description: 'Meta Llama is an open-source large language model for research and commercial applications.',
    icon: 'llama',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'Meta AI Account Creation Service', functionalities: ['Account creation'] },
        { id: 2, number: '1.2', name: 'Model Access and Onboarding', functionalities: ['Model access'] },
        { id: 3, number: '1.3', name: 'Integration Setup', functionalities: ['Integration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'API Key and Access Management', functionalities: ['API keys'] },
        { id: 5, number: '2.2', name: 'Organization and Team Management', functionalities: ['Team management'] },
        { id: 6, number: '2.3', name: 'Model Access Control', functionalities: ['Model access'] }
      ]},
      { id: 3, number: '3', name: 'Credential & Authentication Management', services: [
        { id: 7, number: '3.1', name: 'Account Authentication', functionalities: ['Authentication'] },
        { id: 8, number: '3.2', name: 'API Authentication Methods', functionalities: ['API auth'] },
        { id: 9, number: '3.3', name: 'Security and Compliance', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Model & Resource Provisioning', services: [
        { id: 10, number: '4.1', name: 'Model Selection and Configuration', functionalities: ['Model config'] },
        { id: 11, number: '4.2', name: 'Fine-tuning and Custom Models', functionalities: ['Fine-tuning'] },
        { id: 12, number: '4.3', name: 'Deployment and Environment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Model and Data Ownership', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Usage Tracking and Inventory', functionalities: ['Tracking'] },
        { id: 15, number: '5.3', name: 'Compliance and Governance', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Performance & Optimization', services: [
        { id: 16, number: '6.1', name: 'Latency and Throughput Optimization', functionalities: ['Optimization'] },
        { id: 17, number: '6.2', name: 'Model Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '6.3', name: 'Quality and Accuracy Optimization', functionalities: ['Quality'] }
      ]},
      { id: 7, number: '7', name: 'Reporting & Analytics', services: [
        { id: 19, number: '7.1', name: 'Usage and Cost Reporting', functionalities: ['Usage reports'] },
        { id: 20, number: '7.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] },
        { id: 21, number: '7.3', name: 'Model Analytics', functionalities: ['Analytics'] }
      ]},
      { id: 8, number: '8', name: 'Communication & Support', services: [
        { id: 22, number: '8.1', name: 'Notification and Alert Services', functionalities: ['Notifications'] },
        { id: 23, number: '8.2', name: 'Developer Support and Resources', functionalities: ['Support'] },
        { id: 24, number: '8.3', name: 'Developer Community', functionalities: ['Community'] }
      ]}
    ]
  },
  {
    id: 19, categoryId: 3, name: 'Grok (xAI)', shortName: 'Grok',
    description: 'Grok is an AI assistant developed by xAI with real-time knowledge capabilities.',
    icon: 'grok',
    serviceCategories: [
      { id: 1, number: '1', name: 'User Onboarding & Initial Setup', services: [
        { id: 1, number: '1.1', name: 'xAI Account Creation Service', functionalities: ['Account creation'] },
        { id: 2, number: '1.2', name: 'Model Access and Onboarding', functionalities: ['Model access'] },
        { id: 3, number: '1.3', name: 'Integration Setup', functionalities: ['Integration'] }
      ]},
      { id: 2, number: '2', name: 'Access Provisioning & Management', services: [
        { id: 4, number: '2.1', name: 'API Key and Access Management', functionalities: ['API keys'] },
        { id: 5, number: '2.2', name: 'Organization and Team Management', functionalities: ['Team management'] },
        { id: 6, number: '2.3', name: 'Model Access Control', functionalities: ['Model access'] }
      ]},
      { id: 3, number: '3', name: 'Credential & Authentication Management', services: [
        { id: 7, number: '3.1', name: 'Account Authentication', functionalities: ['Authentication'] },
        { id: 8, number: '3.2', name: 'API Authentication Methods', functionalities: ['API auth'] },
        { id: 9, number: '3.3', name: 'Security and Compliance', functionalities: ['Security'] }
      ]},
      { id: 4, number: '4', name: 'Model & Resource Provisioning', services: [
        { id: 10, number: '4.1', name: 'Model Selection and Configuration', functionalities: ['Model config'] },
        { id: 11, number: '4.2', name: 'Fine-tuning and Custom Models', functionalities: ['Fine-tuning'] },
        { id: 12, number: '4.3', name: 'Deployment and Environment Management', functionalities: ['Deployment'] }
      ]},
      { id: 5, number: '5', name: 'Asset Ownership & Compliance', services: [
        { id: 13, number: '5.1', name: 'Model and Data Ownership', functionalities: ['Ownership'] },
        { id: 14, number: '5.2', name: 'Usage Tracking and Inventory', functionalities: ['Tracking'] },
        { id: 15, number: '5.3', name: 'Compliance and Governance', functionalities: ['Compliance'] }
      ]},
      { id: 6, number: '6', name: 'Performance & Optimization', services: [
        { id: 16, number: '6.1', name: 'Latency and Throughput Optimization', functionalities: ['Optimization'] },
        { id: 17, number: '6.2', name: 'Model Performance Monitoring', functionalities: ['Monitoring'] },
        { id: 18, number: '6.3', name: 'Quality and Accuracy Optimization', functionalities: ['Quality'] }
      ]},
      { id: 7, number: '7', name: 'Reporting & Analytics', services: [
        { id: 19, number: '7.1', name: 'Usage and Cost Reporting', functionalities: ['Usage reports'] },
        { id: 20, number: '7.2', name: 'Operations Dashboard', functionalities: ['Dashboards'] },
        { id: 21, number: '7.3', name: 'Model Analytics', functionalities: ['Analytics'] }
      ]},
      { id: 8, number: '8', name: 'Communication & Support', services: [
        { id: 22, number: '8.1', name: 'Notification and Alert Services', functionalities: ['Notifications'] },
        { id: 23, number: '8.2', name: 'Developer Support and Resources', functionalities: ['Support'] },
        { id: 24, number: '8.3', name: 'Developer Community', functionalities: ['Community'] }
      ]}
    ]
  }
];

// Helper function to get products by category
export const getProductsByCategory = (categoryId) => {
  return products.filter(p => p.categoryId === categoryId);
};

// Helper function to get product by ID
export const getProductById = (productId) => {
  return products.find(p => p.id === productId);
};
