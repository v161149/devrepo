import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  MessageSquare, 
  Users, 
  Search, 
  X, 
  ChevronDown,
  FileText,
  Edit,
  Trash2,
  Send
} from 'lucide-react';

const Header = () => {
  const [showSearch, setShowSearch] = useState(false);
  const [showAboutDropdown, setShowAboutDropdown] = useState(false);
  const [showAdminDropdown, setShowAdminDropdown] = useState(false);
  const [showTeamDropdown, setShowTeamDropdown] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { isAuthenticated, isAdmin, login, logout, user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogin = () => {
    // Demo login - in production this would be a proper auth flow
    login({
      id: 1,
      username: 'admin',
      email: 'admin@irc.com',
      firstName: 'Admin',
      lastName: 'User',
      role: 'admin'
    });
  };

  const handleSearch = (e) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      // Navigate to search results or handle search
      console.log('Searching for:', searchQuery);
      setShowSearch(false);
      setSearchQuery('');
    }
  };

  return (
    <header className="header">
      {/* Search Overlay */}
      {showSearch && (
        <div className="search-overlay">
          <div className="search-header">
            <div className="search-input-wrapper">
              <Search size={20} />
              <input
                type="text"
                placeholder="Search HubSpot"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearch}
                autoFocus
              />
            </div>
            <button className="close-search" onClick={() => setShowSearch(false)}>
              <X size={24} />
            </button>
          </div>
        </div>
      )}

      {/* Top Header Row */}
      <div className="header-top">
        <div className="header-top-left">
          <Link to="/communication-support">
            <MessageSquare size={16} />
            Communication & Support
          </Link>
          <Link to="/contact-us">
            <Users size={16} />
            Contact Us
          </Link>
          {isAuthenticated && isAdmin() && (
            <div 
              className="nav-item"
              onMouseEnter={() => setShowAdminDropdown(true)}
              onMouseLeave={() => setShowAdminDropdown(false)}
              style={{ position: 'relative' }}
            >
              <button className="nav-link" style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                News Management <ChevronDown size={14} />
              </button>
              {showAdminDropdown && (
                <div className="dropdown-menu">
                  <Link to="/admin/news/create" className="dropdown-item">
                    <FileText size={14} style={{ marginRight: '0.5rem' }} />
                    Create News
                  </Link>
                  <Link to="/admin/news/edit" className="dropdown-item">
                    <Edit size={14} style={{ marginRight: '0.5rem' }} />
                    Edit News
                  </Link>
                  <Link to="/admin/news/delete" className="dropdown-item">
                    <Trash2 size={14} style={{ marginRight: '0.5rem' }} />
                    Delete News
                  </Link>
                  <Link to="/admin/news/publish" className="dropdown-item">
                    <Send size={14} style={{ marginRight: '0.5rem' }} />
                    Publish News
                  </Link>
                </div>
              )}
            </div>
          )}
          {isAuthenticated && isAdmin() && (
            <div 
              className="nav-item"
              onMouseEnter={() => setShowTeamDropdown(true)}
              onMouseLeave={() => setShowTeamDropdown(false)}
              style={{ position: 'relative' }}
            >
              <button className="nav-link" style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                Team Management <ChevronDown size={14} />
              </button>
              {showTeamDropdown && (
                <div className="dropdown-menu">
                  <Link to="/admin/team/create" className="dropdown-item">
                    <Users size={14} style={{ marginRight: '0.5rem' }} />
                    Create Team Member Profile
                  </Link>
                  <Link to="/admin/team/edit" className="dropdown-item">
                    <Edit size={14} style={{ marginRight: '0.5rem' }} />
                    Edit Team Member Profile
                  </Link>
                  <Link to="/admin/team/delete" className="dropdown-item">
                    <Trash2 size={14} style={{ marginRight: '0.5rem' }} />
                    Delete Team Member Profile
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
        <div className="header-top-right">
          <button onClick={() => setShowSearch(true)}>
            <Search size={16} />
          </button>
          {isAuthenticated ? (
            <button onClick={logout}>Log out</button>
          ) : (
            <button onClick={handleLogin}>Log in</button>
          )}
          <div 
            className="nav-item"
            onMouseEnter={() => setShowAboutDropdown(true)}
            onMouseLeave={() => setShowAboutDropdown(false)}
          >
            <button className="nav-link">
              About <ChevronDown size={14} />
            </button>
            {showAboutDropdown && (
              <div className="dropdown-menu">
                <Link to="/about-us" className="dropdown-item">About Us</Link>
                <Link to="/contact-us" className="dropdown-item">Contact Us</Link>
                <Link to="/management-team" className="dropdown-item">Management Team</Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="header-main">
        <Link to="/" className="logo">
          Information Resource Center
        </Link>
        <nav className="main-nav">
          <div className="nav-item">
            <Link 
              to="/products-services" 
              className={`nav-link ${location.pathname.includes('/products-services') ? 'active' : ''}`}
            >
              Products & Services <ChevronDown size={14} />
            </Link>
          </div>
          <div className="nav-item">
            <Link 
              to="/sla-management" 
              className={`nav-link ${location.pathname === '/sla-management' ? 'active' : ''}`}
            >
              SLA Management <ChevronDown size={14} />
            </Link>
          </div>
          <div className="nav-item">
            <Link 
              to="/asset-management" 
              className={`nav-link ${location.pathname === '/asset-management' ? 'active' : ''}`}
            >
              Asset Management <ChevronDown size={14} />
            </Link>
          </div>
          <div className="nav-item">
            <Link 
              to="/data-pipeline-management" 
              className={`nav-link ${location.pathname === '/data-pipeline-management' ? 'active' : ''}`}
            >
              Data Pipeline Management <ChevronDown size={14} />
            </Link>
          </div>
          <div className="nav-item">
            <Link 
              to="/operations-dashboard" 
              className={`nav-link ${location.pathname === '/operations-dashboard' ? 'active' : ''}`}
            >
              Operations Dashboard <ChevronDown size={14} />
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
