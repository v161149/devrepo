-- Information Resource Center Database Schema

-- Users table for authentication and roles
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    role VARCHAR(50) DEFAULT 'user', -- 'admin', 'user'
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- News/Announcements table
CREATE TABLE IF NOT EXISTS news (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    news_type VARCHAR(50) NOT NULL, -- 'organization', 'product_release', 'maintenance'
    status VARCHAR(50) DEFAULT 'draft', -- 'draft', 'published', 'archived'
    image_url VARCHAR(500),
    author_id INTEGER,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id)
);

-- Team content for Management/Development/Operation teams
CREATE TABLE IF NOT EXISTS team_content (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_type VARCHAR(50) NOT NULL, -- 'management', 'development', 'operation'
    title VARCHAR(255),
    content TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'draft', -- 'draft', 'published'
    author_id INTEGER,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id)
);

-- Team members
CREATE TABLE IF NOT EXISTS team_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_type VARCHAR(50) NOT NULL, -- 'management', 'development', 'operation'
    name VARCHAR(255) NOT NULL,
    title VARCHAR(255),
    bio TEXT,
    image_url VARCHAR(500),
    email VARCHAR(255),
    linkedin_url VARCHAR(500),
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product categories
CREATE TABLE IF NOT EXISTS product_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products/Platforms
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    short_name VARCHAR(100),
    description TEXT,
    icon_url VARCHAR(500),
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES product_categories(id)
);

-- Service categories within products
CREATE TABLE IF NOT EXISTS service_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    category_number VARCHAR(10),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Sub-categories/services
CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_category_id INTEGER NOT NULL,
    service_number VARCHAR(10),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    functionalities TEXT, -- JSON or delimited list of functionalities
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (service_category_id) REFERENCES service_categories(id)
);

-- About Us content
CREATE TABLE IF NOT EXISTS about_content (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_type VARCHAR(50) NOT NULL, -- 'about_us', 'mission', 'story'
    title VARCHAR(255),
    content TEXT NOT NULL,
    display_order INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'published',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contact requests
CREATE TABLE IF NOT EXISTS contact_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_type VARCHAR(50) NOT NULL, -- 'email', 'chat', 'demo'
    name VARCHAR(255),
    email VARCHAR(255),
    company VARCHAR(255),
    message TEXT,
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'responded', 'closed'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, email, password_hash, first_name, last_name, role) 
VALUES ('admin', 'admin@irc.com', 'pbkdf2:sha256:260000$salt$hashedpassword', 'Admin', 'User', 'admin');

-- Insert default regular user (password: user123)
INSERT INTO users (username, email, password_hash, first_name, last_name, role)
VALUES ('user', 'user@irc.com', 'pbkdf2:sha256:260000$salt$hashedpassword', 'Regular', 'User', 'user');

-- Insert product categories
INSERT INTO product_categories (name, description, display_order) VALUES
('Data Management and Storage Solutions', 'Comprehensive data management platforms and database solutions for enterprise data storage and analytics', 1),
('IT Operations and Orchestration Tools', 'Tools for IT operations monitoring, workflow orchestration, and system management', 2),
('AI Large Language Models (LLMs) and Related Products', 'Advanced AI language models and related products for intelligent automation and natural language processing', 3);

-- Insert products for Data Management and Storage Solutions (category_id = 1)
INSERT INTO products (category_id, name, short_name, description, display_order) VALUES
(1, 'Teradata Platform and Databases', 'Teradata', 'Teradata Vantage is an analytics platform designed for running complex queries and managing large-scale data analytics.', 1),
(1, 'Oracle Platform and Databases', 'Oracle', 'Oracle Database is a multi-model database management system known for enterprise-grade performance and reliability.', 2),
(1, 'SQL Server Databases', 'SQL Server', 'Microsoft SQL Server is a relational database management system for enterprise data management.', 3),
(1, 'Mainframe DB2', 'DB2', 'IBM DB2 for z/OS is a high-performance relational database for mainframe environments.', 4),
(1, 'MySQL', 'MySQL', 'MySQL is an open-source relational database management system widely used for web applications.', 5),
(1, 'PostgreSQL', 'PostgreSQL', 'PostgreSQL is a powerful, open-source object-relational database system with strong standards compliance.', 6),
(1, 'Cassandra', 'Cassandra', 'Apache Cassandra is a distributed NoSQL database for handling large amounts of data across multiple servers.', 7),
(1, 'MongoDB', 'MongoDB', 'MongoDB is a document-oriented NoSQL database designed for scalability and flexibility.', 8),
(1, 'Hadoop Hive', 'Hive', 'Apache Hive is a data warehouse infrastructure for providing data query and analysis.', 9),
(1, 'Hadoop HDFS', 'HDFS', 'Hadoop Distributed File System provides high-throughput access to application data.', 10),
(1, 'Snowflake', 'Snowflake', 'Snowflake is a cloud-based data warehousing platform for analytics and data sharing.', 11);

-- Insert products for IT Operations and Orchestration Tools (category_id = 2)
INSERT INTO products (category_id, name, short_name, description, display_order) VALUES
(2, 'Airflow', 'Airflow', 'Apache Airflow is a platform to programmatically author, schedule, and monitor workflows.', 1),
(2, 'Splunk', 'Splunk', 'Splunk is a software platform for searching, monitoring, and analyzing machine-generated data.', 2),
(2, 'Dynatrace', 'Dynatrace', 'Dynatrace is a software intelligence platform providing application performance management and monitoring.', 3);

-- Insert products for AI LLMs (category_id = 3)
INSERT INTO products (category_id, name, short_name, description, display_order) VALUES
(3, 'Microsoft Copilot', 'Copilot', 'Microsoft Copilot is an AI assistant powered by large language models for productivity enhancement.', 1),
(3, 'GPT series (OpenAI)', 'GPT', 'OpenAI GPT series are advanced language models for natural language understanding and generation.', 2),
(3, 'Gemini models (Google DeepMind)', 'Gemini', 'Google Gemini is a multimodal AI model for various language and reasoning tasks.', 3),
(3, 'Llama series (Meta AI)', 'Llama', 'Meta Llama is an open-source large language model for research and commercial applications.', 4),
(3, 'Grok (xAI)', 'Grok', 'Grok is an AI assistant developed by xAI with real-time knowledge capabilities.', 5);

-- Insert sample news
INSERT INTO news (title, content, news_type, status, published_at) VALUES
('Welcome to Information Resource Center', 'We are excited to launch our new Information Resource Center portal. This platform will serve as your one-stop destination for all data management and IT operations needs.', 'organization', 'published', CURRENT_TIMESTAMP),
('New Snowflake Integration Available', 'We have added full support for Snowflake cloud data warehouse. Users can now provision, manage, and optimize their Snowflake resources directly through our portal.', 'product_release', 'published', CURRENT_TIMESTAMP),
('Scheduled Maintenance - November 25', 'The support phone line will be closed from 9am - 6pm EST on Monday 11/25 for scheduled maintenance. Please use email or chat for support during this time.', 'maintenance', 'published', CURRENT_TIMESTAMP);

-- Insert default About Us content
INSERT INTO about_content (section_type, title, content, display_order) VALUES
('about_us', 'About Us', 'The Information Resource Center is your comprehensive platform for managing data resources, IT operations, and AI-powered solutions. Our team is dedicated to providing seamless access to enterprise-grade tools and services that empower organizations to harness the full potential of their data assets.', 1),
('mission', 'Our Mission: Helping Organizations Grow Better', 'We believe not just in growing bigger, but in growing better. And growing better means aligning the success of your own business with the success of your customers. We strive to provide intuitive, powerful tools that simplify complex data management tasks while maintaining the highest standards of security and compliance.', 2),
('story', 'Our Story', 'Founded with a vision to democratize access to enterprise data management tools, the Information Resource Center has evolved into a comprehensive platform serving organizations of all sizes. Our journey began with a simple idea: make complex data operations accessible to everyone. Today, we support 19 different platforms and databases, serving thousands of users who depend on our services for their daily operations.', 3);

-- Insert sample team members
INSERT INTO team_members (team_type, name, title, bio, display_order) VALUES
('management', 'John Smith', 'Chief Executive Officer', 'John brings over 20 years of experience in enterprise software and data management. He leads our strategic vision and company direction.', 1),
('management', 'Sarah Johnson', 'Chief Technology Officer', 'Sarah oversees all technical aspects of our platform, ensuring we deliver cutting-edge solutions to our users.', 2),
('management', 'Michael Chen', 'Chief Operations Officer', 'Michael manages our day-to-day operations and ensures smooth delivery of all services.', 3),
('development', 'Emily Davis', 'Lead Software Architect', 'Emily designs the overall architecture of our platform and leads the development team in building robust solutions.', 1),
('development', 'David Wilson', 'Senior Backend Developer', 'David specializes in Python microservices and database optimization.', 2),
('development', 'Lisa Anderson', 'Senior Frontend Developer', 'Lisa creates intuitive user interfaces using React and modern web technologies.', 3),
('operation', 'Robert Taylor', 'Operations Manager', 'Robert ensures all systems run smoothly and maintains our high availability standards.', 1),
('operation', 'Jennifer Martinez', 'Support Lead', 'Jennifer leads our support team and ensures users get timely assistance with their queries.', 2),
('operation', 'William Brown', 'Infrastructure Engineer', 'William manages our cloud infrastructure and ensures optimal performance.', 3);
