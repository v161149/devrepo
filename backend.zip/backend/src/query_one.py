import sqlite3

import os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DB = os.path.join(ROOT, 'database', 'SLA_MANAGEMENT_DB.db')
conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.execute("SELECT BUSINESS_NAME FROM SLA_DATABASE_TABLE_COLUMN_DETAILS WHERE TABLE_ID=1 AND COLUMN_NAME=?", ('product_name',))
print(cur.fetchone())
conn.close()
