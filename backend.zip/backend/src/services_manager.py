import subprocess
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = PROJECT_ROOT / "scripts"

# Define the paths to your three batch files
bat_data_management_svc = SCRIPTS_DIR / "start_data_management_svc.bat"
bat_schedule_gen_svc = SCRIPTS_DIR / "start_schedule_generation_svc.bat"
bat_data_archiving_svc = SCRIPTS_DIR / "start_data_archiving_svc.bat"

# Start each batch file as a separate, non-blocking subprocess
print("Starting data management service in the background...")
process_1 = subprocess.Popen(bat_data_management_svc, shell=True)

print("Starting schedule generation service in the background...")
process_2 = subprocess.Popen(bat_schedule_gen_svc, shell=True)

print("Starting data archiving service in the background...")
process_3 = subprocess.Popen(bat_data_archiving_svc, shell=True)

# The main Python script continues immediately after starting the sub-processes.
print("All batch files have been launched as background sub-processes.")
print("The main Python script will continue running, or exit.")