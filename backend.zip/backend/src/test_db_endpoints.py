import os, sys, json
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from data_management_service import app

client = app.test_client()

# Get current database details
resp = client.get('/api/database-details')
print('GET /api/database-details status:', resp.status_code)
data = resp.get_json()
print('Databases count:', len(data.get('data', [])))
if not data.get('data'):
    print('No databases found')
    sys.exit(1)

db = data['data'][0]
print('Before update:', db)

# Update database business fields
db_id = db['DATABASE_ID']
upd = {'BUSINESS_NAME': 'Inventory Business', 'BUSINESS_DESCRIPTION': 'Description of inventory DB'}
resp = client.put(f'/api/database-details/{db_id}', json=upd)
print('PUT db status:', resp.status_code, resp.get_json())

# Update first table's business fields
table = db['tables'][0]
table_id = table['TABLE_ID']
t_upd = {'BUSINESS_NAME': 'Products Biz', 'BUSINESS_DESCRIPTION': 'Products description'}
resp = client.put(f'/api/database-details/tables/{table_id}', json=t_upd)
print('PUT table status:', resp.status_code, resp.get_json())

# Update columns for that table
cols_payload = []
for c in table['columns']:
    cols_payload.append({'COLUMN_NAME': c['COLUMN_NAME'], 'BUSINESS_NAME': 'ColBiz', 'BUSINESS_DESCRIPTION': 'ColDesc', 'CLASSIFICATION': 'Internal'})
resp = client.put(f'/api/database-details/tables/{table_id}/columns', json={'columns': cols_payload})
print('PUT cols status:', resp.status_code, resp.get_json())

# Fetch again and print changes
resp = client.get('/api/database-details')
print('After update GET status:', resp.status_code)
print(json.dumps(resp.get_json(), indent=2))
