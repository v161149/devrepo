from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
import sqlite3
import os
from pathlib import Path
from datetime import datetime
import datetime as _dt
import json
import io
import csv
import sys
import subprocess
import importlib

app = Flask(__name__)
CORS(app)

DATABASE_NAME = "SLA_MANAGEMENT_DB"
CURRENT_PATH = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_PATH.parent.parent.parent
DATABASE_DIR = PROJECT_ROOT / "database"
DB_PATH = str(DATABASE_DIR / f"{DATABASE_NAME}.db")

def get_db_connection():
    """Get database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def check_database():
    """Verify database exists."""
    if not os.path.exists(DB_PATH):
        return False, "Database not found at " + DB_PATH
    return True, "Database found"


# ==================== ASSETS ENDPOINTS ====================

@app.route('/api/assets', methods=['GET'])
def get_assets():
    """Retrieve all assets."""
    try:
        exists, msg = check_database()
        if not exists:
            return jsonify({"error": msg}), 404

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ASSETS")
        rows = cursor.fetchall()
        conn.close()

        assets = [dict(row) for row in rows]
        return jsonify({"status": "success", "data": assets}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/assets', methods=['POST'])
def create_asset():
    """Create a new asset."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO ASSETS (ASSET_NAME, AIT_NUMBER, STATUS) VALUES (?, ?, ?)",
            (data.get('ASSET_NAME'), data.get('AIT_NUMBER'), data.get('STATUS'))
        )
        conn.commit()
        asset_id = cursor.lastrowid
        conn.close()

        return jsonify({"status": "success", "ASSET_ID": asset_id}), 201
    except sqlite3.IntegrityError as e:
        return jsonify({"error": "Asset name must be unique"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/assets/<int:asset_id>', methods=['PUT'])
def update_asset(asset_id):
    """Update an asset."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE ASSETS SET ASSET_NAME=?, AIT_NUMBER=?, STATUS=? WHERE ASSET_ID=?",
            (data.get('ASSET_NAME'), data.get('AIT_NUMBER'), data.get('STATUS'), asset_id)
        )
        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": "Asset updated"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/assets/<int:asset_id>', methods=['DELETE'])
def delete_asset(asset_id):
    """Delete an asset."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM ASSETS WHERE ASSET_ID=?", (asset_id,))
        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": "Asset deleted"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== SLAS ENDPOINTS ====================

@app.route('/api/slas', methods=['GET'])
def get_slas():
    """Retrieve all scheduled SLAs."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM SCHEDULED_SLAS")
        rows = cursor.fetchall()
        conn.close()

        slas = [dict(row) for row in rows]
        return jsonify({"status": "success", "data": slas}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/slas', methods=['POST'])
def create_sla():
    """Create a new SLA."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """INSERT INTO SCHEDULED_SLAS 
               (ASSET_ID, SLA_NAME, SLA_TYPE, TIME_ZONE, FIRST_EXECUTION_DATE, 
                EXPECTED_START_TIME, EXPECTED_END_TIME, FREQUENCY, DEPENDENT_SLAS, DEPENDENT_JOBS)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (data.get('ASSET_ID'), data.get('SLA_NAME'), data.get('SLA_TYPE'),
             data.get('TIME_ZONE'), data.get('FIRST_EXECUTION_DATE'),
             data.get('EXPECTED_START_TIME'), data.get('EXPECTED_END_TIME'),
             data.get('FREQUENCY'), data.get('DEPENDENT_SLAS'), data.get('DEPENDENT_JOBS'))
        )
        conn.commit()
        sla_id = cursor.lastrowid
        conn.close()

        return jsonify({"status": "success", "SLA_ID": sla_id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/slas/<int:sla_id>', methods=['PUT'])
def update_sla(sla_id):
    """Update an SLA."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """UPDATE SCHEDULED_SLAS 
               SET SLA_NAME=?, SLA_TYPE=?, TIME_ZONE=?, FIRST_EXECUTION_DATE=?,
                   EXPECTED_START_TIME=?, EXPECTED_END_TIME=?, FREQUENCY=?,
                   DEPENDENT_SLAS=?, DEPENDENT_JOBS=?
               WHERE SLA_ID=?""",
            (data.get('SLA_NAME'), data.get('SLA_TYPE'), data.get('TIME_ZONE'),
             data.get('FIRST_EXECUTION_DATE'), data.get('EXPECTED_START_TIME'),
             data.get('EXPECTED_END_TIME'), data.get('FREQUENCY'),
             data.get('DEPENDENT_SLAS'), data.get('DEPENDENT_JOBS'), sla_id)
        )
        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": "SLA updated"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== JOBS ENDPOINTS ====================

@app.route('/api/jobs', methods=['GET'])
def get_jobs():
    """Retrieve all scheduled jobs."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Join jobs with SLAs and ASSETS to provide readable names
        cursor.execute(
            """
            SELECT j.*, s.SLA_NAME, a.ASSET_NAME
            FROM SCHEDULED_JOBS j
            LEFT JOIN SCHEDULED_SLAS s ON j.SLA_ID = s.SLA_ID
            LEFT JOIN ASSETS a ON s.ASSET_ID = a.ASSET_ID
            """
        )
        rows = cursor.fetchall()
        conn.close()

        jobs = []
        for row in rows:
            r = dict(row)
            # include friendly keys
            r['SLA_NAME'] = r.get('SLA_NAME')
            r['Asset Name'] = r.get('ASSET_NAME')
            jobs.append(r)
        return jsonify({"status": "success", "data": jobs}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/jobs', methods=['POST'])
def create_job():
    """Create a new job."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """INSERT INTO SCHEDULED_JOBS 
               (SLA_ID, JOB_NAME, JOB_TYPE, TIME_ZONE, FIRST_EXECUTION_DATE,
                EXPECTED_START_TIME, EXPECTED_END_TIME, FREQUENCY, DEPENDENT_JOBS)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (data.get('SLA_ID'), data.get('JOB_NAME'), data.get('JOB_TYPE'),
             data.get('TIME_ZONE'), data.get('FIRST_EXECUTION_DATE'),
             data.get('EXPECTED_START_TIME'), data.get('EXPECTED_END_TIME'),
             data.get('FREQUENCY'), data.get('DEPENDENT_JOBS'))
        )
        conn.commit()
        job_id = cursor.lastrowid
        conn.close()

        return jsonify({"status": "success", "JOB_ID": job_id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/jobs/<int:job_id>', methods=['PUT'])
def update_job(job_id):
    """Update a job."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """UPDATE SCHEDULED_JOBS 
               SET JOB_NAME=?, JOB_TYPE=?, TIME_ZONE=?, FIRST_EXECUTION_DATE=?,
                   EXPECTED_START_TIME=?, EXPECTED_END_TIME=?, FREQUENCY=?,
                   DEPENDENT_JOBS=?
               WHERE JOB_ID=?""",
            (data.get('JOB_NAME'), data.get('JOB_TYPE'), data.get('TIME_ZONE'),
             data.get('FIRST_EXECUTION_DATE'), data.get('EXPECTED_START_TIME'),
             data.get('EXPECTED_END_TIME'), data.get('FREQUENCY'),
             data.get('DEPENDENT_JOBS'), job_id)
        )
        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": "Job updated"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== DATABASE DETAILS ENDPOINTS ====================

@app.route('/api/database-details', methods=['GET'])
def get_database_details():
    """Retrieve all database details."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT A.ASSET_NAME, A.AIT_NUMBER, B.* FROM ASSETS A, SLA_DATABASE_DETAILS B WHERE A.ASSET_ID=B.ASSET_ID")
        databases = cursor.fetchall()

        result = []
        for db in databases:
            db_dict = dict(db)
            cursor.execute(
                "SELECT * FROM SLA_DATABASE_TABLE_DETAILS WHERE DATABASE_ID=?",
                (db['DATABASE_ID'],)
            )
            tables = cursor.fetchall()
            db_dict['tables'] = []

            for table in tables:
                table_dict = dict(table)
                cursor.execute(
                    "SELECT * FROM SLA_DATABASE_TABLE_COLUMN_DETAILS WHERE TABLE_ID=?",
                    (table['TABLE_ID'],)
                )
                columns = cursor.fetchall()
                table_dict['columns'] = [dict(col) for col in columns]
                db_dict['tables'].append(table_dict)

            result.append(db_dict)

        conn.close()
        return jsonify({"status": "success", "data": result}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/database-details', methods=['POST'])
def create_database_details():
    """Create database details with tables and columns."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert database
        cursor.execute(
            """INSERT INTO SLA_DATABASE_DETAILS 
               (ASSET_ID, DATABASE_NAME, BUSINESS_NAME, BUSINESS_DESCRIPTION)
               VALUES (?, ?, ?, ?)""",
            (data.get('ASSET_ID'), data.get('DATABASE_NAME'),
             data.get('BUSINESS_NAME'), data.get('BUSINESS_DESCRIPTION'))
        )
        database_id = cursor.lastrowid

        # Insert tables and columns
        for table in data.get('tables', []):
            cursor.execute(
                """INSERT INTO SLA_DATABASE_TABLE_DETAILS
                   (DATABASE_ID, TABLE_NAME, BUSINESS_NAME, BUSINESS_DESCRIPTION)
                   VALUES (?, ?, ?, ?)""",
                (database_id, table.get('TABLE_NAME'),
                 table.get('BUSINESS_NAME'), table.get('BUSINESS_DESCRIPTION'))
            )
            table_id = cursor.lastrowid

            for column in table.get('columns', []):
                cursor.execute(
                    """INSERT INTO SLA_DATABASE_TABLE_COLUMN_DETAILS
                       (TABLE_ID, COLUMN_NAME, DATA_TYPE, BUSINESS_NAME, BUSINESS_DESCRIPTION, CLASSIFICATION)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (table_id, column.get('COLUMN_NAME'), column.get('DATA_TYPE'),
                     column.get('BUSINESS_NAME'), column.get('BUSINESS_DESCRIPTION'),
                     column.get('CLASSIFICATION'))
                )

        conn.commit()
        conn.close()

        return jsonify({"status": "success", "DATABASE_ID": database_id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/database-details/<int:database_id>', methods=['PUT'])
def update_database_details(database_id):
    """Update database-level business fields."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE SLA_DATABASE_DETAILS SET BUSINESS_NAME=?, BUSINESS_DESCRIPTION=? WHERE DATABASE_ID=?",
            (data.get('BUSINESS_NAME'), data.get('BUSINESS_DESCRIPTION'), database_id)
        )
        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": "Database updated"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/database-details/tables/<int:table_id>', methods=['PUT'])
def update_table_details(table_id):
    """Update table-level business fields."""
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE SLA_DATABASE_TABLE_DETAILS SET BUSINESS_NAME=?, BUSINESS_DESCRIPTION=? WHERE TABLE_ID=?",
            (data.get('BUSINESS_NAME'), data.get('BUSINESS_DESCRIPTION'), table_id)
        )
        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": "Table updated"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/database-details/tables/<int:table_id>/columns', methods=['PUT'])
def update_table_columns(table_id):
    """Update multiple column metadata rows for a table.

    Expects payload: { "columns": [ { "COLUMN_NAME": "col", "BUSINESS_NAME": "..", "BUSINESS_DESCRIPTION": "..", "CLASSIFICATION": ".." }, ... ] }
    Matching is done by TABLE_ID and COLUMN_NAME.
    """
    try:
        data = request.get_json()
        cols = data.get('columns', [])
        conn = get_db_connection()
        cursor = conn.cursor()

        for c in cols:
            col_name = c.get('COLUMN_NAME')
            if not col_name:
                continue
            cursor.execute(
                "UPDATE SLA_DATABASE_TABLE_COLUMN_DETAILS SET BUSINESS_NAME=?, BUSINESS_DESCRIPTION=?, CLASSIFICATION=? WHERE TABLE_ID=? AND COLUMN_NAME=?",
                (c.get('BUSINESS_NAME'), c.get('BUSINESS_DESCRIPTION'), c.get('CLASSIFICATION'), table_id, col_name)
            )

        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": f"Updated {len(cols)} columns"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== MONITORING ENDPOINTS ====================

@app.route('/api/slas-monitor-log', methods=['GET'])
def get_slas_monitor_log():
    """Retrieve all SLA monitoring logs."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM SLAS_MONITOR_LOG ORDER BY EXECUTION_DATE DESC")
        rows = cursor.fetchall()
        conn.close()

        logs = [dict(row) for row in rows]
        return jsonify({"status": "success", "data": logs}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/jobs-monitor-log', methods=['GET'])
def get_jobs_monitor_log():
    """Retrieve all jobs monitoring logs."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM JOBS_MONITOR_LOG ORDER BY EXECUTION_DATE DESC")
        rows = cursor.fetchall()
        conn.close()

        logs = [dict(row) for row in rows]
        return jsonify({"status": "success", "data": logs}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== HISTORY ENDPOINTS ====================

@app.route('/api/slas-deliveries-history', methods=['GET'])
def get_slas_deliveries_history():
    """Retrieve SLA delivery history."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM SLAS_DELIVERIES_HISTORY ORDER BY EXECUTION_DATE DESC")
        rows = cursor.fetchall()
        conn.close()

        history = [dict(row) for row in rows]
        return jsonify({"status": "success", "data": history}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/jobs-deliveries-history', methods=['GET'])
def get_jobs_deliveries_history():
    """Retrieve jobs delivery history."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM JOBS_DELIVERIES_HISTORY ORDER BY EXECUTION_DATE DESC")
        rows = cursor.fetchall()
        conn.close()

        history = [dict(row) for row in rows]
        return jsonify({"status": "success", "data": history}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== BULK UPLOAD ENDPOINTS ====================

@app.route('/api/bulk-upload/assets', methods=['POST'])
def bulk_upload_assets():
    """Bulk upload assets from spreadsheet."""
    try:
        data = request.get_json()
        assets_data = data.get('assets', [])
        conn = get_db_connection()
        cursor = conn.cursor()

        for asset in assets_data:
            app.logger.info(f"Inserting asset: {asset}")
            cursor.execute(
                "INSERT OR IGNORE INTO ASSETS (ASSET_NAME, AIT_NUMBER, STATUS) VALUES (?, ?, ?)",
                (asset.get('ASSET_NAME'), asset.get('AIT_NUMBER'), asset.get('STATUS'))
            )

        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": f"Uploaded {len(assets_data)} assets"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/bulk-upload/slas', methods=['POST'])
def bulk_upload_slas():
    """Bulk upload SLAs from spreadsheet."""
    try:
        data = request.get_json()
        slas_data = data.get('slas', [])
        conn = get_db_connection()
        cursor = conn.cursor()

        for sla in slas_data:
            # Get ASSET_ID from ASSET_NAME (auto-create asset if missing)
            cursor.execute("SELECT ASSET_ID FROM ASSETS WHERE ASSET_NAME=?", (sla.get('ASSET_NAME'),))
            asset_row = cursor.fetchone()
            if not asset_row:
                app.logger.info(f"Asset '{sla.get('ASSET_NAME')}' not found - creating new asset")
                cursor.execute(
                    "INSERT INTO ASSETS (ASSET_NAME, AIT_NUMBER, STATUS) VALUES (?, ?, ?)",
                    (sla.get('ASSET_NAME'), sla.get('AIT_NUMBER') or '', sla.get('STATUS') or 'Active')
                )
                asset_id = cursor.lastrowid
            else:
                asset_id = asset_row['ASSET_ID']
            app.logger.info(f"Using ASSET_ID={asset_id} for SLA '{sla.get('SLA_NAME')}'")
            cursor.execute(
                """INSERT INTO SCHEDULED_SLAS 
                   (ASSET_ID, SLA_NAME, SLA_TYPE, TIME_ZONE, FIRST_EXECUTION_DATE,
                    EXPECTED_START_TIME, EXPECTED_END_TIME, FREQUENCY, DEPENDENT_SLAS, DEPENDENT_JOBS)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (asset_id, sla.get('SLA_NAME'), sla.get('SLA_TYPE'), sla.get('TIME_ZONE'),
                 sla.get('FIRST_EXECUTION_DATE'), sla.get('EXPECTED_START_TIME'),
                 sla.get('EXPECTED_END_TIME'), sla.get('FREQUENCY'),
                 sla.get('DEPENDENT_SLAS'), sla.get('DEPENDENT_JOBS'))
            )

        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": f"Uploaded {len(slas_data)} SLAs"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/bulk-upload/jobs', methods=['POST'])
def bulk_upload_jobs():
    """Bulk upload jobs from spreadsheet."""
    try:
        data = request.get_json()
        jobs_data = data.get('jobs', [])
        conn = get_db_connection()
        cursor = conn.cursor()

        for job in jobs_data:
            app.logger.info(f"Processing job row: {job}")
            # Get SLA_ID from SLA_NAME
            cursor.execute("SELECT SLA_ID, ASSET_ID FROM SCHEDULED_SLAS WHERE SLA_NAME=?", (job.get('SLA_NAME'),))
            sla_row = cursor.fetchone()
            if not sla_row:
                app.logger.info(f"SLA '{job.get('SLA_NAME')}' not found - skipping job")
                continue

            sla_id = sla_row['SLA_ID']
            sla_asset_id = sla_row['ASSET_ID']
            cursor.execute(
                """INSERT INTO SCHEDULED_JOBS 
                   (SLA_ID, JOB_NAME, JOB_TYPE, TIME_ZONE, FIRST_EXECUTION_DATE,
                    EXPECTED_START_TIME, EXPECTED_END_TIME, FREQUENCY, DEPENDENT_JOBS)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (sla_id, job.get('JOB_NAME'), job.get('JOB_TYPE'), job.get('TIME_ZONE'),
                 job.get('FIRST_EXECUTION_DATE'), job.get('EXPECTED_START_TIME'),
                 job.get('EXPECTED_END_TIME'), job.get('FREQUENCY'), job.get('DEPENDENT_JOBS'))
            )

        conn.commit()
        conn.close()

        return jsonify({"status": "success", "message": f"Uploaded {len(jobs_data)} jobs"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ==================== SERVER-SIDE FILE UPLOAD PARSING ====================
ALLOWED_EXTENSIONS = {'.xlsx', '.xls', '.csv'}

def allowed_file(filename):
    _, ext = os.path.splitext(filename.lower())
    return ext in ALLOWED_EXTENSIONS


def normalize_row(row):
    """Normalize header keys to backend column names: 'Asset Name' -> 'ASSET_NAME'"""
    new = {}
    for k, v in row.items():
        if k is None:
            continue
        new_key = k.replace(' ', '_').replace('.', '').replace('-', '_').upper()
        # Convert datetime/date/time to ISO strings for DB insertion
        if isinstance(v, (_dt.datetime, _dt.date, _dt.time)):
            try:
                v = v.isoformat()
            except Exception:
                v = str(v)
        elif v is None:
            v = ''
        else:
            v = str(v)
        new[new_key] = v
    return new


@app.route('/api/upload-spreadsheet', methods=['POST'])
def upload_spreadsheet():
    """Accepts a multipart file upload and parses Assets/SLAs/Jobs sheets server-side."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        filename = secure_filename(file.filename)
        if not allowed_file(filename):
            return jsonify({'error': 'Unsupported file type'}), 400

        _, ext = os.path.splitext(filename.lower())

        parsed = {}

        if ext in ('.xlsx', '.xls'):
            # Dynamically import openpyxl; if missing try to pip install into current interpreter
            try:
                openpyxl = importlib.import_module('openpyxl')
            except Exception:
                app.logger.info('openpyxl not found, attempting to install...')
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'openpyxl'])
                importlib.invalidate_caches()
                openpyxl = importlib.import_module('openpyxl')

            in_mem = io.BytesIO(file.read())
            wb = openpyxl.load_workbook(in_mem, data_only=True)
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = list(ws.values)
                if not rows:
                    continue
                headers = rows[0]
                data_rows = rows[1:]
                objs = []
                for r in data_rows:
                    row_obj = {headers[i]: r[i] for i in range(len(headers)) if i < len(r)}
                    objs.append(normalize_row(row_obj))
                parsed[sheet_name.lower()] = objs
        elif ext == '.csv':
            text = file.stream.read().decode('utf-8')
            reader = csv.DictReader(io.StringIO(text))
            objs = [normalize_row(r) for r in reader]
            parsed['csv'] = objs

    # Now persist using existing bulk endpoints logic (in-process)
        conn = get_db_connection()
        cursor = conn.cursor()

        # Assets
        assets = parsed.get('assets') or parsed.get('asset') or []
        for a in assets:
            cursor.execute("INSERT OR IGNORE INTO ASSETS (ASSET_NAME, AIT_NUMBER, STATUS) VALUES (?, ?, ?)",
                           (a.get('ASSET_NAME'), a.get('AIT_NUMBER'), a.get('STATUS')))

        # SLAs
        slas = parsed.get('slas') or parsed.get('sla') or []
        for s in slas:
            # ensure asset exists
            cursor.execute("SELECT ASSET_ID FROM ASSETS WHERE ASSET_NAME=?", (s.get('ASSET_NAME'),))
            row = cursor.fetchone()
            if not row:
                cursor.execute("INSERT INTO ASSETS (ASSET_NAME, AIT_NUMBER, STATUS) VALUES (?, ?, ?)",
                               (s.get('ASSET_NAME'), s.get('AIT_NUMBER') or '', s.get('STATUS') or 'Active'))
                asset_id = cursor.lastrowid
            else:
                asset_id = row['ASSET_ID']

            cursor.execute(
                "INSERT INTO SCHEDULED_SLAS (ASSET_ID, SLA_NAME, SLA_TYPE, TIME_ZONE, FIRST_EXECUTION_DATE, EXPECTED_START_TIME, EXPECTED_END_TIME, FREQUENCY, DEPENDENT_SLAS, DEPENDENT_JOBS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (asset_id, s.get('SLA_NAME'), s.get('SLA_TYPE'), s.get('TIME_ZONE'), s.get('FIRST_EXECUTION_DATE'), s.get('EXPECTED_START_TIME'), s.get('EXPECTED_END_TIME'), s.get('FREQUENCY'), s.get('DEPENDENT_SLAS'), s.get('DEPENDENT_JOBS'))
            )

        # Jobs
        jobs = parsed.get('jobs') or []
        for j in jobs:
            cursor.execute("SELECT SLA_ID FROM SCHEDULED_SLAS WHERE SLA_NAME=?", (j.get('SLA_NAME'),))
            r = cursor.fetchone()
            if not r:
                # skip jobs without known SLA
                continue
            sla_id = r['SLA_ID']
            cursor.execute(
                "INSERT INTO SCHEDULED_JOBS (SLA_ID, JOB_NAME, JOB_TYPE, TIME_ZONE, FIRST_EXECUTION_DATE, EXPECTED_START_TIME, EXPECTED_END_TIME, FREQUENCY, DEPENDENT_JOBS) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (sla_id, j.get('JOB_NAME'), j.get('JOB_TYPE'), j.get('TIME_ZONE'), j.get('FIRST_EXECUTION_DATE'), j.get('EXPECTED_START_TIME'), j.get('EXPECTED_END_TIME'), j.get('FREQUENCY'), j.get('DEPENDENT_JOBS'))
            )
        # Database Details sheet (if present) - parse and persist into SLA_DATABASE_* tables
        # The sheet headers are normalized by normalize_row to uppercase keys with underscores
        db_sheet = None
        for key in parsed.keys():
            kl = (key or '').lower()
            if 'database' in kl and 'detail' in kl:
                db_sheet = parsed.get(key)
                break

        if db_sheet:
            # Aggregate by DATABASE_NAME -> TABLE_NAME -> COLUMNS
            databases = {}
            for r in db_sheet:
                # ensure asset exists
                cursor.execute("SELECT ASSET_ID FROM ASSETS WHERE ASSET_NAME=?", (r.get('ASSET_NAME'),))
                row = cursor.fetchone()
                asset_id = row['ASSET_ID']

                db_name = (r.get('DATABASE_NAME') or '').strip()
                db_bname = (r.get('DATABASE_BUSINESS_NAME') or '').strip()
                db_bdesc = (r.get('DATABASE_BUSINESS_DESCRIPTION') or '').strip()
                table_name = (r.get('TABLE_NAME') or '').strip()
                table_bname = (r.get('TABLE_BUSINESS_NAME') or '').strip()
                table_bdesc = (r.get('TABLE_BUSINESS_DESCRIPTION') or '').strip()
                column_name = (r.get('TABLE_COLUMN_NAME') or r.get('COLUMN_NAME') or r.get('COLUMN') or '').strip()
                data_type = (r.get('COLUMN_DATA_TYPE') or r.get('DATA_TYPE') or '').strip()
                classification = (r.get('CLASSIFICATION') or '').strip()
                col_bname = (r.get('COLUMN_BUSINESS_NAME') or r.get('COLUMN_BUSINESS') or '').strip()
                col_bdesc = (r.get('COLUMN_BUSINESS_DESCRIPTION') or r.get('COLUMN_BUSINESS_DESC') or '').strip()

                if not db_name:
                    # skip rows without a database name
                    continue

                db = databases.setdefault(db_name, {
                    'BUSINESS_NAME': db_bname,
                    'BUSINESS_DESCRIPTION': db_bdesc,
                    'tables': {}
                })

                if table_name:
                    t = db['tables'].setdefault(table_name, {
                        'BUSINESS_NAME': table_bname,
                        'BUSINESS_DESCRIPTION': table_bdesc,
                        'columns': []
                    })

                    if column_name:
                        t['columns'].append({
                            'COLUMN_NAME': column_name,
                            'DATA_TYPE': data_type,
                            'CLASSIFICATION': classification,
                            'BUSINESS_NAME': col_bname,
                            'BUSINESS_DESCRIPTION': col_bdesc
                        })

            # Persist aggregated structure into DB
            for db_name, db_obj in databases.items():
                # try find existing database by name and asset
                cursor.execute("SELECT DATABASE_ID FROM SLA_DATABASE_DETAILS WHERE DATABASE_NAME=? AND ASSET_ID=?", (db_name, asset_id))
                existing_db = cursor.fetchone()
                if existing_db:
                    database_id = existing_db['DATABASE_ID']
                    # optionally update business fields if provided
                    cursor.execute("UPDATE SLA_DATABASE_DETAILS SET BUSINESS_NAME=?, BUSINESS_DESCRIPTION=? WHERE DATABASE_ID=?",
                                   (db_obj.get('BUSINESS_NAME') or None, db_obj.get('BUSINESS_DESCRIPTION') or None, database_id))
                else:
                    cursor.execute(
                        "INSERT INTO SLA_DATABASE_DETAILS (ASSET_ID, DATABASE_NAME, BUSINESS_NAME, BUSINESS_DESCRIPTION) VALUES (?, ?, ?, ?)",
                        (asset_id, db_name, db_obj.get('BUSINESS_NAME') or None, db_obj.get('BUSINESS_DESCRIPTION') or None)
                    )
                    database_id = cursor.lastrowid

                # Tables
                for table_name, table_obj in db_obj['tables'].items():
                    cursor.execute("SELECT TABLE_ID FROM SLA_DATABASE_TABLE_DETAILS WHERE DATABASE_ID=? AND TABLE_NAME=?", (database_id, table_name))
                    existing_table = cursor.fetchone()
                    if existing_table:
                        table_id = existing_table['TABLE_ID']
                        cursor.execute("UPDATE SLA_DATABASE_TABLE_DETAILS SET BUSINESS_NAME=?, BUSINESS_DESCRIPTION=? WHERE TABLE_ID=?",
                                       (table_obj.get('BUSINESS_NAME') or None, table_obj.get('BUSINESS_DESCRIPTION') or None, table_id))
                    else:
                        cursor.execute(
                            "INSERT INTO SLA_DATABASE_TABLE_DETAILS (DATABASE_ID, TABLE_NAME, BUSINESS_NAME, BUSINESS_DESCRIPTION) VALUES (?, ?, ?, ?)",
                            (database_id, table_name, table_obj.get('BUSINESS_NAME') or None, table_obj.get('BUSINESS_DESCRIPTION') or None)
                        )
                        table_id = cursor.lastrowid

                    # Columns
                    for col in table_obj.get('columns', []):
                        # Use TABLE_ID + COLUMN_NAME to check existence
                        cursor.execute("SELECT ROWID FROM SLA_DATABASE_TABLE_COLUMN_DETAILS WHERE TABLE_ID=? AND COLUMN_NAME=?", (table_id, col.get('COLUMN_NAME')))
                        existing_col = cursor.fetchone()
                        if existing_col:
                            # update existing column metadata
                            cursor.execute(
                                "UPDATE SLA_DATABASE_TABLE_COLUMN_DETAILS SET DATA_TYPE=?, BUSINESS_NAME=?, BUSINESS_DESCRIPTION=?, CLASSIFICATION=? WHERE TABLE_ID=? AND COLUMN_NAME=?",
                                (col.get('DATA_TYPE') or None, col.get('BUSINESS_NAME') or None, col.get('BUSINESS_DESCRIPTION') or None, col.get('CLASSIFICATION') or None, table_id, col.get('COLUMN_NAME'))
                            )
                        else:
                            cursor.execute(
                                "INSERT INTO SLA_DATABASE_TABLE_COLUMN_DETAILS (TABLE_ID, COLUMN_NAME, DATA_TYPE, BUSINESS_NAME, BUSINESS_DESCRIPTION, CLASSIFICATION) VALUES (?, ?, ?, ?, ?, ?)",
                                (table_id, col.get('COLUMN_NAME'), col.get('DATA_TYPE'), col.get('BUSINESS_NAME'), col.get('BUSINESS_DESCRIPTION'), col.get('CLASSIFICATION'))
                            )

        conn.commit()
        conn.close()

        return jsonify({'status': 'success', 'message': 'File parsed and data persisted', 'parsed_summary': { 'assets': len(assets), 'slas': len(slas), 'jobs': len(jobs) }}), 201
    except Exception as e:
        app.logger.exception('Error processing uploaded spreadsheet')
        return jsonify({'error': str(e)}), 500


# ==================== HEALTH CHECK ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Check service health and database connectivity."""
    try:
        exists, msg = check_database()
        if not exists:
            return jsonify({"status": "error", "message": msg}), 503

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as table_count FROM sqlite_master WHERE type='table'")
        result = cursor.fetchone()
        conn.close()

        return jsonify({
            "status": "healthy",
            "database": "connected",
            "tables": result['table_count'],
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 503


# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500


if __name__ == '__main__':
    # Verify database exists before starting
    exists, msg = check_database()
    if not exists:
        print(f"WARNING: {msg}")
        print("Please run create_database.py first.")
    else:
        print(f"Database connected: {DB_PATH}")
    # Run without the debug reloader so the process stays stable for automated tests
    port = int(os.environ.get('PORT', '5000'))
    host = os.environ.get('HOST', '127.0.0.1')
    print(f"Starting server on {host}:{port}")
    app.run(host=host, port=port, debug=False)