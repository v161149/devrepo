import os
import sys
# Ensure project root is on path
proj_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, proj_root)

from data_management_service import app

client = app.test_client()

file_path = os.path.abspath(os.path.join(proj_root, '..', 'sla_onboarding.xlsx'))
if not os.path.exists(file_path):
    file_path = os.path.abspath(os.path.join(proj_root, 'sla_onboarding.xlsx'))

print('Using file:', file_path)

with open(file_path, 'rb') as f:
    data = {
        'file': (f, os.path.basename(file_path))
    }
    resp = client.post('/api/upload-spreadsheet', data=data, content_type='multipart/form-data')
    print('Status code:', resp.status_code)
    try:
        print('JSON:', resp.get_json())
    except Exception:
        print('Response data:', resp.data)
