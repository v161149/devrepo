import sqlite3
import os
import time
import logging
from pathlib import Path
from datetime import datetime, timedelta
import schedule
from flask import Flask, jsonify

app = Flask(__name__)

DATABASE_NAME = "SLA_MANAGEMENT_DB"
CURRENT_PATH = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_PATH.parent.parent.parent
DATABASE_DIR = PROJECT_ROOT / "database"
DB_PATH = str(DATABASE_DIR / f"{DATABASE_NAME}.db")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('data_archiving_service.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def get_db_connection():
    """Get database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def check_database():
    """Verify database exists."""
    if not os.path.exists(DB_PATH):
        return False, "Database not found at " + DB_PATH
    return True, "Database found"


def archive_slas_monitor_log():
    """
    Archive today's SLA monitoring data from SLAS_MONITOR_LOG to SLAS_DELIVERIES_HISTORY.
    This function is called at the end of each day.
    """
    try:
        logger.info("Starting SLA monitoring log archival process...")

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get today's date
        today = datetime.now().strftime('%Y-%m-%d')

        # Query today's data from SLAS_MONITOR_LOG
        cursor.execute("""
            SELECT 
                SLA_SRC_ID,
                SLA_NAME,
                SLA_TYPE,
                TIME_ZONE,
                FREQUENCY,
                EXPECTED_EXECUTION_DATE,
                EXPECTED_START_TIME,
                EXPECTED_END_TIME,
                EXECUTION_DATE,
                START_TIME,
                END_TIME,
                STATUS,
                DEPENDENT_SLAS,
                DEPENDENT_JOBS
            FROM SLAS_MONITOR_LOG
            WHERE DATE(EXECUTION_DATE) = ? OR EXECUTION_DATE IS NULL
        """, (today,))

        slas_to_archive = cursor.fetchall()

        if not slas_to_archive:
            logger.info(f"No SLA monitoring logs found for {today}. Nothing to archive.")
            conn.close()
            return 0

        # Insert into SLAS_DELIVERIES_HISTORY
        archived_count = 0
        for sla in slas_to_archive:
            cursor.execute("""
                INSERT INTO SLAS_DELIVERIES_HISTORY
                (SLA_SRC_ID, SLA_NAME, SLA_TYPE, TIME_ZONE, FREQUENCY,
                 EXPECTED_EXECUTION_DATE, EXPECTED_START_TIME, EXPECTED_END_TIME,
                 EXECUTION_DATE, START_TIME, END_TIME, STATUS, DEPENDENT_SLAS, DEPENDENT_JOBS)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                sla['SLA_SRC_ID'],
                sla['SLA_NAME'],
                sla['SLA_TYPE'],
                sla['TIME_ZONE'],
                sla['FREQUENCY'],
                sla['EXPECTED_EXECUTION_DATE'],
                sla['EXPECTED_START_TIME'],
                sla['EXPECTED_END_TIME'],
                sla['EXECUTION_DATE'],
                sla['START_TIME'],
                sla['END_TIME'],
                sla['STATUS'],
                sla['DEPENDENT_SLAS'],
                sla['DEPENDENT_JOBS']
            ))
            archived_count += 1

        conn.commit()

        # Delete archived records from SLAS_MONITOR_LOG
        cursor.execute("""
            DELETE FROM SLAS_MONITOR_LOG
            WHERE DATE(EXECUTION_DATE) = ? OR EXECUTION_DATE IS NULL
        """, (today,))

        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()

        logger.info(f"SLA archival completed: {archived_count} records archived, {deleted_count} records deleted from monitor log")
        return archived_count

    except Exception as e:
        logger.error(f"Error archiving SLA monitoring logs: {str(e)}")
        return 0


def archive_jobs_monitor_log():
    """
    Archive today's jobs monitoring data from JOBS_MONITOR_LOG to JOBS_DELIVERIES_HISTORY.
    This function is called at the end of each day.
    """
    try:
        logger.info("Starting jobs monitoring log archival process...")

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get today's date
        today = datetime.now().strftime('%Y-%m-%d')

        # Query today's data from JOBS_MONITOR_LOG
        cursor.execute("""
            SELECT 
                SLA_ID,
                SLA_SRC_ID,
                JOB_SRC_ID,
                JOB_NAME,
                JOB_TYPE,
                TIME_ZONE,
                FREQUENCY,
                EXPECTED_EXECUTION_DATE,
                EXPECTED_START_TIME,
                EXPECTED_END_TIME,
                EXECUTION_DATE,
                START_TIME,
                END_TIME,
                STATUS,
                DEPENDENT_JOBS
            FROM JOBS_MONITOR_LOG
            WHERE DATE(EXECUTION_DATE) = ? OR EXECUTION_DATE IS NULL
        """, (today,))

        jobs_to_archive = cursor.fetchall()

        if not jobs_to_archive:
            logger.info(f"No jobs monitoring logs found for {today}. Nothing to archive.")
            conn.close()
            return 0

        # Insert into JOBS_DELIVERIES_HISTORY
        archived_count = 0
        for job in jobs_to_archive:
            cursor.execute("""
                INSERT INTO JOBS_DELIVERIES_HISTORY
                (SLA_ID, SLA_SRC_ID, JOB_SRC_ID, JOB_NAME, JOB_TYPE, TIME_ZONE,
                 FREQUENCY, EXPECTED_EXECUTION_DATE, EXPECTED_START_TIME, EXPECTED_END_TIME,
                 EXECUTION_DATE, START_TIME, END_TIME, STATUS, DEPENDENT_JOBS)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                job['SLA_ID'],
                job['SLA_SRC_ID'],
                job['JOB_SRC_ID'],
                job['JOB_NAME'],
                job['JOB_TYPE'],
                job['TIME_ZONE'],
                job['FREQUENCY'],
                job['EXPECTED_EXECUTION_DATE'],
                job['EXPECTED_START_TIME'],
                job['EXPECTED_END_TIME'],
                job['EXECUTION_DATE'],
                job['START_TIME'],
                job['END_TIME'],
                job['STATUS'],
                job['DEPENDENT_JOBS']
            ))
            archived_count += 1

        conn.commit()

        # Delete archived records from JOBS_MONITOR_LOG
        cursor.execute("""
            DELETE FROM JOBS_MONITOR_LOG
            WHERE DATE(EXECUTION_DATE) = ? OR EXECUTION_DATE IS NULL
        """, (today,))

        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()

        logger.info(f"Jobs archival completed: {archived_count} records archived, {deleted_count} records deleted from monitor log")
        return archived_count

    except Exception as e:
        logger.error(f"Error archiving jobs monitoring logs: {str(e)}")
        return 0


def daily_archival_job():
    """
    Main daily archival job - called at end of day.
    Archives both SLA and jobs monitoring data.
    """
    logger.info("=" * 80)
    logger.info("DAILY ARCHIVAL JOB STARTED")
    logger.info("=" * 80)

    try:
        slas_archived = archive_slas_monitor_log()
        jobs_archived = archive_jobs_monitor_log()

        logger.info("=" * 80)
        logger.info(f"DAILY ARCHIVAL JOB COMPLETED - SLAs: {slas_archived}, Jobs: {jobs_archived}")
        logger.info("=" * 80)

    except Exception as e:
        logger.error(f"Critical error in daily archival job: {str(e)}")


def cleanup_old_history(days_to_keep=90):
    """
    Clean up old records from history tables.
    By default, keeps last 90 days of historical data.
    """
    try:
        logger.info(f"Starting cleanup of history records older than {days_to_keep} days...")

        conn = get_db_connection()
        cursor = conn.cursor()

        cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).strftime('%Y-%m-%d')

        # Delete old SLA history
        cursor.execute("""
            DELETE FROM SLAS_DELIVERIES_HISTORY
            WHERE DATE(EXECUTION_DATE) < ?
        """, (cutoff_date,))

        sla_deleted = cursor.rowcount

        # Delete old jobs history
        cursor.execute("""
            DELETE FROM JOBS_DELIVERIES_HISTORY
            WHERE DATE(EXECUTION_DATE) < ?
        """, (cutoff_date,))

        jobs_deleted = cursor.rowcount

        conn.commit()
        conn.close()

        logger.info(f"History cleanup completed: SLAs deleted: {sla_deleted}, Jobs deleted: {jobs_deleted}")

    except Exception as e:
        logger.error(f"Error cleaning up history: {str(e)}")


def schedule_jobs():
    """
    Schedule all archival and maintenance jobs.
    """
    # Schedule daily archival at 23:59 (11:59 PM)
    schedule.every().day.at("23:59").do(daily_archival_job)
    logger.info("Scheduled daily archival job at 23:59")

    # Schedule weekly cleanup every Sunday at 02:00 AM
    schedule.every().sunday.at("02:00").do(cleanup_old_history, days_to_keep=90)
    logger.info("Scheduled weekly cleanup job every Sunday at 02:00")

    # Optional: Run daily archival immediately at startup for testing
    # Uncomment below to enable
    # schedule.every().minute.do(daily_archival_job)


def run_scheduler():
    """
    Run the scheduler loop.
    """
    logger.info("Data Archiving Service started")

    while True:
        try:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
        except KeyboardInterrupt:
            logger.info("Data Archiving Service stopped by user")
            break
        except Exception as e:
            logger.error(f"Error in scheduler loop: {str(e)}")
            time.sleep(60)


# ==================== REST API ENDPOINTS ====================

@app.route('/api/archive/manual-slas', methods=['POST'])
def manual_archive_slas():
    """
    Manually trigger SLA archival (admin endpoint).
    """
    try:
        archived = archive_slas_monitor_log()
        return jsonify({
            "status": "success",
            "message": "Manual SLA archival completed",
            "records_archived": archived,
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/archive/manual-jobs', methods=['POST'])
def manual_archive_jobs():
    """
    Manually trigger jobs archival (admin endpoint).
    """
    try:
        archived = archive_jobs_monitor_log()
        return jsonify({
            "status": "success",
            "message": "Manual jobs archival completed",
            "records_archived": archived,
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/archive/cleanup', methods=['POST'])
def manual_cleanup():
    """
    Manually trigger history cleanup (admin endpoint).
    Query parameter: days_to_keep (default: 90)
    """
    try:
        days_to_keep = request.args.get('days_to_keep', 90, type=int)
        cleanup_old_history(days_to_keep)

        return jsonify({
            "status": "success",
            "message": f"Cleanup completed - keeping last {days_to_keep} days",
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/archive/status', methods=['GET'])
def get_archive_status():
    """
    Get archival and history database statistics.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get monitoring log counts
        cursor.execute("SELECT COUNT(*) as count FROM SLAS_MONITOR_LOG")
        sla_monitor_count = cursor.fetchone()['count']

        cursor.execute("SELECT COUNT(*) as count FROM JOBS_MONITOR_LOG")
        jobs_monitor_count = cursor.fetchone()['count']

        # Get history counts
        cursor.execute("SELECT COUNT(*) as count FROM SLAS_DELIVERIES_HISTORY")
        sla_history_count = cursor.fetchone()['count']

        cursor.execute("SELECT COUNT(*) as count FROM JOBS_DELIVERIES_HISTORY")
        jobs_history_count = cursor.fetchone()['count']

        # Get oldest and newest records in history
        cursor.execute("SELECT MIN(EXECUTION_DATE) as oldest, MAX(EXECUTION_DATE) as newest FROM SLAS_DELIVERIES_HISTORY")
        sla_history_range = cursor.fetchone()

        cursor.execute("SELECT MIN(EXECUTION_DATE) as oldest, MAX(EXECUTION_DATE) as newest FROM JOBS_DELIVERIES_HISTORY")
        jobs_history_range = cursor.fetchone()

        conn.close()

        return jsonify({
            "status": "success",
            "monitoring_logs": {
                "slas": sla_monitor_count,
                "jobs": jobs_monitor_count
            },
            "history_records": {
                "slas": sla_history_count,
                "jobs": jobs_history_count
            },
            "history_date_range": {
                "sla_history": {
                    "oldest": sla_history_range['oldest'],
                    "newest": sla_history_range['newest']
                },
                "jobs_history": {
                    "oldest": jobs_history_range['oldest'],
                    "newest": jobs_history_range['newest']
                }
            },
            "timestamp": datetime.now().isoformat()
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    """Check service health."""
    try:
        exists, msg = check_database()
        if not exists:
            return jsonify({"status": "error", "message": msg}), 503

        conn = get_db_connection()
        conn.close()

        return jsonify({
            "status": "healthy",
            "service": "data_archiving_service",
            "database": "connected",
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 503


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404


if __name__ == '__main__':
    exists, msg = check_database()
    if not exists:
        print(f"WARNING: {msg}")
        print("Please run create_database.py first.")
    else:
        print(f"Data Archiving Service - Database connected: {DB_PATH}")

    # Initialize scheduler
    schedule_jobs()

    # Run in two modes:
    # Mode 1: Background scheduler (production)
    # Uncomment below to run as background job:
    # run_scheduler()

    # Mode 2: REST API server + scheduler in separate thread (development)
    # Run scheduler in background thread
    import threading

    scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
    scheduler_thread.start()

    # Run Flask app on port 5002
    logger.info("Starting Flask REST API on port 5002")
    app.run(debug=False, port=5002)