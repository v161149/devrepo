import requests
import os

api_base = 'http://127.0.0.1:5001'
file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'frontend', 'onboarding.xlsx'))

with open(file_path, 'rb') as f:
    files = {'file': ('onboarding.xlsx', f, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
    resp = requests.post(api_base + '/api/upload-spreadsheet', files=files)
    print('Status:', resp.status_code)
    print(resp.text)
