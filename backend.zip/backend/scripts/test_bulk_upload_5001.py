import urllib.request
import json
import time

api_base = 'http://127.0.0.1:5001'

headers = {'Content-Type': 'application/json'}

assets_payload = {
    'assets': [
        {'ASSET_NAME': 'UT Asset', 'AIT_NUMBER': 'AIT-UT', 'STATUS': 'Active'}
    ]
}

slas_payload = {
    'slas': [
        {'ASSET_NAME': 'UT Asset', 'SLA_NAME': 'UT SLA', 'SLA_TYPE': 'TypeA', 'TIME_ZONE': 'UTC', 'FIRST_EXECUTION_DATE': '2025-10-21', 'EXPECTED_START_TIME': '09:00', 'EXPECTED_END_TIME': '10:00', 'FREQUENCY': 'Daily'}
    ]
}

jobs_payload = {
    'jobs': [
        {'SLA_NAME': 'UT SLA', 'JOB_NAME': 'UT Job', 'JOB_TYPE': 'Batch', 'TIME_ZONE': 'UTC', 'FIRST_EXECUTION_DATE': '2025-10-22', 'EXPECTED_START_TIME': '10:00', 'EXPECTED_END_TIME': '11:00', 'FREQUENCY': 'Daily'}
    ]
}


def post(path, payload):
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(api_base + path, data=data, headers=headers, method='POST')
    with urllib.request.urlopen(req) as resp:
        return resp.read().decode()


def get(path):
    with urllib.request.urlopen(api_base + path) as resp:
        return resp.read().decode()


if __name__ == '__main__':
    print('Waiting 1s for server...')
    time.sleep(1)
    try:
        print('POST /api/bulk-upload/assets ->', post('/api/bulk-upload/assets', assets_payload))
        print('POST /api/bulk-upload/slas ->', post('/api/bulk-upload/slas', slas_payload))
        print('POST /api/bulk-upload/jobs ->', post('/api/bulk-upload/jobs', jobs_payload))

        print('\nGET /api/assets ->')
        print(get('/api/assets'))
        print('\nGET /api/slas ->')
        print(get('/api/slas'))
        print('\nGET /api/jobs ->')
        print(get('/api/jobs'))
    except Exception as e:
        print('Error during test:', e)
