import requests
import subprocess
import time
import os
import signal
import sys

# Configuration
API_HOST = '127.0.0.1'
API_PORT = 5002
API_BASE = f'http://{API_HOST}:{API_PORT}'
SERVER_SCRIPT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src', 'data_management_service.py'))
UPLOAD_FILE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'frontend', 'onboarding.xlsx'))

def start_server():
    env = os.environ.copy()
    env['PORT'] = str(API_PORT)
    env['HOST'] = API_HOST
    print('Starting server...')
    proc = subprocess.Popen([sys.executable, SERVER_SCRIPT], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return proc


def wait_for_health(timeout=15):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get(API_BASE + '/api/health', timeout=2)
            if r.status_code == 200:
                print('Health check OK')
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def stop_server(proc):
    print('Stopping server...')
    try:
        proc.send_signal(signal.SIGINT)
        time.sleep(1)
        proc.terminate()
    except Exception:
        proc.kill()


if __name__ == '__main__':
    proc = start_server()

    try:
        if not wait_for_health():
            print('Server did not become healthy in time')
            print(proc.stdout.read().decode(errors='ignore'))
            stop_server(proc)
            sys.exit(2)

        print('Uploading spreadsheet...')
        with open(UPLOAD_FILE, 'rb') as f:
            files = {'file': ('onboarding.xlsx', f, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
            r = requests.post(API_BASE + '/api/upload-spreadsheet', files=files, timeout=30)
            print('Upload status:', r.status_code)
            print('Upload response:', r.text)
            if r.status_code not in (200, 201):
                raise SystemExit('Upload failed')

        # Check assets/slas/jobs endpoints
        print('Checking assets/slas/jobs endpoints...')
        assets = requests.get(API_BASE + '/api/assets').json()
        slas = requests.get(API_BASE + '/api/slas').json()
        jobs = requests.get(API_BASE + '/api/jobs').json()
        print('Assets count:', len(assets.get('data', [])))
        print('SLAs count:', len(slas.get('data', [])))
        print('Jobs count:', len(jobs.get('data', [])))

        print('E2E test completed successfully')
    finally:
        stop_server(proc)
