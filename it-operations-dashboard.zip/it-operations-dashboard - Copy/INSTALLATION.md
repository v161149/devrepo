# Installation Guide - IT Operations Dashboard

## System Requirements

### Minimum Requirements
- **Python**: 3.8 or higher
- **Node.js**: 16 or higher
- **npm**: 8 or higher
- **Operating System**: Windows, macOS, or Linux
- **RAM**: 4GB minimum
- **Disk Space**: 500MB free space

### Recommended Requirements
- **Python**: 3.11+
- **Node.js**: 18+ (LTS)
- **npm**: 9+
- **RAM**: 8GB+
- **Disk Space**: 1GB+ free space

## Installation Steps

### Step 1: Verify Prerequisites

```bash
# Check Python version
python --version  # or python3 --version
# Should show: Python 3.8.x or higher

# Check Node.js version
node --version
# Should show: v16.x.x or higher

# Check npm version
npm --version
# Should show: 8.x.x or higher
```

### Step 2: Extract Project Files

```bash
# Extract the downloaded archive
unzip it-operations-dashboard.zip
# OR
tar -xzf it-operations-dashboard.tar.gz

# Navigate to project directory
cd it-operations-dashboard
```

### Step 3: Database Setup

```bash
# Navigate to database folder
cd database

# Install dependencies (none required, but optional tools available)
pip install -r requirements.txt
# This is optional - the script uses only Python standard library

# Initialize the database
python init_database.py

# You should see: "Database initialized successfully at: it_operations.db"

# Return to project root
cd ..
```

**Troubleshooting Database:**
- If you get "python: command not found", try `python3`
- The database file will be created at: `database/it_operations.db`
- If file exists, it will be overwritten (backup if needed)

### Step 4: Backend Setup

```bash
# Navigate to backend folder
cd backend

# Install CORE dependencies (required)
pip install Flask==3.0.0 Flask-CORS==4.0.0 PyJWT==2.8.0 python-dotenv==1.0.0

# OR install from requirements.txt (core only)
pip install Flask Flask-CORS PyJWT python-dotenv

# OPTIONAL: Install database drivers only for databases you'll use
# For example, if you need PostgreSQL:
pip install psycopg2-binary

# For MySQL:
pip install PyMySQL

# See backend/requirements.txt for full list of optional drivers
```

**Note on Database Drivers:**
- Only install drivers for databases you actually plan to connect to
- Some drivers (like cx-Oracle) may require additional system libraries
- The application will work without external database drivers (using SQLite only)

**Using Virtual Environment (Recommended):**

```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install Flask Flask-CORS PyJWT python-dotenv

# When done, deactivate:
deactivate
```

**Troubleshooting Backend:**
- If `pip` doesn't work, try `pip3`
- On some systems, use `--break-system-packages` flag
- For permission errors on Linux/Mac, use `sudo` or virtual environment

### Step 5: Frontend Setup

```bash
# Navigate to frontend folder
cd frontend

# Install dependencies
npm install

# This will install all required packages from package.json
# Takes 2-5 minutes depending on internet speed
```

**Troubleshooting Frontend:**
- If npm is slow, try: `npm install --legacy-peer-deps`
- For network errors: Check firewall/proxy settings
- If installation fails, delete `node_modules` and try again:
  ```bash
  rm -rf node_modules package-lock.json
  npm install
  ```

### Step 6: Verify Installation

```bash
# Check if backend dependencies are installed
cd backend
python -c "import flask; import jwt; print('Backend dependencies OK')"

# Check if frontend dependencies are installed
cd ../frontend
npm list --depth=0
# Should show all installed packages without errors
```

## Running the Application

### Option 1: Manual Start (Development)

**Terminal 1 - Auth Service:**
```bash
cd backend/services/auth
python auth_service.py
# Should show: Running on http://127.0.0.1:5001
```

**Terminal 2 - Database Service:**
```bash
cd backend/services/database
python database_service.py
# Should show: Running on http://127.0.0.1:5002
```

**Terminal 3 - Dashboard Service:**
```bash
cd backend/services/dashboard
python dashboard_service.py
# Should show: Running on http://127.0.0.1:5003
```

**Terminal 4 - KPI Service:**
```bash
cd backend/services/kpi
python kpi_service.py
# Should show: Running on http://127.0.0.1:5004
```

**Terminal 5 - Alert Service:**
```bash
cd backend/services/alert
python alert_service.py
# Should show: Running on http://127.0.0.1:5005
```

**Terminal 6 - Frontend:**
```bash
cd frontend
npm run dev
# Should show: Local: http://localhost:3000/
```

### Option 2: Using Screen/tmux (Linux/Mac)

```bash
# Install screen if needed
sudo apt-get install screen  # Ubuntu/Debian
brew install screen          # macOS

# Create a startup script
cat > start_services.sh << 'EOF'
#!/bin/bash

cd backend/services/auth && screen -dmS auth python auth_service.py
cd ../../services/database && screen -dmS database python database_service.py
cd ../../services/dashboard && screen -dmS dashboard python dashboard_service.py
cd ../../services/kpi && screen -dmS kpi python kpi_service.py
cd ../../services/alert && screen -dmS alert python alert_service.py
cd ../../../frontend && screen -dmS frontend npm run dev

echo "All services started!"
echo "List screens with: screen -ls"
echo "Attach to a screen with: screen -r <name>"
EOF

chmod +x start_services.sh
./start_services.sh
```

### Option 3: Using Docker (Advanced)

Create a `docker-compose.yml` (you'll need to create this):

```yaml
version: '3.8'

services:
  auth:
    build: ./backend/services/auth
    ports:
      - "5001:5001"
    
  database:
    build: ./backend/services/database
    ports:
      - "5002:5002"
    
  # Add other services...
  
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
```

## Accessing the Application

Once all services are running:

1. **Open your browser**
2. **Navigate to**: http://localhost:3000
3. **Register a new account**:
   - Username: admin
   - Email: admin@example.com
   - Password: admin123
4. **Login** with your credentials
5. **Explore the dashboard!**

## Port Configuration

Default ports used:
- Frontend: 3000
- Auth Service: 5001
- Database Service: 5002
- Dashboard Service: 5003
- KPI Service: 5004
- Alert Service: 5005

**To change ports:**
1. Backend: Modify the `app.run()` call in each service file
2. Frontend: Modify `vite.config.js`

## Environment Variables

Create `.env` files for configuration:

**Backend (.env in backend/ folder):**
```bash
# Database
DATABASE_PATH=../database/it_operations.db

# JWT Secret (change in production!)
JWT_SECRET=your-secret-key-here

# CORS
ALLOWED_ORIGINS=http://localhost:3000

# Debug Mode
FLASK_DEBUG=True
```

**Frontend (.env in frontend/ folder):**
```bash
# API Base URL
VITE_API_BASE_URL=http://localhost:5000
```

## Common Installation Issues

### Issue: "Module not found"
**Solution:**
```bash
# Make sure you're in the right directory
cd backend
pip install -r requirements.txt
```

### Issue: "Port already in use"
**Solution:**
```bash
# Find process using the port (example for port 5001)
# Linux/Mac:
lsof -ti:5001 | xargs kill -9

# Windows:
netstat -ano | findstr :5001
taskkill /PID <PID> /F
```

### Issue: "Cannot connect to database"
**Solution:**
- Ensure database is initialized: `python database/init_database.py`
- Check database file exists: `ls database/it_operations.db`
- Verify path in services: Should be `../../../database/it_operations.db`

### Issue: npm install fails
**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Remove old files
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

### Issue: Frontend can't reach backend
**Solution:**
- Ensure all backend services are running
- Check CORS settings in backend services
- Verify API URL in frontend/.env

## Next Steps

After successful installation:

1. **Read the documentation**: Start with `INDEX.md`
2. **Explore the UI**: Create dashboards, add connections
3. **Test API endpoints**: Use Postman or curl
4. **Customize**: Modify code to fit your needs
5. **Deploy**: Follow production deployment guide

## Production Deployment

For production deployment:

1. **Use PostgreSQL** instead of SQLite
2. **Set up proper secrets**: Use environment variables
3. **Enable HTTPS**: Use SSL certificates
4. **Use process manager**: pm2 (Node) or gunicorn (Python)
5. **Set up reverse proxy**: nginx or Apache
6. **Configure firewall**: Open only necessary ports
7. **Set up monitoring**: Use logs and health checks
8. **Back up database**: Regular automated backups

## Getting Help

If you encounter issues:

1. Check the error message carefully
2. Review the relevant documentation
3. Check logs in terminal/console
4. Verify all services are running
5. Ensure all dependencies are installed

## Uninstallation

To remove the application:

```bash
# Stop all running services (Ctrl+C in each terminal)

# Remove project directory
rm -rf it-operations-dashboard

# Remove Python virtual environment (if created)
rm -rf venv

# Remove node_modules (if you want to clean up)
cd frontend && rm -rf node_modules
```

## Success Checklist

- [ ] Python 3.8+ installed and verified
- [ ] Node.js 16+ installed and verified
- [ ] Database initialized successfully
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed
- [ ] All 5 backend services start without errors
- [ ] Frontend dev server starts successfully
- [ ] Can access http://localhost:3000
- [ ] Can register and login
- [ ] Can view dashboard

Once all boxes are checked, you're ready to use the IT Operations Dashboard!
