/**
 * Dashboard Page Component
 * Main dashboard with customizable widgets and real-time data visualization
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { dashboardAPI, kpiAPI } from '../services/api';
import { 
  Plus, 
  RefreshCw, 
  Settings, 
  Grid,
  TrendingUp,
  TrendingDown,
  Activity,
  Server,
  AlertTriangle
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

// KPI Card Component
const KPICard = ({ kpi, data, status }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'critical': return 'bg-red-50 border-red-200';
      case 'warning': return 'bg-yellow-50 border-yellow-200';
      default: return 'bg-green-50 border-green-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'critical': return <AlertTriangle className="text-red-600" size={20} />;
      case 'warning': return <TrendingDown className="text-yellow-600" size={20} />;
      default: return <TrendingUp className="text-green-600" size={20} />;
    }
  };

  return (
    <div className={`p-6 rounded-lg border-2 ${getStatusColor(status)} transition-all hover:shadow-md`}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-sm text-gray-600 font-medium">{kpi?.kpi_name}</p>
          <p className="text-3xl font-bold text-gray-900 mt-1">
            {data?.value?.toFixed(2)} {kpi?.unit_of_measure}
          </p>
        </div>
        <div className="p-2 bg-white rounded-lg">
          {getStatusIcon(status)}
        </div>
      </div>
      
      <div className="flex items-center justify-between text-sm">
        <span className="text-gray-600">Status</span>
        <span className={`font-medium capitalize ${
          status === 'critical' ? 'text-red-600' :
          status === 'warning' ? 'text-yellow-600' : 'text-green-600'
        }`}>
          {status}
        </span>
      </div>
      
      {kpi?.threshold_warning && (
        <div className="mt-2 text-xs text-gray-500">
          Warning: {kpi.threshold_warning} | Critical: {kpi.threshold_critical}
        </div>
      )}
    </div>
  );
};

// Chart Widget Component
const ChartWidget = ({ widget, data }) => {
  const renderChart = () => {
    const chartType = widget?.visualization_config?.chartType || 'line';
    
    // Sample data transformation (in real app, this comes from query results)
    const chartData = data || [
      { time: '00:00', value: 65 },
      { time: '04:00', value: 72 },
      { time: '08:00', value: 81 },
      { time: '12:00', value: 78 },
      { time: '16:00', value: 86 },
      { time: '20:00', value: 74 },
    ];

    const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

    switch (chartType) {
      case 'bar':
        return (
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#3B82F6" />
          </BarChart>
        );
      
      case 'area':
        return (
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Area type="monotone" dataKey="value" fill="#3B82F6" stroke="#2563EB" />
          </AreaChart>
        );
      
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={chartData}
              dataKey="value"
              nameKey="time"
              cx="50%"
              cy="50%"
              outerRadius={80}
              label
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        );
      
      default: // line chart
        return (
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={2} />
          </LineChart>
        );
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">
          {widget?.widget_title || 'Untitled Chart'}
        </h3>
        <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <Settings size={18} className="text-gray-500" />
        </button>
      </div>
      
      <ResponsiveContainer width="100%" height={250}>
        {renderChart()}
      </ResponsiveContainer>
    </div>
  );
};

// Main Dashboard Page
const DashboardPage = () => {
  const { user } = useAuth();
  const [dashboards, setDashboards] = useState([]);
  const [currentDashboard, setCurrentDashboard] = useState(null);
  const [kpiData, setKpiData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboards();
    loadKPIData();
  }, [user]);

  const loadDashboards = async () => {
    try {
      const response = await dashboardAPI.getDashboards(user.user_id);
      if (response.success) {
        setDashboards(response.data);
        // Set default dashboard or first one
        const defaultDashboard = response.data.find(d => d.is_default) || response.data[0];
        setCurrentDashboard(defaultDashboard);
      }
    } catch (error) {
      console.error('Failed to load dashboards:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadKPIData = async () => {
    try {
      // Load KPI definitions
      const kpiDefsResponse = await kpiAPI.getDefinitions();
      
      if (kpiDefsResponse.success) {
        // Load latest data for each KPI
        const kpiPromises = kpiDefsResponse.data.slice(0, 8).map(async (kpi) => {
          try {
            const latestResponse = await kpiAPI.getLatest(kpi.kpi_id);
            return {
              kpi,
              latest: latestResponse.data?.latest_value,
              status: latestResponse.data?.status
            };
          } catch {
            return { kpi, latest: null, status: 'normal' };
          }
        });
        
        const kpiResults = await Promise.all(kpiPromises);
        setKpiData(kpiResults);
      }
    } catch (error) {
      console.error('Failed to load KPI data:', error);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadKPIData();
    setRefreshing(false);
  };

  const handleCreateDashboard = async () => {
    const name = prompt('Enter dashboard name:');
    if (name) {
      try {
        const response = await dashboardAPI.createDashboard({
          user_id: user.user_id,
          dashboard_name: name,
          description: '',
        });
        
        if (response.success) {
          await loadDashboards();
        }
      } catch (error) {
        alert('Failed to create dashboard');
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-gray-600">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Welcome back, {user?.full_name || user?.username}
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <RefreshCw size={18} className={refreshing ? 'animate-spin' : ''} />
            <span>Refresh</span>
          </button>
          
          <button
            onClick={handleCreateDashboard}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus size={18} />
            <span>New Dashboard</span>
          </button>
        </div>
      </div>

      {/* Dashboard Selector */}
      {dashboards.length > 0 && (
        <div className="flex items-center space-x-2 overflow-x-auto pb-2">
          {dashboards.map((dashboard) => (
            <button
              key={dashboard.dashboard_id}
              onClick={() => setCurrentDashboard(dashboard)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                currentDashboard?.dashboard_id === dashboard.dashboard_id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
              }`}
            >
              {dashboard.dashboard_name}
            </button>
          ))}
        </div>
      )}

      {/* KPI Overview Grid */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Activity className="mr-2" size={24} />
          Key Performance Indicators
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiData.map((item, index) => (
            <KPICard
              key={index}
              kpi={item.kpi}
              data={item.latest}
              status={item.status}
            />
          ))}
        </div>
      </div>

      {/* Charts Section */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Grid className="mr-2" size={24} />
          Visualizations
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ChartWidget 
            widget={{ 
              widget_title: 'System Performance Trend',
              visualization_config: { chartType: 'line' }
            }} 
          />
          <ChartWidget 
            widget={{ 
              widget_title: 'Resource Utilization',
              visualization_config: { chartType: 'bar' }
            }} 
          />
          <ChartWidget 
            widget={{ 
              widget_title: 'Network Activity',
              visualization_config: { chartType: 'area' }
            }} 
          />
          <ChartWidget 
            widget={{ 
              widget_title: 'Service Distribution',
              visualization_config: { chartType: 'pie' }
            }} 
          />
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Servers</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">127</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Server className="text-blue-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Alerts</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">3</p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <AlertTriangle className="text-yellow-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Response Time</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">124ms</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <Activity className="text-green-600" size={24} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
