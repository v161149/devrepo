/**
 * Database Connections Page
 * Manage connections to external databases
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { databaseAPI } from '../services/api';
import { Plus, Edit, Trash2, TestTube, Database } from 'lucide-react';

const DatabaseConnectionsPage = () => {
  const { user } = useAuth();
  const [connections, setConnections] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [formData, setFormData] = useState({
    connection_name: '',
    db_type: 'postgresql',
    host: '',
    port: '',
    database_name: '',
    username: '',
    password: '',
  });

  const dbTypes = [
    { value: 'oracle', label: 'Oracle DB' },
    { value: 'teradata', label: 'Teradata' },
    { value: 'sqlserver', label: 'SQL Server' },
    { value: 'db2', label: 'IBM DB2' },
    { value: 'mysql', label: 'MySQL' },
    { value: 'postgresql', label: 'PostgreSQL' },
    { value: 'hive', label: 'Hadoop Hive' },
  ];

  useEffect(() => {
    loadConnections();
  }, [user]);

  const loadConnections = async () => {
    try {
      const response = await databaseAPI.getConnections(user.user_id);
      if (response.success) {
        setConnections(response.data);
      }
    } catch (error) {
      console.error('Failed to load connections:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const data = { ...formData, user_id: user.user_id };
      
      if (editing) {
        await databaseAPI.updateConnection(editing.connection_id, data);
      } else {
        await databaseAPI.createConnection(data);
      }
      
      setShowModal(false);
      setEditing(null);
      resetForm();
      loadConnections();
    } catch (error) {
      alert('Failed to save connection');
    }
  };

  const handleTest = async (connectionId) => {
    try {
      const response = await databaseAPI.testConnection(connectionId);
      if (response.success) {
        alert('Connection successful!');
      }
    } catch (error) {
      alert('Connection failed: ' + error.message);
    }
  };

  const handleDelete = async (connectionId) => {
    if (confirm('Are you sure you want to delete this connection?')) {
      try {
        await databaseAPI.deleteConnection(connectionId);
        loadConnections();
      } catch (error) {
        alert('Failed to delete connection');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      connection_name: '',
      db_type: 'postgresql',
      host: '',
      port: '',
      database_name: '',
      username: '',
      password: '',
    });
  };

  const openEditModal = (connection) => {
    setEditing(connection);
    setFormData({
      connection_name: connection.connection_name,
      db_type: connection.db_type,
      host: connection.host,
      port: connection.port,
      database_name: connection.database_name,
      username: connection.username,
      password: '',
    });
    setShowModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Database Connections</h1>
          <p className="text-gray-600 mt-1">
            Manage connections to external data sources
          </p>
        </div>
        
        <button
          onClick={() => {
            setEditing(null);
            resetForm();
            setShowModal(true);
          }}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus size={18} />
          <span>New Connection</span>
        </button>
      </div>

      {/* Connections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {connections.map((conn) => (
          <div key={conn.connection_id} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Database className="text-blue-600" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{conn.connection_name}</h3>
                  <p className="text-sm text-gray-500">{conn.db_type.toUpperCase()}</p>
                </div>
              </div>
              
              <div className={`px-2 py-1 rounded-full text-xs ${
                conn.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
              }`}>
                {conn.is_active ? 'Active' : 'Inactive'}
              </div>
            </div>

            <div className="space-y-2 text-sm text-gray-600 mb-4">
              <div className="flex justify-between">
                <span>Host:</span>
                <span className="font-medium text-gray-900">{conn.host}:{conn.port}</span>
              </div>
              <div className="flex justify-between">
                <span>Database:</span>
                <span className="font-medium text-gray-900">{conn.database_name}</span>
              </div>
              <div className="flex justify-between">
                <span>User:</span>
                <span className="font-medium text-gray-900">{conn.username}</span>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => handleTest(conn.connection_id)}
                className="flex-1 flex items-center justify-center space-x-1 px-3 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors"
              >
                <TestTube size={16} />
                <span className="text-sm">Test</span>
              </button>
              
              <button
                onClick={() => openEditModal(conn)}
                className="p-2 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Edit size={16} />
              </button>
              
              <button
                onClick={() => handleDelete(conn.connection_id)}
                className="p-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Connection Form Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              {editing ? 'Edit Connection' : 'New Connection'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Connection Name *
                </label>
                <input
                  type="text"
                  value={formData.connection_name}
                  onChange={(e) => setFormData({ ...formData, connection_name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Database Type *
                </label>
                <select
                  value={formData.db_type}
                  onChange={(e) => setFormData({ ...formData, db_type: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  {dbTypes.map((type) => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Host *
                  </label>
                  <input
                    type="text"
                    value={formData.host}
                    onChange={(e) => setFormData({ ...formData, host: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Port *
                  </label>
                  <input
                    type="number"
                    value={formData.port}
                    onChange={(e) => setFormData({ ...formData, port: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Database Name *
                </label>
                <input
                  type="text"
                  value={formData.database_name}
                  onChange={(e) => setFormData({ ...formData, database_name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Username *
                </label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password {editing && '(leave blank to keep current)'}
                </label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required={!editing}
                />
              </div>

              <div className="flex items-center space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {editing ? 'Update Connection' : 'Create Connection'}
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditing(null);
                    resetForm();
                  }}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DatabaseConnectionsPage;
