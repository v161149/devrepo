/**
 * Alerts Page Component
 * Manage alerts and view alert history
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { alertAPI } from '../services/api';
import { Bell, Plus, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

const AlertsPage = () => {
  const { user } = useAuth();
  const [alerts, setAlerts] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('alerts'); // 'alerts' or 'history'

  useEffect(() => {
    loadAlerts();
    loadHistory();
  }, [user]);

  const loadAlerts = async () => {
    try {
      const response = await alertAPI.getAlerts(user.user_id);
      if (response.success) {
        setAlerts(response.data);
      }
    } catch (error) {
      console.error('Failed to load alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadHistory = async () => {
    try {
      const response = await alertAPI.getHistory(user.user_id, null, 50);
      if (response.success) {
        setHistory(response.data);
      }
    } catch (error) {
      console.error('Failed to load alert history:', error);
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'warning': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-blue-100 text-blue-700 border-blue-200';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'threshold': return <AlertTriangle size={20} />;
      case 'anomaly': return <Activity size={20} />;
      default: return <Bell size={20} />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-gray-600">Loading alerts...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Alerts & Notifications</h1>
          <p className="text-gray-600 mt-1">Monitor and manage system alerts</p>
        </div>
        <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus size={18} />
          <span>New Alert</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Alerts</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{alerts.length}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Bell className="text-blue-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Alerts</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {alerts.filter(a => a.is_active).length}
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <CheckCircle className="text-green-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Triggered Today</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {history.filter(h => {
                  const today = new Date().toDateString();
                  return new Date(h.triggered_at).toDateString() === today;
                }).length}
              </p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <AlertTriangle className="text-yellow-600" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {history.filter(h => !h.acknowledged).length}
              </p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <Clock className="text-red-600" size={24} />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('alerts')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'alerts'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Alert Configuration ({alerts.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'history'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Alert History ({history.length})
          </button>
        </nav>
      </div>

      {/* Content */}
      {activeTab === 'alerts' ? (
        <div className="space-y-4">
          {alerts.length === 0 ? (
            <div className="bg-white p-12 rounded-lg shadow-sm border border-gray-200 text-center">
              <Bell className="mx-auto text-gray-400 mb-4" size={48} />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No alerts configured</h3>
              <p className="text-gray-600 mb-4">Create your first alert to start monitoring</p>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Create Alert
              </button>
            </div>
          ) : (
            alerts.map((alert) => (
              <div key={alert.alert_id} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      {getTypeIcon(alert.alert_type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h3 className="text-lg font-semibold text-gray-900">{alert.alert_name}</h3>
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                          alert.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {alert.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-2">
                        Type: <span className="font-medium">{alert.alert_type}</span>
                      </p>
                      {alert.notification_channels && (
                        <p className="text-sm text-gray-600 mt-1">
                          Channels: {alert.notification_channels.join(', ') || 'None configured'}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200">
                      Edit
                    </button>
                    <button className="px-3 py-1 text-sm bg-red-50 text-red-700 rounded hover:bg-red-100">
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {history.length === 0 ? (
            <div className="bg-white p-12 rounded-lg shadow-sm border border-gray-200 text-center">
              <Clock className="mx-auto text-gray-400 mb-4" size={48} />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No alert history</h3>
              <p className="text-gray-600">Alert triggers will appear here</p>
            </div>
          ) : (
            history.map((item) => (
              <div key={item.history_id} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className={`inline-flex px-3 py-1 text-xs font-medium rounded-full border ${
                        getSeverityColor(item.severity)
                      }`}>
                        {item.severity?.toUpperCase() || 'INFO'}
                      </span>
                      <span className="text-sm text-gray-600">
                        {new Date(item.triggered_at).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-gray-900 font-medium">{item.alert_message}</p>
                    <div className="flex items-center space-x-4 mt-3 text-sm text-gray-600">
                      <span>
                        Status: {item.resolved ? (
                          <span className="text-green-600 font-medium">✓ Resolved</span>
                        ) : item.acknowledged ? (
                          <span className="text-blue-600 font-medium">Acknowledged</span>
                        ) : (
                          <span className="text-yellow-600 font-medium">⚠ Pending</span>
                        )}
                      </span>
                      {item.resolved_at && (
                        <span>Resolved: {new Date(item.resolved_at).toLocaleString()}</span>
                      )}
                    </div>
                  </div>
                  {!item.acknowledged && (
                    <button className="px-3 py-1 text-sm bg-blue-50 text-blue-700 rounded hover:bg-blue-100">
                      Acknowledge
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default AlertsPage;
