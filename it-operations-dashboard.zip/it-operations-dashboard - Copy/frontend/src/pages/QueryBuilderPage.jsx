/**
 * Query Builder Page Component
 * Execute SQL queries and visualize results
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { databaseAPI } from '../services/api';
import { Play, Save, Database, Table, BarChart } from 'lucide-react';

const QueryBuilderPage = () => {
  const { user } = useAuth();
  const [connections, setConnections] = useState([]);
  const [selectedConnection, setSelectedConnection] = useState('');
  const [query, setQuery] = useState('-- Write your SQL query here\nSELECT * FROM users LIMIT 10;');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadConnections();
  }, [user]);

  const loadConnections = async () => {
    try {
      const response = await databaseAPI.getConnections(user.user_id);
      if (response.success) {
        setConnections(response.data);
        if (response.data.length > 0) {
          setSelectedConnection(response.data[0].connection_id);
        }
      }
    } catch (error) {
      console.error('Failed to load connections:', error);
    }
  };

  const handleExecuteQuery = async () => {
    if (!selectedConnection) {
      setError('Please select a database connection');
      return;
    }

    if (!query.trim()) {
      setError('Please enter a query');
      return;
    }

    setLoading(true);
    setError('');
    setResults(null); // Clear previous results

    try {
      const response = await databaseAPI.executeQuery({
        connection_id: selectedConnection,
        query: query,
      });

      if (response.success) {
        // The response.data contains the query result
        const queryResult = response.data;
        
        // Check if we have actual data
        if (queryResult && queryResult.data && queryResult.data.length > 0) {
          setResults(queryResult);
        } else if (queryResult && queryResult.data && queryResult.data.length === 0) {
          // Query successful but no rows
          setResults(queryResult);
          setError('Query executed successfully but returned no rows.');
        } else {
          setError('Query executed but response format was unexpected.');
        }
      } else {
        setError(response.message || response.error || 'Query execution failed');
      }
    } catch (err) {
      // Better error handling
      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else if (err.message) {
        setError(err.message);
      } else if (typeof err === 'string') {
        setError(err);
      } else {
        setError('Failed to execute query. Please check your connection and try again.');
      }
      console.error('Query execution error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveQuery = async () => {
    const name = prompt('Enter a name for this query:');
    if (!name) return;

    try {
      await databaseAPI.saveQuery({
        user_id: user.user_id,
        query_name: name,
        query_text: query,
        connection_id: selectedConnection,
      });
      alert('Query saved successfully!');
    } catch (error) {
      alert('Failed to save query');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Query Builder</h1>
          <p className="text-gray-600 mt-1">Execute SQL queries and visualize results</p>
        </div>
      </div>

      {/* Connection Selector */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center space-x-4">
          <Database className="text-gray-500" size={20} />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Database Connection
            </label>
            <select
              value={selectedConnection}
              onChange={(e) => setSelectedConnection(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Choose a connection...</option>
              {connections.map((conn) => (
                <option key={conn.connection_id} value={conn.connection_id}>
                  {conn.connection_name} ({conn.db_type})
                </option>
              ))}
            </select>
          </div>
          {connections.length === 0 && (
            <a
              href="/connections"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
            >
              Add Connection
            </a>
          )}
        </div>
      </div>

      {/* Query Editor */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 px-6 py-4">
          <h2 className="text-lg font-semibold text-gray-900">SQL Query</h2>
        </div>
        <div className="p-6">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full h-64 px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter your SQL query here..."
          />

          <div className="flex items-center space-x-3 mt-4">
            <button
              onClick={handleExecuteQuery}
              disabled={loading || !selectedConnection}
              className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold shadow-sm"
              title={!selectedConnection ? 'Please select a connection first' : 'Execute the SQL query'}
            >
              <Play size={20} />
              <span>{loading ? 'Executing...' : 'Execute Query'}</span>
            </button>

            <button
              onClick={handleSaveQuery}
              disabled={!query.trim()}
              className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold shadow-sm"
              title="Save this query for later use"
            >
              <Save size={20} />
              <span>Save Query</span>
            </button>
            
            <div className="flex-1"></div>
            
            {selectedConnection && (
              <div className="text-sm text-gray-600">
                <span className="font-medium">Connection:</span>{' '}
                {connections.find(c => c.connection_id === parseInt(selectedConnection))?.connection_name || 'Selected'}
              </div>
            )}
          </div>

          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}
        </div>
      </div>

      {/* Results */}
      {results && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Table className="text-gray-500" size={20} />
              <h2 className="text-lg font-semibold text-gray-900">Query Results</h2>
              <span className="text-sm text-gray-500">
                ({results.row_count || 0} rows)
              </span>
            </div>
            <button className="flex items-center space-x-2 px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200">
              <BarChart size={16} />
              <span>Visualize</span>
            </button>
          </div>

          <div className="p-6 overflow-x-auto">
            {results.data && results.data.length > 0 ? (
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    {results.columns && results.columns.map((col, idx) => (
                      <th
                        key={idx}
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {results.data.map((row, rowIdx) => (
                    <tr key={rowIdx} className="hover:bg-gray-50">
                      {results.columns.map((col, colIdx) => (
                        <td key={colIdx} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {row[col] !== null ? row[col].toString() : 'NULL'}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <p>Query executed successfully but returned no rows.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Sample Queries */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="font-semibold text-gray-900 mb-3">Sample Queries</h3>
        <p className="text-sm text-gray-600 mb-4">Click on a query to copy it to the editor</p>
        <div className="space-y-2 text-sm">
          <div 
            onClick={() => setQuery('SELECT * FROM users LIMIT 10;')}
            className="bg-white p-3 rounded border border-blue-100 cursor-pointer hover:bg-blue-50 transition-colors"
          >
            <div className="font-medium text-gray-700 mb-1">View Users (Generic)</div>
            <code className="text-blue-600">SELECT * FROM users LIMIT 10;</code>
          </div>
          <div 
            onClick={() => setQuery('SELECT COUNT(*) as total_users FROM users;')}
            className="bg-white p-3 rounded border border-blue-100 cursor-pointer hover:bg-blue-50 transition-colors"
          >
            <div className="font-medium text-gray-700 mb-1">Count Total Users</div>
            <code className="text-blue-600">SELECT COUNT(*) as total_users FROM users;</code>
          </div>
          <div 
            onClick={() => setQuery("SELECT COUNT(*) as active_users \nFROM users \nWHERE last_login >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)\n  AND status = 'active';")}
            className="bg-white p-3 rounded border border-blue-100 cursor-pointer hover:bg-blue-50 transition-colors"
          >
            <div className="font-medium text-gray-700 mb-1">Active Users (MySQL - Last 5 Minutes)</div>
            <code className="text-blue-600">
              SELECT COUNT(*) as active_users<br/>
              FROM users<br/>
              WHERE last_login &gt;= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            </code>
          </div>
          <div 
            onClick={() => setQuery('SELECT kpi_name, value, timestamp FROM kpi_data ORDER BY timestamp DESC LIMIT 5;')}
            className="bg-white p-3 rounded border border-blue-100 cursor-pointer hover:bg-blue-50 transition-colors"
          >
            <div className="font-medium text-gray-700 mb-1">Recent KPI Data (Dashboard DB)</div>
            <code className="text-blue-600">SELECT kpi_name, value FROM kpi_data ORDER BY timestamp DESC LIMIT 5;</code>
          </div>
          <div 
            onClick={() => setQuery("SHOW TABLES;")}
            className="bg-white p-3 rounded border border-blue-100 cursor-pointer hover:bg-blue-50 transition-colors"
          >
            <div className="font-medium text-gray-700 mb-1">List All Tables (MySQL)</div>
            <code className="text-blue-600">SHOW TABLES;</code>
          </div>
          <div 
            onClick={() => setQuery("SELECT table_name, table_rows \nFROM information_schema.tables \nWHERE table_schema = DATABASE();")}
            className="bg-white p-3 rounded border border-blue-100 cursor-pointer hover:bg-blue-50 transition-colors"
          >
            <div className="font-medium text-gray-700 mb-1">Table Row Counts (MySQL)</div>
            <code className="text-blue-600">
              SELECT table_name, table_rows<br/>
              FROM information_schema.tables<br/>
              WHERE table_schema = DATABASE();
            </code>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QueryBuilderPage;