/**
 * KPI Management Page Component
 * Manage KPI definitions and view historical data
 */
import React, { useState, useEffect } from 'react';
import { kpiAPI } from '../services/api';
import { Activity, Plus, Edit, TrendingUp, AlertCircle, X } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const KPIManagementPage = () => {
  const [kpis, setKpis] = useState([]);
  const [selectedKPI, setSelectedKPI] = useState(null);
  const [kpiData, setKpiData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingKPI, setEditingKPI] = useState(null);
  const [formData, setFormData] = useState({
    kpi_name: '',
    kpi_category: 'system',
    description: '',
    unit_of_measure: '',
    threshold_warning: '',
    threshold_critical: '',
  });
  const [formError, setFormError] = useState('');

  const categories = [
    'system',
    'application',
    'network',
    'incident',
    'security',
    'support',
    'resource',
  ];

  useEffect(() => {
    loadKPIs();
  }, []);

  useEffect(() => {
    if (selectedKPI) {
      loadKPIData(selectedKPI.kpi_id);
    }
  }, [selectedKPI]);

  const loadKPIs = async () => {
    try {
      const response = await kpiAPI.getDefinitions();
      if (response.success) {
        setKpis(response.data);
        if (response.data.length > 0 && !selectedKPI) {
          setSelectedKPI(response.data[0]);
        }
      }
    } catch (error) {
      console.error('Failed to load KPIs:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadKPIData = async (kpiId) => {
    try {
      const response = await kpiAPI.getData(kpiId, 168); // Last 7 days
      if (response.success && response.data.data_points) {
        const chartData = response.data.data_points
          .reverse()
          .map(point => ({
            time: new Date(point.timestamp).toLocaleTimeString([], { 
              month: 'short', 
              day: 'numeric', 
              hour: '2-digit' 
            }),
            value: parseFloat(point.value)
          }));
        setKpiData(chartData);
      }
    } catch (error) {
      console.error('Failed to load KPI data:', error);
    }
  };

  const handleOpenNewKPI = () => {
    setEditingKPI(null);
    setFormData({
      kpi_name: '',
      kpi_category: 'system',
      description: '',
      unit_of_measure: '',
      threshold_warning: '',
      threshold_critical: '',
    });
    setFormError('');
    setShowModal(true);
  };

  const handleOpenEditKPI = (kpi) => {
    setEditingKPI(kpi);
    setFormData({
      kpi_name: kpi.kpi_name,
      kpi_category: kpi.kpi_category,
      description: kpi.description || '',
      unit_of_measure: kpi.unit_of_measure || '',
      threshold_warning: kpi.threshold_warning || '',
      threshold_critical: kpi.threshold_critical || '',
    });
    setFormError('');
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingKPI(null);
    setFormError('');
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    if (!formData.kpi_name.trim()) {
      setFormError('KPI name is required');
      return false;
    }
    if (!formData.kpi_category) {
      setFormError('Category is required');
      return false;
    }
    if (!formData.unit_of_measure.trim()) {
      setFormError('Unit of measure is required');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!validateForm()) {
      return;
    }

    try {
      const payload = {
        ...formData,
        threshold_warning: formData.threshold_warning ? parseFloat(formData.threshold_warning) : null,
        threshold_critical: formData.threshold_critical ? parseFloat(formData.threshold_critical) : null,
      };

      let response;
      if (editingKPI) {
        // Update existing KPI
        response = await kpiAPI.updateDefinition(editingKPI.kpi_id, payload);
      } else {
        // Create new KPI
        response = await kpiAPI.createDefinition(payload);
      }

      if (response.success) {
        await loadKPIs();
        handleCloseModal();
        
        // If we just created a new KPI, select it
        if (!editingKPI && response.data?.kpi_id) {
          const newKPI = kpis.find(k => k.kpi_id === response.data.kpi_id);
          if (newKPI) {
            setSelectedKPI(newKPI);
          }
        }
      } else {
        setFormError(response.message || 'Failed to save KPI');
      }
    } catch (error) {
      setFormError(error.message || 'Failed to save KPI');
    }
  };

  const getCategoryColor = (category) => {
    const colors = {
      system: 'bg-blue-100 text-blue-700',
      application: 'bg-green-100 text-green-700',
      network: 'bg-purple-100 text-purple-700',
      incident: 'bg-orange-100 text-orange-700',
      security: 'bg-red-100 text-red-700',
      support: 'bg-yellow-100 text-yellow-700',
      resource: 'bg-indigo-100 text-indigo-700',
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-gray-600">Loading KPIs...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">KPI Management</h1>
          <p className="text-gray-600 mt-1">Monitor and manage key performance indicators</p>
        </div>
        <button 
          onClick={handleOpenNewKPI}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus size={18} />
          <span>New KPI</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* KPI List */}
        <div className="lg:col-span-1 bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200 px-6 py-4">
            <h2 className="text-lg font-semibold text-gray-900">KPI Definitions</h2>
            <p className="text-sm text-gray-500 mt-1">{kpis.length} total KPIs</p>
          </div>
          <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto">
            {kpis.map((kpi) => (
              <div
                key={kpi.kpi_id}
                onClick={() => setSelectedKPI(kpi)}
                className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                  selectedKPI?.kpi_id === kpi.kpi_id ? 'bg-blue-50 border-l-4 border-blue-600' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{kpi.kpi_name}</h3>
                    <p className="text-sm text-gray-500 mt-1">{kpi.description}</p>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getCategoryColor(kpi.kpi_category)}`}>
                        {kpi.kpi_category}
                      </span>
                      <span className="text-xs text-gray-500">{kpi.unit_of_measure}</span>
                    </div>
                  </div>
                  <Activity className="text-gray-400" size={20} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* KPI Details */}
        <div className="lg:col-span-2 space-y-6">
          {selectedKPI ? (
            <>
              {/* KPI Header */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedKPI.kpi_name}</h2>
                    <p className="text-gray-600 mt-1">{selectedKPI.description}</p>
                  </div>
                  <button 
                    onClick={() => handleOpenEditKPI(selectedKPI)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Edit size={20} className="text-gray-500" />
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Category</div>
                    <span className={`inline-flex px-3 py-1 text-sm font-medium rounded-full ${getCategoryColor(selectedKPI.kpi_category)}`}>
                      {selectedKPI.kpi_category}
                    </span>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Unit</div>
                    <div className="text-lg font-semibold text-gray-900">{selectedKPI.unit_of_measure}</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Thresholds</div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm">
                        ⚠️ {selectedKPI.threshold_warning}
                      </span>
                      <span className="text-sm">
                        🔴 {selectedKPI.threshold_critical}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* KPI Trend Chart */}
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <TrendingUp className="text-blue-600" size={20} />
                  <h3 className="text-lg font-semibold text-gray-900">Historical Trend (Last 7 Days)</h3>
                </div>
                
                {kpiData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={kpiData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="time" 
                        tick={{ fontSize: 12 }}
                        angle={-45}
                        textAnchor="end"
                        height={80}
                      />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#3B82F6" 
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                      {selectedKPI.threshold_warning && (
                        <Line 
                          type="monotone" 
                          dataKey={() => selectedKPI.threshold_warning}
                          stroke="#F59E0B" 
                          strokeDasharray="5 5"
                          dot={false}
                          name="Warning"
                        />
                      )}
                      {selectedKPI.threshold_critical && (
                        <Line 
                          type="monotone" 
                          dataKey={() => selectedKPI.threshold_critical}
                          stroke="#EF4444" 
                          strokeDasharray="5 5"
                          dot={false}
                          name="Critical"
                        />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex flex-col items-center justify-center h-64 text-gray-500">
                    <AlertCircle size={48} className="mb-4" />
                    <p>No historical data available for this KPI</p>
                    <p className="text-sm mt-2">Data will appear once values are recorded</p>
                  </div>
                )}
              </div>

              {/* Statistics */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                  <h4 className="text-sm font-medium text-gray-600 mb-2">Current Status</h4>
                  <div className="text-2xl font-bold text-gray-900">Normal</div>
                  <p className="text-sm text-gray-500 mt-1">Within acceptable range</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                  <h4 className="text-sm font-medium text-gray-600 mb-2">Data Points</h4>
                  <div className="text-2xl font-bold text-gray-900">{kpiData.length}</div>
                  <p className="text-sm text-gray-500 mt-1">In the last 7 days</p>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white p-12 rounded-lg shadow-sm border border-gray-200 text-center">
              <Activity className="mx-auto text-gray-400 mb-4" size={48} />
              <p className="text-gray-600">Select a KPI to view details</p>
            </div>
          )}
        </div>
      </div>

      {/* KPI Form Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingKPI ? 'Edit KPI' : 'Create New KPI'}
              </h2>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X size={24} className="text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  KPI Name *
                </label>
                <input
                  type="text"
                  name="kpi_name"
                  value={formData.kpi_name}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Active Users"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category *
                </label>
                <select
                  name="kpi_category"
                  value={formData.kpi_category}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>
                      {cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleFormChange}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Describe what this KPI measures..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Unit of Measure *
                </label>
                <input
                  type="text"
                  name="unit_of_measure"
                  value={formData.unit_of_measure}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., users, milliseconds, percentage, GB"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Warning Threshold
                  </label>
                  <input
                    type="number"
                    name="threshold_warning"
                    value={formData.threshold_warning}
                    onChange={handleFormChange}
                    step="any"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., 100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Critical Threshold
                  </label>
                  <input
                    type="number"
                    name="threshold_critical"
                    value={formData.threshold_critical}
                    onChange={handleFormChange}
                    step="any"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., 150"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {editingKPI ? 'Update KPI' : 'Create KPI'}
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default KPIManagementPage;
