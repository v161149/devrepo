/**
 * Query Builder Page Component
 * Execute SQL queries and visualize results
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { databaseAPI } from '../services/api';
import { Play, Save, Database, Table, BarChart } from 'lucide-react';

const QueryBuilderPage = () => {
  const { user } = useAuth();
  const [connections, setConnections] = useState([]);
  const [selectedConnection, setSelectedConnection] = useState('');
  const [query, setQuery] = useState('-- Write your SQL query here\nSELECT * FROM users LIMIT 10;');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadConnections();
  }, [user]);

  const loadConnections = async () => {
    try {
      const response = await databaseAPI.getConnections(user.user_id);
      if (response.success) {
        setConnections(response.data);
        if (response.data.length > 0) {
          setSelectedConnection(response.data[0].connection_id);
        }
      }
    } catch (error) {
      console.error('Failed to load connections:', error);
    }
  };

  const handleExecuteQuery = async () => {
    if (!selectedConnection) {
      setError('Please select a database connection');
      return;
    }

    if (!query.trim()) {
      setError('Please enter a query');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await databaseAPI.executeQuery({
        connection_id: selectedConnection,
        query: query,
      });

      if (response.success) {
        setResults(response.data);
      } else {
        setError(response.error || 'Query execution failed');
      }
    } catch (err) {
      setError(err.message || 'Failed to execute query');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveQuery = async () => {
    const name = prompt('Enter a name for this query:');
    if (!name) return;

    try {
      await databaseAPI.saveQuery({
        user_id: user.user_id,
        query_name: name,
        query_text: query,
        connection_id: selectedConnection,
      });
      alert('Query saved successfully!');
    } catch (error) {
      alert('Failed to save query');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Query Builder</h1>
          <p className="text-gray-600 mt-1">Execute SQL queries and visualize results</p>
        </div>
      </div>

      {/* Connection Selector */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center space-x-4">
          <Database className="text-gray-500" size={20} />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Database Connection
            </label>
            <select
              value={selectedConnection}
              onChange={(e) => setSelectedConnection(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Choose a connection...</option>
              {connections.map((conn) => (
                <option key={conn.connection_id} value={conn.connection_id}>
                  {conn.connection_name} ({conn.db_type})
                </option>
              ))}
            </select>
          </div>
          {connections.length === 0 && (
            <a
              href="/connections"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
            >
              Add Connection
            </a>
          )}
        </div>
      </div>

      {/* Query Editor */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 px-6 py-4">
          <h2 className="text-lg font-semibold text-gray-900">SQL Query</h2>
        </div>
        <div className="p-6">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full h-64 px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter your SQL query here..."
          />

          <div className="flex items-center space-x-3 mt-4">
            <button
              onClick={handleExecuteQuery}
              disabled={loading}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
            >
              <Play size={18} />
              <span>{loading ? 'Executing...' : 'Execute Query'}</span>
            </button>

            <button
              onClick={handleSaveQuery}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Save size={18} />
              <span>Save Query</span>
            </button>
          </div>

          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}
        </div>
      </div>

      {/* Results */}
      {results && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Table className="text-gray-500" size={20} />
              <h2 className="text-lg font-semibold text-gray-900">Query Results</h2>
              <span className="text-sm text-gray-500">
                ({results.row_count || 0} rows)
              </span>
            </div>
            <button className="flex items-center space-x-2 px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200">
              <BarChart size={16} />
              <span>Visualize</span>
            </button>
          </div>

          <div className="p-6 overflow-x-auto">
            {results.data && results.data.length > 0 ? (
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    {results.columns && results.columns.map((col, idx) => (
                      <th
                        key={idx}
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {results.data.map((row, rowIdx) => (
                    <tr key={rowIdx} className="hover:bg-gray-50">
                      {results.columns.map((col, colIdx) => (
                        <td key={colIdx} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {row[col] !== null ? row[col].toString() : 'NULL'}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <p>Query executed successfully but returned no rows.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Sample Queries */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="font-semibold text-gray-900 mb-3">Sample Queries</h3>
        <div className="space-y-2 text-sm">
          <div className="bg-white p-3 rounded border border-blue-100">
            <code className="text-blue-600">SELECT * FROM users LIMIT 10;</code>
          </div>
          <div className="bg-white p-3 rounded border border-blue-100">
            <code className="text-blue-600">SELECT COUNT(*) as total FROM dashboards;</code>
          </div>
          <div className="bg-white p-3 rounded border border-blue-100">
            <code className="text-blue-600">SELECT kpi_name, value FROM kpi_data ORDER BY timestamp DESC LIMIT 5;</code>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QueryBuilderPage;
