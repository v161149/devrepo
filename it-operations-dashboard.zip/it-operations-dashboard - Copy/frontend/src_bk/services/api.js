/**
 * API Service Layer
 * Handles all HTTP requests to backend microservices
 */
import axios from 'axios';

// Individual service URLs
const AUTH_SERVICE_URL = import.meta.env.VITE_AUTH_SERVICE_URL || 'http://localhost:5001';
const DATABASE_SERVICE_URL = import.meta.env.VITE_DATABASE_SERVICE_URL || 'http://localhost:5002';
const DASHBOARD_SERVICE_URL = import.meta.env.VITE_DASHBOARD_SERVICE_URL || 'http://localhost:5003';
const KPI_SERVICE_URL = import.meta.env.VITE_KPI_SERVICE_URL || 'http://localhost:5004';
const ALERT_SERVICE_URL = import.meta.env.VITE_ALERT_SERVICE_URL || 'http://localhost:5005';

// Create axios instance factory
const createApiClient = (baseURL) => {
  const client = axios.create({
    baseURL,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Request interceptor to add auth token
  client.interceptors.request.use(
    (config) => {
      const token = localStorage.getItem('auth_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  // Response interceptor for error handling
  client.interceptors.response.use(
    (response) => response.data,
    (error) => {
      if (error.response?.status === 401) {
        localStorage.removeItem('auth_token');
        window.location.href = '/login';
      }
      return Promise.reject(error.response?.data || error.message);
    }
  );

  return client;
};

// Create clients for each service
const authClient = createApiClient(AUTH_SERVICE_URL);
const databaseClient = createApiClient(DATABASE_SERVICE_URL);
const dashboardClient = createApiClient(DASHBOARD_SERVICE_URL);
const kpiClient = createApiClient(KPI_SERVICE_URL);
const alertClient = createApiClient(ALERT_SERVICE_URL);

// ========== AUTH API ==========
export const authAPI = {
  register: (data) => authClient.post('/api/auth/register', data),
  login: (data) => authClient.post('/api/auth/login', data),
  verify: () => authClient.post('/api/auth/verify'),
  getUser: (userId) => authClient.get(`/api/auth/user/${userId}`),
  updateUser: (userId, data) => authClient.put(`/api/auth/user/${userId}`, data),
};

// ========== DATABASE API ==========
export const databaseAPI = {
  getConnections: (userId) => databaseClient.get('/api/database/connections', { params: { user_id: userId } }),
  createConnection: (data) => databaseClient.post('/api/database/connections', data),
  updateConnection: (connectionId, data) => databaseClient.put(`/api/database/connections/${connectionId}`, data),
  deleteConnection: (connectionId) => databaseClient.delete(`/api/database/connections/${connectionId}`),
  testConnection: (connectionId) => databaseClient.post(`/api/database/connections/${connectionId}/test`),
  executeQuery: (data) => databaseClient.post('/api/database/query/execute', data),
  saveQuery: (data) => databaseClient.post('/api/database/query/save', data),
  getSavedQueries: (userId) => databaseClient.get('/api/database/query/saved', { params: { user_id: userId } }),
};

// ========== DASHBOARD API ==========
export const dashboardAPI = {
  // Dashboards
  getDashboards: (userId) => dashboardClient.get('/api/dashboard/dashboards', { params: { user_id: userId } }),
  createDashboard: (data) => dashboardClient.post('/api/dashboard/dashboards', data),
  updateDashboard: (dashboardId, data) => dashboardClient.put(`/api/dashboard/dashboards/${dashboardId}`, data),
  deleteDashboard: (dashboardId) => dashboardClient.delete(`/api/dashboard/dashboards/${dashboardId}`),
  
  // Pages
  getPages: (dashboardId) => dashboardClient.get(`/api/dashboard/dashboards/${dashboardId}/pages`),
  createPage: (data) => dashboardClient.post('/api/dashboard/pages', data),
  updatePage: (pageId, data) => dashboardClient.put(`/api/dashboard/pages/${pageId}`, data),
  deletePage: (pageId) => dashboardClient.delete(`/api/dashboard/pages/${pageId}`),
  
  // Widgets
  getWidgets: (pageId) => dashboardClient.get(`/api/dashboard/pages/${pageId}/widgets`),
  createWidget: (data) => dashboardClient.post('/api/dashboard/widgets', data),
  updateWidget: (widgetId, data) => dashboardClient.put(`/api/dashboard/widgets/${widgetId}`, data),
  deleteWidget: (widgetId) => dashboardClient.delete(`/api/dashboard/widgets/${widgetId}`),
};

// ========== KPI API ==========
export const kpiAPI = {
  getDefinitions: (category) => kpiClient.get('/api/kpi/definitions', { params: { category } }),
  createDefinition: (data) => kpiClient.post('/api/kpi/definitions', data),
  updateDefinition: (kpiId, data) => kpiClient.put(`/api/kpi/definitions/${kpiId}`, data),
  addData: (data) => kpiClient.post('/api/kpi/data', data),
  getData: (kpiId, hours = 24, limit = 1000) => 
    kpiClient.get(`/api/kpi/data/${kpiId}`, { params: { hours, limit } }),
  getLatest: (kpiId) => kpiClient.get(`/api/kpi/data/${kpiId}/latest`),
  getStatistics: (kpiId, hours = 24) => 
    kpiClient.get(`/api/kpi/data/${kpiId}/statistics`, { params: { hours } }),
  getCategories: () => kpiClient.get('/api/kpi/categories'),
};

// ========== ALERT API ==========
export const alertAPI = {
  getAlerts: (userId) => alertClient.get('/api/alert/alerts', { params: { user_id: userId } }),
  createAlert: (data) => alertClient.post('/api/alert/alerts', data),
  getHistory: (userId, alertId = null, limit = 100) => 
    alertClient.get('/api/alert/history', { params: { user_id: userId, alert_id: alertId, limit } }),
};

export default {
  authAPI,
  databaseAPI,
  dashboardAPI,
  kpiAPI,
  alertAPI,
};