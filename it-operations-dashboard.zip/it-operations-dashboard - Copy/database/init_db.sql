-- IT Operations Dashboard Database Schema
-- SQLite Database

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Database connections table
CREATE TABLE IF NOT EXISTS database_connections (
    connection_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    connection_name VARCHAR(255) NOT NULL,
    db_type VARCHAR(50) NOT NULL, -- oracle, teradata, sqlserver, db2, mysql, postgresql, hive
    host VARCHAR(255) NOT NULL,
    port INTEGER NOT NULL,
    database_name VARCHAR(255),
    username VARCHAR(255),
    password_encrypted TEXT,
    additional_params TEXT, -- JSON for extra connection parameters
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Dashboards table
CREATE TABLE IF NOT EXISTS dashboards (
    dashboard_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    dashboard_name VARCHAR(255) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Dashboard pages table (for multi-page dashboards)
CREATE TABLE IF NOT EXISTS dashboard_pages (
    page_id INTEGER PRIMARY KEY AUTOINCREMENT,
    dashboard_id INTEGER NOT NULL,
    page_name VARCHAR(255) NOT NULL,
    page_subject VARCHAR(500),
    page_order INTEGER DEFAULT 0,
    layout_config TEXT, -- JSON for layout configuration
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dashboard_id) REFERENCES dashboards(dashboard_id) ON DELETE CASCADE
);

-- Widgets/Components table
CREATE TABLE IF NOT EXISTS widgets (
    widget_id INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id INTEGER NOT NULL,
    widget_type VARCHAR(50) NOT NULL, -- chart, graph, table, gauge, kpi
    widget_title VARCHAR(255),
    data_source_id INTEGER,
    query_text TEXT,
    visualization_config TEXT, -- JSON for chart/visualization settings
    position_x INTEGER DEFAULT 0,
    position_y INTEGER DEFAULT 0,
    width INTEGER DEFAULT 4,
    height INTEGER DEFAULT 3,
    refresh_interval INTEGER DEFAULT 300, -- seconds
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (page_id) REFERENCES dashboard_pages(page_id) ON DELETE CASCADE,
    FOREIGN KEY (data_source_id) REFERENCES database_connections(connection_id) ON DELETE SET NULL
);

-- Saved queries table
CREATE TABLE IF NOT EXISTS saved_queries (
    query_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    query_name VARCHAR(255) NOT NULL,
    query_text TEXT NOT NULL,
    connection_id INTEGER,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (connection_id) REFERENCES database_connections(connection_id) ON DELETE SET NULL
);

-- KPI definitions table
CREATE TABLE IF NOT EXISTS kpi_definitions (
    kpi_id INTEGER PRIMARY KEY AUTOINCREMENT,
    kpi_name VARCHAR(255) NOT NULL,
    kpi_category VARCHAR(100), -- system, application, network, incident, security, support, resource
    description TEXT,
    unit_of_measure VARCHAR(50),
    threshold_warning REAL,
    threshold_critical REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- KPI data table (for storing KPI values over time)
CREATE TABLE IF NOT EXISTS kpi_data (
    kpi_data_id INTEGER PRIMARY KEY AUTOINCREMENT,
    kpi_id INTEGER NOT NULL,
    value REAL NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata TEXT, -- JSON for additional context
    FOREIGN KEY (kpi_id) REFERENCES kpi_definitions(kpi_id) ON DELETE CASCADE
);

-- Alerts and notifications table
CREATE TABLE IF NOT EXISTS alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    alert_name VARCHAR(255) NOT NULL,
    alert_type VARCHAR(50), -- threshold, anomaly, status_change
    widget_id INTEGER,
    kpi_id INTEGER,
    condition_config TEXT, -- JSON for alert conditions
    is_active BOOLEAN DEFAULT 1,
    notification_channels TEXT, -- JSON array: email, sms, slack, etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (widget_id) REFERENCES widgets(widget_id) ON DELETE CASCADE,
    FOREIGN KEY (kpi_id) REFERENCES kpi_definitions(kpi_id) ON DELETE CASCADE
);

-- Alert history table
CREATE TABLE IF NOT EXISTS alert_history (
    history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id INTEGER NOT NULL,
    triggered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    alert_message TEXT,
    severity VARCHAR(20), -- info, warning, critical
    acknowledged BOOLEAN DEFAULT 0,
    acknowledged_by INTEGER,
    acknowledged_at TIMESTAMP,
    resolved BOOLEAN DEFAULT 0,
    resolved_at TIMESTAMP,
    FOREIGN KEY (alert_id) REFERENCES alerts(alert_id) ON DELETE CASCADE,
    FOREIGN KEY (acknowledged_by) REFERENCES users(user_id)
);

-- Reports table
CREATE TABLE IF NOT EXISTS reports (
    report_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    report_name VARCHAR(255) NOT NULL,
    report_type VARCHAR(50), -- scheduled, ad_hoc
    dashboard_id INTEGER,
    page_id INTEGER,
    widget_ids TEXT, -- JSON array of widget IDs
    schedule_config TEXT, -- JSON for scheduling (cron-like)
    export_format VARCHAR(20), -- csv, excel, pdf
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (dashboard_id) REFERENCES dashboards(dashboard_id) ON DELETE CASCADE,
    FOREIGN KEY (page_id) REFERENCES dashboard_pages(page_id) ON DELETE CASCADE
);

-- Report execution history
CREATE TABLE IF NOT EXISTS report_executions (
    execution_id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER NOT NULL,
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    file_path VARCHAR(500),
    file_size INTEGER,
    status VARCHAR(50), -- success, failed, pending
    error_message TEXT,
    FOREIGN KEY (report_id) REFERENCES reports(report_id) ON DELETE CASCADE
);

-- User preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
    preference_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    preference_key VARCHAR(100) NOT NULL,
    preference_value TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE(user_id, preference_key)
);

-- Audit log table
CREATE TABLE IF NOT EXISTS audit_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INTEGER,
    details TEXT,
    ip_address VARCHAR(45),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_db_connections_user ON database_connections(user_id);
CREATE INDEX IF NOT EXISTS idx_dashboards_user ON dashboards(user_id);
CREATE INDEX IF NOT EXISTS idx_widgets_page ON widgets(page_id);
CREATE INDEX IF NOT EXISTS idx_kpi_data_kpi_timestamp ON kpi_data(kpi_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_alerts_user ON alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_alert_history_alert ON alert_history(alert_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(timestamp);

-- Insert sample KPI definitions
INSERT INTO kpi_definitions (kpi_name, kpi_category, description, unit_of_measure, threshold_warning, threshold_critical) VALUES
('System Uptime', 'system', 'Server/system availability percentage', 'percentage', 95.0, 90.0),
('Application Response Time', 'application', 'Average application response time', 'milliseconds', 500, 1000),
('Error Rate', 'application', 'Application error rate', 'percentage', 5.0, 10.0),
('Network Latency', 'network', 'Average network latency', 'milliseconds', 100, 200),
('Bandwidth Usage', 'network', 'Network bandwidth utilization', 'percentage', 75.0, 90.0),
('Packet Loss', 'network', 'Network packet loss rate', 'percentage', 1.0, 5.0),
('Mean Time to Resolve (MTTR)', 'incident', 'Average time to resolve incidents', 'minutes', 120, 240),
('Security Threat Level', 'security', 'Current security threat level', 'level', 7.0, 9.0),
('Open Vulnerabilities', 'security', 'Number of open security vulnerabilities', 'count', 10, 25),
('Support Ticket Volume', 'support', 'Number of open support tickets', 'count', 50, 100),
('Customer Satisfaction', 'support', 'Customer satisfaction score', 'score', 3.5, 3.0),
('CPU Utilization', 'resource', 'Server CPU utilization', 'percentage', 75.0, 90.0),
('Memory Utilization', 'resource', 'Server memory utilization', 'percentage', 80.0, 95.0),
('Storage Utilization', 'resource', 'Storage capacity utilization', 'percentage', 80.0, 90.0);
