"""
Database initialization script for IT Operations Dashboard
"""
import sqlite3
import os
from pathlib import Path

def init_database(db_path='it_operations.db'):
    """Initialize the SQLite database with schema"""
    
    # Get the directory of this script
    script_dir = Path(__file__).parent
    sql_file = script_dir / 'init_db.sql'
    
    # Create database connection
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Read and execute SQL schema
    with open(sql_file, 'r') as f:
        sql_script = f.read()
        cursor.executescript(sql_script)
    
    conn.commit()
    conn.close()
    
    print(f"Database initialized successfully at: {db_path}")

if __name__ == "__main__":
    init_database()
