# Python Requirements - Complete Guide

## Overview

The IT Operations Dashboard has Python requirements in two locations:

### 1. Database Folder (`database/requirements.txt`)
**Location:** `database/requirements.txt`

**Dependencies:** NONE required! ✅

The database initialization script uses only Python's standard library:
- `sqlite3` (built-in)
- `os` (built-in)  
- `pathlib` (built-in)

**Optional dependencies** (if you want enhanced features):
- SQLAlchemy - For ORM capabilities
- alembic - For database migrations
- pydantic - For data validation

**Installation:**
```bash
cd database
# No installation needed! Python standard library only.

# But if you want optional features:
pip install -r requirements.txt
```

### 2. Backend Folder (`backend/requirements.txt`)
**Location:** `backend/requirements.txt`

**Core Dependencies (REQUIRED):**
- Flask==3.0.0
- Flask-CORS==4.0.0
- PyJWT==2.8.0
- python-dotenv==1.0.0

**External Database Drivers (OPTIONAL - install only what you need):**
- cx-Oracle - For Oracle Database
- PyMySQL - For MySQL
- psycopg2-binary - For PostgreSQL
- pyodbc - For SQL Server
- ibm-db-sa - For IBM DB2
- teradatasql - For Teradata
- pyhive - For Hadoop Hive

**Installation:**

**Minimal (Core only):**
```bash
cd backend
pip install Flask Flask-CORS PyJWT python-dotenv
```

**With specific database support:**
```bash
# For PostgreSQL
pip install Flask Flask-CORS PyJWT python-dotenv psycopg2-binary

# For MySQL
pip install Flask Flask-CORS PyJWT python-dotenv PyMySQL

# For multiple databases
pip install Flask Flask-CORS PyJWT python-dotenv psycopg2-binary PyMySQL
```

**Full installation (all optional drivers):**
```bash
cd backend
pip install -r requirements.txt
# Note: This will try to install all database drivers
# Some may fail if system libraries are missing
```

## Quick Start Installation

### Minimum to get started:

```bash
# 1. Database - No dependencies needed!
cd database
python init_database.py

# 2. Backend - Core only
cd ../backend
pip install Flask Flask-CORS PyJWT python-dotenv

# 3. Frontend
cd ../frontend
npm install

# That's it! You can now run the application.
```

## Installation by Use Case

### Use Case 1: Just Testing the Application
**What to install:**
```bash
# Backend core only
pip install Flask Flask-CORS PyJWT python-dotenv

# Frontend
npm install
```
**Result:** App works with SQLite, no external database connections

### Use Case 2: Connecting to PostgreSQL
**What to install:**
```bash
# Backend core + PostgreSQL
pip install Flask Flask-CORS PyJWT python-dotenv psycopg2-binary

# Frontend
npm install
```
**Result:** App works + can connect to PostgreSQL databases

### Use Case 3: Connecting to MySQL
**What to install:**
```bash
# Backend core + MySQL
pip install Flask Flask-CORS PyJWT python-dotenv PyMySQL

# Frontend
npm install
```
**Result:** App works + can connect to MySQL databases

### Use Case 4: Production Deployment with Multiple Databases
**What to install:**
```bash
# Backend - install all needed drivers
pip install Flask Flask-CORS PyJWT python-dotenv \
    psycopg2-binary PyMySQL

# Optional: Add other drivers as needed
# pip install cx-Oracle  # for Oracle
# pip install pyodbc     # for SQL Server

# Frontend
npm install
```

## Troubleshooting

### Database Driver Installation Issues

**Issue:** cx-Oracle installation fails
**Solution:** Requires Oracle Instant Client on your system
```bash
# Follow Oracle's guide to install Instant Client first
# Then: pip install cx-Oracle
```

**Issue:** psycopg2 installation fails
**Solution:** Use the binary version
```bash
pip install psycopg2-binary
# Not: pip install psycopg2
```

**Issue:** pyodbc installation fails
**Solution:** Requires ODBC drivers on your system
```bash
# Windows: Install Microsoft ODBC Driver for SQL Server
# Linux: sudo apt-get install unixodbc-dev
# Mac: brew install unixodbc
# Then: pip install pyodbc
```

### General Installation Issues

**Issue:** pip command not found
**Solution:**
```bash
# Try pip3 instead
pip3 install Flask Flask-CORS PyJWT python-dotenv
```

**Issue:** Permission denied
**Solution:**
```bash
# Use virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install Flask Flask-CORS PyJWT python-dotenv

# OR use --user flag
pip install --user Flask Flask-CORS PyJWT python-dotenv

# OR use sudo (not recommended)
sudo pip install Flask Flask-CORS PyJWT python-dotenv
```

**Issue:** Module conflicts
**Solution:**
```bash
# Use a clean virtual environment
rm -rf venv
python -m venv venv
source venv/bin/activate
pip install Flask Flask-CORS PyJWT python-dotenv
```

## Requirements File Locations

```
it-operations-dashboard/
├── database/
│   └── requirements.txt       ← Optional (no deps needed)
│
├── backend/
│   └── requirements.txt       ← Core dependencies here
│
└── frontend/
    └── package.json           ← Node.js dependencies
```

## Complete Installation Commands

**For a fresh installation:**

```bash
# Navigate to project root
cd it-operations-dashboard

# 1. Initialize database (no deps needed)
cd database
python init_database.py
cd ..

# 2. Install backend dependencies (CHOOSE ONE):

# Option A: Minimal (recommended for testing)
cd backend
pip install Flask Flask-CORS PyJWT python-dotenv
cd ..

# Option B: With common databases
cd backend
pip install Flask Flask-CORS PyJWT python-dotenv psycopg2-binary PyMySQL
cd ..

# Option C: Everything (may have some failures)
cd backend
pip install -r requirements.txt
cd ..

# 3. Install frontend dependencies
cd frontend
npm install
cd ..

# Done!
```

## Verifying Installation

**Check Python dependencies:**
```bash
cd backend
python -c "import flask, jwt, flask_cors; print('✓ All core dependencies installed')"
```

**Check optional database drivers:**
```bash
# PostgreSQL
python -c "import psycopg2; print('✓ PostgreSQL driver installed')"

# MySQL
python -c "import pymysql; print('✓ MySQL driver installed')"

# Check for any driver
python -c "import sys; import psycopg2; print('✓ PostgreSQL OK')" 2>/dev/null || echo "✗ PostgreSQL not installed"
```

**Check frontend dependencies:**
```bash
cd frontend
npm list --depth=0
```

## Summary

**Minimum Requirements:**
- Database: No dependencies needed ✅
- Backend: 4 core packages (Flask, Flask-CORS, PyJWT, python-dotenv)
- Frontend: Automatically installed via npm

**To get started quickly:**
```bash
pip install Flask Flask-CORS PyJWT python-dotenv
cd frontend && npm install
```

**That's it!** The application will work with these minimal dependencies. Install database drivers only when you need to connect to external databases.

## Need Help?

- See `INSTALLATION.md` for complete installation guide
- See `QUICKSTART.md` for quick setup
- Check backend/requirements.txt for full list of optional dependencies
