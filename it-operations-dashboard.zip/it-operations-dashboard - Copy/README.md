# IT Operations Dashboard

A comprehensive React-based web portal for IT operations monitoring with Python microservices backend and SQLite database.

## 🎯 Features

### Core Functionality
- **Real-time Data Visualization**: Interactive charts, graphs, tables, and gauges
- **Multi-Database Support**: Connect to Oracle, Teradata, SQL Server, DB2, MySQL, PostgreSQL, and Hadoop Hive
- **Customizable Dashboards**: Create multiple dashboards with drag-and-drop widgets
- **KPI Tracking**: Monitor critical IT operations metrics with threshold alerts
- **Query Builder**: Execute ad-hoc queries and save them for reuse
- **Automated Alerts**: Configure threshold-based notifications
- **Report Generation**: Export data in CSV, Excel, or PDF formats
- **User Management**: Role-based access control

### Technical Features
- Component-driven, API-first architecture
- Microservices backend with Python Flask
- SQLite database for metadata storage
- JWT-based authentication
- RESTful API design
- Responsive UI with Tailwind CSS
- Real-time data refresh capabilities

## 📁 Project Structure

```
it-operations-dashboard/
├── backend/                    # Python microservices
│   ├── services/
│   │   ├── auth/              # Authentication service (port 5001)
│   │   ├── database/          # Database connection service (port 5002)
│   │   ├── dashboard/         # Dashboard management (port 5003)
│   │   ├── kpi/               # KPI tracking service (port 5004)
│   │   └── alert/             # Alert service (port 5005)
│   ├── shared/                # Shared utilities
│   │   ├── database.py        # Database managers
│   │   └── utils.py           # Common utilities
│   └── requirements.txt       # Python dependencies
│
├── frontend/                   # React application
│   ├── src/
│   │   ├── components/        # Reusable UI components
│   │   ├── pages/             # Page components
│   │   ├── services/          # API service layer
│   │   ├── contexts/          # React contexts
│   │   └── utils/             # Helper functions
│   └── package.json           # Node dependencies
│
└── database/                   # Database schema
    ├── init_db.sql            # Database schema
    └── init_database.py       # Initialization script
```

## 🚀 Setup Instructions

### Prerequisites
- Python 3.8+
- Node.js 16+
- SQLite 3

### Backend Setup

1. **Initialize Database**
```bash
cd database
python init_database.py
```

This creates `it_operations.db` with all necessary tables and sample KPI definitions.

2. **Install Python Dependencies**
```bash
cd backend
pip install -r requirements.txt
```

3. **Start Microservices**

Each service runs on a different port. Start them in separate terminals:

```bash
# Auth Service (port 5001)
cd backend/services/auth
python auth_service.py

# Database Service (port 5002)
cd backend/services/database
python database_service.py

# Dashboard Service (port 5003)
cd backend/services/dashboard
python dashboard_service.py

# KPI Service (port 5004)
cd backend/services/kpi
python kpi_service.py

# Alert Service (port 5005)
cd backend/services/alert
python alert_service.py
```

### Frontend Setup

1. **Install Dependencies**
```bash
cd frontend
npm install
```

2. **Configure Environment**

Create `.env` file in frontend directory:
```
VITE_API_BASE_URL=http://localhost:5000
```

3. **Start Development Server**
```bash
npm run dev
```

The application will be available at `http://localhost:3000`

## 📊 Database Schema

### Key Tables

**users** - User accounts and authentication
**database_connections** - External database connection configurations
**dashboards** - User dashboards
**dashboard_pages** - Multiple pages within dashboards
**widgets** - Individual visualization widgets
**kpi_definitions** - KPI metrics definitions
**kpi_data** - Time-series KPI data points
**alerts** - Alert configurations
**alert_history** - Alert trigger history
**saved_queries** - Saved SQL queries
**reports** - Report configurations
**audit_log** - System audit trail

## 🔌 API Endpoints

### Authentication API (Port 5001)
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/verify` - Verify JWT token
- `GET /api/auth/user/:id` - Get user details
- `PUT /api/auth/user/:id` - Update user profile

### Database API (Port 5002)
- `GET /api/database/connections` - List connections
- `POST /api/database/connections` - Create connection
- `PUT /api/database/connections/:id` - Update connection
- `DELETE /api/database/connections/:id` - Delete connection
- `POST /api/database/connections/:id/test` - Test connection
- `POST /api/database/query/execute` - Execute query
- `POST /api/database/query/save` - Save query
- `GET /api/database/query/saved` - Get saved queries

### Dashboard API (Port 5003)
- `GET /api/dashboard/dashboards` - List dashboards
- `POST /api/dashboard/dashboards` - Create dashboard
- `PUT /api/dashboard/dashboards/:id` - Update dashboard
- `DELETE /api/dashboard/dashboards/:id` - Delete dashboard
- `GET /api/dashboard/dashboards/:id/pages` - Get pages
- `POST /api/dashboard/pages` - Create page
- `PUT /api/dashboard/pages/:id` - Update page
- `DELETE /api/dashboard/pages/:id` - Delete page
- `GET /api/dashboard/pages/:id/widgets` - Get widgets
- `POST /api/dashboard/widgets` - Create widget
- `PUT /api/dashboard/widgets/:id` - Update widget
- `DELETE /api/dashboard/widgets/:id` - Delete widget

### KPI API (Port 5004)
- `GET /api/kpi/definitions` - List KPI definitions
- `POST /api/kpi/definitions` - Create KPI definition
- `PUT /api/kpi/definitions/:id` - Update KPI definition
- `POST /api/kpi/data` - Add KPI data point
- `GET /api/kpi/data/:id` - Get KPI historical data
- `GET /api/kpi/data/:id/latest` - Get latest KPI value
- `GET /api/kpi/data/:id/statistics` - Get KPI statistics
- `GET /api/kpi/categories` - Get KPI categories

### Alert API (Port 5005)
- `GET /api/alert/alerts` - List alerts
- `POST /api/alert/alerts` - Create alert
- `GET /api/alert/history` - Get alert history

## 🎨 Frontend Components

### Pages
- **LoginPage** - User authentication
- **DashboardPage** - Main dashboard with KPIs and charts
- **DatabaseConnectionsPage** - Manage database connections
- **QueryBuilderPage** - SQL query interface
- **KPIManagementPage** - KPI configuration
- **AlertsPage** - Alert management

### Key Components
- **Layout** - Main application layout with navigation
- **KPICard** - Individual KPI display card
- **ChartWidget** - Configurable chart visualization
- **AuthContext** - Authentication state management

## 🔒 Security Features

- JWT-based authentication
- Password hashing (SHA256)
- Database password encryption
- SQL injection prevention
- Role-based access control
- Audit logging for all actions
- Secure API endpoints with token verification

## 📈 KPI Categories

Pre-configured KPI categories:
- **System**: Uptime, availability
- **Application**: Response times, error rates
- **Network**: Latency, bandwidth, packet loss
- **Incident**: MTTR (Mean Time to Resolve)
- **Security**: Threat levels, vulnerabilities
- **Support**: Ticket volumes, satisfaction scores
- **Resource**: CPU, memory, storage utilization

## 🔧 Configuration

### Database Connections
Supported database types:
- Oracle DB
- Teradata
- SQL Server
- IBM DB2 (Mainframe)
- MySQL
- PostgreSQL
- Hadoop Hive

### Widget Types
- Line charts
- Bar charts
- Area charts
- Pie charts
- Tables
- Gauges
- KPI cards

### Alert Types
- Threshold-based alerts
- Anomaly detection
- Status change notifications

## 🚦 Usage Guide

### 1. First Time Setup
1. Register a new user account
2. Login with credentials
3. Create database connections
4. Configure KPIs
5. Create your first dashboard

### 2. Creating a Dashboard
1. Navigate to Dashboard page
2. Click "New Dashboard"
3. Add pages to organize content
4. Add widgets (charts, KPIs, tables)
5. Configure data sources and queries

### 3. Setting Up Alerts
1. Go to Alerts page
2. Create new alert
3. Select KPI or widget to monitor
4. Configure threshold conditions
5. Choose notification channels

### 4. Running Queries
1. Navigate to Query Builder
2. Select database connection
3. Write SQL query
4. Execute and view results
5. Visualize data with charts
6. Save query for reuse

## 🛠️ Development

### Running in Development Mode

Backend (with auto-reload):
```bash
cd backend/services/auth
FLASK_ENV=development python auth_service.py
```

Frontend (with hot reload):
```bash
cd frontend
npm run dev
```

### Building for Production

Frontend:
```bash
cd frontend
npm run build
```

The built files will be in `frontend/dist/`

## 📝 Notes

- The current implementation uses SQLite for simplicity. For production, consider PostgreSQL or MySQL.
- External database connections require appropriate drivers to be installed.
- Password encryption in the demo uses basic encoding; implement proper encryption (e.g., Fernet) for production.
- JWT secret key should be stored in environment variables for production.
- Implement rate limiting and additional security measures for production deployment.

## 🤝 Contributing

This is a demonstration project showcasing a comprehensive IT operations dashboard architecture.

## 📄 License

This project is provided as-is for educational and demonstration purposes.

## 📧 Support

For questions or issues, please refer to the code comments and API documentation within the source files.
