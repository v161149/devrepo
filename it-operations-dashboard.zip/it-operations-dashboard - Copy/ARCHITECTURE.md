# IT Operations Dashboard - Architecture Documentation

## System Architecture Overview

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend Layer (React)                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │Dashboard │  │ Database │  │  Query   │  │   KPI    │   │
│  │   Page   │  │Connection│  │ Builder  │  │Management│   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘   │
│       │             │              │              │          │
│       └─────────────┴──────────────┴──────────────┘         │
│                          │                                    │
│                  API Service Layer                           │
└──────────────────────────┼────────────────────────────────────┘
                           │
                    REST API (JSON)
                           │
┌──────────────────────────┼────────────────────────────────────┐
│              Backend Layer (Python Microservices)             │
│                          │                                     │
│  ┌──────────┬──────────┬┼──────────┬──────────┬──────────┐  │
│  │   Auth   │ Database ││Dashboard │   KPI    │  Alert   │  │
│  │ Service  │ Service  ││ Service  │ Service  │ Service  │  │
│  │  :5001   │  :5002   ││  :5003   │  :5004   │  :5005   │  │
│  └────┬─────┴────┬─────┴┼────┬─────┴────┬─────┴────┬─────┘  │
│       │          │      ││    │          │          │         │
│       └──────────┴──────┴┘────┴──────────┴──────────┘         │
│                          │                                     │
│                 Shared Utilities Layer                         │
│            (Database Manager, Security, Utils)                │
└──────────────────────────┼────────────────────────────────────┘
                           │
┌──────────────────────────┼────────────────────────────────────┐
│                   Data Layer                                   │
│                          │                                     │
│  ┌────────────────────────────────────────────────┐          │
│  │          SQLite Database (Metadata)            │          │
│  │  ┌──────────┬──────────┬──────────┬──────────┐│          │
│  │  │  Users   │Dashboards│   KPIs   │  Alerts  ││          │
│  │  │Connection│ Widgets  │KPI Data  │  Audit   ││          │
│  │  └──────────┴──────────┴──────────┴──────────┘│          │
│  └────────────────────────────────────────────────┘          │
│                          │                                     │
│  ┌────────────────────────────────────────────────┐          │
│  │   External Data Sources (via Connections)      │          │
│  │  ┌───────┬─────────┬────────┬──────┬─────────┐│          │
│  │  │Oracle │Teradata │SQL Srv │ DB2  │PostgreSQL│          │
│  │  │ MySQL │  Hive   │  JIRA  │ etc  │   etc   ││          │
│  │  └───────┴─────────┴────────┴──────┴─────────┘│          │
│  └────────────────────────────────────────────────┘          │
└───────────────────────────────────────────────────────────────┘
```

## Component Architecture

### Frontend Architecture (React)

```
src/
├── components/          # Reusable UI components
│   ├── Layout/         # Main layout with navigation
│   ├── Charts/         # Chart components (Line, Bar, Pie, etc.)
│   ├── KPI/            # KPI display components
│   ├── Forms/          # Form components
│   └── Common/         # Common UI elements
│
├── pages/              # Page-level components
│   ├── LoginPage       # Authentication
│   ├── DashboardPage   # Main dashboard
│   ├── DatabaseConnectionsPage
│   ├── QueryBuilderPage
│   ├── KPIManagementPage
│   └── AlertsPage
│
├── services/           # API communication
│   └── api.js          # Centralized API calls
│
├── contexts/           # React Context providers
│   └── AuthContext     # Authentication state
│
├── hooks/              # Custom React hooks
│   ├── useAuth         # Authentication hook
│   ├── useDashboard    # Dashboard operations
│   └── useKPI          # KPI operations
│
└── utils/              # Helper functions
    ├── formatters.js   # Data formatting
    ├── validators.js   # Input validation
    └── constants.js    # App constants
```

### Backend Architecture (Microservices)

```
backend/
├── services/
│   ├── auth/                    # Authentication & User Management
│   │   └── auth_service.py     # Port 5001
│   │       ├── /api/auth/register
│   │       ├── /api/auth/login
│   │       ├── /api/auth/verify
│   │       └── /api/auth/user/*
│   │
│   ├── database/                # Database Connection Management
│   │   └── database_service.py # Port 5002
│   │       ├── /api/database/connections
│   │       ├── /api/database/query/execute
│   │       └── /api/database/query/saved
│   │
│   ├── dashboard/               # Dashboard Management
│   │   └── dashboard_service.py # Port 5003
│   │       ├── /api/dashboard/dashboards
│   │       ├── /api/dashboard/pages
│   │       └── /api/dashboard/widgets
│   │
│   ├── kpi/                     # KPI Tracking
│   │   └── kpi_service.py      # Port 5004
│   │       ├── /api/kpi/definitions
│   │       ├── /api/kpi/data
│   │       └── /api/kpi/statistics
│   │
│   └── alert/                   # Alert Management
│       └── alert_service.py    # Port 5005
│           ├── /api/alert/alerts
│           └── /api/alert/history
│
└── shared/                      # Shared utilities
    ├── database.py             # Database managers
    │   ├── DatabaseManager     # SQLite operations
    │   └── ExternalDatabaseConnector
    │
    └── utils.py                # Common utilities
        ├── SecurityUtils       # Auth & encryption
        ├── DataUtils          # Data manipulation
        ├── ValidationUtils    # Input validation
        └── ResponseFormatter  # API responses
```

## Data Flow

### 1. User Authentication Flow
```
User → Login Form → Auth API → Database → JWT Token → Store in LocalStorage
```

### 2. Dashboard Loading Flow
```
User → Dashboard Page → Dashboard API → Database → Widget Config → Render Widgets
                      ↓
                   KPI API → KPI Data → Display KPIs
```

### 3. Query Execution Flow
```
User → Query Builder → Select Connection → Write Query → Database API
                                                           ↓
                                         External DB Connector → Execute Query
                                                           ↓
                                         Results → Visualize → Display Charts
```

### 4. KPI Monitoring Flow
```
Data Source → KPI API → Add KPI Data → Check Thresholds → Alert Service
                                              ↓                  ↓
                                         Store in DB      Trigger Alert
                                              ↓                  ↓
                                         Dashboard       Notification
```

## Database Schema

### Core Tables

**users** - User accounts
- user_id (PK)
- username, email, password_hash
- role, created_at, updated_at

**database_connections** - External DB connections
- connection_id (PK)
- user_id (FK)
- db_type, host, port, database_name
- username, password_encrypted
- is_active, created_at

**dashboards** - User dashboards
- dashboard_id (PK)
- user_id (FK)
- dashboard_name, description
- is_default, created_at

**dashboard_pages** - Dashboard pages
- page_id (PK)
- dashboard_id (FK)
- page_name, page_subject
- layout_config (JSON)
- page_order

**widgets** - Dashboard widgets
- widget_id (PK)
- page_id (FK)
- widget_type, widget_title
- data_source_id (FK)
- query_text
- visualization_config (JSON)
- position_x, position_y
- width, height
- refresh_interval

**kpi_definitions** - KPI definitions
- kpi_id (PK)
- kpi_name, kpi_category
- description, unit_of_measure
- threshold_warning, threshold_critical

**kpi_data** - KPI time-series data
- kpi_data_id (PK)
- kpi_id (FK)
- value, timestamp
- metadata (JSON)

**alerts** - Alert configurations
- alert_id (PK)
- user_id (FK)
- alert_name, alert_type
- widget_id (FK), kpi_id (FK)
- condition_config (JSON)
- notification_channels (JSON)
- is_active

**alert_history** - Alert trigger history
- history_id (PK)
- alert_id (FK)
- triggered_at, alert_message
- severity, acknowledged, resolved

## Security Architecture

### Authentication
- JWT-based token authentication
- SHA256 password hashing
- Token stored in localStorage
- Token verification on each request

### Authorization
- Role-based access control (RBAC)
- User roles: admin, user
- Resource-level permissions

### Data Security
- Database password encryption
- SQL injection prevention
- Input validation and sanitization
- Audit logging for all actions

### API Security
- CORS configuration
- Request rate limiting (planned)
- HTTPS in production (recommended)

## Scalability Considerations

### Horizontal Scaling
- Microservices can be scaled independently
- Load balancer for distributing requests
- Database connection pooling

### Vertical Scaling
- Increase service instance resources
- Optimize database queries
- Implement caching layer (Redis)

### Performance Optimization
- Client-side caching
- Lazy loading for widgets
- Pagination for large datasets
- Database indexing on key columns
- Query result caching

## Technology Stack

### Frontend
- **Framework**: React 18.2
- **Build Tool**: Vite 5.0
- **Routing**: React Router 6
- **State Management**: Zustand + React Context
- **HTTP Client**: Axios
- **Charts**: Recharts
- **UI Framework**: Tailwind CSS
- **Icons**: Lucide React

### Backend
- **Language**: Python 3.8+
- **Framework**: Flask 3.0
- **Authentication**: PyJWT
- **CORS**: Flask-CORS
- **Database ORM**: SQLAlchemy (optional)

### Database
- **Primary**: SQLite 3 (metadata)
- **External**: Multiple DB support
  - Oracle (cx_Oracle)
  - MySQL (PyMySQL)
  - PostgreSQL (psycopg2)
  - SQL Server (pyodbc)
  - DB2 (ibm_db_sa)
  - Teradata (teradatasql)
  - Hive (pyhive)

### Development Tools
- **Package Manager**: npm, pip
- **Version Control**: Git
- **API Testing**: Postman/cURL

## Deployment Architecture

### Development
```
localhost:3000 (Frontend)
    ↓
localhost:5001-5005 (Backend Services)
    ↓
./it_operations.db (SQLite)
```

### Production (Recommended)
```
CDN/Web Server (Frontend - Static Files)
    ↓
API Gateway (Nginx/Kong)
    ↓
Load Balancer
    ↓
Backend Services (Docker Containers)
    ↓
PostgreSQL/MySQL (Production Database)
    ↓
Redis (Caching Layer)
```

## Monitoring & Observability

### Logging
- Service-level logging
- Audit trail in database
- Error tracking and alerting

### Metrics
- API response times
- Service health checks
- Database query performance
- User activity metrics

### Health Checks
- Service availability endpoints
- Database connection status
- External data source connectivity

## Future Enhancements

1. **Advanced Analytics**
   - Machine learning for anomaly detection
   - Predictive analytics
   - Trend analysis

2. **Enhanced Visualizations**
   - 3D charts
   - Heat maps
   - Network diagrams

3. **Collaboration Features**
   - Shared dashboards
   - Comments and annotations
   - Real-time collaboration

4. **Mobile Support**
   - Responsive design improvements
   - Native mobile apps
   - Push notifications

5. **Integration Capabilities**
   - Slack/Teams integration
   - JIRA integration
   - ServiceNow integration
   - Webhook support

6. **Advanced Security**
   - Two-factor authentication
   - SSO integration
   - Fine-grained permissions
   - Data encryption at rest

## Conclusion

This architecture provides a solid foundation for an IT operations dashboard with:
- Modularity and maintainability
- Scalability for growth
- Security best practices
- Extensibility for new features
- Performance optimization
- Clear separation of concerns
