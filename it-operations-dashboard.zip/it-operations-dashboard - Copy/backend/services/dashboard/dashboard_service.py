"""
Dashboard Microservice
Manages dashboards, pages, and widgets
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.database import DatabaseManager
from shared.utils import ResponseFormatter, DataUtils

app = Flask(__name__)
CORS(app)

db_manager = DatabaseManager()

# ============= DASHBOARD OPERATIONS =============

@app.route('/api/dashboard/dashboards', methods=['GET'])
def get_dashboards():
    """Get all dashboards for a user"""
    try:
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify(ResponseFormatter.error('User ID required')), 400
        
        dashboards = db_manager.execute_query(
            """SELECT dashboard_id, dashboard_name, description, is_default, 
                      created_at, updated_at
               FROM dashboards 
               WHERE user_id = ?
               ORDER BY is_default DESC, dashboard_name""",
            (user_id,)
        )
        
        return jsonify(ResponseFormatter.success(dashboards)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/dashboards', methods=['POST'])
def create_dashboard():
    """Create new dashboard"""
    try:
        data = request.json
        
        if not data.get('user_id') or not data.get('dashboard_name'):
            return jsonify(ResponseFormatter.error('User ID and dashboard name required')), 400
        
        # If this is set as default, unset other defaults
        if data.get('is_default'):
            db_manager.execute_write(
                "UPDATE dashboards SET is_default = 0 WHERE user_id = ?",
                (data['user_id'],)
            )
        
        dashboard_id = db_manager.execute_write(
            """INSERT INTO dashboards (user_id, dashboard_name, description, is_default)
               VALUES (?, ?, ?, ?)""",
            (data['user_id'], data['dashboard_name'], 
             data.get('description', ''), data.get('is_default', False))
        )
        
        # Create default page
        page_id = db_manager.execute_write(
            """INSERT INTO dashboard_pages (dashboard_id, page_name, page_subject, page_order)
               VALUES (?, ?, ?, ?)""",
            (dashboard_id, 'Overview', 'Main dashboard page', 0)
        )
        
        # Log audit
        db_manager.execute_write(
            "INSERT INTO audit_log (user_id, action, entity_type, entity_id) VALUES (?, ?, ?, ?)",
            (data['user_id'], 'create_dashboard', 'dashboard', dashboard_id)
        )
        
        return jsonify(ResponseFormatter.success({
            'dashboard_id': dashboard_id,
            'default_page_id': page_id
        }, 'Dashboard created successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/dashboards/<int:dashboard_id>', methods=['PUT'])
def update_dashboard(dashboard_id):
    """Update dashboard"""
    try:
        data = request.json
        
        update_fields = []
        params = []
        
        if 'dashboard_name' in data:
            update_fields.append('dashboard_name = ?')
            params.append(data['dashboard_name'])
        
        if 'description' in data:
            update_fields.append('description = ?')
            params.append(data['description'])
        
        if 'is_default' in data and data['is_default']:
            # Get user_id for this dashboard
            dashboard = db_manager.execute_query(
                "SELECT user_id FROM dashboards WHERE dashboard_id = ?",
                (dashboard_id,)
            )
            if dashboard:
                db_manager.execute_write(
                    "UPDATE dashboards SET is_default = 0 WHERE user_id = ?",
                    (dashboard[0]['user_id'],)
                )
            update_fields.append('is_default = ?')
            params.append(True)
        
        if not update_fields:
            return jsonify(ResponseFormatter.error('No fields to update')), 400
        
        update_fields.append('updated_at = CURRENT_TIMESTAMP')
        params.append(dashboard_id)
        
        query = f"UPDATE dashboards SET {', '.join(update_fields)} WHERE dashboard_id = ?"
        db_manager.execute_write(query, tuple(params))
        
        return jsonify(ResponseFormatter.success(message='Dashboard updated successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/dashboards/<int:dashboard_id>', methods=['DELETE'])
def delete_dashboard(dashboard_id):
    """Delete dashboard"""
    try:
        db_manager.execute_write(
            "DELETE FROM dashboards WHERE dashboard_id = ?",
            (dashboard_id,)
        )
        
        return jsonify(ResponseFormatter.success(message='Dashboard deleted successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


# ============= PAGE OPERATIONS =============

@app.route('/api/dashboard/dashboards/<int:dashboard_id>/pages', methods=['GET'])
def get_pages(dashboard_id):
    """Get all pages for a dashboard"""
    try:
        pages = db_manager.execute_query(
            """SELECT page_id, page_name, page_subject, page_order, layout_config,
                      created_at, updated_at
               FROM dashboard_pages 
               WHERE dashboard_id = ?
               ORDER BY page_order""",
            (dashboard_id,)
        )
        
        # Deserialize layout_config
        for page in pages:
            page['layout_config'] = DataUtils.deserialize_json(page['layout_config'])
        
        return jsonify(ResponseFormatter.success(pages)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/pages', methods=['POST'])
def create_page():
    """Create new page"""
    try:
        data = request.json
        
        if not data.get('dashboard_id') or not data.get('page_name'):
            return jsonify(ResponseFormatter.error('Dashboard ID and page name required')), 400
        
        # Get max page order
        max_order = db_manager.execute_query(
            "SELECT MAX(page_order) as max_order FROM dashboard_pages WHERE dashboard_id = ?",
            (data['dashboard_id'],)
        )
        
        page_order = (max_order[0]['max_order'] or 0) + 1
        
        page_id = db_manager.execute_write(
            """INSERT INTO dashboard_pages (dashboard_id, page_name, page_subject, 
                                           page_order, layout_config)
               VALUES (?, ?, ?, ?, ?)""",
            (data['dashboard_id'], data['page_name'], data.get('page_subject', ''),
             page_order, DataUtils.serialize_json(data.get('layout_config', {})))
        )
        
        return jsonify(ResponseFormatter.success({
            'page_id': page_id
        }, 'Page created successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/pages/<int:page_id>', methods=['PUT'])
def update_page(page_id):
    """Update page"""
    try:
        data = request.json
        
        update_fields = []
        params = []
        
        if 'page_name' in data:
            update_fields.append('page_name = ?')
            params.append(data['page_name'])
        
        if 'page_subject' in data:
            update_fields.append('page_subject = ?')
            params.append(data['page_subject'])
        
        if 'page_order' in data:
            update_fields.append('page_order = ?')
            params.append(data['page_order'])
        
        if 'layout_config' in data:
            update_fields.append('layout_config = ?')
            params.append(DataUtils.serialize_json(data['layout_config']))
        
        if not update_fields:
            return jsonify(ResponseFormatter.error('No fields to update')), 400
        
        update_fields.append('updated_at = CURRENT_TIMESTAMP')
        params.append(page_id)
        
        query = f"UPDATE dashboard_pages SET {', '.join(update_fields)} WHERE page_id = ?"
        db_manager.execute_write(query, tuple(params))
        
        return jsonify(ResponseFormatter.success(message='Page updated successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/pages/<int:page_id>', methods=['DELETE'])
def delete_page(page_id):
    """Delete page"""
    try:
        db_manager.execute_write(
            "DELETE FROM dashboard_pages WHERE page_id = ?",
            (page_id,)
        )
        
        return jsonify(ResponseFormatter.success(message='Page deleted successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


# ============= WIDGET OPERATIONS =============

@app.route('/api/dashboard/pages/<int:page_id>/widgets', methods=['GET'])
def get_widgets(page_id):
    """Get all widgets for a page"""
    try:
        widgets = db_manager.execute_query(
            """SELECT widget_id, widget_type, widget_title, data_source_id, query_text,
                      visualization_config, position_x, position_y, width, height,
                      refresh_interval, created_at, updated_at
               FROM widgets 
               WHERE page_id = ?
               ORDER BY position_y, position_x""",
            (page_id,)
        )
        
        # Deserialize visualization_config
        for widget in widgets:
            widget['visualization_config'] = DataUtils.deserialize_json(widget['visualization_config'])
        
        return jsonify(ResponseFormatter.success(widgets)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/widgets', methods=['POST'])
def create_widget():
    """Create new widget"""
    try:
        data = request.json
        
        if not data.get('page_id') or not data.get('widget_type'):
            return jsonify(ResponseFormatter.error('Page ID and widget type required')), 400
        
        widget_id = db_manager.execute_write(
            """INSERT INTO widgets (page_id, widget_type, widget_title, data_source_id,
                                   query_text, visualization_config, position_x, position_y,
                                   width, height, refresh_interval)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (data['page_id'], data['widget_type'], data.get('widget_title', ''),
             data.get('data_source_id'), data.get('query_text', ''),
             DataUtils.serialize_json(data.get('visualization_config', {})),
             data.get('position_x', 0), data.get('position_y', 0),
             data.get('width', 4), data.get('height', 3),
             data.get('refresh_interval', 300))
        )
        
        return jsonify(ResponseFormatter.success({
            'widget_id': widget_id
        }, 'Widget created successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/widgets/<int:widget_id>', methods=['PUT'])
def update_widget(widget_id):
    """Update widget"""
    try:
        data = request.json
        
        update_fields = []
        params = []
        
        updatable_fields = [
            'widget_type', 'widget_title', 'data_source_id', 'query_text',
            'position_x', 'position_y', 'width', 'height', 'refresh_interval'
        ]
        
        for field in updatable_fields:
            if field in data:
                update_fields.append(f'{field} = ?')
                params.append(data[field])
        
        if 'visualization_config' in data:
            update_fields.append('visualization_config = ?')
            params.append(DataUtils.serialize_json(data['visualization_config']))
        
        if not update_fields:
            return jsonify(ResponseFormatter.error('No fields to update')), 400
        
        update_fields.append('updated_at = CURRENT_TIMESTAMP')
        params.append(widget_id)
        
        query = f"UPDATE widgets SET {', '.join(update_fields)} WHERE widget_id = ?"
        db_manager.execute_write(query, tuple(params))
        
        return jsonify(ResponseFormatter.success(message='Widget updated successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/dashboard/widgets/<int:widget_id>', methods=['DELETE'])
def delete_widget(widget_id):
    """Delete widget"""
    try:
        db_manager.execute_write(
            "DELETE FROM widgets WHERE widget_id = ?",
            (widget_id,)
        )
        
        return jsonify(ResponseFormatter.success(message='Widget deleted successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5003, debug=True)
