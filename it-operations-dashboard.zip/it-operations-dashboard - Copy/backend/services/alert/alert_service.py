"""
Alert Microservice
Manages alerts, notifications, and alert history
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.database import DatabaseManager
from shared.utils import ResponseFormatter, DataUtils

app = Flask(__name__)
CORS(app)

db_manager = DatabaseManager()

@app.route('/api/alert/alerts', methods=['GET'])
def get_alerts():
    """Get all alerts for a user"""
    try:
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify(ResponseFormatter.error('User ID required')), 400
        
        alerts = db_manager.execute_query(
            """SELECT alert_id, alert_name, alert_type, widget_id, kpi_id,
                      condition_config, is_active, notification_channels,
                      created_at, updated_at
               FROM alerts 
               WHERE user_id = ?
               ORDER BY alert_name""",
            (user_id,)
        )
        
        for alert in alerts:
            alert['condition_config'] = DataUtils.deserialize_json(alert['condition_config'])
            alert['notification_channels'] = DataUtils.deserialize_json(alert['notification_channels'])
        
        return jsonify(ResponseFormatter.success(alerts)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/alert/alerts', methods=['POST'])
def create_alert():
    """Create new alert"""
    try:
        data = request.json
        
        if not data.get('user_id') or not data.get('alert_name'):
            return jsonify(ResponseFormatter.error('User ID and alert name required')), 400
        
        alert_id = db_manager.execute_write(
            """INSERT INTO alerts (user_id, alert_name, alert_type, widget_id, kpi_id,
                                  condition_config, is_active, notification_channels)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (data['user_id'], data['alert_name'], data.get('alert_type', 'threshold'),
             data.get('widget_id'), data.get('kpi_id'),
             DataUtils.serialize_json(data.get('condition_config', {})), True,
             DataUtils.serialize_json(data.get('notification_channels', [])))
        )
        
        return jsonify(ResponseFormatter.success({
            'alert_id': alert_id
        }, 'Alert created successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/alert/history', methods=['GET'])
def get_alert_history():
    """Get alert history"""
    try:
        user_id = request.args.get('user_id')
        alert_id = request.args.get('alert_id')
        limit = request.args.get('limit', 100, type=int)
        
        if alert_id:
            history = db_manager.execute_query(
                """SELECT * FROM alert_history 
                   WHERE alert_id = ?
                   ORDER BY triggered_at DESC
                   LIMIT ?""",
                (alert_id, limit)
            )
        elif user_id:
            history = db_manager.execute_query(
                """SELECT ah.* FROM alert_history ah
                   JOIN alerts a ON ah.alert_id = a.alert_id
                   WHERE a.user_id = ?
                   ORDER BY ah.triggered_at DESC
                   LIMIT ?""",
                (user_id, limit)
            )
        else:
            return jsonify(ResponseFormatter.error('User ID or Alert ID required')), 400
        
        return jsonify(ResponseFormatter.success(history)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5005, debug=True)
