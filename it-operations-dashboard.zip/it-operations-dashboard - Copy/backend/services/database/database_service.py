"""
Database Connection Microservice
Manages external database connections and query execution
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.database import DatabaseManager, ExternalDatabaseConnector
from shared.utils import SecurityUtils, ValidationUtils, ResponseFormatter, DataUtils

app = Flask(__name__)
CORS(app)

db_manager = DatabaseManager()
ext_db_connector = ExternalDatabaseConnector()

@app.route('/api/database/connections', methods=['GET'])
def get_connections():
    """Get all database connections for a user"""
    try:
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify(ResponseFormatter.error('User ID required')), 400
        
        connections = db_manager.execute_query(
            """SELECT connection_id, connection_name, db_type, host, port, 
                      database_name, username, is_active, created_at, updated_at
               FROM database_connections 
               WHERE user_id = ?
               ORDER BY connection_name""",
            (user_id,)
        )
        
        return jsonify(ResponseFormatter.success(connections)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/connections', methods=['POST'])
def create_connection():
    """Create new database connection"""
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['user_id', 'connection_name', 'db_type', 'host', 'port', 'username', 'password']
        for field in required_fields:
            if field not in data:
                return jsonify(ResponseFormatter.error(f'Missing required field: {field}')), 400
        
        # Validate database type
        if not ValidationUtils.validate_db_type(data['db_type']):
            return jsonify(ResponseFormatter.error('Invalid database type')), 400
        
        # Encrypt password
        encrypted_password = SecurityUtils.encrypt_password(data['password'])
        
        # Insert connection
        connection_id = db_manager.execute_write(
            """INSERT INTO database_connections 
               (user_id, connection_name, db_type, host, port, database_name, 
                username, password_encrypted, additional_params, is_active)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (data['user_id'], data['connection_name'], data['db_type'], 
             data['host'], data['port'], data.get('database_name', ''),
             data['username'], encrypted_password, 
             DataUtils.serialize_json(data.get('additional_params', {})), True)
        )
        
        # Log audit
        db_manager.execute_write(
            "INSERT INTO audit_log (user_id, action, entity_type, entity_id) VALUES (?, ?, ?, ?)",
            (data['user_id'], 'create_connection', 'database_connection', connection_id)
        )
        
        return jsonify(ResponseFormatter.success({
            'connection_id': connection_id
        }, 'Connection created successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/connections/<int:connection_id>', methods=['PUT'])
def update_connection(connection_id):
    """Update database connection"""
    try:
        data = request.json
        
        # Build dynamic update
        update_fields = []
        params = []
        
        updatable_fields = ['connection_name', 'host', 'port', 'database_name', 'username', 'is_active']
        
        for field in updatable_fields:
            if field in data:
                update_fields.append(f'{field} = ?')
                params.append(data[field])
        
        if 'password' in data:
            update_fields.append('password_encrypted = ?')
            params.append(SecurityUtils.encrypt_password(data['password']))
        
        if not update_fields:
            return jsonify(ResponseFormatter.error('No fields to update')), 400
        
        update_fields.append('updated_at = CURRENT_TIMESTAMP')
        params.append(connection_id)
        
        query = f"UPDATE database_connections SET {', '.join(update_fields)} WHERE connection_id = ?"
        db_manager.execute_write(query, tuple(params))
        
        return jsonify(ResponseFormatter.success(message='Connection updated successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/connections/<int:connection_id>', methods=['DELETE'])
def delete_connection(connection_id):
    """Delete database connection"""
    try:
        db_manager.execute_write(
            "DELETE FROM database_connections WHERE connection_id = ?",
            (connection_id,)
        )
        
        return jsonify(ResponseFormatter.success(message='Connection deleted successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/connections/<int:connection_id>/test', methods=['POST'])
def test_connection(connection_id):
    """Test database connection"""
    try:
        result = ext_db_connector.test_connection(connection_id, db_manager)
        
        if result['success']:
            return jsonify(ResponseFormatter.success(result)), 200
        else:
            return jsonify(ResponseFormatter.error(result.get('error', 'Connection failed'))), 400
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/query/execute', methods=['POST'])
def execute_query():
    """Execute query on external database"""
    try:
        data = request.json
        
        if not data.get('connection_id') or not data.get('query'):
            return jsonify(ResponseFormatter.error('Connection ID and query required')), 400
        
        # Sanitize query (basic check)
        try:
            ValidationUtils.sanitize_sql(data['query'])
        except ValueError as e:
            return jsonify(ResponseFormatter.error(str(e))), 400
        
        # Execute query
        result = ext_db_connector.execute_query(
            data['connection_id'], 
            data['query'], 
            db_manager
        )
        
        if result['success']:
            return jsonify(ResponseFormatter.success(result)), 200
        else:
            return jsonify(ResponseFormatter.error(result.get('error', 'Query execution failed'))), 400
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/query/save', methods=['POST'])
def save_query():
    """Save query for later use"""
    try:
        data = request.json
        
        required = ['user_id', 'query_name', 'query_text']
        for field in required:
            if field not in data:
                return jsonify(ResponseFormatter.error(f'Missing required field: {field}')), 400
        
        query_id = db_manager.execute_write(
            """INSERT INTO saved_queries (user_id, query_name, query_text, connection_id, description)
               VALUES (?, ?, ?, ?, ?)""",
            (data['user_id'], data['query_name'], data['query_text'],
             data.get('connection_id'), data.get('description', ''))
        )
        
        return jsonify(ResponseFormatter.success({
            'query_id': query_id
        }, 'Query saved successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/database/query/saved', methods=['GET'])
def get_saved_queries():
    """Get saved queries for a user"""
    try:
        user_id = request.args.get('user_id')
        
        if not user_id:
            return jsonify(ResponseFormatter.error('User ID required')), 400
        
        queries = db_manager.execute_query(
            """SELECT query_id, query_name, query_text, connection_id, description, 
                      created_at, updated_at
               FROM saved_queries 
               WHERE user_id = ?
               ORDER BY query_name""",
            (user_id,)
        )
        
        return jsonify(ResponseFormatter.success(queries)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002, debug=True)
