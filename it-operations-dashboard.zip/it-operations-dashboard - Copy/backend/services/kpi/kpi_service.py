"""
KPI Microservice
Manages KPI definitions and tracks KPI data over time
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os
from datetime import datetime, timedelta

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.database import DatabaseManager
from shared.utils import ResponseFormatter, DataUtils

app = Flask(__name__)
CORS(app)

db_manager = DatabaseManager()

@app.route('/api/kpi/definitions', methods=['GET'])
def get_kpi_definitions():
    """Get all KPI definitions"""
    try:
        category = request.args.get('category')
        
        if category:
            kpis = db_manager.execute_query(
                """SELECT * FROM kpi_definitions 
                   WHERE kpi_category = ?
                   ORDER BY kpi_name""",
                (category,)
            )
        else:
            kpis = db_manager.execute_query(
                "SELECT * FROM kpi_definitions ORDER BY kpi_category, kpi_name"
            )
        
        return jsonify(ResponseFormatter.success(kpis)), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/definitions', methods=['POST'])
def create_kpi_definition():
    """Create new KPI definition"""
    try:
        data = request.json
        
        if not data.get('kpi_name'):
            return jsonify(ResponseFormatter.error('KPI name required')), 400
        
        kpi_id = db_manager.execute_write(
            """INSERT INTO kpi_definitions 
               (kpi_name, kpi_category, description, unit_of_measure, 
                threshold_warning, threshold_critical)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (data['kpi_name'], data.get('kpi_category', ''),
             data.get('description', ''), data.get('unit_of_measure', ''),
             data.get('threshold_warning'), data.get('threshold_critical'))
        )
        
        return jsonify(ResponseFormatter.success({
            'kpi_id': kpi_id
        }, 'KPI definition created successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/definitions/<int:kpi_id>', methods=['PUT'])
def update_kpi_definition(kpi_id):
    """Update KPI definition"""
    try:
        data = request.json
        
        update_fields = []
        params = []
        
        updatable_fields = [
            'kpi_name', 'kpi_category', 'description', 'unit_of_measure',
            'threshold_warning', 'threshold_critical'
        ]
        
        for field in updatable_fields:
            if field in data:
                update_fields.append(f'{field} = ?')
                params.append(data[field])
        
        if not update_fields:
            return jsonify(ResponseFormatter.error('No fields to update')), 400
        
        update_fields.append('updated_at = CURRENT_TIMESTAMP')
        params.append(kpi_id)
        
        query = f"UPDATE kpi_definitions SET {', '.join(update_fields)} WHERE kpi_id = ?"
        db_manager.execute_write(query, tuple(params))
        
        return jsonify(ResponseFormatter.success(message='KPI definition updated successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/data', methods=['POST'])
def add_kpi_data():
    """Add KPI data point"""
    try:
        data = request.json
        
        if not data.get('kpi_id') or data.get('value') is None:
            return jsonify(ResponseFormatter.error('KPI ID and value required')), 400
        
        kpi_data_id = db_manager.execute_write(
            """INSERT INTO kpi_data (kpi_id, value, metadata)
               VALUES (?, ?, ?)""",
            (data['kpi_id'], data['value'], 
             DataUtils.serialize_json(data.get('metadata', {})))
        )
        
        # Check if thresholds are exceeded
        kpi_def = db_manager.execute_query(
            """SELECT kpi_name, threshold_warning, threshold_critical 
               FROM kpi_definitions WHERE kpi_id = ?""",
            (data['kpi_id'],)
        )
        
        if kpi_def:
            kpi = kpi_def[0]
            severity = None
            
            if kpi['threshold_critical'] and data['value'] >= kpi['threshold_critical']:
                severity = 'critical'
            elif kpi['threshold_warning'] and data['value'] >= kpi['threshold_warning']:
                severity = 'warning'
            
            if severity:
                # This would trigger alert creation (simplified here)
                pass
        
        return jsonify(ResponseFormatter.success({
            'kpi_data_id': kpi_data_id
        }, 'KPI data added successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/data/<int:kpi_id>', methods=['GET'])
def get_kpi_data(kpi_id):
    """Get KPI data for a specific KPI"""
    try:
        # Get time range parameters
        hours = request.args.get('hours', 24, type=int)
        limit = request.args.get('limit', 1000, type=int)
        
        # Calculate start time
        start_time = datetime.utcnow() - timedelta(hours=hours)
        
        data_points = db_manager.execute_query(
            """SELECT kpi_data_id, value, timestamp, metadata
               FROM kpi_data
               WHERE kpi_id = ? AND timestamp >= ?
               ORDER BY timestamp DESC
               LIMIT ?""",
            (kpi_id, start_time.isoformat(), limit)
        )
        
        # Deserialize metadata
        for point in data_points:
            point['metadata'] = DataUtils.deserialize_json(point['metadata'])
        
        # Get KPI definition
        kpi_def = db_manager.execute_query(
            "SELECT * FROM kpi_definitions WHERE kpi_id = ?",
            (kpi_id,)
        )
        
        return jsonify(ResponseFormatter.success({
            'kpi_definition': kpi_def[0] if kpi_def else None,
            'data_points': data_points,
            'count': len(data_points)
        })), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/data/<int:kpi_id>/latest', methods=['GET'])
def get_latest_kpi_value(kpi_id):
    """Get latest KPI value"""
    try:
        latest = db_manager.execute_query(
            """SELECT kpi_data_id, value, timestamp, metadata
               FROM kpi_data
               WHERE kpi_id = ?
               ORDER BY timestamp DESC
               LIMIT 1""",
            (kpi_id,)
        )
        
        if not latest:
            return jsonify(ResponseFormatter.error('No data available')), 404
        
        data = latest[0]
        data['metadata'] = DataUtils.deserialize_json(data['metadata'])
        
        # Get KPI definition for context
        kpi_def = db_manager.execute_query(
            "SELECT * FROM kpi_definitions WHERE kpi_id = ?",
            (kpi_id,)
        )
        
        # Determine status based on thresholds
        status = 'normal'
        if kpi_def:
            kpi = kpi_def[0]
            if kpi['threshold_critical'] and data['value'] >= kpi['threshold_critical']:
                status = 'critical'
            elif kpi['threshold_warning'] and data['value'] >= kpi['threshold_warning']:
                status = 'warning'
        
        return jsonify(ResponseFormatter.success({
            'kpi_definition': kpi_def[0] if kpi_def else None,
            'latest_value': data,
            'status': status
        })), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/data/<int:kpi_id>/statistics', methods=['GET'])
def get_kpi_statistics(kpi_id):
    """Get statistical summary of KPI data"""
    try:
        hours = request.args.get('hours', 24, type=int)
        start_time = datetime.utcnow() - timedelta(hours=hours)
        
        stats = db_manager.execute_query(
            """SELECT 
                   COUNT(*) as count,
                   AVG(value) as average,
                   MIN(value) as minimum,
                   MAX(value) as maximum,
                   SUM(value) as total
               FROM kpi_data
               WHERE kpi_id = ? AND timestamp >= ?""",
            (kpi_id, start_time.isoformat())
        )
        
        return jsonify(ResponseFormatter.success(stats[0] if stats else {})), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/kpi/categories', methods=['GET'])
def get_kpi_categories():
    """Get all unique KPI categories"""
    try:
        categories = db_manager.execute_query(
            "SELECT DISTINCT kpi_category FROM kpi_definitions WHERE kpi_category IS NOT NULL ORDER BY kpi_category"
        )
        
        return jsonify(ResponseFormatter.success([c['kpi_category'] for c in categories])), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5004, debug=True)
