"""
Authentication Microservice
Handles user authentication, registration, and session management
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.database import DatabaseManager
from shared.utils import SecurityUtils, ValidationUtils, ResponseFormatter

app = Flask(__name__)
CORS(app)

db_manager = DatabaseManager()

@app.route('/api/auth/register', methods=['POST'])
def register():
    """Register new user"""
    try:
        data = request.json
        
        # Validate input
        if not data.get('username') or not data.get('email') or not data.get('password'):
            return jsonify(ResponseFormatter.error('Missing required fields')), 400
        
        if not ValidationUtils.validate_email(data['email']):
            return jsonify(ResponseFormatter.error('Invalid email format')), 400
        
        # Check if user already exists
        existing_user = db_manager.execute_query(
            "SELECT user_id FROM users WHERE username = ? OR email = ?",
            (data['username'], data['email'])
        )
        
        if existing_user:
            return jsonify(ResponseFormatter.error('User already exists')), 409
        
        # Hash password and create user
        password_hash = SecurityUtils.hash_password(data['password'])
        
        user_id = db_manager.execute_write(
            """INSERT INTO users (username, email, password_hash, full_name, role) 
               VALUES (?, ?, ?, ?, ?)""",
            (data['username'], data['email'], password_hash, 
             data.get('full_name', ''), data.get('role', 'user'))
        )
        
        # Log audit
        db_manager.execute_write(
            "INSERT INTO audit_log (user_id, action, entity_type, entity_id, ip_address) VALUES (?, ?, ?, ?, ?)",
            (user_id, 'register', 'user', user_id, request.remote_addr)
        )
        
        return jsonify(ResponseFormatter.success({
            'user_id': user_id,
            'username': data['username']
        }, 'User registered successfully')), 201
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/auth/login', methods=['POST'])
def login():
    """User login"""
    try:
        data = request.json
        
        if not data.get('username') or not data.get('password'):
            return jsonify(ResponseFormatter.error('Missing credentials')), 400
        
        # Get user
        users = db_manager.execute_query(
            """SELECT user_id, username, email, password_hash, full_name, role 
               FROM users WHERE username = ?""",
            (data['username'],)
        )
        
        if not users:
            return jsonify(ResponseFormatter.error('Invalid credentials')), 401
        
        user = users[0]
        
        # Verify password
        if not SecurityUtils.verify_password(data['password'], user['password_hash']):
            return jsonify(ResponseFormatter.error('Invalid credentials')), 401
        
        # Create access token
        token = SecurityUtils.create_access_token({
            'user_id': user['user_id'],
            'username': user['username'],
            'role': user['role']
        })
        
        # Log audit
        db_manager.execute_write(
            "INSERT INTO audit_log (user_id, action, ip_address) VALUES (?, ?, ?)",
            (user['user_id'], 'login', request.remote_addr)
        )
        
        return jsonify(ResponseFormatter.success({
            'token': token,
            'user': {
                'user_id': user['user_id'],
                'username': user['username'],
                'email': user['email'],
                'full_name': user['full_name'],
                'role': user['role']
            }
        }, 'Login successful')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/auth/verify', methods=['POST'])
def verify_token():
    """Verify JWT token"""
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        
        if not token:
            return jsonify(ResponseFormatter.error('Token not provided')), 401
        
        payload = SecurityUtils.decode_access_token(token)
        
        if not payload:
            return jsonify(ResponseFormatter.error('Invalid or expired token')), 401
        
        return jsonify(ResponseFormatter.success(payload, 'Token valid')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/auth/user/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Get user details"""
    try:
        users = db_manager.execute_query(
            """SELECT user_id, username, email, full_name, role, created_at, updated_at 
               FROM users WHERE user_id = ?""",
            (user_id,)
        )
        
        if not users:
            return jsonify(ResponseFormatter.error('User not found')), 404
        
        return jsonify(ResponseFormatter.success(users[0])), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


@app.route('/api/auth/user/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    """Update user details"""
    try:
        data = request.json
        
        # Build dynamic update query
        update_fields = []
        params = []
        
        if 'full_name' in data:
            update_fields.append('full_name = ?')
            params.append(data['full_name'])
        
        if 'email' in data:
            if not ValidationUtils.validate_email(data['email']):
                return jsonify(ResponseFormatter.error('Invalid email format')), 400
            update_fields.append('email = ?')
            params.append(data['email'])
        
        if not update_fields:
            return jsonify(ResponseFormatter.error('No fields to update')), 400
        
        update_fields.append('updated_at = CURRENT_TIMESTAMP')
        params.append(user_id)
        
        query = f"UPDATE users SET {', '.join(update_fields)} WHERE user_id = ?"
        db_manager.execute_write(query, tuple(params))
        
        # Log audit
        db_manager.execute_write(
            "INSERT INTO audit_log (user_id, action, entity_type, entity_id) VALUES (?, ?, ?, ?)",
            (user_id, 'update_profile', 'user', user_id)
        )
        
        return jsonify(ResponseFormatter.success(message='User updated successfully')), 200
        
    except Exception as e:
        return jsonify(ResponseFormatter.error(str(e))), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
