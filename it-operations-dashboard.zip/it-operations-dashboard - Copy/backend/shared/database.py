"""
Shared database utilities for IT Operations Dashboard
"""
import sqlite3
from contextlib import contextmanager
from typing import List, Dict, Any, Optional
import json
from shared.utils import SecurityUtils

class DatabaseManager:
    """Manager for SQLite database operations"""
    
    def __init__(self, db_path: str = '../database/it_operations.db'):
        self.db_path = db_path
    
    @contextmanager
    def get_connection(self):
        """Get database connection with context manager"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Execute SELECT query and return results as list of dicts"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    def execute_write(self, query: str, params: tuple = ()) -> int:
        """Execute INSERT/UPDATE/DELETE and return last row id"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return cursor.lastrowid
    
    def execute_many(self, query: str, params_list: List[tuple]) -> None:
        """Execute multiple write operations"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.executemany(query, params_list)


class ExternalDatabaseConnector:
    """Connector for external databases (Oracle, Teradata, SQL Server, etc.)"""
    
    SUPPORTED_DATABASES = [
        'oracle', 'teradata', 'sqlserver', 'db2', 
        'mysql', 'postgresql', 'hive'
    ]
    
    def __init__(self):
        self.connections = {}
    
    def get_connection_string(self, db_type: str, host: str, port: int, 
                             database: str, username: str, password: str, 
                             additional_params: Optional[Dict] = None) -> str:
        """Generate connection string based on database type"""
        
        connection_strings = {
            'oracle': f"oracle+cx_oracle://{username}:{password}@{host}:{port}/{database}",
            'mysql': f"mysql+pymysql://{username}:{password}@{host}:{port}/{database}",
            'postgresql': f"postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}",
            'sqlserver': f"mssql+pyodbc://{username}:{password}@{host}:{port}/{database}?driver=ODBC+Driver+17+for+SQL+Server",
            'db2': f"ibm_db_sa://{username}:{password}@{host}:{port}/{database}",
            'teradata': f"teradatasql://{username}:{password}@{host}:{port}/{database}",
            'hive': f"hive://{username}:{password}@{host}:{port}/{database}"
        }
        
        return connection_strings.get(db_type.lower(), '')
    
    def test_connection(self, connection_id: int, db_manager: DatabaseManager) -> Dict[str, Any]:
        """Test database connection"""
        try:
            # Get connection details from database
            query = """
                SELECT connection_name, db_type, host, port, database_name, 
                       username, password_encrypted, additional_params
                FROM database_connections 
                WHERE connection_id = ? AND is_active = 1
            """
            result = db_manager.execute_query(query, (connection_id,))
            
            if not result:
                return {'success': False, 'error': 'Connection not found'}
            
            conn_info = result[0]
            
            # In a real implementation, you would:
            # 1. Decrypt the password
            # 2. Create actual connection using appropriate driver
            # 3. Test with a simple query
            
            return {
                'success': True,
                'message': f'Connection to {conn_info["connection_name"]} successful',
                'db_type': conn_info['db_type']
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def execute_query(self, connection_id: int, query: str, 
                     db_manager: DatabaseManager) -> Dict[str, Any]:
        """Execute query on external database"""
        try:
            # Get connection details
            conn_query = """
                SELECT connection_name, db_type, host, port, database_name, 
                       username, password_encrypted, additional_params
                FROM database_connections 
                WHERE connection_id = ? AND is_active = 1
            """
            result = db_manager.execute_query(conn_query, (connection_id,))
            
            if not result:
                return {'success': False, 'error': 'Connection not found'}
            
            conn_info = result[0]
            
            # Decrypt password
            password = SecurityUtils.decrypt_password(conn_info['password_encrypted'])
            
            # Execute query based on database type
            db_type = conn_info['db_type'].lower()
            
            if db_type == 'mysql':
                return self._execute_mysql_query(conn_info, password, query)
            elif db_type == 'postgresql':
                return self._execute_postgresql_query(conn_info, password, query)
            elif db_type == 'sqlite':
                return self._execute_sqlite_query(conn_info, password, query)
            else:
                return {
                    'success': False,
                    'error': f'Database type {db_type} not yet implemented. Please install the appropriate driver.'
                }
            
        except Exception as e:
            return {'success': False, 'error': f'Query execution error: {str(e)}'}
    
    def _execute_mysql_query(self, conn_info: Dict, password: str, query: str) -> Dict[str, Any]:
        """Execute query on MySQL database"""
        try:
            import pymysql
            
            # Create connection
            connection = pymysql.connect(
                host=conn_info['host'],
                port=conn_info['port'],
                user=conn_info['username'],
                password=password,
                database=conn_info['database_name'],
                cursorclass=pymysql.cursors.DictCursor
            )
            
            try:
                with connection.cursor() as cursor:
                    # Execute query
                    cursor.execute(query)
                    
                    # Fetch results
                    results = cursor.fetchall()
                    
                    # Get column names
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    
                    return {
                        'success': True,
                        'data': results,
                        'columns': columns,
                        'row_count': len(results)
                    }
            finally:
                connection.close()
                
        except ImportError:
            return {
                'success': False,
                'error': 'PyMySQL not installed. Install it with: pip install pymysql'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'MySQL query failed: {str(e)}'
            }
    
    def _execute_postgresql_query(self, conn_info: Dict, password: str, query: str) -> Dict[str, Any]:
        """Execute query on PostgreSQL database"""
        try:
            import psycopg2
            import psycopg2.extras
            
            # Create connection
            connection = psycopg2.connect(
                host=conn_info['host'],
                port=conn_info['port'],
                user=conn_info['username'],
                password=password,
                database=conn_info['database_name']
            )
            
            try:
                with connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:
                    # Execute query
                    cursor.execute(query)
                    
                    # Fetch results
                    results = cursor.fetchall()
                    
                    # Convert to list of dicts
                    data = [dict(row) for row in results]
                    
                    # Get column names
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    
                    return {
                        'success': True,
                        'data': data,
                        'columns': columns,
                        'row_count': len(data)
                    }
            finally:
                connection.close()
                
        except ImportError:
            return {
                'success': False,
                'error': 'psycopg2 not installed. Install it with: pip install psycopg2-binary'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'PostgreSQL query failed: {str(e)}'
            }
    
    def _execute_sqlite_query(self, conn_info: Dict, password: str, query: str) -> Dict[str, Any]:
        """Execute query on SQLite database"""
        try:
            import sqlite3
            
            # For SQLite, host is typically the file path
            db_path = conn_info.get('database_name') or conn_info.get('host')
            
            connection = sqlite3.connect(db_path)
            connection.row_factory = sqlite3.Row
            
            try:
                cursor = connection.cursor()
                cursor.execute(query)
                
                # Fetch results
                rows = cursor.fetchall()
                
                # Convert to list of dicts
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                data = [dict(zip(columns, row)) for row in rows]
                
                return {
                    'success': True,
                    'data': data,
                    'columns': columns,
                    'row_count': len(data)
                }
            finally:
                connection.close()
                
        except Exception as e:
            return {
                'success': False,
                'error': f'SQLite query failed: {str(e)}'
            }