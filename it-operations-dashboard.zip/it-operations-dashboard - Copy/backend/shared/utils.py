"""
Shared utility functions for IT Operations Dashboard
"""
import hashlib
import secrets
import json
from datetime import datetime, timedelta
from typing import Any, Dict, Optional
import jwt

class SecurityUtils:
    """Security-related utilities"""
    
    SECRET_KEY = secrets.token_hex(32)  # In production, use environment variable
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 60
    
    @staticmethod
    def hash_password(password: str) -> str:
        """Hash password using SHA256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        return SecurityUtils.hash_password(plain_password) == hashed_password
    
    @staticmethod
    def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=SecurityUtils.ACCESS_TOKEN_EXPIRE_MINUTES)
        
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SecurityUtils.SECRET_KEY, algorithm=SecurityUtils.ALGORITHM)
        return encoded_jwt
    
    @staticmethod
    def decode_access_token(token: str) -> Optional[Dict[str, Any]]:
        """Decode and verify JWT token"""
        try:
            payload = jwt.decode(token, SecurityUtils.SECRET_KEY, algorithms=[SecurityUtils.ALGORITHM])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.JWTError:
            return None
    
    @staticmethod
    def encrypt_password(password: str) -> str:
        """
        Encrypt database password for storage
        In production, use proper encryption like Fernet
        """
        # Simple base64 encoding for demo (NOT secure for production)
        import base64
        return base64.b64encode(password.encode()).decode()
    
    @staticmethod
    def decrypt_password(encrypted: str) -> str:
        """Decrypt database password"""
        import base64
        return base64.b64decode(encrypted.encode()).decode()


class DataUtils:
    """Data manipulation utilities"""
    
    @staticmethod
    def serialize_json(obj: Any) -> str:
        """Serialize object to JSON string"""
        return json.dumps(obj, default=str)
    
    @staticmethod
    def deserialize_json(json_str: str) -> Any:
        """Deserialize JSON string to object"""
        if not json_str:
            return None
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            return None
    
    @staticmethod
    def paginate(items: list, page: int = 1, page_size: int = 10) -> Dict[str, Any]:
        """Paginate list of items"""
        total = len(items)
        start = (page - 1) * page_size
        end = start + page_size
        
        return {
            'items': items[start:end],
            'total': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size
        }


class ValidationUtils:
    """Input validation utilities"""
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format"""
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_db_type(db_type: str) -> bool:
        """Validate database type"""
        valid_types = ['oracle', 'teradata', 'sqlserver', 'db2', 'mysql', 'postgresql', 'hive']
        return db_type.lower() in valid_types
    
    @staticmethod
    def sanitize_sql(query: str) -> str:
        """Basic SQL injection prevention"""
        # In production, use parameterized queries
        dangerous_keywords = ['DROP', 'DELETE', 'TRUNCATE', 'ALTER', 'CREATE']
        upper_query = query.upper()
        
        for keyword in dangerous_keywords:
            if keyword in upper_query and 'TABLE' in upper_query:
                raise ValueError(f"Dangerous SQL keyword detected: {keyword}")
        
        return query


class ResponseFormatter:
    """API response formatting"""
    
    @staticmethod
    def success(data: Any = None, message: str = "Success") -> Dict[str, Any]:
        """Format success response"""
        return {
            'success': True,
            'message': message,
            'data': data,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    @staticmethod
    def error(message: str, error_code: Optional[str] = None, details: Any = None) -> Dict[str, Any]:
        """Format error response"""
        return {
            'success': False,
            'message': message,
            'error_code': error_code,
            'details': details,
            'timestamp': datetime.utcnow().isoformat()
        }
