1. launch auth service in terminal # 1
   set PYTHONPATH=C:\development\GCP\projects\it-operations-dashboard\backend
   uv run services\auth\auth_service.py

2. launch database service in terminal # 2
   set PYTHONPATH=C:\development\GCP\projects\it-operations-dashboard\backend
   uv run services\database\database_service.py

3. launch dashboard service in terminal # 3
   set PYTHONPATH=C:\development\GCP\projects\it-operations-dashboard\backend
   uv run services\dashboard\dashboard_service.py

4. launch kpi service in terminal # 4
   set PYTHONPATH=C:\development\GCP\projects\it-operations-dashboard\backend
   uv run services\kpi\kpi_service.py

5. launch alert service in terminal # 5
   set PYTHONPATH=C:\development\GCP\projects\it-operations-dashboard\backend
   uv run services\alert\alert_service.py      