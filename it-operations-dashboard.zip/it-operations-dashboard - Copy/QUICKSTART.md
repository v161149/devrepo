# Quick Start Guide - IT Operations Dashboard

## 🚀 Get Started in 5 Minutes

### Step 1: Initialize Database (30 seconds)
```bash
cd database
python init_database.py
# ✅ Database created: it_operations.db
```

### Step 2: Start Backend Services (2 minutes)

Open 5 terminal windows and run:

**Terminal 1 - Auth Service**
```bash
cd backend/services/auth
pip install flask flask-cors pyjwt --break-system-packages
python auth_service.py
# Running on http://localhost:5001
```

**Terminal 2 - Database Service**
```bash
cd backend/services/database  
python database_service.py
# Running on http://localhost:5002
```

**Terminal 3 - Dashboard Service**
```bash
cd backend/services/dashboard
python dashboard_service.py
# Running on http://localhost:5003
```

**Terminal 4 - KPI Service**
```bash
cd backend/services/kpi
python kpi_service.py
# Running on http://localhost:5004
```

**Terminal 5 - Alert Service**
```bash
cd backend/services/alert
python alert_service.py
# Running on http://localhost:5005
```

### Step 3: Start Frontend (2 minutes)

```bash
cd frontend
npm install  # First time only
npm run dev
# Running on http://localhost:3000
```

### Step 4: Use the Application

1. **Open Browser**: Navigate to `http://localhost:3000`

2. **Register Account**:
   - Click "Register"
   - Username: `admin`
   - Email: `admin@example.com`
   - Password: `admin123`

3. **Explore Dashboard**:
   - View pre-loaded KPIs
   - Create new dashboards
   - Add database connections
   - Build custom visualizations

## 📊 Sample Data

The database is pre-loaded with 14 KPI definitions across 7 categories:
- System (Uptime, Response Time, Error Rate)
- Network (Latency, Bandwidth, Packet Loss)
- Incident (MTTR)
- Security (Threat Level, Vulnerabilities)
- Support (Tickets, Satisfaction)
- Resource (CPU, Memory, Storage)

## 🎯 Key Features to Try

### 1. Database Connections
- Go to "Database Connections"
- Click "New Connection"
- Configure connection to your database
- Test connection

### 2. Create Dashboard
- Click "New Dashboard"
- Name your dashboard
- Add charts and KPIs
- Arrange widgets

### 3. Query Builder
- Select a database connection
- Write SQL query
- Execute and visualize results
- Save for later use

### 4. KPI Monitoring
- View real-time KPI cards
- Check status indicators
- Monitor thresholds
- Track trends

### 5. Alerts
- Configure threshold alerts
- Set notification preferences
- View alert history

## 🛠️ Troubleshooting

### Backend Won't Start
```bash
# Install dependencies
pip install flask flask-cors pyjwt --break-system-packages
```

### Frontend Won't Start
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Database Not Found
```bash
# Reinitialize database
cd database
python init_database.py
```

### Port Already in Use
```bash
# Find and kill process
lsof -ti:5001 | xargs kill -9  # Change port number as needed
```

## 📁 Project Structure

```
it-operations-dashboard/
├── backend/          # Python microservices (5 services)
├── frontend/         # React application
├── database/         # SQLite database and schema
└── README.md         # Full documentation
```

## 🔗 API Endpoints

Once services are running:
- Auth: http://localhost:5001/api/auth/*
- Database: http://localhost:5002/api/database/*
- Dashboard: http://localhost:5003/api/dashboard/*
- KPI: http://localhost:5004/api/kpi/*
- Alert: http://localhost:5005/api/alert/*

## 📚 Next Steps

1. Read the full [README.md](README.md)
2. Explore the API documentation
3. Customize KPIs for your environment
4. Configure production databases
5. Set up automated alerts
6. Create custom dashboards

## 💡 Tips

- **Default Login**: Use the account you registered
- **Sample Data**: Pre-loaded KPIs are ready to use
- **Customization**: All widgets and dashboards are fully customizable
- **API First**: All features are available via REST APIs
- **Extensible**: Easy to add new microservices or features

## 🎉 You're Ready!

Your IT Operations Dashboard is now running. Start exploring and customizing it to fit your needs!
